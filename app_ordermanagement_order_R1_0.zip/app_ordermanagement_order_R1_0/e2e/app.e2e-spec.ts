import { AppOrdermanagemnetSupplychainmanagementPage } from './app.po';

describe('app-ordermanagemnet-supplychainmanagement App', function() {
  let page: AppOrdermanagemnetSupplychainmanagementPage;

  beforeEach(() => {
    page = new AppOrdermanagemnetSupplychainmanagementPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
