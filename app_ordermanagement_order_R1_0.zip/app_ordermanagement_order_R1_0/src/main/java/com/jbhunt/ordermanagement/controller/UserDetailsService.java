package com.jbhunt.ordermanagement.controller;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jbhunt.hrms.EOIAPIUtil.apiutil.EOIAPIUtil;
import com.jbhunt.hrms.EOIAPIUtil.exception.AdHocSearchParseException;
import com.jbhunt.hrms.EOIAPIUtil.exception.AuditInformationException;
import com.jbhunt.hrms.EOIAPIUtil.exception.EOIAPIException;
import com.jbhunt.hrms.EOIAPIUtil.exception.RecordNotFoundException;
import com.jbhunt.hrms.EOIAPIUtil.exception.SizeLimitExceededException;
import com.jbhunt.hrms.EOIAPIUtil.exception.TooManyRecordsException;
import com.jbhunt.hrms.eoi.api.dto.adhoc.AdHocPersonDTO;
import com.jbhunt.hrms.eoi.api.dto.adhoc.AdHocPersonsDTO;
import com.jbhunt.hrms.eoi.api.dto.person.PersonDTO;
import com.jbhunt.ordermanagement.order.dto.UserDetailDTO;
import com.jbhunt.security.boot.ldap.client.LdapClient;
import com.jbhunt.ws.ldap.models.JBHUser;
import com.jbhunt.ws.ldap.models.constants.JBHLdapUserAttributes;

import lombok.extern.slf4j.Slf4j;

/**
 * @author rcon452
 *
 */
@Service
@Slf4j
public class UserDetailsService {

	private LdapClient ldapClient;

	private EOIAPIUtil eoiapiUtil;

	/**
	 * @param ldapClient
	 * @param eoiapiUtil
	 */
	@Autowired
	public UserDetailsService(LdapClient ldapClient, EOIAPIUtil eoiapiUtil) {
		this.ldapClient = ldapClient;
		this.eoiapiUtil = eoiapiUtil;
	}

	/**
	 * @param userID
	 * @return
	 */
	public List<AdHocPersonDTO> getPeopleByCriteria(String userID) {
		AdHocPersonsDTO adHocPersonsDTO = null;
		List<AdHocPersonDTO> adHocPersonDTOs = null;
		try {
			adHocPersonsDTO = eoiapiUtil.getPeopleByCriteria("select Person.UserID",
					"Person.IsActive eq true AND Person.UserID LIKE '" + userID + "%'");
			if (Optional.ofNullable(adHocPersonsDTO).isPresent()) {
				adHocPersonDTOs = adHocPersonsDTO.getPeople();
			}
		} catch (RecordNotFoundException | TooManyRecordsException | AuditInformationException | EOIAPIException
				| AdHocSearchParseException | SizeLimitExceededException e) {
			log.debug("Problem occured while retriving values", e);
		}
		return adHocPersonDTOs;
	}

	/**
	 * @param userID
	 * @return UserDetailDTO
	 */
	public UserDetailDTO fetchUserDetails(String userID) {
		UserDetailDTO userDetailDTO = findUserLdapDetails(userID);
		findUserEOIDetails(userID, userDetailDTO);
		return userDetailDTO;
	}

	/**
	 * Find EOI details for the given UserID
	 * 
	 * @param userID
	 * @param userDetailDTO
	 */
	private void findUserEOIDetails(String userID, UserDetailDTO userDetailDTO) {
		try {
			PersonDTO personDTO = eoiapiUtil.getPersonByUserID(userID);
			if (Optional.ofNullable(personDTO).isPresent()) {
				userDetailDTO.setBusinessUnit(personDTO.getBusinessUnit());
				userDetailDTO.setPreferredName(personDTO.getPrefName());
			}
		} catch (RecordNotFoundException | TooManyRecordsException | AuditInformationException | EOIAPIException e) {
			log.debug("Problem occured while retriving values", e);
		}
	}

	/**
	 * Find ldap details for the given UserID
	 * 
	 * @param userID
	 * @return UserDetailDTO
	 */
	private UserDetailDTO findUserLdapDetails(String userID) {
		Set<String> userIDs = new HashSet<>();
		userIDs.add(userID);
		Set<JBHLdapUserAttributes> fieldsToGet = new HashSet<>();
		fieldsToGet.add(JBHLdapUserAttributes.FIRST_NAME);
		fieldsToGet.add(JBHLdapUserAttributes.LAST_NAME);
		fieldsToGet.add(JBHLdapUserAttributes.AD_USERID);
		fieldsToGet.add(JBHLdapUserAttributes.EMAIL);
		fieldsToGet.add(JBHLdapUserAttributes.PHONE);
		fieldsToGet.add(JBHLdapUserAttributes.EMPLOYEE_NUMBER);
		fieldsToGet.add(JBHLdapUserAttributes.DISPLAY_NAME);
		List<JBHUser> jbhUsers = (List<JBHUser>) ldapClient.findUsersByUserId(userIDs, fieldsToGet);
		UserDetailDTO userDetailDTO = new UserDetailDTO();
		if (Optional.ofNullable(jbhUsers).isPresent() && !jbhUsers.isEmpty()) {
			JBHUser jbhUser = jbhUsers.stream().findFirst().get();
			userDetailDTO.setUserId(jbhUser.getUserId());
			userDetailDTO.setEmailAddress(jbhUser.getEmail());
			userDetailDTO.setFirstName(jbhUser.getFirstName());
			userDetailDTO.setLastName(jbhUser.getLastName());
			userDetailDTO.setEmployeeId(jbhUser.getEmployeeNumber());
			userDetailDTO.setPhoneNumber(jbhUser.getPhone());
			userDetailDTO.setDisplayName(jbhUser.getDisplayName());
		}
		return userDetailDTO;
	}
}
