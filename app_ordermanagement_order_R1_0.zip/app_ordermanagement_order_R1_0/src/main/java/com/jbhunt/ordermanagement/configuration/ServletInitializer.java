package com.jbhunt.ordermanagement.configuration;

import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;

import com.jbhunt.ordermanagement.Application;


/**
 * 
 *
 */
//@Order(value=Ordered.LOWEST_PRECEDENCE)
public class ServletInitializer extends org.springframework.boot.web.support.SpringBootServletInitializer {

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.boot.context.web.SpringBootServletInitializer#
	 * configure(org.springframework.boot.builder.SpringApplicationBuilder)
	 */
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(Application.class);
	}

}