package com.jbhunt.ordermanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.jbhunt.hrms.eoi.api.dto.adhoc.AdHocPersonDTO;
import com.jbhunt.ordermanagement.order.dto.UserDetailDTO;

/**
 * @author rcon452
 *
 */
@RestController
public class UserDetailsController {

	private UserDetailsService userDetailsService;

	@Autowired
	public UserDetailsController(UserDetailsService userDetailsService) {
		this.userDetailsService = userDetailsService;

	}

	/**
	 * @param userID
	 * @return
	 */
	@RequestMapping(value = "/users/{userID}", method = RequestMethod.GET)
	@ResponseBody
	public UserDetailDTO fetchUserDetails(@PathVariable("userID") String userID) {
		return userDetailsService.fetchUserDetails(userID);
	}

	/**
	 * @param userID
	 * @return
	 */
	@RequestMapping(value = "/getPeopleByCriteria/{userID}", method = RequestMethod.GET)
	@ResponseBody
	public List<AdHocPersonDTO> getPeopleByCriteria(@PathVariable("userID") String userID) {
		return userDetailsService.getPeopleByCriteria(userID);
	}
}
