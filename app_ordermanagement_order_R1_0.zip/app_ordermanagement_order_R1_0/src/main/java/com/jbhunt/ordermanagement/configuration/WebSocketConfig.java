package com.jbhunt.ordermanagement.configuration;

import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.session.ExpiringSession;
import org.springframework.session.web.socket.config.annotation.AbstractSessionWebSocketMessageBrokerConfigurer;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;

import com.jbhunt.biz.securepid.PIDCredentials;
import com.jbhunt.ordermanagement.properties.OrderProperties;

@Configuration
@EnableWebSocketMessageBroker
public class WebSocketConfig extends AbstractSessionWebSocketMessageBrokerConfigurer<ExpiringSession> {
	
	private final PIDCredentials pidCredentials;
	private final OrderProperties orderProperties;
	
	public WebSocketConfig(OrderProperties orderProperties, PIDCredentials pidCredentials){
		this.orderProperties = orderProperties;
		this.pidCredentials = pidCredentials;
	}
	  
    @Override
    public void configureMessageBroker(MessageBrokerRegistry config) {
        config.enableStompBrokerRelay("/topic", "/queue").setRelayHost(orderProperties.getHost())
                .setRelayPort(orderProperties.getPort())
                .setVirtualHost(orderProperties.getHost()).setSystemLogin(pidCredentials.getUsername())
                .setSystemPasscode(pidCredentials.getPassword()).setClientLogin(pidCredentials.getUsername())
                .setClientPasscode(pidCredentials.getPassword());
        config.setApplicationDestinationPrefixes("/app");
    }

    @Override
    public void configureStompEndpoints(StompEndpointRegistry registry) {
        // use the /messaging endpoint (prefixed with /app as configured above)
        // for incoming requests
        registry.addEndpoint("/messaging").withSockJS();
    }
}
