package com.jbhunt.ordermanagement.configuration;


import java.util.Arrays;

import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.hateoas.hal.Jackson2HalModule;
import org.springframework.http.MediaType;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.http.converter.xml.Jaxb2RootElementHttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jbhunt.biz.securepid.PIDCredentials;
import com.jbhunt.ordermanagement.interceptor.BasicAuthInterceptor;

@Configuration
public class RestTemplateConfiguration {
    
    private static final int CONNECTION_MAX_TOTAL = 10; 
    
    private final PIDCredentials pidCredentials;

    @Autowired
    public RestTemplateConfiguration(PIDCredentials pidCredentials){
        this.pidCredentials = pidCredentials;       
    }
    
    @Bean
    public RestTemplate restTemplate() {     
        final ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        mapper.registerModule(new Jackson2HalModule());
        MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
        converter.setSupportedMediaTypes(MediaType.parseMediaTypes("application/hal+json, application/json"));
        converter.setObjectMapper(mapper);
        final RestTemplate restTemplate = new RestTemplate(Arrays.asList(converter));
        Jaxb2RootElementHttpMessageConverter jaxbMessageConverter = new Jaxb2RootElementHttpMessageConverter();
        restTemplate.getMessageConverters().add(jaxbMessageConverter);
        BasicAuthInterceptor basicAuthInterceptor = new BasicAuthInterceptor(pidCredentials.getUsername(),
                pidCredentials.getPassword());
        restTemplate.getInterceptors().add(basicAuthInterceptor);
        final PoolingHttpClientConnectionManager connManager = new PoolingHttpClientConnectionManager();
        connManager.setMaxTotal(CONNECTION_MAX_TOTAL);
        final HttpClient httpClient = HttpClientBuilder.create().setConnectionManager(connManager).build();
        ClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);
        restTemplate.setRequestFactory(requestFactory);
        return restTemplate;
    }

}
