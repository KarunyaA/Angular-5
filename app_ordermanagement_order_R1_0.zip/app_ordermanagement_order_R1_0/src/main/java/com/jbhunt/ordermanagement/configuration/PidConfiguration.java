package com.jbhunt.ordermanagement.configuration;

import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.web.socket.config.annotation.AbstractWebSocketMessageBrokerConfigurer;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;

@Configuration
@EnableWebSocketMessageBroker
public class PidConfiguration extends AbstractWebSocketMessageBrokerConfigurer {

    @Override
    public void configureMessageBroker(MessageBrokerRegistry config) {
        // use the /topic prefix for outgoing WebSocket communication
        //config.enableStompBrokerRelay("/topic","/queue").setRelayHost("winx-v0672.jbhunt.com").setRelayPort(61616);
    	//config.enableStompBrokerRelay("/topic","/queue").setRelayHost("amq62-dev1").setRelayPort(61613);
    	
  //      config.enableSimpleBroker("/topic","/queue");
       // config.setUserDestinationPrefix("/topic/unresolved-user-dest");

       // use the /app prefix for others
        config.setApplicationDestinationPrefixes("/app");
    }

    @Override
    public void registerStompEndpoints(StompEndpointRegistry registry) {
        // use the /messaging endpoint (prefixed with /app as configured above) for incoming requests
        registry.addEndpoint("/messaging").withSockJS();
    }
}
