/* tslint:disable:no-unused-variable */

import { async, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';

import { AppComponent } from './app.component';
import { CoreModule } from './core/core.module';
import { SimpleNotificationsModule } from 'angular2-notifications';
import { SpinnerComponent, SpinnerService } from './shared/spinner/index';
import { JBHGlobals } from './app.service';

import { NotificationsService } from 'angular2-notifications';

import { ApiClientService } from './shared/jbh-app-services/api-client.service';
import { LoggerService } from './shared/jbh-app-services/logger.service';
import { AppSharedDataService } from './shared/jbh-app-services/app-shared-data.service';
import { LocalStorageService } from './shared/jbh-app-services/local-storage.service';
import { ShortcutkeyService } from './shared/jbh-app-services/shortcutkey.service';
import { TemplateJsonTransformerService } from './features/create-orders/templates/template-json-transformer.service';
import { MouseEventService } from './shared/jbh-app-services/mouseevent.service';

describe('AppComponent', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule, CoreModule, SimpleNotificationsModule
      ],
      declarations: [
        AppComponent, SpinnerComponent
      ],
      providers: [SpinnerService,
        JBHGlobals,
        ApiClientService,
        LoggerService,
        AppSharedDataService,
        LocalStorageService,
        ShortcutkeyService,
        TemplateJsonTransformerService,
        MouseEventService,
        NotificationsService
      ]
    });
    TestBed.compileComponents();
  });

  it('should create the app', async(() => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  }));

});
