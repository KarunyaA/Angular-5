import {
    Component,
    Input,
    OnInit,
    ViewChild
} from '@angular/core';
// import { ActivatedRoute } from '@angular/router';
// import { Observable } from 'rxjs/Observable';
import {
    JBHGlobals
} from './../../../../app.service';
import {
    OrderService
} from './../services/order.service';
import {
    ChargesComponent
} from './charges/charges.component';
import {
    DocumentsComponent
} from './documents/documents.component';
import {
    InstructionsComponent
} from './instructions/instructions.component';
import {
    ActivatedRoute
} from '@angular/router';
import {
    StopSharedDataService
} from '../../orders/add-stops/services/stop-shared-data.service';

@Component({
    selector: 'app-manageoverlay',
    templateUrl: './manageoverlay.component.html',
    styleUrls: ['./manageoverlay.component.scss']
})
export class ManageoverlayComponent implements OnInit {
    subscription: any;
    orderData: any;
    orderId: any;
    manageOverlayFixed = false;
    manageOverlayIcon = false;
    @ViewChild('comments') comments;
    @ViewChild('instructions') instructions;
    @ViewChild('reference') reference;
    @ViewChild('documents') documents;
    @ViewChild('charges') charges;
    @ViewChild(ChargesComponent) ChargesComponent: any;
    @ViewChild(DocumentsComponent) DocumentsComponent: any;
    @ViewChild(InstructionsComponent) InsComponent: any;
    @Input() isCurrViewTemplate = false;

    constructor(
        public jbhGlobals: JBHGlobals,
        public orderService: OrderService,
        public stopSharedDataService: StopSharedDataService,
        public route: ActivatedRoute) {

    }
    ngOnInit(): void {
        this.setUpKeyboardShortcuts();
        if (!this.jbhGlobals.utils.isEmpty(this.route.snapshot.params.id)) {
            this.orderId = Number(this.route.snapshot.params.id);
            this.stopSharedDataService.getStopsSummary(this.orderId);
        };

    }

    setUpKeyboardShortcuts() {
        this.jbhGlobals.shortkeys.getData().subscribe(data => {
            if (data.keyCode === 'ctrl+shift+!' || data.keyCode === 'ctrl+shift+1') {
                this.comments.nativeElement.parentElement.focus();
                this.comments.nativeElement.click();
            } else if (data.keyCode === 'ctrl+shift+@' || data.keyCode === 'ctrl+shift+2') {
                this.documents.nativeElement.parentElement.focus();
                this.documents.nativeElement.click();
            } else if (data.keyCode === 'ctrl+shift+#' || data.keyCode === 'ctrl+shift+3') {
                this.reference.nativeElement.parentElement.focus();
                this.reference.nativeElement.click();
            } else if (data.keyCode === 'ctrl+shift+$' || data.keyCode === 'ctrl+shift+4') {
                this.instructions.nativeElement.parentElement.focus();
                this.instructions.nativeElement.click();
            } else if (data.keyCode === 'ctrl+shift+%' || data.keyCode === 'ctrl+shift+5') {
                this.charges.nativeElement.parentElement.focus();
                this.charges.nativeElement.click();
            } else { }
        });
    }
    clickManageTab() {
        this.ChargesComponent.chargeTabClick();
    }
    clickDocumentTab() {
        this.DocumentsComponent.documentTabClick();
    }
    clickInstructionTab() {
        this.InsComponent.instructionTabClick();
    }
	onFixedToolbar() {
		this.manageOverlayFixed = !this.manageOverlayFixed;
		this.manageOverlayIcon = !this.manageOverlayIcon;
	}
	getManageOverlayIcon() {
		return this.manageOverlayIcon ? 'fa fa-stop-circle-o' : 'fa fa-circle-o';
	}
}
