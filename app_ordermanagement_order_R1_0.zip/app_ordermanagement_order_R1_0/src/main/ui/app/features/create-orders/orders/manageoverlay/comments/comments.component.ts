import {
  Component,
  OnInit,
  ViewChild
} from '@angular/core';
import {
  ActivatedRoute,
  Router
} from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import {
  OrderService
} from '../../services/order.service';
import {
  JBHGlobals
} from '../../../../../app.service';
import {
  StopSharedDataService
} from '../../../orders/add-stops/services/stop-shared-data.service';
import {
  CommentsModel
} from './models/comments.model';
import {
  CommentsService
} from './services/comments.service';
import {
  ViewOrderService
} from '../../../../view-order/services/view-order.service';
import * as jsonpatch from 'fast-json-patch';

@Component({
  selector: 'app-comments',
  templateUrl: './comments.component.html',
  styleUrls: ['./comments.component.scss'],
  providers: [CommentsService]
})

export class CommentsComponent implements OnInit {
  // tslint:disable:member-access
  @ViewChild('cmntTxtArea') templateTypeReference: any;
  @ViewChild('cmntTagRef') tagFieldReference: any;
  @ViewChild('popInstance') popInstance: any;
  jsonpatch: any;
  rateSheetBlock: boolean;
  tagTypeClass: string;
  commentsModel: CommentsModel; // importing Model
  commentsTagData: any = ['Order'];
  commentsFilter: any = ['All Tags'];
  commentsTagDataDuplicate: any = this.commentsTagData;
  commentSection: FormGroup

  constructor(public orderService: OrderService,
    public jbhGlobals: JBHGlobals,
    public formBuilder: FormBuilder,
    public stopSharedDataService: StopSharedDataService,
    public route: ActivatedRoute,
    public router: Router,
    public commentsService: CommentsService,
    public viewOrderService: ViewOrderService
  ) {
    this.jsonpatch = jsonpatch;
  }

  ngOnInit(): void {
    this.commentsModel = new CommentsModel(); // Model instance
    this.commentsModel.orderData = '';
    this.viewOrderService.getData().subscribe(sharedOrderData => {
      if (!this.jbhGlobals.utils.isEmpty(sharedOrderData)) {
        const sharedOrderDetails = sharedOrderData;
        if (sharedOrderDetails) {
          this.commentsModel.orderData = sharedOrderDetails[
            'lastUpdateTimestampString'];
        }
      }
    });
    this.commentSection = this.formBuilder.group({
      'commentLevel': '',
      'commentTxtarea': ['', Validators.required]
    })

    this.commentsModel.currentPage = this.router.url.split('?')[0].substring(
      1, this.router
        .url.length).toString().toLowerCase();
    if (this.commentsModel.currentPage === 'manageratesheet') {
      this.rateSheetBlock = true;
      this.tagTypeClass = '';
    } else {
      this.rateSheetBlock = false;
      this.tagTypeClass = 'tagFieldCmntDiv';
    }
    this.route.queryParams.subscribe(
      (queryParam: any) => {
        if (!this.jbhGlobals.utils.isEmpty(queryParam['id'])) {
          this.commentsModel.orderId = Number(queryParam['id']);
        }
      });

    this.stopSharedDataService.getData().subscribe(data => {
      if (!this.jbhGlobals.utils.isEmpty(data)) {
        if (data[0].action === 'add') {
          this.commentsModel.stopAndIds = data[0].data;
          this.loadStopTags();
          // this.reloadStopTags();
        }
      }
    });

    // OrderDTO service
    if (this.commentsModel.orderId) {

      if (!this.jbhGlobals.utils.isEmpty(this.commentsModel.stopAndIds)) {
        this.loadStopTags();
      }

      // Comments List Initial
      this.commentsModel.commentsDto = {
        commentPath: '/comments',
        commentID: this.commentsModel.orderId,
        endpoint: this.jbhGlobals.endpoints.order.getInitialCommentsList
      };

      this.commentsService.loadComments(this.commentsModel.commentsDto).subscribe(
        data => {
          // console.log(22222222, data);
          this.commentsModel.loadCmnts = data;
          if (this.commentsModel.loadCmnts && this.commentsModel.loadCmnts
            .length !==
            0) {
            this.loadCommentsList();
          }
        });

    }

    // Using JBHGlobals services
    this.commentsService.commentsType(this.jbhGlobals.endpoints.order.getCommentType)
      .subscribe(data => {
        console.log(11111111111, data);
        this.commentsModel.cmntTypes = data;
      });

  }

  getTimeStampForVIewOrder() {
    this.commentsModel.orderData = null;
    this.viewOrderService.getData().subscribe(sharedOrderData => {
      if (!this.jbhGlobals.utils.isEmpty(sharedOrderData)) {
        const sharedOrderDetails = sharedOrderData;
        if (sharedOrderDetails) {
          this.commentsModel.orderData = sharedOrderDetails[
            'lastUpdateTimestampString'];
        }
      }
    });
  }

  onSelectTemplateType($event) {
    // need to append value to textarea
    this.commentsModel.txtAreaText = $event.text;
  }

  onRemoveTemplateType($event) {
    // need to delete the appended data in textarea
    this.commentsModel.txtAreaText = null;
  }

  loadStopTags() {
    this.commentsTagData = ['Order'];
    if (!this.rateSheetBlock) {
      if (this.commentsModel.stopAndIds && this.commentsModel.stopAndIds.length !==
        0) {
        for (let i = 0; i < this.commentsModel.stopAndIds.length; i++) {
          if (this.commentsModel.stopAndIds[i].stop.stopID !== null &&
            this.commentsModel
              .stopAndIds[i].stop.stopID !== '') {
            const stpNbr = this.commentsModel.stopAndIds[i].stop.stopSequenceNumber;
            this.commentsTagData.push('Stop ' + stpNbr);
            this.commentsTagData = this.jbhGlobals.utils.uniq(this.commentsTagData);
          }
        }
        this.tagFieldReference.autocompleteItems = this.commentsTagData;
      }
    }

  }

  reloadStopTags(cmntTagRef) {

    if (!this.rateSheetBlock) {
      if (this.commentsModel.stopAndIds) { // Form loading OrderDto & Comments
        for (let i = 0; i < this.commentsModel.stopAndIds.length; i++) {
          const stpNbr = this.commentsModel.stopAndIds[i].stop.stopSequenceNumber;
          this.commentsTagData.push('Stop ' + stpNbr);
          this.commentsTagData = this.jbhGlobals.utils.uniq(this.commentsTagData);
          const tagFieldCmnts = cmntTagRef;
          tagFieldCmnts.autocompleteItems = this.commentsTagData;
        }
      }
    }

  }

  getRemovedCmntVal(CurrentCmntValue, cmntTagRef) {
    this.commentsModel.cmntTagReference = cmntTagRef;
    this.commentsModel.cmmntSgtnsList = [];

    const stop = CurrentCmntValue.text.substring(0, 4).toLowerCase();
    if (CurrentCmntValue.text.toLowerCase().toString() === 'order') {
      this.commentsTagData = ['Order'];
      this.loadStopTags();
      this.commentsTagData = this.jbhGlobals.utils.uniq(this.commentsTagData);
    } else if (stop.toString() === 'stop') {
      this.commentsTagData = [];
      this.commentsTagData = ['Order'];
      this.loadStopTags();
      this.commentsTagData = this.jbhGlobals.utils.uniq(this.commentsTagData);
    }
    if (CurrentCmntValue.text.toLowerCase().toString() !== 'order' && stop
      .toString() !==
      'stop' && this
        .commentsTagData.length !== 1) {
      this.commentsModel.cmmntSgtnsList = []; // Clearing the old templateType suggestions
      this.templateTypeReference.active = []; // Clearing the active templateType Tag
      if (this.commentsModel.cmntTypes) {
        const commentTypeObj = this.commentsModel.cmntTypes._embedded.commentTypes;
        this.commentsTagData = [];
        for (let i = 0; i <= commentTypeObj.length - 1; i++) { // For adding noOfStops
          this.commentsTagData.push(commentTypeObj[i].commentTypeDescription);
        }
        this.commentsTagData = this.commentsTagData;
      }
    }
    if (CurrentCmntValue.text.toLowerCase().toString() !== 'order' && stop
      .toString() !==
      'stop' && this
        .commentsTagData.length === 1) {
      this.commentsTagData = ['Order'];
      this.loadStopTags();
      this.commentsTagData = this.jbhGlobals.utils.uniq(this.commentsTagData);
    }

  }

  currentTags(tagsArr) {
    // To empty TagSuggestions after two Tags
    this.commentsModel.tagsArrLength = tagsArr.length;
    this.commentsModel.allTagsArray = tagsArr;
    if (tagsArr.length === 2) {
      this.commentsTagData = [];
    }
    if (tagsArr.length === 0) {
      this.commentsTagData = [];
      this.loadStopTags();
    }

    // Validations
    if (this.commentsModel.allTagsArray.length === 2) {
      this.commentsModel.tagValidator = false;
    } else if (this.commentsModel.allTagsArray.length !== 2) {
      this.commentsModel.tagValidator = true;
    }

  }

  getCurrentCmntVal(CurrentCmntValue, cmntTagRef, cmntTxtArea) {
    this.commentsModel.cmntTagReference = cmntTagRef;
    const stop = CurrentCmntValue.text.substring(0, 4).toLowerCase();

    // Setting & getting commentTypes Frm Service.
    if (stop.toString() !== 'orde' && stop.toString() !== 'stop' && this.commentsModel
      .cmntTypes) {
      this.commentsModel.cmmntSgtnsList = []; // Clearing the old templateType suggestions
      this.templateTypeReference.active = []; // Clearing the active templateType Tag
      for (let z = 0; z < this.commentsModel.cmntTypes._embedded.commentTypes
        .length; z++) {
        if (this.commentsModel.cmntTypes._embedded.commentTypes[z].commentTypeDescription ===
          CurrentCmntValue.text) {
          this.commentsModel.cmntTypCodeParam = this.commentsModel.cmntTypes
            ._embedded
            .commentTypes[z].commentTypeCode;
        }
      }

      if (this.commentsModel.cmntTypCodeParam) {

        const params = {
          'commentTypeCode': this.commentsModel.cmntTypCodeParam
        };

        this.commentsService.getCommentSuggestions(this.jbhGlobals.endpoints
          .order
          .postCommentType, params).subscribe(
          data => {
            this.commentsModel.commentSuggestions = data;
            if (this.commentsModel.commentSuggestions.length !== 0) {
              const cmntSgstnLen = this.commentsModel.commentSuggestions
                ._embedded
                .commentTemplates.length;
              if (cmntSgstnLen !== 0) {
                this.commentsModel.currntSuggstns = []; // emptying suggestions
                for (let i = 0; i < cmntSgstnLen; i++) {
                  this.commentsModel.currntSuggstns.push(this.commentsModel
                    .commentSuggestions
                    ._embedded
                    .commentTemplates[
                    i].commentText);
                }
              } else {
                this.commentsModel.currntSuggstns = [];
              }
            }

            this.commentsModel.cmmntSgtnsList = [];
            this.commentsModel.cmmntSgtnsList = this.jbhGlobals.utils
              .uniq(
              this.commentsModel.currntSuggstns);

            this.commentsModel.cmmntSgtnsList = this.jbhGlobals.utils
              .sortBy(this.commentsModel.cmmntSgtnsList, function (
                o) {
                return o;
              }, ['asc']);
          });
      }

    } else {
      this.commentsModel.currntSuggstns = [];
    }
    // Setting & getting commentTypes Frm Service Ends.
    if (CurrentCmntValue.text.toLowerCase().toString() === 'order' && this
      .commentsModel
      .tagsArrLength !== 2) {
      this.commentsModel.orderAndStops.push(CurrentCmntValue.text);
      this.commentsTagData = this.commentsModel.orderAndStops;

      if (this.commentsModel.cmntTypes) {
        const commentTypeObj = this.commentsModel.cmntTypes._embedded.commentTypes;
        this.commentsTagData = [];
        if (this.rateSheetBlock) {
          this.commentsTagData.push('Billing Comment');
        } else {
          for (let i = 0; i <= commentTypeObj.length - 1; i++) {
            this.commentsTagData.push(commentTypeObj[i].commentTypeDescription);
          }
        }
        this.commentsTagData = this.commentsTagData;
      } else {
        this.commentsTagData = [];
      }
    } else if (stop.toString() === 'stop') {

      if (this.commentsModel.cmntTypes) {
        const commentTypeObj = this.commentsModel.cmntTypes._embedded.commentTypes;
        this.commentsTagData = [];
        for (let i = 0; i < commentTypeObj.length; i++) {
          this.commentsTagData.push(commentTypeObj[i].commentTypeDescription);
        }
        this.commentsTagData = this.commentsTagData;
      }
    } else if (CurrentCmntValue.text.toLowerCase().toString() === 'order') {
      this.commentsTagData = [];
    }

    if (this.commentsModel.tagsArrLength === 2) {
      this.commentsTagData = [];
    }

  }

  onblurcmttag(currentCmntValue, cmntTagRef) {
    this.commentsModel.compName = cmntTagRef.element.nativeElement.id;
    this.commentsModel.formValue = this.commentSection.get('commentLevel').value;
    if (this.commentsModel.formValue.length < 2) {
      // setTimeout(() => {
      this.commentSection.get(this.commentsModel.compName).markAsTouched();
      if (this.commentsModel.compName === 'commentLevel') {
        console.log(this.commentsModel.compName);
        this.commentSection.get(this.commentsModel.compName).setErrors({ 'required': true });
      }
    // }, 200);
    }
  }

  seperateOrderStops() {

    this.commentsModel.stopArrayObjects = []; // Emptying Arrays
    this.commentsModel.orderArrayObjects = [];
    if (this.commentsModel.loadCmnts && this.commentsModel.loadCmnts.length !==
      0) {
      // Logic to seperate order & stop objects
      for (let i = 0; i < this.commentsModel.loadCmnts.length; i++) {
        if (this.commentsModel.loadCmnts[i].comment.commentLevelTypeCode
          .toLowerCase()
          .toString() === 'stop') {
          this.commentsModel.stopArrayObjects.push(this.commentsModel.loadCmnts[
            i]); // stopObjects
        } else {
          this.commentsModel.orderArrayObjects.push(this.commentsModel.loadCmnts[
            i]); // orderObjects
        }
      }
      this.commentsModel.orderArrayObjects = this.jbhGlobals.utils.orderBy(
        this.commentsModel.orderArrayObjects,
        function (o) {
          return o['comment']['@id'];
        }, ['asc']
      );
      this.commentsModel.stopArrayObjects = this.jbhGlobals.utils.orderBy(
        this.commentsModel.stopArrayObjects,
        function (o) {
          return o['comment']['@id'];
        }, ['asc']
      );
      console.log(this.commentsModel.stopArrayObjects, '<----stop object');
      console.log(this.commentsModel.orderArrayObjects, '<----order object');
    }
  }

  seperateSelectedStop() {
    this.commentsModel.finalIndex = null;
    this.commentsModel.searchObject = null;
    if (this.commentsModel.loadCmnts && this.commentsModel.loadCmnts.length !==
      0) {

      this.commentsModel.selectedStopObjectsArray = [];
      if (this.commentsModel.editActiveIndex !== null && this.commentsModel.editActiveIndex !==
        undefined) {
        this.commentsModel.searchObject = this.commentsModel.loadCmnts[this.commentsModel
          .editActiveIndex];
        this.commentsModel.stopSeqNumber = this.commentsModel.loadCmnts[this.commentsModel
          .editActiveIndex]['stopSequenceNumber'];

        for (let i = 0; i < this.commentsModel.loadCmnts.length; i++) {
          if (this.commentsModel.stopSeqNumber.toString() === this.commentsModel
            .loadCmnts[i].stopSequenceNumber.toString()) {
            this.commentsModel.selectedStopObjectsArray.push(this.commentsModel
              .loadCmnts[i]);
          }
        }
        console.log(this.commentsModel.selectedStopObjectsArray); // final seperated array
        if (this.commentsModel.selectedStopObjectsArray.length !== 0) {
          this.commentsModel.extractedIndex = this.jbhGlobals.utils.orderBy(
            this.commentsModel.stopArrayObjects,
            function (o) {
              return o['comment']['@id'];
            }, ['asc']);
        }
        this.commentsModel.finalIndex = this.jbhGlobals.utils.findIndex(this.commentsModel
          .extractedIndex, this.commentsModel.searchObject); // stopCommentIndex
        console.log(this.commentsModel.finalIndex + '++++++++++++++++++++');
      }
    }
  }

  loadCommentsList() {

    if (this.commentsModel.loadCmnts && this.commentsModel.loadCmnts.length !==
      0) {
      this.commentsModel.tempCmntArr = [];
      const ordStpCmnts = this.commentsModel.loadCmnts;
      this.commentsModel.tempCmntArr = ordStpCmnts;
      this.commentsModel.tmpCmntsListBakUp = this.commentsModel.tempCmntArr;
      this.seperateOrderStops(); // to seperate order & stop objects
    }

    if (this.commentsModel.loadCmnts) { // Filter DropDwnLoad
      for (let i = 0; i < this.commentsModel.loadCmnts.length; i++) {
        if (this.commentsModel.loadCmnts[i].stopSequenceNumber === null) {
          this.commentsFilter.push('Order');
          this.commentsFilter.push(this.commentsModel.loadCmnts[i].commentTypeDescription);
        } else {
          this.commentsFilter.push('Stop' + ' ' + this.commentsModel.loadCmnts[
            i].stopSequenceNumber);
          this.commentsFilter.push(this.commentsModel.loadCmnts[i].commentTypeDescription);
        }
      }
      const UniqueArr = this.jbhGlobals.utils.uniq(this.commentsFilter); // For filtering Duplicates
      this.commentsFilter = UniqueArr;
    }

  }

  reloadCommentsList() {
    this.commentsModel.commentsDto = {
      commentPath: '/comments',
      commentID: this.commentsModel.orderId,
      endpoint: this.jbhGlobals.endpoints.order.getInitialCommentsList
    };

    this.commentsService.loadComments(this.commentsModel.commentsDto).subscribe(
      data => {
        this.commentsModel.loadCmnts = data;
        if (this.commentsModel.loadCmnts) {
          this.commentsModel.tempCmntArr = [];
          const ordStpCmnts = this.commentsModel.loadCmnts;
          this.commentsModel.tempCmntArr = ordStpCmnts;
          this.commentsModel.tmpCmntsListBakUp = this.commentsModel.tempCmntArr;

          if (this.commentsModel.loadCmnts) { // Filter DropDwnLoad
            for (let i = 0; i < this.commentsModel.loadCmnts.length; i++) {
              if (this.commentsModel.loadCmnts[i].stopSequenceNumber ===
                null) {
                this.commentsFilter.push('Order');
                this.commentsFilter.push(this.commentsModel.loadCmnts[
                  i].commentTypeDescription);
              } else {
                this.commentsFilter.push('Stop' + ' ' + this.commentsModel
                  .loadCmnts[
                  i].stopSequenceNumber);
                this.commentsFilter.push(this.commentsModel.loadCmnts[
                  i].commentTypeDescription);
              }
            }
            const UniqueArr = this.jbhGlobals.utils.uniq(this.commentsFilter); // For filtering Duplicates
            this.commentsFilter = UniqueArr;
          }
        }
      });

  }

  cmntFiltrOnSelect(currntVal) {

    this.commentsModel.commentsDto = {
      commentPath: '/comments',
      commentID: this.commentsModel.orderId,
      endpoint: this.jbhGlobals.endpoints.order.getInitialCommentsList
    };
    this.commentsService.loadComments(this.commentsModel.commentsDto).subscribe(
      data => {
        this.commentsModel.loadCmnts = data;
        if (this.commentsModel.loadCmnts && this.commentsModel.loadCmnts
          .length !==
          0) {
          this.commentsModel.tempCmntArr = [];
          this.commentsModel.tempCmntArr = this.commentsModel.loadCmnts;
          this.commentsModel.cmntArrBackUp2 = this.commentsModel.tempCmntArr;
          if (currntVal.toString() === 'All Tags') {
            this.commentsModel.tempCmntArr = this.commentsModel.tempCmntArr;
          } else if (currntVal.toString() !== 'All Tags') {
            this.commentsModel.fltrCrrVal = currntVal;
            this.commentsModel.newFltrArr = this.filterMethod(this.commentsModel
              .cmntArrBackUp2, this.commentsModel
                .fltrCrrVal);
          }
        }
      });

  }

  filterMethod(tempCmntArr, curSelVal) {
    this.commentsModel.filteredArr = [];
    this.commentsModel.stpNumFilter = curSelVal.substring(curSelVal.length -
      1,
      curSelVal.length);
    this.commentsModel.selStpNumFilter = curSelVal.substring(0, 4).toLowerCase();

    if (curSelVal.toLowerCase().toString() === 'order') {
      for (let i = 0; i < tempCmntArr.length; i++) {
        if (tempCmntArr[i].stopSequenceNumber === null) {
          this.commentsModel.filteredArr.push(tempCmntArr[i]);
        }
      }
      this.commentsModel.tempCmntArr = this.commentsModel.filteredArr;
    } else if (curSelVal.toString() === 'All Tags') {
      this.commentsModel.tempCmntArr = this.commentsModel.tmpCmntsListBakUp;
    } else if (curSelVal.toString() !== 'All Tags' && this.commentsModel.selStpNumFilter
      .toString() !==
      'stop' && curSelVal.toLowerCase().toString() !== 'order') {
      for (let i = 0; i < tempCmntArr.length; i++) {
        if (tempCmntArr[i]['commentTypeDescription'].toString() ===
          curSelVal
            .toString()) {
          this.commentsModel.filteredArr.push(tempCmntArr[i]);
        }
      }
      this.commentsModel.tempCmntArr = this.commentsModel.filteredArr;
    } else {
      for (let j = 0; j < tempCmntArr.length; j++) {
        if (tempCmntArr[j]['stopSequenceNumber']) {
          if (this.commentsModel.stpNumFilter.toString() ===
            tempCmntArr[j][
              'stopSequenceNumber'
            ].toString()) {
            this.commentsModel.filteredArr.push(tempCmntArr[j]);
          }
        }

      }
      this.commentsModel.tempCmntArr = this.commentsModel.filteredArr;
    }

  }

  editCommentSection(index, remark, cmntTagRef, cmntTxtArea) {

    this.commentsModel.cmntTagReference = cmntTagRef;
    this.commentsModel.cmntTextArea = cmntTxtArea;
    const TmpFullArr = this.commentsModel.tempCmntArr[index];

    this.commentsModel.editIndex = this.commentsModel.tempCmntArr[index][
      'comment'
    ]['commentID'];

    // CLearing Old Values Before setting Edt Values
    cmntTagRef.active = [];
    cmntTxtArea.active = [];
    this.commentsModel.txtAreaText = ''; // cmntTextArea reference
    this.loadStopTags(); // reload Values in Tag DropDown

    // Hiding Delete Btn on on edit Clk
    this.commentsModel.editActiveIndex = index; // Used in showHide Del Btn
    this.commentsModel.selectedDelBtn = index;
    this.commentsModel.viewOrderEditIndex = index;

    // Getting Old Values
    const oldRemark: any = remark.innerHTML;
    let oldStopNumber: any; // Stop
    if (this.commentsModel.tempCmntArr[index].comment.commentLevelTypeCode
      .toLowerCase()
      .toString() === 'order') {
      oldStopNumber = 'Order';
    } else {
      oldStopNumber = 'Stop ' + this.commentsModel.tempCmntArr[index].stopSequenceNumber;
    }
    const oldCommentTypeCode: any = TmpFullArr['commentTypeDescription']; // commentType

    // Setting Values For Editing
    this.commentsTagData = [];
    cmntTagRef.active.push({
      'id': oldStopNumber,
      'text': oldStopNumber
    });
    cmntTagRef.active.push({
      'id': oldCommentTypeCode,
      'text': oldCommentTypeCode
    });
    this.commentsModel.txtAreaText = oldRemark;

    if (this.commentsModel.cmntTypes) {
      for (let z = 0; z < this.commentsModel.cmntTypes._embedded.commentTypes
        .length; z++) {
        if (this.commentsModel.cmntTypes._embedded.commentTypes[z].commentTypeDescription ===
          oldCommentTypeCode) {
          this.commentsModel.cmntTypCodeVal = this.commentsModel.cmntTypes
            ._embedded
            .commentTypes[z].commentTypeCode;
        }
      }

      if (this.commentsModel.cmntTypCodeVal) {
        const params = {
          'commentTypeCode': this.commentsModel.cmntTypCodeVal
        };

        this.commentsService.getCommentSuggestions(this.jbhGlobals.endpoints
          .order
          .postCommentType, params).subscribe(
          data => {
            this.commentsModel.commentSuggestions = data;
            if (this.commentsModel.commentSuggestions.length !== 0) {
              const cmntSgstnLen = this.commentsModel.commentSuggestions
                ._embedded
                .commentTemplates.length;
              if (cmntSgstnLen !== 0) {
                for (let i = 0; i < cmntSgstnLen; i++) {
                  this.commentsModel.currntSuggstns.push(this.commentsModel
                    .commentSuggestions
                    ._embedded
                    .commentTemplates[
                    i].commentText);
                }
              } else {
                this.commentsModel.currntSuggstns = [];
              }
            }

            this.commentsModel.cmmntSgtnsList = [];
            this.commentsModel.cmmntSgtnsList = this.jbhGlobals.utils
              .uniq(
              this.commentsModel.currntSuggstns);
            this.commentsModel.cmmntSgtnsList = this.jbhGlobals.utils
              .sortBy(this.commentsModel.cmmntSgtnsList, function (
                o) {
                return o;
              }, ['asc']);
          });

      }

    }

    this.commentsModel.editCall = true;
    this.commentsModel.cmntCancelShow = true; // To show cancel Btn on screen

  }

  getCrrntDate() {
    const date = new Date().toString(); // Getting Date
    const time = date.substring(16, 21);
    const mnth = date.substring(4, 7);
    const day = date.substring(8, 10);
    const yr = date.substring(11, 15);
    const crrDateField = time + ' AM ' + mnth + ' ' + day + ' ' + yr;
    return crrDateField;
  }

  tagFieldOnBlur() {

    // if (this.allTagsArray.length === 2) {
    //    this.tagValidator = false;
    // } else if (this.allTagsArray.length !== 2) {
    //    this.tagValidator = true;
    // }
  }

  commentsOnBlur(innerHtmlCmnt) {
    // if (innerHtmlCmnt.length !== 0 && innerHtmlCmnt !== null && innerHtmlCmnt !== '') {
    //    this.commentValidator = false;
    // } else if (innerHtmlCmnt.length === 0 || innerHtmlCmnt === null || innerHtmlCmnt === '') {
    //    this.commentValidator = true;
    // }
  }

  checkDuplicateExists(stopOrdrTag, cmntTypeTag) {

    if (this.commentsModel.loadCmnts && this.commentsModel.loadCmnts.length !==
      0) {

      if (stopOrdrTag.toLowerCase().toString() === 'order') {
        const stpOrdrNum = ['ORDER', 'Order', 'order'];
        for (let k = 0; k < stpOrdrNum.length; k++) {
          const duplicateOrdr = this.jbhGlobals.utils.find(this.commentsModel
            .loadCmnts, {
              'commentTypeDescription': cmntTypeTag,
              'stopSequenceNumber': null,
              'comment': {
                'commentLevelTypeCode': stpOrdrNum[k]
              }
            });
          if (duplicateOrdr) {
            this.commentsModel.duplicateExists.push(duplicateOrdr);
          }
        }
      } else if (stopOrdrTag.toLowerCase().toString() !== 'order') {
        const stpOrdrNum = stopOrdrTag.substring(stopOrdrTag.length - 1,
          stopOrdrTag.length);
        this.commentsModel.duplicateStop = this.jbhGlobals.utils.find(
          this.commentsModel
            .loadCmnts, {
            'referenceNumberTypeDescription': cmntTypeTag,
            'stopSequenceNumber': stpOrdrNum
          });
      }

    }

    if (this.commentsModel.duplicateStop || this.commentsModel.duplicateExists
      .length >
      0) {
      this.commentsModel.cmntRecordExists = true;
      // this.duplicateExists = [];
      // this.duplicateStop = null;
    } else {
      this.commentsModel.cmntRecordExists = false;
      // this.duplicateExists = [];
      // this.duplicateStop = null;
    }

  }
  onDelete(eve) {
    if (eve.flag) {
      event.preventDefault();
      this.commentsModel.cmntCancelShow = false;
      this.commentsModel.cmntTagReference.active = [];
      this.commentsModel.cmntTextArea.active = [];
      // Clearing the form
      this.commentsModel.txtAreaText = ''; // cmntTextArea reference
      this.loadStopTags();

      // SHowing Delete Btn
      this.commentsModel.selectedDelBtn = null;
      eve.model.hide();
    } else {
      document.querySelector('body').removeChild(this.popInstance.deleteButtonModal._element.nativeElement);
      this.commentsModel.cmntCancelShow = true; // To show cancel Btn on screen
      eve.model.hide();
    }
  }

  onCancel() {
    document.querySelector('body').appendChild(this.popInstance.deleteButtonModal._element.nativeElement);
    this.popInstance.deleteButtonModal.show();
  }

  commentSave(commentsForm, cmntTagRef, cmntTxtArea) {

    event.preventDefault();

    this.commentsModel.newComment = this.commentsModel.txtAreaText;

    let newTag1: any;
    let newTag2: any;

    if (cmntTagRef.active[0]) {
      newTag1 = cmntTagRef.active[0].text;
      this.commentsModel.stopOrdrTag = newTag1;
      this.commentsModel.stopNum = newTag1.substring(newTag1.length - 1,
        newTag1.length);
    }
    if (cmntTagRef.active[1]) {
      newTag2 = cmntTagRef.active[1].text;
      this.commentsModel.cmntTypeTag = newTag2;
    }

    this.checkDuplicateExists(this.commentsModel.stopOrdrTag, this.commentsModel
      .cmntTypeTag); // checks duplicate record

    if (newTag1 !== undefined && newTag2 !== undefined && this.commentsModel
      .newComment !==
      undefined) {
      if (this.commentsModel.cmntTypes) {
        for (let i = 0; i < this.commentsModel.cmntTypes._embedded.commentTypes
          .length; i++) {
          if (this.commentsModel.cmntTypes._embedded.commentTypes[i].commentTypeDescription ===
            newTag2) {
            this.commentsModel.newTag2Code = this.commentsModel.cmntTypes
              ._embedded
              .commentTypes[i].commentTypeCode;
          }
        }
      }

      // Order Save create
      if (newTag1.toLowerCase().toString() === 'order' &&
        this.commentsModel.editCall.toString() === false.toString() &&
        this.commentsModel.currentPage !==
        'vieworder') { // For Saving OrderCmnts
        const OrdrParams = {
          'order': '/' + this.commentsModel.orderId,
          'commentID': '',
          'remark': this.commentsModel.newComment,
          'commentTypeCode': this.commentsModel.newTag2Code,
          'location': '',
          '@type': 'OrderComment'
        };

        if (this.commentsModel.orderId && this.commentsModel.newComment &&
          this
            .commentsModel.newTag2Code) {
          this.commentsService.SaveComments(this.jbhGlobals.endpoints.order
            .postOrderComments,
            OrdrParams).subscribe(data => {
              this.commentsModel.orderObjResponce = data;
              if (this.commentsModel.orderObjResponce) {
                // Comments List Initial
                this.reloadCommentsList();
              }

            });
          // this.reloadStopTags(cmntTagRef);
          this.loadStopTags();
        } else {
          console.log('All Fields are mandatory');
        }

        // Stop save create
      } else if (this.commentsModel.currentPage !== 'vieworder' && newTag1.substring(
        0,
        4).toLowerCase()
        .toString() === 'stop' &&
        this.commentsModel.editCall.toString() === false.toString()) {

        if (this.commentsModel.stopNum) {
          for (let i = 0; i < this.commentsModel.stopAndIds.length; i++) {
            const stpNbr = this.commentsModel.stopAndIds[i].stop.stopSequenceNumber;
            if (this.commentsModel.stopNum.toString() === stpNbr.toString()) {
              this.commentsModel.stopIdEdt = this.commentsModel.stopAndIds[
                i]
                .stop
                .stopID;
            }

          }
        }

        if (this.commentsModel.stopIdEdt) {
          const StopParams = {
            'remark': this.commentsModel.newComment,
            'commentTypeCode': this.commentsModel.newTag2Code,
            'location': null,
            'stop': '/' + this.commentsModel.stopIdEdt, // stop ID
            'order': '/' + this.commentsModel.orderId,
            '@type': 'StopComment'
          };

          this.commentsService.SaveComments(this.jbhGlobals.endpoints.order
            .postStopComments,
            StopParams).subscribe(data => {
              this.commentsModel.stopObjResponce = data;
              if (this.commentsModel.stopObjResponce) {
                this.reloadCommentsList();
              }
            });
        }
        this.reloadStopTags(cmntTagRef);
      } else if (this.commentsModel.currentPage === 'vieworder' && newTag1.toLowerCase()
        .toString() ===
        'order' &&
        this.commentsModel.editCall.toString() === false.toString()) { // Order save in Vieworder

        const OrdrParams = {
          'commentID': '',
          'remark': this.commentsModel.newComment,
          'commentTypeCode': this.commentsModel.newTag2Code,
          'location': '',
          '@type': 'OrderComment'
        };

        if (this.commentsModel.orderId && this.commentsModel.newComment &&
          this.commentsModel.newTag2Code) {
          this.seperateOrderStops(); // refreshing seperated arrays
          const orderNewCommentindex = this.commentsModel.orderArrayObjects.length;
          const orderParam = {
            'order': [{
              'op': 'add',
              'path': '/orderComments/' +
              orderNewCommentindex,
              'value': OrdrParams
            }]
          };

          const url = this.jbhGlobals.endpoints.viewOrder.orderUpdate + this.commentsModel.orderId + '/warningoverriden/' + false;
          this.viewOrderService.updateOrder(url, orderParam).subscribe(
            data => {
              this.viewOrderService.errorHandling(data);
              this.viewOrderService.loadOrder(this.commentsModel.orderId);
              this.reloadStopTags(cmntTagRef);
              this.reloadCommentsList();
            });
          this.commentsModel.selectedCmntDivv = null; // enabling delete Btn
        } else {
          console.log('All Fields are mandatory');
        }

      } else if (this.commentsModel.currentPage === 'vieworder' && newTag1.substring(
        0,
        4).toLowerCase()
        .toString() === 'stop' &&
        this.commentsModel.editCall.toString() === false.toString()) { // Stop save in ViewOrder

        if (this.commentsModel.stopNum) {
          for (let i = 0; i < this.commentsModel.stopAndIds.length; i++) {
            const stpNbr = this.commentsModel.stopAndIds[i].stop.stopSequenceNumber;
            if (this.commentsModel.stopNum.toString() === stpNbr.toString()) {
              this.commentsModel.stopIdEdt = this.commentsModel.stopAndIds[
                i]
                .stop.stopID;
            }

          }
        }

        if (this.commentsModel.stopIdEdt) {
          this.seperateOrderStops(); // refreshing seperated arrays
          // this.seperateSelectedStop(); // Getting StopCommentIndex arrays
          const StopParams = {
            'remark': this.commentsModel.newComment,
            'commentTypeCode': this.commentsModel.newTag2Code,
            'location': null,
            '@type': 'StopComment'
          };
          // 'stop': '/' + this.commentsModel.stopIdEdt, // stop ID
          // 'order': '/' + this.commentsModel.orderId,
          const stopNewCommentindex = this.commentsModel.selectedStopObjectsArray
            .length;
          const stopNum = Number(this.commentsModel.stopNum) - 1;
          // const stopNum = this.commentsModel.searchObject.stopSequenceNumber - 1;
          const stopPatchParam = {
            'order': [{
              'op': 'add',
              'path': '/stops/' + stopNum + '/stopComments/' +
              stopNewCommentindex,
              'value': StopParams
            }]
          };

          const url = this.jbhGlobals.endpoints.viewOrder.orderUpdate + this.commentsModel.orderId + '/warningoverriden/' + false;
          this.viewOrderService.updateOrder(url, stopPatchParam).subscribe(
            data => {
              this.viewOrderService.loadOrder(this.commentsModel.orderId);
              this.reloadStopTags(cmntTagRef);
              this.reloadCommentsList();
              this.viewOrderService.errorHandling(data);
            });
          this.commentsModel.selectedCmntDivv = null; // enabling delete Btn
        }
      }

      // Edit Order Update
      if (this.commentsModel.currentPage !== 'vieworder' && newTag1.toLowerCase()
        .toString() ===
        'order' && this.commentsModel.editCall
          .toString() === true.toString()) {

        const OrdrParams = {
          'order': '/' + this.commentsModel.orderId,
          'remark': this.commentsModel.newComment,
          'commentTypeCode': this.commentsModel.newTag2Code,
          'location': '',
          '@type': 'OrderComment'
        };
        // commentID is this.editIndex
        this.commentsService.updateComments(this.jbhGlobals.endpoints.order
          .updateOrderComments +
          '/' + this.commentsModel.editIndex, OrdrParams).subscribe(
          data => {
            this.commentsModel.orderObjResponce = data;
            if (this.commentsModel.orderObjResponce) {
              this.reloadCommentsList();
              // Showing Delete Btn
              this.commentsModel.selectedDelBtn = null;
            }
          });
        this.reloadStopTags(cmntTagRef);
      } else if (this.commentsModel.currentPage !== 'vieworder' && newTag1.substring(
        0,
        4).toLowerCase()
        .toString() === 'stop' &&
        this.commentsModel.editCall.toString() ===
        true.toString()) {
        // Stop Edit Update Logic
        if (this.commentsModel.stopNum) {
          for (let i = 0; i < this.commentsModel.stopAndIds.length; i++) {
            const stpNbr = this.commentsModel.stopAndIds[i].stop.stopSequenceNumber;
            if (this.commentsModel.stopNum === stpNbr) {
              this.commentsModel.stopIdEdt = this.commentsModel.stopAndIds[
                i]
                .stop
                .stopID;
            }

          }
        }

        const StopParams = {
          'remark': this.commentsModel.newComment,
          'commentTypeCode': this.commentsModel.newTag2Code,
          'location': null,
          'stop': '/' + this.commentsModel.stopIdEdt,
          'order': '/' + this.commentsModel.orderId,
          '@type': 'StopComment'
        };
        this.commentsService.updateComments(this.jbhGlobals.endpoints.order
          .updateStopComments +
          '/' + this.commentsModel.editIndex, StopParams).subscribe(
          data => {
            this.commentsModel.stopObjResponce = data;
            if (this.commentsModel.stopObjResponce) {
              this.reloadCommentsList();
              // Showing Delete Btn
              this.commentsModel.selectedDelBtn = null;
            }
            this.commentsModel.editCall = false;
            this.commentsModel.filterLoaded = false;

          });
        this.reloadStopTags(cmntTagRef);
      } else if (this.commentsModel.currentPage === 'vieworder' && newTag1.toLowerCase()
        .toString() ===
        'order' && this.commentsModel.editCall
          .toString() === true.toString()) { // Order EditUpdate in viewOrder
        //  'order': '',
        this.seperateOrderStops(); // refreshing seperated arrays
        const OrdrParams = {
          'remark': this.commentsModel.newComment,
          'commentTypeCode': this.commentsModel.newTag2Code,
          'location': '',
          '@type': 'OrderComment'
        };

        const editedCommentObject = this.commentsModel.tempCmntArr[this.commentsModel
          .viewOrderEditIndex];
        const patchIndex = this.jbhGlobals.utils.findIndex(this.commentsModel
          .orderArrayObjects,
          editedCommentObject);
        const orderEditPatchIndex = patchIndex; // OrderEdit PatchIndex
        const orderPatchParam = {
          'order': [{
            'op': 'replace',
            'path': '/orderComments/' + orderEditPatchIndex,
            'value': OrdrParams
          }]
        };

        const url = this.jbhGlobals.endpoints.viewOrder.orderUpdate + this.commentsModel.orderId + '/warningoverriden/' + false;
        this.viewOrderService.updateOrder(url, orderPatchParam).subscribe(
          data => {
            this.viewOrderService.loadOrder(this.commentsModel.orderId);
            this.reloadStopTags(cmntTagRef);
            this.reloadCommentsList();
            this.viewOrderService.errorHandling(data);
          });
        // Showing Delete Btn
        this.commentsModel.selectedDelBtn = null;

      } else if (this.commentsModel.currentPage === 'vieworder' && newTag1.substring(
        0,
        4).toLowerCase()
        .toString() === 'stop' &&
        this.commentsModel.editCall.toString() === true.toString()) { // viewOrder stop EditUpdate
        // vieworder Stop Edit Update Logic
        if (this.commentsModel.stopNum) {
          for (let i = 0; i < this.commentsModel.stopAndIds.length; i++) {
            const stpNbr = this.commentsModel.stopAndIds[i].stop.stopSequenceNumber;
            if (this.commentsModel.stopNum === stpNbr) {
              this.commentsModel.stopIdEdt = this.commentsModel.stopAndIds[
                i]
                .stop.stopID;
            }
          }
        }

        const StopParams = {
          'remark': this.commentsModel.newComment,
          'commentTypeCode': this.commentsModel.newTag2Code,
          'location': null,
          '@type': 'StopComment'
        };
        // 'stop': '/' + this.commentsModel.stopIdEdt,
        // 'order': '/' + this.commentsModel.orderId,
        this.seperateOrderStops(); // refreshing seperated arrays
        this.seperateSelectedStop(); // Getting StopCommentIndex arrays
        const editedCommentObject = this.commentsModel.tempCmntArr[this.commentsModel
          .viewOrderEditIndex];
        const patchIndex = this.jbhGlobals.utils.findIndex(this.commentsModel
          .stopArrayObjects,
          editedCommentObject);

        // const stopEditPatchIndex = patchIndex; // stopEdit PatchIndex

        const stopNum = Number(this.commentsModel.searchObject.stopSequenceNumber) -
          1;

        const stopPatchParam = {
          'order': [{
            'op': 'replace',
            'path': '/stops/' + stopNum + '/stopComments/' + this.commentsModel
              .finalIndex,
            'value': StopParams
          }]
        };

        const url = this.jbhGlobals.endpoints.viewOrder.orderUpdate + this.commentsModel.orderId + '/warningoverriden/' + false;
        this.viewOrderService.updateOrder(url, stopPatchParam).subscribe(
          data => {
            this.viewOrderService.loadOrder(this.commentsModel.orderId);
            this.reloadStopTags(cmntTagRef);
            this.reloadCommentsList();
            this.viewOrderService.errorHandling(data);
          });
        this.commentsModel.selectedDelBtn = null; // Showing Delete Btn
      }

      commentsForm.reset(); // Resetting commentsForm
      cmntTagRef.active = []; // Clearing tagField
      cmntTxtArea.active = []; // Clearing template type tagField
      this.commentsTagData = []; // clearing tagField
      this.commentsTagData = this.commentsTagDataDuplicate; // Resetting TagField
      this.loadStopTags(); // reloading stoptags
      this.commentsModel.tmpCmntsListBakUp = this.commentsModel.tempCmntArr; // Resetting TagFieldD
      this.commentsModel.cmntFilterLoaded = false; // for loading filterDropDwn
      this.commentsModel.cmntCancelShow = false; // cancel button hide

    } else {
      this.jbhGlobals.notifications.error('Error', 'Please fill all the fields');
    }
  }

  editEnableVerify(stopCmnts) {
    this.commentsModel.selectedCmntDiv = stopCmnts.comment.
      createProgramName === 'Electronic' ? null : stopCmnts;
  }

  delCommentSection(delIndex) {
    this.commentsModel.selectedCmntDivv = delIndex;
    this.commentsModel.viewOrderDelIndex = delIndex;
    console.log(this.commentsModel.viewOrderDelIndex);
  }

  undoDelCommentSection(i) {
    this.commentsModel.selectedCmntDivv = null;
  }

  cmntPmntDel(indx) {

    const TmpFullArr = this.commentsModel.tempCmntArr[indx];

    if (this.commentsModel.currentPage !== 'vieworder' && TmpFullArr[
      'comment'][
      'commentLevelTypeCode'
    ].toLowerCase().toString() ===
      'order') { // Order comment delete
      const delCmntId = this.commentsModel.tempCmntArr[indx]['comment'][
        'commentID'
      ];
      this.commentsService.deleteComments(this.jbhGlobals.endpoints.order
        .delOrderComments +
        '/' +
        delCmntId).subscribe(data => {
          this.reloadCommentsList();
          if (this.commentsModel.tempCmntArr.length === 1) {
            this.commentsModel.tempCmntArr = [];
          }
        });
      this.commentsModel.selectedCmntDivv = null; // setting delete overlay normal
    } else if (this.commentsModel.currentPage !== 'vieworder' && TmpFullArr[
      'comment'][
      'commentLevelTypeCode'
    ].substring(0, 4).toLowerCase()
      .toString() === 'stop') { // stop comment delete
      const delCmntId = this.commentsModel.tempCmntArr[indx]['comment'][
        'commentID'
      ];
      this.commentsService.deleteComments(this.jbhGlobals.endpoints.order
        .delStopComments +
        '/' + delCmntId).subscribe(data => {
          this.reloadCommentsList();
          if (this.commentsModel.tempCmntArr.length === 1) {
            this.commentsModel.tempCmntArr = [];
          }
        });
      this.commentsModel.selectedCmntDivv = null; // setting delete overlay normal
    } else if (this.commentsModel.currentPage === 'vieworder' && TmpFullArr[
      'comment'][
      'commentLevelTypeCode'
    ].toLowerCase().toString() ===
      'order') { // order Delete in ViewOrder
      this.seperateOrderStops(); // refreshing seperated arrays
      const editedCommentObject = this.commentsModel.tempCmntArr[this.commentsModel
        .viewOrderDelIndex];
      const patchIndex = this.jbhGlobals.utils.findIndex(this.commentsModel.orderArrayObjects,
        editedCommentObject);
      const orderCmntdeleteIndex = patchIndex;
      const orderParam = {
        'order': [{
          'op': 'remove',
          'path': '/orderComments/' + orderCmntdeleteIndex
        }]
      };

      const url = this.jbhGlobals.endpoints.viewOrder.orderUpdate + this.commentsModel.orderId + '/warningoverriden/' + false;
      this.viewOrderService.updateOrder(url, orderParam).subscribe(data => {
        this.viewOrderService.loadOrder(this.commentsModel.orderId);
        this.reloadStopTags(this.tagFieldReference);
        this.reloadCommentsList();
        this.viewOrderService.errorHandling(data);
      });

      this.commentsModel.selectedCmntDivv = null; // setting delete overlay normal
    } else if (this.commentsModel.currentPage === 'vieworder' && TmpFullArr[
      'comment'][
      'commentLevelTypeCode'
    ].substring(0, 4).toLowerCase()
      .toString() === 'stop') { // stop comment delete in vieworder

      this.seperateOrderStops(); // refreshing seperated arrays
      const editedCommentObject = this.commentsModel.tempCmntArr[this.commentsModel
        .viewOrderDelIndex];
      const patchIndex = this.jbhGlobals.utils.findIndex(this.commentsModel.stopArrayObjects,
        editedCommentObject);
      const stopCmntdeleteIndex = patchIndex;
      const stopNumberDelete = Number(this.commentsModel.searchObject.stopSequenceNumber) -
        1;
      const orderParam = {
        'order': [{
          'op': 'remove',
          'path': '/stops/' + stopNumberDelete + '/stopComments/' +
          this.commentsModel.finalIndex
        }]
      };

      const url = this.jbhGlobals.endpoints.viewOrder.orderUpdate + this.commentsModel.orderId + '/warningoverriden/' + false;
      this.viewOrderService.updateOrder(url, orderParam).subscribe(data => {
        this.viewOrderService.loadOrder(this.commentsModel.orderId);
        this.reloadStopTags(this.tagFieldReference);
        this.reloadCommentsList();
        this.viewOrderService.errorHandling(data);
      });
      this.commentsModel.selectedCmntDivv = null; // setting delete overlay normal
    }

  }
  // noBtnClick() {
  //   this.commentsModel.cmntCancelShow = true; // To show cancel Btn on screen
  // }

}
