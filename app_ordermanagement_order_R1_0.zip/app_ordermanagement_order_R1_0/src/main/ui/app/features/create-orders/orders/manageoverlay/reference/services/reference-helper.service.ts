import { Injectable, OnInit } from '@angular/core';
import { JBHGlobals } from '../../../../../../app.service';
import { ReferencesService } from './references.service';
@Injectable()
export class ReferenceHelperService {
  jsonpatch: any;
  constructor(private jbhGlobals: JBHGlobals) { }

  clearReferenceFields(referencesModel) {
    referencesModel.orderRefUpdate = false;
    referencesModel.oRefOval = null; // emptying reference Value InputField
    referencesModel.oRefId = null; // emptying value after save
  }

  checkDuplicateOrderExists(referencesModel, refValTxt, refNumTypeCode) {
    referencesModel.orderRefLst = referencesModel.referencesList
      .Order;
    referencesModel.orderReferenceDuplicateCheck = this.jbhGlobals
      .utils.find(referencesModel.orderRefLst, {
        'referenceNumber': {
          'referenceNumberValue': refValTxt,
          'referenceNumberTypeCode': refNumTypeCode
        }
      });
  }

  getOrderParamForSave(referencesModel, refNumTypeCode, refValTxt) {
    const ordrParams = {
      'order': '/' + referencesModel.currentOrderId,
      'referenceNumberID': '',
      'referenceNumberTypeCode': refNumTypeCode,
      'referenceNumberValue': refValTxt,
      '@type': 'OrderReferenceNumber'
    };
    return ordrParams;
  }

  checkDuplicateOrderVieworder(referencesModel, refValTxt, refNumTypeCode) {
    referencesModel.orderRefLst = referencesModel.referencesList.Order;
    referencesModel.orderReferenceDuplicateCheck = this.jbhGlobals
      .utils.find(referencesModel.orderRefLst, {
        'referenceNumber': {
          'referenceNumberValue': refValTxt,
          'referenceNumberTypeCode': refNumTypeCode
        }
      });
  }

  getOrderParamValueForVieworder(referencesModel, refValTxt, refNumTypeCode) {
    const orderParam = {
      'order': [{
        'op': 'add',
        'path': '/orderReferenceNumbers/0',
        'value': {
          'referenceNumberID': '',
          'referenceNumberTypeCode': refNumTypeCode,
          'referenceNumberValue': refValTxt,
          '@type': 'OrderReferenceNumber'
        }
      }]
    };
    return orderParam;
  }

  getEditParamsForVieworder(referencesModel, refNumTypeCode) {
    const orderParam = {
      'order': [{
        'op': 'replace',
        'path': '/orderReferenceNumbers/' + referencesModel.orderPatchIndex,
        'value': {
          'referenceNumberID': referencesModel.oRefId,
          'referenceNumberTypeCode': refNumTypeCode,
          'referenceNumberValue': referencesModel.oRefOval,
          '@type': 'OrderReferenceNumber'
        }
      }]
    };
    return orderParam;
  }

  clearUsedVariables(referencesModel) {
    referencesModel.orderRefUpdate = false;
    referencesModel.oRefOval = null; // emptying reference Value InputField
    referencesModel.oRefId = null; // emptying value after save
    referencesModel.oUpdateIndex = null;
  }

  getstopEditIdNReferenceId(referencesModel) {
    referencesModel.editIdObjt = this.jbhGlobals.utils.find(
      referencesModel.orderRefLstz, {
        'referenceNumberTypeDescription': referencesModel.oldStopDesc
      });
    referencesModel.stopEdtRefNumId = referencesModel.editIdObjt
      .referenceNumber.referenceNumberID; // referenceNumberID
    const valLen = {
      'page': 0,
      'size': 500
    };
    return valLen;
  }

  geteditOrderParamsForstopUpdate(referencesModel) {
    const editStopParams = {
      'referenceNumberID': referencesModel.stopEdtRefNumId,
      'referenceNumberTypeCode': referencesModel.sRefCode,
      'referenceNumberValue': referencesModel.sRefNumVal,
      '@type': 'StopReferenceNumber'
    };
    return editStopParams;
  }

  showResponseMessge(referencesModel) {
    this.jbhGlobals.notifications.alert('Warning', referencesModel.newStopRef); // responce message
    referencesModel.stopEdit = false;
    referencesModel.stopEdtRefNumId = null;
    referencesModel.sRefCode = null;
    referencesModel.sRefNumVal = null;
    referencesModel.stpAssociatRefNumbid = null;
    referencesModel.oRefOval = null; // resetting refType
  }

  extractStopUpdateIndex(parentScope, referencesModel, finaliseCall) {
    referencesModel.stopEditPatchIndex = null;
    const srefNumberTypCode = referencesModel.srefNumberTypCode ? referencesModel
      .srefNumberTypCode : referencesModel.stopReferenceCode;
    const sRefNumbrValue = referencesModel.sRefNumbrValue ? referencesModel.sRefNumbrValue : referencesModel.stopReferencevalue;
    parentScope.referencesService.getAllReference(this.jbhGlobals.endpoints.order.getReferenceIndex +
      referencesModel.selectedStopId).subscribe(data5 => {
        const currentStopReferencesArray = data5;
        if (currentStopReferencesArray['stopReferenceNumbers']) {
          const fullReferenceArray = currentStopReferencesArray['stopReferenceNumbers'];
          referencesModel.stopEditPatchIndex = this.jbhGlobals.utils.findIndex(fullReferenceArray, {
            'referenceNumberTypeCode': srefNumberTypCode,
            'referenceNumberValue': sRefNumbrValue
          });
          if (referencesModel.stopEditPatchIndex && finaliseCall === 'delete') {
            parentScope.stopDeleteInVieworder(); // Delete Stop in ViewOrder
          }
        };
      });
  }

  stopEditReferenceUpdateCall(parentScope, referencesModel, editStopParms, refForm) {
    // Stop reference Update
    if (referencesModel.currentPage !== 'vieworder') { // Stop Edit In Moc
      parentScope.referencesService.SaveReference(
        this.jbhGlobals.endpoints.order.updateStopRef + referencesModel
          .stpIDStopUpdate + '/stopreferencenumbers/', editStopParms).subscribe(data5 => {
            referencesModel.newStopRef = data5;
            if (referencesModel.newStopRef) {
              this.jbhGlobals.notifications.alert('Warning', referencesModel.newStopRef); // responce message
              parentScope.reloadStopReferenceList(); // To Reload List
              // Resetting used values to null
              referencesModel.stopEdit = false; // Resetting edit to False
              referencesModel.stopEdtRefNumId = null;
              referencesModel.sRefCode = null;
              referencesModel.sRefNumVal = null;
              refForm.value.ParRefType = null;
              parentScope.pRefTypeValReference.active = [];
              referencesModel.oRefOval = null; // resetting refType
              referencesModel.stopEleRef.refType.nativeElement.value = 'select';
              referencesModel.stopEleRef.stopLevel.nativeElement.value = 'select';
            }
          });
    }
    if (referencesModel.currentPage !== 'vieworder') { // Stop Edit In VIEWORDER
      const finaliseCall = 'edit';
      parentScope.extractStopUpdateIndex(finaliseCall); // To get order Edited Index
      const stopPatchLevel = Number(referencesModel.edtSelNum) - 1;
      const stopParamsForPatch = {
        'order': [{
          'op': 'replace',
          'path': '/stops/' + stopPatchLevel + '/stopReferenceNumbers/' + referencesModel.stopEditPatchIndex +
          '/referenceNumberValue',
          'value': editStopParms
        }]
      };
      const url = this.jbhGlobals.endpoints.viewOrder.orderUpdate + referencesModel.currentOrderId + '/warningoverriden/' + false;
      parentScope.viewOrderService.updateOrder(url, stopParamsForPatch).subscribe(data => {
        this.jbhGlobals.notifications.alert('Warning', referencesModel.newStopRef); // responce message
        parentScope.reloadStopReferenceList(); // To Reload List
        // Resetting used values to null
        referencesModel.stopEdit = false; // Resetting edit to False
        referencesModel.stopEdtRefNumId = null;
        referencesModel.sRefCode = null;
        referencesModel.sRefNumVal = null;
        refForm.value.ParRefType = null;
        parentScope.pRefTypeValReference.active = [];
        referencesModel.oRefOval = null; // resetting refType
        // Below Variables used in stopIndex Srch Logic
        referencesModel.srefNumberTypCode = null;
        referencesModel.stopReferenceCode = null;
        referencesModel.sRefNumbrValue = null;
        referencesModel.stopReferencevalue = null;
      });
    }
  }

  stopSaveForMoc(parentScope, referencesModel) {
    parentScope.referencesService.saveStopReferences(this.jbhGlobals.endpoints.order.postStopRef +
      referencesModel.stpIDSave + '/stopreferencenumbers', referencesModel.stpOrdrParams
    ).subscribe(data => {
      referencesModel.getreferencesTypez = data;
      if (referencesModel.getreferencesTypez) {
        this.jbhGlobals.notifications.alert('Warning', referencesModel.getreferencesTypez); // responce message
        parentScope.reloadStopReferenceList(); // To rePopulate StopRef List
        referencesModel.oRefOval = null; // clearing RefValue field
        // resetting Parent type & Val datas on delete
        if (parentScope.stopLevelNumber.nativeElement.value) {
          parentScope.stopLevelOnSel(parentScope.stopLevelNumber.nativeElement.value, parentScope.stopLevelNumber.nativeElement.value);
        }
        parentScope.refNumTypeCode = null; // Emptying After Save
        parentScope.refValTxt = null; // Emptying After Save
        //parentScope.eleRef.nativeElement.value = 'select';
        referencesModel.stopEleRef.refType.nativeElement.value = 'select';
        referencesModel.stopEleRef.stopLevel.nativeElement.value = 'select';
      }
    });
  }

  stopSaveForVieworder(parentScope, referencesModel, refNumTypeCode, refValTxt) {
    parentScope.viewOrderService.loadOrder(referencesModel.currentOrderId);
    const stpOrdrPatchParams = { // StopSave function else with No Parent Vals
      'referenceNumberTypeCode': refNumTypeCode,
      'referenceNumberValue': refValTxt,
      'referenceNumberLevelTypeCode': 'STOP',
      '@type': 'StopReferenceNumber',
      'associatedReferenceNumber': []
    };
    const stoplevelPatch = Number(referencesModel.stopLvel) - 1;
    const orderParam = {
      'order': [{
        'op': 'add',
        'path': '/stops/' + stoplevelPatch +
        '/stopReferenceNumbers/0',
        'value': stpOrdrPatchParams
      }]
    };
    const url = this.jbhGlobals.endpoints.viewOrder.orderUpdate + referencesModel.currentOrderId + '/warningoverriden/' + false;
    parentScope.viewOrderService.updateOrder(url, orderParam).subscribe(data => {
      this.jbhGlobals.notifications.alert('Warning', referencesModel.getreferencesTypez); // responce message
      parentScope.reloadStopReferenceList(); // To rePopulate StopRef List
      referencesModel.oRefOval = null; // clearing RefValue field
      // resetting Parent type & Val datas on delete
      if (parentScope.stopLevelNumber.nativeElement.value) {
        parentScope.stopLevelOnSel(parentScope.stopLevelNumber.nativeElement
          .value, parentScope.stopLevelNumber.nativeElement.value);
      }
      refNumTypeCode = null; // Emptying After Save
      refValTxt = null; // Emptying After Save
    });
  }

  StopReferenceValueAndParentValuesReady(parentScope, referencesModel, refNumTypeCode, refValTxt) {
    referencesModel.stpOrdrParams = {
      'referenceNumberTypeCode': refNumTypeCode,
      'referenceNumberValue': refValTxt,
      '@type': 'StopReferenceNumber',
      'associatedReferenceNumber': [{
        'referenceNumber': {
          'referenceNumberTypeCode': referencesModel.stpRefNumTypCdeForSave,
          'referenceNumberValue': referencesModel.prefValTxt,
          '@type': 'StopReferenceNumber'
        }
      }]
    };
    for (let j = 0; j < referencesModel.stopNIds.length; j++) {
      if (referencesModel.stopNIds[j].stop.stopSequenceNumber.toString() ===
        referencesModel.stopLevelNum.toString()) {
        referencesModel.stpIDSave = referencesModel.stopNIds[j].stop.stopID;
      }
    }
    if (referencesModel.currentPage !== 'vieworder') {
      parentScope.referencesService.saveStopReferences(this.jbhGlobals.endpoints.order
        .postStopRef + referencesModel.stpIDSave +
        '/stopreferencenumbers', referencesModel.stpOrdrParams).subscribe(data => {
          referencesModel.getreferencesTyp = data;
          if (referencesModel.getreferencesTyp) {
            this.jbhGlobals.notifications.alert('Warning',
              referencesModel.getreferencesTyp); // responce message
            parentScope.reloadStopReferenceList(); // To rePopulate StopRef List
            referencesModel.oRefOval = null; // Clearing referenceValue
            parentScope.pRefTypeValReference.active = []; // Clearing ParreferenceValue
            referencesModel.pRefTypeFlag = false; // parRefType enabling
            referencesModel.pRefValueFlag = false; // parRefVal enabling
            // resetting Parent type & Val datas on delete
            if (parentScope.stopLevelNumber) {
              parentScope.stopLevelOnSel(parentScope.stopLevelNumber.nativeElement.value,
                parentScope.stopLevelNumber.nativeElement.value);
            }
            referencesModel.stpRefNumTypCdeForSave = null; // Emptying after Save
            referencesModel.prefValTxt = null; // Emptying after Save
            refNumTypeCode = null; // Emptying after Save
            refValTxt = null; // Emptying after Save
          }
        });
    } else if (referencesModel.currentPage === 'vieworder') { // Stop Save VIEWORDER with parent Values
      const stoplevelPatch = Number(referencesModel.stopLvel) - 1;
      const stopPatchObj = {
        'order': [{
          'op': 'add',
          'path': '/stops/' + stoplevelPatch + '/stopReferenceNumbers/0',
          'value': referencesModel.stpOrdrParams
        }]
      };
      const url = this.jbhGlobals.endpoints.viewOrder.orderUpdate + referencesModel.currentOrderId + '/warningoverriden/' + false;
      parentScope.viewOrderService.updateOrder(url, stopPatchObj).subscribe(data => {
        this.jbhGlobals.notifications.alert('Warning', referencesModel.getreferencesTypez); // responce message
        parentScope.reloadStopReferenceList(); // To rePopulate StopRef List
        referencesModel.oRefOval = null; // clearing RefValue field
        // resetting Parent type & Val datas on delete
        if (parentScope.stopLevelNumber.nativeElement.value) {
          parentScope.stopLevelOnSel(parentScope.stopLevelNumber.nativeElement.value,
            parentScope.stopLevelNumber.nativeElement.value);
        }
        parentScope.refNumTypeCode = null; // Emptying After Save
        parentScope.refValTxt = null; // Emptying After Save
      });
    }
  }

  triggerOnDelete(parentScope, referencesModel, eve) {
    referencesModel.editRefShow = false;
    referencesModel.oRefOval = null; // Clearing referenceValue
    if (parentScope.pRefTypeValReference) {
      parentScope.pRefTypeValReference.active = []; // Clearing ParreferenceValue
    }
    parentScope.referenceForm.reset(); // Resetting the whole form
    parentScope.referenceTypeDirectReference.nativeElement.value = 'select';
    parentScope.stopLevelNumber.nativeElement.value = 'select';
    parentScope.associatedParentReferenceType.nativeElement.value = 'select';
    referencesModel.enableDelete = null; // enable delete Button
    referencesModel.refValValidate = false; // Resetting Validation
    referencesModel.editRefShow = null; // hiding cancel Btn
    eve.model.hide();
  }

  permanentDeleteReference(parentScope, referencesModel, index) {
    const delObjId = referencesModel.orderRefLst[index].referenceNumber.referenceNumberID;
    if (referencesModel.currentPage !== 'vieworder') {
      this.jbhGlobals.apiService.removeData(this.jbhGlobals.endpoints.order.deleteOrderRef + delObjId).subscribe(data => {
        parentScope.reloadOrderGetreferencesList();
        referencesModel.showDeleteOverlay = null; // Showing deleteOverlay
        referencesModel.descriptionWrapper = null; // hiding Desc section
      });
    }
    if (referencesModel.currentPage === 'vieworder') {
      parentScope.findOrderIndex(); // To get order Edited Index
      const orderParam = {
        'order': [{
          'op': 'remove',
          'path': '/orderReferenceNumbers/' + referencesModel.orderPatchIndex
        }]
      };
      const url = this.jbhGlobals.endpoints.viewOrder.orderUpdate + referencesModel.currentOrderId + '/warningoverriden/' + false;
      parentScope.viewOrderService.updateOrder(url, orderParam).subscribe(data => {
        parentScope.reloadOrderGetreferencesList();
        referencesModel.showDeleteOverlay = null; // Showing deleteOverlay
        referencesModel.descriptionWrapper = null; // hiding Desc section
        referencesModel.deletePatchIndex = null;
      });
    }
  }

  reloadStopreferencesList(parentScope, referencesModel) {
    parentScope.referencesService.loadReferences(this.jbhGlobals.endpoints.order.getreferencesList +
      referencesModel.currentOrderId + '/referencenumbers').subscribe(data => {
        referencesModel.referencesList = data;
        parentScope.orderService.setReference(parentScope.referencesModel.referencesList);
        if (referencesModel.referencesList && referencesModel.referencesList.length !== 0) {
          parentScope.getReferenceList();
          parentScope.referenceUtility.setParentReferenceFlags(referencesModel);
        }
      });
  }

}
