import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SelectModule } from '../../../../shared/select';
import { ModalModule } from 'ngx-bootstrap';
import { TextMaskModule } from 'angular2-text-mask';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { SharedModule } from '../../../../shared/shared.module';
import { AddcontactsComponent } from './addcontacts.component';

@NgModule({
  imports: [
    CommonModule,
    SelectModule,
    ModalModule.forRoot(),
    FormsModule,
    TextMaskModule,
    SharedModule,
    ReactiveFormsModule
  ],
  declarations: [AddcontactsComponent],
  exports: [AddcontactsComponent]
})
export class AddcontactsModule { }
