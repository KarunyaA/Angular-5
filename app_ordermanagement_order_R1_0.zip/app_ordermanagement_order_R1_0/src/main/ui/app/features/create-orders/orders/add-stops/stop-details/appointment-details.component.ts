import { Component, EventEmitter, Input, OnDestroy, OnInit, Output, ViewChild } from '@angular/core';
import * as moment from 'moment';

import { AppointmentDetailsModel } from './models/appointment-details-model'

import { JBHGlobals } from '../../../../../app.service';
import { DatePipe } from '@angular/common';
import { AddStopsOrderService } from './../services/add-stops-order.service';
import { OrderFormBuilderService } from '../../services/order-form-builder.service';
import { StopSharedDataService } from './../services/stop-shared-data.service';
import { AppointmentDetailsService } from './services/appointment-details.service'
import { AppointmentDetailsUtilsService } from './services/appointment-details-utils.service'

@Component({
    selector: 'app-appointment-details',
    templateUrl: './appointment-details.component.html',
    styleUrls: ['./appointment-details.component.scss'],
    providers: [DatePipe, AppointmentDetailsService, AppointmentDetailsUtilsService]
})

export class AppointmentDetailsComponent implements OnDestroy, OnInit {

    @Input() apptType: any;
    @Input() stopID: number;
    @Input() position: number;
    @Input() appointmentData;
    @Input() scheduledAppts: object;
    @Input() apptRequested: object;
    @Input() stopNumber: number;
    @Input() stopResequenceDetails: Array<object>;
    @Input() isCurrViewTemplate: boolean;
    @Output() apptDetails = new EventEmitter();
    @Output() recommendedApptDetails = new EventEmitter();
    appointmentDetailsModel: AppointmentDetailsModel;
    appointmentForm: any;
    stop: any;

    constructor(
        public jbhGlobals: JBHGlobals,
        public datePipeObj: DatePipe,
        public addStopsOrderService: AddStopsOrderService,
        public orderFormBuilder: OrderFormBuilderService,
        public appointmentDetailsService: AppointmentDetailsService,
        public stopSharedDataService: StopSharedDataService,
        public appointmentDetailsUtilsService: AppointmentDetailsUtilsService) { }

    ngOnInit(): void {
        this.appointmentDetailsModel = new AppointmentDetailsModel();
        this.stop = this.stopNumber;
        if (this.apptType === 0) {
            this.apptType = 'Requested';
        } else {
            this.apptType = 'Scheduled';
        }
        this.appointmentForm = this.orderFormBuilder.getInitDateTimeDetails();
        this.loadOrderData();
        this.populateApptDetails();
        if (!this.appointmentDetailsModel.initialDateSet) {
            this.appointmentDetailsModel.myEndTime = this.appointmentDetailsUtilsService.setInitialTime();
            this.appointmentDetailsModel.myStartTime = this.appointmentDetailsUtilsService.setInitialTime();
            this.appointmentDetailsModel.initialDateSet = true;
        }
        this.appointmentDetailsUtilsService.setMeridiansStart(this.appointmentDetailsModel);
        // this.appointmentDetailsUtilsService.setMeridiansEnd(this.appointmentDetailsModel);
    }

    ngOnDestroy(): void {
        this.appointmentDetailsModel.subscriberFlag = false;
    }

    loadOrderData(): void {
        this.addStopsOrderService.getData().takeWhile(() => this.appointmentDetailsModel.subscriberFlag).subscribe(sharedOrderData => {
            if (!this.jbhGlobals.utils.isEmpty(sharedOrderData)) {
                for (let i = 0; i < sharedOrderData['stopDTOs']['stop']['appointment'].length; i++) {
                    sharedOrderData['stopDTOs']['stop']['appointment'][i].appointmentTypeCode =
                        sharedOrderData['stopDTOs']['stop']['appointment'][i].appointmentTypeCode;
                }
                this.appointmentDetailsModel.orderData = sharedOrderData;
            }
        });
    }

    populateApptDetails(): void {
        if (this.apptType === 'Requested') {
            this.appointmentDetailsModel.apptStartDateTime = this.apptRequested['appointmentStartTimestamp'];
            this.appointmentDetailsModel.apptEndDateTime = this.apptRequested['appointmentEndTimestamp'];
        } else if (this.apptType === 'Scheduled') {
            this.appointmentDetailsModel.apptStartDateTime = this.scheduledAppts['appointmentStartTimestamp'];
            this.appointmentDetailsModel.apptEndDateTime = this.scheduledAppts['appointmentEndTimestamp'];
        }
        if (this.appointmentDetailsModel.apptStartDateTime && this.appointmentDetailsModel.apptStartDateTime !== undefined ||
            this.appointmentDetailsModel.apptEndDateTime && this.appointmentDetailsModel.apptEndDateTime !== undefined) {
            this.setAppointmentDetails(this.appointmentDetailsModel.apptStartDateTime, this.appointmentDetailsModel.apptEndDateTime);
            this.appointmentDetailsModel.initialDateSet = true;
        }
    }

    setAppointmentDetails(apptStartDateTime, apptEndDateTime): void {
        this.appointmentDetailsUtilsService.setStartTimeToZero(this.appointmentDetailsModel);
        this.appointmentDetailsUtilsService.setEndTimeToZero(this.appointmentDetailsModel);
        if (apptStartDateTime !== null && apptStartDateTime !== undefined) {
            const appStartDate = this.appointmentDetailsService.setDateTimeDetails(apptStartDateTime);
            this.appointmentForm['controls']['appointmentStartDate']['setValue']({
                date: {
                    year: Number(moment(appStartDate).format('YYYY')),
                    month: Number(moment(appStartDate).format('M')),
                    day: Number(moment(appStartDate).format('D'))
                }
            });
            const startTime = apptStartDateTime.slice(0, 19);
            this.appointmentDetailsModel.apptStartTime = moment(startTime).format('HH:mm');
            this.appointmentDetailsModel.myStartTime = this.appointmentDetailsUtilsService.setTimeOnForm(appStartDate,
                this.appointmentDetailsModel.apptStartTime, 'Start Date');
        }
        if (apptEndDateTime !== null && apptEndDateTime !== undefined) {
            const appEndDate = this.appointmentDetailsService.setDateTimeDetails(apptEndDateTime);
            this.appointmentForm['controls']['appointmentEndDate']['setValue']({
                date: {
                    year: Number(moment(appEndDate).format('YYYY')),
                    month: Number(moment(appEndDate).format('M')),
                    day: Number(moment(appEndDate).format('D'))
                }
            });
            const endTime = apptEndDateTime.slice(0, 19);
            this.appointmentDetailsModel.apptEndTime = moment(endTime).format('HH:mm');
            this.appointmentDetailsModel.myEndTime = this.appointmentDetailsUtilsService.setTimeOnForm(appEndDate,
                this.appointmentDetailsModel.apptEndTime, 'End Date');
        }
    }

    onRemoveAppointmentDate(apptType: string, position: number): void {
        let apptId;
        let appt;
        let data;
        let apptDateTimeDetailId;
        appt = this.jbhGlobals.utils.find(this.appointmentDetailsModel.orderData.stopDTOs.stop.appointment, {
            appointmentTypeCode: apptType
        });
        if (apptType === 'Requested') {
            data = {
                'appointmentID': appt.appointmentID,
                'appointmentTypeCode': 'Requested',
                'requestCallBackIndicator': 'Y',
                'appointmentInboundDate': '',
                'appointmentDetails': [{
                    'appointmentDetailID': appt.appointmentDetails['0'].appointmentDetailID,
                    'appointmentSetReasonCode': '02'
                }],
                'appointmentDateTimeDetails': appt.appointmentDateTimeDetails,
                'stop': {
                    'stopID': this.appointmentDetailsModel.orderData.stopDTOs.stop.stopID
                }
            };
        } else if (apptType === 'Scheduled') {
            data = {
                'appointmentID': appt.appointmentID,
                'appointmentTypeCode': 'Scheduled',
                'appointmentConfirmationNumber': appt.appointmentConfirmationNumber,
                'requestCallBackIndicator': 'Y',
                'appointmentInboundDate': '',
                'appointmentDetails': [{
                    'appointmentDetailID': appt.appointmentDetails['0'].appointmentDetailID,
                    'appointmentSetReasonCode': '02'
                }],
                'appointmentDateTimeDetails': appt.appointmentDateTimeDetails,
                'appointmentInstructionAssociations': appt.appointmentInstructionAssociations,
                'stop': {
                    'stopID': this.appointmentDetailsModel.orderData.stopDTOs.stop.stopID
                }
            };
            if (data['appointmentInstructionAssociations'] && data['appointmentInstructionAssociations'].length !== 0 &&
                data['appointmentInstructionAssociations'].appointmentInstruction === '') {
                data['appointmentInstructionAssociations'] = [];
            }
        }
        if (appt && appt.appointmentID) {
            apptId = appt.appointmentID;
            apptDateTimeDetailId = appt.appointmentDateTimeDetails[position]['appointmentDateTimeDetailID'];
        }
        appt.appointmentDateTimeDetails.splice(position, 1);
        if (apptId && apptDateTimeDetailId) {
            this.appointmentDetailsService.loadUpdateService(this.jbhGlobals.endpoints.order.crudApptDetails + '/' + apptId,
                data).subscribe(apptData => {
                    this.jbhGlobals.notifications.alert('Warning', 'Appointment Deleted');
                });
        }
    }

    getRecommendedApptJson(firstStopData): object {
        const stopData = [];
        stopData.push(firstStopData);
        stopData.push(this.appointmentDetailsModel.orderData.stopDTOs.stop);
        this.appointmentDetailsModel.recommendedJson =
            this.appointmentDetailsService.reccommendedApptStructure(this.appointmentDetailsModel, stopData);
        return this.appointmentDetailsModel.recommendedJson;
    }

    submitRecommended(recommendedData): void {
        const firstStopDetails = recommendedData;
        const recommendedJson = this.getRecommendedApptJson(firstStopDetails);
        /*const recommendApptUrl = 'recommendedappointments';
        this.appointmentDetailsService.loadAddDataService(this.jbhGlobals.endpoints.order.getstopbyid + 'recommendedappointments',
            recommendedJson).subscribe(data => {
                this.appointmentDetailsModel.recommendedAppt = data;
            });*/
        if (recommendedData['stop']['appointment']) {
            recommendedData['stop']['appointment'].forEach(appointment => {
                console.log(appointment['appointmentTypeCode']);
                if (appointment['appointmentTypeCode'] === 'Recmmended') {
                    const startDate = moment(appointment['appointmentDateTimeDetails'][0]['appointmentStartTimestamp']).format('MM/DD/YYYY');
                    const startTime = moment(appointment['appointmentDateTimeDetails'][0]['appointmentStartTimestamp']).format('h:mm');
                    const startTimeStamp = startDate + ' ' + startTime;
                    const endDate = moment(appointment['appointmentDateTimeDetails'][0]['appointmentEndTimestamp']).format('MM/DD/YYYY');
                    const endTime = moment(appointment['appointmentDateTimeDetails'][0]['appointmentEndTimestamp']).format('h:mm');
                    const endTimeStamp = endDate + ' ' + endTime;
                    this.appointmentDetailsModel.recommendedAppt = startTimeStamp + ' - ' + endTimeStamp;
                    this.recommendedApptDetails.emit(this.appointmentDetailsModel.recommendedAppt);
                }
            });
        }
    }

    saveRecommendedAppt(): void {
        const prevStopNumber = this.stop;
        const stopId = this.stopResequenceDetails[prevStopNumber]['stop']['stopID'];
        if (stopId !== null && stopId !== undefined) {
            const stopParam = this.appointmentDetailsModel.orderData.orderID + '/stops/' + stopId;
            const stopUrl = this.jbhGlobals.endpoints.order.getstopbyid + stopParam;
            this.appointmentDetailsService.loadService(stopUrl).subscribe(data => {
                if (data && data !== undefined) {
                    this.submitRecommended(data);
                }
            });
        }
    }

    saveAppointment(): void {
        if (this.appointmentDetailsModel.apptStartDate === undefined) {
            this.appointmentDetailsModel.apptStartDate = this.appointmentDetailsUtilsService.getDateValue(
                this.appointmentForm.controls['appointmentStartDate'].value);
        }
        if (this.appointmentDetailsModel.apptEndDate === undefined) {
            this.appointmentDetailsModel.apptEndDate = this.appointmentDetailsUtilsService.getDateValue(
                this.appointmentForm.controls['appointmentEndDate'].value);
        }
        let apptId;
        const apptDetailId: any = '';
        let appt;
        appt = this.jbhGlobals.utils.find(this.appointmentDetailsModel.orderData.stopDTOs.stop.appointment, {
            appointmentTypeCode: this.apptType
        });
        if (appt && appt.appointmentID) {
            apptId = appt.appointmentID;
        }
        const primaryIndicator = this.appointmentDetailsService.primaryIndicatorGenerator(this.position);
        const appointmentStartTime = this.appointmentDetailsService.startDateTimeGenerator(
            this.appointmentDetailsModel.apptStartDate, this.appointmentDetailsModel.apptStartTime);
        const appointmentEndTime = this.appointmentDetailsService.EndDateTimeGenerator(
            this.appointmentDetailsModel.apptEndDate, this.appointmentDetailsModel.apptEndTime);
        if (appointmentStartTime !== undefined && appointmentStartTime !== null) {
            this.appointmentDetailsUtilsService.setStartFlag(true);
        }
        if (appointmentEndTime !== undefined && appointmentEndTime !== null) {
            this.appointmentDetailsUtilsService.setEndFlag(true);
        }
        this.selectServiceCall(appointmentStartTime, appointmentEndTime, primaryIndicator, apptId, apptDetailId);
    }

    selectServiceCall(appointmentStartTime: string, appointmentEndTime: string, primaryIndicator: string, apptId: number,
        apptDetailId: number): void {
        if (!this.isCurrViewTemplate) {
            if (!this.stopID) {
                this.jbhGlobals.notifications.alert('Warning', 'Stop should be created before adding appointment');
                return;
            } else if (apptId && apptId !== undefined) {
                this.updateAppointmentDetails(appointmentStartTime, appointmentEndTime, primaryIndicator, apptId, apptDetailId);
            } else {
                this.addAppointmentDetails(appointmentStartTime, appointmentEndTime, primaryIndicator);
            }
        } else {
            const json = this.appointmentDetailsService.appointmentJson(this.apptType, appointmentStartTime,
                appointmentEndTime, primaryIndicator, apptId, this.stopID, apptDetailId,
                this.scheduledAppts, this.apptRequested, this.appointmentDetailsModel);
            this.appointmentDetailsService.setApptToStopDto(this.apptType, {}, json, this.apptType, this.apptRequested,
                this.scheduledAppts, this.position, this.appointmentDetailsModel);
            return;
        }
    }

    addAppointmentDetails(appointmentStartTime: any, appointmentEndTime: any, primaryCallBack: string): void {
        const apptId: any = '';
        const apptDetailId: any = '';
        this.appointmentDetailsModel.apptJson =
            this.appointmentDetailsService.appointmentJson(this.apptType, appointmentStartTime, appointmentEndTime, primaryCallBack, apptId,
                this.stopID, apptDetailId, this.scheduledAppts, this.apptRequested, this.appointmentDetailsModel);
        this.appointmentDetailsService.loadAddDataService(this.jbhGlobals.endpoints.order.crudApptDetails,
            this.appointmentDetailsModel.apptJson).takeWhile(() => this.appointmentDetailsModel.subscriberFlag).subscribe(apptData => {
                if (!this.jbhGlobals.utils.isEmpty(apptData)) {
                    this.appointmentDetailsService.showSaveStatus(this.appointmentDetailsModel, this.apptType, 'Success', 'Add');
                    this.appointmentDetailsService.setApptToStopDto(this.apptType, apptData, this.appointmentDetailsModel.apptJson,
                        this.apptType, this.apptRequested, this.scheduledAppts, this.position, this.appointmentDetailsModel);
                    if (this.apptType === 'Scheduled') {
                        this.apptDetails.emit(true);
                    }
                    this.stopSharedDataService.getStopsSummary(this.appointmentDetailsModel.orderData.orderID);
                    this.saveRecommendedAppt();
                }
            }, (err: Error) => {
                this.appointmentDetailsService.showSaveStatus(this.appointmentDetailsModel, this.apptType, 'Error', 'Add');
            });
    }

    updateAppointmentDetails(appointmentStartTime: any, appointmentEndTime: any, primaryCallBack: string,
        apptId: any, apptDetailId: number): void {
        let apptDateTimeDetails;
        this.appointmentDetailsModel.apptJson =
            this.appointmentDetailsService.appointmentJson(this.apptType, appointmentStartTime, appointmentEndTime,
                primaryCallBack, apptId, this.stopID, apptDetailId, this.scheduledAppts, this.apptRequested, this.appointmentDetailsModel);
        apptId = '/' + apptId;
        apptDateTimeDetails = this.appointmentDetailsService.setApptToStopDto(this.apptType, '', this.appointmentDetailsModel.apptJson,
            this.apptType, this.apptRequested, this.scheduledAppts, this.position, this.appointmentDetailsModel);
        this.appointmentDetailsModel.apptJson['appointmentDateTimeDetails'] = apptDateTimeDetails;
        this.appointmentDetailsService.loadUpdateService(this.jbhGlobals.endpoints.order.crudApptDetails + apptId,
            this.appointmentDetailsModel.apptJson).subscribe(apptData => {
                if (!this.jbhGlobals.utils.isEmpty(apptData)) {
                    this.appointmentDetailsService.showSaveStatus(this.appointmentDetailsModel, this.apptType, 'Success', 'Edit');
                    this.appointmentDetailsService.setApptToStopDto(this.apptType, apptData, this.appointmentDetailsModel.apptJson,
                        this.apptType, this.apptRequested, this.scheduledAppts, this.position, this.appointmentDetailsModel);
                    this.stopSharedDataService.getStopsSummary(this.appointmentDetailsModel.orderData.orderID);
                    this.saveRecommendedAppt();
                }
            }, (err: Error) => {
                this.appointmentDetailsService.showSaveStatus(this.appointmentDetailsModel, this.apptType, 'Error', 'Edit');
            });
    }

    onStartDateChanged(event: any): void {
            if (event && event.formatted) {
                this.appointmentDetailsModel.startDate = event.formatted;
                this.appointmentDetailsModel.apptStartDate = event.formatted;
                this.appointmentDetailsModel.apptEndDate = this.appointmentDetailsUtilsService.getDateValue(
                    this.appointmentForm.controls['appointmentEndDate'].value);
                if (this.appointmentDetailsModel.apptStartDate) {
                    if (this.appointmentDetailsService.validateDateRange(this.appointmentDetailsModel.apptStartDate, 'appointmentStartDate',
                        'Start Date', this.apptType, this.apptRequested, this.scheduledAppts, this.appointmentForm,
                        this.appointmentDetailsModel)) {
                        this.onStartTimeChanged();
                    }
                }
            }
        if (event && event.formatted === '' && !this.appointmentDetailsModel.apptStartDate) {
                this.appointmentDetailsModel.startDate = null;
            this.appointmentForm.controls['appointmentStartTimestamp'].setValue(null);
            // appointmentDetailsModel.endTimeMeridian = false;
            this.appointmentForm.controls['appointmentStartDate'].setValue(null);
            this.appointmentDetailsModel.startTime = null;
                this.saveAppointment();
            }
    }

    checkConditionsForTime(apptFieldName: string): void {
        if (this.appointmentDetailsModel.endDate === null) {
            this.appointmentDetailsModel.myEndTime = this.appointmentDetailsUtilsService.setInitialTime();
            this.appointmentDetailsModel.apptEndTime = moment(this.appointmentDetailsModel.myEndTime).format('HH:mm');
            this.appointmentDetailsModel.endTime = this.appointmentDetailsModel.apptEndTime
        }
        if (this.appointmentDetailsModel.startDate === null) {
            this.appointmentDetailsModel.myStartTime = this.appointmentDetailsUtilsService.setInitialTime();
            this.appointmentDetailsModel.apptStartTime = moment(this.appointmentDetailsModel.myStartTime).format('HH:mm');
            this.appointmentDetailsModel.startTime = this.appointmentDetailsModel.apptStartTime
        }
        if (this.appointmentDetailsUtilsService.validateApptDateTime(this.appointmentDetailsModel.apptStartTime,
            this.appointmentDetailsModel.apptEndTime, this.appointmentDetailsModel.apptStartDate, this.appointmentDetailsModel.apptEndDate,
            apptFieldName, this.appointmentDetailsModel,
            this.appointmentForm)) {
            if (this.checkForDate(apptFieldName)) {
                this.saveAppointment();
            }
        }

    }

    checkForDate(apptFieldName: string): boolean {
        let isSave = true;
        if (apptFieldName === 'appointmentStartTimestamp') {
            if (this.appointmentDetailsModel.apptStartDate === undefined || this.appointmentDetailsModel.apptStartDate === null) {
                this.jbhGlobals.notifications.alert('Warning', 'Start date is Mandatory for Saving Appointmnet');
                isSave = false;
                this.appointmentDetailsUtilsService.setStartTimeToZero(this.appointmentDetailsModel);
            }
        } else if (apptFieldName === 'appointmentEndTimestamp') {
            if (this.appointmentDetailsModel.apptEndDate === undefined || this.appointmentDetailsModel.apptEndDate === null) {
                this.jbhGlobals.notifications.alert('Warning', 'End date is Mandatory for Saving Appointmnet');
                isSave = false;
                this.appointmentDetailsUtilsService.setEndTimeToZero(this.appointmentDetailsModel);
            }
        }
        return isSave;
    }

    onEndDateChanged(event: any): void {
            if (event && event.formatted) {
                this.appointmentDetailsModel.endDate = event.formatted;
                this.appointmentDetailsModel.apptEndDate = event.formatted;
                this.appointmentDetailsModel.apptStartDate = this.appointmentDetailsUtilsService.getDateValue(
                    this.appointmentForm.controls['appointmentStartDate'].value);
                if (this.appointmentDetailsModel.apptEndDate) {
                    if (this.appointmentDetailsService.validateDateRange(this.appointmentDetailsModel.apptEndDate, 'appointmentEndDate',
                        'End Date', this.apptType, this.apptRequested, this.scheduledAppts, this.appointmentForm,
                        this.appointmentDetailsModel)) {
                        this.onEndTimeChanged();
                    }
                }
            }
            if (event && event.formatted === '' && !this.appointmentDetailsModel.apptEndDate) {
                this.appointmentForm.controls['appointmentEndTimestamp'].setValue(null);
                // appointmentDetailsModel.endTimeMeridian = false;
                this.appointmentForm.controls['appointmentEndDate'].setValue(null);
                this.appointmentDetailsModel.endDate = null;
                this.appointmentDetailsModel.endTime = null;
                this.saveAppointment();
            }
    }

    onStartTimeChanged(): void {
        // this.appointmentDetailsModel.startTimeMeridian = true;
        this.appointmentDetailsModel.apptStartTime = moment(this.appointmentDetailsModel.myStartTime).format('HH:mm');
        if (this.appointmentDetailsModel.apptStartTime === 'Invalid date') {
            this.appointmentDetailsModel.myStartTime = this.appointmentDetailsUtilsService.setInitialTime();
            this.appointmentDetailsModel.apptStartTime = moment(this.appointmentDetailsModel.myStartTime).format('HH:mm');
        }
        if (this.appointmentDetailsModel.startTime !== this.appointmentDetailsModel.apptStartTime) {
            this.appointmentDetailsModel.startTime = this.appointmentDetailsModel.apptStartTime;
            this.appointmentDetailsUtilsService.timeValidator(this.appointmentDetailsModel,
                this.appointmentDetailsModel.myStartTime, 'Start');
            this.checkConditionsForTime('appointmentStartTimestamp');
        } else {
            this.appointmentDetailsUtilsService.setStartTimeToZero(this.appointmentDetailsModel);
        }
    }

    onEndTimeChanged(): void {
        // this.appointmentDetailsModel.endTimeMeridian = true;
        this.appointmentDetailsModel.apptEndTime = moment(this.appointmentDetailsModel.myEndTime).format('HH:mm');
        if (this.appointmentDetailsModel.apptEndTime === 'Invalid date') {
            this.appointmentDetailsModel.myEndTime = this.appointmentDetailsUtilsService.setInitialTime();
            this.appointmentDetailsModel.apptEndTime = moment(this.appointmentDetailsModel.myEndTime).format('HH:mm');
        }
        if (this.appointmentDetailsModel.endTime !== this.appointmentDetailsModel.apptEndTime) {
            this.appointmentDetailsModel.endTime = this.appointmentDetailsModel.apptEndTime;
            this.appointmentDetailsUtilsService.timeValidator(this.appointmentDetailsModel, this.appointmentDetailsModel.myEndTime, 'End');
            this.checkConditionsForTime('appointmentEndTimestamp');
        } else {
            this.appointmentDetailsUtilsService.setEndTimeToZero(this.appointmentDetailsModel);
        }
    }

    onEnterToClick(event): void {
        if (event.keyCode === 13) {
            event.currentTarget.click();
        }
    }
}
