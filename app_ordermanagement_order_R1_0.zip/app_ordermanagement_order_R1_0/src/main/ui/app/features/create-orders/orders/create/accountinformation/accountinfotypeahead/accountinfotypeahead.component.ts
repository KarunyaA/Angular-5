import { ChangeDetectionStrategy,ChangeDetectorRef, Component, Input, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';

import { JBHGlobals } from '../../../../../../app.service';
import { OrderService } from '../../../services/order.service';
import { OrderFormBuilderService } from '../../../services/order-form-builder.service';
import { AccountinfotypeaheadService } from './service/accountinfotypeahead.service';
import { AccountTypeaheadModel } from './model/accountinfotypeahead.model';
import { AddcontactsComponent } from '../../../addcontacts/addcontacts.component';
import * as moment from 'moment';

@Component({
    // changeDetection: ChangeDetectionStrategy.OnPush,
    selector: 'app-accountinfotypeahead',
    templateUrl: './accountinfotypeahead.component.html',
    styleUrls: ['./accountinfotypeahead.component.scss'],
    providers: [AccountinfotypeaheadService]
})
export class AccountInfoTypeaheadComponent implements OnInit, OnDestroy {
    @ViewChild(AddcontactsComponent) addcontact: AddcontactsComponent;
    @ViewChild('popoverDiv') popoverDiv: any;
    @ViewChild('pop') popup: any;
    @ViewChild('billtocontact') billtocontactTag;
    @ViewChild('lobContact') lobContactTag;
    @ViewChild('solicitorContact') solicitorTag;
    @ViewChild('addParties') addParties;
    @Input() isCurrViewTemplate: boolean;
    @Input() accountInfoForm: any;
    @Input() parentdata: any;
    accounttypeaheadmodel: AccountTypeaheadModel;
    subscriptions: any = [];
    orderData: any;
    debounceValue: number;
    flag: boolean;
    billIcon = false;
    lobIcon = false;
    addPartyCode: any;
    partyValue: any;
    lobValue: any;
    additionalpartytype: string;
    contactValue: any;
    displaytypeaheadvalue: any[] = [];
    hiddenTypeAheadList: string[] = [];
    orderId: number;
    additionalPartyValue: string;
    additionalPartyId: number;
    outSourcingVal: string;
    creditStatusBillTo: string;
    creditStatusLOB: string;
    dataPopulated: boolean;
    profileCode: any;
    accountRoleFlag = false;
    additionalPartyListFlag = false;
    additionalPartyRole: string;
    additionalPartyList: any = [];
    creditStatus: string;
    billOrgName: any;
    billValue: any;
    organizationName: any;
    addressValue: any;
    constructor(public jbhGlobals: JBHGlobals,
        public orderService: OrderService,
        public orderFormBuilder: OrderFormBuilderService,
        public accounttypeaheadservice: AccountinfotypeaheadService,
		private changeDetector: ChangeDetectorRef) {
        this.accounttypeaheadmodel = new AccountTypeaheadModel();
    }

    ngOnInit(): void {

        this.dataPopulated = false;
        this.accountInfoForm = this.orderFormBuilder.orderForm.controls['orderBillingDetail']['controls']['accountInfoForm'];
        this.debounceValue = this.jbhGlobals.settings.debounce;
        const me = this;
        this.jbhGlobals.utils.forIn(this.accountInfoForm.controls, function (value, name, object) {
            (<FormControl>me.accountInfoForm.controls[name]).setValue('');
            me.accountInfoForm.controls[name].setErrors(null);
        });

        this.getOrder();
        this.subscriptions.push(this.accountInfoForm['controls']['billToCode']['valueChanges']
            .debounceTime(this.debounceValue)
            .distinctUntilChanged()
            .subscribe((value) => {
                this.accounttypeaheadmodel['typeAheadList'] = [''];
                if (value !== null && value !== undefined && value.length === 0) {
                    if (value === '') {
                        this.accounttypeaheadmodel.billtocontacthide = false;
                        this.billIcon = false;
                        this.accountInfoForm['controls']['billToCode'].setValidators([Validators.required,
                        this.jbhGlobals.customValidator.alphaNumeric
                        ]);
                        this.accountInfoForm['controls']['billToCode'].updateValueAndValidity({
                            onlySelf: true,
                            emitEvent: false
                        });
                        if (this.isCurrViewTemplate) {
                            this.orderData['orderBillingDetailDTOs'] = [];
                        }
                    }
                    this.accountInfoForm['controls']['contactTypeCode']['setValue']('');
                    this.accounttypeaheadmodel.billToContactTypeRes = [];
                    this.accounttypeaheadmodel.typeAheadList = [];
                }
                if (!this.jbhGlobals.utils.isEmpty(value)) {
                    this.accounttypeaheadmodel.billtopartytype = 'Bill To';
                    if (value && value.length > 2 && this.checkVal(value, 'typeAheadList')) {
                        this.getBillToTypeAhead(value, this.accounttypeaheadmodel.billtopartytype);
                    }
                }
            }, (err: Error) => {
                console.log(err);
            }));
        this.subscriptions.push(this.accountInfoForm['controls']['lineofBusiness']['valueChanges']
            .debounceTime(this.debounceValue)
            .distinctUntilChanged()
            .subscribe((value) => {
                this.accounttypeaheadmodel['typeAheadListLOB'] = [''];
                if (value !== null && value !== undefined && value.length === 0) {
                    if (value === '') {
                        this.accounttypeaheadmodel.lobcontacthide = false;
                        this.lobIcon = false;
                        this.accounttypeaheadmodel.typeAheadListLOB = [];
                        this.accountInfoForm['controls']['lineofBusiness'].setValidators([
                            this.jbhGlobals.customValidator.alphaNumeric
                        ]);
                        this.accountInfoForm['controls']['lineofBusiness'].updateValueAndValidity({
                            onlySelf: true,
                            emitEvent: false
                        });
                    }
                    this.accountInfoForm['controls']['lineofbusinessContact']['setValue']('');
                    this.accounttypeaheadmodel.lineOfBusinessContactTypeRes = [];
                }
                if (!this.jbhGlobals.utils.isEmpty(value)) {
                    this.accounttypeaheadmodel.lobpartytype = 'LineOfBusiness';
                    if (value && value.length > 2 && this.checkVal(value, 'typeAheadListLOB')) {
                        this.getLineOfBusinessTypeAhead(value, this.accounttypeaheadmodel.lobpartytype);
                    }
                }
            }, (err: Error) => {
                console.log(err);
            }));
        this.subscriptions.push(this.accountInfoForm['controls']['aditionalparty']['valueChanges']
            .debounceTime(this.debounceValue)
            .distinctUntilChanged()
            .subscribe((value) => {
                this.accounttypeaheadmodel['hiddenTypeAheadList'] = [''];
                if (!this.jbhGlobals.utils.isEmpty(value)) {
                    this.additionalpartytype = 'AdditionalParty';
                    //  this.additionalpartytype = 'Bill To';
                    if (value && value.length > 2 && this.checkVal(value, 'hiddenTypeAheadList')) {
                        this.getAdditionalPartyTypeAhead(value, this.additionalpartytype);
                    }
                }
            }, (err: Error) => {
                console.log(err);
            }));
        this.subscriptions.push(this.accountInfoForm['controls']['accountRole']['valueChanges']
            .debounceTime(this.debounceValue)
            .distinctUntilChanged()
            .subscribe((value) => {
                if (!this.jbhGlobals.utils.isEmpty(value)) {
                    this.additionalpartytype = 'AdditionalParty';
                    if (value !== undefined && value.length > 2) {
                        if (value.indexOf(' ') === -1) {
                            this.getAccountRoles(value);
                        }
                    }
                }
            }, (err: Error) => {
                console.log(err);
            }));
        this.subscriptions.push(this.accountInfoForm['controls']['contactTypeCode']['valueChanges']
            .debounceTime(this.debounceValue)
            .distinctUntilChanged()
            .subscribe((billToContactCodeValue) => {
                if (!this.jbhGlobals.utils.isEmpty(billToContactCodeValue)) {
                    if (this.accounttypeaheadmodel.billToContactTypeRes && billToContactCodeValue) {
                        if (billToContactCodeValue[0].text !== 'Add Contact') {
                            const obj = this.transform(this.accounttypeaheadmodel.billToContactTypeRes, billToContactCodeValue[0].text)[0];
                            this.contactValue = billToContactCodeValue;
                            if (obj !== undefined) {
                                if (this.orderData['orderBillingDetailDTOs'] !== undefined) {
                                    if (this.orderData['orderBillingDetailDTOs'].length === 0) {
                                        const contactOrderDto = {
                                            'profileDTO': {
                                                'contactDTO': [{
                                                    'contactId': obj.contactId,
                                                    'contactType': obj.contactMethod
                                                }]
                                            }
                                        };
                                        if (this.isCurrViewTemplate) {
                                            this.orderData['orderBillingDetailDTOs'][0].profileDTO.contactDTO = [obj];
                                        } else {
                                            this.orderData['orderBillingDetailDTOs'].push(contactOrderDto);
                                        }
                                    } else if (this.orderData['orderBillingDetailDTOs'][0].profileDTO.contactDTO === null ||
                                        this.orderData['orderBillingDetailDTOs'][0].profileDTO.contactDTO === undefined) {
                                        const contactOrderDto = {
                                            'contactId': obj.contactId,
                                            'contactType': obj.contactMethod
                                        };
                                        if (this.isCurrViewTemplate) {
                                            this.orderData['orderBillingDetailDTOs'][0].profileDTO.contactDTO = [obj];
                                        } else {
                                            this.orderData['orderBillingDetailDTOs'][0].profileDTO.contactDTO = contactOrderDto;
                                        }
                                    } else {
                                        if (this.isCurrViewTemplate) {
                                            this.orderData['orderBillingDetailDTOs'][0].profileDTO.contactDTO = [obj];
                                        } else {
                                            this.orderData['orderBillingDetailDTOs'][0].profileDTO.contactDTO.contactId = obj.contactId;
                                            this.orderData['orderBillingDetailDTOs'][0].profileDTO.contactDTO.contactType = obj.contactMethod;
                                        }
                                    }
                                    if (!this.isCurrViewTemplate) {
                                        this.orderService.saveData(this.orderData);
                                    }
                                }
                            }
                        }
                    }
                }
            }, (err: Error) => {
                console.log(err);
            }));
        this.subscriptions.push(this.accountInfoForm['controls']['lineofbusinessContact']['valueChanges']
            .debounceTime(this.debounceValue)
            .distinctUntilChanged()
            .subscribe((lobContactCodeValue) => {
                if (!this.jbhGlobals.utils.isEmpty(lobContactCodeValue)) {
                    if (this.accounttypeaheadmodel.lineOfBusinessContactTypeRes && lobContactCodeValue) {
                        if (lobContactCodeValue[0].text !== 'Add Contact') {
                            const objlob = this.transformlob(
                                this.accounttypeaheadmodel.lineOfBusinessContactTypeRes, lobContactCodeValue[0].text)[0];
                            this.contactValue = lobContactCodeValue;
                            console.log(objlob);
                            if (objlob !== undefined) {
                                if (this.orderData['orderBillingDetailDTOs'] !== undefined) {
                                    if (this.orderData['orderBillingDetailDTOs'].length === 0) {
                                        const contactOrderDto = {
                                            'profileDTO': {
                                                'contactId': objlob.contactId,
                                                'contactType': objlob.contactMethod
                                            }
                                        };
                                        if (this.isCurrViewTemplate) {
                                            this.orderData['orderBillingDetailDTOs'].push(objlob);
                                        } else {
                                            this.orderData['orderBillingDetailDTOs'].push(contactOrderDto);
                                        }
                                    } else if (this.orderData['orderBillingDetailDTOs'][0].profileDTO.contactDTO === undefined ||
                                        this.orderData['orderBillingDetailDTOs'][0].profileDTO.contactDTO === null) {
                                        const contactOrderDto = {
                                            'contactId': objlob.contactId,
                                            'contactType': objlob.contactMethod
                                        };
                                        if (this.isCurrViewTemplate) {
                                            this.orderData['orderBillingDetailDTOs'][0].profileDTO.contactDTO = objlob;
                                        } else {
                                            this.orderData['orderBillingDetailDTOs'][0].profileDTO.contactDTO = contactOrderDto;
                                        }
                                    } else {
                                        this.orderData['orderBillingDetailDTOs'][0].profileDTO.contactDTO.contactId = objlob.contactId;
                                        this.orderData['orderBillingDetailDTOs'][0].profileDTO.contactDTO.contactType =
                                            objlob.contactMethod;
                                    }
                                }
                            }
                        }
                    }
                    this.orderService.saveData(this.orderData);
                }
            }, (err: Error) => {
                console.log(err);
            }));
        this.subscriptions.push(this.accountInfoForm['controls']['solicitorCodeContact']['valueChanges']
            .debounceTime(this.debounceValue)
            .distinctUntilChanged()
            .subscribe((solicitorContactCodeValue) => {
                if (!this.jbhGlobals.utils.isEmpty(solicitorContactCodeValue)) {
                    if (this.accounttypeaheadmodel.solicitorContactTypeRes &&
                        solicitorContactCodeValue) {
                        if (solicitorContactCodeValue[0].text !== 'Add Contact') {
                            const objsoli = this.transformSolicitor(
                                this.accounttypeaheadmodel.solicitorContactTypeRes, solicitorContactCodeValue[0].text)[0];
                            this.contactValue = solicitorContactCodeValue;
                            if (this.jbhGlobals.utils.isEmpty(this.orderData['orderRequestorDTOs'])) {
                                this.orderData['orderRequestorDTOs'] = [];
                                //   if (this.orderData['orderRequestorDTOs'].length === 0) {
                                const solicitorOrderDto = {
                                    'profileDTO': {
                                        'partyID': this.accounttypeaheadmodel.billtocode,
                                        'contactDTO': {
                                            'contactId': objsoli.contactId,
                                            'contactType': objsoli.contactMethod
                                        }
                                    }
                                };
                                this.orderData['orderRequestorDTOs'].push(solicitorOrderDto);
                                if (this.isCurrViewTemplate) {
                                    this.orderData['orderRequestorDTOs'][0]['profileDTO']['contactDTO'] = [objsoli];
                                }
                            } else {
                                if (this.isCurrViewTemplate) {
                                    this.orderData['orderRequestorDTOs'][0]['profileDTO']['contactDTO'] = [objsoli];
                                } else {
                                    this.orderData['orderRequestorDTOs'][0].profileDTO.profileDTO.contactDTO.contactId =
                                        objsoli.contactId;
                                    this.orderData['orderRequestorDTOs'][0].profileDTO.profileDTO.contactDTO.contactType =
                                        objsoli.contactMethod;
                                }
                            }
                            this.orderService.saveData(this.orderData);
                            //  }
                            /*   if (objsoli !== undefined) {
                              if (this.orderData['orderRequestorDTOs'] !== undefined) {
                             if (this.orderData['orderRequestorDTOs'].length === 0) {
                                 const contactOrderDto = {
                                     'profileDTO': {
                                         'contactId': objsoli.contactId,
                                         'contactType': objsoli.contactMethod
                                     }
                                 };
                                 this.orderData['orderRequestorDTOs'].push(contactOrderDto);
                             } else if (this.orderData['orderRequestorDTOs'][0].profileDTO.contactDTO === undefined ||
                                 this.orderData['orderRequestorDTOs'][0].profileDTO.contactDTO === null) {
                                 const soliContactOrderDto = {
                                     'contactId': objsoli.contactId,
                                     'contactType': objsoli.contactMethod
                                 };
                                 this.orderData['orderRequestorDTOs'][0].profileDTO.contactDTO = soliContactOrderDto;
                             } else {
                                 this.orderData['orderRequestorDTOs'][0].profileDTO.contactDTO.contactId = objsoli.contactId;
                                 this.orderData['orderRequestorDTOs'][0].profileDTO.contactDTO.contactType = objsoli.contactMethod;
                             }
                             this.orderService.saveData(this.orderData);
                           //  this.solicitorContactCodeChangeDetection(solicitorContactCodeValue);
                         }
                     }*/
                        }
                    }
                }
            }, (err: Error) => {
                console.log(err);
            }));
    }
    checkVal(value, typeaheadList): boolean {
        const format = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/;
        if (!format.test(value)) {
            return true;
        } else {
            return false;
        }
    }
    getAccountRoles(value) {
        const params = value;
        const url = this.jbhGlobals.endpoints.order.getAccountRoles;
        this.accounttypeaheadservice.getAccountRolesList(url + params).subscribe(data => {
            this.accounttypeaheadmodel.accountRoleList = [];
            for (let i = 0; i < data.length; i++) {
                this.accounttypeaheadmodel.accountRoleList.push(
                    {
                        id: data[i]['partyRoleTypeCode'],
                        text: data[i]['partyRoleTypeDescription']
                    }
                );
            }
            console.log(this.accounttypeaheadmodel.accountRoleList);
            this.accountRoleFlag = true;
        });
    }
    deleteAccountRole() {
        this.accountRoleFlag = false;
    }
    onSelectAccountRole(eve) {
        this.flag = false;
        this.accountRoleFlag = false;
        this.additionalPartyRole = eve.text;
        this.additionalPartyValue = eve.id;
        const additionalPartyObj = {
            partyID: this.additionalPartyId,
            partyValue: this.accountInfoForm['controls']['aditionalparty'].value,
            role: this.additionalPartyRole
        };
        this.additionalPartyList.push(additionalPartyObj);
        this.accounttypeaheadmodel.hiddenTypeAheadList = [];
        this.accountInfoForm['controls']['accountRole'].setValue('');
        this.accountInfoForm['controls']['aditionalparty'].setValue('');
        this.additionalPartyListFlag = true;
        if (!this.isCurrViewTemplate) {
            this.createAdditionalParty(this.orderId, this.additionalPartyId, this.additionalPartyValue);
        }
        // this.orderData['orderAssociatedParties'].push(orderDto);
        // this.orderService.saveData(this.orderData);
        if (this.isCurrViewTemplate) {
            this.orderData['orderAssociatedPartiesTmp']['partyType'] = eve.text;
            this.orderData['orderAssociatedPartiesTmp']['partyRoleCode'] = eve.id;
            this.orderData.orderAssociatedParties.push(this.orderData['orderAssociatedPartiesTmp']);
        }
        this.getOutSourcingFlag(this.additionalPartyId, 'partyValue', eve.id, this.accounttypeaheadmodel);
    }
    transform(items: any[], args: string): any {
        if (items) {
            return items.filter(item => this.checkArray(item, args));
        } else {
            return 0;
        }
        // filter items array, items which match and return true will be kept, false will be filtered out
    }
    checkArray(item, args) {
        if (item.contactValue && args) {
            return item.contactValue.toLowerCase().indexOf(args.split(', ')[1].toLowerCase()) !== -1;
        } else {
            return false;
        }
    }
    transformlob(items: any[], args: string): any {
        if (items) {
            return items.filter(item => this.checkArray(item, args));
        } else {
            return 0;
        }
        // filter items array, items which match and return true will be kept, false will be filtered out
    }
    transformSolicitor(items: any[], args: string): any {
        // filter items array, items which match and return true will be kept, false will be filtered out
        // return items.filter(item => item.firstName.toLowerCase().indexOf(args.toLowerCase()) !== -1 );
        if (items) {
            return items.filter(item => this.checkArray(item, args));
        } else {
            return 0;
        }
    }
    ngOnDestroy(): void {
        this.accountInfoForm.reset();
        for (const subs of this.subscriptions) {
            subs.unsubscribe();
        }
    }

    getBillToTypeAhead(value, billToPartyType) {
        const timestamp = moment(new Date()).format('YYYY-MM-DDTHH:mm:ss.SSS') + 'Z';
        const paramss = {
            'size': 6,
            '_source': [
                'OrganizationName',
                'PartyID',
                'CustomerCode',
                'partyaddresses.AddressLine1',
                'partyaddresses.AddressLine2',
                'partyaddresses.CityName',
                'partyaddresses.StateName',
                'partyaddresses.CountryName',
                'partyaddresses.PostalCode',
                'partyaddresses.PartyRoleTypeDescription',
                'ExpirationTimestamp',
                'OrganizationStatusTypeCode'
            ],
            'query': {
                'bool': {
                    'filter': {
                        'bool': {
                            'should': [
                                {
                                    'range': {
                                        'ExpirationTimestamp': {
                                            'lte': '2111-01-01T05:59:59.453Z'
                                        }
                                    }
                                },
                                {
                                    'range': {
                                        'ExpirationTimestamp': {
                                            'gte': timestamp
                                        }
                                    }
                                }
                            ],
                            'minimum_should_match': 2
                        }
                    },
                    'should': [
                        {
                            'query_string': {
                                'fields': [
                                    'OrganizationName^6',
                                    'CustomerCode^3'
                                ],
                                'query': value + '*',
                                'default_operator': 'and'
                            }
                        },
                        {
                            'nested': {
                                'path': 'partyaddresses',
                                'query': {
                                    'query_string': {
                                        'fields': [
                                            'partyaddresses.AddressLine1^18',
                                            'partyaddresses.AddressLine2^18',
                                            'partyaddresses.CityName^15',
                                            'partyaddresses.StateName^12',
                                            'partyaddresses.PostalCode^9',
                                            'partyaddresses.CountryName',
                                            'OrganizationName'
                                        ],
                                        'query': value + '*',
                                        'default_operator': 'and'
                                    }
                                },
                                'inner_hits': {
                                    'size': 1,
                                    '_source': {
                                        'includes': [
                                            'partyaddresses.AddressLine1',
                                            'partyaddresses.AddressLine2',
                                            'partyaddresses.CityName',
                                            'partyaddresses.StateName',
                                            'partyaddresses.CountryName',
                                            'partyaddresses.PostalCode',
                                            'partyaddresses.PartyRoleTypeDescription'
                                        ]
                                    }
                                }
                            }
                        }
                    ],
                    'minimum_should_match': 1,
                    'must': [
                        {
                            'query_string': {
                                'default_field': 'OrganizationStatusTypeCode.keyword',
                                'query': 'Approved'
                            }
                        },
                        {
                            'nested': {
                                'path': 'partyaddresses',
                                'query': {
                                    'match': {
                                        'partyaddresses.PartyRoleTypeDescription.keyword': 'Bill To'
                                    }
                                }
                            }
                        }
                    ]
                }
            }
        }

        this.accounttypeaheadservice.getTypeaheadList(this.jbhGlobals.endpoints.order.gettypeaheadlob, paramss).subscribe(data => {
            if (!this.jbhGlobals.utils.isEmpty(data['hits']['hits']) && data['hits']['hits'].length > 0) {
                this.accounttypeaheadmodel.typeAheadList = [];
                this.jbhGlobals.utils.map(data['hits']['hits'], (items) => {
                    const obj = {};
                    const source = items['_source']['partyaddresses'][0];
                    obj['name'] = source['AddressLine1'] + ' ' + source['AddressLine2'] + ', ' +
                        source['CityName'] + ', ' + source['StateName'] + ', ' + source['PostalCode'] + ', ' +
                        source['CountryName'] + ', ' + items['_source']['OrganizationName']
                        + ' (' + ((items['_source']['CustomerCode']) ? items['_source']['CustomerCode'] : '') + ')';
                    obj['partyId'] = items['_source']['PartyID'];
                    obj['orgName'] = items['_source']['OrganizationName'];
                    obj['addressDTO'] = items['_source']['partyaddresses'][0];
                    this.accounttypeaheadmodel.typeAheadList.push(obj);
					this.changeDetector.detectChanges();
                    console.log(obj);
                });
            } else {
                this.accounttypeaheadmodel.typeAheadList = [];
                this.accounttypeaheadmodel.typeAheadList.push({});
            }
        });
    }
    /*    public getSolicitorTypeAhead(value, solipartytype) {
             const params = {
                value: value,
                roletype: solipartytype,
                active: 'yes',
                page: 0,
                size: 5,
                approved: true,
                addresstype: 'MAILING'

         };
            this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getBillToData).subscribe(data => {
                //  if(data['profileDTO'] !== undefined){
                this.typeAheadListSolicitor = data['profileDTO'];
                // this.typeAheadListSolicitor.push(data['profileDTO']);
                console.log(this.typeAheadListSolicitor);
                // }
            });
        }*/
    getLineOfBusinessTypeAhead(value, lobpartytype) {
        const params = {
            'size': 0,
            '_source': ['OrganizationName', 'Level'],
            'query': {
                'bool':
                {
                    'must': [
                        {
                            'query_string':
                            {
                                'default_field': 'Level.keyword',
                                'query': ' Business Line ',
                                'split_on_whitespace': false
                            }
                        },
                        {
                            'query_string':
                            {
                                'default_field': 'OrganizationName',
                                'query': value + '*'
                            }
                        }]
                }
            },

            'aggs': {
                'unique': {
                    'terms': {
                        'field': 'OrganizationName.keyword',
                        'size': 6
                    },
                    'aggs': {
                        'Level': {
                            'top_hits': {

                                '_source': {
                                    'includes': ['OrganizationName', 'Level', 'OrganizationID']
                                },
                                'size': 1
                            }
                        }
                    }
                }
            }
        };
        this.accounttypeaheadservice.getTypeaheadList(this.jbhGlobals.endpoints.order.gettypeaheadlineofbusiness,
            params).subscribe(data => {
                if (data) {
                    if (data['aggregations'] && data['aggregations']['unique']
                        && data['aggregations']['unique']['buckets'].length > 0) {
                        const dataValues = data['aggregations']['unique']['buckets'],
                            dataLength = dataValues.length;
                        this.accounttypeaheadmodel.typeAheadListLOB = [];
                        for (let i = 0; i < dataLength; i++) {
                            if (dataValues[i]['key'] && dataValues[i]['Level']['hits'] &&
                                dataValues[i]['Level']['hits']['hits']) {
                                const obj = {};
                                obj['name'] = dataValues[i]['key'];
                                obj['id'] = dataValues[i]['Level']['hits']['hits'][0]['_source']['OrganizationID'];
                                this.accounttypeaheadmodel.typeAheadListLOB.push(obj);
								this.changeDetector.detectChanges();
                            }
                        }
                    } else {
                        this.accounttypeaheadmodel.typeAheadListLOB = [];
                        this.accounttypeaheadmodel.typeAheadListLOB.push({});
                    }
                }
            });
    }
    getAdditionalPartyTypeAhead(value, additionalpartytype) {
        const params = {
            'size': 6,
            '_source': ['OrganizationName', 'PartyID', 'CustomerCode', 'partyaddresses.AddressLine1', 'partyaddresses.AddressLine2',
                'partyaddresses.CityName', 'partyaddresses.StateName', 'partyaddresses.CountryName',
                'partyaddresses.PostalCode',
                'partyaddresses.PartyRoleTypeDescription'],
            'query': {
                'bool': {
                    'should': [
                        {
                            'query_string': {

                                'fields': ['OrganizationName', 'CustomerCode'],
                                'query': value + '*',
                                'default_operator': 'and'
                            }
                        },
                        {
                            'nested': {
                                'path': 'partyaddresses',
                                'query': {
                                    'query_string': {
                                        'fields': ['partyaddresses.AddressLine1', 'partyaddresses.AddressLine2',
                                            'partyaddresses.CityName', 'partyaddresses.StateName',
                                            'partyaddresses.PostalCode', 'partyaddresses.CountryName'],
                                        'query': value + '*',
                                        'default_operator': 'and'
                                    }
                                },

                                'inner_hits': {
                                    'size': 1,
                                    '_source': {
                                        'includes': ['partyaddresses.AddressLine1', 'partyaddresses.AddressLine2',
                                            'partyaddresses.CityName',
                                            'partyaddresses.StateName', 'partyaddresses.CountryName',
                                            'partyaddresses.PostalCode', 'partyaddresses.PartyRoleTypeDescription'
                                        ]
                                    }
                                }
                            }
                        }]
                }
            }
        };
        if (value !== undefined && value.length > 1) {
            this.jbhGlobals.apiService.addData(this.jbhGlobals.endpoints.order.gettypeaheadlob, params, false).subscribe(data => {
                if (!this.jbhGlobals.utils.isEmpty(data) && data['hits']['hits'].length > 0) {
                    this.accounttypeaheadmodel.hiddenTypeAheadList = [];
                    this.jbhGlobals.utils.map(data['hits']['hits'], (items) => {
                        const obj = {};
                        const source = items['_source']['partyaddresses'][0];
                        obj['name'] = source['AddressLine1'] + ' ' + source['AddressLine2'] + ', ' +
                            source['CityName'] + ', ' + source['StateName'] + ', ' + source['PostalCode'] + ', ' +
                            source['CountryName'] + ', ' + items['_source']['OrganizationName'];
                        obj['partyId'] = items['_source']['PartyID'];
                        obj['orgName'] = items['_source']['OrganizationName'];
                        obj['addressDTO'] = items['_source']['partyaddresses'][0];
                        this.accounttypeaheadmodel.hiddenTypeAheadList.push(obj);
						this.changeDetector.detectChanges();
                        console.log(obj);
                    });
                } else {
                    this.accounttypeaheadmodel.hiddenTypeAheadList = [];
                    this.accounttypeaheadmodel.hiddenTypeAheadList.push({});
                }
            });
        }
    }
    onSelectbilltoaddress(billToPartyCode, billToPartyType, contactComboValue, addedContact?: any) {
        // public onSelectbilltoaddress() {
        const params = {
            id: billToPartyCode,
            // id: 13883,
            roletype: billToPartyType,
            active: 'yes'
        };
        this.accounttypeaheadservice.getContactList(this.jbhGlobals.endpoints.order.getlobcontacts, params).subscribe(data => {
            if (!this.jbhGlobals.utils.isEmpty(data)) {
                this.accounttypeaheadmodel.stopAppointmentValue = [];
                this.accounttypeaheadmodel.billToContactTypeRes = data;
                for (let i = 0; i < this.accounttypeaheadmodel.billToContactTypeRes.length; i++) {
                    const value1 = this.accounttypeaheadmodel.billToContactTypeRes[i].firstName + ' ' +
                        this.accounttypeaheadmodel.billToContactTypeRes[i].lastName;
                    const value = value1 + ' , ' + this.accounttypeaheadmodel.billToContactTypeRes[i].contactValue;
                    this.accounttypeaheadmodel.stopAppointmentValue.push({
                        'id': value,
                        'text': value
                    });
                }
                this.accounttypeaheadmodel.stopAppointmentValue.push({
                    'id': 'Add Contact',
                    'text': 'Add Contact'
                });
                if (!this.jbhGlobals.utils.isEmpty(contactComboValue)) {
                    this.billtocontactTag.active.push({
                        'id': contactComboValue,
                        'text': contactComboValue
                    });
                }
                if (addedContact) {
                    const len = this.accounttypeaheadmodel.billToContactTypeRes.length;
                    const value1 = this.accounttypeaheadmodel.billToContactTypeRes[len - 1].firstName + ' ' +
                        this.accounttypeaheadmodel.billToContactTypeRes[len - 1].lastName;
                    const value = this.accounttypeaheadmodel.billToContactTypeRes[len - 1].contactValue;
                    const val = value1 + ' , ' + value;
                    const obj = {
                        'id': val,
                        'text': val
                    };
                    this.accountInfoForm['controls']['contactTypeCode']['setValue']([obj]);
                }
            }
        });
    }
    onSelectSolicitorContact(billToPartyCode, billToPartyType, contactComboValue) {
        const params = {
            id: billToPartyCode,
            // id: '20512',
            roletype: billToPartyType,
            active: 'YES',
            contacttype: 'SOLICITOR'
        };
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getlobcontacts, params, false).subscribe(data => {
            if (data !== undefined) {
                this.accounttypeaheadmodel.stopAppointmentValueSoli = [];
                this.accounttypeaheadmodel.solicitorContactTypeRes = data;
                // this.accounttypeaheadmodel.solicitorContactTypeRes = [{
                //     'contactId': 146148,
                //     'contactType': 'primary',
                //     'contactValue': '2062661000',
                //     'contactMethod': 'Phone',
                //     'firstName': 'Audrey',
                //     'lastName': 'Gibson',
                //     'personId': '1001'
                // }];
                for (let i = 0; i < this.accounttypeaheadmodel.solicitorContactTypeRes.length; i++) {
                    const value1 =
                        this.accounttypeaheadmodel.solicitorContactTypeRes[i].firstName +
                        ' ' + this.accounttypeaheadmodel.solicitorContactTypeRes[i].lastName;
                    const value = value1 + ' , ' +
                        this.accounttypeaheadmodel.solicitorContactTypeRes[i].contactValue;
                    this.accounttypeaheadmodel.stopAppointmentValueSoli.push({
                        'id': value,
                        'text': value
                    });
                }
            }
            if (!this.jbhGlobals.utils.isEmpty(contactComboValue)) {
                this.solicitorTag.active.push({
                    'id': contactComboValue,
                    'text': contactComboValue
                });
            }
        });
    }
    onSelectLineOfBusiness(lobpartycode, lobpartytype, contactComboValue) {
        const params = {
            // code: lobpartycode,
            id: lobpartycode,
            roletype: lobpartytype,
            active: 'yes'
        };
        this.accounttypeaheadservice.getContactList(this.jbhGlobals.endpoints.order.getlobcontact, params).subscribe(data => {
            /* if (data !== undefined) { */
            this.accounttypeaheadmodel.lineOfBusinessContactTypeRes = data['ProfileContactDTO']['contactDTO'];
            this.accounttypeaheadmodel.stopAppointmentValueLob = [];
            for (let i = 0; i < this.accounttypeaheadmodel.lineOfBusinessContactTypeRes.length; i++) {
                const value = this.accounttypeaheadmodel.lineOfBusinessContactTypeRes[i].firstName +
                    ' ' + this.accounttypeaheadmodel.lineOfBusinessContactTypeRes[i].lastName +
                    ' , ' + this.accounttypeaheadmodel.lineOfBusinessContactTypeRes[i].contactMethod;
                this.accounttypeaheadmodel.stopAppointmentValueLob.push({
                    'id': value,
                    'text': value
                });
            }
            this.accounttypeaheadmodel.stopAppointmentValueLob.push({
                'id': 'Add Contact',
                'text': 'Add Contact'
            });
            if (!this.jbhGlobals.utils.isEmpty(contactComboValue)) {
                this.lobContactTag.active.push({
                    'id': contactComboValue,
                    'text': contactComboValue
                });
            }
            //  }
        });
    }
    onClickAdditionalParty() {
        this.flag = true;
        if (this.additionalPartyList.length > 0) {
            this.additionalPartyListFlag = true;
        }
    }
    selectval(element, eve) {
        const temp = eve.item.addressDTO;
        this.organizationName = eve.item.orgName;
        this.addressValue = temp.AddressLine1 +
            temp.AddressLine2 + ' , ' + temp.CityName + ',' + temp.StateName + ' ,' + temp.PostalCode + ' , ' + temp.CountryName;
        this.getAccountRoles(eve.item.partyId);
        // this.flag = false;
        // this.addPartyCode = eve.item.id;
        if (this.isCurrViewTemplate) {
            if (!this.orderData.orderAssociatedParties) {
                this.orderData.orderAssociatedParties = [];
            }
            this.orderData['orderAssociatedPartiesTmp'] = this.additionalPartyDtoFramer(eve.item);
        }
        this.additionalPartyValue = eve.item.name;
        // + '-' + eve.item.addressDTO.AddressLine1
        //     + ' ' + eve.item.addressDTO.AddressLine2 +
        //     ',' + eve.item.addressDTO.CityName + ' ' + eve.item.addressDTO.CountryName +
        //     ' ' + eve.item.addressDTO.StateName + ' ' + eve.item.addressDTO.PostalCode + ' ' + '(' + eve.item.partyId + ')';
        if (this.displaytypeaheadvalue.indexOf(this.additionalPartyValue) === -1) {
            this.displaytypeaheadvalue.push(this.additionalPartyValue);
            // element.value = '';
            this.orderId = this.orderData.orderID;
            this.additionalPartyId = eve.item.partyId;
            this.additionalPartyValue = eve.item.name;
            /*if (!this.isCurrViewTemplate) {
                this.createAdditionalParty(this.orderId, this.additionalPartyId, this.additionalPartyValue);
            }*/
        }
        // this.orderData.orderAssociatedParties.push(this.additionalPartyDtoFramer(eve.item));
        // this.accounttypeaheadmodel.hiddenTypeAheadList = [];
        // this.getOutSourcingFlag(eve.item.id, 'partyValue', 'ADPART1');
        // this.getOutSourcingFlag(eve.item.partyId, 'partyValue', 'ADPART1', this.accounttypeaheadmodel);
    }
    additionalPartyDtoFramer(data) {
        if (data && data['addressDTO']) {
            const obj = {
                'partyID': data['partyId'],
                'partyName': data['name'],
                'addressDTO': {
                    'addressLineOne': data['addressDTO']['AddressLine1'],
                    'addressLineTwo': data['addressDTO']['AddressLine2'],
                    'city': data['addressDTO']['CityName'],
                    'cityID': '',
                    'country': data['addressDTO']['CountryName'],
                    'state': data['addressDTO']['StateName'],
                    'zipCode': data['addressDTO']['PostalCode']
                }
            };
            return obj;
        }
    }
    createAdditionalParty(orderId, additionalPartyId, additionalPartyValue) {
        const id = '/' + orderId;
        const params = {
            order: id,
            partyID: additionalPartyId,
            partyRoleCode: additionalPartyValue
            // partyRoleCode: 'AMSEF3'
        };
        this.jbhGlobals.apiService.addData(this.jbhGlobals.endpoints.order.getadditionalpartysave, params).subscribe(data => {
            this.accounttypeaheadmodel.associatedIdRecord.push(data['orderAssociatedPartyID']);
        });
    }
    onDeleteAdditionalParty(i: any) {
        const id = this.accounttypeaheadmodel.associatedIdRecord[i];
        this.displaytypeaheadvalue.splice(i, 1);
        this.additionalPartyList.splice(i, 1);
        this.accounttypeaheadmodel.associatedIdRecord.splice(i, 1);
        if (this.isCurrViewTemplate) {
            this.orderData.orderAssociatedParties.splice(i, 1);
        } else {
            this.jbhGlobals.apiService.removeData(this.jbhGlobals.endpoints.order.getadditionalpartydelet + '/' + id).subscribe(data => {
                console.log(data);
            }, (err: Error) => {
                console.log(err);
            });
        }
    }
    typeaheadOnSelect(eve) {
        this.accounttypeaheadmodel.billtocode = eve.item.partyId;
        const code = eve.value.split('(');
        const temp = eve.item.addressDTO;
        this.billOrgName = eve.item.orgName + ' (' + code[1]
        this.billValue = temp.AddressLine1 +
            temp.AddressLine2 + ' , ' + temp.CityName + ' , ' + temp.StateName + ' , ' + temp.PostalCode + ' , ' + temp.CountryName;
        // this.accounttypeaheadmodel.billtocode = '1001';
        this.profileCode = eve.item.partyId;
        this.accounttypeaheadmodel.billtopartytype = 'Bill To';
        this.billIcon = true;
        this.accounttypeaheadmodel.billtocontacthide = true;
        this.accountInfoForm['controls']['billToCode']['setValue'](eve.item.name);
        this.accountInfoForm['controls']['billToCode'].setValidators([Validators.required]);
        this.accountInfoForm['controls']['billToCode'].updateValueAndValidity({
            onlySelf: true,
            emitEvent: false
        });
        this.accountInfoForm['controls']['contactTypeCode'].setValidators();
        this.accountInfoForm['controls']['contactTypeCode'].updateValueAndValidity({
            onlySelf: true,
            emitEvent: false
        });
        this.accountInfoForm['controls']['lineofBusiness']['setValue']('');
        this.accountInfoForm['controls']['lineofbusinessContact']['setValue']('');
        this.onSelectbilltoaddress(this.accounttypeaheadmodel.billtocode, this.accounttypeaheadmodel.billtopartytype, null);
        this.onSelectSolicitorContact(this.accounttypeaheadmodel.billtocode, this.accounttypeaheadmodel.billtopartytype, null);
        console.log(this.orderData['orderBillingDetailDTOs']);
        if (this.orderData['orderBillingDetailDTOs']) {
            this.setTemplateData(eve);
            if (this.orderData['orderBillingDetailDTOs'].length === 0) {
                // console.log('len lob');
                const orderDto = {
                    'profileDTO': {
                        'partyID': this.accounttypeaheadmodel.billtocode // eve.item.id
                    },
                    'lineOfBusinessCode': null
                };
                this.orderData['orderBillingDetailDTOs'].push(orderDto);

            } else {
                if (this.orderData['orderBillingDetailDTOs'][0].profileDTO) {
                    this.orderData['orderBillingDetailDTOs'][0].profileDTO.partyID =
                        this.accounttypeaheadmodel.billtocode; // eve.item.id
                    this.orderData['orderBillingDetailDTOs'][0].lineOfBusinessCode = null;
                } else {
                    this.orderData['orderBillingDetailDTOs'][0]['profileDTO'] = {
                        'partyID': this.accounttypeaheadmodel.billtocode // eve.item.id
                    };
                    this.orderData['orderBillingDetailDTOs'][0]['lineOfBusinessCode'] = null;
                }
            }
        }
        this.orderService.saveData(this.orderData);
        this.accounttypeaheadmodel.typeAheadList = [];
        // this.getOutSourcingFlag(eve.item.id, 'outSourcingVal', 'BILL TO');
        this.getOutSourcingFlag(eve.item.partyId, 'outSourcingVal', 'BILL TO', this.accounttypeaheadmodel);
        this.getAutoRateStatus(eve.item.partyId);
        this.getCustomerId(eve.item.partyId);
        const url = this.jbhGlobals.endpoints.order.getCreditStatus + '' + this.accounttypeaheadmodel.billtocode;
        this.accounttypeaheadservice.getCreditStatus(url).subscribe(data => {
            console.log(data);
            if (!this.jbhGlobals.utils.isEmpty(data)) {
                this.creditStatus = data['creditStatus']
                // if (data['iscreditstatusapproved'] === true) {
                //     this.creditStatus = 'Approved';
                // } else if (data['iscreditstatusapproved'] === false) {
                //     this.creditStatus = 'Not Approved';
                // }
            }
        });
    }
    setTemplateData(eve) {
        if (this.isCurrViewTemplate) {
            if (!this.orderData['orderBillingDetailDTOs'][0]) {
                this.orderData['orderBillingDetailDTOs'] = [];
                this.orderData['orderBillingDetailDTOs'][0] = {};
            }
            const orderDto = this.getBillToTemplateDetails(eve);
            this.orderData['orderBillingDetailDTOs'][0]['profileDTO'] = {};
            this.orderData['orderBillingDetailDTOs'][0]['profileDTO'] = orderDto['profileDTO'];
            this.orderData['orderBillingDetailDTOs'][0]['lineOfBusinessCode'] = orderDto['lineOfBusinessCode'];
        }
    }
    typeaheadOnSelectLOB(eve) {
        this.accounttypeaheadmodel.lobcode = eve.item.id;
        this.profileCode = eve.item.id;
        this.accounttypeaheadmodel.lobpartytype = 'lineofbusiness';
        this.lobIcon = true;
        this.accounttypeaheadmodel.lobcontacthide = true;
        this.accountInfoForm.controls['lineofBusiness'].setValue(eve.item.name);
        this.onSelectLineOfBusiness(
            this.accounttypeaheadmodel.lobcode, this.accounttypeaheadmodel.lobpartytype, null);
        this.accountInfoForm['controls']['billToCode'].setValidators();
        this.accountInfoForm['controls']['billToCode'].updateValueAndValidity({
            onlySelf: true,
            emitEvent: false
        });
        this.accountInfoForm['controls']['lineofBusiness'].setValidators([Validators.required]);
        this.accountInfoForm['controls']['lineofBusiness'].updateValueAndValidity({
            onlySelf: true,
            emitEvent: false
        });
        this.accountInfoForm.controls['lineofbusinessContact'].setValidators();
        this.accountInfoForm.controls['lineofbusinessContact'].updateValueAndValidity({
            onlySelf: true,
            emitEvent: false
        });
        if (this.orderData['orderBillingDetailDTOs']) {
            this.setTemplateData(eve);
            if (this.orderData['orderBillingDetailDTOs'].length === 0) {
                const orderDto = {
                    'profileDTO': {
                        'partyID': null
                    },
                    'lineOfBusinessCode': this.accounttypeaheadmodel.lobcode
                };
                this.orderData['orderBillingDetailDTOs'].push(orderDto);
            } else {
                this.orderData['orderBillingDetailDTOs'][0].lineOfBusinessCode = this.accounttypeaheadmodel.lobcode;
                if (this.orderData['orderBillingDetailDTOs'][0].profileDTO) {
                    this.orderData['orderBillingDetailDTOs'][0].profileDTO.partyID = null;
                } else {
                    this.orderData['orderBillingDetailDTOs'][0]['profileDTO'] = { 'partyID': null };
                }
                // this.orderData['orderBillingDetailDTOs'][0].lineOfBusinessCode = this.accounttypeaheadmodel.lobcode;
                // this.orderData['orderBillingDetailDTOs'][0].profileDTO.partyID = null;
            }
            // this.orderService.saveData(this.orderData);
        }
        this.orderService.saveData(this.orderData);
        this.accounttypeaheadmodel.typeAheadListLOB = [];
        // this.getOutSourcingFlag(eve.item.id, 'lobValue', 'LineOfBusiness');
        this.getOutSourcingFlag(eve.item.id, 'lobValue', 'LineOfBusiness', this.accounttypeaheadmodel);
    }
    /*      public typeaheadOnSelectSoli(eve) {
             this.solicode = eve.item.code;
             this.solipartytype = 'Solicitor';
             this.solicontacthide = true;
             this.typeaheadModule.controls['solicitorCode'].setValue(eve.item.name + '-' +
                 eve.item.addressDTO.addressLine1 + ' ' + eve.item.addressDTO.addressLine2 +
                 ',' + eve.item.addressDTO.city + ' ' + eve.item.addressDTO.cityID + ' ' + eve.item.addressDTO.country +
                 ' ' + eve.item.addressDTO.state + ' ' + eve.item.addressDTO.zipcode);
             this.onSelectSolicitorContact(this.solicode, this.solipartytype);
             this.typeaheadModule.controls['solicitorCodeContact'].setValidators([Validators.required]);
             this.typeaheadModule.controls['solicitorCodeContact'].updateValueAndValidity({onlySelf: true, emitEvent: false});
             if (this.orderData['orderRequestorDTOs']) {
                 if (this.orderData['orderRequestorDTOs'].length === 0) {
                     const solicitorOrderDto = {
                         'profileDTO': {
                             'partyID': this.solicode // eve.item.code
                         }
                     };
                     this.orderData['orderRequestorDTOs'].push(solicitorOrderDto);
                 } else {
                     this.orderData['orderRequestorDTOs'][0].profileDTO.partyID = this.solicode; // eve.item.code;
                 }
                 this.orderService.saveData(this.orderData);
             }
         }*/
    billToAddContactChange(eve) {
        if (eve.id === 'Add Contact') {
            this.addcontact.showModal(this, 'Bill To');
        }
    }
    lobAddContactChange(eve) {
        if (eve.id === 'Add Contact') {
            this.addcontact.showModal(this);
        }
    }
    getOrder() {
        this.subscriptions.push(this.orderService.getData().subscribe(sharedOrderData => {
            if (!this.jbhGlobals.utils.isEmpty(sharedOrderData)) {

                this.orderData = sharedOrderData;
                // if (this.orderData !== 'undefined' || this.orderData.length !== 0) {
                this.callPopulateMethod();
                // console.log('Typeahead----------------->', this.orderData);
            }
        }));
    }
    callPopulateMethod() {
        // const fromStopFlag = this.jbhGlobals.commonDataService.getFromStopCheckFlag();
        if (!this.dataPopulated) {
            this.billtocontactTag.active = [];
            this.lobContactTag.active = [];
            this.populateData();
            this.dataPopulated = true;
        }
    }
    populateData() {
        // this.dataPopulated = true;
        if (this.orderData.orderBillingDetailDTOs.length !== 0) {
            if (this.orderData.orderBillingDetailDTOs[0].profileDTO.partyType !== 'LineOfBusiness') {

                this.accounttypeaheadmodel.billtocontacthide = true;
                this.billIcon = true;
                this.accounttypeaheadmodel.populatingvaluebillto =
                    this.orderData.orderBillingDetailDTOs[0].profileDTO.partyName + ' - ' +
                    this.orderData.orderBillingDetailDTOs[0].profileDTO.addressDTO.addressLineOne + ' ' +
                    this.orderData.orderBillingDetailDTOs[0].profileDTO.addressDTO.addressLineTwo + ' , ' +
                    this.orderData.orderBillingDetailDTOs[0].profileDTO.addressDTO.city + ' ' +
                    this.orderData.orderBillingDetailDTOs[0].profileDTO.addressDTO.country + ' ' +
                    this.orderData.orderBillingDetailDTOs[0].profileDTO.addressDTO.state + ' ' +
                    this.orderData.orderBillingDetailDTOs[0].profileDTO.addressDTO.zipCode + '(' +
                    this.orderData.orderBillingDetailDTOs[0].profileDTO.partyID + ')';
                this.accountInfoForm['controls']['billToCode'].setValue(
                    this.accounttypeaheadmodel.populatingvaluebillto);
                this.accountInfoForm['controls']['billToCode'].setValidators([Validators.required]);
                this.accountInfoForm['controls']['billToCode'].updateValueAndValidity({
                    onlySelf: true,
                    emitEvent: false
                });
                const profileDto = this.orderData['orderBillingDetailDTOs'][0].profileDTO;
                const addressDTO = profileDto.addressDTO;
                const code = profileDto.locationCode ? profileDto.locationCode : ' ';
                this.billOrgName = profileDto.partyName + ' (' + code + ')';
                this.billValue = addressDTO.addressLineOne + addressDTO.addressLineTwo + ' , ' +
                    addressDTO.city + ' , ' + addressDTO.state + ' , ' + addressDTO.zipCode + ' , ' + addressDTO.country;
                this.orderData['orderBillingDetailDTOs'][0].profileDTO.partyID =
                    this.orderData.orderBillingDetailDTOs[0].profileDTO.partyID; // eve.item.id
                this.orderData['orderBillingDetailDTOs'][0].lineOfBusinessCode = null;
                // console.log(this.populatingvaluebillto);
                // this.setOutSourcingFlag(ProfileDTO['outsourcing'], 'outSourcingVal', accounttypeaheadmodel);
                this.setOutSourcingFlag(this.orderData.orderBillingDetailDTOs[0].profileDTO['outsourcing'], 'outSourcingVal',
                    this.accounttypeaheadmodel);
                if (this.orderData.orderBillingDetailDTOs[0].profileDTO) {
                    const billcode = this.orderData.orderBillingDetailDTOs[0].profileDTO.partyID;
                    this.profileCode = this.orderData.orderBillingDetailDTOs[0].profileDTO.partyID;
                    const billtype = 'Bill To';
                    if (this.orderData.orderRequestorDTOs && this.orderData.orderRequestorDTOs[0] &&
                        this.orderData.orderRequestorDTOs[0].profileDTO &&
                        this.orderData.orderRequestorDTOs[0].profileDTO.contactDTO) {
                        const solicContactDto = this.orderData.orderRequestorDTOs[0].profileDTO.contactDTO;
                        let solicContact = {
                            'firstName': null,
                            'lastName': null,
                            'contactValue': null
                        };
                        if (solicContactDto) {
                            solicContact = solicContactDto[0] ? solicContactDto[0] : solicContactDto;
                        }
                        if (solicContact.firstName && solicContact.lastName) {
                            const soliComboValue = solicContact.firstName + ' ' +
                                solicContact.lastName + ' , ' + solicContact.contactValue;
                            this.onSelectSolicitorContact(billcode, billtype, soliComboValue);
                        }
                    } else {
                        this.onSelectSolicitorContact(billcode, billtype, null);
                    }
                    const contactDto = this.orderData.orderBillingDetailDTOs[0].profileDTO.contactDTO;
                    let contact = {
                        'firstName': null,
                        'lastName': null,
                        'contactValue': null
                    };
                    if (contactDto) {
                        contact = contactDto[0] ? contactDto[0] : contactDto;
                    }
                    if (contact.firstName !== null && contact.lastName !== null && contact.contactValue !== null) {
                        const contactComboValue = contact.firstName + ' ' +
                            contact.lastName + ' , ' + contact.contactValue;
                        //  if (!this.jbhGlobals.utils.isEmpty(contactComboValue)) {
                        this.onSelectbilltoaddress(billcode, billtype, contactComboValue);
                    } else {
                        this.onSelectbilltoaddress(billcode, billtype, null);
                    }
                } else {
                    const billcode = this.orderData.orderBillingDetailDTOs[0].profileDTO.partyID;
                    const billtype = 'Bill To';
                    this.onSelectbilltoaddress(billcode, billtype, null);
                    this.onSelectSolicitorContact(billcode, billtype, null);
                }
                this.accountInfoForm['controls']['billToCode'].setValidators();
                this.accountInfoForm['controls']['billToCode'].updateValueAndValidity({
                    onlySelf: true,
                    emitEvent: false
                });
                this.accountInfoForm['controls']['lineofBusiness'].setValidators();
                this.accountInfoForm['controls']['lineofBusiness'].updateValueAndValidity({
                    onlySelf: true,
                    emitEvent: false
                });
            } else {
                this.accounttypeaheadmodel.lobcontacthide = true;
                this.lobIcon = true;
                this.accounttypeaheadmodel.populatingvaluelob =
                    this.orderData.orderBillingDetailDTOs[0].profileDTO.partyName + ' - ' +
                    this.orderData.orderBillingDetailDTOs[0].profileDTO.addressDTO.addressLineOne + ' ' +
                    this.orderData.orderBillingDetailDTOs[0].profileDTO.addressDTO.addressLineTwo + ' , ' +
                    this.orderData.orderBillingDetailDTOs[0].profileDTO.addressDTO.city + ' ' +
                    this.orderData.orderBillingDetailDTOs[0].profileDTO.addressDTO.country + ' ' +
                    this.orderData.orderBillingDetailDTOs[0].profileDTO.addressDTO.state + ' ' +
                    this.orderData.orderBillingDetailDTOs[0].profileDTO.addressDTO.zipCode + ' (' +
                    this.orderData.orderBillingDetailDTOs[0].profileDTO.partyID + ')';
                this.accountInfoForm['controls']['lineofBusiness'].setValue(
                    this.accounttypeaheadmodel.populatingvaluelob);
                this.orderData['orderBillingDetailDTOs'][0].lineOfBusinessCode =
                    this.orderData.orderBillingDetailDTOs[0].profileDTO.partyID;
                this.orderData['orderBillingDetailDTOs'][0].profileDTO.partyID = null;
                // console.log(this.billtoaddressvalue)
                if (!this.jbhGlobals.utils.isEmpty(
                    this.orderData.orderBillingDetailDTOs[0].profileDTO.contactDTO)) {
                    const lobcode = this.orderData.orderBillingDetailDTOs[0].profileDTO.partyID;
                    this.profileCode = this.orderData.orderBillingDetailDTOs[0].lineOfBusinessCode;
                    const lobtype = 'LineOfBusiness';
                    const contactDto = this.orderData.orderBillingDetailDTOs[0].profileDTO.contactDTO;
                    let contact = {
                        'firstName': null,
                        'lastName': null,
                        'contactValue': null
                    };
                    if (contactDto) {
                        contact = contactDto[0] ? contactDto[0] : contactDto;
                    }
                    if (contact.firstName !== null && contact.lastName !== null && contact.contactValue !== null) {
                        const contactComboValue = contact.firstName + ' ' +
                            contact.lastName + ' , ' + contact.contactValue;
                        //   if (!this.jbhGlobals.utils.isEmpty(contactComboValue)) {
                        this.onSelectLineOfBusiness(lobcode, lobtype, contactComboValue);
                    } else {
                        this.onSelectLineOfBusiness(lobcode, lobtype, null);
                    }
                } else {
                    const lobcode = this.orderData.orderBillingDetailDTOs[0].profileDTO.partyID;
                    const lobtype = 'LineOfBusiness';
                    this.onSelectLineOfBusiness(lobcode, lobtype, null);
                }
                this.accountInfoForm['controls']['lineofBusiness'].setValidators();
                this.accountInfoForm['controls']['lineofBusiness'].updateValueAndValidity({
                    onlySelf: true,
                    emitEvent: false
                });
                this.accountInfoForm['controls']['lineofbusinessContact'].setValidators();
                this.accountInfoForm['controls']['lineofbusinessContact'].updateValueAndValidity({
                    onlySelf: true,
                    emitEvent: false
                });
                this.accountInfoForm['controls']['billToCode'].setValidators();
                this.accountInfoForm['controls']['billToCode'].updateValueAndValidity({
                    onlySelf: true,
                    emitEvent: false
                });
            }
        }

        if (this.orderData.orderAssociatedParties && this.orderData.orderAssociatedParties.length > 0) {
            this.additionalPartyListFlag = true;
            let partyText = '';
            // this.displaytypeaheadvalue = [];
            this.additionalPartyList = [];
            this.accounttypeaheadmodel.associatedIdRecord = [];
            for (const assParty of this.orderData.orderAssociatedParties) {
                partyText = assParty.partyName;
                const addDTO = assParty.addressDTO;
                if (assParty.addressDTO) {
                    partyText += '-' + assParty.addressDTO.addressLineOne + ' ' + assParty.addressDTO.addressLineTwo +
                        ',' + assParty.addressDTO.city + ' ' + assParty.addressDTO.country +
                        ' ' + assParty.addressDTO.state + ' ' + assParty.addressDTO.zipCode;
                    this.organizationName = assParty.partyName;
                    this.addressValue = addDTO.addressLineOne + addDTO.addressLineTwo + ' ,' +
                        addDTO.city + ' ,' + addDTO.state + ' ,' + addDTO.zipCode + ' ,' + addDTO.country;
                };
                partyText += ' (' + assParty.partyID + ')';
                const obj = {
                    partyID: assParty.partyID,
                    partyValue: partyText,
                    role: assParty.partyType
                }
                this.additionalPartyList.push(obj);
                this.accounttypeaheadmodel.associatedIdRecord.push(assParty.id);
            }
        }
    }
    onChangelob(val) {
        console.log(val);
    }
    onChangesoli(val) {
        console.log(val);
    }
    getBillToTemplateDetails(eve) {
        const obj = {
            'profileDTO': {
                'addressDTO': {
                    'addressLineOne': (eve.item.addressDTO) ?
                        eve.item.addressDTO.AddressLine1 : '',
                    'addressLineTwo': (eve.item.addressDTO) ?
                        eve.item.addressDTO.AddressLine1 : '',
                    'city': (eve.item.addressDTO) ?
                        eve.item.addressDTO.CityName : '',
                    'cityID': null,
                    'country': (eve.item.addressDTO) ?
                        eve.item.addressDTO.CountryName : '',
                    'state': eve.item.addressDTO ?
                        eve.item.addressDTO.StateName : '',
                    'zipCode': eve.item.addressDTO ?
                        eve.item.addressDTO.PostalCode : ''
                },
                'partyID': this.accounttypeaheadmodel.billtocode,
                'partyName': eve.item.name,
                'partyStatus': null,
                'partyType': null
            },
            'lineOfBusinessCode': this.accounttypeaheadmodel.lobcode
        };
        return obj;
    }
    // getOutSourcingFlag(id, field, role) {
    //     const URL = this.jbhGlobals.endpoints.order.getOutSourcingFlag,
    //         params = {
    //             'partyId': id,
    //             'roletype': role
    //         };
    //     this.accounttypeaheadservice.getOutSourcingFlag(URL, params).subscribe(data => {
    //         this.setOutSourcingFlag(data['outsourcingStatus'], field);
    //     });
    // }
    getOutSourcingFlag(id, field, role, accounttypeaheadmodel) {
        const URL = this.jbhGlobals.endpoints.order.getOutSourcingFlag,
            params = {
                'partyId': id,
                'roletype': role
            };
        this.accounttypeaheadservice.getOutSourcingFlag(URL, params).subscribe(data => {
            this.setOutSourcingFlag(data['outsourcingStatus'], field, accounttypeaheadmodel);
        });
    }
    getAutoRateStatus(billToId) {
        const URL = this.jbhGlobals.endpoints.order.getAutoRateStatus + '/' + billToId,
            params = {};
        this.accounttypeaheadservice.getOutSourcingFlag(URL, params).subscribe(data => {
            if (data && data['autoRateStatus'] === 'true') {
                this.orderData['orderBillingDetailDTOs'][0]['autorateIndicator'] = 'Y';
                this.orderService.saveData(this.orderData);
            } else if (data && data['autoRateStatus'] === 'false') {
                this.orderData['orderBillingDetailDTOs'][0]['autorateIndicator'] = 'N';
                this.orderService.saveData(this.orderData);
            }
        });
    }
    getCustomerId(billToId): void {
        const URL = this.jbhGlobals.endpoints.order.getCustomerId + '/' + billToId + '/billtocustomers',
            params = {};
        this.accounttypeaheadservice.getCustomerIdService(URL, params).subscribe(data => {
            this.orderData['customerID'] = (data && data[0] && data[0]['parentId']) ? data[0]['parentId'] : '';
            this.orderService.saveData(this.orderData);
        });
    }
    // setOutSourcingFlag(flag, field) {
    //     if (flag === true) {
    //         this[field] = 'Outsourcing Allowed';
    //     } else if (flag === false) {
    //         this[field] = 'Outsourcing Not Allowed';
    //     } else {
    //         this[field] = '';
    //     }
    // }
    setOutSourcingFlag(flag, field, accounttypeaheadmodel) {
        if (flag === true) {
            accounttypeaheadmodel[field] = 'Outsourcing Allowed';
        } else if (flag === false) {
            accounttypeaheadmodel[field] = 'Outsourcing Not Allowed';
        } else {
            accounttypeaheadmodel[field] = '';
        }
    }
    enterToClick(event) {
        if (event.keyCode === 13) {
            event.currentTarget.click();
        }
    }
    onDetailsClick(eve) {
        this.accounttypeaheadmodel.popOverFlag = true;
        window.open(this.jbhGlobals.endpoints.account.accountApplication + this.profileCode);
    }
    onPopOverBlur(popup): void {
        const scope = this;
        this.accounttypeaheadmodel.popOverFlag = true;
        setTimeout(() => {
            const popOVerList = this.popoverDiv['nativeElement'];
            popOVerList.setAttribute('tabindex', '1');
            popOVerList.focus();
            popOVerList.addEventListener('blur', function (event) {
                if (scope.accounttypeaheadmodel.popOverFlag) {
                    popup.hide();
                    scope.accounttypeaheadmodel.popOverFlag = false;
                }
            });
        }, 500);
    }
}