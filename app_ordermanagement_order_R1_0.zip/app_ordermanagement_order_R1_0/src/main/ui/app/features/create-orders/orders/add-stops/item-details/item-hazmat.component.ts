import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { JBHGlobals } from '../../../../../app.service';
import { AddStopsOrderService } from './../services/add-stops-order.service';
import { OrderFormBuilderService } from '../../services/order-form-builder.service';
import { ItemHazmatModel } from '../models/item-hazmat.model';

@Component({
    selector: 'app-item-hazmat',
    templateUrl: './item-hazmat.component.html',
    styleUrls: ['./item-details.component.scss']
})

export class ItemHazmatComponent implements OnInit {
    hazmatModel: any;
    @ViewChild('netExplosiveQnty') netExplosiveQnty: any;
    @ViewChild('unitOfWeightMeasurementCode') unitOfWeightMeasurementCode: any;
    @ViewChild('placad') placad: any;
    @ViewChild('driverreq') driverreq: any;
    @ViewChild('limitedQty') limitedQty: any;
    @ViewChild('reportableQty') reportableQty: any;
    @Input() isCurrViewTemplate: any;
    @Input() handlingIndex: any;
    @Input() dataIndex: any;
    @Input() hazmatService: any;
    @Output() hazmatObjFn = new EventEmitter();

    constructor(
        private jbhGlobals: JBHGlobals,
        private orderService: AddStopsOrderService,
        private orderFormBuilder: OrderFormBuilderService) {
        this.hazmatModel = new ItemHazmatModel();
    }

    ngOnInit(): void {
        this.hazmatModel.itemHazmatForm = this.orderFormBuilder.addHazmat();
        if (this.jbhGlobals.utils.isEmpty(this.hazmatModel.orderData)) {
            this.hazmatModel.subscription = this.orderService.getData().subscribe(sharedOrderData => {
                this.hazmatModel.orderData = sharedOrderData;
                if (this.hazmatModel.orderData.stopDTOs && this.hazmatModel.orderData.stopDTOs.itemHandlingDetailDTOs
                    && this.hazmatModel.orderData.stopDTOs.itemHandlingDetailDTOs[this.handlingIndex]) {
                    this.hazmatModel.stopData = this.hazmatModel.orderData.stopDTOs.itemHandlingDetailDTOs[this.handlingIndex];
                    this.hazmatModel.handlingData = this.hazmatModel.stopData.stopItemDTOs;
                    if (this.hazmatModel.orderData.stopDTOs && this.hazmatModel.orderData.stopDTOs.stop) {
                        this.hazmatModel.stopID = this.hazmatModel.orderData.stopDTOs.stop.stopID;
                    }
                    if (this.hazmatModel.stopData && this.hazmatModel.stopData.itemHandlingDetail) {
                        this.hazmatModel.handlingUnitID = this.hazmatModel.stopData.itemHandlingDetail.itemHandlingDetailID;
                    }
                    if (this.hazmatModel.handlingData[this.dataIndex] && this.hazmatModel.handlingData[this.dataIndex].stopItem) {
                        this.hazmatModel.stopItemID = this.hazmatModel.handlingData[this.dataIndex].stopItem.stopItemID;
                        this.hazmatModel.itemHazmatData = this.hazmatModel.handlingData[this.dataIndex];
                        const hazmatDat = this.hazmatModel.handlingData[this.dataIndex].stopItem.stopItemHazardousMaterialDetails;
                        if (hazmatDat && hazmatDat.length > 0) {
                            this.hazmatModel.hazmatSpecificData = hazmatDat[0];
                            this.hazmatModel.hazardMtrlId = this.hazmatModel.hazmatSpecificData.stopItemHazardousMaterialDetailID;
                        } else {
                            this.hazmatModel.hazmatSpecificData = this.hazmatModel.finalHazmatObj;
                        }
                    }
                    if (this.hazmatModel.stopID && this.hazmatModel.handlingUnitID &&
                        this.hazmatModel.stopItemID && this.hazmatModel.hazardMtrlId) {
                        if (this.hazmatModel.isDataLoaded) {
                            this.populateData();
                            this.hazmatModel.isDataLoaded = false;
                        }
                    } else if (this.isCurrViewTemplate) {
                        if (this.hazmatModel.isDataLoaded) {
                            this.populateData();
                            this.hazmatModel.isDataLoaded = false;
                        }
                    }
                }
            });
        }
        this.hazmatModel.debounceValue = this.jbhGlobals.settings.debounce;
        this.hazmatModel.itemHazmatForm['controls']['unnaCode']['valueChanges'].debounceTime(this.hazmatModel.debounceValue)
            .distinctUntilChanged().subscribe((value) => {
                if (value && value.length > 1) {
                    this.getUNNumber(value);
                }
            }, (err: Error) => {
                console.log(err);
            });
    }
    populateData() {
        if (!this.jbhGlobals.utils.isEmpty(this.hazmatModel.itemHazmatData.unnaCode)) {
            this.hazmatModel.itemHazmatForm.controls.unnaCode.setValue(this.hazmatModel.itemHazmatData.unnaCode);
            this.onSaveUnnaNumber(this.hazmatModel.itemHazmatData.unnaCode);
            this.populateHazmatFields();
        }
    }
    populateHazmatFields() {
        const form = this.hazmatModel.itemHazmatForm.controls;
        const itemHazmatData = this.hazmatModel.itemHazmatData;
        const hazmatSpecificData = this.hazmatModel.hazmatSpecificData;
        form.propershippingname.setValue([{ id: itemHazmatData['properShippingName'], text: itemHazmatData['properShippingName'] }]);
        form.hazmatclasscodes.setValue([{ id: itemHazmatData['primaryHazmatClass'], text: itemHazmatData['primaryHazmatClass'] }]);
        form.sechazmatclasscodes.setValue([{ id: itemHazmatData['secondaryHazmatClass'], text: itemHazmatData['secondaryHazmatClass'] }]);
        form.packaginggroup.setValue([{ id: itemHazmatData['packagingGroup'], text: itemHazmatData['packagingGroup'] }]);
        form.hazardousMaterialTechnicalname.setValue(hazmatSpecificData.hazardousMaterialTechnicalname);
        form.providerContractNumber.setValue(hazmatSpecificData.providerContractNumber);
        form.emergencyResponsePhoneNumber.setValue(hazmatSpecificData.emergencyResponsePhoneNumber);
        form.netExplosiveMassQuantity.setValue(hazmatSpecificData.netExplosiveMassQuantity);
        form.unitOfWeightMeasurementCode.setValue(hazmatSpecificData.unitOfWeightMeasurementCode);
        form.driverCertificationRequiredIndicator.setValue(
            (hazmatSpecificData.driverCertificationRequiredIndicator === 'Y') ? true : false);
        form.limitedQuantityIndicator.setValue((hazmatSpecificData.limitedQuantityIndicator === 'Y') ? true : false);
        form.placardRequiredIndicator.setValue((hazmatSpecificData.placardRequiredIndicator === 'Y') ? true : false);
        form.reportableQuantityIndicator.setValue((hazmatSpecificData.reportableQuantityIndicator === 'Y') ? true : false);
    }
    getUNNumber(val) {
       /* const unnObj = {
            'unnaCode': val
            //'projection': 'viewhazardousmaterialspecification'
        }; */
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getUnnaTypeahead + val).subscribe(data => {
            this.hazmatModel.getUNNumberList = data;
        });
    }
    checkUnnaCode(formObj) {
        if (formObj && formObj['stopItemHazardousMaterialDetails']) {
            formObj['stopItemHazardousMaterialDetails'].push(this.hazmatModel.finalHazmatObj);
        } else {
            return;
        }
    }
    // Functionality
    onSelectUnnaNumber(event) {
        this.netExplosiveQnty.nativeElement.value = '';
        this.hazmatModel.netExplosiveFlag = false;
        //this.placad.nativeElement.disabled = 'disabled';
        this.placad.nativeElement.checked = false;
        this.driverreq.nativeElement.checked = false;
        this.hazmatModel.unnNo = event.value;
        this.hazmatResetUnNaDependentFields();
        this.onSaveUnnaNumber(event.value);
        if (this.isCurrViewTemplate) {
            this.hazmatModel.handlingData[this.dataIndex]['unnaCode'] = event.value;
        }
    }
    onSaveUnnaNumber(value) {
            this.hazmatModel.unnNo = value;
            const unnObj = {
            'briefingReferenceRequests': {
                'briefing': [{
                    'hazMatSpecification': [{
                        'unnaCode': value,
                        'properShippingName': {
                            'name': ''
                        },
                        'packagingGroup': {
                            'code': ''
                        },
                        'hazMatClassType': [{
                            'hazMatClass': {
                                'code': ''
                            }
                        }]
                    }]
                }]
            }
        };
            this.jbhGlobals.apiService.addData(this.jbhGlobals.endpoints.order.getHazmatSecdy, unnObj).subscribe(data => {
            this.hazmatModel.getHazmatData = data;
            console.log(this.hazmatModel.getHazmatData);
            this.getHazmatListData(this.hazmatModel.getHazmatData);
        });
    }
    getHazmatListData(hazMatData) {
        this.hazmatModel.getProperShipping = this.getSecondaryHazDetails(hazMatData['properShippingName']);
        this.hazmatModel.getPackagingGroup = this.getSecondaryHazDetails(hazMatData['packagingGroup']);
        this.hazmatModel.getPrimaryHzdList = this.getSecondaryHazDetails(hazMatData['hazmatClassCodes']);
        this.hazmatModel.getSecondaryHzdList = this.getSecondaryHazDetails(hazMatData['secHazmatClassCodes']);
        if (hazMatData['hazmatClassCodes'][0]['code'] === '1.4S') {
            this.hazmatModel.netExplosiveFlag = true;
        }
    }
    getSecondaryHazDetails(hazmatData) {
        const hazmatArr = [];
        const optionLen = hazmatData.length;
        for (let i = 0; i < optionLen; i++) {
            hazmatArr.push(hazmatData[i]['code']);
        }
        return hazmatArr;
    }
    hazmatResetUnNaDependentFields(): any {
        this.hazmatModel.itemHazmatForm.controls.propershippingname.setValue([]);
        this.hazmatModel.itemHazmatForm.controls.hazmatclasscodes.setValue([]);
        this.hazmatModel.itemHazmatForm.controls.sechazmatclasscodes.setValue([]);
        this.hazmatModel.itemHazmatForm.controls.packaginggroup.setValue([]);
    }
    onSelectProperShipping(event) {
        if (this.jbhGlobals.utils.isEmpty(this.hazmatModel.properShippingTemp)) {
            if (this.jbhGlobals.utils.isEmpty(this.hazmatModel.properShippingTemp)) {
                this.hazmatModel.properShippingTemp =
                    this.hazmatModel.getHazmatData['packageGroupAndProperShippingNameMapping'][0]['properShippingName'];
                // this.getHazmatDetailsByProperShipperName(event.text);
            } else {
                // this.getHazmatDetailsByProperShipperName(event.text);
            }
        }
        if (this.isCurrViewTemplate) {
            this.hazmatModel.handlingData[this.dataIndex]['properShippingName'] = event.text;
        }
    }
    getHazmatDetailsByProperShipperName(properShippingVal) {
        this.hazmatModel.getPackagingGroup = [];
        this.hazmatModel.getPrimaryHzdList = [];
        this.hazmatModel.getSecondaryHzdList = [];
        const properlen = this.hazmatModel.properShippingTemp.length;
        for (let i = 0; i < properlen; i++) {
            if (this.hazmatModel.properShippingTemp[i]['properShippingName'] === properShippingVal) {
                this.hazmatModel.getPackagingGroup = this.hazmatModel.properShippingTemp[i]['packageGroups'];
                this.hazmatModel.getPrimaryHzdList = this.hazmatModel.properShippingTemp[i]['hazmatClassCodes'];
                this.hazmatModel.getSecondaryHzdList = this.hazmatModel.properShippingTemp[i]['secHazmatClassCodes'];
            }
        }
    }
    onSelectPrimaryHazmat(event) {
        if (this.jbhGlobals.utils.isEmpty(this.hazmatModel.primaryHazmatTemp)) {
            this.hazmatModel.primaryHazmatTemp =
                this.hazmatModel.getHazmatData['packageGroupAndProperShippingNameMapping'][0]['hazmatClassCodes'];
            // this.getHazmatDetailsByPrimaryClass(event.text);
        } else {
            // this.getHazmatDetailsByPrimaryClass(event.text);
        }
        if (this.isCurrViewTemplate) {
            this.hazmatModel.handlingData[this.dataIndex]['primaryHazmatClass'] = event.text;
        }
    }
    getHazmatDetailsByPrimaryClass(primaryHazmatVal) {
        this.hazmatModel.getPackagingGroup = [];
        this.hazmatModel.getSecondaryHzdList = [];
        this.hazmatModel.getProperShipping = [];
        const primaryhazlen = this.hazmatModel.primaryHazmatTemp.length;
        for (let i = 0; i < primaryhazlen; i++) {
            if (this.hazmatModel.primaryHazmatTemp[i]['hazmatClassCode'] === primaryHazmatVal) {
                this.hazmatModel.getPackagingGroup = this.hazmatModel.primaryHazmatTemp[i]['packageGroups'];
                this.hazmatModel.getSecondaryHzdList = this.hazmatModel.primaryHazmatTemp[i]['secHazmatClassCodes'];
                this.hazmatModel.getProperShipping = this.hazmatModel.primaryHazmatTemp[i]['properShippingNames'];
            }
        }
    }
    onSelectSecondaryHazmat(event) {
        if (this.jbhGlobals.utils.isEmpty(this.hazmatModel.secondaryHazmatTemp)) {
            this.hazmatModel.secondaryHazmatTemp =
                this.hazmatModel.getHazmatData['packageGroupAndProperShippingNameMapping'][0]['secHazmatClassCodes'];
            // this.getHazmatDetailsBySecondaryClass(event.text);
        } else {
            //  this.getHazmatDetailsBySecondaryClass(event.text);
        }
        if (this.isCurrViewTemplate) {
            this.hazmatModel.handlingData[this.dataIndex]['secondaryHazmatClass'] = event.text;
        }
    }
    getHazmatDetailsBySecondaryClass(secHazmatVal) {
        this.hazmatModel.getPackagingGroup = [];
        this.hazmatModel.getPrimaryHzdList = [];
        this.hazmatModel.getProperShipping = [];
        const sechazlen = this.hazmatModel.secondaryHazmatTemp.length;
        for (let i = 0; i < sechazlen; i++) {
            if (this.hazmatModel.secondaryHazmatTemp[i]['secHazmatClassCodes'] === secHazmatVal) {
                this.hazmatModel.getPackagingGroup = this.hazmatModel.secondaryHazmatTemp[i]['packageGroups'];
                this.hazmatModel.getPrimaryHzdList = this.hazmatModel.secondaryHazmatTemp[i]['hazmatClassCodes'];
                this.hazmatModel.getProperShipping = this.hazmatModel.secondaryHazmatTemp[i]['properShippingNames'];
            }
        }
    }
    onSelectPackingGroup(event) {
        if (this.jbhGlobals.utils.isEmpty(this.hazmatModel.packagingGroupTemp)) {
            this.hazmatModel.packagingGroupTemp =
                this.hazmatModel.getHazmatData['packageGroupAndProperShippingNameMapping'][0]['packageGroup'];
            // this.getHazmatDetailsByPackagingGroup(event.text);
        } else {
            // this.getHazmatDetailsByPackagingGroup(event.text);
        }
        if (this.isCurrViewTemplate) {
            this.hazmatModel.handlingData[this.dataIndex]['packagingGroup'] = event.text;
        }
    }
    getHazmatDetailsByPackagingGroup(packGrpVal) {
        this.hazmatModel.getSecondaryHzdList = [];
        this.hazmatModel.getPrimaryHzdList = [];
        this.hazmatModel.getProperShipping = [];
        const pkglen = this.hazmatModel.packagingGroupTemp.length;
        for (let i = 0; i < pkglen; i++) {
            if (this.hazmatModel.packagingGroupTemp[i]['packageGroupName'] === packGrpVal) {
                this.hazmatModel.getPrimaryHzdList = this.hazmatModel.packagingGroupTemp[i]['hazmatClassCodes'];
                this.hazmatModel.getSecondaryHzdList = this.hazmatModel.packagingGroupTemp[i]['secHazmatClassCodes'];
                this.hazmatModel.getProperShipping = this.hazmatModel.packagingGroupTemp[i]['properShippingNames'];
            }
        }
    }
    getHazmatSpecficationId() {
        const hazData = this.hazmatModel.itemHazmatForm.value;
        this.hazmatModel.hazMatSpecification = this.hazmatModel.getHazmatData['briefingReference'][0]['hazMatSpecification'];
        const hazLen = this.hazmatModel.hazMatSpecification.length;
        for (let i = 0; i < hazLen; i++) {
            const secHazClassCode = (this.hazmatModel.hazMatSpecification[i].hazMatClassType[1] !== undefined) ?
                this.hazmatModel.hazMatSpecification[i].hazMatClassType[0].hazMatClass.code : '';
            if (hazData.packaginggroup[0] && hazData.propershippingname[0] && hazData.hazmatclasscodes[0]) {
                // && hazData.sechazmatclasscodes[0]
                if (this.hazmatModel.hazMatSpecification[i].packagingGroup.code === hazData.packaginggroup[0].id &&
                    this.hazmatModel.hazMatSpecification[i].properShippingName.name === hazData.propershippingname[0].id &&
                    this.hazmatModel.hazMatSpecification[i].hazMatClassType[0].hazMatClass.code === hazData.hazmatclasscodes[0].id
                    // && secHazClassCode === hazData.sechazmatclasscodes
                ) {
                    console.log(this.hazmatModel.hazMatSpecification[i].hazMatSpecificationId);
                    this.hazmatModel.hazMatSpecificationId = this.hazmatModel.hazMatSpecification[i].hazMatSpecificationId;
                    this.hazmatModel.itemHazmatForm.value.hazardousMaterialSpecificationID = this.hazmatModel.hazMatSpecificationId;
                }
            }
        }
        this.saveHazmatDetails();
        this.getPlaCardDetails();
    }
    saveHazmatDetails() {
        const formObj = this.hazmatModel.itemHazmatData.stopItem;
        const form = this.hazmatModel.itemHazmatForm.value;
        form.driverCertificationRequiredIndicator = (this.driverreq.nativeElement.checked === true) ? 'Y' : 'N';
        form.limitedQuantityIndicator = (this.limitedQty.nativeElement.checked === true) ? 'Y' : 'N';
        form.placardRequiredIndicator = (this.placad.nativeElement.checked === true) ? 'Y' : 'N';
        form.reportableQuantityIndicator = (this.reportableQty.nativeElement.checked === true) ? 'Y' : 'N';
        this.hazmatModel.finalHazmatObj = {
            stopItemHazardousMaterialDetailID: this.hazmatModel.hazmatSpecificData.stopItemHazardousMaterialDetailID,
            driverCertificationRequiredIndicator: form.driverCertificationRequiredIndicator,
            emergencyResponsePhoneNumber: form.emergencyResponsePhoneNumber,
            hazardousMaterialSpecificationID: form.hazardousMaterialSpecificationID,
            providerContractNumber: form.providerContractNumber,
            unitOfWeightMeasurementCode: form.unitOfWeightMeasurementCode,
            netExplosiveMassQuantity: form.netExplosiveMassQuantity,
            limitedQuantityIndicator: form.limitedQuantityIndicator,
            reportableQuantityIndicator: form.reportableQuantityIndicator,
            placardRequiredIndicator: form.placardRequiredIndicator,
            hazardousMaterialTechnicalname: form.hazardousMaterialTechnicalname
        };
        formObj['stopItemHazardousMaterialDetails'][0] = this.hazmatModel.finalHazmatObj;
        this.hazmatObjFn.emit(formObj['stopItemHazardousMaterialDetails']);
    }
    getPlaCardDetails() {
        this.hazmatModel.hazMatSpecification[0]['unnaCode'] = this.hazmatModel.unnNo;
        this.hazmatModel.hazMatSpecification[0]['properShippingName']['code'] =
            this.hazmatModel.hazMatSpecification[0]['properShippingName']['name'];
        const PlacardVal = this.hazmatModel.hazMatSpecification[0]['placard']['name'] + ' ' +
            this.hazmatModel.hazMatSpecification[0]['unnaCode'].slice(-4);
        const operatorCodeHeader = {
            'userNameToken': 'rcon333'
        };
        const plaCardReqData = {
            'briefingRequests': {
                'briefing': [{
                    'briefingId': '',
                    'employeeId': '',
                    'dispatchType': {
                        'operatorCode': 'MUTR2'
                    },
                    'orderType': {
                        'orderNumber': '',
                        'truckDetails': {
                            'truckNumber': ['']
                        }
                    },
                    'highValue': {
                        'commodity': {
                            'type': {
                                'code': ''
                            },
                            'effDate': '',
                            'expDate': ''
                        },
                        'commodityName': ''
                    },
                    'auditFields': {
                        'auditFields': '',
                        'createdByName': '',
                        'createdByDate': '',
                        'updatedById': '',
                        'updatedByName': '',
                        'updatedByDate': ''
                    },
                    'orderNumbers': [''],
                    'hazMat': {
                        'placardingList': [{
                            'code': PlacardVal
                        }],
                        'stopNumber': 1,
                        'detail': [{
                            'hazMatSpecification': this.hazmatModel.hazMatSpecification[0],
                            'shipperDetails': {
                                'shipperId': ''
                            },
                            'placardException': {
                                'placardException': {
                                    'code': 'None'
                                }
                            },
                            'packageMeasurementType': {
                                'packageMeasurement': {
                                    'code': 'None'
                                }
                            },
                            'unitOfWeightMeasurementType': {
                                'unitOfWeightMeasurement': {
                                    'code': this.hazmatModel.itemHazmatForm['controls']['unitOfWeightMeasurementCode']['value']
                                }
                            },
                            'commodityCode': '',
                            'packageQuantity': 2,
                            'weightQuantity': this.hazmatModel.itemHazmatForm['controls']['netExplosiveMassQuantity']['value'] ?
                                this.hazmatModel.itemHazmatForm['controls']['netExplosiveMassQuantity']['value'] : 3254,
                            'weightCategoryCode': 'BULK',
                            'facilityType': null
                        }]
                    }
                }]
            }
        };
        this.jbhGlobals.apiService.addData(this.jbhGlobals.endpoints.order.getPlaCardDetails, plaCardReqData, operatorCodeHeader)
            .subscribe(data => {
                /* if (data['briefings'][0]['hazMat']['placardingList'][0]['code'] !== 'NON REQUIRED') {
                    if (me.hazmatModel.hazMatSpecification['hazMatClassType'][0]['hazMatClass']['code'] === '1.4') {
                            me.hazmatModel.itemHazmatForm.value.driverCertificationRequiredIndicator = true;
                            me.hazmatModel.itemHazmatForm.value.placardRequiredIndicator = true;
                            return true;
                    }
                    if ((me.hazmatModel.itemHazmatForm.value.driverCertificationRequiredIndicator === false) ?
                     true : (me.hazmatModel.itemHazmatForm.value.placardRequiredIndicator  === false) ? true : false) {
                         me.placad.nativeElement.checked = true;
                         this.saveHazmatDetails();
                    }
                }*/
                console.log(data);
            });
    }
}
