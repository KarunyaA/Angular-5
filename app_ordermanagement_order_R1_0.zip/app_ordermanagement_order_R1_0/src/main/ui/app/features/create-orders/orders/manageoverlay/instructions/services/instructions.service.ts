import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Response } from '@angular/http';
import { JBHGlobals } from '../../../../../../app.service';

@Injectable()
export class InstructionsService {
  constructor(private jbhGlobals: JBHGlobals) { }

createInstruction(instructionObj): Observable<Response[]> {
    return this.jbhGlobals.apiService
      .addData(this.jbhGlobals.endpoints.order.postInstruction, instructionObj);
  }

updateInstruction(instructionObj): Observable<Response[]> {
    return this.jbhGlobals.apiService
      .updateData(this.jbhGlobals.endpoints.order.updateInstruction + instructionObj['additionalInstructionId'], instructionObj);
  }
deleteInstruction(instructionId): Observable<Response[]> {
    return this.jbhGlobals.apiService
      .removeData(this.jbhGlobals.endpoints.order.removeInstruction + instructionId);
  }
readInstruction(instruction): Observable<Response[]> {
    return this.jbhGlobals.apiService.getData(instruction);
  }

}
