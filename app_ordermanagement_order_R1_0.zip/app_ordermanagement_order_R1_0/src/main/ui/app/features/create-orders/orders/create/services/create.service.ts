import { Injectable } from '@angular/core';

@Injectable()
export class CreateService {
  private equipmentResponse = [];

  constructor() { }

  getEquipmentRequirementResponse(): any {
    return this.equipmentResponse;
  }
  setEquipmentRequirementResponse(data): void {
    this.equipmentResponse = data;
  }
}
