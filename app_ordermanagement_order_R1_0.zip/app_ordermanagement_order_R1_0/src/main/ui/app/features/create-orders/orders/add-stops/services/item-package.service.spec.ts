import { inject, TestBed } from '@angular/core/testing';

import { ItemPackageService } from './item-package.service';

describe('ItemPackageService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ItemPackageService]
    });
  });

  it('should be created', inject([ItemPackageService], (service: ItemPackageService) => {
    expect(service).toBeTruthy();
  }));
});
