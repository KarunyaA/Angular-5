import { ChangeDetectorRef, Component, ElementRef, Input, OnDestroy, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { TypeaheadMatch } from 'ngx-bootstrap';
import { Observable, Subscription } from 'rxjs/Rx';
import 'rxjs/add/observable/of';

import { JBHGlobals } from '../../../../../app.service';
import { AddStopsOrderService } from './../services/add-stops-order.service';
import { OrderFormBuilderService } from '../../services/order-form-builder.service';
import { ItemHazmatComponent } from '../item-details/item-hazmat.component';
import { StopHandlingComponent } from '../handling-units/stop-handling.component';
import { ItemService } from '../services/item.service';
import { UnitOfLengthService } from '../services/unit-of-length.service';
import { UnitOfWeightService } from '../services/unit-of-weight.service';
import { ItemTemperatureService } from '../services/item-temperature.service';
import { ItemPackageService } from '../services/item-package.service';
import { ItemFreightClassService } from '../services/item-freight-class.service';
// import { ItemCategoryService } from '../services/item-category.service';
import { ItemDetailsModel } from '../models/item-details.model';
import { StopSharedDataService } from './../services/stop-shared-data.service';

@Component({
  selector: 'app-item-details',
  templateUrl: './item-details.component.html',
  providers: [ItemService],
  styleUrls: ['./item-details.component.scss']
})
export class ItemDetailsComponent implements OnInit, OnDestroy {
  // tslint:disable:member-access
  itemForm: any;
  index: any;
  confirmMessage: any;
  itemModel: ItemDetailsModel;
  itemHazmatAddFlag: any;
  @Input() isCurrViewTemplate: any;
  @Input() count: number;
  @Input() dataIndex: any;
  @Input() handlingIndex: any;
  @Input() lastItem: any;
  @Input() itemServices: any;
  // @ViewChild('transitem') transitem: any;
  // @ViewChild('saveditem') saveditem: any;
  @ViewChild('pop') pop: any;
  @ViewChild('itemServiceQuantity') itemServiceQuantity: any;
  @ViewChild('itemBarCodeNumber') itemBarCodeNumber: any;
  @ViewChild('serialNumber') serialNumber: any;
  @ViewChild('itemCharacteristicsTag') itemCharacteristicsTag: any;
  @ViewChild('majorRadio') majorRadio: any;
  @ViewChild('minorRadio') minorRadio: any;
  @ViewChild('itemPopup') itemPopup: any;
  @ViewChild('itemDiv') itemDiv: any;
  @ViewChild(ItemHazmatComponent) hazmatComponent: ItemHazmatComponent;
  @ViewChild('propershippingnameTag') propershippingnameTag: any;
  @ViewChild('primaryhazTag') primaryhazTag: any;
  @ViewChild('packaginggrpTag') packaginggrpTag: any;
  @ViewChild('packageUnitRef') packageUnitRef: any;
  @ViewChild('addItemBar') addItemBar;
  @ViewChild('addAdditional') addAdditional;
  @ViewChild('popInstance') popInstance: any;
  hazmatimer: any;
  sub: Subscription;
  showLabel = false;

  constructor(
    public orderService: AddStopsOrderService,
    public formBuilder: FormBuilder, public jbhGlobals: JBHGlobals,
    public orderFormBuilder: OrderFormBuilderService, public elementRef: ElementRef,
    private viewContainerRef: ViewContainerRef, public changeDetector: ChangeDetectorRef,
    public itemService: ItemService, public lengthService: UnitOfLengthService,
    public weightService: UnitOfWeightService, public temperatureService: ItemTemperatureService,
    public packageService: ItemPackageService, public frieghtService: ItemFreightClassService,
    // public categoryService: ItemCategoryService,
    public stopSharedDataService: StopSharedDataService) { }

  ngOnInit(): void {
    this.itemModel = new ItemDetailsModel();
    this.itemForm = this.orderFormBuilder.addItem();
    this.itemModel.emptyObj = this.itemModel.itemDescriptionObj;
    this.loadOrderData();
    this.itemModel.debounceValue = this.jbhGlobals.settings.debounce;
    this.loadLength();
    this.loadWeight();
    this.loadTemperature();
    // this.loadCategory();
    this.loadFreightClass();
    this.loadPackage(null);
    this.loadItemCharacteristics();
    this.loadExtremeLength();
    this.loadBarCodeType();
    this.hazmatimer = Observable.timer(4000);
    this.itemPopup['onHidden'].subscribe((selectedTranDesc) => {
      this.onPopupOutsideClose();
    });

    // this.itemModel.transItemFlag = (this.itemModel.icsLTLFlag || this.itemModel.dcsFlag) ? false : true;
    this.itemModel.subscriptions.push(this.itemForm['controls']['itemDescription']['valueChanges']
      .debounceTime(this.itemModel.debounceValue)
      .distinctUntilChanged()
      .subscribe((selectedTranDesc) => {
        if (selectedTranDesc.length < 1) {
          this.itemModel.transSearchFlag = false;
          this.itemModel.saveSearchFlag = false;
          this.itemModel.showTransDetailIcon = false;
          this.itemModel.showSaveDetailIcon = false;
          this.itemModel.onSelectTransValue = false;
        }
        if (selectedTranDesc !== undefined && selectedTranDesc.length > 2) {
          if (!this.itemModel.onSelectTransValue) {
            this.itemModel.typeaheadFlag = false;
            // if (this.transitem.nativeElement.checked === true) {
            this.loadTransType(selectedTranDesc, false, false);
            // } else {
            //   this.loadSavedItem(selectedTranDesc, false);
            // }
          }
        } else {
          this.itemForm['controls']['freightClassCode'].setValue([]);
        }
      }, (err: Error) => {
        console.log(err);
      }));
    this.itemModel.subscriptions.push(this.itemForm['controls']['popupItemDescription']['valueChanges']
      .debounceTime(this.itemModel.debounceValue)
      .distinctUntilChanged()
      .subscribe((selectedValue) => {
        if (selectedValue !== undefined && selectedValue.length > 2) {
          if (!this.itemModel.onSelectPopupValue) {
            if (this.itemModel.itemPopupHeading === 'Transactional Item') {
              this.loadTransType(selectedValue, true, false);
            } else {
              this.loadSavedItem(selectedValue, true);
            }
          }
        }
        if (selectedValue.length < 1) {
          this.itemModel.onSelectPopupValue = false;
          if (this.itemModel.itemPopupHeading === 'Transactional Item') {
            this.itemForm['controls']['nmfcNumber'].setValue('');
          } else {
            this.dataPopulation(this.itemForm['controls'], this.itemModel.itemDescriptionObj);
          }
        }
      }, (err: Error) => {
        console.log(err);
      }));
    this.itemModel.subscriptions.push(this.itemForm['controls']['nmfcNumber']['valueChanges']
      .debounceTime(this.itemModel.debounceValue)
      .distinctUntilChanged()
      .subscribe((selectedValue) => {
        if (selectedValue !== undefined && selectedValue !== '' && selectedValue !== null) {
          if (selectedValue.length > 2) {
            if (!this.itemModel.onSelectPopupNmfcValue) {
              if (this.itemModel.itemPopupHeading === 'Transactional Item') {
                this.loadTransType(selectedValue, true, true);
              }
            }
          }
        }
        if (selectedValue.length < 1) {
          this.itemModel.onSelectPopupNmfcValue = false;
        }
      }, (err: Error) => {
        console.log(err);
      }));
    this.itemModel.subscriptions.push(this.itemForm['controls']['itemLength']['valueChanges']
      .debounceTime(this.itemModel.debounceValue)
      .distinctUntilChanged()
      .subscribe((itemlength) => {
        if (itemlength) {
          this.itemModel.itemData[this.dataIndex].stopItem.itemLength = itemlength;
          this.calculateVolume();
          this.calculateDensity();
        } else {
          this.itemModel.itemData[this.dataIndex].stopItem.itemLength = null;
          this.setMeasurementEmpty();
        }
        this.checkExtremeLength();
      }, (err: Error) => {
        console.log(err);
      }));
    this.itemModel.subscriptions.push(this.itemForm['controls']['itemWidth']['valueChanges']
      .debounceTime(this.itemModel.debounceValue)
      .distinctUntilChanged()
      .subscribe((width) => {
        if (width) {
          this.itemModel.itemData[this.dataIndex].stopItem.itemWidth = width;
          this.calculateVolume();
          this.calculateDensity();
        } else {
          this.itemModel.itemData[this.dataIndex].stopItem.itemWidth = null;
          this.setMeasurementEmpty();
        }
      }, (err: Error) => {
        console.log(err);
      }));
    this.itemModel.subscriptions.push(this.itemForm['controls']['itemHeight']['valueChanges']
      .debounceTime(this.itemModel.debounceValue)
      .distinctUntilChanged()
      .subscribe((height) => {
        if (height) {
          this.itemModel.itemData[this.dataIndex].stopItem.itemHeight = height;
          this.calculateVolume();
          this.calculateDensity();
        } else {
          this.itemModel.itemData[this.dataIndex].stopItem.itemHeight = null;
          this.setMeasurementEmpty();
        }
      }, (err: Error) => {
        console.log(err);
      }));
    this.itemModel.subscriptions.push(this.itemForm['controls']['unitOfLengthMeasurementCode']['valueChanges']
      .debounceTime(this.itemModel.debounceValue)
      .distinctUntilChanged()
      .subscribe((unit) => {
        if (unit.length > 0) {
          this.itemModel.itemData[this.dataIndex].stopItem.unitOfLengthMeasurementCode = unit;
          this.calculateVolume();
          this.calculateDensity();
          this.checkExtremeLength();
        } else {
          this.itemModel.itemData[this.dataIndex].stopItem.unitOfLengthMeasurementCode = null;
          this.setMeasurementEmpty();
        }
      }, (err: Error) => {
        console.log(err);
      }));
    this.itemModel.subscriptions.push(this.itemForm['controls']['itemWeight']['valueChanges']
      .debounceTime(this.itemModel.debounceValue)
      .distinctUntilChanged()
      .subscribe((weight) => {
        this.itemModel.itemData[this.dataIndex].stopItem.itemWeight = weight ? weight : null;
        if (weight) {
          if (this.itemModel.itemDimensionFlag) {
            this.calculateVolume();
            this.calculateDensity();
          }
          this.calculateVolumeConversion();
        } else {
          this.setDensityEmpty();
          this.itemModel.itemDensity = '';
          this.itemModel.itemDenistyVal = '';
        }
      }, (err: Error) => {
        console.log(err);
      }));
    this.itemModel.subscriptions.push(this.itemForm['controls']['unitOfWeightMeasurementCode']['valueChanges']
      .debounceTime(this.itemModel.debounceValue)
      .distinctUntilChanged()
      .subscribe((weightunit) => {
        this.itemModel.itemData[this.dataIndex].stopItem.unitOfWeightMeasurementCode = weightunit.length > 0 ? weightunit : null;
        if (weightunit.length) {
          if (this.itemModel.itemDimensionFlag) {
            this.calculateVolume();
            this.calculateDensity();
          }
          this.calculateVolumeConversion();
        } else {
          this.setDensityEmpty();
          this.itemModel.itemDensity = '';
        }
      }, (err: Error) => {
        console.log(err);
      }));
    // this.itemModel.subscriptions.push(this.itemForm['controls']['packagingUnitTypeCode']['valueChanges']
    //   .debounceTime(this.itemModel.debounceValue)
    //   .distinctUntilChanged()
    //   .subscribe((packageUnit) => {
    //     this.itemModel.itemData[this.dataIndex].stopItem.packagingUnitTypeCode = packageUnit.length > 0 ? packageUnit : '';
    //   }, (err: Error) => {
    //     console.log(err);
    //   }));
    this.itemModel.subscriptions.push(this.itemForm['controls']['packagingUnitTypeQuantity']['valueChanges']
      .debounceTime(this.itemModel.debounceValue)
      .distinctUntilChanged()
      .subscribe((value) => {
        this.itemModel.itemData[this.dataIndex].stopItem.packagingUnitTypeQuantity = value ? value : null;
      }, (err: Error) => {
        console.log(err);
      }));
    this.itemModel.subscriptions.push(this.itemForm['controls']['itemTemperatureControlMethodCode']['valueChanges']
      .debounceTime(this.itemModel.debounceValue)
      .distinctUntilChanged()
      .subscribe((value) => {
        this.itemModel.itemData[this.dataIndex].stopItem.itemTemperatureControlMethodCode = value.length > 0 ? value : '';
      }, (err: Error) => {
        console.log(err);
      }));
    this.itemModel.subscriptions.push(this.itemForm['controls']['itemVolume']['valueChanges']
      .debounceTime(this.itemModel.debounceValue)
      .distinctUntilChanged()
      .subscribe((itemVolume) => {
        this.itemModel.itemData[this.dataIndex].stopItem.itemVolume = itemVolume ? itemVolume : null;
        this.itemModel.itemData[this.dataIndex].stopItem.unitOfVolumeMeasurementCode = itemVolume ? 'Cubic CM' : null;
        this.itemModel.itemVolumeVal = itemVolume ? itemVolume : '';
        this.itemModel.volMeasureFlag = itemVolume ? true : false;
        this.itemForm['controls']['itemVolume'].setValue(itemVolume ? itemVolume : '');
        this.itemForm['controls']['unitOfVolumeMeasurementCode'].setValue(itemVolume ? 'Cubic CM' : '');
        if (itemVolume) {
          this.calculateVolumeConversion();
        } else {
          this.itemModel.itemDenistyVal = '';
          this.setDensityEmpty();
        }
      }, (err: Error) => {
        console.log(err);
      }));
    if (this.isCurrViewTemplate) {
      this.itemForm['controls']['itemDescription'].setValidators([]);
      this.itemForm['controls']['itemDescription'].updateValueAndValidity();
    }
  }
  ngOnDestroy(): void {
    this.itemForm.reset();
    for (const subs of this.itemModel.subscriptions) {
      subs.unsubscribe();
    }
  }
  getstopHandlingComponent(): StopHandlingComponent {
    const handlingComp = this.viewContainerRef['_data'].componentView.component.viewContainerRef['_view'].component;
    const stopHandlingComp = handlingComp.viewContainerRef['_data'].componentView.component.viewContainerRef['_view'].component;
    return stopHandlingComp;
  }
  loadLength() {
    if (this.jbhGlobals.utils.isEmpty(this.itemModel.lengthList) || this.jbhGlobals.utils.isArray(this.itemModel.lengthList)) {
      this.lengthService.getData().subscribe(data => {
        this.itemModel.lengthList = data;
      });
    }
  }
  loadWeight() {
    if (this.jbhGlobals.utils.isEmpty(this.itemModel.weightList)) {
      this.weightService.getData().subscribe(data => {
        this.itemModel.weightList = data;
      });
    }
  }
  loadTemperature() {
    if (this.jbhGlobals.utils.isEmpty(this.itemModel.temperatureList)) {
      this.temperatureService.getData().subscribe(data => {
        this.itemModel.temperatureList = data;
      });
    }
  }
  // loadCategory() {
  //   if (this.jbhGlobals.utils.isEmpty(this.itemModel.categoryList)) {
  //     this.categoryService.getData().subscribe(data => {
  //       this.itemModel.categoryList = data;
  //     });
  //   }
  // }
  loadFreightClass() {
    if (this.jbhGlobals.utils.isEmpty(this.itemModel.freightClass)) {
      this.frieghtService.getData().subscribe(data => {
        this.itemModel.freightClass = data;
        this.itemModel.freightClassList = [];
        for (const freightCode of this.itemModel.freightClass) {
          this.itemModel.freightClassList.push({
            'id': freightCode.freightClassCode,
            'text': freightCode.freightClassCode + ',' + freightCode.freightClassDescription
          });
        }
        for (let i = 0; i < this.itemModel.freightClassList.length; i++) {
          const freightClassListId = this.itemModel.freightClassList[i].id;
          const frValue = this.itemModel.itemData[this.dataIndex].stopItem.freightClassCode;
          if (frValue === freightClassListId) {
            this.itemForm['controls']['freightClassCode'].setValue([{
              'id': freightClassListId,
              'text': this.itemModel.freightClassList[i].text
            }]);
          }
        }
      });
    }
  }
  loadPackage(populateValue) {
    if (this.jbhGlobals.utils.isEmpty(this.itemModel.packageList)) {
      this.packageService.getData().subscribe(data => {
        // this.itemModel.packageList = data;
        this.itemModel.packageList = [];
        for (const packagingUnit of data) {
          const obj = {
            'id': packagingUnit.packagingUnitTypeCode,
            'text': packagingUnit.packagingUnitTypeDescription
          };
          this.itemModel.packageList.push(obj);
        }
        this.setPopulateValue(populateValue);
      });
    } else {
      this.setPopulateValue(populateValue);
    }
  }
  loadOrderData() {
    this.orderService.getData().subscribe(sharedOrderData => {
      this.itemModel.orderData = sharedOrderData;
      this.itemModel.orderId = this.itemModel.orderData.orderID;
      if (this.itemModel.orderData.stopDTOs && this.itemModel.orderData.stopDTOs.itemHandlingDetailDTOs
        && this.itemModel.orderData.stopDTOs.itemHandlingDetailDTOs[this.handlingIndex]) {
        this.itemModel.handlingData = this.itemModel.orderData.stopDTOs.itemHandlingDetailDTOs[this.handlingIndex];
        this.itemModel.itemData = this.itemModel.handlingData.stopItemDTOs;
        this.itemModel.stopItemLength = this.itemModel.itemData.length - 1;
        this.itemModel.stopID = this.itemModel.orderData.stopDTOs.stop.stopID;
        this.itemModel.handlingUnitID = this.itemModel.handlingData.itemHandlingDetail.itemHandlingDetailID;
        if (this.itemModel.itemData[this.dataIndex]) {
          this.itemModel.stopItemID = this.itemModel.itemData[this.dataIndex].stopItem.stopItemID;
          const lengthMeasValue = this.itemModel.itemData[this.dataIndex].stopItem.unitOfLengthMeasurementCode;
          if (!this.itemModel.stopItemID && !this.isCurrViewTemplate) {
            this.setItemDefaultValue(this.itemForm);
          } else if (!lengthMeasValue && this.isCurrViewTemplate) {
            this.setItemDefaultValue(this.itemForm);
          }
        }
        if (!this.itemModel.isDataLoaded) {
          this.onBusinessUnitBased();
          this.volTrdCheck();
          // if (!this.itemModel.dcsFlag && !this.itemModel.icsLTLFlag) {
          this.onItemTypeChange('transactionalItem');
          // }
          const itemDataPopulation = this.itemModel.itemData[this.dataIndex].stopItem;
          if (this.itemModel.stopID && this.itemModel.handlingUnitID && this.itemModel.stopItemID) {
            this.itemModel.saveItemFlag = false;
            this.populateItem(itemDataPopulation);
          }
          if (this.isCurrViewTemplate && !this.jbhGlobals.utils.isEmpty(this.itemModel.orderData)) {
            this.populateItem(itemDataPopulation);
          }
        }
        this.itemModel.isDataLoaded = true;
      }
    });
  }
  setItemDefaultValue(form) {
    form['controls']['unitOfLengthMeasurementCode'].setValue('Inches');
    form['controls']['unitOfWeightMeasurementCode'].setValue('Pounds');
    this.itemModel.itemData[this.dataIndex].stopItem.unitOfLengthMeasurementCode = 'Inches';
    this.itemModel.itemData[this.dataIndex].stopItem.unitOfWeightMeasurementCode = 'Pounds';
  }
  onSelectPackagingUnitType(value, isSelect) {
    this.itemModel.itemData[this.dataIndex].stopItem.packagingUnitTypeCode = isSelect ? value : '';
  }
  setPopulateValue(populateValue) {
    if (populateValue) {
      for (const packagingUnit of this.itemModel.packageList) {
        if (populateValue === packagingUnit.id) {
          this.itemForm.controls['packagingUnitTypeCode'].setValue([packagingUnit]);
        }
      }
    }
  }
  onBusinessUnitBased() {
    const bu = this.itemModel.orderData.financeBusinessUnitCode;
    if (bu === 'DCS' || bu === 'ICS') {
      this.onServiceOfferingBased();
    }
    // this.disableSavedItem();
  }

  onServiceOfferingBased() {
    switch (this.itemModel.orderData.serviceOfferingCode) {
      case 'FinalMile':
        this.itemModel.dcsFlag = true;
        if (this.itemModel.orderData.orderTypeCode === 'Standard' || this.itemModel.orderData.orderTypeCode === 'Return') {
          this.itemForm['controls']['itemModelNumber'].setValidators([Validators.required]);
          this.itemForm['controls']['itemModelNumber'].updateValueAndValidity();
          this.itemForm['controls']['itemWeight'].setValidators([Validators.required]);
          this.itemForm['controls']['itemWeight'].updateValueAndValidity();
        } else {
          this.itemForm['controls']['itemModelNumber'].setValidators([]);
          this.itemForm['controls']['itemModelNumber'].updateValueAndValidity();
          this.itemForm['controls']['itemWeight'].setValidators([]);
          this.itemForm['controls']['itemWeight'].updateValueAndValidity();
        }
        break;
      case 'LTL':
        if (this.itemModel.orderData.orderSubTypeCode !== 'CON') {
          this.itemModel.icsLTLDirFlag = true;
        }
        this.itemModel.icsLTLFlag = true;
        this.mandateCheck();
        break;
      case 'Flatbed':
        this.itemModel.flatbedFlag = true;
        break;
      case 'Reefer':
        this.mandateCheck();
        break;
      default:
        break;
    }
    // this.disableSavedItem();
  }

  // disableSavedItem() {
  //   if (this.itemModel.dcsFlag || this.itemModel.icsLTLFlag) {
  //     this.saveditem.nativeElement.disabled = false;
  //     this.itemModel.transItemFlag = false;
  //   } else {
  //     this.saveditem.nativeElement.disabled = true;
  //     this.itemModel.transItemFlag = true;
  //   }
  // }
  mandateCheck() {
    if (this.itemModel.orderData.orderRefrigeratedIndicator === 'Y') {
      this.itemForm['controls']['freightClassCode'].setValidators([]);
      this.itemForm['controls']['freightClassCode'].updateValueAndValidity();
      this.itemForm['controls']['itemWeight'].setValidators([Validators.required]);
      this.itemForm['controls']['itemWeight'].updateValueAndValidity();
    } else {
      this.itemForm['controls']['freightClassCode'].setValidators([Validators.required]);
      this.itemForm['controls']['freightClassCode'].updateValueAndValidity();
      this.itemForm['controls']['itemWeight'].setValidators([Validators.required]);
      this.itemForm['controls']['itemWeight'].updateValueAndValidity();
    }
  }
  volTrdCheck() {
    if (!this.jbhGlobals.utils.isEmpty(this.itemModel.orderData.orderCarrierDetails) &&
      this.jbhGlobals.utils.isArray(this.itemModel.orderData.orderCarrierDetails)) {
      const carrrierDetails = this.itemModel.orderData.orderCarrierDetails;
      for (let i = 0; i < carrrierDetails.length; i++) {
        if ((carrrierDetails[i].orderVolumeTradeShowTypeCode === 'TrdShip') ||
          (carrrierDetails[i].orderVolumeTradeShowTypeCode === 'VolShip')) {
          this.validateDimension(true);
          this.itemForm['controls']['itemWeight'].setValidators([Validators.required]);
          this.itemForm['controls']['itemWeight'].updateValueAndValidity();
        }
      }
    }
  }
  itemFormSaveCall(itemAddFlag) {
    this.itemHazmatAddFlag = itemAddFlag;
    const form = this.itemModel.itemData[this.dataIndex].stopItem;
    if (this.itemModel.icsLTLFlag && this.itemModel.icsLTLDirFlag) {
      this.validateCubicCapacity(form);
    }
    this.validateItemForm(form);
    if (this.itemModel.showHazmat) {
      this.getHazmatDetails(form);
    } else {
      this.itemFormPostSave(form, itemAddFlag);
    }
  }
  hazmatEventEmit(hazmatForm: any): void {
    const form = this.itemModel.itemData[this.dataIndex].stopItem;
    form['stopItemHazardousMaterialDetails'] = hazmatForm;
    this.itemFormPostSave(form, this.itemHazmatAddFlag);
  }
  itemFormPostSave(form, itemAddFlag): boolean {
    let x: any;
    x = '';
    let invalidFields: any;
    invalidFields = [];
    for (x in form) {
      if (this.itemForm['controls'][x]) {
        if (!this.itemForm['controls'][x].valid) {
          this.itemForm['controls'][x].markAsTouched();
          // if (x === 'itemModelNumber' || x === 'itemManufacturer') {
          invalidFields.push(' ' + x);
          // }
        }
      }
    }
    const orderData = this.itemModel.orderData;
    const itemId = form.stopItemID,
      handlingTypeCode = this.itemModel.handlingData.itemHandlingDetail.itemHandlingTypeCode,
      businessUnit = orderData.financeBusinessUnitCode,
      serviceOff = orderData.serviceOfferingCode,
      lob = (this.jbhGlobals.utils.isEmpty(orderData.lineOfBusinessCode)) ? 'TKLT' : orderData.lineOfBusinessCode;
    console.log(this.itemForm);
    if (this.itemModel.stopID && this.itemModel.handlingUnitID && this.itemForm['valid'] &&
      this.itemModel.popupFlag === false && this.itemModel.saveItemFlag) {
      const params = form;
      params['itemHandlingDetail'] = {
        'itemHandlingDetailID': this.itemModel.handlingUnitID,
        'itemHandlingTypeCode': handlingTypeCode
      };
      if (itemId) {
        this.itemFormUpdateServiceCall(params, this.itemModel.stopID, this.itemModel.handlingUnitID,
          handlingTypeCode, businessUnit, serviceOff, lob, itemId, itemAddFlag);
      } else if (!itemId) {
        this.itemFormSaveServiceCall(params, this.itemModel.stopID, this.itemModel.handlingUnitID,
          handlingTypeCode, businessUnit, serviceOff, lob, itemAddFlag);
      }
    } else if (!this.itemModel.stopID && !this.isCurrViewTemplate) {
      this.jbhGlobals.notifications.error('Error', 'Stop information should be filled');
      return false;
    } else if (!this.itemModel.handlingUnitID && !this.isCurrViewTemplate && this.itemModel.handlingUnitSave) {
      this.jbhGlobals.notifications.error('Error', 'Handling details is not valid');
      return false;
    } else if (!this.itemForm['valid'] && !this.itemModel.handlingUnitID) {
      console.log(invalidFields);
      this.jbhGlobals.notifications.error('Error', 'Please fill all the required fiellds ' + invalidFields);
      return false;
    }

  }

  itemFormSaveServiceCall(params, stopId, handlingUnitId, handlingTypeCode, businessUnit, serviceOff, lob, addItemFlag) {
    const saveCallUrl = this.jbhGlobals.endpoints.order.saveItemDetailServiceCall;
    const url = saveCallUrl + '/' + stopId + '/stopitems?businessUnit=' +
      businessUnit + '&serviceOffering=' + serviceOff + '&lob=' + lob;
    this.itemService.addItem(url, params).subscribe(data => {
      delete data['itemHandlingDetail'];
      delete data['@id'];
      this.saveItemResponseToOrder(data, stopId);
      this.jbhGlobals.notifications.success('Success', 'Item added successfully');
      if (addItemFlag) {
        this.addItemForm();
      }
      this.stopSharedDataService.getStopsSummary(this.itemModel.orderData.orderID);
    });
  }

  itemFormUpdateServiceCall(params, stopId, handlingUnitId, handlingTypeCode, businessUnit, serviceOff, lob, itemId, addItemFlag) {
    const updateUrl = this.jbhGlobals.endpoints.order.crudHandlingUnit;
    const url = updateUrl + '/' + stopId + '/stopitems/' + itemId + '?businessUnit=' +
      businessUnit + '&serviceOffering=' + serviceOff + '&lob=' + lob;
    this.itemService.updateItem(url, params).subscribe(data => {
      this.saveItemResponseToOrder(data, stopId);
      this.jbhGlobals.notifications.success('Success', 'Item updated successfully');
      if (addItemFlag) {
        this.addItemForm();
      }
      this.stopSharedDataService.getStopsSummary(this.itemModel.orderData.orderID);
    });
  }
  getHazmatDetails(formObj): any {
    const form = formObj;
    if (this.hazmatComponent && this.hazmatComponent.hazmatModel.itemHazmatForm['controls']['unnaCode']['value'] !== '') {
      if (this.hazmatComponent.hazmatModel.itemHazmatForm['valid'] && this.hazmatComponent.hazmatModel.itemHazmatForm['dirty']) {
        this.hazmatComponent.getHazmatSpecficationId();
      } else if (!this.hazmatComponent.hazmatModel.itemHazmatForm['valid']) {
        let x: any;
        x = '';
        let invalidFields: any;
        invalidFields = [];
        for (x in form) {
          if (this.hazmatComponent.hazmatModel.itemHazmatForm['controls'][x]) {
            if (!this.hazmatComponent.hazmatModel.itemHazmatForm['controls'][x].valid) {
              this.hazmatComponent.hazmatModel.itemHazmatForm['controls'][x].markAsTouched();
              console.log(this.hazmatComponent.hazmatModel.itemHazmatForm['controls'][x].errors);
              invalidFields.push(' ' + x);
            }
          }
        }
        console.log(invalidFields);
        return this.jbhGlobals.notifications.error('Error', 'Please enter valid values ' + invalidFields);
      }
    } else {
      this.hazmatComponent.checkUnnaCode(form);
    }
  }

  onClickOfAddItem() {
    if (this.isCurrViewTemplate) {
      this.itemModel.addItemFlag = true;
      this.addItemForm();
    } else {
      if (this.itemModel.stopID && this.itemModel.handlingUnitID) {
        this.itemModel.addItemFlag = true;
        this.itemFormSaveCall(this.itemModel.addItemFlag);
      } else if (!this.itemModel.stopID && !this.isCurrViewTemplate) {
        this.jbhGlobals.notifications.error('Error', 'Stop information should be filled');
      } else if (!this.itemModel.handlingUnitID && !this.isCurrViewTemplate) {
        this.jbhGlobals.notifications.error('Error', 'Handling information should be filled');
      }
    }
  }
  addItemForm() {
    if (this.itemServices) {
      const itemObj = JSON.parse(JSON.stringify(
        this.itemServices['stopMock'].itemHandlingDetailDTOs[0].stopItemDTOs[0]));
      this.itemModel.handlingData.stopItemDTOs.push(itemObj);
      this.itemModel.addItemFlag = false;
      this.changeDetector.markForCheck();
    }
  }
  validateItemForm(form) {
    const isICSReefer = this.itemModel.orderData.financeBusinessUnitCode === 'ICS'
      && this.itemModel.orderData.serviceOfferingCode === 'Reefer' ? true : false;
    if (this.jbhGlobals.utils.isEmpty(form['itemLengthType'])) {
      form['itemLengthType'] = null;
      this.validateDimension(isICSReefer);
    }
    if (this.jbhGlobals.utils.isEmpty(form['itemVolumeType'])) {
      form['itemVolumeType'] = null;
    }
    if (this.jbhGlobals.utils.isEmpty(form['itemStackingType'])) {
      form['itemStackingType'] = null;
    }
    if (this.jbhGlobals.utils.isEmpty(form['itemProtectionType'])) {
      form['itemProtectionType'] = null;
    }
    if (this.itemModel.showHazmat === false) {
      form['stopItemHazardousMaterialDetails'] = [];
    }
    if (this.jbhGlobals.utils.isEmpty(form['stopItemBarcodeDetails'])) {
      form['stopItemBarcodeDetails'] = [];
    }
  }
  saveItemResponseToOrder(response, stopId) {
    this.itemModel.itemData[this.dataIndex].stopItem = response;
    this.itemModel.stopItemID = this.itemModel.itemData[this.dataIndex].stopItem.stopItemID;
    this.orderService.saveData(this.itemModel.orderData);
  }
  loadBarCodeType() {
    this.itemModel.itemBarCodeTypeList = [];
    this.itemService.getBarCode(this.jbhGlobals.endpoints.order.getItemBarCodeType).subscribe(data => {
      console.log(data);
      for (let i = 0; i < data['_embedded']['barcodeTypes'].length; i++) {
        this.itemModel.itemBarCodeTypeList.push({
          'id': data['_embedded']['barcodeTypes'][i].barcodeTypeCode,
          'text': data['_embedded']['barcodeTypes'][i].barcodeTypeDescription
        });
      }
    });
  }
  loadItemCharacteristics() {
    this.itemService.getItemCharacteristics(this.jbhGlobals.endpoints.order.getItemCharacteristics).subscribe(data => {
      this.itemModel.itemCharacteristicsList = data;
      if (this.itemModel.icsLTLFlag && this.itemModel.itemCharacteristicsList.length > 0) {
        this.itemModel.itemCharacteristicsList.push('Extreme Length');
      }
      const formdata = this.itemModel.handlingData.stopItemDTOs[this.dataIndex].stopItem;
      if (this.itemModel.stopID && this.itemModel.handlingUnitID && this.itemModel.stopItemID) {
        this.itemModel.saveItemFlag = false;
        this.setItemCharacteristics(formdata);
      }
      if (this.isCurrViewTemplate && !this.jbhGlobals.utils.isEmpty(formdata)) {
        this.setItemCharacteristics(formdata);
      }
    }
    );
  }
  loadExtremeLength() {
    const params = {
      'ParameterName': 'Extreme Length'
    };
    this.itemService.getExtremeLength(this.jbhGlobals.endpoints.order.getExtremLength, params).subscribe(data => {
      this.itemModel.extremeLength = data['parameterValue'];
      if (this.itemModel.icsLTLFlag) {
        this.checkExtremeLength();
      }
    });
  }
  loadTransType(value, fromPopUpFlag, fromNmfcFlag) {
    const url = this.jbhGlobals.endpoints.order.getTransTypeahead + '/' + value;
    this.itemService.transItemDescription(url).subscribe(data => {
      this.itemModel.transSearchFlag = data.length < 1 ? true : false;
      this.itemModel.itemDescriptionList = data;
      if (fromPopUpFlag) {
        if (fromNmfcFlag) {
          this.itemModel.nmfcNumberList = data
        } else {
          this.itemModel.popUpItemDescriptionList = data;
        }
      } else {
        this.itemModel.transTypeaheadList = data;
        console.log(data);
        this.itemModel.transTypeaheadList.push({
          'itemDescription': 'Add new Item',
          'nmfcFreightClassification': '',
          'nmfcItemSub': '',
          'nmfcNumber': '',
          'pntrNmfcItem': '',
          'sequenceNumber': ''
        });
		this.changeDetector.detectChanges();
        console.log(this.itemModel.transTypeaheadList);
      }
    });
  }
  loadSavedItem(value, fromPopUpFlag) {
    const url = this.jbhGlobals.endpoints.order.getSavedItem + '/' + value;
    this.itemService.savedItemDescription(url).subscribe(data => {
      this.itemModel.saveSearchFlag = data.length < 1 ? true : false;
      if (fromPopUpFlag) {
        this.itemModel.popUpItemDescriptionList = data;
      } else {
        this.itemModel.saveItemList = data;
      }
    });
  }
  loadItemService(value) {
    const url = this.jbhGlobals.endpoints.order.getItemServices;
    // 20185260
    const params = {
      'modelNumber': value,
      'productCategory': 'ALL',
      'tradingPartner': 'ABFS'
    };
    this.itemService.getItemService(url, params).subscribe(data => {
      this.itemModel.standardServicesList = data['Standard Services'];
      this.itemModel.itemServiceList = data['Additonal Services'];
      for (let i = 0; i < this.itemModel.standardServicesList.length; i++) {
        const itemServiceObj = {
          stopItemServiceDetailID: '',
          itemServiceID: this.itemModel.standardServicesList[i].requestServiceTypeId,
          itemServiceTypeCode: this.itemModel.standardServicesList[i].customerServiceTypeCode,
          itemServiceDescription: this.itemModel.standardServicesList[i].serviceDescription,
          itemServiceQuantity: 0
        };
        this.itemModel.itemData[this.dataIndex].stopItem.stopItemServiceDetails.push(itemServiceObj);
      }
      this.itemModel.standardServiceFlag = false;
    });
  }
  setMeasurementEmpty() {
    this.itemForm['controls']['itemVolume'].setValue('');
    this.itemForm['controls']['itemDensity'].setValue('');
    this.itemModel.itemDensity = '';
    this.itemModel.volumeVal = '';
    this.itemModel.volMeasureFlag = false;
    this.itemModel.denMeasureFlag = false;
  }

  onClickOfSerailNumber(event) {
    this.itemModel.serialNumberFlag = true;
  }
  addSerialNumber(event) {
    const serialNumber = parseInt(event.target.value, 10);
    if (serialNumber !== null) {
      const serialObj = {
        'stopitemSerialNumberDetailID': '',
        'stopItemSerialNumber': serialNumber
      };
      const serialArr = JSON.parse(JSON.stringify(this.itemModel.itemData[this.dataIndex].stopItem.stopItemSerialNumberDetails));
      for (const obj of serialArr) {
        obj.stopitemSerialNumberDetailID = '';
        obj.stopItemSerialNumber = obj.stopItemSerialNumber;
        delete obj.lastUpdateTimestampString;
      }
      if (this.jbhGlobals.utils.findIndex(serialArr, serialObj) === -1) {
        const serialNumArr = this.itemModel.itemData[this.dataIndex].stopItem.stopItemSerialNumberDetails;
        if (!this.jbhGlobals.utils.isArray(serialNumArr)) {
          this.itemModel.itemData[this.dataIndex].stopItem.stopItemSerialNumberDetails = [];
        }
        this.itemModel.itemData[this.dataIndex].stopItem.stopItemSerialNumberDetails.push(serialObj);
        this.itemModel.serialNumberFlag = false;
        this.itemForm['controls']['serialNumber'].setValue('');
        this.itemFormSaveCall(false);
      } else {
        this.jbhGlobals.notifications.error('Error', 'The serial number is already added');
        this.itemModel.serialNumberFlag = true;
        this.itemForm['controls']['serialNumber'].setValue('');
      }
    }
  }
  removeSerialNumber(i: number) {
    this.itemModel.removeSerialNum = true;
    this.itemModel.barCoderemove = false;
    this.itemModel.itemserv = false;
    this.confirmMessage = 'Are you sure you want to delete this Serial Number?';
    this.popInstance.deleteButtonModal.show();
  }
  onDelete(eve) {
    if (eve.flag) {
      if (this.itemModel.removeSerialNum) {
        this.itemModel.itemData[this.dataIndex].stopItem.stopItemSerialNumberDetails.splice(
          this.index, 1);
      } else if (this.itemModel.barCoderemove) {
        const barCodeArray = this.itemModel.itemData[this.dataIndex].stopbarCode;
        barCodeArray.splice([this.dataIndex], 1);
        this.itemModel.itemData[this.dataIndex].stopItem.stopItemBarcodeDetails.splice(this.index, 1);
      } else if (this.itemModel.itemserv) {
        const serviceArray = this.itemModel.itemData[this.dataIndex].stopItem.stopItemServiceDetails;
        serviceArray.splice([this.dataIndex], 1);
      }
      eve.model.hide();
    } else {
      eve.model.hide();
    }
  }
  onClickOfBarCode($event) {
    this.itemModel.barcodeFlag = true;
  }
  onBarCodeSelect(event?: any) {
    let itemBarCodeObj: any;
    if (event) {
      this.itemModel.itemBarCodeType = event;
    }
    const itemBarCodeNumber = (this.itemBarCodeNumber.nativeElement.value) ? this.itemBarCodeNumber.nativeElement.value : '';
    if (this.itemModel.itemBarCodeType.id !== '' && itemBarCodeNumber !== '') {
      this.itemModel.itemData[this.dataIndex].stopbarCode = (this.itemModel.itemData[this.dataIndex].stopbarCode) ?
        this.itemModel.itemData[this.dataIndex].stopbarCode : [];
      itemBarCodeObj = {
        stopItemBarcodeDetail: {
          stopItemBarcodeDetailID: '',
          barcodeTypeCode: this.itemModel.itemBarCodeType.id,
          stopItemBarcodeNumber: itemBarCodeNumber
        },
        barcodeTypeDescription: this.itemModel.itemBarCodeType.text
      };
      const barcodearray = JSON.parse(JSON.stringify(this.itemModel.itemData[this.dataIndex].stopbarCode));
      for (const obj of barcodearray) {
        obj.stopItemBarcodeDetail.stopItemBarcodeDetailID = '';
        delete obj.stopItemBarcodeDetail.lastUpdateTimestampString;
      }
      this.itemModel.barcodeFlag = false;
      if (this.jbhGlobals.utils.findIndex(barcodearray, itemBarCodeObj) === -1) {
        this.itemModel.itemData[this.dataIndex].stopbarCode.push(itemBarCodeObj);
        const barArr = this.itemModel.itemData[this.dataIndex].stopItem.stopItemBarcodeDetails;
        if (!this.jbhGlobals.utils.isArray(barArr)) {
          this.itemModel.itemData[this.dataIndex].stopItem.stopItemBarcodeDetails = [];
        }
        this.itemModel.itemData[this.dataIndex].stopItem.stopItemBarcodeDetails.push(itemBarCodeObj.stopItemBarcodeDetail);
        this.itemModel.barCodeDetails.push(itemBarCodeObj.stopItemBarcodeDetail);
        this.itemBarCodeNumber.nativeElement.value = '';
        this.itemFormSaveCall(false);
      } else {
        this.jbhGlobals.notifications.error('Error', 'The bar code is already added');
      }
      this.itemForm.controls['itemBarCodeType'].setValue('');
      this.itemForm.controls['itemBarCodeNumber'].setValue('');
      // this.itemModel.barcodeFlag = false;
    } else if (this.itemModel.itemBarCodeType.id === '' && itemBarCodeNumber === '') {
      this.jbhGlobals.notifications.error('Error', 'Please enter both barcode Type and Quantity');
    }
  }
  removeBarCode(value: number) {
    this.itemModel.barCoderemove = true;
    this.itemModel.removeSerialNum = false;
    this.itemModel.itemserv = false;
    this.index = value;
    this.confirmMessage = 'Are you sure you want to delete this Bar Code?';
    this.popInstance.deleteButtonModal.show();
    // this.ordersComponent.onDeleteModal(this, ' Are you sure you want to delete this Bar Code?', value);
    // this.servicePopInstance.deleteButtonModal.show();
  }
  onClickOfAdditionalService(event) {
    this.itemModel.serviceFlag = true;
  }
  onSelectOfItemService(itemdesc, quantity, event?: any) {
    let itemServiceObj: any;
    if (event) {
      this.itemModel.itemServiceCode = (event.item.customerServiceTypeCode) ? event.item.customerServiceTypeCode : '';
      this.itemModel.itemServiceDescription = (event.item.serviceDescription) ? event.item.serviceDescription : '';
      this.itemModel.serviceId = (event.item.requestServiceTypeId) ? event.item.requestServiceTypeId : '';
      this.itemForm['controls']['itemService'].setValue(this.itemModel.itemServiceCode + ' ' + this.itemModel.itemServiceDescription);
    }
    if (this.itemModel.itemServiceCode && quantity.value !== '') {
      itemServiceObj = {
        stopItemServiceDetailID: '',
        itemServiceID: this.itemModel.serviceId,
        itemServiceTypeCode: this.itemModel.itemServiceCode,
        itemServiceDescription: this.itemModel.itemServiceDescription,
        itemServiceQuantity: quantity.value
      };
      const serviceArray = this.itemModel.itemData[this.dataIndex].stopItem.stopItemServiceDetails;
      const serviceListarray = JSON.parse(JSON.stringify(serviceArray));
      for (const obj of serviceListarray) {
        obj.stopItemServiceDetailID = '';
        obj.itemServiceQuantity = obj.itemServiceQuantity.toString();
        delete obj.lastUpdateTimestampString;
      }
      if (this.jbhGlobals.utils.findIndex(serviceListarray, itemServiceObj) === -1) {
        if (!this.jbhGlobals.utils.isArray(this.itemModel.itemData[this.dataIndex].stopItem.stopItemServiceDetails)) {
          this.itemModel.itemData[this.dataIndex].stopItem.stopItemServiceDetails = [];
        }
        this.itemModel.itemData[this.dataIndex].stopItem.stopItemServiceDetails.push(itemServiceObj);
        this.itemFormSaveCall(false);
      } else {
        this.jbhGlobals.notifications.error('Error', 'The service is already added');
      }
      this.itemModel.serviceFlag = false;

      itemdesc.value = '';
      this.itemForm['controls']['itemService'].setValue('');
      quantity.value = '';
      this.itemForm['controls']['itemServiceQuantity'].setValue('');
      this.itemModel.itemServiceCode = '';
      this.itemModel.itemServiceDescription = '';
    }
    this.itemModel.standardServiceFlag = true;
  }
  removeItemService(value: number) {
    this.itemModel.removeSerialNum = false;
    this.itemModel.barCoderemove = false;
    this.itemModel.itemserv = true;
    // this.ordersComponent.onDeleteModal(this, ' Are you sure you want to delete this Item Service?', value);
    this.index = value;
    this.confirmMessage = 'Are you sure you want to delete this Item Service?';
    this.popInstance.deleteButtonModal.show();
  }
  onDimensionChange(value) {
    if (value === 'itemDimension') {
      this.itemModel.itemDimensionFlag = true;
      this.itemForm.controls['itemVolume'].setValue('');
      this.itemModel.itemData[this.dataIndex].stopItem.itemVolume = null;
      this.itemModel.itemData[this.dataIndex].stopItem.unitOfVolumeMeasurementCode = null;
      this.setDensityEmpty();
      this.itemModel.validataDimensionFlag = true;
    } else {
      this.itemModel.itemDimensionFlag = false;
      this.itemForm.controls['itemLength'].setValue('');
      this.itemForm.controls['itemWidth'].setValue('');
      this.itemForm.controls['itemHeight'].setValue('');
      this.itemModel.itemData[this.dataIndex].stopItem.itemLength = null;
      this.itemModel.itemData[this.dataIndex].stopItem.itemWidth = null;
      this.itemModel.itemData[this.dataIndex].stopItem.itemHeight = null;
      this.setDensityEmpty();
      this.itemModel.validataDimensionFlag = false;
    }
    this.validateDimension(false);
  }
  onSelectFreightClassCode(event): void {
    this.itemModel.itemData[this.dataIndex].stopItem.freightClassCode = event.id;
    this.itemFormSaveCall(false);
  }
  onItemTypeChange(value) {
    this.itemModel.transSearchFlag = false;
    this.itemModel.saveSearchFlag = false;
    if (value === 'transactionalItem') {
      this.itemModel.showTransDetailIcon = false;
      this.itemModel.transItemFlag = true;
      // this.itemModel.itemData[this.dataIndex].stopItem.stopItemServiceDetails = [];
    } else {
      this.itemModel.showSaveDetailIcon = false;
      this.itemModel.transItemFlag = false;
    }
    this.itemForm.controls['freightClassCode'].setValue([]);
    this.itemForm.controls['itemDescription'].setValue('');
    this.itemModel.typeaheadFlag = false;
    this.itemModel.onSelectTransValue = false;
  }

  onTransValueSelected(event: TypeaheadMatch): void {
    const transItemDesc = event.value ? event.value : '';
    const transItemNumber = event.item.nmfcNumber ? event.item.nmfcNumber : '';
    const freightClass = event.item.nmfcFreightClassification;
    if (event.item.itemDescription) {
      this.itemModel.showTransDetailIcon = true;
      this.itemModel.itemDescriptionNMFC = this.itemModel.itemDescriptionObj;
      this.itemModel.itemDescriptionNMFC['itemDescription'] = transItemDesc;
      this.itemModel.itemDescriptionNMFC['nmfcNumber'] = transItemNumber;
      this.saveItemDescription(transItemDesc, freightClass, this.itemModel.itemDescriptionNMFC);
    }
    this.itemForm['controls']['itemDescription'].setValue(transItemDesc + ' (' + transItemNumber + ')');
    for (let i = 0; i < this.itemModel.freightClassList.length; i++) {
      const freightClassListId = parseInt(this.itemModel.freightClassList[i].id, 10);
      if (freightClassListId === freightClass) {
        this.itemForm['controls']['freightClassCode'].setValue([{ 'id': freightClass, 'text': this.itemModel.freightClassList[i].text }]);
      }
    }
    this.itemModel.typeaheadFlag = true;
    this.itemModel.onSelectTransValue = true;
    this.itemModel.transSearchFlag = false;
    this.itemFormSaveCall(false);
  }
  itemDesNoMatchFound(event: TypeaheadMatch): void {
    this.itemModel.transSearchFlag = event ? true : false;
    this.itemModel.saveSearchFlag = event ? true : false;
    this.itemModel.showTransDetailIcon = false;
    this.itemModel.showSaveDetailIcon = false;
    this.itemModel.onSelectTransValue = false;
    this.itemForm['controls']['freightClassCode'].setValue([{ 'id': '', 'text': 'Freight Class' }]);
  }
  onSavedItemValueSelected(event: TypeaheadMatch): void {
    const savedItemDesc = event.value ? event.value : '';
    const savedModelNumber = event.item.modelNumber ? event.item.modelNumber : '';
    const freightClass = event.item.nmfcFreightClassification;
    if (!this.jbhGlobals.utils.isEmpty(savedItemDesc)) {
      this.itemModel.showSaveDetailIcon = true;
      this.getSavedItemListService(event, savedItemDesc, savedModelNumber, freightClass, true);
    }
    if (savedModelNumber !== null && this.itemModel.dcsFlag === true) {
      this.loadItemService(savedModelNumber);
    } else {
      this.itemModel.standardServicesList = [];
      this.itemModel.itemServiceList = [];
    }
    this.itemForm['controls']['itemDescription'].setValue(savedItemDesc + ' (' + savedModelNumber + ')');
    for (let i = 0; i < this.itemModel.freightClassList.length; i++) {
      const freightClassListId = parseInt(this.itemModel.freightClassList[i].id, 10);
      if (freightClassListId === freightClass) {
        this.itemForm['controls']['freightClassCode'].setValue([{ 'id': freightClass, 'text': this.itemModel.freightClassList[i].text }]);
      }
    }
    this.itemModel.typeaheadFlag = true;
    this.itemModel.onSelectTransValue = true;
    this.itemModel.saveSearchFlag = false;
    // if (this.itemModel.itemData[this.dataIndex].stopItem.itemDescription &&
    //   savedItemDesc === this.itemModel.itemData[this.dataIndex].stopItem.itemDescription) {
    //   this.itemFormSaveCall(false);
    // }
  }
  getSavedItemListService(event, savedItemDesc, savedModelNumber, freightClass, flag) {
    const sku = (!this.jbhGlobals.utils.isEmpty(event.item.sku)) ? event.item.sku : '',
      supplierSKU = (!this.jbhGlobals.utils.isEmpty(event.item.supplierSKU)) ? event.item.supplierSKU : '',
      productCategory = (!this.jbhGlobals.utils.isEmpty(event.item.itemCategory)) ? event.item.itemCategory : '';
    savedItemDesc = (!this.jbhGlobals.utils.isEmpty(savedItemDesc)) ? savedItemDesc : '';
    savedModelNumber = (!this.jbhGlobals.utils.isEmpty(savedModelNumber)) ? savedModelNumber : '';
    const params = {
      'modelNumber': savedModelNumber,
      'sku': sku,
      'supplierSKU': supplierSKU,
      'productCategory': productCategory,
      'productDescription': savedItemDesc
    };
    const url = this.jbhGlobals.endpoints.order.getSaveItemDetails;
    this.itemService.getSavedItemListService(url, params).subscribe(data => {
      if (flag) {
        this.itemModel.itemDescriptionSaved = data[0];
        this.saveItemDescription(savedItemDesc, freightClass, this.itemModel.itemDescriptionSaved);
        this.dataPopulation(this.itemForm['controls'], this.itemModel.itemDescriptionSaved);
        if (this.itemModel.itemData[this.dataIndex].stopItem.itemDescription &&
          savedItemDesc === this.itemModel.itemData[this.dataIndex].stopItem.itemDescription) {
          this.itemFormSaveCall(false);
        }
      } else {
        this.itemModel.popUpItemDescriptionNMFC = data[0];
        if (this.itemModel.popUpItemDescriptionNMFC) {
          this.itemModel.popUpItemDescriptionNMFC['freightClass'] = freightClass;
          this.dataPopulation(this.itemForm['controls'], this.itemModel.popUpItemDescriptionNMFC);
          this.itemForm['controls']['popupItemDescription'].setValue(savedItemDesc + ' (' + savedModelNumber + ')');
        }
      }
    });
  }

  saveItemDescription(transItemDesc, freightClass, itemdesc) {
    for (let i = 0; i < this.itemModel.editItemArray.length; i++) {
      const editObj = itemdesc[this.itemModel.editItemObjArray[i]] ? itemdesc[this.itemModel.editItemObjArray[i]] : '';
      this.itemModel.itemData[this.dataIndex]['stopItem'][this.itemModel.editItemArray[i]] = editObj;
    }
    this.itemModel.itemData[this.dataIndex].stopItem.itemDescription = transItemDesc;
    this.itemModel.itemData[this.dataIndex].stopItem.freightClassCode = freightClass + '';
  }

  onPopUpItemDescValueSelected(event) {
    const transItemDesc = event.item.itemDescription ? event.item.itemDescription : '';
    const transItemNumber = event.item.nmfcNumber ? event.item.nmfcNumber : '';
    const savedModelNumber = event.item.modelNumber;
    const freightClass = event.item.nmfcFreightClassification;
    if (event.item.itemDescription) {
      if (this.itemModel.itemPopupHeading === 'Transactional Item') {
        this.itemModel.itemDescriptionNMFC['freightClass'] = freightClass;
        this.itemModel.itemDescriptionNMFC['nmfcNumber'] = transItemNumber;
        this.dataPopulation(this.itemForm['controls'], this.itemModel.itemDescriptionNMFC);
        this.itemForm['controls']['popupItemDescription'].setValue(transItemDesc + ' (' + transItemNumber + ')');
      } else {
        this.getSavedItemListService(event, transItemDesc, savedModelNumber, freightClass, false);
      }
    }
    this.itemModel.onSelectPopupValue = true;
  }

  onNMFCSelected(event) {
    const transItemDesc = event.item.itemDescription ? event.item.itemDescription : '';
    const transItemNumber = event.item.nmfcNumber ? event.item.nmfcNumber : '';
    const freightClass = event.item.nmfcFreightClassification;
    if (event.item.itemDescription) {
      this.itemModel.itemDescriptionNMFC['freightClass'] = freightClass;
      this.itemModel.itemDescriptionNMFC['nmfcNumber'] = transItemNumber;
      this.dataPopulation(this.itemForm['controls'], this.itemModel.itemDescriptionNMFC);
      this.itemForm['controls']['popupItemDescription'].setValue(transItemDesc + ' (' + transItemNumber + ')');
      this.itemModel.transSearchFlag = false;
      this.itemModel.saveSearchFlag = false;
    }
    this.itemForm['controls']['nmfcNumber'].setValue((transItemNumber ? transItemNumber : ''));
    this.itemModel.onSelectPopupNmfcValue = true;
  }
  onEditItemClick(itemPopup, transItem) {
    this.pop.hide();
    itemPopup.show();
    this.itemModel.popupFlag = true;
    this.itemModel.itemPopupButton = 'Save';
    this.itemForm['controls']['popupItemDescription'].setValidators([Validators.required]);
    this.itemForm['controls']['popupItemDescription'].updateValueAndValidity();
    if (transItem.name === 'editTransItem') {
      this.itemModel.itemPopupHeading = 'Transactional Item';
      this.itemModel.transEditFlag = true;
      this.itemModel.transPopCloseFlag = false;
      this.itemModel.transSearchFlag = false;
      this.dataPopulation(this.itemForm['controls'], this.itemModel.itemDescriptionNMFC);
    } else {
      this.itemModel.itemPopupHeading = 'Saved Item';
      this.itemModel.transTypeaheadList = this.itemModel.saveItemList;
      this.itemModel.saveEditFlag = true;
      this.itemModel.savedPopCloseFlag = false;
      this.itemModel.saveSearchFlag = false;
      this.dataPopulation(this.itemForm['controls'], this.itemModel.itemDescriptionSaved);
    }
  }

  dataPopulation(form, itemDesc) {
    form['popupItemDescription'].setValue(itemDesc['itemDescription'] ? itemDesc['itemDescription'] : '');
    const len = this.itemModel.editItemArray.length;
    for (let i = 0; i < len; i++) {
      const editArr = itemDesc[this.itemModel.editItemObjArray[i]] ? itemDesc[this.itemModel.editItemObjArray[i]] : '';
      form[this.itemModel.editItemArray[i]].setValue(editArr);
    }
    if (itemDesc['itemClassification'] === 'MAJOR') {
      this.majorRadio.nativeElement.checked = true;
    }
    if (itemDesc['itemClassification'] === 'MINOR') {
      this.minorRadio.nativeElement.checked = true;
    }
    if (itemDesc['itemClassification'] === '') {
      this.majorRadio.nativeElement.checked = false;
      this.minorRadio.nativeElement.checked = false;
    }
    this.itemModel.onSelectPopupValue = itemDesc['itemDescription'] ? true : false;
    this.itemModel.onSelectPopupNmfcValue = itemDesc['nmfcNumber'] ? true : false;
  }

  onEditClick(popup) {
    let itemDescObj = {};
    let validFlag = true;
    if (this.itemModel.transEditFlag) {
      itemDescObj = this.itemModel.itemDescriptionNMFC;
      this.itemModel.transSearchFlag = false;
    } else {
      itemDescObj = this.itemModel.itemDescriptionSaved;
      this.itemModel.saveSearchFlag = false;
    }
    this.itemForm['controls']['itemDescription'].setValue(this.itemForm['controls']['popupItemDescription'].value);
    if (this.itemModel.popUpItemDescriptionNMFC) {
      for (let i = 0; i < this.itemModel.freightClassList.length; i++) {
        const freightClassListId = parseInt(this.itemModel.freightClassList[i].id, 10);
        const freightClass = this.itemModel.popUpItemDescriptionNMFC.freightClass;
        if (freightClassListId === freightClass) {
          this.itemForm['controls']['freightClassCode'].setValue([{ 'id': freightClass, 'text': this.itemModel.freightClassList[i].text }]);
        }
      }
    }
    itemDescObj['itemDescription'] = this.itemForm['controls']['itemDescription'].value ?
      this.itemForm['controls']['itemDescription'].value : '';
    if (this.majorRadio.nativeElement.checked === true) {
      this.itemForm['controls']['itemClassificationCode'].setValue('MAJOR');
    }
    if (this.minorRadio.nativeElement.checked === true) {
      this.itemForm['controls']['itemClassificationCode'].setValue('MINOR');
    }
    for (let i = 0; i < this.itemModel.editItemObjArray.length; i++) {
      if (this.itemForm['controls'][this.itemModel.editItemArray[i]].valid) {
        const editArr = this.itemForm['controls'][this.itemModel.editItemArray[i]].value ?
          this.itemForm['controls'][this.itemModel.editItemArray[i]].value : '';
        itemDescObj[this.itemModel.editItemObjArray[i]] = editArr;
      } else {
        this.itemForm['controls'][this.itemModel.editItemArray[i]].markAsTouched();
        validFlag = false;
      }
    }
    if (this.itemModel.transEditFlag) {
      this.itemModel.itemDescriptionNMFC = itemDescObj;
      this.itemModel.showTransDetailIcon = true;
    } else {
      this.itemModel.itemDescriptionSaved = itemDescObj;
      this.itemModel.showSaveDetailIcon = true;
    }
    const itemDesc = this.jbhGlobals.utils.split(this.itemForm['controls']['itemDescription'].value.toString(), '(')[0];
    if (validFlag && this.itemForm['controls']['itemDescription'].valid) {
      const freightClass = (this.itemForm['controls']['freightClassCode'].value &&
        this.itemForm['controls']['freightClassCode'].value.length > 0) ?
        this.itemForm['controls']['freightClassCode'].value[0].id : null;
      this.saveItemDescription(itemDesc, freightClass, itemDescObj);
      this.itemModel.popupFlag = false;
      this.itemModel.onSelectTransValue = true;
      this.itemDiv.nativeElement.focus();
      popup.hide();
      this.itemForm['controls']['popupItemDescription'].setValidators([]);
      this.itemForm['controls']['popupItemDescription'].updateValueAndValidity();
    }
    if (itemDescObj['modelNumber']) {
      if (itemDescObj['itemManufacturer']) {
        this.findModelNumber(itemDescObj['modelNumber'], itemDescObj['itemManufacturer']);
      }
      this.loadItemService(itemDescObj['modelNumber']);
    }
    if (validFlag && this.itemForm['controls']['itemDescription'].valid) {
      this.itemFormSaveCall(false);
    }
  }

  onAddNewItemClick(itemPopup, itemType) {
    this.itemForm['controls']['popupItemDescription'].setValidators([Validators.maxLength(500), Validators.required]);
    this.itemForm['controls']['itemDescription'].setValidators([Validators.maxLength(500), Validators.required]);
    itemPopup.show();
    this.itemModel.itemPopupButton = 'Add';
    const itemdescobj = {
      'itemMake': '',
      'upc': '',
      'itemManufacturer': '',
      'modelNumber': '',
      'sku': '',
      'supplierSKU': '',
      'itemCategory': '',
      'itemClassification': '',
      'itemDescription': '',
      'nmfcNumber': '',
      'itemPartNumber': ''
    };
    itemdescobj['itemDescription'] = this.itemForm['controls']['itemDescription'].value;
    if (itemType.name === 'addNewTransItem') {
      this.itemModel.itemPopupHeading = 'Transactional Item';
      this.itemModel.transEditFlag = true;
      this.itemModel.itemDescriptionNMFC = itemdescobj;
    } else {
      this.itemModel.itemPopupHeading = 'Saved Item';
      this.itemModel.saveEditFlag = true;
      this.itemModel.itemDescriptionSaved = itemdescobj;
    }
    this.dataPopulation(this.itemForm['controls'], itemdescobj);
  }

  onCloseOfItemPopup(itemPopup) {
    itemPopup.hide();
    this.itemModel.showTransDetailIcon = true;
    this.itemModel.showSaveDetailIcon = true;
    if (this.itemModel.itemPopupHeading === 'Transactional Item') {
      this.itemModel.transPopCloseFlag = true;
    } else {
      this.itemModel.savedPopCloseFlag = true;
    }
  }

  onPopupOutsideClose() {
    if (this.itemModel.itemDescriptionNMFC || this.itemModel.itemDescriptionSaved) {
      let itemDescObj;
      if (this.itemModel.itemPopupHeading === 'Transactional Item') {
        itemDescObj = this.itemModel.itemDescriptionNMFC;
        this.itemModel.transPopCloseFlag = true;
      } else {
        itemDescObj = this.itemModel.itemDescriptionSaved;
        this.itemModel.savedPopCloseFlag = true;
      }
      for (let i = 0; i < this.itemModel.editItemArray.length; i++) {
        this.itemForm['controls'][this.itemModel.editItemArray[i]].setValue(itemDescObj[this.itemModel.editItemObjArray[i]]);
      }
    }
  }

  findModelNumber(modelValue, manufacturerValue) {
    const url = this.jbhGlobals.endpoints.order.checkModelNumber;
    const params = {
      'modelNumber': modelValue,
      'manufacturer': manufacturerValue,
      'lob': 'TKLT'
    };
    this.itemService.getModelNumber(url, params).subscribe(data => {
      this.itemModel.newModelNumberFlag = data;
      if (this.itemModel.newModelNumberFlag) {
        this.validateModelNumber();
      }
    });
  }

  validateModelNumber() {
    if (this.itemModel.newModelNumberFlag) {
      this.itemForm['controls']['itemManufacturer'].setValidators([Validators.required]);
      this.itemForm['controls']['itemManufacturer'].updateValueAndValidity();
      this.itemModel.validataDimensionFlag = (this.itemModel.itemDimensionFlag) ? true : false;
      this.validateDimension(true);
    } else {
      this.itemForm['controls']['itemManufacturer'].setValidators([]);
      this.itemForm['controls']['itemManufacturer'].updateValueAndValidity();
      this.itemModel.validataDimensionFlag = false;
      this.validateDimension(true);
    }
  }
  onItemCharacteristicSelection(event, flag) {
    const itemCharacteristics = event.text;
    switch (itemCharacteristics) {
      case 'Temperature Control':
        this.itemModel.showTemperature = flag;
        if (!flag) {
          this.itemModel.itemData[this.dataIndex].stopItem.itemTemperatureControlMethodCode = '';
        }
        this.itemForm['controls']['itemTemperatureControlMethodCode'].setValue('');
        break;
      case 'Hazmat':
        this.itemModel.showHazmat = flag;
        if (!flag) {
          this.itemModel.itemData[this.dataIndex].stopItem.stopItemHazardousMaterialDetails = [];
          /* empty the hazmat data */
        }
        // this.itemFormSaveCall(false);
        break;
      case 'Freeze Protect':
        if (flag) {
          this.itemModel.itemData[this.dataIndex].stopItem.itemProtectionType = 'Freeze';
        } else {
          this.itemModel.itemData[this.dataIndex].stopItem.itemProtectionType = null;
        }
        // this.itemFormSaveCall(false);
        break;
      case 'Stackable':
        if (flag) {
          this.itemModel.itemData[this.dataIndex].stopItem.itemStackingType = 'Stackable';
        } else {
          this.itemModel.itemData[this.dataIndex].stopItem.itemStackingType = null;
        }
        // this.itemFormSaveCall(false);
        break;
      case 'Extreme Length':
        if (flag) {
          this.itemModel.itemData[this.dataIndex].stopItem.itemLengthType = 'Extreme Length';
        } else {
          this.itemModel.itemData[this.dataIndex].stopItem.itemLengthType = null;
        }
        this.checkExtremeLength();
        break;
      default:
        break;
    }
  }
  calculateVolume() {
    const itemLength = this.itemForm.value.itemLength;
    const itemWidth = this.itemForm.value.itemWidth;
    const itemHeigth = this.itemForm.value.itemHeight;
    const itemUnit = this.itemForm.value.unitOfLengthMeasurementCode;
    if (itemLength && itemWidth && itemHeigth && !this.jbhGlobals.utils.isEmpty(itemUnit)) {
      const length = this.getstopHandlingComponent().conversionToInches(itemLength, itemUnit);
      const width = this.getstopHandlingComponent().conversionToInches(itemWidth, itemUnit);
      const height = this.getstopHandlingComponent().conversionToInches(itemHeigth, itemUnit);
      const volume = (length * width * height) / (12 * 12 * 12);
      const val = this.validateDimensionAndVolume(volume);
      if (val) {
        this.itemModel.volumeVal = parseFloat(val.toFixed(4));
        this.itemModel.volMeasureFlag = true;
        this.itemForm['controls']['itemVolume'].setValue(parseFloat(volume.toFixed(4)));
        this.itemForm['controls']['unitOfVolumeMeasurementCode'].setValue('Cubic CM');
        this.itemModel.itemData[this.dataIndex].stopItem.itemVolume = parseFloat(volume.toFixed(4));
        this.itemModel.itemData[this.dataIndex].stopItem.unitOfVolumeMeasurementCode = 'Cubic CM';
      }
    } else {
      this.itemForm['controls']['itemVolume'].setValue('');
      this.itemForm['controls']['unitOfVolumeMeasurementCode'].setValue('');
      this.itemModel.itemData[this.dataIndex].stopItem.itemVolume = null;
      this.itemModel.itemData[this.dataIndex].stopItem.unitOfVolumeMeasurementCode = null;
    }
  }
  calculateDensity() {
    const itemLength = this.itemForm.value.itemLength;
    const itemWidth = this.itemForm.value.itemWidth;
    const itemHeigth = this.itemForm.value.itemHeight;
    const itemUnit = this.itemForm.value.unitOfLengthMeasurementCode;
    const itemWeight = this.itemForm.value.itemWeight;
    const itemWeightUnit = this.itemForm.value.unitOfWeightMeasurementCode;
    if (itemLength && itemWidth && itemHeigth && !this.jbhGlobals.utils.isEmpty(itemUnit) &&
      itemWeight && !this.jbhGlobals.utils.isEmpty(itemWeightUnit)) {
      const length = this.getstopHandlingComponent().conversionToFeet(itemLength, itemUnit);
      const width = this.getstopHandlingComponent().conversionToFeet(itemWidth, itemUnit);
      const height = this.getstopHandlingComponent().conversionToFeet(itemHeigth, itemUnit);
      const weight = this.getstopHandlingComponent().weightConversion(itemWeight, itemWeightUnit);
      const density = weight / (length * width * height);
      const denVal = this.validateDimensionAndVolume(density);
      if (denVal) {
        this.itemModel.itemDensity = density.toFixed(4);
        this.setDenityVal(density.toFixed(4));
      }
    } else {
      this.setDensityEmpty();
      this.itemModel.itemDensity = '';
    }
  }
  checkExtremeLength() {
    const length = this.itemForm.value.itemLength;
    const lengthUnit = this.itemForm.value.unitOfLengthMeasurementCode;
    const extremeVal = this.itemModel.itemData[this.dataIndex].stopItem.itemLengthType;
    if (this.itemModel.icsLTLFlag && length && !this.jbhGlobals.utils.isEmpty(lengthUnit)) {
      const itemLength = this.getstopHandlingComponent().conversionToInches(length, lengthUnit);
      if (this.jbhGlobals.utils.isEmpty(extremeVal) && itemLength > parseFloat(this.itemModel.extremeLength)) {
        this.jbhGlobals.notifications.alert('Warning', 'Length has exceeded 14inch');
        this.itemModel.itemData[this.dataIndex].stopItem.itemLengthType = 'Extreme Length';
        if (this.itemCharacteristicsTag.active.indexOf({
          id: 'Extreme Length',
          text: 'Extreme Length'
        }) === -1) {
          this.itemCharacteristicsTag.active.push({
            id: 'Extreme Length',
            text: 'Extreme Length'
          });
        }
      }
      if (itemLength > 10.8 && itemLength < parseFloat(this.itemModel.extremeLength)) {
        this.jbhGlobals.notifications.alert('Warning', 'Length has exceeded 10.8 Inches');
      }
    }
    // this.itemFormSaveCall(false);
  }

  calculateVolumeConversion() {
    const volume = this.itemForm.value.itemVolume;
    const weight = this.itemForm.value.itemWeight;
    const weightUnit = this.itemForm.value.unitOfWeightMeasurementCode;
    if (volume && weight && !this.jbhGlobals.utils.isEmpty(weightUnit)) {
      const weightConv = this.getstopHandlingComponent().weightConversion(weight, weightUnit);
      const density = weightConv / volume * (12 * 12 * 12);
      const denVal = this.validateDimensionAndVolume(density);
      if (denVal) {
        this.itemModel.itemDenistyVal = density.toFixed(4);
        this.setDenityVal(denVal.toFixed(4));
      }
    } else {
      this.itemModel.itemDenistyVal = '';
      this.setDensityEmpty();
    }
  }

  validateDimension(flag: boolean) {
    const arr = ['itemLength', 'itemWidth', 'itemHeight', 'unitOfLengthMeasurementCode'];
    if (flag) {
      if (this.itemModel.validataDimensionFlag) {
        for (let i = 0; i < arr.length; i++) {
          this.itemForm['controls'][arr[i]].setValidators(arr[i] !== 'unitOfLengthMeasurementCode' ?
            [Validators.required, this.jbhGlobals.customValidator.stopMeasurement,
            this.jbhGlobals.customValidator.decimalNumber] : [Validators.required]);
          this.itemForm['controls'][arr[i]].updateValueAndValidity();
        }
        this.itemForm['controls']['itemVolume'].setValidators([this.jbhGlobals.customValidator.stopMeasurement,
        this.jbhGlobals.customValidator.decimalNumber]);
        this.itemForm['controls']['itemVolume'].updateValueAndValidity();
      } else {
        for (let i = 0; i < arr.length; i++) {
          this.itemForm['controls'][arr[i]].setValidators(arr[i] !== 'unitOfLengthMeasurementCode' ?
            [this.jbhGlobals.customValidator.stopMeasurement, this.jbhGlobals.customValidator.decimalNumber] : []);
          this.itemForm['controls'][arr[i]].updateValueAndValidity();
        }
        this.itemForm['controls']['itemVolume'].setValidators([Validators.required, this.jbhGlobals.customValidator.stopMeasurement,
        this.jbhGlobals.customValidator.decimalNumber]);
        this.itemForm['controls']['itemVolume'].updateValueAndValidity();
      }
    } else {
      for (let i = 0; i < arr.length; i++) {
        this.itemForm['controls'][arr[i]].setValidators(arr[i] !== 'unitOfLengthMeasurementCode' ?
          [this.jbhGlobals.customValidator.stopMeasurement,
          this.jbhGlobals.customValidator.decimalNumber] : []);
        this.itemForm['controls'][arr[i]].updateValueAndValidity();
      }
      this.itemForm['controls']['itemVolume'].setValidators([this.jbhGlobals.customValidator.stopMeasurement,
      this.jbhGlobals.customValidator.decimalNumber]);
      this.itemForm['controls']['itemVolume'].updateValueAndValidity();
    }
  }
  setDenityVal(density) {
    this.itemModel.denMeasureFlag = true;
    this.itemForm['controls']['itemDensity'].setValue(parseFloat(density));
    this.itemForm['controls']['unitOfDensityMeasurementCode'].setValue('GM/CC');
    this.itemModel.itemData[this.dataIndex].stopItem.itemDensity = parseFloat(density);
    this.itemModel.itemData[this.dataIndex].stopItem.unitOfDensityMeasurementCode = 'GM/CC';
  }
  setDensityEmpty() {
    this.itemModel.denMeasureFlag = false;
    this.itemForm['controls']['unitOfDensityMeasurementCode'].setValue('');
    this.itemForm['controls']['itemDensity'].setValue('');
    this.itemModel.itemData[this.dataIndex].stopItem.unitOfDensityMeasurementCode = null;
    this.itemModel.itemData[this.dataIndex].stopItem.itemDensity = null;
  }
  populateItem(itemDataPopulation) {
    // this.itemModel.transItemFlag = (this.itemModel.icsLTLFlag || this.itemModel.dcsFlag) ? false : true;
    this.setItemCharacteristics(itemDataPopulation);
    const form = this.itemForm['controls'];
    this.itemForm.patchValue(itemDataPopulation);
    this.loadPackage(itemDataPopulation.packagingUnitTypeCode);
    const itemDesc = {
      'itemMake': itemDataPopulation.itemMake,
      'upc': itemDataPopulation.itemUniversalProductCode,
      'itemManufacturer': itemDataPopulation.itemManufacturer,
      'modelNumber': itemDataPopulation.itemModelNumber,
      'sku': itemDataPopulation.skuNumber,
      'supplierSKU': itemDataPopulation.supplierSKU,
      'itemCategory': itemDataPopulation.itemCategory,
      'itemClassification': itemDataPopulation.itemClassificationCode,
      'itemDescription': itemDataPopulation.itemDescription,
      'nmfcNumber': itemDataPopulation.nmfcNumber,
      'itemPartNumber': itemDataPopulation.itemPartNumber
    };
    if (itemDataPopulation.itemVolume && !this.jbhGlobals.utils.isEmpty(itemDataPopulation.unitOfVolumeMeasurementCode)
      && !itemDataPopulation.itemLength && !itemDataPopulation.itemWidth && !itemDataPopulation.itemHeight) {
      this.itemModel.itemDimensionFlag = false;
      this.itemModel.itemVolumeVal = form.itemVolume.value;
      this.itemModel.volMeasureFlag = true;
      if (itemDataPopulation.itemWeight && !this.jbhGlobals.utils.isEmpty(itemDataPopulation.unitOfWeightMeasurementCode)) {
        this.itemModel.itemDenistyVal = form.itemDensity.value;
        this.itemModel.denMeasureFlag = true;
      }
    } else {
      this.itemModel.itemDimensionFlag = true;
      this.itemModel.itemVolumeVal = '';
      this.itemModel.itemDenistyVal = '';
    }

    if (itemDataPopulation.itemLength && itemDataPopulation.itemWidth && itemDataPopulation.itemHeight
      && !this.jbhGlobals.utils.isEmpty(itemDataPopulation.unitOfLengthMeasurementCode) && itemDataPopulation.itemVolume
      && !this.jbhGlobals.utils.isEmpty(itemDataPopulation.unitOfVolumeMeasurementCode)) {
      this.itemModel.volumeVal = form.itemVolume.value;
      this.itemModel.volMeasureFlag = true;
      if (itemDataPopulation.itemWeight && !this.jbhGlobals.utils.isEmpty(itemDataPopulation.unitOfWeightMeasurementCode)) {
        this.itemModel.itemDensity = form.itemDensity.value;
        this.itemModel.denMeasureFlag = true;
      }
    } else {
      this.itemModel.volumeVal = '';
      this.itemModel.itemDensity = '';
    }
    if (itemDataPopulation && itemDataPopulation.itemDescription && this.isCurrViewTemplate) {
      this.itemModel.onSelectTransValue = true;
    }
    if (this.itemModel.transItemFlag) {
      form.itemDescription.setValue((itemDataPopulation.itemDescription ? itemDataPopulation.itemDescription : '') +
        (itemDataPopulation.nmfcNumber ? '(' + itemDataPopulation.nmfcNumber + ')' : ''));
      this.itemModel.transEditFlag = true;
      this.itemModel.showTransDetailIcon = true;
      this.itemModel.itemDescriptionNMFC = itemDesc;
    } else {
      form.itemDescription.setValue((itemDataPopulation.itemDescription ? itemDataPopulation.itemDescription : '') +
        + (itemDataPopulation.itemModelNumber ? ' ( ' + itemDataPopulation.itemModelNumber + ' ) ' : ''));
      this.itemModel.saveEditFlag = true;
      this.itemModel.showSaveDetailIcon = true;
      this.itemModel.itemDescriptionSaved = itemDesc;
    }
    if (itemDesc.modelNumber) {
      this.loadItemService(itemDesc.modelNumber);
    }
    if (itemDataPopulation.freightClassCode) {
      for (let i = 0; i < this.itemModel.freightClassList.length; i++) {
        const freightClassListId = parseInt(this.itemModel.freightClassList[i].id, 10);
        if (freightClassListId === itemDataPopulation.freightClassCode) {
          this.itemForm['controls']['freightClassCode'].setValue([{
            'id': itemDataPopulation.freightClassCode,
            'text': this.itemModel.freightClassList[i].text
          }]);
        }
      }
    }
    this.itemModel.saveItemFlag = true;
  }

  setItemCharacteristics(itemDataPopulation) {
    this.itemCharacteristicsTag.active = [];
    if (itemDataPopulation.itemLengthType === 'Extreme Length') {
      if (this.jbhGlobals.utils.findIndex(this.itemCharacteristicsTag.active,
        { id: 'Extreme Length', text: 'Extreme Length' }) === -1) {
        this.itemCharacteristicsTag.active.push({ id: 'Extreme Length', text: 'Extreme Length' });
      }
    }
    if (itemDataPopulation.itemProtectionType === 'Freeze') {
      if (this.jbhGlobals.utils.findIndex(this.itemCharacteristicsTag.active,
        { id: 'Freeze Protect', text: 'Freeze Protect' }) === -1) {
        this.itemCharacteristicsTag.active.push({ id: 'Freeze Protect', text: 'Freeze Protect' });
      }
    }
    if (itemDataPopulation.itemStackingType === 'Stackable') {
      if (this.jbhGlobals.utils.findIndex(this.itemCharacteristicsTag.active, { id: 'Stackable', text: 'Stackable' }) === -1) {
        this.itemCharacteristicsTag.active.push({ id: 'Stackable', text: 'Stackable' });
      }
    }
    if (itemDataPopulation.itemTemperatureControlMethodCode && itemDataPopulation.itemTemperatureControlMethodCode.length > 0) {
      if (this.jbhGlobals.utils.findIndex(this.itemCharacteristicsTag.active,
        { id: 'Temperature Control', text: 'Temperature Control' }) === -1) {
        this.itemCharacteristicsTag.active.push({ id: 'Temperature Control', text: 'Temperature Control' });
        const tempMethod = this.itemModel.itemData[this.dataIndex].stopItem.itemTemperatureControlMethodCode;
        this.itemModel.showTemperature = true;
        this.itemForm['controls']['itemTemperatureControlMethodCode'].setValue(tempMethod);
      }
    }

    if (this.itemModel.itemData[this.dataIndex].stopItem.stopItemHazardousMaterialDetails.length > 0) {
      if (this.jbhGlobals.utils.findIndex(this.itemCharacteristicsTag.active, { id: 'Hazmat', text: 'Hazmat' }) === -1) {
        this.itemCharacteristicsTag.active.push({ id: 'Hazmat', text: 'Hazmat' });
        this.itemModel.showHazmat = true;
      }
    }
    this.itemModel.saveItemFlag = true;
  }
  validateCubicCapacity(form) {
    const density = form['itemDensity'];
    const volume = form['itemVolume'];
    const length = form['itemLength'];
    const unitLength = form['unitOfVolumeMeasurementCode'];
    let lengthVal: any;
    if (length && !this.jbhGlobals.utils.isEmpty(unitLength)) {
      lengthVal = this.getstopHandlingComponent().conversionToFeet(length, unitLength);
    }
    if (density && volume && lengthVal) {
      if (density < 6 && volume > 750 && lengthVal > 13) {
        form['itemVolumeType'] = 'Cubic Capacity';
      }
    } else {
      form['itemVolumeType'] = '';
    }
  }
  validateDimensionAndVolume(value): any {
    const val = this.jbhGlobals.utils.floor(value);
    const valLength = val.toString().length;
    if (!isNaN(value) && valLength < 8) {
      return value;
    } else {
      this.setDimensionandVolumeEmpty();
      this.jbhGlobals.notifications.error('Error', 'Please enter proper value for Dimesion or Volume');
      return null;
    }
  }
  setDimensionandVolumeEmpty() {
    if (this.itemModel.itemDimensionFlag) {
      this.itemForm['controls']['itemLength'].setValue('');
      this.itemForm['controls']['itemWidth'].setValue('');
      this.itemForm['controls']['itemHeight'].setValue('');
      this.itemForm['controls']['itemWeight'].setValue('');
      this.itemForm['controls']['unitOfVolumeMeasurementCode'].setValue('');
      this.itemForm['controls']['itemVolume'].setValue('');
      this.setDensityEmpty();
    } else {
      this.itemForm['controls']['itemWeight'].setValue('');
      this.itemForm['controls']['itemVolume'].setValue('');
      this.itemForm['controls']['unitOfVolumeMeasurementCode'].setValue('');
      this.setDensityEmpty();
    }
  }
  enterToClick(event) {
    if (event.keyCode === 13) {
      event.currentTarget.click();
    }
  }
}
