import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Response } from '@angular/http';

import { JBHGlobals } from '../../../../../../app.service';

@Injectable()
export class ReferencesService {

  constructor(private jbhGlobals: JBHGlobals) {}

  loadReferences(commentsUrl): Observable < Response[] > {
    return this.jbhGlobals.apiService
      .getData(commentsUrl);
  }
  getAllReference(commentsUrl): Observable < Response[] > {
    return this.jbhGlobals.apiService
      .getData(commentsUrl);
  }
  getReferencesTypeAndValue(commentsUrl, urlLength): Observable < Response[] > {
    return this.jbhGlobals.apiService
      .getData(commentsUrl, urlLength);
  }
  getParentReferences(commentsUrl): Observable < Response[] > {
    return this.jbhGlobals.apiService
      .getData(commentsUrl);
  }
  SaveReference(commentsUrl, params): Observable < Response[] > {
    return this.jbhGlobals.apiService
      .addData(commentsUrl, params);
  }
  saveStopReferences(commentsUrl, params): Observable < Response[] > {
    return this.jbhGlobals.apiService
      .addData(commentsUrl, params);
  }
  updateReference(commentsUrl, params): Observable < Response[] > {
    return this.jbhGlobals.apiService
      .updateData(commentsUrl, params);
  }
  deleteReference(commentDeleteUrl): Observable < Response[] > {
    return this.jbhGlobals.apiService
      .removeData(commentDeleteUrl);
  }
  deleteStopReference(commentDeleteUrl, params): Observable < Response[] > {
    return this.jbhGlobals.apiService
      .removeData(commentDeleteUrl, params);
  }

}
