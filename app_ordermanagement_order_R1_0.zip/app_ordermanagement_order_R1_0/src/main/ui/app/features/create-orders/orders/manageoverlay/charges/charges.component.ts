import {
    ChargesService
} from './services/charges.service';
import {
    Component,
    Input,
    OnInit,
    ViewChild
} from '@angular/core';
import {
    JBHGlobals
} from '../../../../../app.service';
import {
    OrderService
} from './../../services/order.service';
import {
    ChargesModel
} from './models/charges.model';
import {
    FormBuilder,
    FormGroup,
    Validators
} from '@angular/forms';
import {
    StopSharedDataService
} from '../../../orders/add-stops/services/stop-shared-data.service';
import {
    ViewOrderService
} from '../../../../view-order/services/view-order.service';
import {
    Router
} from '@angular/router';
import {
    ActivatedRoute
} from '@angular/router';

@Component({
    selector: 'app-charges',
    providers: [ChargesService],
    templateUrl: './charges.component.html',
    styleUrls: ['./charges.component.scss', '../comments/comments.component.scss']
})

export class ChargesComponent implements OnInit {
    // tslint:disable:member-access
    chargesModel: ChargesModel;
    chargeDtoDetails: FormGroup;
    chargeDuplicate: any = [];
    @Input() totCharges: number;
    @ViewChild('popInstance') popInstance: any;
    @ViewChild('unityTypeTag') unityTypeTag: any;
    constructor(private formBuilder: FormBuilder,
        private jbhGlobals: JBHGlobals,
        private orderService: OrderService,
        public stopSharedDataService: StopSharedDataService,
        private chargesService: ChargesService,
        public route: ActivatedRoute,
        public viewOrderService: ViewOrderService,
        public router: Router) { }

    ngOnInit(): void {
        this.chargesModel = new ChargesModel();
        this.chargesModel.orderData = '';
        this.chargesModel.debounceValue = this.jbhGlobals.settings.debounce;
        if (this.jbhGlobals.utils.isEmpty(this.chargesModel.orderData)) {
            this.chargesModel.subscription = this.orderService.getData().subscribe(sharedOrderData => {
                this.chargesModel.orderData = sharedOrderData;
                if (!this.jbhGlobals.utils.isEmpty(this.chargesModel.orderData) && this.chargesModel.orderData !== undefined &&
                    this.chargesModel.intialChargeClick) {
                    this.getChargeDataService();
                    this.chargesModel.intialChargeClick = false;
                    this.stopShowCharge();
                }
            });
        }
        this.frameChargeListFormBuilder();
        this.chargesModel.currentPage = this.router.url.split('?')[0].substring(1, this.router
            .url.length).toString().toLowerCase();

        this.route.queryParams.subscribe(
            (queryParam: any) => {
                if (!this.jbhGlobals.utils.isEmpty(queryParam['id'])) {
                    this.chargesModel.orderId = Number(queryParam['id']);
                }
            });
    }

    getTimeStampForVIewOrder() {
        this.viewOrderService.getData().subscribe(sharedOrderData => {
            if (!this.jbhGlobals.utils.isEmpty(sharedOrderData)) {
                const sharedOrderDetails = sharedOrderData;
                if (sharedOrderDetails) {
                    this.chargesModel.orderData = sharedOrderDetails['lastUpdateTimestampString'];
                }
            }
        });
    }

    stopShowCharge() {
        this.stopSharedDataService.getData().subscribe(data => {
            if (!this.jbhGlobals.utils.isEmpty(data)) {
                if (data[0].action === 'add') {
                    this.chargesModel.stopSummary = data[0].data;
                    this.loadStopCharge();
                }
            }

        });
    }
    loadStopCharge() {
        this.chargesModel.levelCode = [];
        this.chargesModel.levelCode.push({
            'chargeLvlCode': 'ORDER',
            'chargeLevelTypeCode': 'ORDER'
        });
        if (this.chargesModel.stopSummary && this.chargesModel.stopSummary.length !== 0) {
            for (let i = 0; i < this.chargesModel.stopSummary.length; i++) {
                if (this.chargesModel.stopSummary[i].stop.stopID !== '' && this.chargesModel.stopSummary[i].stop.stopID !== null) {
                    const stopNum = this.chargesModel.stopSummary[i].stop.stopSequenceNumber;
                    if (!this.chargesModel.levelCode) {
                        this.chargesModel.levelCode = [];
                    }
                    this.chargesModel.levelCode.push({
                        'chargeLevelTypeCode': 'STOP ' + stopNum,
                        'chargeLvlCode': 'STOP ' + stopNum,
                        'stopReason': this.chargesModel.stopSummary[i]['stop']['stopReason'],
                        'stopID': this.chargesModel.stopSummary[i]['stop']['stopID']
                    });
                    this.chargesModel.levelCode = this.jbhGlobals.utils.uniq(this.chargesModel.levelCode);
                }
            }
        }
    }

    chargeTabClick() {
        this.chargesModel.unitFlag = false;
        this.chargesModel.flatFlag = true;
    }

    frameChargeListFormBuilder() {
        this.chargeDtoDetails = this.formBuilder.group({
            'chargeID': null,
            'chargeQuantity': ['0.00', Validators.compose([Validators.required, this.jbhGlobals.customValidator.decimalNumberUptoTwo])],
            'chargeUnitCode': null,
            'chargeCode': '',
            'order': '',
            'chargeUnitRateAmount': ['00.0000', Validators.compose([Validators.required,
            this.jbhGlobals.customValidator.decimalNumberUptoFour
            ])],
            'customerAuthorizationFirstName': '',
            'customerAuthorizationLastName': '',
            'customerAuthorizationNumber': '',
            'chargeLevelTypeCode': ['', Validators.compose([Validators.required])],
            'chargeDescription': ['', Validators.compose([Validators.required])],
            // 'chargeUnitCalculation': '',
            '@type': ''

        });

        this.chargeDtoDetails['controls']['chargeDescription']['valueChanges']
            .debounceTime(this.chargesModel.debounceValue)
            .distinctUntilChanged()
            .subscribe((chargeSearchVal) => {
                const tabType = (this.chargesModel.flatFlag === true) ? 'FLAT' : 'UNIT';
                this.getChargeCodeList(chargeSearchVal, tabType);
            }, (err: Error) => {
                this.jbhGlobals.logger.warn(err);
            });
    }

    getChargeCodeList(val, tabName) {
        if (val !== undefined) {
            if (this.chargesModel.orderData.serviceOfferingCode === null && this.chargesModel.orderData.financeBusinessUnitCode === null) {
                const level = this.chargeDtoDetails.value.chargeLevelTypeCode,
                    manual = 'MANUAL';

                const chargeCodePar = '?chargeCode=' + val + '&stopReason=' + this.chargesModel.stopreason +
                    '&level=' + level + '&unitType=' + tabName + '&type=' + manual;

                this.chargesService.retreiveChargeCode(this.jbhGlobals.endpoints.order.getChargeCodes + chargeCodePar).subscribe(data => {
                    this.chargesModel.responseData = data;
                    if (this.chargesModel.responseData !== undefined) {
                        this.chargesModel.typeHeadChargeCodeList = this.chargesModel.responseData;
                    }
                    this.jbhGlobals.logger.info('Getting flat Charge Code List --->');
                    this.jbhGlobals.logger.info(this.chargesModel.typeHeadChargeCodeList);
                });

            } else {
                const serviceoffering = this.chargesModel.orderData.serviceOfferingCode,
                    businessunit = this.chargesModel.orderData.financeBusinessUnitCode,
                    level = this.chargeDtoDetails.value.chargeLevelTypeCode,
                    manual = 'MANUAL';

                const chargeCodeParam = '?chargeCode=' + val + '&stopReason=' + this.chargesModel.stopreason +
                    '&level=' + level + '&unitType=' + tabName + '&type=' + manual + '&businessUnit=' + businessunit +
                    '&serviceOffering=' + serviceoffering;
                this.chargesService.retreiveChargeCode(this.jbhGlobals.endpoints.order.getChargeCodes + chargeCodeParam).subscribe(data => {
                    this.chargesModel.responseData = data;
                    if (this.chargesModel.responseData !== undefined) {
                        this.chargesModel.typeHeadChargeCodeList = this.chargesModel.responseData;
                    }
                    this.jbhGlobals.logger.info('Getting flat Charge Code List --->');
                    this.jbhGlobals.logger.info(this.chargesModel.typeHeadChargeCodeList);
                });
            }
        }

    }

    getUnitCodeList(chargeCode) {
        const unitParam = {
            'chargecode': chargeCode
        };
        this.chargesService.retreiveUnitCode(this.jbhGlobals.endpoints.order.getChargeUnitCodes, unitParam)
            .subscribe(data => {
                this.chargesModel.unitCodeList = [];
                const unitCodeLists = data['_embedded']['unitTypes'];
                for (const unitCode of unitCodeLists) {
                    const obj = {
                        'id': unitCode.unitTypeCode,
                        'text': unitCode.unitTypeCode
                    };
                    this.chargesModel.unitCodeList.push(obj);
                }
                this.jbhGlobals.logger.info('Getting Unit Code data --->');
            });
    }
    selChargeUnitCode(selEvnt) {
        this.chargesModel.updatedChargeCode = selEvnt.item.chargeClassCode.trim();
        this.getUnitCodeList(selEvnt.item.chargeClassCode);
    }
    chargeViewList() {
        if (this.chargesModel.chargeList && this.chargesModel.chargeList.length !== 0) {
            for (let i = 0; i < this.chargesModel.chargeList.length; i++) {
                this.chargesModel.chargesIndex.push(this.chargesModel.chargeList[i]);
            }
        }
    }
    pushToChargeDto(chargeDto, param?: any) {
        if (this.chargesModel.editCall === false) {
            if (this.chargesModel.currentPage !== 'vieworder') {
                const updateParam = param ? param : null;
                this.chargesModel.chargeDtoVal = this.chargesModel.chargeDtoVal ? chargeDto['value'] : chargeDto;
                if (chargeDto['customerAuthorizationLastName'] === '') {
                    chargeDto.custAuthName = chargeDto['customerAuthorizationFirstName']
                } else {
                    chargeDto.custAuthName = chargeDto['customerAuthorizationFirstName'].split(/(\s+)/);
                    chargeDto['customerAuthorizationFirstName'] = chargeDto.custAuthName[0];
                    chargeDto['customerAuthorizationLastName'] = chargeDto.custAuthName[2];

                }
                chargeDto['order'] = '/' + this.route.snapshot.queryParams.id;
                chargeDto['chargeUnitRateAmount'] = parseFloat(chargeDto['chargeUnitRateAmount']);
                chargeDto['chargeQuantity'] = parseFloat(chargeDto['chargeQuantity']);
                chargeDto['chargeCode'] = (this.chargesModel.updatedChargeCode !== undefined) ?
                    this.chargesModel.updatedChargeCode : chargeDto['chargeCode'];
                this.chargesModel.chargeListFlag = false;
                this.addToChargeDto(chargeDto, false);
            }
            if (this.chargesModel.currentPage === 'vieworder') {
                const updateParam = param ? param : null;
                this.chargesModel.chargeDtoVal = this.chargesModel.chargeDtoVal ? chargeDto['value'] : chargeDto;
                this.chargesModel.custAuthName = this.chargesModel.chargeDtoVal['customerAuthorizationFirstName'].split(/(\s+)/);
                this.chargesModel.chargeDtoVal['customerAuthorizationFirstName'] = this.chargesModel.custAuthName[0];
                this.chargesModel.chargeDtoVal['customerAuthorizationLastName'] = this.chargesModel.custAuthName[2];
                this.chargesModel.chargeDtoVal['chargeUnitRateAmount'] = parseFloat(this.chargesModel.chargeDtoVal['chargeUnitRateAmount']);
                this.chargesModel.chargeDtoVal['chargeQuantity'] = parseFloat(this.chargesModel.chargeDtoVal['chargeQuantity']);
                this.chargesModel.chargeDtoVal['chargeCode'] = (this.chargesModel.updatedChargeCode !== undefined) ?
                    this.chargesModel.updatedChargeCode : this.chargesModel.chargeDtoVal['chargeCode'];
                delete this.chargesModel.chargeDtoVal['order'];
                this.chargesModel.chargeListFlag = false;
                this.viewAddToChargeDto(this.chargesModel.chargeDtoVal, updateParam);
            }
        } else {
            if (this.chargesModel.currentPage !== 'vieworder') {
                const updateParam = param ? param : null;
                this.chargesModel.chargeDtoVal = this.chargesModel.chargeDtoVal ? chargeDto['value'] : chargeDto;
                if (this.chargesModel.editValue.customerAuthorizationLastName === null ||
                    this.chargesModel.editValue.customerAuthorizationLastName === undefined ||
                    this.chargesModel.editValue.customerAuthorizationLastName === '') {
                    this.chargesModel.custAuthName = this.chargesModel.editValue['customerAuthorizationFirstName']
                } else {
                    this.chargesModel.custAuthName = this.chargesModel.editValue['customerAuthorizationFirstName'].split(/(\s+)/);
                    this.chargesModel.editValue['customerAuthorizationFirstName'] = this.chargesModel.custAuthName[0];
                    this.chargesModel.editValue['customerAuthorizationLastName'] = this.chargesModel.custAuthName[2];
                }
                this.chargesModel.editValue['order'] = '/' + this.route.snapshot.queryParams.id;
                this.chargesModel.editValue['chargeUnitRateAmount'] = parseFloat(this.chargesModel.editValue['chargeUnitRateAmount']);
                this.chargesModel.editValue['chargeQuantity'] = parseFloat(this.chargesModel.editValue['chargeQuantity']);
                this.chargesModel.editValue['chargeCode'] = (this.chargesModel.updatedChargeCode !== undefined) ?
                    this.chargesModel.updatedChargeCode : this.chargesModel.editValue['chargeCode'];
                this.chargesModel.chargeListFlag = false;
                this.addToChargeDto(chargeDto, updateParam);
            } else if (this.chargesModel.currentPage === 'vieworder') {
                const updateParam = param ? param : null;
                this.chargesModel.chargeDtoVal = this.chargesModel.chargeDtoVal ? chargeDto['value'] : chargeDto;
                if (this.chargesModel.editValue.customerAuthorizationLastName === null ||
                    this.chargesModel.editValue.customerAuthorizationLastName === undefined ||
                    this.chargesModel.editValue.customerAuthorizationLastName === '') {
                    this.chargesModel.custAuthName = this.chargesModel.editValue['customerAuthorizationFirstName']
                } else {
                    this.chargesModel.custAuthName = this.chargesModel.editValue['customerAuthorizationFirstName'].split(/(\s+)/);
                    this.chargesModel.editValue['customerAuthorizationFirstName'] = this.chargesModel.custAuthName[0];
                    this.chargesModel.editValue['customerAuthorizationLastName'] = this.chargesModel.custAuthName[2];
                }
                delete this.chargesModel.chargeDtoVal['order'];
                // this.chargesModel.chargeDtoVal['order'] = '/' + this.route.snapshot.queryParams.id;
                this.chargesModel.chargeDtoVal['chargeUnitRateAmount'] = parseFloat(this.chargesModel.chargeDtoVal['chargeUnitRateAmount']);
                this.chargesModel.chargeDtoVal['chargeQuantity'] = parseFloat(this.chargesModel.chargeDtoVal['chargeQuantity']);
                this.chargesModel.chargeDtoVal['chargeCode'] = (this.chargesModel.updatedChargeCode !== undefined) ?
                    this.chargesModel.updatedChargeCode : this.chargesModel.chargeDtoVal['chargeCode'];
                this.chargesModel.chargeListFlag = false;
                this.viewAddToChargeDto(this.chargesModel.chargeDtoVal, updateParam);
            }
        }

    }

    viewAddToChargeDto(chargeDto, updateParam) {
        if (updateParam === 'update') {
            this.viewUpdateChargeService(chargeDto);
        } else {
            this.viewAddChargeService(chargeDto);
        }
    }

    addToChargeDto(chargeDto, updateParam) {
        if (updateParam === 'update') {
            this.updateChargeService(chargeDto);
        } else {
            this.addChargeService(chargeDto);
        }
    }

    viewAddChargeService(addDto) {
        const stopVal = addDto['chargeLevelTypeCode'].split(' ');
        addDto['chargeLevelTypeCode'] = stopVal[0];
        const stopindex = stopVal[1] - 1;
        if (addDto['chargeLevelTypeCode'].indexOf('ST') >= 0) {
            addDto['stop'] = this.chargesModel.stopID;
            addDto['chargeLevelTypeCode'] = addDto['chargeLevelTypeCode'].slice(0, -1);
        }
        const chargesViewIndex = this.chargesModel.chargesIndex.length;
        const requestObj = {
            'order': [{
                'op': 'add',
                'path': (this.chargeDtoDetails.value.chargeLevelTypeCode === 'ORDER') ? '/orderCharges/' + chargesViewIndex : '/stops/' +
                    stopindex + '/stopCharges/' + chargesViewIndex,
                'value': addDto
            }]
        };
        this.chargeViewList();
        const url = this.jbhGlobals.endpoints.viewOrder.orderUpdate + this.chargesModel.orderId + '/warningoverriden/' + false;
        this.viewOrderService.updateOrder(url, requestObj).subscribe(data => {
            if (!this.jbhGlobals.utils.isEmpty(data)) {
                console.log(data);
                this.viewOrderService.loadOrder(this.chargesModel.orderId);
                this.getChargeDataService();
                this.viewOrderService.errorHandling(data);
            }
        });
    }

    addChargeService(addDto) {
        if (addDto['chargeLevelTypeCode'].indexOf('ST') >= 0) {
            this.chargesModel.chargeDto = {
                endpoint: this.jbhGlobals.endpoints.order.stopcharge
            };
            addDto['chargeLevelTypeCode'] = addDto['chargeLevelTypeCode'].slice(0, -1);
            addDto['stop'] = this.chargesModel.stopID;
        } else {
            this.chargesModel.chargeDto = {
                endpoint: this.jbhGlobals.endpoints.order.charge
            };
        }
        this.chargesService.createCharge(this.chargesModel.chargeDto, addDto).subscribe(chargeData => {
            if (!this.jbhGlobals.utils.isEmpty(chargeData)) {
                this.jbhGlobals.logger.info('Adding Charge Data --->');
                this.jbhGlobals.logger.info(chargeData);
                this.getChargeDataService();
                this.chargeDtoDetails.reset();
                this.frameChargeListFormBuilder();
            }
        });
    }

    viewUpdateChargeService(updateDto) {
        const stopVal = updateDto['chargeLevelTypeCode'].split(' ');
        updateDto['chargeLevelTypeCode'] = stopVal[0];
        const stopindex = stopVal[1] - 1;
        if (updateDto['chargeLevelTypeCode'].indexOf('ST') >= 0) {
            // updateDto['stop'] = '/' + this.chargesModel.stopID;
            this.chargesModel.chargeDto = {
                endpoint: this.jbhGlobals.endpoints.order.stopcharge,
                chargeID: updateDto['chargeID']
            };
        } else {
            this.chargesModel.chargeDto = {
                endpoint: this.jbhGlobals.endpoints.order.charge,
                chargeID: updateDto['chargeID']
            };
        }
        const chargesViewIndex = this.chargesModel.chargesIndex.length;
        const requestObj = {
            'order': [{
                'op': 'replace',
                'path': (this.chargeDtoDetails.value.chargeLevelTypeCode === 'ORDER') ? '/orderCharges/' + chargesViewIndex : '/stops/' +
                    stopindex + '/stopCharges/' + chargesViewIndex,
                'value': updateDto
            }]
        };
        this.chargeViewList();
        const url = this.jbhGlobals.endpoints.viewOrder.orderUpdate + this.chargesModel.orderId + '/warningoverriden/' + false;
        this.viewOrderService.updateOrder(url, requestObj).subscribe(data => {
            if (!this.jbhGlobals.utils.isEmpty(data)) {
                console.log(data);
                this.viewOrderService.loadOrder(this.chargesModel.orderId);
                this.getChargeDataService();
                this.viewOrderService.errorHandling(data);
            }
        });
    }
    updateChargeService(updateDto) {
        if (updateDto['chargeLevelTypeCode'].indexOf('ST') >= 0) {
            updateDto['stop'] = '/' + this.chargesModel.stopID;
            this.chargesModel.chargeDto = {
                endpoint: this.jbhGlobals.endpoints.order.stopcharge,
                chargeID: updateDto['chargeID']
            };
        } else {
            this.chargesModel.chargeDto = {
                endpoint: this.jbhGlobals.endpoints.order.charge,
                chargeID: updateDto['chargeID']
            };
        }

        this.chargesService.updateCharge(this.chargesModel.chargeDto, updateDto)
            .subscribe(chargeData => {
                if (!this.jbhGlobals.utils.isEmpty(chargeData)) {
                    this.jbhGlobals.logger.info('Updated Charge Data --->');
                    this.jbhGlobals.logger.info(chargeData);
                    this.getChargeDataService();
                    this.chargeDtoDetails.reset();
                    this.chargesModel.editCall = false;
                    this.frameChargeListFormBuilder();

                }
            });
    }

    deleteChargeService(deleteDto) {
        if (deleteDto['chargeLevelTypeCode'].indexOf('ST') >= 0) {
            this.chargesModel.chargeDto = {
                endpoint: this.jbhGlobals.endpoints.order.stopcharge,
                chargeID: deleteDto['chargeID']
            };
        } else {
            this.chargesModel.chargeDto = {
                endpoint: this.jbhGlobals.endpoints.order.charge,
                chargeID: deleteDto['chargeID']
            };
        }
        this.chargesService.deleteCharge(this.chargesModel.chargeDto)
            .subscribe(chargeData => {
                this.chargesModel.delIndex = null;
                this.chargesModel.editDelIndex = null;
                this.getChargeDataService();
            });
    }

    viewDeleteChargeService(deleteDto) {
        if (deleteDto['chargeLevelTypeCode'].indexOf('ST') >= 0) {
            this.chargesModel.chargeDto = {
                endpoint: this.jbhGlobals.endpoints.order.stopcharge,
                chargeID: deleteDto['chargeID']
            };
        } else {
            this.chargesModel.chargeDto = {
                endpoint: this.jbhGlobals.endpoints.order.charge,
                chargeID: deleteDto['chargeID']
            };
        }
        const chargesViewIndex = this.chargesModel.chargesIndex.length;
        const requestObj = {
            'order': [{
                'op': 'remove',
                'path': '/orderCharges/' + chargesViewIndex,
                'value': deleteDto
            }]
        };
        this.chargeViewList();
        const url = this.jbhGlobals.endpoints.viewOrder.orderUpdate + this.chargesModel.orderId + '/warningoverriden/' + false;
        this.viewOrderService.updateOrder(url, requestObj).subscribe(data => {
            if (!this.jbhGlobals.utils.isEmpty(data)) {
                console.log(data);
                this.viewOrderService.loadOrder(this.chargesModel.orderId);
                this.getChargeDataService();
                this.viewOrderService.errorHandling(data);
            }
        });

    }
    getChargeDataService() {
        const me = this;
        me.totCharges = 0;
        me.chargesModel.chargeDto = {
            chargePath: '/charges',
            chargeID: this.route.snapshot.queryParams.id,
            endpoint: this.jbhGlobals.endpoints.order.getorder
        };
        this.chargesService.readCharge(me.chargesModel.chargeDto)
            .subscribe(chargeData => {
                if (!this.jbhGlobals.utils.isEmpty(chargeData)) {
                    this.jbhGlobals.logger.info('Getting charge datalist --->');
                    this.jbhGlobals.logger.info(chargeData);
                    me.chargesModel.chargeList = [];
                    me.chargesModel.levelCode = [];
                    //if (chargeData.length === 0) {
                    me.chargesModel.levelCode.push({
                        'chargeLvlCode': 'ORDER',
                        'chargeLevelTypeCode': 'ORDER'
                    });
                    //} else {
                    const arrLen = chargeData.length;
                    for (let i = 0; i < arrLen; i++) {
                        /*if (chargeData[i]['charge']['chargeLevelTypeCode'] === 'ORDER') {
                            me.chargesModel.levelCode.push({
                                'chargeLvlCode': chargeData[i]['charge']['chargeLevelTypeCode'],
                                'chargeLevelTypeCode': chargeData[i]['charge']['chargeLevelTypeCode']
                            });
                        //} else {
                            chargeData[i]['charge']['chargeLevelTypeCode'] = chargeData[i]['charge']['chargeLevelTypeCode'] +
                                ' ' + chargeData[i]['stopSequenceNumber'];
                            chargeData[i]['charge']['stopID'] = chargeData[i]['stopID'];
                        }*/
                        if (chargeData[i]['charge']['chargeLevelTypeCode'] === 'STOP') {
                            chargeData[i]['charge']['chargeLevelTypeCode'] = chargeData[i]['charge']['chargeLevelTypeCode'] +
                                ' ' + chargeData[i]['stopSequenceNumber'];
                            chargeData[i]['charge']['stopID'] = chargeData[i]['stopID'];
                        }
                        me.totCharges = me.totCharges + chargeData[i]['charge']['chargeUnitRateAmount'];
                        const chargeObj = chargeData[i]['charge'];
                        chargeObj['chargeDescription'] = chargeData[i]['chargeDescription'];
                        me.chargesModel.chargeList.push(chargeObj);
                        me.chargesModel.chargeListFlag = true;
                    }
                    this.stopShowCharge();

                    //}
                } else {
                    me.chargesModel.chargeListFlag = false;
                    me.chargesModel.chargeList = [];
                    me.chargesModel.levelCode = [];
                    me.chargesModel.levelCode.push({
                        'chargeLvlCode': 'ORDER',
                        'chargeLevelTypeCode': 'ORDER'
                    });
                }
            });
    }

    showUnitContent(el) {
        el.target.classList.remove('active');
        if (el.target.innerHTML === 'Flat') {
            this.chargesModel.unitFlag = false;
            this.chargesModel.flatFlag = true;
            el.target.classList.add('active');
            el.target.nextElementSibling.classList.remove('active');
        } else {
            this.chargesModel.flatFlag = false;
            this.chargesModel.unitFlag = true;
            el.target.previousElementSibling.classList.remove('active');
            el.target.classList.add('active');
        }
    }

    enableChargeEdit(chargeIndex) {
        this.chargesModel.showEditBtn = true;
        this.chargesModel.onEditAuthDetail = true;
        this.chargesModel.editDelIndex = chargeIndex;
    }

    editCharges(index) {
        this.chargesModel.editCall = true;
        this.chargesModel.gbEdtIdx = index;
        this.chargesModel.addBtn = false;
        this.chargesModel.editBtn = true;
        this.chargesModel.hideDelBtn = index; // hiding delete button
        //this.onSelLevelCode(index);
        this.chargesModel.editValue = this.chargesModel.chargeList[index];
        this.chargesModel.stopID = this.chargesModel.editValue['stopID'];
        if (!this.jbhGlobals.utils.isEmpty(this.chargesModel.editValue['chargeUnitCode'])) {
            this.chargesModel.flatFlag = false;
            this.chargesModel.unitFlag = true;
        } else {
            this.chargesModel.unitFlag = false;
            this.chargesModel.flatFlag = true;
        }

        this.chargesModel.editValue['chargeUnitRateAmount'] = this.chargesModel.editValue['chargeUnitRateAmount'].toString();
        this.chargesModel.editValue['chargeQuantity'] = this.chargesModel.editValue['chargeQuantity'].toString();
        if (this.chargesModel.editValue['customerAuthorizationLastName'] === null) {
            this.chargesModel.editValue['customerAuthorizationFirstName'] = this.chargesModel.editValue['customerAuthorizationFirstName']
        } else {
            this.chargesModel.editValue['customerAuthorizationFirstName'] =
                this.chargesModel.editValue['customerAuthorizationFirstName'] + ' ' +
                this.chargesModel.editValue['customerAuthorizationLastName']
        }
        this.chargeDtoDetails.patchValue(this.chargesModel.editValue);
    }

    delCharges(index) {
        this.chargesModel.showEditBtn = false;
        this.chargesModel.editDelIndex = null;
        this.chargesModel.delIndex = index;
    }

    chargeCloseIcon(index) {
        if (this.chargesModel.currentPage !== 'vieworder') {
            this.deleteChargeService(this.chargesModel.chargeList[index]);
            this.chargesModel.chargeList.splice(0, index);
        } else {
            this.viewDeleteChargeService(this.chargesModel.chargeList[index]);
            this.chargesModel.chargeList.splice(0, index);
        }
    }

    undoDelChargeSection(i) {
        this.chargesModel.delIndex = null;
        this.chargesModel.editDelIndex = null;

    }

    onSaveCharge() {
        this.chargesModel.chargeList.splice(0, this.chargesModel.gbEdtIdx);
        const updateParam = 'update';
        this.pushToChargeDto(this.chargeDtoDetails.getRawValue(), updateParam);
        this.chargeDtoDetails.reset();
        this.chargesModel.onEditAuthDetail = false;
        this.chargesModel.addBtn = true;
        this.chargesModel.editBtn = false;
        this.chargesModel.showEditBtn = false;
        this.chargesModel.hideDelBtn = null;
    }

    onAddCharges() {
        if (this.chargesModel.updatedChargeCode !== undefined) {
            if (this.chargeDtoDetails.value.chargeLevelTypeCode === 'ORDER') {
                this.chargeDtoDetails.controls['@type'].setValue('OrderCharge');
            } else {
                this.chargeDtoDetails.controls['@type'].setValue('StopCharge');
            }
            if (this.chargesModel.unitFlag === true) {
                if (this.chargeDtoDetails.value.chargeDescription === 'DEADHDMILE' &&
                    Number(this.chargeDtoDetails.value.chargeUnitRateAmount) === 0) {
                    this.jbhGlobals.notifications.error('Error', 'Unit rate should be greater than 0.0');
                    return false;
                }
            }
            if (this.chargeDtoDetails.value.chargeDescription === 'DEADHDMILE' &&
                Number(this.chargeDtoDetails.value.chargeQuantity) === 0) {
                this.jbhGlobals.notifications.error('Error', 'Quantity should be greater than 0.00');
                return false;
            } else if (this.jbhGlobals.utils.trim(this.chargeDtoDetails.value.chargeDescription) === 'DETENTION' &&
                Number(this.chargeDtoDetails.value.chargeQuantity) === 0) {
                this.jbhGlobals.notifications.error('Error', 'Quantity should be greater than 0.00');
                return false;
            } else if (this.chargeDtoDetails.value.chargeDescription === 'DETENTIONP' &&
                Number(this.chargeDtoDetails.value.chargeQuantity) === 0) {
                this.jbhGlobals.notifications.error('Error', 'Quantity should be greater than 0.00');
                return false;
            }
            let invalidCharge = this.chargesdupCode() ? true : false;
            invalidCharge = this.chargesDupliCode() ? true : false;
            if (!invalidCharge) {
                this.pushToChargeDto(this.chargeDtoDetails.value, true);
                this.chargeDtoDetails.reset();
                this.frameChargeListFormBuilder();
            }
        }
    }

    chargesdupCode(): boolean {
        if (this.chargesModel.flatFlag === true) {
            const chargeListLen = this.chargesModel.chargeList.length;
            for (let i = 0; i < chargeListLen; i++) {
                if (this.chargesModel.chargeList[i]['chargeCode']['trim']() ===
                    this.chargeDtoDetails['controls']['chargeDescription']['value']['trim']() &&
                    this.chargesModel.chargeList[i]['chargeUnitRateAmount'] ===
                    Number(this.chargeDtoDetails['controls']['chargeUnitRateAmount']['value']) &&
                    this.chargesModel.chargeList[i]['chargeLevelTypeCode'] ===
                    this.chargeDtoDetails['controls']['chargeLevelTypeCode']['value'] &&
                    this.chargesModel.chargeList[i]['chargeQuantity'] ===
                    Number(this.chargeDtoDetails['controls']['chargeQuantity']['value'])) {
                    this.jbhGlobals.notifications.error('Error', 'This is Duplicate Entry');
                    return true;
                }
            }

        } else {
            const chargeListLen = this.chargesModel.chargeList.length;
            for (let i = 0; i < chargeListLen; i++) {
                if (this.chargesModel.chargeList[i]['chargeCode']['trim']() ===
                    this.chargeDtoDetails['controls']['chargeDescription']['value']['trim']() &&
                    this.chargesModel.chargeList[i]['chargeUnitRateAmount'] ===
                    Number(this.chargeDtoDetails['controls']['chargeUnitRateAmount']['value']) &&
                    this.chargesModel.chargeList[i]['chargeLevelTypeCode'] ===
                    this.chargeDtoDetails['controls']['chargeLevelTypeCode']['value'] &&
                    this.chargesModel.chargeList[i]['chargeQuantity'] ===
                    Number(this.chargeDtoDetails['controls']['chargeQuantity']['value']) &&
                    this.chargesModel.chargeList[i]['chargeUnitCode']['trim']() ===
                    this.chargeDtoDetails['controls']['chargeUnitCode']['value']['trim']()) {
                    this.jbhGlobals.notifications.error('Error', 'This is Duplicate Entry');
                    return true;
                }
            }
        }
    }

    chargesDupliCode() {
        const chargeListLeng = this.chargesModel.chargeList.length;
        for (let i = 0; i < chargeListLeng; i++) {
            if (this.chargesModel.chargeList[i]['chargeCode']['trim']() === 'TRLSVC INC' && (
                this.chargeDtoDetails['value']['chargeDescription']['trim']() === 'TRLSVC INC' ||
                this.chargeDtoDetails['value']['chargeDescription']['trim']() === 'DOOR2DOOR' ||
                this.chargeDtoDetails['value']['chargeDescription']['trim']() === 'RP2RP' ||
                this.chargeDtoDetails['value']['chargeDescription']['trim']() === 'RP2DR' ||
                this.chargeDtoDetails['value']['chargeDescription']['trim']() === 'DR2RP')) {
                this.jbhGlobals.notifications.error('Error', 'These two charges codes can not be added at same time');
                return true;
            } else if (this.chargesModel.chargeList[i]['chargeCode']['trim']() === 'DOOR2DOOR' && (
                this.chargeDtoDetails['value']['chargeDescription']['trim']() === 'DOOR2DOOR' ||
                this.chargeDtoDetails['value']['chargeDescription']['trim']() === 'TRLSVC INC' ||
                this.chargeDtoDetails['value']['chargeDescription']['trim']() === 'RP2RP' ||
                this.chargeDtoDetails['value']['chargeDescription']['trim']() === 'RP2DR' ||
                this.chargeDtoDetails['value']['chargeDescription']['trim']() === 'DR2RP')) {
                this.jbhGlobals.notifications.error('Error', 'These two charges codes can not be added at same time');
                return true;
            } else if (this.chargesModel.chargeList[i]['chargeCode']['trim']() === 'RP2RP' && (
                this.chargeDtoDetails['value']['chargeDescription']['trim']() === 'RP2RP' ||
                this.chargeDtoDetails['value']['chargeDescription']['trim']() === 'TRLSVC INC' ||
                this.chargeDtoDetails['value']['chargeDescription']['trim']() === 'DOOR2DOOR' ||
                this.chargeDtoDetails['value']['chargeDescription']['trim']() === 'RP2DR' ||
                this.chargeDtoDetails['value']['chargeDescription']['trim']() === 'DR2RP')) {
                this.jbhGlobals.notifications.error('Error', 'These two charges codes can not be added at same time');
                return true;
            } else if (this.chargesModel.chargeList[i]['chargeCode']['trim']() === 'RP2DR' && (
                this.chargeDtoDetails['value']['chargeDescription']['trim']() === 'RP2DR' ||
                this.chargeDtoDetails['value']['chargeDescription']['trim']() === 'TRLSVC INC' ||
                this.chargeDtoDetails['value']['chargeDescription']['trim']() === 'DOOR2DOOR' ||
                this.chargeDtoDetails['value']['chargeDescription']['trim']() === 'RP2RP' ||
                this.chargeDtoDetails['value']['chargeDescription']['trim']() === 'DR2RP')) {
                this.jbhGlobals.notifications.error('Error', 'These two charges codes can not be added at same time');
                return true;
            } else if (this.chargesModel.chargeList[i]['chargeCode']['trim']() === 'DR2RP' && (
                this.chargeDtoDetails['value']['chargeDescription']['trim']() === 'DR2RP' ||
                this.chargeDtoDetails['value']['chargeDescription']['trim']() === 'TRLSVC INC' ||
                this.chargeDtoDetails['value']['chargeDescription']['trim']() === 'DOOR2DOOR' ||
                this.chargeDtoDetails['value']['chargeDescription']['trim']() === 'RP2RP' ||
                this.chargeDtoDetails['value']['chargeDescription']['trim']() === 'RP2DR')) {
                this.jbhGlobals.notifications.error('Error', 'These two charges codes can not be added at same time');
                return true;
            }
        }
    }

    onDelete(eve) {
        if (eve.flag) {
            this.chargeDtoDetails.reset();
            this.chargesModel.addBtn = true;
            this.chargesModel.hideDelBtn = null;
            this.chargesModel.editBtn = false;
            this.chargesModel.showEditBtn = false;
            this.chargesModel.onEditAuthDetail = false;
            eve.model.hide();
        } else {
            document.querySelector('body').removeChild(this.popInstance.deleteButtonModal._element.nativeElement);
            eve.model.hide();
        }
    }

    onCancel() {
        document.querySelector('body').appendChild(this.popInstance.deleteButtonModal._element.nativeElement);
        this.popInstance.deleteButtonModal.show();
    }

    onSelLevelCode(val) {
        const chargeIndex = (val.options !== undefined) ? val.options.selectedIndex - 1 : val;
        const stopData = this.chargesModel.levelCode[chargeIndex];
        if (stopData['chargeLevelTypeCode'] === 'ORDER') {
            this.chargesModel.stopreason = 'Delivery';
        } else {
            this.chargesModel.stopreason = stopData['stopReason'];
            this.chargesModel.stopID = '/' + stopData['stopID'];
        }
    }
}
