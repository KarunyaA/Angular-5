import { ReferencesService } from './services/references.service';
import { Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { JBHGlobals } from '../../../../../app.service';
import { OrderService } from '../../services/order.service';
import { StopSharedDataService } from '../../../orders/add-stops/services/stop-shared-data.service';
import { ReferencesModel } from './models/references.model';
import { ActivatedRoute, Router } from '@angular/router';
import { ReferenceUtilityService } from './services/reference-utility.service';
import { ReferenceHelperService } from './services/reference-helper.service';
import { ReferenceGenerateTreeService } from './services/reference-generate-tree.service';
import { ReferenceSupportService } from './services/reference-support.service';
import { ViewOrderService } from '../../../../view-order/services/view-order.service';

@Component({
  selector: 'app-reference',
  templateUrl: './reference.component.html',
  styleUrls: ['./reference.component.scss',
    '../charges/charges.component.scss'
  ],
  providers: [ReferencesService, ReferenceUtilityService, ReferenceHelperService, ReferenceGenerateTreeService, ReferenceSupportService]
})
export class ReferenceComponent implements OnInit, OnDestroy {
  referencesModel: ReferencesModel;
  @ViewChild('reftype') referenceTypeDirectReference: any;
  @ViewChild('parRefVal') pRefTypeValReference: any;
  @ViewChild('stplevel') stopLevelNumber: any;
  @ViewChild('refForm') referenceForm: any;
  @ViewChild('parReftype') associatedParentReferenceType: any;
  @ViewChild('treeContainer') treeContainer: ElementRef;
  @ViewChild('popInstance') popInstance: any;
  @ViewChild('orderBtn') orderBtn: ElementRef;
  @ViewChild('stopBtn') stopBtn: ElementRef;
  @ViewChild('refVal') refVal: ElementRef;
  deleteOverlay: any;
  constructor(
    public orderService: OrderService,
    private jbhGlobals: JBHGlobals,
    private elementRef: ElementRef,
    public stopSharedDataService: StopSharedDataService,
    public route: ActivatedRoute,
    public router: Router,
    public viewOrderService: ViewOrderService,
    public referenceUtility: ReferenceUtilityService,
    public referenceHelper: ReferenceHelperService,
    public referenceGenerateTreeService: ReferenceGenerateTreeService,
    public referenceSupportService: ReferenceSupportService,
    public referencesService: ReferencesService) { };
  ngOnInit() {
    this.referencesModel = new ReferencesModel(); // Model instance
    this.referencesModel.indent = 20;
    this.referencesModel.currentPage = this.router.url.split('?')[0].substring(1, this.router.url.length).toString().toLowerCase();
    this.viewOrderService.getData().subscribe(sharedOrderData => {
      if (!this.jbhGlobals.utils.isEmpty(sharedOrderData)) {
        const sharedOrderDetails = sharedOrderData;
        if (sharedOrderDetails) {
          this.referencesModel.orderData = sharedOrderDetails['lastUpdateTimestampString'];
        }
      }
    });
    // OrderDTO service
    this.route.queryParams.subscribe(
      (queryParam: any) => {
        if (!this.jbhGlobals.utils.isEmpty(queryParam['id'])) {
          this.referencesModel.currentOrderId = Number(queryParam['id']);
        };
      });
    if (this.referencesModel.currentOrderId) {
      // Using JBHGlobals services ReferenceList Initial
      this.referencesService.loadReferences(this.jbhGlobals.endpoints.order.getreferencesList +
        this.referencesModel.currentOrderId + '/referencenumbers').subscribe(data => {
          this.referencesModel.referencesList = data;
          this.orderService.setReference(this.referencesModel.referencesList);
          if (this.referencesModel.referencesList && this.referencesModel.referencesList.length !== 0) {
            this.getReferenceList();
          }
        });
      // For Populating Stop Level
      this.stopSharedDataService.getData().subscribe(data => {
        if (!this.jbhGlobals.utils.isEmpty(data)) {
          if (data[0].action === 'add') {
            this.referencesModel.stopNIds = data[0].data;
            this.loadStopLevels();
          }
        };
      });
      // Using JBHGlobals services ReferenceType Initial
      const valLen = {
        'page': 0,
        'size': 500
      };
      this.referencesService.getReferencesTypeAndValue(this.jbhGlobals.endpoints.order.getReferenceTypeValueCommon,
        valLen).subscribe(data => {
          this.referencesModel.getreferencesType = data;
          if (this.referencesModel.getreferencesType && this.referencesModel.getreferencesType.length !== 0) {
            this.getReferencesType();
          }
        });
    }
  }
  ngOnDestroy(): void {
    for (const subs of this.referencesModel.subscriptions) {
      subs.unsubscribe();
    }
  }
  refValOnBlur(oRefOval) {
    this.referenceUtility.referenceValueOnBlur(oRefOval, this.referencesModel);
  }
  stopLvlOnBlur($event, stplevelvalue) {
    this.referenceUtility.stopLevelValidate(stplevelvalue, this.referencesModel);
  }
  refTypeOnBlur(reftypevalue) {
    this.referenceUtility.referenceTypeOnBlur(this.referencesModel, reftypevalue);
  }
  getReferencesType() {
    this.referenceUtility.getReferencesType(this.referencesModel);
    this.refreshStopLevels();
  }
  refreshStopLevels() {
    this.referenceUtility.reloadStopLevels(this.referencesModel);
  }
  reloadReferencesType() {
    this.referenceGenerateTreeService.reloadReferenceTypes(this, this.referencesModel);
  }
  loadStopLevels() {
    this.referenceUtility.loadStopLevels(this.referencesModel);
  }
  resetValidators() {
    this.referenceUtility.resetValidations(this.referencesModel);
  }
  stopsave(element) {
    this.stopBtn.nativeElement.click();
    this.referenceGenerateTreeService.triggerStopSaveForReferences(this, this.referencesModel, element);
    this.enableSelect(this.referenceTypeDirectReference);
    this.enableSelect(this.stopLevelNumber);
    this.enableSelect(this.associatedParentReferenceType);
  }
  ordersaveFlg(element) {
    this.orderBtn.nativeElement.click();
    this.referenceGenerateTreeService.setOrderSaveFlag(this, this.referencesModel, element);
    this.enableSelect(this.referenceTypeDirectReference);
    this.refVal.nativeElement.value = '';
  }
  getReferenceList() {
    const me = this;
    this.referenceGenerateTreeService.getReferencesList(this, this.referencesModel, me);
  }
  reloadStopReferenceList() {
    this.referenceHelper.reloadStopreferencesList(this, this.referencesModel);
  }
  generateTree(): void {
    const me = this;
    this.referenceGenerateTreeService.generateReferenceTree(this, this.referencesModel, me);
  }
  addClass(element, className) {
    this.referenceGenerateTreeService.callAddClass(this, element, className);
  }
  removeClass(element, className) {
    this.referenceGenerateTreeService.callremoveClass(this, element, className);
  }
  hasClass(element, className) {
    if (element.classList) {
      return element.classList.contains(className);
    } else {
      return !!element.className.match(new RegExp('(\\s|^)' + className + '(\\s|$)'));
    }
  }
  extractDTO(dto, indentVal) {
    this.referenceGenerateTreeService.extractDtoForListGeneration(this, this.referencesModel, dto, indentVal);
  }
  frameLi(desc, id, indentVal, stopID, refeNumberTypCode, refNmbrValue, uniqueStopIndex, stopLevelForViewOrder): void {
    const me = this;
    if (desc.length > 25) {
      me.referencesModel.displayDesc = desc;
    } else {
      me.referencesModel.displayDesc = desc;
    }
    const iteratedIndex = uniqueStopIndex++;
    const className = id + '--' + desc + '--' + stopID + '--' + refeNumberTypCode + '--' +
      refNmbrValue + '--' + iteratedIndex + '--' + stopLevelForViewOrder;
    this.referencesModel.requiredValues = {
      'className': className,
      'desc': desc,
      'indentVal': indentVal,
      'refNmbrValue': refNmbrValue,
      'displayDesc': me.referencesModel.displayDesc
    };
    if (this.referencesModel.selRefDiv && this.referencesModel.selRefDiv === className) {
      if (desc.length > 25) { // Html To Enable ToolTip
        this.referenceUtility.getTreeTemplatewithTooltip(this.referencesModel);
      } else { // Html without ToolTip
        this.referenceUtility.getTreeTemplateWithoutTooltip(this.referencesModel);
      }
    } else if (this.deleteOverlay && this.deleteOverlay === id + desc + stopID) {
      this.referenceUtility.finalizeDeleteOverlay(this.referencesModel);
    } else {
      if (desc.length > 25) { // Html with Tooltip
        this.referenceUtility.templateWithToolTip(this.referencesModel);
      } else { // Html withOut Tooptip
        this.referenceUtility.templateWithoutToolTip(this.referencesModel);
      }
    }
  }
  reloadOrderGetreferencesList() {
    const me = this;
    this.referenceGenerateTreeService.reloadOrderGetReferencesList(this, this.referencesModel, me);
  }
  ordrEdtDelShwHide(setiVal) {
    this.referencesModel.ordrEdtShw = setiVal;
  }
  stopEdtDel(sid, sDescriptn, srefNumbTypCode, sRefNumbrVal) {
    this.stopBtn.nativeElement.click();
    this.referencesModel.oldStopDesc = sDescriptn; // Used to get Obj in Stop Update
    this.referencesModel.srefNumberTypCode = srefNumbTypCode; // Used in stop edit update
    this.referencesModel.sRefNumbrValue = sRefNumbrVal; // Used in stop edit update
    this.referencesModel.stopEdtRefNumId = sid;
    this.referencesModel.pRefTypeFlag = false; // enabling ParRefType
    this.referencesModel.pRefValueFlag = false; // enabling ParRefVal

    if (this.pRefTypeValReference) { // Clearing active tag
      this.pRefTypeValReference.active = [];
    }
    this.referenceGenerateTreeService.stopEditAndDeleteLogic(this, this.referencesModel);
    this.enableSelect(this.referenceTypeDirectReference);
  }
  process(processObject, func) {
    const me = this;
    func(processObject);
    if (processObject.referenceNumberDTOs !== null) {
      processObject.referenceNumberDTOs.forEach(referenceNumberDTOs => {
        me.process(referenceNumberDTOs, func);
      });
    }
  }
  orderDel(index) {
    this.referenceUtility.orderDelete(this.referencesModel, index);
  }
  stopPermanentDel(sRefDelId, sRefDesc, stopIdDel) { // Stop delete function
    this.referenceGenerateTreeService.stopPermanentDeleteInReference(this, this.referencesModel, sRefDelId);
  }
  stopDeleteInVieworder() {
    this.referenceGenerateTreeService.stopDeleteInOrderview(this, this.referencesModel);
  }
  stopDel(sRefDelId, sRefDesc, stopIdDel, stopSequenceNumber, stopTypeVal, stopRefCode) { // overlay Enabling delete function
    this.referencesModel.valuesForStopDelete = {
      'stopIdDel': stopIdDel,
      'stopSequenceNumber': stopSequenceNumber,
      'stopRefCode': stopRefCode,
      'stopTypeVal': stopTypeVal,
      'sRefDelId': sRefDelId,
      'sRefDesc': sRefDesc
    };
    this.referenceGenerateTreeService.stopDeleteOverlay(this, this.referencesModel);
  }
  associatedParentRefOnSel($event, parReftype, stplevelValue) {
    this.referenceSupportService.associatedParentReferenceOnselect(this, this.referencesModel, parReftype, stplevelValue);
    this.disableSelect(this.associatedParentReferenceType);
  }
  orderEdtDel(index) {
    this.orderBtn.nativeElement.click();
    this.referenceUtility.performOrderEditDelete(this.referencesModel, index);
  }
  refTypeOnSel(event, reftype) {
    this.referenceUtility.referenceTypeOnselect(this.referencesModel, event);
    this.disableSelect(this.referenceTypeDirectReference);
  }
  stopLevelOnSel(event, stopLevel) {
    this.referenceSupportService.triggerStopLevelOnselect(this, this.referencesModel, event, stopLevel);
    this.stopLvlOnBlur(event, stopLevel);
    this.disableSelect(this.stopLevelNumber);
  }
  findOrderIndex() {
    this.referenceUtility.findOrderIndexForPatch(this.referencesModel);
  }
  saveReferences(event, refForm, reftype, refVal) {
    this.refTypeOnBlur(reftype.value);
    this.refValOnBlur(refVal.value);
    if (this.referencesModel.refTypeValidate === false && this.referencesModel.refValValidate === false) {
      event.preventDefault();
      this.referencesModel.editRefShow = false;
      if (!this.referencesModel.stopLvel) {
        this.referencesModel.stopLvel = 1;
      } else {
        this.referencesModel.stopLvel = this.referencesModel.stopLvel;
      }
      const refType = reftype.value;
      const refValTxt = refVal.value;
      const refNumTypeCode = this.referenceUtility.getParentReferenceTypeFromForm(this.referencesModel, refForm,
        this.pRefTypeValReference, refType);
      // Order Edit Update
      if (this.referencesModel.orderRefUpdate === true && this.referencesModel
        .stopSave === false && this.referencesModel.currentPage !== 'vieworder') {
        this.referenceSupportService.orderSaveInMocCall(this, this.referencesModel, refNumTypeCode);
      } else if (this.referencesModel.orderRefUpdate === false && this.referencesModel
        .stopSave === false && this.referencesModel.currentPage !== 'vieworder') { // Order create Save
        if (this.referencesModel.referencesList && this.referencesModel.referencesList.length !== 0) {
          this.referenceHelper.checkDuplicateOrderExists(this.referencesModel, refValTxt, refNumTypeCode);
          if (!this.referencesModel.orderReferenceDuplicateCheck) {
            const ordrParams = this.referenceHelper.getOrderParamForSave(this.referencesModel, refNumTypeCode, refValTxt);
            this.referencesService.SaveReference(this.jbhGlobals.endpoints
              .order.postReferencesType, ordrParams).subscribe(data => {
                const ordrCreatePost = data;
                if (ordrCreatePost) {
                  this.reloadOrderGetreferencesList();
                  this.referencesModel.oRefOval = null; // Clearing referenceValue Field
                  this.referenceTypeDirectReference.nativeElement.value = 'select';

                }
              });
          } else {
            this.jbhGlobals.notifications.alert('Warning', 'Duplicate Record Exists');
          }
        }
      } else if (this.referencesModel.orderRefUpdate === false && this.referencesModel
        .stopSave === false && this.referencesModel.currentPage === 'vieworder') { // Order create Save VIEWORDER
        if (this.referencesModel.referencesList && this.referencesModel.referencesList.length !== 0) {
          this.referenceHelper.checkDuplicateOrderVieworder(this.referencesModel, refValTxt, refNumTypeCode);
          if (!this.referencesModel.orderReferenceDuplicateCheck) {
            const orderParam = this.referenceHelper.getOrderParamValueForVieworder(this.referencesModel, refValTxt, refNumTypeCode);
            const url = this.jbhGlobals.endpoints.viewOrder.orderUpdate +
              this.referencesModel.currentOrderId + '/warningoverriden/' + false;
            this.viewOrderService.updateOrder(url, orderParam).subscribe(data => {
              this.reloadOrderGetreferencesList();
              this.viewOrderService.errorHandling(data);
            });
          } else {
            this.jbhGlobals.notifications.alert('Warning', 'Duplicate Record Exists');
          }
        }
      } else if (this.referencesModel.orderRefUpdate === true && this.referencesModel
        .stopSave === false && this.referencesModel.currentPage === 'vieworder') { // Order EDIT in VIEWORDER
        if (this.referencesModel.oRefId) {
          this.findOrderIndex(); // To get order Edited Index
          const orderParam = this.referenceHelper.getEditParamsForVieworder(this.referencesModel, refNumTypeCode);
          const url = this.jbhGlobals.endpoints.viewOrder.orderUpdate + this.referencesModel.currentOrderId + '/warningoverriden/' + false;
          this.viewOrderService.updateOrder(url, orderParam).subscribe(data => {
            this.reloadOrderGetreferencesList();
            this.viewOrderService.errorHandling(data);
            this.referenceHelper.clearUsedVariables(this.referencesModel);
          });
        }
      }
      this.referencesModel.stopEleRef = {
        refType: this.referenceTypeDirectReference,
        stopLevel: this.stopLevelNumber
      };
      // Stop save
      if (this.referencesModel.stopSave.toString() === true.toString() &&
        this.referencesModel.stopEdit.toString() === false.toString() &&
        this.referencesModel.stpLevelValidate === false) {
        this.stopSaveReferences(refNumTypeCode, refValTxt);
      } else if (this.referencesModel.stopEdit === true && this.referencesModel.stopSave !== false &&
        this.referencesModel.stpLevelValidate === false) { // For Stop edit
        this.stopEditReferencesCall(reftype, refVal, refForm);
      }
    }

  }
  stopEditReferencesCall(reftype, refVal, refForm) {
    const me = this;
    this.referencesModel.stopReferenceEditCallValues = {
      'reftype': reftype,
      'refVal': refVal,
      'refForm': refForm
    };
    this.referenceGenerateTreeService.stopReferenceEditCall(this, this.referencesModel, me);
  }
  stopAndIdsReady(refForm) {
    this.referenceGenerateTreeService.extractStopsAndIds(this, this.referencesModel, refForm);
  }
  stopEditReferenceIfCall(refForm) {
    this.referenceSupportService.editStopReferencesFinalizeCall(this, this.referencesModel, refForm);
  }
  extractStopUpdateIndex(finaliseCall) {
    this.referenceHelper.extractStopUpdateIndex(this, this.referencesModel, finaliseCall);
  }
  stopEditReferenceElseCall(refForm) {
    if (this.referencesModel.stopEdtRefNumId && this.referencesModel.sRefCode && this.referencesModel.sRefNumVal &&
      this.referencesModel.stpIDStopUpdate && !refForm.value.ParRefType) {
      //if (this.pRefTypeValReference.active.length !== 0) {
      const editStopParms = {
        'referenceNumberID': this.referencesModel.stopEdtRefNumId,
        'referenceNumberTypeCode': this.referencesModel.sRefCode,
        'referenceNumberValue': this.referencesModel.sRefNumVal,
        '@type': 'StopReferenceNumber'
      };
      this.referenceHelper.stopEditReferenceUpdateCall(this, this.referencesModel, editStopParms, refForm);
      //}
    }
  }
  stopSaveReferences(refNumTypeCode, refValTxt) {
    this.referencesModel.stopSaveReferencesValues = {
      'refNumTypeCode': refNumTypeCode,
      'refValTxt': refValTxt
    };
    this.referenceSupportService.stopSaveReferencesFinalize(this, this.referencesModel);
  }
  stopRefValueCodeAndPrefValReady(refNumTypeCode, refValTxt) {
    this.referenceHelper.StopReferenceValueAndParentValuesReady(this, this.referencesModel, refNumTypeCode, refValTxt);
  }
  undoDelReferenceSection() {
    this.referencesModel.showDeleteOverlay = null; // Showing deleteOverlay
    this.referencesModel.descriptionWrapper = null; // hiding Desc section
  }
  onCancel() {
    document.querySelector('body').appendChild(this.popInstance.deleteButtonModal._element.nativeElement);
    this.popInstance.deleteButtonModal.show();
  }
  onDelete(event) {
    if (event.flag) {
      this.referenceHelper.triggerOnDelete(this, this.referencesModel, event);
    } else {
      document.querySelector('body').removeChild(this.popInstance.deleteButtonModal._element.nativeElement);
      this.referencesModel.editRefShow = true; // To show cancel Btn on screen
      event.model.hide();
    }
  }
  permanentReferenceDelete(index) {
    this.referenceHelper.permanentDeleteReference(this, this.referencesModel, index);
  }
  disableSelect(field) {
    field.nativeElement.options[0].disabled = true;
  }
  enableSelect(field) {
    field.nativeElement.options[0].disabled = false;
    field.nativeElement.value = 'select';
  }
}
