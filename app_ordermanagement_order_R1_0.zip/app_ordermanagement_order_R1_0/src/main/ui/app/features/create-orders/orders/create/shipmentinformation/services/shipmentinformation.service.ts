import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Response } from '@angular/http';

import { JBHGlobals } from '../../../../../../app.service';

@Injectable()
export class ShipmentinformationService {

  constructor(public jbhGlobals: JBHGlobals) { }

  getOrderType(params): Observable<Response[]> {
    const url = this.jbhGlobals.endpoints.order.getordertype;
    return this.jbhGlobals.apiService.getData(url, params, false);
  }

  getSecOrderType(params): Observable<Response[]> {
    const url = this.jbhGlobals.endpoints.order.getSecOrderType;
    return this.jbhGlobals.apiService.getData(url, params, false);
  }

  getShipmentRequirement(): Observable<Response[]> {
    const url = this.jbhGlobals.endpoints.order.getshipmentrequirements;
    return this.jbhGlobals.apiService.getData(url, false);
  }

  getCarrierName(params): Observable<Response[]> {
    const url = this.jbhGlobals.endpoints.order.getCarrier;
    return this.jbhGlobals.apiService.getData(url, params, false);
  }

  getCustomsBroker(params): Observable<Response[]> {
    const url = this.jbhGlobals.endpoints.order.getcustomsbroker;
    return this.jbhGlobals.apiService.addData(url, params, false);
  }

  getClearingCustoms(params): Observable<Response[]> {
    const url = this.jbhGlobals.endpoints.order.getclearingcustoms;
    return this.jbhGlobals.apiService.getData(url, params);
  }

  getInternationalServices(params): Observable<Response[]> {
    const url = this.jbhGlobals.endpoints.order.getinternationalservices;
    return this.jbhGlobals.apiService.getData(url, params);
  }

  getBondHolderRole(params): Observable<Response[]> {
    const url = this.jbhGlobals.endpoints.order.getbondholderrole;
    return this.jbhGlobals.apiService.getData(url, params);
  }

  getBondHolderParty(params): Observable<Response[]> {
    const url = this.jbhGlobals.endpoints.order.getbondholderparty;
    return this.jbhGlobals.apiService.getData(url, params);
  }

  getBondHolderTypes(): Observable<Response[]> {
    const url = this.jbhGlobals.endpoints.order.getbondholdertype;
    return this.jbhGlobals.apiService.getData(url, false);
  }

  getPortOfExit(): Observable<Response[]> {
    const url = this.jbhGlobals.endpoints.order.getportofexit;
    return this.jbhGlobals.apiService.getData(url);
  }

  getPortOfEntryByExit(value): Observable<Response[]> {
    const url = this.jbhGlobals.endpoints.order.getportofentrybyexit + '/' + value;
    return this.jbhGlobals.apiService.getData(url);
  }

  getFleetCode(params): Observable<Response[]> {
    const url = this.jbhGlobals.endpoints.order.getfleetcode;
    return this.jbhGlobals.apiService.getData(url, params, false);
  }

  getOutSourcingFlag(params): Observable<Response[]> {
    const url = this.jbhGlobals.endpoints.order.getOutSourcingFlag;
    return this.jbhGlobals.apiService.getData(url, params);
  }

  getCreditStatus(url): Observable<Response[]> {
    return this.jbhGlobals.apiService
      .getData(url);
  }
}
