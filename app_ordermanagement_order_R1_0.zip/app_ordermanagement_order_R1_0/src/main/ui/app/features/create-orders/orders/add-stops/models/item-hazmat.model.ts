export class ItemHazmatModel {
    itemHazmatForm: any;
    hazmatSpecificData: any;
    subscription: any;
    orderData: any;
    stopData: any;
    handlingData: any;
    netExplosiveFlag = false;
    itemData: any;
    getUNNumberList: any[] = [];
    getHazmatData: any[];
    debounceValue: any;
    getProperShipping: any[];
    getPrimaryHzdList: any[];
    getSecondaryHazDetailsList: any[];
    getSecondaryHzdList: any[];
    getPackagingGroup: any[];
    properShippingTemp: any[];
    primaryHazmatTemp: any[];
    secondaryHazmatTemp: any[];
    packagingGroupTemp: any[];
    hazMatSpecification: any[] = [];
    itemWeightList: any[] = [];
    hazmatValueData: any[] = [];
    unnNo: any;
    stopItemHazardousMaterialDetails: any;
    hazMatSpecificationId: any;
    finalHazmatObj: any = {
        stopItemHazardousMaterialDetailID: '',
        driverCertificationRequiredIndicator: 'N',
        emergencyResponsePhoneNumber: '',
        hazardousMaterialSpecificationID: '',
        providerContractNumber: '',
        unitOfWeightMeasurementCode: '',
        netExplosiveMassQuantity: '',
        limitedQuantityIndicator: 'N',
        reportableQuantityIndicator: 'N',
        placardRequiredIndicator: 'N',
        hazardousMaterialTechnicalname: ''
    };
    valHaz = false;
    stopID: any;
    handlingUnitID: any;
    stopItemID: any;
    hazardMtrlId: any;
    isDataLoaded = true;
    itemHazmatData: any;
}
