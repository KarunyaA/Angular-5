import { inject, TestBed } from '@angular/core/testing';

import { ReferenceGenerateTreeService } from './reference-generate-tree.service';

describe('ReferenceGenerateTreeService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ReferenceGenerateTreeService]
    });
  });

  it('should be created', inject([ReferenceGenerateTreeService], (service: ReferenceGenerateTreeService) => {
    expect(service).toBeTruthy();
  }));
});
