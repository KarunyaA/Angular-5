import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { JBHGlobals } from 'app/app.service';

@Injectable()
export class ItemPackageService {
  sharingData: BehaviorSubject < any[] > ;

  constructor(public jbhGlobals: JBHGlobals) {
        this.sharingData = < BehaviorSubject < any[] >> new BehaviorSubject([]);
        this.init();
  }

  init(): void {
     const url = this.jbhGlobals.endpoints.order.getPackagingUnitType;
     const params = { 'page': 0, 'size': 200 };
     this.jbhGlobals.apiService.getData(url, params).subscribe(data => {
            this.saveData(data['_embedded']['packagingUnitTypes']);
     });
  }
  saveData(data): void {
       this.sharingData.next(data);
  }
  getData() {
      return this.sharingData.asObservable();
  }
}
