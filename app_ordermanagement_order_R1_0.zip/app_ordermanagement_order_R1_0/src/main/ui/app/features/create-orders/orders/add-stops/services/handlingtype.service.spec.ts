import { inject, TestBed } from '@angular/core/testing';

import { HandlingtypeService } from './handlingtype.service';

describe('HandlingtypeService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [HandlingtypeService]
    });
  });

  it('should be created', inject([HandlingtypeService], (service: HandlingtypeService) => {
    expect(service).toBeTruthy();
  }));
});
