import { Injectable } from '@angular/core';
import * as moment from 'moment';

import { JBHGlobals } from '../../../../../../app.service';

@Injectable()
export class AppointmentDetailsUtilsService {

  startFlagState: boolean;
  endFlagState: boolean;

  constructor(public jbhGlobals: JBHGlobals) { }

  validateApptDateTime(startTime, endTime, apptStartDate, apptEndDate, apptFieldName, appointmentDetailsModel,
    appointmentForm): boolean {
    let isSave = true;
    let apptStartTime;
    let apptEndTime;
    if (!apptStartDate) {
      appointmentDetailsModel.apptStartDate = this.getDateValue(appointmentForm.controls['appointmentStartDate'].value);
    } else {
      appointmentDetailsModel.apptStartDate = apptStartDate;
    }
    if (!apptEndDate) {
      appointmentDetailsModel.apptEndDate = this.getDateValue(appointmentForm.controls['appointmentEndDate'].value);
    } else {
      appointmentDetailsModel.apptEndDate = apptEndDate;
    }
    if (!startTime) {
      apptStartTime = appointmentForm.controls['appointmentStartTimestamp'].value;
    } else {
      apptStartTime = startTime;
    }
    if (!endTime) {
      apptEndTime = appointmentForm.controls['appointmentEndTimestamp'].value;
    } else {
      apptEndTime = endTime;
    }
    if (appointmentDetailsModel.apptStartDate && appointmentDetailsModel.apptEndDate && apptStartTime && apptEndTime) {
      if (appointmentDetailsModel.apptEndDate === appointmentDetailsModel.apptStartDate && !(apptEndTime > apptStartTime)) {
        this.jbhGlobals.notifications.alert('Warning', 'End time must be greater than Start time');
        appointmentForm.controls['appointmentEndTimestamp'].setValue(null);
        isSave = false;
      } else if (apptEndTime === apptStartTime) {
        isSave = true;
        if (moment(appointmentDetailsModel.apptEndDate).diff(appointmentDetailsModel.apptStartDate) < 0) {
          if (apptFieldName === 'appointmentEndTimestamp') {
            this.jbhGlobals.notifications.alert('Warning', 'End date must be greater than Start date');
            appointmentForm.controls['appointmentEndTimestamp'].setValue(null);
            // appointmentDetailsModel.endTimeMeridian = false;
            appointmentForm.controls['appointmentEndDate'].setValue(null);
            appointmentDetailsModel.endDate = null;
            appointmentDetailsModel.endTime = null;
            isSave = false;
          }
          if (apptFieldName === 'appointmentStartTimestamp') {
            this.jbhGlobals.notifications.alert('Warning', 'Start date must be less than or equal to end date');
            appointmentDetailsModel.startDate = null;
            appointmentForm.controls['appointmentStartTimestamp'].setValue(null);
            // appointmentDetailsModel.endTimeMeridian = false;
            appointmentForm.controls['appointmentStartDate'].setValue(null);
            appointmentDetailsModel.startTime = null;
            isSave = false;
          }
        }
      } else if (appointmentDetailsModel.apptEndDate !== undefined &&
        moment(appointmentDetailsModel.apptEndDate).diff(appointmentDetailsModel.apptStartDate) < 0) {
        if (apptFieldName === 'appointmentStartTimestamp') {
          this.jbhGlobals.notifications.alert('Warning', 'Start date must be less than or equal to end date');
          appointmentDetailsModel.startDate = null;
          appointmentForm.controls['appointmentStartTimestamp'].setValue(null);
          // appointmentDetailsModel.endTimeMeridian = false;
          appointmentForm.controls['appointmentStartDate'].setValue(null);
          appointmentDetailsModel.startTime = null;
        } else {
          this.jbhGlobals.notifications.alert('Warning', 'End date must be greater than Start date');
          appointmentForm.controls['appointmentEndTimestamp'].setValue(null);
          // appointmentDetailsModel.endTimeMeridian = false;
          appointmentForm.controls['appointmentEndDate'].setValue(null);
          appointmentDetailsModel.endDate = null;
          appointmentDetailsModel.endTime = null;
        }
        isSave = false;
      }
    } else if (!(appointmentDetailsModel.apptStartDate < appointmentDetailsModel.apptEndDate)) {
      isSave = this.validateDate(apptFieldName, appointmentDetailsModel, appointmentForm);
    }
    return isSave;
  }

  validateDate(apptFieldName, appointmentDetailsModel, appointmentForm): boolean {
    let isSave = true;
    if (apptFieldName === 'appointmentEndDate') {
      if (appointmentDetailsModel.apptEndDate !== undefined && appointmentDetailsModel.apptStartDate !== undefined &&
        !(appointmentDetailsModel.apptEndDate >= appointmentDetailsModel.apptStartDate)) {
        this.jbhGlobals.notifications.alert('Warning', 'End date must be greater than or equal to Start date');
        isSave = false;
        appointmentDetailsModel.endDate = null;
      }
    } else {
      if (appointmentDetailsModel.apptEndDate !== undefined && appointmentDetailsModel.apptStartDate !== undefined &&
        !(appointmentDetailsModel.apptStartDate < appointmentDetailsModel.apptEndDate)) {
        this.jbhGlobals.notifications.alert('Warning', 'Start date must be lesser than or equal to end date');
        appointmentDetailsModel.startDate = null;
        isSave = false;
      }
    }
    return isSave;
  }

  getDateValue(dateValue): string {
    let inputDate = dateValue;
    if (inputDate && inputDate !== undefined) {
      inputDate = inputDate.date.month + '-' + inputDate.date.day + '-' + inputDate.date.year;
      return moment(inputDate).format('MM-DD-YYYY');
    }
    return;
  }

  setStartTimeToZero(appointmentDetailsModel: object): void {
    appointmentDetailsModel['myStartTime'] = this.setInitialTime();
    appointmentDetailsModel['apptStartTime'] = moment(appointmentDetailsModel['myStartTime']).format('HH:mm');
    appointmentDetailsModel['startTime'] = '';
    // appointmentDetailsModel['startTimeMeridian'] = false;
  }

  setEndTimeToZero(appointmentDetailsModel: object): void {
    appointmentDetailsModel['myEndTime'] = this.setInitialTime();
    appointmentDetailsModel['apptEndTime'] = moment(appointmentDetailsModel['myEndTime']).format('HH:mm');
    appointmentDetailsModel['endTime'] = '';
    // appointmentDetailsModel['endTimeMeridian'] = false;
  }

  setInitialTime(): any {
    const initialTime = new Date();
    initialTime.setHours(0);
    initialTime.setMinutes(0);
    return initialTime;
  }

  timeValidator(appointmentDetailsModel, time, key): void {
    const hour = Number(moment(time).format('HH'));
    const minute = Number(moment(time).format('mm'));
    if ((hour === 0 && minute === 0)) {
      switch (key) {
        case 'Start':
          appointmentDetailsModel.myStartTime = this.setInitialTime();
          break;
        case 'End':
          appointmentDetailsModel.myEndTime = this.setInitialTime();
          break;
        default:
      }
    } else {
      this.conditonalValidator(appointmentDetailsModel, time, key);
    }
  }

  conditonalValidator(appointmentDetailsModel, myTime, key): void {
    switch (key) {
      case 'Start':
        appointmentDetailsModel.myStartTime = this.hoursMinsSetter(myTime, key);
        break;
      case 'End':
        appointmentDetailsModel.myEndTime = this.hoursMinsSetter(myTime, key);
        break;
      default:
    }
  }

  hoursMinsSetter(time, key) {
    let hour = Number(moment(time).format('HH'));
    let minute = Number(moment(time).format('mm'));
    hour = hour !== 0 ? hour : 0;
    minute = minute !== 0 ? minute : 0;
    const setTime = new Date();
    setTime.setHours(hour);
    setTime.setMinutes(minute);
    return setTime;
  }

  setStartFlag(value): void {
    this.startFlagState = false;
    if (value) {
      this.startFlagState = value;
    }
  }

  setEndFlag(value): void {
    this.endFlagState = false;
    if (value) {
      this.endFlagState = value;
    }
  }

  getStartFlag(): boolean {
    return this.startFlagState;
  }

  getEndFlag(): boolean {
    return this.endFlagState;
  }

  setTimeOnForm(date: string, time: string, dateType: string) {
    const hour = time.slice(0, 2);
    const minute = time.slice(3, 5);
    const setDate = new Date(date);
    const hours = Number(hour);
    const minutes = Number(minute);
    setDate.setHours(hours);
    setDate.setMinutes(minutes);
    if (hour !== '00' || minute !== '00') {
      if (dateType === 'Start Date') {
        this.setStartFlag(true);
      }
      if (dateType === 'End Date') {
        this.setEndFlag(true);
      }
    }
    return setDate;
  }

  setMeridiansStart(appointmentDetailsModel) {
    if (this.getStartFlag()) {
      // appointmentDetailsModel.startTimeMeridian = true;
      // appointmentDetailsModel.endTimeMeridian = true;
    }
  }
}
