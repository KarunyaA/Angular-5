import { Injectable, OnInit } from '@angular/core';
import { JBHGlobals } from '../../../../../../app.service';
import { ReferencesService } from './references.service';
@Injectable()
export class ReferenceGenerateTreeService {
  jsonpatch: any;
  constructor(private jbhGlobals: JBHGlobals) { }

  generateReferenceTree(parentScope, referencesModel, me) {
    referencesModel.uniqueStopIndex = 1; // For uniqueStop Attribute
    if (referencesModel.obj && referencesModel.obj.length !== 0) {
      // const me = me;
      referencesModel.tree = '<ul>';
      for (let i = 0; i < referencesModel.obj.Stop.length; i++) {
        if (referencesModel.obj.Stop[i].referenceNumberTypeDescription) {
          parentScope.frameLi(referencesModel.obj.Stop[i].referenceNumberTypeDescription,
            referencesModel.obj.Stop[i].referenceNumber.referenceNumberID, 0, referencesModel.obj.Stop[i].stopID,
            referencesModel.obj.Stop[i].referenceNumber
              .referenceNumberTypeCode, referencesModel.obj.Stop[i].referenceNumber.referenceNumberValue, referencesModel.uniqueStopIndex++,
            referencesModel.obj.Stop[i].stopSequenceNumber
          );
          parentScope.extractDTO(referencesModel.obj.Stop[i].referenceNumberDTOs, me.referencesModel.indent + 10);
        }
      }
      referencesModel.tree = referencesModel.tree + '</ul>';
      parentScope.treeContainer.nativeElement.insertAdjacentHTML('beforeend', referencesModel.tree);
      const editlist = parentScope.treeContainer.nativeElement.querySelectorAll('.stopEdtBtn');
      for (let i = 0; i < editlist.length; i++) {
        editlist[i].addEventListener('click', function (event) {
          parentScope.sIdEdtRef = event.target.getAttribute('data-desc-attr').split('--')[0];
          parentScope.sDescEdtRef = event.target.getAttribute('data-desc-attr').split('--')[1];
          parentScope.srefNumbTypCode = event.target.getAttribute('data-desc-attr').split('--')[4];
          parentScope.sRefNumbrVal = event.target.getAttribute('data-desc-attr').split('--')[5];
          if (parentScope.sIdEdtRef && parentScope.sDescEdtRef) {
            me.stopEdtDel(parentScope.sIdEdtRef, parentScope.sDescEdtRef, parentScope.srefNumbTypCode, parentScope.sRefNumbrVal);
          }
        });
      }
      const deleteList = parentScope.treeContainer.nativeElement.querySelectorAll('.stopDelBtn');
      for (let i = 0; i < deleteList.length; i++) {
        deleteList[i].addEventListener('click', function (event) {
          parentScope.sIdDelRef = event.target.getAttribute('data-desc-attr').split('--')[0];
          parentScope.sDescDelRef = event.target.getAttribute('data-desc-attr').split('--')[1];
          parentScope.stpIdDelRef = event.target.getAttribute('data-desc-attr').split('--')[2];
          parentScope.stopLevelOvderView = event.target.getAttribute('data-desc-attr').split('--')[6];
          parentScope.srefNumbTypValForDel = event.target.getAttribute('data-desc-attr').split('--')[4];
          parentScope.sRefNumbrCodeForDel = event.target.getAttribute('data-desc-attr').split('--')[3];
          if (parentScope.sIdDelRef && parentScope.sDescDelRef && parentScope.stpIdDelRef) {
            // Stop Delete Triggered here
            me.stopDel(parentScope.sIdDelRef, parentScope.sDescDelRef, parentScope.stpIdDelRef,
              parentScope.stopLevelOvderView, parentScope.srefNumbTypValForDel, parentScope.sRefNumbrCodeForDel
            );
          }
        });
      }
      const listDivs = parentScope.treeContainer.nativeElement.querySelectorAll('.child-li');
      for (let h = 0; h < listDivs.length; h++) {
        listDivs[h].addEventListener('click', function (event) {
          if (event.target.getAttribute('data-desc-attr')) {
            me.referencesModel.selRefDiv = event.target.getAttribute('data-desc-attr').toString();
          }
          const tree = document.getElementsByClassName('stopReftree');
          tree[0].innerHTML = '';
          me.referencesModel.indent = 0;
          me.generateTree();
        });
      }
      const tooltipDiv = parentScope.treeContainer.nativeElement.querySelectorAll('.ref-list');
      for (let k = 0; k < tooltipDiv.length; k++) {
        tooltipDiv[k].addEventListener('mouseover', function (event) {
          for (let g = 0; g < document.getElementsByClassName('refTooltip').length; g++) {
            const valOne = event.target.getAttribute('data-desc-attr');
            const valTwo = document.getElementsByClassName('refTooltip')[g].getAttribute('tooltiphlper');
            if (valOne === valTwo) {
              const parentElement = document.getElementsByClassName('refTooltip')[g];
              me.addClass(parentElement, 'refDivShow');
            }
          }
        });
      }
      const undoOverlay = parentScope.treeContainer.nativeElement.querySelectorAll('.undoOverlay');
      for (let k = 0; k < undoOverlay.length; k++) {
        undoOverlay[k].addEventListener('click', function (event) {
          me.deleteOverlay = null; // setting overlay to normal
          const tree = document.getElementsByClassName('stopReftree');
          tree[0].innerHTML = '';
          me.referencesModel.indent = 0;
          me.generateTree();
        });
      }
      const permanentDeleteComment = parentScope.treeContainer.nativeElement.querySelectorAll(
        '.permanentDeleteComment');
      for (let k = 0; k < permanentDeleteComment.length; k++) {
        permanentDeleteComment[k].addEventListener('click', function (event) {
          this.sIdDelRef = event.target.getAttribute('data-desc-attr').split('--')[0];
          this.sDescDelRef = event.target.getAttribute('data-desc-attr').split('--')[1];
          this.stpIdDelRef = event.target.getAttribute('data-desc-attr').split('--')[2];
          if (this.sIdDelRef && this.sDescDelRef && this.stpIdDelRef) {
            // Stop Delete Triggered here
            me.stopPermanentDel(this.sIdDelRef, this.sDescDelRef, this.stpIdDelRef);
          }
          const tree = document.getElementsByClassName('stopReftree');
          tree[0].innerHTML = '';
          me.referencesModel.indent = 0;
          me.generateTree();
        });
      }
      const tooltipRemove = parentScope.treeContainer.nativeElement.querySelectorAll('.ref-list');
      for (let k = 0; k < tooltipRemove.length; k++) {
        tooltipRemove[k].addEventListener('mouseleave', function (event) {
          for (let g = 0; g < document.getElementsByClassName('refTooltip').length; g++) {
            const valOne = event.target.getAttribute('data-desc-attr');
            const valTwo = document.getElementsByClassName('refTooltip')[g].getAttribute('tooltiphlper');
            if (valOne === valTwo) {
              const parentElement = document.getElementsByClassName('refTooltip')[g];
              me.removeClass(parentElement, 'refDivShow');
            }
          }
        });
      }
    }
  }

  callAddClass(parentScope, element, className) {
    if (element.classList) {
      element.classList.add(className);
    } else if (!parentScope.hasClass(element, className)) {
      element.className += ' ' + className;
    } else { }
  }

  callremoveClass(parentScope, element, className) {
    if (element.classList) {
      element.classList.remove(className);
    } else if (parentScope.hasClass(element, className)) {
      const reg = new RegExp('(\\s|^)' + className + '(\\s|$)');
      element.className = element.className.replace(reg, ' ');
    } else { }
  }

  triggerStopSaveForReferences(parentScope, referencesModel, element) {
    parentScope.reloadReferencesType();
    referencesModel.stopSave = true;
    referencesModel.oRefOval = null;
    referencesModel.parntRefDisplay = true;
    element.target.classList.add('active');
    element.target.previousElementSibling.classList.remove('active');
    parentScope.resetValidators(); // Resetting Validators
  }

  getReferencesList(parentScope, referencesModel, me) {
    referencesModel.orderRefLst = referencesModel.referencesList.Order;
    referencesModel.stopsRefLst = referencesModel.referencesList.Stop;
    referencesModel.obj = referencesModel.referencesList; // Used for stopRef TreeFraming
    const tree = document.getElementsByClassName('stopReftree');
    if (referencesModel.referencesList.Stop) {
      tree[0].innerHTML = '';
      me.referencesModel.indent = 0;
      parentScope.generateTree();
      me.referencesModel.orderRefLstz = [];
      if (referencesModel.stopsRefLst.length !== 0) {
        for (let y = 0; y < referencesModel.stopsRefLst.length; y++) {
          parentScope.process(referencesModel.stopsRefLst[y], function (object) {
            if (object.referenceNumberTypeDescription && object.referenceNumber.referenceNumberValue) {
              me.referencesModel.orderRefLstz.push(object);
            }
          });
        }
      }
      if (!referencesModel.stopsRefLst) { // clearing view on Last Deleted Stopreference
        tree[0].innerHTML = '';
      }
    }
  }

  reloadOrderGetReferencesList(parentScope, referencesModel, me) {
    parentScope.referencesService.loadReferences(this.jbhGlobals.endpoints.order.getreferencesList +
      referencesModel.currentOrderId + '/referencenumbers').subscribe(data => {
        referencesModel.referencesList = data;
        if (referencesModel.referencesList && referencesModel.referencesList.length !== 0) {
          referencesModel.orderRefLst = referencesModel.referencesList.Order;
          me.referencesModel.orderRefLstz = [];
          if (referencesModel.stopsRefLst) {
            for (let y = 0; y < referencesModel.stopsRefLst.length; y++) {
              parentScope.process(referencesModel.stopsRefLst[y],
                function (object) {
                  if (object.referenceNumberTypeDescription && object.referenceNumber.referenceNumberValue) {
                    me.referencesModel.orderRefLstz.push(object);
                  }
                });
            }
          }
        }
      });
  }

  stopDeleteInOrderview(parentScope, referencesModel) {
    const stopParamsForPatch = {
      'order': [{
        'op': 'remove',
        'path': '/stops/' + referencesModel.deleteSequenceNumber +
        '/stopReferenceNumbers/' + referencesModel.stopEditPatchIndex +
        '/referenceNumberValue'
      }]
    };
    const url = this.jbhGlobals.endpoints.viewOrder.orderUpdate + referencesModel.currentOrderId + '/warningoverriden/' + false;
    if (referencesModel.deleteSequenceNumber && referencesModel.stopEditPatchIndex) {
      parentScope.viewOrderService.updateOrder(url, stopParamsForPatch).subscribe(data => {
        parentScope.reloadStopReferenceList();
        // resetting Parent type & Val datas on delete
        if (parentScope.stopLevelNumber) {
          parentScope.stopLevelOnSel(parentScope.stopLevelNumber.nativeElement.value,
            parentScope.stopLevelNumber.nativeElement.value);
        }
      });
    }
  }

  stopDeleteOverlay(parentScope, referencesModel) {
    referencesModel.selectedStopId = referencesModel.valuesForStopDelete.stopIdDel; // StopId used in Vieworder
    referencesModel.deleteSequenceNumber = referencesModel.valuesForStopDelete.stopSequenceNumber; // level Number Used in ViewOrderDelete
    referencesModel.stopReferenceCode = referencesModel.valuesForStopDelete.stopRefCode;
    referencesModel.stopReferencevalue = referencesModel.valuesForStopDelete.stopTypeVal;
    // Logic to Enable delete overlay
    parentScope.deleteOverlay = referencesModel.valuesForStopDelete.sRefDelId + referencesModel.valuesForStopDelete.sRefDesc +
      referencesModel.valuesForStopDelete.stopIdDel;
    const tree = document.getElementsByClassName('stopReftree');
    tree[0].innerHTML = '';
    referencesModel.indent = 0;
    parentScope.generateTree();
  }

  stopEditForViewOrderCall(parentScope, referencesModel, editStopParams, refForm) {
    parentScope.extractStopUpdateIndex(null); // To get order Edited Index
    const stopPatchLevel = Number(referencesModel.edtSelNum) - 1;
    const orderParam = {
      'order': [{
        'op': 'replace',
        'path': '/stops/' + stopPatchLevel + '/stopReferenceNumbers/' + referencesModel.stopEditPatchIndex +
        '/referenceNumberValue',
        'value': editStopParams
      }]
    };
    const url = this.jbhGlobals.endpoints.viewOrder.orderUpdate + referencesModel.currentOrderId + '/warningoverriden/' + false;
    parentScope.viewOrderService.updateOrder(url, orderParam).subscribe(data => {
      this.jbhGlobals.notifications.alert('Warning', referencesModel.newStopRef); // responce message
      parentScope.reloadStopReferenceList();
      referencesModel.stopEdit = false;
      referencesModel.stopEdtRefNumId = null;
      referencesModel.sRefCode = null;
      referencesModel.sRefNumVal = null;
      referencesModel.stpAssociatRefNumbid = null;
      referencesModel.oRefOval = null; // resetting refType
      // Below Variables used in stopIndex Srch Logic
      referencesModel.srefNumberTypCode = null;
      referencesModel.stopReferenceCode = null;
      referencesModel.sRefNumbrValue = null;
      referencesModel.stopReferencevalue = null;
      refForm.value.ParRefType = null;
      refForm.value.pRefVal = null;
    });
  }

  stopReferenceEditCall(parentScope, referencesModel, me) {
    parentScope.referencesService.loadReferences(this.jbhGlobals.endpoints.order.getreferencesList +
      referencesModel.currentOrderId + '/referencenumbers').subscribe(data => {
        referencesModel.referencesList = data;
        if (referencesModel.referencesList && referencesModel.referencesList.length !== 0) {
          me.referencesModel.orderRefLstz = []; // Emptying Processed Single level Array
          if (referencesModel.referencesList.Stop && referencesModel.referencesList.Stop.length !== 0) {
            for (let y = 0; y < referencesModel.referencesList.Stop.length; y++) {
              parentScope.process(referencesModel.referencesList.Stop[y],
                function (object) {
                  if (object.referenceNumberTypeDescription &&
                    object.referenceNumber.referenceNumberValue) {
                    me.referencesModel.orderRefLstz.push(object);
                  }
                });
            }
          }
        }
        if (referencesModel.orderRefLstz && referencesModel.orderRefLstz.length !== 0) {
          const valLen = parentScope.referenceHelper.getstopEditIdNReferenceId(referencesModel);
          parentScope.referencesService.getReferencesTypeAndValue(this.jbhGlobals
            .endpoints.order.getReferenceTypeValueCommon, valLen).subscribe(data8 => {
              referencesModel.getreferencesType = data8;
              if (referencesModel.getreferencesType && referencesModel.getreferencesType._embedded.referenceNumberTypes) {
                referencesModel.refTypeAndVals = this.jbhGlobals.utils.find(referencesModel.getreferencesType
                  ._embedded.referenceNumberTypes, {
                    'referenceNumberTypeDescription': referencesModel.stopReferenceEditCallValues.reftype.value
                  });
                if (referencesModel.refTypeAndVals) {
                  referencesModel.sRefCode = referencesModel.refTypeAndVals.referenceNumberTypeCode;
                  referencesModel.sRefNumVal = referencesModel.stopReferenceEditCallValues.refVal.value; // NEW referenceNumberValue
                  if (referencesModel.stopNIds && referencesModel.stopNIds.length !== 0 && referencesModel.edtSelNum) {
                    parentScope.stopAndIdsReady(referencesModel.stopReferenceEditCallValues.refForm);
                  }
                }
              }
            });
        }
      });
  }

  extractStopsAndIds(parentScope, referencesModel, refForm) {
    for (let f = 0; f < referencesModel.stopNIds.length; f++) {
      if (referencesModel.stopNIds[f].stop.stopID !== null) {
        if (referencesModel.stopNIds[f].stop.stopSequenceNumber.toString() === referencesModel.edtSelNum.toString()) {
          referencesModel.stpIDStopUpdate = referencesModel.stopNIds[f].stop.stopID; // StopID used in URL
          if (referencesModel.stpIDStopUpdate) { // Srch For Associatd Ref
            if (referencesModel.stpIDStopUpdate && refForm.value.ParRefType &&
              parentScope.pRefTypeValReference) { // FinalisingUpdatecallUrl
              if (parentScope.pRefTypeValReference.active.length !== 0) {
                parentScope.stopEditReferenceIfCall(refForm); // If ParentValues
              }
            } else {
              parentScope.stopEditReferenceElseCall(refForm); // if NO ParentValues
            }
          }
        }
      }
    }
  }

  stopEditAndDeleteLogic(parentScope, referencesModel) {
    referencesModel.processStopDeleteValues = {
      'sid': referencesModel.stopEdtRefNumId,
      'sDescriptn': referencesModel.oldStopDesc,
      'srefNumbTypCode': referencesModel.srefNumberTypCode,
      'sRefNumbrVal': referencesModel.sRefNumbrValue,
      'pRefTypeValReference': parentScope.pRefTypeValReference
    };
    parentScope.referenceUtility.assignReferenceValues(referencesModel);
    if (referencesModel.stopSave === true) {
      parentScope.referenceUtility.processStopDelete(referencesModel);
      // Edit Logic Ends
      if (referencesModel.sSeqNum) { //  setting associated parent type
        if (referencesModel.stopNIds && referencesModel.stopNIds.length !==
          0 && referencesModel.sSeqNum) {
          parentScope.referenceUtility.getStopAssiciatedIdnumber(referencesModel);
        }
        if (referencesModel.stpIDForAssoRefNum) {
          parentScope.referencesService.getParentReferences(this.jbhGlobals.endpoints
            .order.getAssociatedRefNVals + referencesModel.stpIDForAssoRefNum +
            '/referencenumbertypes?associatedparentflag=true').subscribe(data => {
              referencesModel.associatedRefArr = data;
              parentScope.referenceUtility.initiateSaveCallForreferences(referencesModel);
            });
        }
      }
    }
  }

  extractDtoForListGeneration(parentScope, referencesModel, dto, indentVal) {
    if (dto) {
      referencesModel.tree = referencesModel.tree + '<ul>';
      for (let i = 0; i < dto.length; i++) {
        if (dto[i].referenceNumberTypeDescription && dto[i].referenceNumber.referenceNumberID && dto[i].stopID) {
          parentScope.frameLi(dto[i].referenceNumberTypeDescription, dto[i].referenceNumber
            .referenceNumberID, indentVal, dto[i].stopID, dto[i].referenceNumber.referenceNumberTypeCode,
            dto[i].referenceNumber.referenceNumberValue, referencesModel.uniqueStopIndex++, dto[i].stopSequenceNumber);
        }
        if (dto[i].referenceNumberDTOs) {
          referencesModel.indent = referencesModel.indent + 10;
          parentScope.extractDTO(dto[i].referenceNumberDTOs, referencesModel.indent + 10);
        }
      }
      referencesModel.tree = referencesModel.tree + '</ul>';
    }
  }

  reloadReferenceTypes(parentScope, referencesModel) {
    const valLen = {
      'page': 0,
      'size': 500
    };
    parentScope.referencesService.getReferencesTypeAndValue(this.jbhGlobals.endpoints
      .order.getReferenceTypeValueCommon, valLen).subscribe(data => {
        referencesModel.getreferencesType = data;
        if (referencesModel.getreferencesType && referencesModel.getreferencesType.length !== 0) {
          parentScope.getReferencesType();
        }
      });
  }

  setOrderSaveFlag(parentScope, referencesModel, element) {
    parentScope.getReferencesType();
    referencesModel.stopSave = false;
    referencesModel.parntRefDisplay = false;
    element.target.classList.add('active');
    element.target.nextElementSibling.classList.remove('active');
    parentScope.resetValidators(); // Resetting Validators
  }

  stopPermanentDeleteInReference(parentScope, referencesModel, sRefDelId) {
    const delObjId = sRefDelId;
    if (referencesModel.currentPage !== 'vieworder') {
      parentScope.referencesService.deleteReference(this.jbhGlobals.endpoints.order.deleteStopRef +
        delObjId).subscribe(data => {
          parentScope.reloadStopReferenceList();
          // resetting Parent type & Val datas on delete
          if (parentScope.stopLevelNumber) {
            parentScope.stopLevelOnSel(parentScope.stopLevelNumber.nativeElement.value,
              parentScope.stopLevelNumber.nativeElement.value);
          }
        });
    } else if (parentScope.referencesModel.currentPage === 'vieworder') { // Delete Stop VIEWORDER
      const finaliseCall = 'delete';
      parentScope.extractStopUpdateIndex(finaliseCall); // To get order Edited Index
    }
  }

}
