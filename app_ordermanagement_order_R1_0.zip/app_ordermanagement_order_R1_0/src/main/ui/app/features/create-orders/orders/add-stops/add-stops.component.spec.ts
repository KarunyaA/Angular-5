/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { By } from '@angular/platform-browser';
import { DebugElement, NO_ERRORS_SCHEMA } from '@angular/core';
import { AddStopsModule } from './add-stops.module';
import { OrdersModule } from '../orders.module';
import { CreateOrdersModule } from '../../create-orders.module';
import { AddStopsComponent } from './add-stops.component';
import { AppModule } from '../../../../app.module';

describe('AddStopsComponent', () => {
  let component: AddStopsComponent;
  let fixture: ComponentFixture<AddStopsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
                  AppModule,
                  RouterTestingModule,
                  CreateOrdersModule,
                  AddStopsModule,
                  OrdersModule
               ],
      declarations: [],
      providers: [],
      schemas: [NO_ERRORS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddStopsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
