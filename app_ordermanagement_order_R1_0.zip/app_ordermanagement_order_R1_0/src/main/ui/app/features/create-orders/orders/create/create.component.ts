import {
    Component,
    OnDestroy,
    OnInit,
    ViewChild
} from '@angular/core';
import {
    Router
} from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { JBHGlobals } from './../../../../app.service';
import { OrderService } from './../services/order.service';
import { OrderFormBuilderService } from '../services/order-form-builder.service';
import { CreateService } from './services/create.service';

@Component({
    selector: 'app-create',
    templateUrl: './create.component.html',
    styleUrls: ['./create.component.scss'],
    providers: []
})

/*
  CreateComponent - is a form contains list of child components like account information, operation information, service offering
                     and shipment information.
                  - On form submit navigates to add stop with OrderDto data.
*/
export class CreateComponent implements OnInit, OnDestroy {
    @ViewChild('accountInformation') accountInformation;
    @ViewChild('serviceOffering') serviceOffering;
    @ViewChild('shipmentInformation') shipmentInformation;
    @ViewChild('operationInformation') operationInformation;
    @ViewChild('deleteButton') deleteButton;
    @ViewChild('nextButton') nextButton;
    @ViewChild('cancelDialog') cancelDialog;

    sub: any;
    equipdata: any;
    errorMessage: string;
    subscription: any;
    orderData: any;

    constructor(private orderFormBuilder: OrderFormBuilderService,
        private route: ActivatedRoute,
        private jbhGlobals: JBHGlobals,
        private orderService: OrderService,
        private createService: CreateService,
        private router: Router) { }

    ngOnInit(): void {
        this.orderService.saveData([]);
        this.orderService.loadOrder(this.route.snapshot.queryParams.id);
        this.loadOrderData();
        this.setUpKeyboardShortcuts();
    }

    ngOnDestroy(): void {
        this.subscription.unsubscribe();
    }

    setUpKeyboardShortcuts() {
        this.jbhGlobals.shortkeys.getData().subscribe(data => {
            if (data.keyCode === 'alt+1') {
                this.accountInformation.billingDetailsRadio.nativeElement.focus();
                window.scrollTo(0, 0);
            } else if (data.keyCode === 'alt+2') {
                this.serviceOffering.businessunitTag.element.nativeElement.focus();
            } else if (data.keyCode === 'alt+3') {
                this.shipmentInformation.shipmentIdentificationNumber.nativeElement.focus();
            } else if (data.keyCode === 'alt+4') {
                this.operationInformation.trailerequipment.nativeElement.focus();
            } else if (data.keyCode === 'alt+Delete' || data.keyCode === 'alt+Del') {
                this.deleteButton.nativeElement.focus();
            } else if (data.keyCode === 'alt+ArrowRight' || data.keyCode === 'alt+Right') {
                this.nextButton.nativeElement.focus();
            } else if (data.keyCode === 'alt+n') {
                const activeId = document.activeElement.id;
                document.getElementById(activeId).click();
            } else { }
        });
    }

    loadOrderData() {
        this.subscription = this.orderService.getData().subscribe(data => {
            this.orderData = data;
        });
    }

    onCancelOrder(): void {
        const url = this.jbhGlobals.endpoints.order.cancelorder + this.orderData.orderID + '/cancel';
        const params = {
            'orderStatusEventComment': null,
            'orderStatusEventReasonDescription': 'Cancel Of Data Entry'
        };
        this.jbhGlobals.apiService.updateData(url, params).subscribe((response: any) => {
            this.accountInformation.orderBillingDetail.reset();
            this.serviceOffering.serviceOfferingDetail.reset();
            this.shipmentInformation.shipmentInformation.reset();
            this.operationInformation.operationInformationDetail.reset();
            this.cancelDialog.hide();
            this.jbhGlobals.notifications.success('Order', 'Order deleted successfully!');
            this.router.navigateByUrl('/createorders/template');
        });
    }

    onSave(): void {
        this.callEquipmentsSave();
        this.orderService.saveOrder(this.orderData).subscribe((response: any) => {
            this.jbhGlobals.logger.info('Save Response');
            this.jbhGlobals.notifications.success('Order', 'Order Data Saved.');
        });
    }
    callEquipmentsSave() {
        if (this.orderData.financeBusinessUnitCode === 'ICS') {
            if (this.orderData.serviceOfferingCode !== 'LTL') {
                this.saveEquipmentDetails();
            }
        } else if (this.orderData.financeBusinessUnitCode === 'DCS') {
            if (this.orderData.serviceOfferingCode !== 'FinalMile') {
                this.saveEquipmentDetails();
            }
        } else {
            this.saveEquipmentDetails();
        }
    }
    onSubmit(): void {
        const accInfoForm = this.accountInformation.orderBillingDetail['controls']['accountInfoForm'];
        if (!this.jbhGlobals.utils.isEmpty(accInfoForm.controls['lineofBusiness'].value)) {
            accInfoForm.controls['billToCode'].setValidators([]);
            accInfoForm.controls['billToCode'].updateValueAndValidity({ onlySelf: true, emitEvent: false });
        }
        if (!this.jbhGlobals.utils.isEmpty(accInfoForm.controls['billToCode'].value)) {
            accInfoForm.controls['lineofBusiness'].setValidators([]);
            accInfoForm.controls['lineofBusiness'].updateValueAndValidity({ onlySelf: true, emitEvent: false });
        }
        if ((accInfoForm['controls']['billToCode'].valid
            && this.accountInformation.orderBillingDetail['controls']
            ['accountInfoForm']['controls']['lineofBusiness'].valid) &&
            this.shipmentInformation.shipmentInformation.valid &&
            this.operationInformation.operationInformationDetail.valid &&
            !this.jbhGlobals.utils.isEmpty(this.orderData.financeBusinessUnitCode) &&
            !this.jbhGlobals.utils.isEmpty(this.orderData.serviceOfferingCode) &&
            !(this.orderData.financeBusinessUnitCode === 'ICS' &&
                this.orderData.orderOperationalElementDTOs.length === 0)) {
            this.callEquipmentsSave();
            this.jbhGlobals.logger.info('Form submit value');
            // this.orderData['orderOwnership'] = [{
            //     'taskAssignmentID': null,
            //     'backupTaskAssignmentID': this.orderData.orderID,
            //     'effectiveTimestamp': this.orderData['lastUpdateTimestampString'],
            //     'expirationTimestamp': this.orderData['lastUpdateTimestampString']
            // }];
            this.orderData['orderOwnership'] = [];
            this.orderService.saveOrder(this.orderData).subscribe((response: any) => {
                this.jbhGlobals.logger.info('Submit Response');
                this.jbhGlobals.notifications.success('Order', 'Order Data Saved.');
                this.router.navigateByUrl('/createorders/order/addstops?id=' + this.orderData.orderID);
            });
        } else {
            this.accountInformation.onValidateForm();
            this.serviceOffering.onValidateForm();
            this.shipmentInformation.onValidateForm();
            this.operationInformation.onValidateForm();
            this.jbhGlobals.notifications.error('Order', 'Fill all required fields.');
        }
    }

    saveEquipmentDetails() {
        if (this.operationInformation.operationInformationDetail.valid) {
            const equipparam = this.createService.getEquipmentRequirementResponse();
            const equipparamlocal = this.operationInformation.equipSaveParams;
            if (!this.jbhGlobals.utils.isEmpty(equipparam)) {
                const assObj = {
                    'orderEquipmentRequirementSpecificationAssociationID': '',
                    'equipmentRequirementSpecificationAssociationID': 0,
                    'lastUpdateTimestampString': '',
                    'equipmentRequirementSpecificationDetailID': '',
                    'orderEquipmentRequirementSpecificationDetails': []
                };
                assObj.orderEquipmentRequirementSpecificationDetails = equipparam;
                if (!equipparamlocal.orderEquipmentRequirementID) {
                    console.log(assObj);
                    if (!this.jbhGlobals.utils.isEmpty(equipparamlocal.orderEquipmentRequirementSpecificationAssociations)
                        && this.jbhGlobals.utils.isArray(equipparamlocal.orderEquipmentRequirementSpecificationAssociations)) {
                        equipparamlocal.orderEquipmentRequirementSpecificationAssociations.push(assObj);
                    } else {
                        equipparamlocal.orderEquipmentRequirementSpecificationAssociations = [];
                        equipparamlocal.orderEquipmentRequirementSpecificationAssociations.push(assObj);
                    }
                } else {
                    if (!this.jbhGlobals.utils.isEmpty(equipparamlocal.orderEquipmentRequirementSpecificationAssociations)
                        && this.jbhGlobals.utils.isArray(equipparamlocal.orderEquipmentRequirementSpecificationAssociations)) {
                        const isPresent = this.jbhGlobals.utils.findIndex(
                            equipparamlocal.orderEquipmentRequirementSpecificationAssociations, {
                                'equipmentRequirementSpecificationAssociationID': 0
                            });
                        if (isPresent !== -1) {
                            equipparamlocal.orderEquipmentRequirementSpecificationAssociations[isPresent]
                            ['orderEquipmentRequirementSpecificationDetails'] = equipparam;
                        } else {
                            equipparamlocal.orderEquipmentRequirementSpecificationAssociations.push(assObj);
                        }
                    }
                }
            }
           
            if (!equipparamlocal.orderEquipmentRequirementID) {
                equipparamlocal.order = '/' + this.orderData.orderID;
                this.jbhGlobals.apiService.addData(this.jbhGlobals.endpoints.order.saveEquipment, equipparamlocal).subscribe(data => {
                    console.log(data);
                });
            } else {
                    equipparamlocal.order = {
                    orderID: this.orderData.orderID 
                };
                const id = equipparamlocal.orderEquipmentRequirementID;
                const url = this.jbhGlobals.endpoints.order.updateEquipment + '/' + id;
                this.jbhGlobals.apiService.updateData(url, equipparamlocal).subscribe(data => {
                    console.log(data);
                });
            }
        }
    }
}
