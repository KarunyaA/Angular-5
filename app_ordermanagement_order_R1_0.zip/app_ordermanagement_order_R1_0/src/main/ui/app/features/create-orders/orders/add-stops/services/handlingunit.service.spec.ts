import { inject, TestBed } from '@angular/core/testing';

import { HandlingunitService } from './handlingunit.service';

describe('HandlingunitService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [HandlingunitService]
    });
  });

  it('should be created', inject([HandlingunitService], (service: HandlingunitService) => {
    expect(service).toBeTruthy();
  }));
});
