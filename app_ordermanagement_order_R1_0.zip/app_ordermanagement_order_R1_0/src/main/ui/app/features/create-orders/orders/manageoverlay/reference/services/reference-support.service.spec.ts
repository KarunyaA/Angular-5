import { inject, TestBed } from '@angular/core/testing';

import { ReferenceSupportService } from './reference-support.service';

describe('ReferenceSupportService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ReferenceSupportService]
    });
  });

  it('should be created', inject([ReferenceSupportService], (service: ReferenceSupportService) => {
    expect(service).toBeTruthy();
  }));
});
