import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ManageoverlayRoutingModule } from './manageoverlay-routing.module';
import { ManageoverlayComponent } from './manageoverlay.component';
import { ReferenceComponent } from './reference/reference.component';
import { ChargesComponent } from './charges/charges.component';
import { CommentsComponent } from './comments/comments.component';
import { InstructionsComponent } from './instructions/instructions.component';
import { DocumentsComponent } from './documents/documents.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RlTagInputModule } from '../../../../shared/tag-input';
// import { OrderService } from './../services/order.service';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { TagInputModule } from 'ng2-tag-input';
import { TypeaheadModule } from '../../../../shared/jbh-typeahead/typeahead.module';
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { SharedModule } from '../../../../shared/shared.module';
import { PopoverModule } from 'ngx-bootstrap';
import { SelectModule } from '../../../../shared/select';
import { ConfirmationPopupModule } from '../../../../shared/confirmation-popup/confirmation-popup.module';
import { ModalModule } from 'ngx-bootstrap';
import { TemplateInstructionsComponent } from './template-instructions/template-instructions.component';
import { ViewOrderService } from '../../../view-order/services/view-order.service';
import { ErrorDataHandlerService } from '../../../view-order/services/error-data-handler.service';

@NgModule({
  imports: [
    TabsModule.forRoot(),
    CommonModule,
    ManageoverlayRoutingModule,
    FormsModule,
    PerfectScrollbarModule,
    TagInputModule,
    ReactiveFormsModule,
    RlTagInputModule,
    SharedModule,
    TypeaheadModule.forRoot(),
    PopoverModule.forRoot(),
    SelectModule,
    ModalModule,
    ConfirmationPopupModule
  ],
  declarations: [ManageoverlayComponent,
    CommentsComponent,
    ReferenceComponent,
    ChargesComponent,
    InstructionsComponent,
    DocumentsComponent,
    TemplateInstructionsComponent
  ],
  exports: [ManageoverlayComponent,
    CommentsComponent,
    ReferenceComponent,
    ChargesComponent,
    InstructionsComponent,
    DocumentsComponent
  ],
  providers: [
    ViewOrderService,
    ErrorDataHandlerService
  ]
})
export class ManageoverlayModule { }
