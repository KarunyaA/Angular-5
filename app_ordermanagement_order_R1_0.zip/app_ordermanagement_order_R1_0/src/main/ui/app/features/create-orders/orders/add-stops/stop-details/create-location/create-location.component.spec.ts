import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RouterTestingModule } from '@angular/router/testing';

import { AppModule } from '../../../../../../app.module';
import { CreateOrdersModule } from '../../../../create-orders.module';
import { OrdersModule } from '../../../orders.module';
import { AddStopsModule } from '../../add-stops.module';

import { CreateLocationComponent } from './create-location.component';

describe('CreateLocationComponent', () => {
  let component: CreateLocationComponent;
  let fixture: ComponentFixture<CreateLocationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
          AppModule,
          RouterTestingModule,
          CreateOrdersModule,
          AddStopsModule,
          OrdersModule
       ],
      declarations: []
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateLocationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
