import { Component, EventEmitter, Input, OnDestroy, OnInit, Output, ViewChild } from '@angular/core';
import { JBHGlobals } from './../../../../../../app.service';
import { AddStopsOrderService } from './../../services/add-stops-order.service';
import { StopSharedDataService } from '../../../add-stops/services/stop-shared-data.service'
@Component({
  selector: 'app-stop-resequence',
  templateUrl: './stop-resequence.component.html',
  styleUrls: ['./stop-resequence.component.scss']
})
export class StopResequenceComponent implements OnInit, OnDestroy {
  @Input() stopResequenceList: any;
  @Input() orderId;
  @Input() appointmentResequence;
  @Input() appType;
  @Input() stopID;
  @Output() finalAppointment = new EventEmitter();
  @Output() removeStopEvent = new EventEmitter();
  @Output() isCloseClicked = new EventEmitter();
  @ViewChild('stopResequenceModal') stopResequenceModal;
  appointmentDateTimeDetails: any;
  orderData: any;
  constructor(public jbhGlobals: JBHGlobals,
    public orderService: AddStopsOrderService,
    public stopSharedDataService: StopSharedDataService) { }

  ngOnInit(): void {
    if (this.appointmentResequence) {
      for (let i = 0; i < this.appointmentResequence.length; i++) {
        if (this.appType === this.appointmentResequence[i].appointmentTypeCode) {
          this.appointmentDateTimeDetails = this.appointmentResequence[i].appointmentDateTimeDetails;
          return;
        }
      }
    }

  }

  ngOnDestroy() {

  }
  showStopResequence(event, stopResequenceModal) {
    event.stopPropagation();
    stopResequenceModal.show();
  }

  updateStopResequence(stopData, index) {
    const stopParam = '/resequence' + '/' + stopData.stop.stopID + '?reSequenceFlag=true';
    const stopForm = {
      'stopID': stopData.stop.stopID,
      'locationID': stopData.stop.locationContactID,
      'locationContactID': stopData.stop.locationContactID,
      'locationContactType': stopData.stop.locationContactType,
      'highCostDeliveryIndicator': stopData.stop.highCostDeliveryIndicator,
      'stopReason': stopData.stop.stopReason,
      'totalStopWeight': stopData.stop.totalStopWeight,
      'unitOfWeightMeasurementCode': stopData.stop.unitOfWeightMeasurementCode,
      'initialOfferedDate': stopData.stop.initialOfferedDate,
      'stopSequenceNumber': index,
      'order': {
        'orderID': this.orderId
      }
    };
    this.jbhGlobals.apiService.patchData(this.jbhGlobals.endpoints.order.crudStopDetails + stopParam, stopForm).subscribe(data => {
      if (data === {}) {
        this.jbhGlobals.logger.info('Stop Resequence Updated');
        this.jbhGlobals.notifications.success('Stop Resequence', 'Stop Resequence updated successfully');
      } else {
        if (data) {
          this.jbhGlobals.notifications.error('Stop Resequence', '' + Object.keys(data));
        }
      }
    }, (err: Error) => {
      return false;
    });
  }

  stopResequenceValidation() {
    const resequenceFlag = this.orderId + '?resequenceflag=true';
    const params = {};
    this.jbhGlobals.apiService.addData(this.jbhGlobals.endpoints.order.getResequenceValidation + resequenceFlag, params).subscribe(data => {
      if (!this.jbhGlobals.utils.isEmpty(data)) {
        this.jbhGlobals.logger.info('Stops Validated Successfully');
        this.stopSharedDataService.getStopsSummary(this.orderId);
      }
    }, (err: Error) => {
      return false;
    });
  }

  removeStopResequence(event, pos: number, stopId: number) {
    this.stopResequenceModal.hide();
    const obj = {
      'event': event, 'index': pos, 'stopId': stopId
    }
    this.removeStopEvent.emit(obj);
  }

  primaryAppointmentGenerator(apptData): Array<object> {
    const tempArray = [];
    for (let i = 0; i < apptData.length; i++) {
      const temp = [];
      if (i === 0) {
        apptData[i].primaryAppointmentIndicator = 'Y';
        tempArray.push(apptData[i]);
      } else {
        apptData[i].primaryAppointmentIndicator = 'N';
        tempArray.push(apptData[i]);
      }
    }
    return tempArray;
  }

  onAppResequenceValidation(apptData): void {
    this.stopResequenceModal.hide()
    let apptJson;
    let schData;
    const appArr = this.primaryAppointmentGenerator(apptData);
    if (this.appType === 'Requested') {
      this.appointmentResequence[0].appointmentDateTimeDetails = appArr;
      apptJson = this.appointmentResequence[0];
    } else if (this.appType === 'Scheduled') {
      if (this.appointmentResequence.length === 2) {
        this.appointmentResequence[1].appointmentDateTimeDetails = appArr;
        apptJson = this.appointmentResequence[1];
      } else {
        this.appointmentResequence[0].appointmentDateTimeDetails = appArr;
        apptJson = this.appointmentResequence[0];
      }
    }
    if (this.appType === 'Scheduled') {
      schData = {
        'appointmentID': apptJson.appointmentID,
        'appointmentTypeCode': 'Scheduled',
        'appointmentConfirmationNumber': apptJson.appointmentConfirmationNumber,
        'requestCallBackIndicator': 'Y',
        'appointmentInboundDate': '',
        'appointmentDetails': [{
          'appointmentDetailID': apptJson.appointmentDetails['0'].appointmentDetailID,
          'appointmentSetReasonCode': '02'
        }],
        'appointmentDateTimeDetails': apptJson.appointmentDateTimeDetails,
        'appointmentInstructionAssociations': apptJson.appointmentInstructionAssociations,
        'stop': {
          'stopID': this.stopID
        }
      };
    }
    if (this.appType === 'Requested') {
      schData = {
        'appointmentID': apptJson.appointmentID,
        'appointmentTypeCode': 'Requested',
        'requestCallBackIndicator': 'Y',
        'appointmentInboundDate': '',
        'appointmentDetails': [{
          'appointmentDetailID': apptJson.appointmentDetails['0'].appointmentDetailID,
          'appointmentSetReasonCode': '02'
        }],
        'appointmentDateTimeDetails': apptJson.appointmentDateTimeDetails,
        'stop': {
          'stopID': this.stopID
        }
      };
    }
    this.jbhGlobals.apiService.updateData(this.jbhGlobals.endpoints.order.crudApptDetails + '/' + apptJson['appointmentID'],
      schData).subscribe(apptDatas => {
        this.jbhGlobals.notifications.success('Success', 'Appointment Updated Successfully');
      });
  }

  onDropEnabled(event, index): void {
    if (this.stopResequenceList) {
      this.updateStopResequence(event, index);
    }
  }

  closeStopResequence() {
    this.stopResequenceModal.hide()
    this.isCloseClicked.emit(true);
  }

}
