import { inject, TestBed } from '@angular/core/testing';

import { ShipmentinformationService } from './shipmentinformation.service';

describe('ShipmentinformationService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ShipmentinformationService]
    });
  });

  it('should be created', inject([ShipmentinformationService], (service: ShipmentinformationService) => {
    expect(service).toBeTruthy();
  }));
});
