import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {OrderService} from '../../services/order.service';
import { JBHGlobals } from 'app/app.service';
import { OrderFormBuilderService } from '../../services/order-form-builder.service';
import { InstructionsModel } from './model/instructions.model';
import { TemplateService } from './../../../templates/template.service';

@Component({
  selector: 'app-template-instructions',
  templateUrl: './template-instructions.component.html',
  styleUrls: ['./template-instructions.component.scss']
})
export class TemplateInstructionsComponent implements OnInit, OnDestroy {

    @ViewChild('insTagList') insTagList: any;
    instructionsModel: InstructionsModel;
    orderData: any;
    instructionForm: FormGroup;
    instructionList: any[] = [];
    lastUpdateTimestampString: string;
    subscribeFlag = true;
    constructor(public formBuilder: FormBuilder, public orderService: OrderService, public jbhGlobals: JBHGlobals,
                public orderFormBuilder: OrderFormBuilderService,
                public templateService: TemplateService) {}

    ngOnInit(): void {
        this.instructionsModel = new InstructionsModel();
        this.addInstructionFormBuilder();
        this.loadTemplateData();
        this.populateTemplateTags();
    }
    ngOnDestroy(): void {
        this.subscribeFlag = false;
    }
    onInsItemSelected(indx: any): void {
        if (this.instructionsModel.selectedInsIndex !== indx) {
            if (this.instructionsModel.removedInsIndex !== null) {
                this.deleteInstructionPermanently(this.instructionsModel.removedInsIndex);
            }
            if (this.instructionsModel.editInsIndex !== null) {
                this.instructionsModel.editInsIndex = null;
                this.resetInstructionForm();
            }
            this.instructionsModel.saveMode = '';
            this.instructionsModel.selectedInsIndex = indx;
        }
    }

    saveInstruction(): void {
        const dateValue = new Date(),
         instructionObj = {};
        instructionObj['additionalInstructionType'] = this.instructionForm.value.insTagList[0]['id'];
        instructionObj['additionalInstructionText'] = this.instructionForm.value.instDesc;
        instructionObj['name'] = this.jbhGlobals.user.name;
        instructionObj['id'] = this.jbhGlobals.user.id;
        instructionObj['lastUpdateTimestampString'] = dateValue.toISOString();

        if (this.instructionsModel.saveMode !== 'edit') {
            this.addNewInstructionsToDTO(instructionObj);
        } else {
            this.updateInstructionsToDTO(instructionObj);
        }
        this.resetInstructionForm();
        this.populateTemplateTags();
    }
    editInstruction(indx): void {
        const editItem = this.instructionList[indx];
        const obj = {};
        obj['id'] = editItem['additionalInstructionType'];
        obj['text'] = editItem['additionalInstructionType'];
        this.instructionForm['controls']['insTagList'].setValue([obj]);
        this.instructionForm['controls']['instDesc'].setValue(editItem['additionalInstructionText']);

        this.instructionsModel.editInsIndex = indx;
        this.instructionsModel.saveMode = 'edit';
    }
    deleteInstruction(indx): void {
        if (this.instructionsModel.editInsIndex !== null) {
            this.instructionsModel.editInsIndex = null;
            this.resetInstructionForm();
        }
        this.instructionsModel.removedInsIndex = indx;
    }
    deleteInstructionPermanently(indx): void {
        const delItem = this.instructionList[indx];
        const instructionType = delItem.additionalInstructionType.split(' ');
        switch (instructionType[0]) {
            case 'Order':
                {
                    this.instructionList.splice(this.instructionsModel.removedInsIndex, 1);
                    this.orderData['orderAdditionalInstruction'] =
                    this.instructionList.filter(obj => obj['additionalInstructionType'] === 'Order');
                    break;
                }
            case 'Billing':
                {
                    this.instructionList.splice(this.instructionsModel.removedInsIndex, 1);
                    this.orderData['orderBillingDetailDTOs'][0]['orderBillingAdditionalInstruction'] =
                    this.instructionList.filter(obj => obj['additionalInstructionType'] === 'Billing');
                    break;
                }
            case 'Equipment':
                {
                    this.instructionList.splice(this.instructionsModel.removedInsIndex, 1);
                    this.orderData['orderEquipmentRequirementDTOs'][0]['orderEquipmentAdditionalInstruction'] =
                    this.instructionList.filter(obj => obj['additionalInstructionType'] === 'Equipment');
                    break;
                }
            case 'Stop':
                {
                    this.instructionList.splice(this.instructionsModel.removedInsIndex, 1);
                    const stopSequenceNo = parseInt(instructionType[1], 10);
                    const stopData = this.templateService.getStopList();
                    const delInst = this.instructionList.filter(obj => obj['additionalInstructionType'] ===
                        delItem.additionalInstructionType);
                    const currentStop = stopData.find(item => item['stop']['stopSequenceNumber'] === stopSequenceNo);
                    currentStop['stop']['stopAdditionalInstruction'] = delInst;
                    break;
                }
            default:
                {
                    break;
                }
        };
        this.instructionsModel.removedInsIndex = null;
    }
    undoDeleteInstruction(): void {
        this.instructionsModel.removedInsIndex = null;
    }
    private addInstructionFormBuilder() {
        this.instructionForm = this.formBuilder.group({
            'instDesc': ['', Validators.compose([Validators.required, this.jbhGlobals.customValidator.maxLengthValidator])],
            'insTagList': [
                [], Validators.compose([Validators.required])
            ],
            'lastUpdateTimestampString': ''
        });
    }

    private loadTemplateData(): void {

        if (this.jbhGlobals.utils.isEmpty(this.orderData)) {
            this.instructionsModel.subscription = this.orderService.getData()
            .takeWhile(() => this.subscribeFlag).subscribe(sharedOrderData => {
                this.orderData = sharedOrderData;
                if (!this.jbhGlobals.utils.isEmpty(this.orderData)) {
                    this.instructionList = [];
                    this.populateTemplateInstruction();
                    this.populateTemplateTags();
                }
            });
        }
    }

    private populateTemplateInstruction(): void {
        if (this.orderData) {
            // To load Order Instructions
            if (this.orderData['orderAdditionalInstruction']) {
                for (const insItem of this.orderData['orderAdditionalInstruction']) {
                    this.instructionList.push(insItem);
                };
            }
            // To load Billing Instructions
            if (this.orderData['orderBillingDetailDTOs'][0]) {
                if (this.orderData['orderBillingDetailDTOs'][0]['orderBillingAdditionalInstruction']) {
                    for (const insItem of this.orderData['orderBillingDetailDTOs'][0]['orderBillingAdditionalInstruction']) {
                        this.instructionList.push(insItem);
                    }
                }
            };
            // To load Equipment Instructions
            const equip = this.orderData['orderEquipmentRequirementDTOs'];
            if (equip[0]) {
                if (equip[0]['orderEquipmentRequirementAdditionalInstruction']) {
                    for (const insItem of equip[0]['orderEquipmentRequirementAdditionalInstruction']) {
                        this.instructionList.push(insItem);
                    }
                }
            };
            // To load stop instructions
            if (this.orderData['stopList']) {
                for (const stopItem of this.orderData['stopList']) {
                    for (const insItem of stopItem['stop']['stopAdditonalInstruction']) {
                        this.instructionList.push(insItem);
                    }
                }
            }
        }
        this.instructionList = this.jbhGlobals.utils.sortBy(this.instructionList, ['lastUpdateTimestampString']).reverse();
    }

    private populateTemplateTags(): void {
        const stopData = this.templateService.getStopList();
        const obj = [];
        obj.push('Order');
        obj.push('Billing');
        obj.push('Equipment');
        for (const stopItem of stopData) {
            obj.push('Stop ' + stopItem['stop']['stopSequenceNumber']);
        };
        this.instructionsModel.instructionTagList = obj;
    }
    private addNewInstructionsToDTO(insObj): void {
        const instructionType = insObj.additionalInstructionType.split(' ');
        switch (instructionType[0]) {
            case 'Order':
                {
                    if (this.orderData['orderAdditionalInstruction'] == null) {
                        this.orderData['orderAdditionalInstruction'] = [];
                    }
                    this.instructionList.push(insObj);
                    this.orderData['orderAdditionalInstruction'].push(insObj);
                    break;
                }
            case 'Billing':
                {
                    if (this.orderData['orderBillingDetailDTOs'][0]['orderBillingAdditionalInstruction'] == null) {
                        this.orderData['orderBillingDetailDTOs'][0]['orderBillingAdditionalInstruction'] = [];
                    }
                    this.instructionList.push(insObj);
                    this.orderData['orderBillingDetailDTOs'][0]['orderBillingAdditionalInstruction'].push(insObj);
                    break;
                }
            case 'Equipment':
                {
                    if (!(this.orderData['orderEquipmentRequirementDTOs'][0] &&
                            this.orderData['orderEquipmentRequirementDTOs'][0]['orderEquipmentRequirementAdditionalInstruction'])) {
                        if (!this.orderData['orderEquipmentRequirementDTOs'][0]) {
                            this.orderData['orderEquipmentRequirementDTOs'][0] = {};
                        }
                        this.orderData['orderEquipmentRequirementDTOs'][0]['orderEquipmentRequirementAdditionalInstruction'] = [];
                    }
                    this.instructionList.push(insObj);
                    this.orderData['orderEquipmentRequirementDTOs'][0]['orderEquipmentRequirementAdditionalInstruction'].push(insObj);
                    break;
                }
            case 'Stop':
                {
                    this.instructionList.push(insObj);
                    const stopData = this.templateService.getStopList();
                    const stopSequenceNo = parseInt(instructionType[1], 10);
                    const currentStop = stopData.find(item => item['stop']['stopSequenceNumber'] === stopSequenceNo);
                    console.log(currentStop);
                    const obj = {
                        'additionalInstructionText': insObj.additionalInstructionText,
                        'additionalInstructionType': 'Stop',
                        'name': insObj.name,
                        'id': insObj.id,
                        'lastUpdateTimestampString': insObj.lastUpdateTimestampString
                    };
                    currentStop['stop']['stopAdditionalInstruction'] ? currentStop['stop']['stopAdditionalInstruction'].push(obj) :
                    currentStop['stop']['stopAdditionalInstruction'] = [];
                    if (currentStop['stop']['stopAdditionalInstruction'].length === 0) {
                        currentStop['stop']['stopAdditionalInstruction'].push(obj);
                    }
                    break;
                }
            default:
                {
                    break;
                }
        }
        this.instructionList = this.jbhGlobals.utils.sortBy(this.instructionList, ['lastUpdateTimestampString']).reverse();
        this.populateTemplateTags();
    }
    private updateInstructionsToDTO(insObj): void {
        const instructionType = insObj.additionalInstructionType.split(' ');
        switch (instructionType[0]) {
            case 'Order':
                {
                    this.instructionList[this.instructionsModel.editInsIndex] = insObj;
                    this.orderData['orderAdditionalInstruction'] =
                    this.instructionList.filter(obj => obj['additionalInstructionType'] === 'Order');
                    break;
                }
            case 'Billing':
                {
                    this.instructionList[this.instructionsModel.editInsIndex] = insObj;
                    this.orderData['orderBillingDetailDTOs'][0]['orderBillingAdditionalInstruction'] =
                    this.instructionList.filter(obj => obj['additionalInstructionType'] === 'Billing');
                    break;
                }
            case 'Equipment':
                {
                    this.instructionList[this.instructionsModel.editInsIndex] = insObj;
                    this.orderData['orderEquipmentRequirementDTOs'][0]['orderEquipmentAdditionalInstruction'] =
                    this.instructionList.filter(obj => obj['additionalInstructionType'] === 'Equipment');
                    break;
                }
            case 'Stop':
                {
                    this.instructionList[this.instructionsModel.editInsIndex] = insObj;
                    const stopSequenceNo = parseInt(instructionType[1], 10);
                    const stopData = this.templateService.getStopList();
                    const stopInst = this.instructionList.filter(obj => obj['additionalInstructionType'] ===
                        insObj.additionalInstructionType);
                    const currentStop = stopData.find(item => item['stop']['stopSequenceNumber'] === stopSequenceNo);
                    const editedInst = [];
                    for (const instItems of stopInst) {
                        const obj = {};
                        obj['additionalInstructionType'] = 'Stop';
                        obj['additionalInstructionText'] = instItems['additionalInstructionText'];
                        obj['name'] = instItems['name'];
                        obj['id'] = instItems['id'];
                        obj['lastUpdateTimestampString'] = instItems['lastUpdateTimestampString'];
                        editedInst.push(obj);
                    }
                    currentStop['stop']['stopAdditionalInstruction'] = editedInst;
                    break;
                }
            default:
                {
                    break;

                }
        }
        this.instructionList = this.jbhGlobals.utils.sortBy(this.instructionList, ['lastUpdateTimestampString']).reverse();
        this.instructionsModel.saveMode = '';

    }
    private resetInstructionForm(): void {
        this.instructionForm.reset();
    }
}
