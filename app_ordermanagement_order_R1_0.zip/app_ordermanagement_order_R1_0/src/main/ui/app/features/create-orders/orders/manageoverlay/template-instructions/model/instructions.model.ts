export class InstructionsModel {

subscription: any;
selectedInsIndex = null;
removedInsIndex = null;
editInsIndex = null;
saveMode = '';
instructionTagList: any[] = [];
}
