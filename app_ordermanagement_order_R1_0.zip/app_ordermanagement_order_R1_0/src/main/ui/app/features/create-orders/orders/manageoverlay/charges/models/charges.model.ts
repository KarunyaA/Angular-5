export class ChargesModel {
    unitCodeList: any;
    chargeList: Array<string> = [];
    chargeListFlag = false;
    onEditAuthDetail = false;
    typeHeadChargeCodeList: string[] = [];
    editDelIndex: number;
    delIndex: number;
    updatedChargeCode: any;
    subscription: any;
    orderData: any;
    unitFlag = false;
    flatFlag = false;
    addBtn = true;
    editBtn = false;
    hideDelBtn: any;
    gbEdtIdx: number;
    showEditBtn: boolean;
    debounceValue: any;
    levelCode: any;
    intialChargeClick = true;
    chargeDto: any;
    stopreason: any;
    stopID: any;
    stopSummary: any;
    orderId: number;
    currentPage: any;
    custAuthName: string;
    chargeDtoVal: any;
    editValue: any;
    responseData: any;
    chargesIndex: any = [];
    editCall = false
    
    
}
