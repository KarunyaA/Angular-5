/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { ModalModule } from 'ngx-bootstrap';
import { AccordionModule } from 'ngx-bootstrap';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { MyDatePickerModule } from 'mydatepicker';
import { RatingModule } from 'ngx-bootstrap/rating';
import { PopoverModule } from 'ngx-bootstrap/popover';
import { BsDropdownModule } from 'ngx-bootstrap';

import { AccountinformationComponent } from './accountinformation.component';

describe('AccountinformationComponent', () => {
  let component: AccountinformationComponent;
  let fixture: ComponentFixture<AccountinformationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
    imports: [
        AccordionModule.forRoot(),
        TabsModule.forRoot(),
        PerfectScrollbarModule,
        MyDatePickerModule,
        RatingModule.forRoot(),
        PopoverModule.forRoot(),
        BsDropdownModule.forRoot(),
        ModalModule.forRoot(),
        FormsModule,
        ReactiveFormsModule
      ],
      declarations: [ AccountinformationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountinformationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
