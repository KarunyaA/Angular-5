import { Injectable } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { JBHGlobals } from 'app/app.service';
import { JbhJsonTransformerService } from '../../../orders/services/jbh-json-transformer.service';
import { IOrderDtoModel } from '../../../orders/models/order-dto-model';
import { IOrderEntityModel } from '../../../orders/models/order-entity-model';

@Injectable()
export class AddStopsOrderService {
    sharingData: BehaviorSubject<IOrderDtoModel[]>;
    orderEntity = <IOrderEntityModel>{};
    data: IOrderDtoModel;
    flagState: boolean;

    constructor(public jbhGlobals: JBHGlobals,
                public transformerService: JbhJsonTransformerService,
                public route: ActivatedRoute) {
        this.sharingData = <BehaviorSubject<IOrderDtoModel[]>>new BehaviorSubject([]);
        // this.init();
        this.jbhGlobals.logger.info('Add stops Order Service initialized');
    }

    init(): void {
        this.route.queryParams.subscribe(
            (queryParam: any) => {
                if (!this.jbhGlobals.utils.isEmpty(queryParam['id'])) {
                    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getorder + queryParam['id']).subscribe(data => {
                        data['orderID'] = parseInt(queryParam['id'], 10);
                        this.saveData(data);
                        this.jbhGlobals.logger.info('Add Stop order Dto Loaded', data);
                    });
                }
            });
    }

    loadOrder(id): void {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getorder + id).subscribe(data => {
            this.saveData(data);
            this.jbhGlobals.logger.info('Order Dto Loaded', data);
        });
    }

    saveData(orderDtoData): void {
        this.data = orderDtoData;
        this.sharingData.next(orderDtoData);
    }

    getData() {
        return this.sharingData.asObservable();
    }

    getDataAsEntity(): IOrderEntityModel {
        return this.transformerService.orderDtoToEntity(this.data, this.orderEntity);
    }

    getDataAsDto(): IOrderDtoModel {
        return this.data;
    }

    setFlag(value) {
        this.flagState = false;
        if (value) {
            this.flagState = value;
        }
    }
    getFlag() {
        return this.flagState;
    }
}
