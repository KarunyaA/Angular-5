import { inject, TestBed } from '@angular/core/testing';

import { ItemTemperatureService } from './item-temperature.service';

describe('ItemTemperatureService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ItemTemperatureService]
    });
  });

  it('should be created', inject([ItemTemperatureService], (service: ItemTemperatureService) => {
    expect(service).toBeTruthy();
  }));
});
