import { inject, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';

import { CreateService } from './create.service';
import { CreateModule } from '../create.module';
import { AppModule } from '../../../../../app.module';

describe('CreateService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CreateService],
      imports: [CreateModule, AppModule, RouterTestingModule]
    });
  });

  it('should be created', inject([CreateService], (service: CreateService) => {
    expect(service).toBeTruthy();
  }));
});
