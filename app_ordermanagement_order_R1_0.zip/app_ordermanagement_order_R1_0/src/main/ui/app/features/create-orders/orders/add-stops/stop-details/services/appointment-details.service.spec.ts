import { inject, TestBed } from '@angular/core/testing';

import { AppointmentDetailsService } from './appointment-details.service';

describe('AppointmentDetailsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AppointmentDetailsService]
    });
  });

  it('should be created', inject([AppointmentDetailsService], (service: AppointmentDetailsService) => {
    expect(service).toBeTruthy();
  }));
});
