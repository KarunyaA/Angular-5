export class ShipmentinformationModel {
  // tslint:disable:member-access
  operTempError = ' operating temperature range';
  preCoolTempError = ' precool temperature range';
  debounceValue: any;
  orderTypeList: any[] = [{ 'id': 'Standard', 'text': 'Standard' }];
  secondaryOrderTypeList: any[];
  shipmentRequirementList: any[];
  carrierNameList: any[] = [];
  volumecarrierNameList: any[] = [];
  customsBrokerList: any[] = [];
  clearingCustomsList: any[];
  internationalServicesList: any[];
  bondHolderRoleList: any[];
  bondHolderPartyList: any[];
  bondHolderTypesList: any[];
  portOfEntryList: any[];
  portOfExitList: any[];
  fleetCodeList: any[] = [];
  selectedBondHolderRoleCode: string;
  ptemperaturezone: any[] = [];
  otemperaturezone: any[] = [];
  ptemperaturezoneinFah: any[] = [];
  otemperaturezoneinFah: any[] = [];
  temperatureArray: any[] = [];
  orderData: any;
  subscriptions: any = [];
  serviceOfferingValue = null;
  businessUnitValue = null;
  transitMode = '';
  orderType = '';
  orderId = '';
  populateFlag = true;
  orderSubTypeFlag = false;
  equipmentRequirementID: any = '';
  specificationID: any = '';
  specificationAssociationID: any = '';
  brokerProfile: any = '';
  clearingString = 'Clearing Customs';
  fleetcodeflag = true;
  rmaorderflag = false;
  rmanumberflag = false;
  flatbedFlag = false;
  maritimeflag = false;
  ICSLTLflag = false;
  DCSFMSflag = false;
  returnOrderFlag = false;
  tradeshow = false;
  volship = false;
  tempcontrol = false;
  intship = false;
  refrigerated = false;
  foodsafety = false;
  precoolflag = false;
  operatingflag = false;
  omaximumerrorflag = false;
  maximumerrorflag = false;
  precooladdtemperatureflag = false;
  operaddtemperatureflag = false;
  addtemperaturezoneflag = false;
  addoptemperaturezoneflag = false;
  customsErrorFlag = false;
  errorflag = false;
  precoolerrorflag = false;
  tscarrierId: any;
  vscarrierId: any;
  inbondflag = false;
  addcustombrokerflag = false;
  customsbrokersdisplayflag = false;
  railintactserviceflag = false;
  customsBrokerDetails: any[] = [];
  customsbrokerId: number;
  clearingcountrycode = '';
  compName: any;
  ordercrossborderdetailid: any;
  recordIndex: any;
  flag: any;
  confirmMessage: any;
  brokerRecordIndex: any;
  deleteElement: string;
  outsourcingVal: string;
  creditStatus: string;
  params: any = {
    'orderEquipmentRequirementID': '',
    'equipmentID': 0,
    'trailerPreloadedIndicator': 'N',
    'equipmentTypeRequiredIndicator': 'Y',
    'equipmentLengthRequiredIndicator': 'Y',
    'equipmentClassificationTypeAssociationID': 0,
    'orderEquipmentRequirementSpecificationAssociations': [{
      'orderEquipmentRequirementSpecificationAssociationID': '',
      'equipmentRequirementSpecificationAssociationID': 0,
      'lastUpdateTimestampString': '',
      'equipmentRequirementSpecificationDetailID': '',
      'orderEquipmentRequirementSpecificationDetails': []
    }],
    'orderNonCompanyEquipmentDetails': [],
    'orderEquipmentRequirementFeatureAssociations': [],
    'lastUpdateTimestampString': '',
    'order': ''
  };
  array = ['shipmentIdentificationNumber', 'orderValueAmount'];
  internationalshipmentarray = ['vesselNumber', 'voyageNumber', 'bondNumber', 'entryNumber'];
  tradeshowarray = ['carrierName', 'carrierQuoteNumber', 'carrierBoothNumber'];
  volshiparray = ['volcarrierName', 'volcarrierQuoteNumber'];
}
