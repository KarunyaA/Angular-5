// declare module namespace {

export interface ChargeDTO {
    charge?: any;
    stopLocationCode?: any;
    stopSequenceNumber: number;
    chargeDescription?: any;
}

export interface AddressDTO {
    addressLineOne: string;
    addressLineTwo?: any;
    city?: any;
    state?: any;
    zipCode?: any;
    country?: any;
    cityID?: any;
}

export interface ContactDTO {
    contactId: string;
    contactValue?: any;
    contactType?: any;
    contactName?: any;
    contactMethod?: any;
    locationCode?: any;
    firstName?: any;
    marketingArea?: any;
    lastName?: any;
    profileCode?: any;
    profileName?: any;
}

export interface ProfileDTO {
    partyID: number;
    partyName?: any;
    partyType?: any;
    partyStatus?: any;
    addressDTO: AddressDTO;
    contactDTO: ContactDTO;
}

export interface RatingCycleDTO {
    ratingCode?: any;
    ratingDescription?: any;
}

export interface ContactDTO2 {
    contactId: string;
    contactValue?: any;
    contactType?: any;
    contactName?: any;
    contactMethod?: any;
    locationCode?: any;
    firstName?: any;
    marketingArea?: any;
    lastName?: any;
    profileCode?: any;
    profileName?: any;
}

export interface OrderBillingAdditionalInstruction {
    additionalInstructionText?: any;
    additionalInstructionType: string;
    orderID: number;
    lastUpdateTimestampString?: any;
}

export interface OrderBillingDetailDTO {
    profileDTO: ProfileDTO;
    ratingCycleDTO: RatingCycleDTO;
    autorateIndicator: string;
    contactDTO: ContactDTO2;
    freightChargeTermTypeCode?: any;
    orderBillingAdditionalInstruction: OrderBillingAdditionalInstruction[];
    lineOfBusinessCode?: any;
}

export interface OrderService {
    serviceID: string;
    serviceType: string;
    serviceCount: number;
    unitOfServiceMeasurementCode: string;
    serviceLevelTypeCode: string;
    lastUpdateTimestampString: Date;
}

export interface AddressDTO2 {
    addressLineOne: string;
    addressLineTwo?: any;
    city?: any;
    state?: any;
    zipCode?: any;
    country?: any;
    cityID?: any;
}

export interface ContactDTO3 {
    contactId: string;
    contactValue?: any;
    contactType?: any;
    contactName?: any;
    contactMethod?: any;
    locationCode?: any;
    firstName?: any;
    marketingArea?: any;
    lastName?: any;
    profileCode?: any;
    profileName?: any;
}

export interface ProfileDTO2 {
    partyID: number;
    partyName?: any;
    partyType?: any;
    partyStatus?: any;
    addressDTO: AddressDTO2;
    contactDTO: ContactDTO3;
}

export interface OrderRequestorDTO {
    profileDTO: ProfileDTO2;
    outsourcing: boolean;
}

export interface AddressDTO3 {
    addressLineOne: string;
    addressLineTwo?: any;
    city?: any;
    state?: any;
    zipCode?: any;
    country?: any;
    cityID?: any;
}

export interface ContactDTO4 {
    contactId: string;
    contactValue?: any;
    contactType?: any;
    contactName?: any;
    contactMethod?: any;
    locationCode?: any;
    firstName?: any;
    marketingArea?: any;
    lastName?: any;
    profileCode?: any;
    profileName?: any;
}

export interface OrderAssociatedParty {
    partyID: number;
    partyName?: any;
    partyType?: any;
    partyStatus?: any;
    addressDTO: AddressDTO3;
    contactDTO: ContactDTO4;
}

export interface InternationalOrderElement {
    bondType: string;
    bondHolder?: any;
    portOfEntry?: any;
    portOfExit?: any;
    bondNumber?: any;
    entryNumber?: any;
    voyageNumber?: any;
    vesselNumber?: any;
    bondHolderCarrierName?: any;
    lastUpdateTimestampString?: any;
}

export interface InternationalService {
    serviceType?: any;
    serviceCount: number;
    unitOfServiceMeasurementCode?: any;
    serviceLevelTypeCode: string;
    lastUpdateTimestampString?: any;
}

export interface AddressDTO4 {
    addressLineOne: string;
    addressLineTwo?: any;
    city?: any;
    state?: any;
    zipCode?: any;
    country?: any;
    cityID?: any;
}

export interface ContactDTO5 {
    contactId: string;
    contactValue?: any;
    contactType?: any;
    contactName?: any;
    contactMethod?: any;
    locationCode?: any;
    firstName?: any;
    marketingArea?: any;
    lastName?: any;
    profileCode?: any;
    profileName?: any;
}

export interface ProfileDTO3 {
    partyID: number;
    partyName?: any;
    partyType?: any;
    partyStatus?: any;
    addressDTO: AddressDTO4;
    contactDTO: ContactDTO5;
}

export interface OrderCrossesBorderDetailDTO {
    clearingCountryCode?: any;
    profileDTO: ProfileDTO3;
}

export interface OrderOperationalElement {
    projectCode?: any;
    fleetCode?: any;
    lastUpdateTimestampString?: any;
}

export interface OrderMonitorInformation {
    orderMonitorInformationID: number;
    destinationMonitorArea?: any;
    originMonitorArea?: any;
    lastUpdateTimestampString?: any;
}

export interface OrderEquipmentRequirement {
    orderEquipmentRequirementID: number;
    equipmentID: number;
    equipmentClassificationTypeAssociationID: number;
    equipmentLengthRequiredIndicator?: any;
    equipmentTypeRequiredIndicator?: any;
    trailerPreloadedIndicator?: any;
    orderNonCompanyEquipmentDetails?: any;
    lastUpdateTimestampString?: any;
}

export interface OrderEquipmentTypeCategoryDetailDTO {
    equipmentCategoryCode?: any;
    equipmentTypeCode?: any;
    equipmentTypeDescription?: any;
    equipmentCategoryDescription?: any;
    equipmentCategoryClassificationTypeAssociationID: number;
}

export interface EquipmentRequirementSpecificationDetail {
    id: number;
    detailDescription?: any;
}

export interface OrderEquipmentRequirementSpecificationAssociationDTO {
    orderEquipmentRequirementSpecificationAssociationID: number;
    equipmentRequirementSpecificationAssociationID: number;
    equipmentRequirementTypeCode?: any;
    equipmentRequirementTypeDescription?: any;
    equipmentRequirementSpecificationCode?: any;
    equipmentRequirementSpecificationDescription?: any;
    equipmentRequirementSpecificationDetail: EquipmentRequirementSpecificationDetail[];
}

export interface OrderEquipementRequirementFeatureAssociationDTO {
    orderEquipmentRequirementFeatureAssociationID: number;
    equipmentCategoryClassificationTypeFeatureAssociationID: number;
    equipmentFeatureCode?: any;
    equipmentFeatureDescription?: any;
}

export interface OrderEquipmentRequirementDTO {
    orderEquipmentRequirement: OrderEquipmentRequirement;
    locationCodes?: any;
    trailerPrefix?: any;
    trailerNumber?: any;
    orderEquipmentTypeCategoryDetailDTO: OrderEquipmentTypeCategoryDetailDTO;
    orderEquipmentRequirementSpecificationAssociationDTOs: OrderEquipmentRequirementSpecificationAssociationDTO[];
    orderEquipementRequirementFeatureAssociationDTOs: OrderEquipementRequirementFeatureAssociationDTO[];
}

export interface CommentDTO {
    commentTypeDescription?: any;
    comment?: any;
    firstName?: any;
    lastName: string;
    stopNumber?: any;
    locationCode?: any;
    lastUpdateTimestamp?: any;
}

export interface StopCharge {
    chargeID: string;
    chargeCode: string;
    chargeQuantity: number;
    chargeUnitCode: string;
    chargeUnitRateAmount: number;
    customerAuthorizationFirstName: string;
    customerAuthorizationLastName: string;
    customerAuthorizationNumber: string;
    chargeLevelTypeCode: string;
    lastUpdateTimestampString: Date;
}

export interface StopComment {
    commentID: number;
    remark: string;
    commentTypeCode: string;
    location: string;
    commentLevelTypeCode: string;
    lastUpdateTimestampString: Date;
}

export interface StopService {
    serviceID: number;
    serviceType: string;
    serviceCount: number;
    unitOfServiceMeasurementCode: string;
    serviceLevelTypeCode: string;
    lastUpdateTimestampString: Date;
}

export interface ReferenceNumber {
    referenceNumberID: number;
    referenceNumberTypeCode: string;
    referenceNumberValue: string;
    referenceNumberLevelTypeCode: string;
}

export interface AssociatedReferenceNumber {
    referenceNumber: ReferenceNumber;
    lastUpdateTimestampString: Date;
}

export interface StopReferenceNumber {
    referenceNumberID: number;
    referenceNumberTypeCode: string;
    referenceNumberValue: string;
    referenceNumberLevelTypeCode: string;
    associatedReferenceNumber: AssociatedReferenceNumber[];
    lastUpdateTimestampString: Date;
}

export interface AppointmentDetail {
    appointmentDetailID: string;
    AppointmentSetReasonCode: string;
}

export interface AppointmentInstructionAssociation {
    appointmentInstructionAssociationID: string;
    appointmentInstruction: string;
    appointmentInstructionAdditionalDetail: string;
}

export interface AppointmentDateTimeDetail {
    appointmentDateTimeDetailID: string;
    appointmentStartTimestamp: string;
    appointmentEndTimestamp: string;
    primaryAppointmentIndicator: string;
}

export interface Appointment {
    appointmentID: string;
    appointmentTypeCode: string;
    appointmentConfirmationNumber: string;
    requestCallBackIndicator: string;
    recommendedAppointmentTimeStamp: string;
    appointmentInboundDate: string;
    appointmentDetails: AppointmentDetail[];
    appointmentInstructionAssociation: AppointmentInstructionAssociation[];
    appointmentDateTimeDetails: AppointmentDateTimeDetail[];
}

export interface ItemHandlingDetail {
    itemHandlingDetailID: string;
    itemHandlingTypeCode: string;
    itemHandlingTypeQuantity: string;
    itemHandlingUnitHeight: string;
    itemHandlingUnitLength: string;
    itemHandlingUnitWidth: string;
    unitOfLengthMeasurementCode: string;
    itemHandlingUnitVolume: string;
    unitOfVolumeMeasurementCode: string;
    itemHandlingUnitWeight: string;
    unitOfWeightMeasurementCode: string;
    itemHandlingUnitDensity: string;
    unitOfDensityMeasurementCode: string;
}

export interface StopItemHazardousMaterialDetail {
    stopItemHazardousMaterialDetailID: string;
    driverCertificationRequiredIndicator: string;
    emergencyResponsePhoneNumber: string;
    hazardousMaterialSpecificationID: string;
    providerContractNumber: string;
    unitOfWeightMeasurementCode: string;
    netExplosiveMassQuantity: string;
    limitedQuantityIndicator: string;
    reportableQuantityIndicator: string;
    hazardousMaterialTechnicalname: string;
}

export interface StopItemSerialNumberDetail {
    stopitemSerialNumberDetailID: string;
    stopItemSerialNumber: string;
}

export interface StopItemServiceDetail {
    stopItemServiceDetailID: string;
    itemServiceID: string;
    itemServiceTypeCode: string;
    itemServiceDescription: string;
    itemServiceQuantity: string;
}

export interface StopReferenceNumber2 {
    referenceNumberID: string;
    referenceNumberTypeCode: string;
    referenceNumberValue: string;
    referenceNumberLevelTypeCode: string;
}

export interface StopItemReferenceNumberAssociation {
    stopItemReferenceNumberAssociationID: string;
    stopReferenceNumber: StopReferenceNumber2[];
}

export interface StopItem {
    stopItemID: string;
    packagingUnitTypeQuantity: string;
    freightClassCode: string;
    itemDensity: string;
    itemDescription: string;
    itemHeight: string;
    itemLength: string;
    itemQuantity: string;
    itemLengthType: string;
    itemVolumeType: string;
    itemStackingType: string;
    itemVolume: string;
    itemWeight: string;
    itemWidth: string;
    nmfcNumber: string;
    packagingUnitTypeCode: string;
    skuNumber: string;
    unitOfLengthMeasurementCode: string;
    unitOfVolumeMeasurementCode: string;
    unitOfWeightMeasurementCode: string;
    unitOfDensityMeasurementCode: string;
    stopItemHazardousMaterialDetails: StopItemHazardousMaterialDetail[];
    itemModelNumber: string;
    itemExtremeLengthIndicator: string;
    itemClassificationCode: string;
    itemTemperatureControlMethodCode: string;
    supplierSKU: string;
    itemMake: string;
    itemManufacturer: string;
    itemCategory: string;
    itemPartNumber: string;
    ItemProtectionType: string;
    itemUniversalProductCode: string;
    stopItemSerialNumberDetail: StopItemSerialNumberDetail[];
    stopItemServiceDetail: StopItemServiceDetail[];
    StopItemReferenceNumberAssociation: StopItemReferenceNumberAssociation[];
}

export interface StopItemHandlingDetailAssociation {
    stopItemHandlingDetailAssociationID: string;
    itemHandlingDetail: ItemHandlingDetail;
    stopItem: StopItem;
}

export interface ReferenceNumberDTO {
    referenceNumberTypeDescription?: any;
    referenceNumber?: any;
    firstName: string;
    lastName?: any;
    stopLocationCode?: any;
    stopSequenceNumber?: any;
    lastUpdateTimestamp?: any;
}

export interface OrderMaterialHandlingRequirementAssociation {
    orderMaterialHandlingRequirementAssociationID: number;
    materialHandlingRequirementCode?: any;
    materialHandlingRequirementQuantity: number;
    lastUpdateTimestampString?: any;
}

export interface OrderUnifiedCustomerRequestAssociation {
    orderUnifiedCustomerRequestAssociationID: number;
    unifiedCustomerRequestID: number;
    lastUpdateTimestampString?: any;
}

export interface OrderCarrierDetail {
    carrierName?: any;
    carrierQuoteNumber?: any;
    carrierBoothNumber?: any;
    lastUpdateTimestampString?: any;
}

export interface OrderStatusWorkflow {
    orderStatusWorkflowID: number;
    orderProgressStatusCode?: any;
    lastUpdateTimestampString?: any;
}

export interface OrderStatusEvent {
    orderStatusEventComment?: any;
    orderStatusEventReasonID: number;
    lastUpdateTimestampString?: any;
}

export interface OrderFoodSafetyDetail {
    OrderEquipmentRequirementSpecificationDetailID: number;
    lastUpdateTimestampString?: any;
}

export interface OrderOwnership {
    taskAssignmentID: string;
    backupTaskAssignmentID: string;
    appointmentID: string;
    effectiveTimestamp?: string;
    expirationTimestamp?: string;
}

export interface Stop {
    stopID: string;
    locationCode: string;
    locationContactID: string;
    locationContactType: string;
    highCostDeliveryIndicator: string;
    stopReason: string;
    stopSequenceNumber: string;
    totalStopWeight: string;
    unitOfWeightMeasurementCode: string;
    initialOfferedDate: string;
    stopCharges: StopCharge[];
    stopComments: StopComment[];
    stopServices: StopService[];
    stopReferenceNumbers: StopReferenceNumber[];
    appointment: Appointment[];
    stopItemHandlingDetailAssociation: StopItemHandlingDetailAssociation[];
    referenceNumberDTOs: ReferenceNumberDTO[];
    orderMaterialHandlingRequirementAssociation: OrderMaterialHandlingRequirementAssociation[];
    servicePriorityTypeCode?: any;
    orderTypeCode?: any;
    orderSubTypeCode?: any;
    orderValueTypeCode?: any;
    orderVolumeTypeCode?: any;
    orderRefrigeratedIndicator?: any;
    orderGroupingID?: any;
    orderUnifiedCustomerRequestAssociations: OrderUnifiedCustomerRequestAssociation[];
    orderAdditionalInstructions?: any;
    orderCarrierDetails: OrderCarrierDetail[];
    orderStatusWorkflows: OrderStatusWorkflow[];
    orderStatusEvents: OrderStatusEvent[];
    orderFoodSafetyDetails: OrderFoodSafetyDetail[];
}

export interface StopDTO {
    stopMiles?: any;
    totalStopMiles?: any;
    totalOrderWeight?: any;
    totalStopWeight?: any;
    locationDTO?: any;
    stop: Stop;
}

export interface IOrderDtoModel {
    orderID: number;
    serviceOfferingCode?: any;
    shipmentIdentificationNumber?: any;
    orderSourceCode?: any;
    orderAdditionalInstruction?: any;
    orderTrackingNumber?: any;
    orderValueAmount?: any;
    orderStatusCode?: any;
    customerID?: any;
    requestedServiceLevelCode?: any;
    transitModeCode?: any;
    financeBusinessUnitCode?: any;
    orderHighValueIndicator: boolean;
    owner?: any;
    creator?: any;
    chargeDTOs: ChargeDTO[];
    orderBillingDetailDTOs: OrderBillingDetailDTO[];
    orderServices: OrderService[];
    orderRequestorDTOs: OrderRequestorDTO[];
    orderAssociatedParties: OrderAssociatedParty[];
    internationalOrderElement: InternationalOrderElement[];
    internationalService: InternationalService[];
    orderCrossesBorderDetailDTOs: OrderCrossesBorderDetailDTO[];
    orderOperationalElements: OrderOperationalElement[];
    orderMonitorInformations: OrderMonitorInformation[];
    orderEquipmentRequirementDTOs: OrderEquipmentRequirementDTO[];
    orderOwnership: OrderOwnership[];
    commentDTOs: CommentDTO[];
    stopDTOs: StopDTO[];
}

// }
