import { AfterViewInit, Component, ElementRef, Input, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Validators } from '@angular/forms';

// import {TypeaheadComponent} from './typeahead/typeahead.component';
// import {AddcontactComponent} from './addcontact/addcontact.component';
import { OrderService } from '../../services/order.service';
import { OrderFormBuilderService } from '../../services/order-form-builder.service';

import { JBHGlobals } from '../../../../../app.service';

@Component({
    selector: 'app-accountinformation',
    templateUrl: './accountinformation.component.html',
    styleUrls: ['./accountinformation.component.scss']
})
export class AccountinformationComponent implements OnInit, AfterViewInit, OnDestroy {
    radioSelectFlag = false;
    selectFlag: boolean;
    subscription: any;
    orderData: any;
    orderId: any;
    ownerName: any;
    // copies  = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
    copies: Array<string> = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10'];
    dataPopulated = true;

    @Input() orderBillingDetail: any;
    @Input() accountInfoForm: any;
    @Input() isCurrViewTemplate: boolean;
    @Input() TempStatus: string;
    @Input() tempOwner: any;
    @ViewChild('r1') billingDetailsRadio;
    @ViewChild('selectvalue') selectvalue: ElementRef;
    @ViewChild('selCopies') selCopies: ElementRef;
    constructor(public orderFormBuilder: OrderFormBuilderService,
                public orderService: OrderService,
                public jbhGlobals: JBHGlobals) { }

    ngOnInit(): void {
        this.orderBillingDetail = this.orderFormBuilder.orderForm['controls']['orderBillingDetail'];
        this.accountInfoForm = this.orderFormBuilder.orderForm.controls['orderBillingDetail']['controls']['accountInfoForm'];
        // if (typeof(Storage) !== 'undefined') {
        //      localStorage.setItem('orderCount', '1');
        // }
        // this.populateData();
        // console.log(this.selectvalue);
        this.subscription = this.orderService.getData().subscribe(data => {
            if (!this.jbhGlobals.utils.isEmpty(data)) {
                this.orderData = data;
                this.orderId = this.orderData.orderID;
                if (this.dataPopulated) {
                  this.populateData();
                  this.dataPopulated = false;
                }
            }
        });
        this.templateOwner();
    }

    ngAfterViewInit() {
        if (this.orderService.getOrderCopies() > 0) {
            const copies = this.orderService.getOrderCopies();
            this.selectvalue.nativeElement.value = copies;
        }
    }

    ngOnDestroy(): void {
        this.orderBillingDetail.reset();
        this.subscription.unsubscribe();
    }

    radio(value) {
        if (value === 'billToAccountRadio') {
            this.radioSelectFlag = false;
            this.accountInfoForm['controls']['lineofBusiness'].setValidators([]);
            this.accountInfoForm['controls']['lineofBusiness'].updateValueAndValidity({ onlySelf: true, emitEvent: false });
            this.accountInfoForm['controls']['lineofBusiness'].setValue('');
            this.accountInfoForm['controls']['billToCode'].setValidators([Validators.required,
            this.jbhGlobals.customValidator.alphaNumeric]);
            this.accountInfoForm['controls']['billToCode'].updateValueAndValidity({ onlySelf: true, emitEvent: false });

        } else {
            this.radioSelectFlag = true;
            this.accountInfoForm['controls']['billToCode'].setValidators([]);
            this.accountInfoForm['controls']['billToCode'].updateValueAndValidity({ onlySelf: true, emitEvent: false });
            this.accountInfoForm['controls']['billToCode'].setValue('');
            this.accountInfoForm['controls']['lineofBusiness'].setValidators([Validators.required,
            this.jbhGlobals.customValidator.alphaNumeric]);
            this.accountInfoForm['controls']['lineofBusiness'].updateValueAndValidity({ onlySelf: true, emitEvent: false });

        }

    }

    onChangeDropDown(value) {
        this.orderService.setOrderCopies(value.text);
    }

    onValidateForm() {
        const me = this;
        this.jbhGlobals.utils.forIn(this.accountInfoForm.controls,
            function (value, name, object) {
                me.accountInfoForm.controls[name].markAsTouched();
            });
    }

    templateOwner() {
        if (this.isCurrViewTemplate) {
            this.ownerName = [];
            if (this.tempOwner && this.tempOwner[0]) {
                const length = (this.tempOwner.length) > 3 ? 3 : this.tempOwner.length;
                for (let i = 0; i < length; i++) {
                    if (this.tempOwner[i] && this.tempOwner[i]['personDTO']) {
                        const obj = {};
                        obj['firstName'] = this.tempOwner[i]['personDTO']['firstName'] + ' ' + this.tempOwner[i]['personDTO']['lastName'];
                        obj['details'] = this.tempOwner[i]['personDTO'];
                        obj['employeeTaskScheduleList'] = this.employeeListSorter(this.tempOwner[i]['employeeTaskScheduleList']);
                        this.employeeScheduleList(obj);
                        this.ownerName.push(obj);
                    }
                }
            }
        }
    }
    employeeListSorter(dataList) {
        if (dataList) {
        const arr = [null, null, null, null, null, null, null];
        for (const dataObj of dataList) {
            switch (dataObj['employeeTaskScheduleDay']) {
                case 'MONDAY':
                    arr[0] = dataObj;
                    break;
                case 'TUESDAY':
                    arr[1] = dataObj;
                    break;
                case 'WEDNESDAY':
                    arr[2] = dataObj;
                    break;
                case 'THURSDAY':
                    arr[3] = dataObj;
                    break;
                case 'FRIDAY':
                    arr[4] = dataObj;
                    break;
                case 'SATURDAY':
                    arr[5] = dataObj;
                    break;
                case 'SUNDAY':
                    arr[6] = dataObj;
                    break;
                default:
                    break;
            }
        }
        return arr;
        }
        return null;
    }
    returnTime(time) {
        let twelveHrsTime = '';
        if ((time.indexOf('AM') === -1) && (time.indexOf('PM') === -1)) {
          const convertTime = Number(time.substring(0, 2));
          if (convertTime > 12) {
            const twelveHrsFormat = convertTime - 12;
            twelveHrsTime = twelveHrsFormat.toString() + ':' + time.substring(3,
              5).toString() + 'PM';
          } else if (convertTime === 12) {
            twelveHrsTime = convertTime.toString() + ':' + time.substring(3, 5).toString() +
              'AM';
          } else {
            twelveHrsTime = convertTime.toString() + ':' + time.substring(3, 5).toString() +
              'AM';
          }
        } else {
          twelveHrsTime = time;
        }
        return twelveHrsTime;
  }

  employeeScheduleList(employeDetails) {
      if (employeDetails && employeDetails['employeeTaskScheduleList']) {
        employeDetails['rows'] = [];
        const scheduleList = employeDetails['employeeTaskScheduleList'];
        for (let k = 0; k < scheduleList.length; k++) {
            if (scheduleList[k]) {
              scheduleList[k].employeeTaskScheduleStartTime = this.returnTime(scheduleList[k].employeeTaskScheduleStartTime);
              scheduleList[k].employeeTaskScheduleEndTime = this.returnTime(scheduleList[k].employeeTaskScheduleEndTime);
            }
        }
        employeDetails['rows'].push(scheduleList);
      }
  }
    populateData() {
        if (this.orderData && this.orderData.orderBillingDetailDTOs.length > 0) {
            if (this.orderData.orderBillingDetailDTOs[0].profileDTO.partyType !== 'LineOfBusiness') {
                this.radio('billToAccountRadio');
            } else {
                this.radio('lineOfBusinessRadio');
            }
        }
    }
}
