import { inject, TestBed } from '@angular/core/testing';

import { AccountinfotypeaheadService } from './accountinfotypeahead.service';

describe('AccountinfotypeaheadService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AccountinfotypeaheadService]
    });
  });

  it('should be created', inject([AccountinfotypeaheadService], (service: AccountinfotypeaheadService) => {
    expect(service).toBeTruthy();
  }));
});
