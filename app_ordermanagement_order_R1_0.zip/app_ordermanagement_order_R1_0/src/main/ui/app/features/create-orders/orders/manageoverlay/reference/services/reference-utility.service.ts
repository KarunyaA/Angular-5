import { Injectable, OnInit } from '@angular/core';
import { JBHGlobals } from '../../../../../../app.service';
import { ReferencesService } from './references.service';
@Injectable()
export class ReferenceUtilityService {
  jsonpatch: any;
  constructor(private jbhGlobals: JBHGlobals) {}

  referenceValueOnBlur(oRefOval, referencesModel) {
    if (oRefOval && oRefOval !== null && oRefOval !== '') {
      referencesModel.refValValidate = false;
    } else {
      referencesModel.refValValidate = true;
    }
  }

  stopLevelValidate(stplevelvalue, referencesModel) {
    if (stplevelvalue && stplevelvalue !== null && stplevelvalue !== '') {
      referencesModel.stpLevelValidate = false;
    } else {
      referencesModel.stpLevelValidate = true;
    }
  }

  referenceTypeOnBlur(referencesModel, reftypevalue) {
    if (reftypevalue && reftypevalue !== null && reftypevalue !== '') {
      referencesModel.refTypeValidate = false;
    } else {
      referencesModel.refTypeValidate = true;
    }
  }

  getReferencesType(referencesModel) {
    if (referencesModel.getreferencesType) {
      referencesModel.refTypeArr = referencesModel.getreferencesType
        ._embedded.referenceNumberTypes;
    }
  }

  reloadStopLevels(referencesModel) {
    for (let i = 0; i < referencesModel.stopNIds.length; i++) {
      if (referencesModel.stopNIds[i].stop.stopID !== null && referencesModel
        .stopNIds[i].stop.stopID !== '') {
        const stpNbr = referencesModel.stopNIds[i].stop.stopSequenceNumber;
        referencesModel.stopNums.push(stpNbr);
      }
    }
    referencesModel.stopNums = this.jbhGlobals.utils.uniq(referencesModel.stopNums);
  }

  loadStopLevels(referencesModel) {
    if (referencesModel.stopNIds.length === 0) {
      referencesModel.pRefTypeFlag = false;
      referencesModel.pRefValueFlag = false;
    } else {
      referencesModel.pRefTypeFlag = true;
      referencesModel.pRefValueFlag = true;
    }
    if (referencesModel.stopNIds.length !== 0) {
      for (let i = 0; i < referencesModel.stopNIds.length; i++) {
        if (referencesModel.stopNIds[i].stop.stopID !== null && referencesModel
          .stopNIds[i].stop.stopID !== '') {
          const stpNbr = referencesModel.stopNIds[i].stop.stopSequenceNumber;
          referencesModel.stopNums.push(stpNbr);
        }
        referencesModel.stopNums = this.jbhGlobals.utils.uniq(referencesModel
          .stopNums);
      }
    }
  }

  resetValidations(referencesModel) {
    referencesModel.refTypeValidate = false;
    referencesModel.refValValidate = false;
    referencesModel.stpLevelValidate = false;
  }

  setParentReferenceFlags(referencesModel) {
    if (referencesModel.associatedRefArr && referencesModel
      .associatedRefArr.length !== 0) {
      referencesModel.pRefTypeFlag = true;
      referencesModel.pRefValueFlag = true;
    } else {
      referencesModel.pRefTypeFlag = false;
      referencesModel.pRefValueFlag = false;
    }
  }

  getTreeTemplatewithTooltip(referencesModel) {
    const values = referencesModel.requiredValues;
    referencesModel.tree = referencesModel.tree +
    '<p class="refTooltip" tooltipHlper="' + values.className + '">' + values.desc +
    '</p> <li tabindex="0" class = "child-li ref-list pad-top10" data-desc-attr="' +
    values.className + '"style = "text-indent:' + values.indentVal + 'px;">' + values.displayDesc
    + ' ' + '<span>' + values.refNmbrValue + '</span></li>' +
    '<div class="clearfix pad-bot10 border-bottom refDivShow"><div class="pull-right pad-top10 pad-bottom10">' +
    '<a class="stopEdtBtn font12 link-primary pad-right10" data-desc-attr="' +
    values.className + '">Edit</a>' + '<a class="stopDelBtn link-primary font12" data-desc-attr="' +
    values.className + '">Delete</a></div></div>';
    referencesModel.selRefDiv = null;
  }

  getTreeTemplateWithoutTooltip(referencesModel) {
    const values = referencesModel.requiredValues;
    referencesModel.tree = referencesModel.tree +
    '<li class="child-li ref-list pad-top10" data-desc-attr="' +
    values.className + '"style="text-indent:' + values.indentVal + 'px;">' + values.displayDesc
    + ' ' + '<span>' + values.refNmbrValue + '</span></li>' +
    '<div class="clearfix pad-bot10 border-bottom refDivShow"><div class="pull-right pad-top10 pad-bottom10">' +
    '<a class="stopEdtBtn font12 link-primary pad-right10" data-desc-attr="' +
    values.className + '">Edit</a>' + '<a class="stopDelBtn link-primary font12" data-desc-attr="' +
    values.className + '">Delete</a></div></div>';
    referencesModel.selRefDiv = null;
  }

  finalizeDeleteOverlay(referencesModel) {
    referencesModel.tree = referencesModel.tree +
    '<div style="border: 1px solid #eee; width:90%; background:#fff;height:60px">' +
    '<div class="pull-left" style="width:20px; height:60px;background-color:#ccc;">&nbsp;</div>' +
    '<div class="pad5"><div class="col-md-9">' +
    '<div><strong>Info</strong></div>' + '<div class="pad-top5">Reference was deleted</div>' +
    '<div class="pad-top5"><a href="javascript:void(0)" class="undoOverlay">Undo</a></div></div><div class="col-md-1">' +
    '<span class="icon-jbh_close icon14 permanentDeleteComment" data-desc-attr="' +
    referencesModel.requiredValues.className + '"> </span>' + ' </div>' + '</div></div>';
  }

  templateWithToolTip(referencesModel) {
    const values = referencesModel.requiredValues;
    referencesModel.tree = referencesModel.tree +
    '<p class="refTooltip" tooltipHlper="' + values.className + '">' + values.desc +
    '</p> <li class="child-li ref-list pad-top10" data-desc-attr="' +
    values.className + '"style = "text-indent:' + values.indentVal + 'px;">' + values.displayDesc
     + ' ' + '<span>' + values.refNmbrValue + '</span></li>' +
    '<div class="clearfix pad-bot10 border-bottom refDivHide"><div class="pull-right pad-top10 pad-bottom10">' +
    '<a class="stopEdtBtn font12 link-primary pad-right10" data-desc-attr="' +
    values.className + '">Edit</a>' + '<a class="stopDelBtn link-primary font12" data-desc-attr="' +
    values.className + '">Delete</a></div></div>';
  }

  templateWithoutToolTip(referencesModel) {
    const values = referencesModel.requiredValues;
    referencesModel.tree = referencesModel.tree +
    '<li class="child-li ref-list pad-top10" data-desc-attr="' +
    values.className + '"style="text-indent:' + values.indentVal + 'px;">' + values.displayDesc
    + ' ' + '<span>' + values.refNmbrValue + '</span></li>' +
    '<div class="clearfix pad-bot10 border-bottom refDivHide"><div class="pull-right pad-top10 pad-bottom10">' +
    '<a class="stopEdtBtn font12 link-primary pad-right10" data-desc-attr="' +
    values.className + '">Edit</a>' + '<a class="stopDelBtn link-primary font12" data-desc-attr="' +
    values.className + '">Delete</a></div></div>';
  }

  assignReferenceValues(referencesModel) {
    const processStopValues = referencesModel.processStopDeleteValues;
    processStopValues.selectedStopId = processStopValues.sid; // stopId used in ViewOrder
    processStopValues.pRefTypeFlag = false; // enabling ParRefType
    processStopValues.pRefValueFlag = false; // enabling ParRefVal
    if (processStopValues.pRefTypeValReference) { // Clearing active tag
      processStopValues.pRefTypeValReference.active = [];
    }
    referencesModel.oldStopDesc = processStopValues.sDescriptn; // Used to get Obj in Stop Update
    referencesModel.srefNumberTypCode = processStopValues.srefNumbTypCode; // Used in stop edit update
    referencesModel.sRefNumbrValue = processStopValues.sRefNumbrVal; // Used in stop edit update
    referencesModel.stopEdtRefNumId = processStopValues.sid;
    referencesModel.selectedStopId = processStopValues.sid;
    referencesModel.stopEdit = true;
    referencesModel.editRefShow = true;
  }

  processStopDelete(referencesModel) {
    const processStopValues = referencesModel.processStopDeleteValues;
    if (referencesModel.orderRefLstz.length !== 0) {
      for (let i = 0; i < referencesModel.orderRefLstz.length; i++) {
        if (processStopValues.sid.toString() === referencesModel.orderRefLstz[i].referenceNumber
          .referenceNumberID.toString()) {
          referencesModel.edtStpObj = referencesModel.orderRefLstz[i];
        }
      }
    }
    // setting sel Optns in RefType dropDown
    referencesModel.edtSelVal = referencesModel.edtStpObj.referenceNumberTypeDescription;
    referencesModel.oRefOval = referencesModel.edtStpObj.referenceNumber
      .referenceNumberValue;
    referencesModel.sSeqNum = referencesModel.edtStpObj.stopSequenceNumber;
    referencesModel.edtSelNum = referencesModel.sSeqNum; // setting seq number
    // Edit Logic STarts
    referencesModel.orderRefSrchLst = referencesModel.orderRefLstz;
    if (referencesModel.orderRefSrchLst.length !== 0) {
      for (let i = 0; i < referencesModel.orderRefSrchLst.length; i++) {
        if (referencesModel.orderRefSrchLst[i].referenceNumberDTOs !==
          null) {
          for (let j = 0; j < referencesModel.orderRefSrchLst[i].referenceNumberDTOs
            .length; j++) {
            if (referencesModel.orderRefSrchLst[i].referenceNumberDTOs[
              j]
            .referenceNumberTypeDescription !== null) {
            if (referencesModel.orderRefSrchLst[i].referenceNumberDTOs[
                j]
              .referenceNumberTypeDescription.toString() === referencesModel
              .edtSelVal.toString() &&
              referencesModel.orderRefSrchLst[i].referenceNumberDTOs[
                j]
              .referenceNumber.referenceNumberValue.toString() ===
              referencesModel.oRefOval.toString()
            ) {
              referencesModel.aParentRefObj.push(referencesModel
                .orderRefSrchLst[i]);
            }
          }
          }
        }
      }
    }
  }

  getStopAssiciatedIdnumber(referencesModel) {
    for (let f = 0; f < referencesModel.stopNIds.length; f++) {
      if (referencesModel.stopNIds[f].stop.stopID !== null) {
        if (referencesModel.stopNIds[f].stop.stopSequenceNumber.toString() ===
          referencesModel.sSeqNum.toString()) {
          referencesModel.stpIDForAssoRefNum = referencesModel.stopNIds[f].stop.stopID;
        }
      }
    }
  }

  initiateSaveCallForreferences(referencesModel) {
    referencesModel.asParRefVals = [];
    if (referencesModel.associatedRefArr.length !== 0) {
      referencesModel.pRefTypeArr = []; // Emptying Par Ref Type Array
      for (let f = 0; f < referencesModel.associatedRefArr.length; f++) {
        if (referencesModel.associatedRefArr[f].referenceNumberTypeDescription) {
          referencesModel.pRefTypeArr.push(referencesModel
            .associatedRefArr[f].referenceNumberTypeDescription
          );
        }
      }
      referencesModel.pRefTypeArr = this.jbhGlobals.utils
        .uniq(referencesModel.pRefTypeArr);
      for (let k = 0; k < referencesModel.associatedRefArr.length; k++) {
        if (referencesModel.associatedRefArr[k].referenceNumberTypeDescription) {
          if (referencesModel.associatedRefArr[k].referenceNumberTypeDescription
            .toString() === referencesModel.edtSelVal.toString()) {
            referencesModel.asParRefVals.push(referencesModel
              .associatedRefArr[k].referenceNumber.referenceNumberValue);
          }
        }
      }
    }
  }

  orderDelete(referencesModel, index) {
    referencesModel.deletePatchIndex = index;
    referencesModel.showDeleteOverlay = index; // Showing deleteOverlay
    referencesModel.descriptionWrapper = index; // hiding Desc section
  }

  getStopIdForStopSave(referencesModel, parReftype, stplevelValue) {
    referencesModel.associatedPref = parReftype;
    referencesModel.stopLvel = stplevelValue; // stopLevel seq Num
    referencesModel.asParRefVals = []; // clearing the associated parent ref value
    if (referencesModel.associatedRefArr.length !== 0) {
      for (let k = 0; k < referencesModel.associatedRefArr.length; k++) {
        if (referencesModel.associatedRefArr[k].referenceNumberTypeDescription !==
          null &&
          referencesModel.associatedRefArr[k].referenceNumberTypeDescription ===
          referencesModel.associatedPref
        ) {
          referencesModel.asParRefVals.push(referencesModel.associatedRefArr[
            k].referenceNumber.referenceNumberValue);
        }
      }
    }
    referencesModel.asParRefVals = this.jbhGlobals.utils.uniq(referencesModel
      .asParRefVals);
    // Logic to get refTypeNumCOde To Be used on STop Save
    if (referencesModel.stopNIds.length !== 0) { // To get stopId based on stpSeqNum frm drpDwn
      for (let i = 0; i < referencesModel.stopNIds.length; i++) {
        if (referencesModel.stopNIds[i].stop.stopID !== null && referencesModel
          .stopNIds[i].stop.stopID !== '') {
          const stpNbr = referencesModel.stopNIds[i].stop.stopSequenceNumber;
          if (stpNbr.toString() === referencesModel.stopLvel.toString()) {
            referencesModel.stopIDStpSave = referencesModel.stopNIds[
              i].stop.stopID;
          }
        }
      }
    }
  }

  getStopreferenceNumberCode(referencesModel) {
    if (referencesModel.assoRefForAsPrefTypCode) {
      for (let h = 0; h < referencesModel.assoRefForAsPrefTypCode
        .length; h++) {
        if (referencesModel.assoRefForAsPrefTypCode[h].referenceNumberTypeDescription) {
          if (referencesModel.associatedPref === referencesModel
            .assoRefForAsPrefTypCode[h].referenceNumberTypeDescription
          ) {
            referencesModel.stpRefNumTypCdeForSave = referencesModel.assoRefForAsPrefTypCode[
                h].referenceNumber.referenceNumberTypeCode;
          }
        }
      }
    }
  }

  performOrderEditDelete(referencesModel, index) {
    referencesModel.oUpdateIndex = index;
    referencesModel.oRefId = referencesModel.orderRefLst[index].referenceNumber
      .referenceNumberID;
    referencesModel.oRefCode = referencesModel.orderRefLst[index].referenceNumber
      .referenceNumberTypeCode;
    referencesModel.oRefNumVal = referencesModel.orderRefLst[index]
      .referenceNumber.referenceNumberValue;
    // setting sel Optn in RefType dropDown
    referencesModel.edtSelVal = referencesModel.orderRefLst[index].referenceNumberTypeDescription;
    referencesModel.oRefOval = referencesModel.oRefNumVal;
    if (referencesModel.edtSelVal !== undefined && referencesModel.oRefOval !==
      undefined) {
      referencesModel.orderRefUpdate = true;
    }
    referencesModel.editRefShow = true;
    referencesModel.enableDelete = index; // disabling delete btnOn editClick
  }

  referenceTypeOnselect(referencesModel, event) {
    if (referencesModel.getreferencesType && referencesModel.getreferencesType
      ._embedded.referenceNumberTypes) {
      for (let u = 0; u < referencesModel.getreferencesType._embedded.referenceNumberTypes
        .length; u++) {
        const tmpRefDesc = referencesModel.getreferencesType._embedded
          .referenceNumberTypes[u].referenceNumberTypeDescription;
        if (event.target.value === tmpRefDesc) {
          referencesModel.ordrStpEdtRefTypCode = referencesModel
            .getreferencesType._embedded.referenceNumberTypes[u].referenceNumberTypeCode;
        }
      }
    }
  }

  stopLevelOnselect(referencesModel, stplevl) {
    referencesModel.stopLvel = stplevl;
    referencesModel.edtSelNum = stplevl;
    if (referencesModel.stopNIds && referencesModel.stopNIds.length !==
      0 && referencesModel.stopLvel) {
      for (let f = 0; f < referencesModel.stopNIds.length; f++) {
        if (referencesModel.stopNIds[f].stop.stopID !== null) {
          if (referencesModel.stopNIds[f].stop.stopSequenceNumber.toString() ===
            referencesModel.stopLvel.toString()) {
            referencesModel.stpIDForAssoRef = referencesModel.stopNIds[
              f].stop.stopID;
          }
        }
      }
    }
  }

  setAssociatedParentReferenceArray(referencesModel) {
    referencesModel.uniqPrefType = []; // clearing Old RefTypeValues before pushing
    for (let f = 0; f < referencesModel.associatedRefArr.length; f++) {
      if (referencesModel.associatedRefArr[f].referenceNumberTypeDescription) {
        referencesModel.uniqPrefType.push(referencesModel
          .associatedRefArr[f].referenceNumberTypeDescription);
      }
    }
    referencesModel.pRefTypeArr = this.jbhGlobals.utils.uniq(
      referencesModel.uniqPrefType);
  }

  setParentReferenceTypeFlags(referencesModel) {
    referencesModel.pRefTypeFlag = false; // enabling AssociatedParentType
    referencesModel.pRefValueFlag = false; // enabling AssociatedParentValue
  }

  setParentReferenceTypeFlags2(referencesModel) {
    referencesModel.pRefTypeFlag = true; // disabling AssociatedParentType
    referencesModel.pRefValueFlag = true; // disabling AssociatedParentValue
  }

  findOrderIndexForPatch(referencesModel) {
    referencesModel.searchedOrderIndex = null;
    referencesModel.searchedOrderIndex = referencesModel.oUpdateIndex ?
      referencesModel.oUpdateIndex : referencesModel.deletePatchIndex;
    if (referencesModel.referencesList) {
      const orderArray = referencesModel.referencesList['Order'];
      referencesModel.orderPatchIndex = this.jbhGlobals.utils.findIndex(
        orderArray, orderArray[referencesModel.searchedOrderIndex]);
    }
  }
  getParentReferenceTypeFromForm(referencesModel, refForm, pRefTypeValReference, refType) {
    if (refForm.value.ParRefType !== undefined && pRefTypeValReference) {
      if (pRefTypeValReference.active.length !== 0) {
        if (refForm.value.ParRefType !== '') {
          referencesModel.prefType = refForm.value.ParRefType;
        }
        referencesModel.prefValTxt = pRefTypeValReference.active[0].text;
      }
    }
    referencesModel.stopLevelNum = referencesModel.stopLvel;
    const currRefTypeObj = this.jbhGlobals.utils.find(referencesModel
      .refTypeArr, ['referenceNumberTypeDescription', refType]);
    const refNumTypeCode = currRefTypeObj.referenceNumberTypeCode;
    return refNumTypeCode;
  }
}
