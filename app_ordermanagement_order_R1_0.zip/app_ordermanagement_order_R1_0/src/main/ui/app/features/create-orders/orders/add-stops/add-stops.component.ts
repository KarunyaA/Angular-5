import { Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';

import { JBHGlobals } from './../../../../app.service';
import { OrderFormBuilderService } from '../services/order-form-builder.service';
import { StopSharedDataService } from './services/stop-shared-data.service';
import { OrderService } from '../services/order.service';
import { AddStopsOrderService } from './services/add-stops-order.service';
import { HandlingunitService } from './services/handlingunit.service';
import { WebSocketService } from '../../../../shared/jbh-app-services/web-socket.service';

@Component({
    selector: 'app-add-stops',
    templateUrl: './add-stops.component.html',
    styleUrls: ['./add-stops.component.scss']
})

export class AddStopsComponent implements OnInit, OnDestroy {
    // tslint:disable:member-access
    @ViewChild('stopChild') stopChild: any;
    @ViewChild('saveDialog') saveDialog: any;
    @ViewChild('handlingUnitRef') handlingUnitRef: any;
    @ViewChild('handlingUnit') handlingUnit: any;
    @ViewChild('itemDetailsRef') itemDetailsRef: any;
    @ViewChild('cancelDialog') cancelDialog: any;
    @ViewChild('originSec') originSec: ElementRef;
    @ViewChild('destSec') destSec: ElementRef;
    @ViewChild('myModal') myModal: any;
    @ViewChild('popInstance') popInstance: any;
    @ViewChild('submissionModal') submissionModal: any;
       private wsConf: any;
    private connectionStatusSubscription: any = null;
    private shippingOptnSubscription: any = null;
    // private autoAcceptStatusSubscription: any = null;
    private collapseFlag = true;
    // tslint:disable:member-ordering
    index: number;
    stopId: number;
    errorMessage: string;
    subscription: any;
    orderData: any;
    orderID: any;
    debounceValue: number;
    newStopId: number;
    firstStopOpened = false;
    stopData: any;
    stopSaveActionSuccess = false;
    requestedAppts: any;
    scheduledAppts: any;
    businessUnitCode: string[] = ['DCS', 'ICS'];
    serviceOfferingCode: string[] = ['FinalMile', 'LTL'];
    orderTypeCode: string[] = ['Standard', 'Return', 'Other'];
    stopDataLoaded = false;
    businessUnit: boolean;
    serviceOffering: boolean;
    orderType: boolean;
    activeStop: any;
    activeAccordionList: any[] = [];
    stopResequenceList: any[] = [];
    isDataLoaded = true;
    copyarray: any[] = [];
    handlingUnitList: Array<Object>;
    deliveryhandlingUnitFlag: boolean;
    isFormSaved: any;
    errorMsg: any;
    navigationFlag = false;
    topicName: any;
    handlingUnitSave = true;
    focusDiv: any;
    private prevDiv: any;
    private currDiv: any;
    private orderSub;
    private stopSub;
    private mouseEventSub;
    private currentClickEventObj: any[] = [];
    private warningFlag = false;
    notificationList: any = [{
        'text': 'Initial Service Offering'
    }];
    currentStep = 1;
    isIcsFlatBed: boolean;

    constructor(public jbhGlobals: JBHGlobals,
        public orderFormBuilder: OrderFormBuilderService,
        public route: ActivatedRoute,
        public router: Router,
        public orderService: OrderService,
        public stopSharedDataService: StopSharedDataService,
        public addStopsOrderService: AddStopsOrderService,
        public handlingunitService: HandlingunitService,
        private stomp: WebSocketService) {
        this.wsConf = {
            host: this.jbhGlobals.endpoints.shippingoptions.messageConnection,
            debug: true
        };
    }

    ngOnInit(): void {
        this.stopSharedDataService.saveData([], 'add');
        this.orderService.saveData([]);
        this.orderService.loadOrder(this.route.snapshot.queryParams['id']);
        this.loadOrderData();
        this.debounceValue = this.jbhGlobals.settings.debounce;
        this.checkClosestClickEvent();
        this.setUpKeyboardShortcuts();
        this.getSocTopicName();
    }
    setUpKeyboardShortcuts() {
        this.jbhGlobals.shortkeys.getData().subscribe(data => {
            if (data.keyCode === 'alt+1') {
                const popUpStatus = this.stopChild.appSiteProfile.popUpStatus;
                if (popUpStatus === true) {
                    this.stopChild.appSiteProfile.locationName.nativeElement.focus();
                } else {
                    this.stopChild.locDet.nativeElement.focus();
                }
            }
            if (data.keyCode === 'alt+2') {
                const popUpStatus = this.stopChild.appSiteProfile.popUpStatus;
                if (popUpStatus === true) {
                    this.stopChild.appSiteProfile.siteRequirements.nativeElement.focus();
                } else {
                    this.stopChild.handlingUnitRef.handlingUnit.handlingUnitDiv.nativeElement.focus();
                }
            }
            if (data.keyCode === 'alt+3') {
                const popUpStatus = this.stopChild.appSiteProfile.popUpStatus;
                if (popUpStatus === true) {
                    this.stopChild.appSiteProfile.genInstructions.nativeElement.focus();
                } else {
                    this.stopChild.handlingUnitRef.handlingUnit.itemDetailsRef.packageUnitRef.nativeElement.focus();
                }
            }
            if (data.keyCode === 'alt+4') {
                const popUpStatus = this.stopChild.appSiteProfile.popUpStatus;
                if (popUpStatus === true) {
                    this.stopChild.appSiteProfile.directions.nativeElement.focus();
                }
            }
            if (data.keyCode === 'alt+5') {
                const popUpStatus = this.stopChild.appSiteProfile.popUpStatus;
                if (popUpStatus === true) {
                    this.stopChild.appSiteProfile.facilityHours.nativeElement.focus();
                }
            }
            if (data.keyCode === 'ctrl+1') {
                this.originSec.nativeElement.click();
            }
            if (data.keyCode === 'ctrl+2') {
                this.destSec.nativeElement.click();
            }
            if (data.keyCode === 'alt+n') {
                const activeId = document.activeElement.id;
                document.getElementById(activeId).click();
            }
            if (data.keyCode === 'Tab') {
                this.prevDiv = this.currDiv;
                this.currDiv = this.getClosest(data.eventElement, 'section') ? this.getClosest(data.eventElement, 'section') : '';
                const prevTag = (this.prevDiv && this.prevDiv.id) ? this.prevDiv.id.split('-') : [];
                this.currentClickEventObj = [{ prevDivTag: prevTag, stopChild: this.stopChild }];
                if (this.currDiv !== this.prevDiv && this.prevDiv) {
                    this.handlingAndItemSaveCall(prevTag, this.stopChild);
                }
            }
        });
    }
    ngOnDestroy(): void {
        // this.orderSub.unsubscribe();
        // this.stopSub.unsubscribe();
        // this.mouseEventSub.unsubscribe();
        this.unsubscribeSockets();
    }
    addStopList() {
        if (this.stopResequenceList.length === 1) {
            this.stopResequenceList.push({
                stop: {
                    stopID: null,
                    stopSequenceNumber: 2
                }
            });
        } else if (this.stopResequenceList.length === 0) {
            this.stopResequenceList.push({
                stop: {
                    stopID: null,
                    stopSequenceNumber: 1
                }
            });
            this.stopResequenceList.push({
                stop: {
                    stopID: null,
                    stopSequenceNumber: 2
                }
            });
        }
    }
    getResequenceList() {
        let orderId: any;
        orderId = this.orderID + '/stops';
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getstopresequencelist + orderId).subscribe(data => {
            if (!this.jbhGlobals.utils.isEmpty(data)) {
                if (data['content'] && data['content'] !== undefined) {
                    this.stopResequenceList = data['content'];
                } else {
                    this.stopResequenceList = data;
                }
                this.addStopList();
            } else if (this.jbhGlobals.utils.isEmpty(data)) {
                this.stopResequenceList = [];
                this.addStopList();
            }
        }, (err: Error) => {
            return false;
        });
    }
    trackByFn(index, item) {
        return index;
    }
    loadOrderData() {
        if (this.jbhGlobals.utils.isEmpty(this.orderData)) {
            this.orderService.init();
        }
        this.stopSub = this.stopSharedDataService.getData().subscribe(data => {
            if (!this.jbhGlobals.utils.isEmpty(data)) {
                this.stopResequenceList = data[0].data;
            }
        });
        // if (this.jbhGlobals.utils.isEmpty(this.orderData)) {
        this.orderSub = this.orderService.getData().subscribe(sharedOrderData => {
            if (!this.jbhGlobals.utils.isEmpty(sharedOrderData)) {
                this.orderData = sharedOrderData;
                this.orderID = this.orderData.orderID;
                if (this.isDataLoaded) {
                    // this.getResequenceList();
                    this.stopSharedDataService.getStopsSummary(this.orderID);
                }
                // this.stopReason = this.orderData.stopDTOs[0].stop.stopReason;
                this.businessUnit = this.isServiceOfferingExist();
                this.serviceOffering = this.isBusinessUnitExist();
                this.orderType = this.isOrderTypeExist();
                this.isDataLoaded = false;
                this.isIcsFlatBed = this.isIcsFlatBedCheck();
            }
        }, (err: Error) => {
            return false;
        });
        // }
    }
    isBusinessUnitExist() {
        const businessUnit: string = this.orderData.financeBusinessUnitCode;
        if (!this.jbhGlobals.utils.isEmpty(businessUnit) && (this.businessUnitCode.indexOf(businessUnit) !== -1)) {
            return true;
        } else {
            return false;
        }
    }
    isServiceOfferingExist() {
        const serviceOffering: string = this.orderData.serviceOfferingCode;
        if (!this.jbhGlobals.utils.isEmpty(serviceOffering) && (this.serviceOfferingCode.indexOf(serviceOffering) !== -1)) {
            return true;
        } else {
            return false;
        }
    }
    isOrderTypeExist() {
        const orderType: string = this.orderData.orderTypeCode;
        if (!this.jbhGlobals.utils.isEmpty(orderType) && (this.orderTypeCode.indexOf(orderType) !== -1)) {
            return true;
        } else {
            return false;
        }
    }
    isIcsFlatBedCheck() {
        const businessUnit: string = this.orderData.financeBusinessUnitCode;
        const serviceOffering: string = this.orderData.serviceOfferingCode;
        if (businessUnit === 'ICS' && serviceOffering === 'Flatbed') {
            return false;
        } else {
            return true;
        }
    }
    getFistStop(stopId: number, group: any, stopPosition: number) {
        this.activeAccordionList = [{
            event: '', stopId: stopId, group: group,
            stopPosition: stopPosition
        }];
        if (stopPosition === 0 && !this.firstStopOpened) {
            this.activeStop = group;
            group.isOpen = true;
            this.firstStopOpened = true;
        }
        return false;
    }
    saveStopForm(event: any, stopId: number, group: any, stopPosition: number, stopCollapse: boolean): boolean {
        if (this.stopChild) {
            const stopDetails = (this.stopChild.orderData.stopDTOs) ? this.stopChild.orderData.stopDTOs.stop : '';
            if (this.validateStop(stopDetails, event, group, stopCollapse)) {
                if (this.activeStop !== null) {
                    this.stopSaveActionSuccess = this.stopChild.stopDetailSaveForm('cur',
                        function (saveStatus) {
                            if (saveStatus !== undefined && saveStatus === false) {
                                if (event && event !== undefined) {
                                    event.stopPropagation();
                                }
                                return;
                            }
                        });
                    this.activeStop = null;
                }
                if (!group.isOpen) {
                    this.activeStop = group;
                }
            }
        }
        return true;
    }
    onStopCollapse(event: any, stopId: number, group: any, stopPosition: number) {
        this.activeAccordionList = [{
            event: event, stopId: stopId, group: group,
            stopPosition: stopPosition
        }];
        if (!group.isOpen) {
            this.collapseFlag = true;
            this.checkClosestClickEvent();
        }
        this.saveStopForm(event, stopId, group, stopPosition, true);
        this.handlingUnitSave = true;
    }
    stopFormSubmit(page: string) {
        if (this.stopChild) {
            const stopDetails = (this.stopChild.orderData.stopDTOs) ? this.stopChild.orderData.stopDTOs.stop : '';
            if (this.validateStop(stopDetails, this.activeAccordionList[0].event, this.activeAccordionList[0].group, false)) {
                this.stopChild.stopDetailSaveForm(page);
            }
        }
    }
    stopSavePrompt() {
        // if (this.stopChild.dirty) {
        this.saveDialog.show();
        // }
    }
    onStopCancel() {
        this.router.navigateByUrl('/createorders/order/create?id=' + this.orderData.orderID);
        // this.jbhGlobals.commonDataService.setFromStopCheckFlag(true);
    }
    goBack() {
        this.router.navigateByUrl('/createorders/order/create?id=' + this.orderData.orderID);
    }
    preventCollpase(event) {
        event.stopPropagation();
    }
    addAppointment(appt: number) {
        if (appt === 0) {
            this.orderData.stopDTOs.stop.appointment.push(this.orderFormBuilder.requestedAppointments());
        }
        if (appt === 1) {
            this.orderData.stopDTOs.stop.appointment.push(this.orderFormBuilder.scheduledAppointments());
        }
        // this.orderData.stopDTOs.stop.appointment.push(apptCtrl);
        // this.orderService.saveData(this.orderData);
    }
    removeResequenceStop(event) {
        if (event) {
            this.removeStop(event.event, event.index, event.stopId, null);
        }
    }
    removeStop(event, indx: number, stopId: number, popover) {
        if (popover) {
            popover.hide();
        }
        this.popInstance.deleteButtonModal.show();
        this.index = indx;
        this.stopId = stopId;
        event.stopPropagation();
    }
    onDelete(eve) {
        if (eve.flag) {
            this.stopResequenceList.splice(this.index, 1);
            if (this.stopId && this.stopId !== undefined) {
                const stopID = '/' + this.stopId;
                this.jbhGlobals.apiService.removeData(this.jbhGlobals.endpoints.order.crudStopDetails + stopID).subscribe(chargeData => {
                    this.jbhGlobals.logger.info('Stop Deleted');
                }, (err: Error) => {
                    return false;
                });
            }
            eve.model.hide();
        } else {
            eve.model.hide();
        }
    }

    initAddStopDetails(event, group: any, indx: number, seqNo: number) {
        // console.log(this.addStopsOrderService.getRequestedStopFlag());
        // const getrequestedstopflag = this.addStopsOrderService.getRequestedStopFlag();
        // if( !getrequestedstopflag && finalStop) {
        //     this.addStopsOrderService.setLiveloadFlag();
        // }
        const stopCtrl = {
            'stop': {
                'stopID': '',
                'stopSequenceNumber': (seqNo + 1)
            }
        };
        if (this.stopChild) {
            const stopDetails = (this.stopChild.orderData.stopDTOs) ? this.stopChild.orderData.stopDTOs.stop : '';
            if (this.validateStop(stopDetails, event, group, false)) {
                this.stopResequenceList.splice((indx + 1), 0, stopCtrl);
                group.isOpen = true;
            }
        }
    }
    onSubmit(val) {
        console.log(val.value);
    }
    checkClosestClickEvent() {
        this.mouseEventSub = this.jbhGlobals.mouseevents.getData().subscribe(data => {
            if (!this.jbhGlobals.utils.isEmpty(data) && this.stopChild !== undefined && this.stopChild && this.stopChild.handlingUnitRef) {
                const targetElement = !this.handlingUnitSave ? data.target : this.stopChild.handlingUnitRef.handlingUnit.handlingDiv.nativeElement;
                this.prevDiv = this.currDiv;
                this.currDiv = this.getClosest(targetElement, 'section') ? this.getClosest(targetElement, 'section') : '';
                this.focusDiv = this.getClosest(data.target, 'section') ? this.getClosest(data.target, 'section') : '';
                const prevTag = (this.prevDiv && this.prevDiv.id) ? this.prevDiv.id.split('-') : [];
                this.currentClickEventObj = [{ prevDivTag: prevTag, stopChild: this.stopChild }];
                if ((this.currDiv !== this.prevDiv && this.prevDiv) || (this.collapseFlag && this.focusDiv)
                    || (this.handlingUnitSave && !this.stopChild.handlingUnitRef.handlingForm['touched']) ) {
                    this.handlingUnitSave = false;
                    this.collapseFlag = false;
                    this.handlingAndItemSaveCall(prevTag, this.stopChild);
                }
            }
        }, (err: Error) => {
            this.jbhGlobals.logger.info(err);
        });
    }
    handlingAndItemSaveCall(prevTag, stopChild) {
        if (!this.jbhGlobals.utils.isEmpty(prevTag) && !this.jbhGlobals.utils.isEmpty(stopChild)) {
            const handlingArray = stopChild.handlingUnitRef.handlingComponent.toArray();
            const handlingIndex = parseInt(prevTag[1], 10);
            if (prevTag[0] === 'handlingDiv') {
                const handlingComponent = handlingArray[handlingIndex];
                if (handlingComponent) {
                    handlingComponent.handlingUnitSaveCall();
                }
            } else if (prevTag[0] === 'itemDiv') {
                const itemIndex = parseInt(prevTag[2], 10);
                handlingArray[handlingIndex].itemComponent.handlingUnitSave = this.handlingUnitSave;
                const itemComponent = handlingArray[handlingIndex].itemComponent.toArray()[itemIndex];
                itemComponent.itemFormSaveCall();
            }
        }
    }
    conditionalCheck(businessUnit, serviceOffering, orderType) {
        let isValid = true;
        if (this.stopChild) {
            const stopDetails = (this.stopChild.orderData.stopDTOs) ? this.stopChild.orderData.stopDTOs.stop : '';
            if (stopDetails && (!stopDetails.locationID || this.jbhGlobals.utils.isEmpty(stopDetails.stopReason))) {
                this.jbhGlobals.notifications.alert('Warning', 'Please enter stop location & stop reason');
                isValid = false;
            } else if (stopDetails && this.stopChild.handlingUnitRef) {
                const handlingForm = this.stopChild.handlingUnitRef.handlingComponent.first;
                const itemForm = handlingForm.itemComponent.first;
                if (!handlingForm.handlingModel.handlingUnitId || !itemForm.itemModel.stopItemID) {
                    isValid = false;
                    this.jbhGlobals.notifications.alert('Warning', 'Stops should have atleast one handling unit and item');
                }
            }
        }
        if (isValid) {
            // if (businessUnit === 'DCS' && serviceOffering === 'FinalMile' && orderType === 'Standard' &&
            //     stopReason !== 'Delivery') {
            //     this.jbhGlobals.notifications.alert('Warning', 'Delivery Stop details must be filled');
            //     isValid = false;
            // } else
            if (businessUnit === 'ICS' && serviceOffering === 'LTL' && orderType === 'Return' &&
                this.stopChild && this.stopChild.stopReasonType !== 'Pickup') {
                this.jbhGlobals.notifications.alert('Warning', 'Pickup Stop details must be filled');
                isValid = false;
            }
        }
        return isValid;
    }
    checkDeliveryHandlingUnit() {
        const url = this.jbhGlobals.endpoints.order.updateorder + '' + this.orderID + '/fetchUnDeliveredItems';
        this.handlingunitService.fetchUndeliveredHandling(url).subscribe(data => {
            this.handlingUnitList = data;
            console.log(this.handlingUnitList);
            if (this.handlingUnitList !== undefined && this.handlingUnitList.length === 0) {
                this.deliveryhandlingUnitFlag = true;
            } else {
                this.deliveryhandlingUnitFlag = false;
            }
            this.saveStopAndNavigate();
        });

    }
    orderSubmission(event) {
        this.orderService.setShowOrHideOverlay(false);
        let accordionEvent: any;
        // if (typeof(Storage) !== 'undefined') {
        //    orderCount = localStorage.getItem('orderCount');
        // }
        // orderCount = this.jbhGlobals.commonDataService.getCopies();
        this.isFormSaved = false;
        let conditionalCheck = false;
        if (!this.jbhGlobals.utils.isEmpty(this.activeAccordionList) && this.activeAccordionList[0].event) {
            accordionEvent = this.activeAccordionList[0].event;
        } else {
            // accordionEvent = event;
            accordionEvent = '';
        }
        conditionalCheck = this.conditionalCheck(this.orderData.financeBusinessUnitCode, this.orderData.serviceOfferingCode,
            this.orderData.orderTypeCode);
        if (conditionalCheck) {
            this.isFormSaved = this.saveStopForm(accordionEvent, this.activeAccordionList[0].stopId,
                this.activeAccordionList[0].group, this.activeAccordionList[0].stopPosition, false);
            this.checkDeliveryHandlingUnit();
        }
    }
    saveStopAndNavigate() {
        // this.showErrorMessage();
        const orderCount = Number(this.orderService.getOrderCopies());
        const notification = document.getElementsByClassName('simple-notification-wrapper')[0];
        if (this.isFormSaved) {
            if (orderCount === 0) {
                const headerObj = {
                    'errorCallback': true
                }
                const url = this.jbhGlobals.endpoints.order.getorder + this.orderID + '/ordersubmission?warningFlag=false';
                const params = {};
                notification.classList.add('notification-hide');
                this.submissionModal.show();
                this.stomp.configure(this.wsConf);
                this.stomp.startConnect();
                this.subscribeSockets();
                this.jbhGlobals.apiService.updateData(url, params, headerObj).subscribe(data => {
                    this.formatValidationError(data['errorDTOs']);
                    // localStorage.setItem('orderCount', '');
                    if (!this.jbhGlobals.utils.isEmpty(data) && data['orderStatus'] === 'Pending' && data['errorDTOs'].length === 0) {
                        this.orderService.setOrderCopies('0');
                        this.submissionModal.hide();
                        this.myModal.smModal.show();
                        // this.router.navigateByUrl('/createorders/order/ordershippingoptions?id=' + this.orderID);
                        this.navigationFlag = false;
                        this.warningFlag = false;
                        this.orderService.setNavigationFlag(this.navigationFlag);
                    } else if (!this.jbhGlobals.utils.isEmpty(data) && data['orderStatus'] === 'Pending' && data['errorDTOs'].length !== 0) {
                        this.orderService.setOrderCopies('0');
                        this.warningFlag = true;
                        this.submissionModal.hide();
                        this.unsubscribeSockets();
                    } else if (!this.jbhGlobals.utils.isEmpty(data) && data['orderStatus'] === null && data['errorDTOs'].length !== 0) {
                        this.orderService.setOrderCopies('0');
                        this.jbhGlobals.notifications.error('Error', 'Order Processing Rules Failed');
                        this.submissionModal.hide();
                        this.warningFlag = true;
                        this.unsubscribeSockets();
                    } /* else if (!this.jbhGlobals.utils.isEmpty(data) && data['orderStatus'] === 'Incomplete') {
                        // this.unsubscribeSockets();
                        if (!this.jbhGlobals.utils.isEmpty(data['errors'])) {
                            const errorList = data['errors'];
                            for (const errorObj of errorList) {
                                if (errorObj['errorType'] === 'ERROR') {
                                    this.jbhGlobals.notifications.error('Error', errorObj['code']);
                                } else if (errorObj['errorType'] === 'WARNING') {
                                    this.jbhGlobals.notifications.alert('Warning', errorObj['code']);
                                }
                            }}
                        this.router.navigateByUrl('/createorders/order/addstops?id=' + this.orderID);
                    } */

                }, (err: Error) => {
                    notification.classList.add('notification-hide');
                    this.submissionModal.hide();
                    this.formatValidationError(err);
                    this.unsubscribeSockets();
                    // return false;
                });
            } else if (orderCount > 0 && orderCount < 10) {
                // const copiesValue = this.jbhGlobals.commonDataService.getOrderCopies();
                const url = this.jbhGlobals.endpoints.order.getorder + 'ordercopy';
                const params = {
                    'noOfCopies': orderCount,
                    'sourceOrderId': this.orderID,
                    'copyType': 'EXACT'
                };
                this.jbhGlobals.apiService.addData(url, params).subscribe(data => {
                    this.copyarray = Object.keys(data);
                    const currentOrderStatus = data[this.copyarray[0]]['orderStatus'];
                    console.log(currentOrderStatus);
                    if (!this.jbhGlobals.utils.isEmpty(data) && currentOrderStatus === 'Pending' && data['errorDTOs'].length === 0) {
                        this.orderService.setOrderCopies('0');
                        this.router.navigateByUrl('/createorders/order/ordershippingoptions?id=' + this.orderID);
                    } else if (!this.jbhGlobals.utils.isEmpty(data) && currentOrderStatus === null) {
                        this.orderService.setOrderCopies('0');
                        this.jbhGlobals.notifications.error('Error', 'Order Processing rules Failed');
                    } else if (!this.jbhGlobals.utils.isEmpty(data) && currentOrderStatus === 'Incomplete') {
                        if (!this.jbhGlobals.utils.isEmpty(data['errors'])) {
                            const errorList = data['errors'];
                            // for (const errorObj of errorList) {
                            //     if (errorObj['errorType'] === 'ERROR') {
                            //         this.jbhGlobals.notifications.error('Error', errorObj['code']);
                            //     } else if (errorObj['errorType'] === 'WARNING') {
                            //         this.jbhGlobals.notifications.alert('Warning', errorObj['code']);
                            //     }
                            // }
                        }
                        this.router.navigateByUrl('/createorders/order/addstops?id=' + this.orderID);
                    }
                });
            }
        }/* else if (this.deliveryhandlingUnitFlag === false) {
            this.unsubscribeSockets();
            this.jbhGlobals.notifications.error('Error', 'Delivery Handling unit is not associated');
        }*/
        notification.classList.remove('notification-hide');
    }
    /*public showErrorMessage() {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getErrorDatas)
                    .subscribe(errorData => {
                        console.log(errorData);
                        this.errorMsg = errorData;
                        this.formatValidationError(this.errorMsg);
                        // this.errorDataHandlerService.saveData(this.formatValidationError(errorData));
                    });
    } */
    formatValidationError(errorMsg?: any) {
        // const errorMsgCode = errorMsg.code;
        // console.log(errorMsg.title);
        // const codeType = errorMsgCode.substr((errorMsgCode.length) - 3, errorMsgCode.length);
        const errorDataObject = {
            /* errors: {
                 serviceOfferingErrors: [],
                 shipmentInfoErrors: [],
                 accountsInfoErrors: [],
                 stopsInfoErrors: [],
                 equipmentsInfoErrors: []
             }, */
            errors: [],
            warnings: []
        };
        const serviceOfferingFormValue = this.jbhGlobals.utils.keys(this.orderFormBuilder.orderForm
        ['controls']['serviceOfferingDetail']['value']);
        console.log(serviceOfferingFormValue);
        const shipmentInfoFormValue = this.jbhGlobals.utils.keys(this.orderFormBuilder.orderForm['controls']
        ['shipmentInformation']['value']);
        console.log(shipmentInfoFormValue);
        const accountsInfoFormValue = this.jbhGlobals.utils.keys(this.orderFormBuilder.orderForm['controls']
        ['orderBillingDetail']['controls']['accountInfoForm']['value']);
        console.log(accountsInfoFormValue);
        const equipmentsInfoFormValue = this.jbhGlobals.utils.keys(this.orderFormBuilder.orderForm['controls']
        ['operationInformationDetail']['value']);
        console.log(equipmentsInfoFormValue);
        for (let i = 0; i < errorMsg.length; i++) {
            if (errorMsg[i].errorSeverity === 'ERROR') {
                // if (errorMsg.title === 'ERROR' || codeType === 'Err') {
                /*  for (const errorData of errorMsg) {
                      if (errorData.title === 'Error') {
                      for (const serviceOfferingData of serviceOfferingFormValue) {
                          if (serviceOfferingData === errorData.fieldName) {
                              errorDataObject.errors.serviceOfferingErrors.push({
                                  fieldName: errorData.fieldName,
                                  errorMessage: errorData.errorMessage
                              });
                          }
                      }
                      for (const accountsData of accountsInfoFormValue) {
                          if (accountsData === errorData.fieldName) {
                              errorDataObject.errors.accountsInfoErrors.push({
                                  fieldName: errorData.fieldName,
                                  errorMessage: errorData.errorMessage
                              });
                          }
                      }
                      for (const equipment of equipmentsInfoFormValue) {
                          if (equipment === errorData.fieldName) {
                              errorDataObject.errors.equipmentsInfoErrors.push({
                                  fieldName: errorData.fieldName,
                                  errorMessage: errorData.errorMessage
                              });
                          }
                      }
                      for (const shipmentData of shipmentInfoFormValue) {
                          if (shipmentData === errorData.fieldName) {
                              errorDataObject.errors.shipmentInfoErrors.push({
                                  fieldName: errorData.fieldName,
                                  errorMessage: errorData.errorMessage
                              });
                          }
                      }
                      const newErrorObj = {
                          component: errorData.fieldName.split('/')[0],
                          index: errorData.fieldName.split('/')[1],
                          fieldName: errorData.fieldName.split('/')[2],
                          position: errorData.fieldName.split('/')[3],
                          errorField: errorData.fieldName.split('/')[4],
                          errorMessage: errorData.errorMessage
                      };
                      if (newErrorObj.component === 'stops') {
                          errorDataObject.errors.stopsInfoErrors.push({
                              fieldName: newErrorObj.fieldName,
                              errorMessage: newErrorObj.errorMessage
                          });
                      } */
                errorDataObject.errors.push(errorMsg[i].errorMessage);
            } else if (errorMsg[i].errorSeverity === 'WARNING') {
                errorDataObject.warnings.push(errorMsg[i].errorMessage);
            }
        }
        this.orderService.loadOrder(this.orderID);
        console.log(errorDataObject);
        const errorArray = ['serviceOfferingErrors', 'shipmentInfoErrors',
            'accountsInfoErrors', 'stopsInfoErrors', 'equipmentsInfoErrors'];
        console.log(Object.keys(errorDataObject.errors));
        for (const compName of errorArray) {
            for (const errObj of Object.keys(errorDataObject.errors)) {
                if (compName === errObj) {
                    this.navigationFlag = true;
                }
            }
        }
        console.log(this.navigationFlag);
        this.orderService.setNavigationFlag(this.navigationFlag);
        this.orderService.setErrorData(errorDataObject);
        if (this.navigationFlag) {
            // this.goBack();
            // this.stopSavePrompt();
        }
    }

    validateStop(stopDetails, event, group, stopCollapse) {
        let isValid = true;
        if (stopCollapse) {
            if (stopDetails && this.stopChild.handlingUnitRef) {
                const handlingForm = this.stopChild.handlingUnitRef.handlingComponent.first;
                if (handlingForm !== undefined && handlingForm.itemComponent && handlingForm.itemComponent.first) {
                    const itemForm = handlingForm.itemComponent.first;
                    if (handlingForm.handlingModel.handlingUnitId && !itemForm.itemModel.stopItemID) {
                        isValid = false;
                        this.jbhGlobals.notifications.alert('Warning', 'Stops should have handling unit and item');
                    }
                }
            }
        } else if (stopDetails && (!stopDetails.locationID || this.jbhGlobals.utils.isEmpty(stopDetails.stopReason))) {
            this.jbhGlobals.notifications.alert('Warning', 'Please enter stop location & stop reason');
            isValid = false;
        } else if (stopDetails && this.stopChild.handlingUnitRef) {
            const handlingForm = this.stopChild.handlingUnitRef.handlingComponent.first;
            const itemForm = handlingForm.itemComponent.first;
            if (!handlingForm.handlingModel.handlingUnitId || !itemForm.itemModel.stopItemID) {
                isValid = false;
                this.jbhGlobals.notifications.alert('Warning', 'Stops should have atleast one handling unit and item');
            }
        }
        if (!isValid) {
            this.activeStop = group;
            if (event && event !== undefined) {
                event.stopPropagation();
            }
            return false;
        }
        return true;
    }

    private subscribeSockets() {
        const me = this;
        this.connectionStatusSubscription = this.stomp.getConnectionStatus().subscribe(status => {
            const connectionStatus = status;
            if (connectionStatus === 'CONNECTED') {
                const headerObj = {
                    ack: 'client',
                    selector: 'orderId = ' + me.orderID
                };
                me.shippingOptnSubscription = me.stomp.subscribe(
                    '/topic/' + me.topicName,
                    me.onSocketNotification, headerObj);
            }
        });
    }
    private unsubscribeSockets() {
        if (this.stomp.status !== 'CLOSED') {
            this.stomp.disconnect().then(() => {
                console.log('Connection closed');
            });
        }
        if (this.shippingOptnSubscription) {
            this.shippingOptnSubscription.unsubscribe();
        }
        if (this.connectionStatusSubscription) {
            this.connectionStatusSubscription.unsubscribe();
        }
        this.myModal.smModal.hide();
    }
    private onSocketNotification = (data) => {
        const resData = JSON.parse(data);
        const orderSts = (resData.orderStatus) ? resData.orderStatus.toLowerCase() : '';
        const qlfSts = resData.qualifyStatus;
        const orderPickupDate = (resData.orderPickupDate) ? resData.orderPickupDate : '';

		if (orderSts === 'accepted') {
            this.jbhGlobals.notifications.success('Success', 'Order Accepted Successfully');
            this.redirectToViewOrder();
        } else if (orderSts === 'qualified') {
        	if(resData['errormessage'] || resData['validationErrorDTO']) {
        		this.onAutoAcceptSocketNotification(resData);
        	} else {
	            this.notificationList.push({
	                'text': 'Order Qualified'
	            });
	            this.notificationList.push({
	                'text': 'Listening Auto-Accept'
	            });
            }            
        } else if (orderSts === 'pending' && this.warningFlag === false) {
        	if (qlfSts) {
	            switch (qlfSts) {
	                case 'PrimaryQualified':
	                    this.unsubscribeSockets();
	                    this.router.navigateByUrl('/createorders/order/ordershippingoptions?id='
	                        + this.orderID + '&pickUpDt=' + orderPickupDate);
	                    break;
	                case 'Qualification Process Error':
	                    this.unsubscribeSockets();
	                    this.jbhGlobals.notifications.alert('Failure', 'Qualification Process Error');
	                    break;
	                case 'No Primary Service Offering Found':
	                    this.unsubscribeSockets();
	                    this.jbhGlobals.notifications.alert('Failure', 'No Primary Service Offering Found');
	                    break;
	                case 'Rate Publication Code':
	                    this.notificationList.push({
	                        'text': 'Rate Publication Code'
	                    });
	                    break;
	                case 'Rate Item Code':
	                    this.notificationList.push({
	                        'text': 'Rate Item Code'
	                    });
	                    break;
	                case 'Rate Item Code Not Found':
	                    this.notificationList.push({
	                        'text': 'Rate Item Code Not Found'
	                    });
	                    break;
	                default:
	                    break;
	            } 
            } else if (resData['errors']) {
	        	let errorStr = '';
	            for (const errorObj of resData['errors']) {
	            	if (errorObj['errorMessage']) {
	                	errorStr += errorObj['errorMessage'] + '<br/>';
	                }
	            }
	            this.jbhGlobals.notifications.html(this.frameMultiLineNotificationString('Failure', errorStr), 'alert');
	        }
        }
    }

    private onAutoAcceptSocketNotification(data): void {
        const resData = data;
        if (resData['validationErrorDTO']) {
            let errorStr = '';
            for (const errorObj of resData['validationErrorDTO']) {
                errorStr += errorObj['params'] + '<br/>';
            }
            this.jbhGlobals.notifications.html(this.frameMultiLineNotificationString('Failure', errorStr), 'alert');
            this.redirectToViewOrder();
        } else if (resData['errormessage']) {
            switch (resData['errormessage']) {
                case 'Validate Shipping Option':
                    this.jbhGlobals.notifications.alert('Failure', 'Validate Shipping Option');
                    this.redirectToShippingOptions();
                    break;
                case 'Re-Qualify Triggerd':
                    // look for requalify.
                    this.notificationList.push({
                        'text': 'Re-Qualify Triggerd'
                    });
                    break;
                default:
                    this.jbhGlobals.notifications.alert('Failure', resData['errormessage']);
                    // this.redirectToViewOrder();
                    this.unsubscribeSockets();
                    break;
            }
        }  
    }
    private redirectToViewOrder(): void {
        this.unsubscribeSockets();
        setTimeout(() => {
            this.router.navigateByUrl('/vieworder?id=' + this.orderID);
        }, 4000);
    }
    private redirectToShippingOptions(): void {
        this.unsubscribeSockets();
        const timerValue = Observable.timer(2000);
        timerValue.subscribe(x => {
            this.router.navigateByUrl('/createorders/order/ordershippingoptions?id=' + this.orderID);
        });
    }
    private frameMultiLineNotificationString(title, content): string {
        let str = '';
        str = '<div class="sn-title">' + title + '</div>';
        str += '<div class="sn-content">' + content + '</div>';
        str += '<div class="icon"></div>';
        return str;
    }
    getSocTopicName() {
        const me = this;
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.shippingoptions.getTopicName).subscribe(data => {
            me.topicName = data['topic'];
        }, (err: Error) => {
            return false;
        });
    }
    getClosest(el, tag) {
        while (el && el.tagName && el.tagName !== tag.toUpperCase()) {
            el = el.parentElement;
        }
        return el;
    }

    onCancelOrder(): void {
        const url = this.jbhGlobals.endpoints.order.cancelorder + this.orderData.orderID + '/cancel';
        const params = {
            'orderStatusEventComment': null,
            'orderStatusEventReasonDescription': 'Cancel Of Data Entry'
        };
        this.jbhGlobals.apiService.updateData(url, params).subscribe((response: any) => {
            this.jbhGlobals.notifications.success('Order', 'Order deleted successfully!');
            this.cancelDialog.hide();
            this.router.navigateByUrl('/createorders/template');
        });
    }
    onSave(event): void {
        let accordionEvent: any;
        let isFormSaved = false;
        let conditionalCheck = false;
        if (!this.jbhGlobals.utils.isEmpty(this.activeAccordionList) && this.activeAccordionList[0].event) {
            accordionEvent = this.activeAccordionList[0].event;
        } else {
            // accordionEvent = event;
            accordionEvent = '';
        }
        conditionalCheck = this.conditionalCheck(this.orderData.financeBusinessUnitCode, this.orderData.serviceOfferingCode,
            this.orderData.orderTypeCode);
        if (conditionalCheck) {
            isFormSaved = this.saveStopForm(accordionEvent, this.activeAccordionList[0].stopId,
                this.activeAccordionList[0].group, this.activeAccordionList[0].stopPosition, false);
        }
        if (isFormSaved) {
            // const url = this.jbhGlobals.endpoints.order.getorder + this.orderID + '/ordersubmission?warningFlag=true';
            // const params = {};
            // this.jbhGlobals.apiService.updateData(url, params).subscribe((response: any) => {
            //     this.jbhGlobals.notifications.success('Order', 'Order saved successfully!');
            // });
            this.orderService.saveOrder(this.orderData).subscribe((response: any) => {
                this.jbhGlobals.notifications.success('Order', 'Order saved successfully!');
            });
        }
    }
    displayTotalWeight(data) {
        let showFlag = true;
        if (data.totalStopWeight === 0 || data.totalStopWeight === null) {
            showFlag = false;
        }
        return showFlag;
    }

    isCloseClicked(value) {
        if (value) {
           this.stopSharedDataService.getStopsSummary(this.orderID)
        }
    }
}
