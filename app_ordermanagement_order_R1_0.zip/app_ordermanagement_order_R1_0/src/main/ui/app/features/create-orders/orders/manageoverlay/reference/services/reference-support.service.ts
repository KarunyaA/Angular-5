import { Injectable, OnInit } from '@angular/core';
import { JBHGlobals } from '../../../../../../app.service';
import { ReferencesService } from './references.service';
@Injectable()
export class ReferenceSupportService {
  jsonpatch: any;
  constructor(private jbhGlobals: JBHGlobals) {}

  editStopReferencesFinalizeCall(parentScope, referencesModel, refForm) {
    parentScope.referencesService.getParentReferences(this.jbhGlobals.endpoints.order
      .getAssociatedRefNVals + referencesModel.stpIDStopUpdate +
      '/referencenumbertypes?associatedparentflag=true').subscribe(data2 => {
      referencesModel.associatedRefArr = data2;
      if (referencesModel.associatedRefArr) {
        for (let d = 0; d < referencesModel.associatedRefArr.length; d++) {
          if (referencesModel.associatedRefArr[d].referenceNumberTypeDescription === refForm.value.ParRefType &&
             referencesModel.associatedRefArr[d].referenceNumber.referenceNumberValue ===
             parentScope.pRefTypeValReference.active[0].text) { // AssoRefIDforURL
            referencesModel.stpAssociatRefNumbid = referencesModel.associatedRefArr[d].referenceNumber.referenceNumberID;
            if (referencesModel.stpAssociatRefNumbid) {
              const editStopParams = parentScope.referenceHelper.geteditOrderParamsForstopUpdate(referencesModel);
              if (referencesModel.currentPage !== 'vieworder') { // Stop reference Update
                parentScope.referencesService.SaveReference(this.jbhGlobals.endpoints.order.updateStopRef +
                   referencesModel.stpIDStopUpdate +
                  '/stopreferencenumbers/' + referencesModel.stpAssociatRefNumbid, editStopParams).subscribe(data3 => {
                  referencesModel.newStopRef = data3;
                  if (referencesModel.newStopRef) {
                    parentScope.reloadStopReferenceList();
                    parentScope.referenceHelper.showResponseMessge(referencesModel);
                    refForm.value.ParRefType = null;
                    refForm.value.pRefVal = null;
                  };
                });
              }
              if (referencesModel.currentPage === 'vieworder') { // Stop Edit in VIEWORDER Call
                parentScope.referenceGenerateTreeService.stopEditForViewOrderCall(parentScope, referencesModel, editStopParams, refForm);
              }
            }
          }
        }
      }
    });
  }

  stopSaveReferencesFinalize(parentScope, referencesModel) {
    if (referencesModel.stopSaveReferencesValues.refNumTypeCode !== null && referencesModel.stopSaveReferencesValues.refValTxt !==
      null && referencesModel.stopLevelNum !== null) {
      if (referencesModel.stopSaveReferencesValues.refNumTypeCode !== '' && referencesModel.stopSaveReferencesValues.refValTxt !==
        '' && referencesModel.stopLevelNum !== '') {
        if (referencesModel.stopSaveReferencesValues.refNumTypeCode !== undefined && referencesModel.stopSaveReferencesValues
          .refValTxt !== undefined && referencesModel.stopLevelNum !== undefined) {
          referencesModel.editRefShow = false;
          referencesModel.stpRefNumTypCdeForSave = referencesModel.stpRefNumTypCdeForSave;
          referencesModel.prefValTxt = referencesModel.prefValTxt;
          if (referencesModel.stpRefNumTypCdeForSave && referencesModel.prefValTxt) {
            parentScope.stopRefValueCodeAndPrefValReady(referencesModel.stopSaveReferencesValues.refNumTypeCode,
              referencesModel.stopSaveReferencesValues.refValTxt); // StopSave function with Parent Vals1
          } else if (!referencesModel.stpRefNumTypCdeForSave || !referencesModel.prefValTxt) {
            referencesModel.stpOrdrParams = { // StopSave function else with No Parent Vals
              'referenceNumberTypeCode': referencesModel.stopSaveReferencesValues.refNumTypeCode,
              'referenceNumberValue': referencesModel.stopSaveReferencesValues.refValTxt,
              '@type': 'StopReferenceNumber'
            };
            for (let j = 0; j < referencesModel.stopNIds.length; j++) {
              if (referencesModel.stopNIds[j].stop.stopID !== null) {
                if (referencesModel.stopNIds[j].stop.stopSequenceNumber.toString() === referencesModel.stopLevelNum.toString()) {
                  referencesModel.stpIDSave = referencesModel.stopNIds[j].stop.stopID;
                }
              }
            }
            if (referencesModel.stpIDSave && referencesModel.currentPage !== 'vieworder') { // StopSave MOC
              parentScope.referenceHelper.stopSaveForMoc(parentScope, referencesModel);
            } else if (referencesModel.stpIDSave && referencesModel.currentPage === 'vieworder') { // StopSave VIEWORDER
              parentScope.referenceHelper.stopSaveForVieworder(parentScope, referencesModel, referencesModel.stopSaveReferencesValues
                .refNumTypeCode, referencesModel.stopSaveReferencesValues.refValTxt);
            }
          }
        }
      }
    }
  }

  orderSaveInMocCall(parentScope, referencesModel, refNumTypeCode) {
    const ordrParams = {
      'order': '/' + referencesModel.currentOrderId,
      'referenceNumberID': referencesModel.oRefId,
      'referenceNumberTypeCode': refNumTypeCode,
      'referenceNumberValue': referencesModel.oRefOval,
      '@type': 'OrderReferenceNumber'
    };
    if (referencesModel.oRefId) {
      parentScope.referencesService.updateReference(this.jbhGlobals.endpoints.order.updateOrderRefEdit +
        referencesModel.oRefId, ordrParams).subscribe(data => {
        referencesModel.editedOrderRef = data;
        if (referencesModel.editedOrderRef) {
          parentScope.reloadOrderGetreferencesList();
          parentScope.referenceHelper.clearReferenceFields(referencesModel);
        }
      });
    }
  }

  triggerStopLevelOnselect(parentScope, referencesModel, event, stopLevel) {
    parentScope.referenceUtility.stopLevelOnselect(referencesModel, stopLevel);
    if (referencesModel.stpIDForAssoRef) {
      parentScope.referencesService.getParentReferences(this.jbhGlobals.endpoints.order
        .getAssociatedRefNVals + referencesModel.stpIDForAssoRef +
        '/referencenumbertypes?associatedparentflag=true').subscribe(data => {
          referencesModel.associatedRefArr = data;
          if (referencesModel.associatedRefArr) {
            parentScope.referenceUtility.setAssociatedParentReferenceArray(referencesModel);
            if (referencesModel.pRefTypeArr && referencesModel
              .pRefTypeArr.length === 1) { // Setting Asso Parref Val
                parentScope.associatedParentRefOnSel(event, referencesModel.pRefTypeArr[0], referencesModel.stopLvel);
            }
            parentScope.referenceUtility.setParentReferenceTypeFlags(referencesModel);
          } else {
            parentScope.referenceUtility.setParentReferenceTypeFlags2(referencesModel);
          }
        });
    }
  }

  associatedParentReferenceOnselect(parentScope, referencesModel, parReftype, stplevelValue) {
    parentScope.referenceUtility.getStopIdForStopSave(referencesModel, parReftype, stplevelValue);
    if (referencesModel.stopIDStpSave) { // To get refNumTypCode of AssoParRefType for stop save
      parentScope.referencesService.getParentReferences(this.jbhGlobals.endpoints.order
        .getAssociatedRefNVals + referencesModel.stopIDStpSave +
        '/referencenumbertypes?associatedparentflag=true').subscribe(data => {
          referencesModel.assoRefForAsPrefTypCode = data;
          parentScope.referenceUtility.getStopreferenceNumberCode(referencesModel);
        });
    }
    if (parentScope.pRefTypeValReference) { // Clearing Par ref type value
      parentScope.pRefTypeValReference.active = [];
    }
  }

}
