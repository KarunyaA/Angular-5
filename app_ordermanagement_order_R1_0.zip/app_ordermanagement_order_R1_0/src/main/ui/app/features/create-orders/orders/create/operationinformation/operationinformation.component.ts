import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { JBHGlobals } from '../../../../../app.service';
import { OrderService } from '../../services/order.service';
import { OrderFormBuilderService } from '../../services/order-form-builder.service';
import { OperationinformationService } from './service/operationinformation.service';

@Component({
    selector: 'app-operationinformation',
    providers: [OperationinformationService],
    templateUrl: './operationinformation.component.html',
    styleUrls: ['./operationinformation.component.scss']
})

export class OperationinformationComponent implements OnInit {
    @ViewChild('trailerequipment') trailerequipment;
    @Input() operationInformationDetail: any;
    @ViewChild('trailerpre') trailerpreTag;
    @ViewChild('equipmentoption') equipmentoptionTag;
    @ViewChild('nonCompText') nonCompText;
    @ViewChild('freightsecurement') freightsecurementTag;
    @ViewChild('protectionmaterial') protectionmaterialTag;
    @ViewChild('equipCategoryFlex') equipCategoryFlex;
    @ViewChild('equipTypeFlex') equipTypeFlex;
    @ViewChild('equipLengthFlex') equipLengthFlex;
    @Input() isCurrViewTemplate: boolean;
    value: any = {};
    equipmentType: any[] = [];
    equipmentCategory: any[] = [];
    equipmentLength: any[] = [];
    trailerPrefix: any[] = [];
    trailerNumber: any[] = [];
    equipOptSelectedArray: any[] = [];
    freightSecSelectedArray: any[] = [];
    equipOptionList: string[];
    equipList: any[] = [];
    cateval: any;
    lenval: any;
    typval: any;
    noncompany = true;
    disabletab = false;
    equipTypeInitialValue: any;
    equipCategoryIntialValue: any;
    selectedEquipList: any[] = [];
    selectedEquipDescription: string[] = [];
    freightSecurementList: string[] = [];
    personalProtectionMaterialList: any[] = [];
    personalProtectionMaterialListDescription: string[];
    freightSecureList: any[] = [];
    freightSecureListDescription: string[];
    selectedEquipmentTags: any = [];
    selectedFreightTags: any = [];
    selectedProtectionTags: any = [];
    trailerPrefixList: any = [];
    trailerPrefixListDescription: any[];
    trailerNumberListDescription: any[];
    trailerNumberList: any[] = [];
    flag = true;
    equipPlaceholder = 'Equipment Options';
    freightPlaceholder = 'Freight Securement';
    protectionPlaceholder = 'Personal Protection';
    manualPallet = 'Manual Pallet Jack';
    handTrucks = 'Hand Trucks';
    moffets = 'Moffets';
    forkLifts = 'Fork Lifts';
    liftGates = 'Lift Gates';
    isManualPallet = false;
    isHandtrucks = false;
    isMoffets = false;
    isForkLifts = false;
    isEditOrder = true;
    isLiftGates = false;
    financeBUValue = '';
    equipmentCategoryCode = '';
    equipCategory: any;
    equipType: any;
    serviceOfferingValue = '';
    manualPalletSpecID = '';
    handtrucksSpecID = '';
    moffetsSpecID = '';
    forkLiftsSpecID = '';
    liftGatesSpecID = '';
    selCategory = '';
    selType = '';
    selLength = '';
    debounceValue: number;
    hasTrailerNumber = false;
    showEquipment = true;
    hasTrailerPrefix = false;
    selNumber = '';
    selPrefix = '';
    isCompanyTrailer = false;
    isOrderDataLoaded = true;
    isdataLoaded = true;
    orderid: any;
    temp: any;
    equipSaveParams: any;
    subscription: any;
    orderData: any;
    category: any;
    type: any;
    CategoryIntialValue: any;
    constructor(public jbhGlobals: JBHGlobals,
                public orderService: OrderService,
                public orderFormBuilder: OrderFormBuilderService,
                public operationservice: OperationinformationService) { }

    onClickTrailerEquip(onSelEquipment) {
        this.operationInformationDetail['controls']['trailerPrefix'].setValue('');
        this.operationInformationDetail['controls']['trailerNumber'].setValue('');
        this.operationInformationDetail['controls']['orderNonCompanyEquipmentDetails'].setValue('');
        this.operationInformationDetail['controls']['equipmentCategoryCode'].setValue([]);
        this.operationInformationDetail['controls']['equipmentTypeCode'].setValue([]);
        this.operationInformationDetail['controls']['equipmentLengthCode'].setValue([]);
        this.operationInformationDetail['controls']['equipmentLengthRequiredIndicator'].setValue('');
        this.operationInformationDetail['controls']['equipmentTypeRequiredIndicator'].setValue('');
        this.operationInformationDetail['controls']['equipmentClassificationRequiredIndicator'].setValue('');
        this.selectedFreightTags = [];
        this.selectedProtectionTags = [];
        this.selectedEquipmentTags = [];
        // const requirementDTO = this.orderData.orderEquipmentRequirementDTOs;
        if (onSelEquipment === true) {
            this.flag = true;
            this.noncompany = true;
            this.equipSaveParams.trailerPreloadedIndicator = 'N';
            this.equipSaveParams.equipmentClassificationRequiredIndicator =
                (this.equipSaveParams.equipmentClassificationRequiredIndicator) ?
                    this.equipSaveParams.equipmentClassificationRequiredIndicator : 'N';
            this.equipSaveParams.equipmentTypeRequiredIndicator = (this.equipSaveParams.equipmentTypeRequiredIndicator) ?
                this.equipSaveParams.equipmentTypeRequiredIndicator : 'N';
            this.equipSaveParams.equipmentLengthRequiredIndicator = (this.equipSaveParams.equipmentLengthRequiredIndicator) ?
                this.equipSaveParams.equipmentLengthRequiredIndicator : 'N';
            this.equipSaveParams.orderNonCompanyEquipmentDetails = [];
        } else {
            this.flag = false;
            this.equipSaveParams.trailerPreloadedIndicator = 'Y';
            this.equipSaveParams.equipmentClassificationRequiredIndicator = 'N';
            this.equipSaveParams.equipmentTypeRequiredIndicator = 'N';
            this.equipSaveParams.equipmentLengthRequiredIndicator = 'N';
        }
    }
    getEquipmentType(val) {
        const str = val;
        const res = str.substring(0, 1);
        if (res === ' ') {
            const cate = str.substring(1, val.length);
            this.equipmentCategoryCode = cate;
        } else {
            this.equipmentCategoryCode = val;
        }
        const params = {
            equipmentCategoryCode: this.equipmentCategoryCode
        };
        this.operationservice.getEquipment(this.jbhGlobals.endpoints.order.getEquipmentType, params).subscribe(data => {
            this.equipmentType = [];
            if (data !== undefined) {
                for (const equipType of data['_embedded']['equipmentTypes']) {
                    this.equipmentType.push({
                        'id': equipType['equipmentTypeCode'],
                        'text': equipType['equipmentTypeDescription'],
                        'equipmentClassificationTypeAssociations': equipType['equipmentClassificationTypeAssociations']
                    });
                }
                this.populateSelectedData(this.equipmentType);
            }
        });
    }
    getEquipmentCategory() {
        this.financeBUValue = this.orderData.financeBusinessUnitCode;
        this.serviceOfferingValue = this.orderData.serviceOfferingCode;
        const params = {
            financebusinessunitcode: this.financeBUValue,
            serviceofferingcode: this.serviceOfferingValue
        };
        this.operationservice.getEquipment(this.jbhGlobals.endpoints.order.getEquipmentCategory, params).subscribe(data => {
            this.equipmentCategory = [];
            if (data !== undefined) {
                for (const equipCatCode of data['_embedded']['equipmentClassifications']) {
                    this.equipmentCategory.push({
                        'id': equipCatCode['equipmentClassificationCode'],
                        'text': equipCatCode['equipmentClassificationDescription']
                    });
                }
                this.populateSelectedData(this.equipmentCategory);
            }
        });
    }
    getEquipmentLength(val) {
        const params = {
            'equipmentclassificationtypeassociationid': val
        };
        this.operationservice.getEquipment(this.jbhGlobals.endpoints.order.getEquipmentLength, params).subscribe(data => {
            this.equipmentLength = [];
            if (data !== undefined) {
                for (const equipLen of data['_embedded']['equipmentRequirementSpecificationAssociations']) {
                    this.equipmentLength.push({
                        'id': equipLen['equipmentRequirementSpecification']['equipmentRequirementSpecificationDescription'],
                        'text': equipLen['equipmentRequirementSpecification']['equipmentRequirementSpecificationDescription'],
                        'equipmentRequirementSpecification': equipLen['equipmentRequirementSpecification'],
                        'equipmentRequirementSpecificationAssociationID': equipLen['equipmentRequirementSpecificationAssociationID'],
                        'equipmentRequirementSpecificationDetail': equipLen['equipmentRequirementSpecificationDetail'],
                        'equipmentRequirementType': equipLen['equipmentRequirementType']
                    });
                }
                this.populateSelectedData(this.equipmentLength);
            }
        });
    }
    getEquipmentOption(value, selectedArr) {
        const params = {
            equipmentClassificationTypeAssociationID: value
        };
        this.operationservice.getEquipmentMultiSelect(this.jbhGlobals.endpoints.order.getEquipmentOption, params).subscribe(data => {
            this.equipList = data;
            this.equipOptionList = [];
            for (let i = 0; i < this.equipList.length; i++) {
                const equipCode = this.equipList[i]['code'];
                if (equipCode !== 'Freight' && equipCode !== 'Length' && equipCode !== 'MatHandEqu' && equipCode !== 'PersnalPro') {
                    if ((this.equipList[i]['code'] === 'Door') || (this.equipList[i]['code'] === 'Roof') ||
                        (this.equipList[i]['code'] === 'Floor')) {
                        this.equipOptionList.push(this.equipList[i]['associatedDescription'] + '&nbsp;' + this.equipList[i]['code']);
                    } else {
                        this.equipOptionList.push(this.equipList[i]['associatedDescription'] + '&nbsp;' + 'Other');
                    }
                }
            }
            if (selectedArr && selectedArr.length > 0) {
                for (const obj of selectedArr) {
                    let selVal = obj.id;
                    selVal = selVal.substring(0, selVal.indexOf('&'));
                    this.onSaveSelectedOptions(selVal);
                }
            }
        });
    }
    getFreightSecurement(value) {
        const params = {
            equipmentClassificationTypeAssociationID: value
        };
        this.operationservice.getEquipmentMultiSelect(this.jbhGlobals.endpoints.order.getEquipmentOption, params).subscribe(data => {
            this.freightSecureList = data;
            this.freightSecureListDescription = [];
            for (let i = 0; i < this.freightSecureList.length; i++) {
                const freightCode = this.freightSecureList[i]['code'];
                if (freightCode === 'Freight') {
                    this.freightSecureListDescription.push(this.freightSecureList[i]['associatedDescription']);
                }
            }
        });
    }
    equipSelectedData(value: any): void {
        this.selectedEquipmentTags = value;
    }
    freightSelectedData(value: any): void {
        this.selectedFreightTags = value;
    }
    protSelectedData(value: any): void {
        this.selectedProtectionTags = value;
    }
    populateSelectedData(paramObj) {
        if (!this.jbhGlobals.utils.isEmpty(paramObj)) {
            for (let i = 0; i < paramObj.length; i++) {
                const paramObjId = paramObj[i].id;
                if (paramObjId === (!this.jbhGlobals.utils.isEmpty(this.equipmentCategoryCode) ?
                    this.equipmentCategoryCode : this.cateval)) {
                    this.operationInformationDetail['controls']['equipmentCategoryCode'].setValue([{
                        'id': paramObjId,
                        'text': paramObj[i].text
                    }]);
                }
                if (paramObjId === (!this.jbhGlobals.utils.isEmpty(this.type) ? this.type.text : this.typval)) {
                    this.operationInformationDetail['controls']['equipmentTypeCode'].setValue([{
                        'id': paramObjId,
                        'text': paramObj[i].text
                    }]);
                }
                if (paramObjId === this.lenval) {
                    this.operationInformationDetail['controls']['equipmentLengthCode'].setValue([{
                        'id': paramObjId,
                        'text': paramObj[i].text
                    }]);
                }
            }
        }
    }
    onSelectEquipOptionsService(value) {
        let selVal = value.id;
        selVal = selVal.substring(0, selVal.indexOf('&'));
        this.onSaveSelectedOptions(selVal);
        const equipRequirementObj = this.transformEquip(this.equipList, selVal)[0];
        if (this.selectedEquipmentTags.indexOf(value) !== -1) {
            const selEquipObj = this.transformEquip(this.equipList, selVal)[0];
            if (selEquipObj.equipmentClassificationTypeFeatureAssociationID !== null) {
                this.frameFeatureSpecificationOrderDTO(selEquipObj);
            } else {
                this.frameEquipSpecificationOrderDTO(selEquipObj);
            }
        }
        if (this.isCurrViewTemplate) {
            this.templateEquipReqSpecFramerOther(equipRequirementObj, 'add');
        }
    }
    onRemoveEquipOptionsService(value) {
        let selVal = value.id;
        let remVal = value.id;
        remVal = remVal.substring(0, remVal.indexOf('&'));
        selVal = selVal.split(';');
        const res = selVal[1];
        for (let i = 0; i < this.selectedEquipList.length; i++) {
            if (res === this.selectedEquipList[i].type) {
                this.selectedEquipList.splice(i, 1);
            }
        }
        const removeEquipObj = this.transformEquip(this.equipList, remVal)[0];
        this.removeEquipSpecificationOrderDTO(removeEquipObj);
        if (this.isCurrViewTemplate) {
            this.templateEquipReqSpecFramerOther(removeEquipObj, 'remove');
        }
    }
    templateEquipReqSpecFramerOther(equipRequirementObj, methodType) {
        if (!this.orderData.orderEquipementRequirementFeatureAssociationDTOs) {
            this.orderData.orderEquipementRequirementFeatureAssociationDTOs = [];
        }
        if (equipRequirementObj['code'] !== 'Roof' &&
            equipRequirementObj['code'] !== 'Door' && equipRequirementObj['code'] !== 'Floor') {
            if (methodType === 'add') {
                const obj = {
                    'orderEquipmentRequirementFeatureAssociationID': equipRequirementObj['orderEquipmentRequirementFeatureAssociationID'],
                    'equipmentCategoryClassificationTypeFeatureAssociationID':
                    equipRequirementObj['equipmentClassificationTypeFeatureAssociationID'],
                    'equipmentFeatureCode': equipRequirementObj['code'],
                    'equipmentFeatureDescription': equipRequirementObj['description']
                }
                this.orderData.orderEquipementRequirementFeatureAssociationDTOs.push(obj)
            }
            if (methodType === 'remove') {
                const arr = this.orderData.orderEquipementRequirementFeatureAssociationDTOs;
                for (let i = 0; i < arr.length; i++) {
                    if (equipRequirementObj['code'] === arr[i]['equipmentFeatureCode']) {
                        arr.splice(i, 1);
                        return;
                    }
                }
            }
        }
    }
    onSelectFreightSecureService(selectedFreight) {
        const freightSecureObj = this.equipListTransform(this.freightSecureList, selectedFreight.id)[0];
        this.frameEquipSpecificationOrderDTO(freightSecureObj);
    }
    onRemoveFreightSecureService(value) {
        const removeFreightObj = this.equipListTransform(this.freightSecureList, value.text)[0];
        this.removeEquipSpecificationOrderDTO(removeFreightObj);
    }
    loadProtectionMaterialHandling(value) {
        // Get all PersonalProtection And MaterialHandling Equipment
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getProtectionMaterialHandling).subscribe(data => {
            this.personalProtectionMaterialList = data['_embedded']['equipmentRequirementSpecificationAssociations'];
            this.personalProtectionMaterialListDescription = [];
            for (let i = 0; i < this.personalProtectionMaterialList.length; i++) {
                const eSpc = this.personalProtectionMaterialList[i]['equipmentRequirementSpecification'];
                const eDesc = eSpc['equipmentRequirementSpecificationDescription'];
                this.personalProtectionMaterialListDescription.push(eDesc);
            }
            if (value) {
                this.onSelectProtectionHandling(value, false);
            }
        });
    }
    onSelectProtectionHandling(value, event) {
        const protectionObj = this.protectionListTransform(this.personalProtectionMaterialList, value.id)[0];
        if (value.id.trim() === this.manualPallet) {
            this.isManualPallet = true;
            this.manualPalletSpecID = protectionObj.equipmentRequirementSpecificationAssociationID;
            this.populateProtectionQuantity(this.manualPalletSpecID, 'manulaPJQty');
        }
        if (value.id.trim() === this.handTrucks) {
            this.isHandtrucks = true;
            this.handtrucksSpecID = protectionObj.equipmentRequirementSpecificationAssociationID;
            this.populateProtectionQuantity(this.handtrucksSpecID, 'handTrucks');
        }
        if (value.id.trim() === this.moffets) {
            this.isMoffets = true;
            this.moffetsSpecID = protectionObj.equipmentRequirementSpecificationAssociationID;
            this.populateProtectionQuantity(this.moffetsSpecID, 'moffQty');
        }
        if (value.id.trim() === this.forkLifts) {
            this.isForkLifts = true;
            this.forkLiftsSpecID = protectionObj.equipmentRequirementSpecificationAssociationID;
            this.populateProtectionQuantity(this.forkLiftsSpecID, 'forkLitQty');
        }
        if (value.id.trim() === this.liftGates) {
            this.isLiftGates = true;
            this.liftGatesSpecID = protectionObj.equipmentRequirementSpecificationAssociationID;
            this.populateProtectionQuantity(this.liftGatesSpecID, 'liftGatQty');
        }
        if (event) {
            this.frameProtectionSpecificationOrderDTO(protectionObj);
        }
        if (this.isCurrViewTemplate && event) {
            this.templateEquipReqSpecFrammer(protectionObj);
        }
    }
    populateProtectionQuantity(reqFieldSpecID, formName) {
        if (this.equipSaveParams.orderEquipmentRequirementSpecificationAssociations &&
            this.equipSaveParams.orderEquipmentRequirementSpecificationAssociations.length > 0) {
            const parentArray = this.equipSaveParams.orderEquipmentRequirementSpecificationAssociations;
            for (const reqDto of parentArray) {
                if (reqFieldSpecID === reqDto.equipmentRequirementSpecificationAssociationID) {
                    this.operationInformationDetail['controls'][formName].setValue(
                        reqDto.orderEquipmentRequirementSpecificationDetails[0].specificationDetailValue);
                }
            }
        }
    }
    onBlurQuantity(value, requiredQtyField) {
        let reqFieldSpecID = '';
        if (requiredQtyField === 'Manual') {
            reqFieldSpecID = this.manualPalletSpecID;
        }
        if (requiredQtyField === 'HandTrucks') {
            reqFieldSpecID = this.handtrucksSpecID;
        }
        if (requiredQtyField === 'Moffets') {
            reqFieldSpecID = this.moffetsSpecID;
        }
        if (requiredQtyField === 'ForkLifts') {
            reqFieldSpecID = this.forkLiftsSpecID;
        }
        if (requiredQtyField === 'LiftGates') {
            reqFieldSpecID = this.liftGatesSpecID;
        }
        const parentArray = this.equipSaveParams.orderEquipmentRequirementSpecificationAssociations;
        for (const reqDto of parentArray) {
            if (reqFieldSpecID === reqDto.equipmentRequirementSpecificationAssociationID) {
                reqDto.orderEquipmentRequirementSpecificationDetails[0].specificationDetailValue = value;
            }
        }
    }
    onRemoveProtectionHandling(value) {
        const removeProtectionObj = this.protectionListTransform(this.personalProtectionMaterialList, value.text)[0];
        if (value.id.trim() === this.manualPallet) {
            this.isManualPallet = false;
        }
        if (value.id.trim() === this.handTrucks) {
            this.isHandtrucks = false;
        }
        if (value.id.trim() === this.moffets) {
            this.isMoffets = false;
        }
        if (value.id.trim() === this.forkLifts) {
            this.isForkLifts = false;
        }
        if (value.id.trim() === this.liftGates) {
            this.isLiftGates = false;
        }
        this.removeProtectionSpecificationOrderDTO(removeProtectionObj);
    }
    protectionListTransform(items: any[], args: string): any {
        // filter items array, items which match and return true will be kept, false will be filtered out
        const s = args.toLowerCase();
        return items.filter(item =>
            item.equipmentRequirementSpecification.equipmentRequirementSpecificationDescription.toLowerCase().indexOf(s) !== -1);
    }

    transformEquip(items: any[], args: string): any {
        // filter items array, items which match and return true will be kept, false will be filtered out
        return items.filter(item => item.associatedDescription.toLowerCase().indexOf(args.toLowerCase()) !== -1);
    }
    clearDependentFields(flag) {
        if (flag) {
            this.operationInformationDetail['controls']['equipmentTypeCode'].setValue([]);
            this.typval = null;
            this.equipSaveParams.equipmentClassificationTypeAssociationID = null;
        }
        const lengthValue = this.operationInformationDetail['controls']['equipmentLengthCode'].value;
        if (lengthValue && lengthValue[0]) {
            const removeEquipObj = this.transformEquip(this.equipList, lengthValue[0].id)[0];
            this.removeEquipSpecificationOrderDTO(removeEquipObj);
            this.lenval = null;
        }
        const equipValues = this.operationInformationDetail['controls']['equipOption'].value;
        const freightValues = this.operationInformationDetail['controls']['freightSecurement'].value;
        for (const removeObj of equipValues) {
            this.onRemoveEquipOptionsService(removeObj);
        }
        for (const removeObj of freightValues) {
            this.onRemoveFreightSecureService(removeObj);
        }
        this.operationInformationDetail['controls']['equipmentLengthCode'].setValue([]);
        this.operationInformationDetail['controls']['equipOption'].setValue([]);
        this.operationInformationDetail['controls']['freightSecurement'].setValue([]);

    }
    onSelectEquipmentCategory(value, isSelect) {
        if (isSelect) {
            const val = value.trim();
            // this.getEquipmentOption(val, null);
            // this.getFreightSecurement(val);
            this.tempCatObjFrammer(val, '');
            this.getEquipmentType(val);
        }
        this.clearDependentFields(true);
    }
    onSelectEquipmentType(value, isSelect) {
        if (isSelect) {
            const str = value;
            const res = str.substring(0, 1);
            if (res === ' ') {
                const cate = str.substring(1, value.length);
                value = cate;
            } else {
                value = str;
            }
            const obj = this.transform(this.equipmentType, value)[0];
            const associationId = obj.equipmentClassificationTypeAssociations[0].equipmentClassificationTypeAssociationID;
            this.getEquipmentLength(associationId);
            this.getEquipmentOption(associationId, null);
            this.getFreightSecurement(associationId);
            this.equipSaveParams.equipmentClassificationTypeAssociationID = associationId;
            this.tempCatObjFrammer('', obj);
        }
        this.clearDependentFields(false);
    }
    onSelectEquipmentLength(value, isSelect) {
        if (isSelect) {
            const str = value;
            const res = str.substring(0, 1);
            if (res === ' ') {
                const cate = str.substring(1, value.length);
                value = cate;
            } else {
                value = str;
            }
            const lengthObj = this.protectionListTransform(this.equipmentLength, value)[0];
            this.frameProtectionSpecificationOrderDTO(lengthObj);
        }
    }
    loadTrailerPrefixBlur(val) {
        if (this.noncompany === true) {
            this.operationInformationDetail['controls']['trailerPrefixtxt'].setValue('');
        } /*else {
           this.onRemovePrefix(this.trailerpreTag.activeOption);
        }*/
        const value = val;
        if (value.length > 2 && value.length <= 10) {
            this.loadTrailerPrefixByNumber(val);
        }
        if (!this.jbhGlobals.utils.isEmpty(value)) {
            if (this.orderData.financeBusinessUnitCode === 'ICS') {
                this.jbhGlobals.notifications.error('Order',
            'In order for this load to be booked for ICS, you must call the customer and have it changed to Live Load');
            }
        }
    }
    checkOnPrefix(val) {
        const selectedPrefix = val;
        this.selPrefix = selectedPrefix;
        if (selectedPrefix.length > 2) {
            this.equipSaveParams.orderNonCompanyEquipmentDetails = [];
            this.checkForCompanyTrailer();
            const orderEquipmentReqObj = {
                'orderNonCompanyEquipmentDetailID': '',
                'nonCompanyEquipmentPrefix': val,
                'nonCompanyEquipmentNumber': this.selNumber,
                'equipmentClassificationCode': '',
                'lastUpdateTimestampString': ''
            };
            this.equipSaveParams.orderNonCompanyEquipmentDetails.push(orderEquipmentReqObj);
        }
    }
    loadTrailerPrefixByNumber(selectedNumber) {
        this.selNumber = selectedNumber;
        this.trailerPrefixListDescription = [];
        this.hasTrailerPrefix = false;
        const params = {
            'trailernumber': selectedNumber
        };
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getTrailerPrefixByNumber, params).subscribe(data => {
            this.trailerPrefixListDescription = [];
            this.trailerNumberList = data['_embedded']['equipments'];
            if (!this.jbhGlobals.utils.isEmpty(this.trailerNumberList)) {
                this.equipSaveParams.orderNonCompanyEquipmentDetails = [];
                this.noncompany = false;
                // console.log(this.trailerpreTag);
                const equipmentId = this.trailerNumberList[0]['equipmentId'];
                //   const equipmentId =  1712;
                this.equipSaveParams.equipmentID = equipmentId;
                if (data['_embedded']['equipments'][0]['trailerPrefix']) {
                    this.trailerPrefixListDescription.push(
                        data['_embedded']['equipments'][0]['trailerPrefix'].trim());
                }
                if (!this.jbhGlobals.utils.isEmpty(selectedNumber) && selectedNumber.trim() ===
                    data['_embedded']['equipments'][0]['trailerPrefix'].trim()) {
                    this.trailerpreTag.active.push({
                        'id': selectedNumber.trim(),
                        'text': data['_embedded']['equipments'][0]['trailerPrefix'].trim()
                    });
                }
            } else {
                this.equipSaveParams.equipmentID = 0;
                this.noncompany = true;
                console.log(this.nonCompText);

            }
        });
        this.checkForCompanyTrailer();
    }
    checkForCompanyTrailer() {
        if (this.selNumber && this.selPrefix) {
            const qParam = '/' + this.selPrefix + '/' + this.selNumber;
            this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.isCompanyTrailer + qParam).subscribe(data => {
                if (data['id']) {
                    this.isCompanyTrailer = true;
                    /*this.operationInformationDetail['controls']['orderNonCompanyEquipmentDetails'].setValidators([Validators.required]);
                    this.operationInformationDetail['controls']['orderNonCompanyEquipmentDetails'].updateValueAndValidity({
                        onlySelf: true,
                        emitEvent: false
                    });*/
                } else {
                    /* this.operationInformationDetail['controls']['orderNonCompanyEquipmentDetails'].setValidators([Validators.required]);
                     this.operationInformationDetail['controls']['orderNonCompanyEquipmentDetails'].updateValueAndValidity({
                         onlySelf: true,
                         emitEvent: false
                     });*/
                }
            });
        }
        this.selPrefix = '';
        this.saveTrailerNoDTO();
        this.saveTrailerPrefixDTO();
    }
    saveTrailerNoDTO() {
        /* if (this.orderData.orderEquipmentRequirementDTOs === undefined) {
             this.orderData.orderEquipmentRequirementDTOs = [];
         }*/
    }

    onSelectPrefix(value: any): void {
        const selectedPrefix = value.id.trim();
        this.selPrefix = selectedPrefix;
        this.checkForCompanyTrailer();
    }
    typed(selectedPrefix: any): void {
        if (selectedPrefix !== undefined && selectedPrefix.length > 3) {
            this.checkForCompanyTrailer();
        }
    }
    onSelectTrailerNumber(value: any): void {
        const selectedNumber = value.id.trim();
        this.getEquipmentId(selectedNumber);
        this.selNumber = selectedNumber;
        this.checkForCompanyTrailer();
    }
    getEquipmentId(value) {
        console.log(value);
        console.log(this.trailerNumberList);
    }
    saveTrailerPrefixDTO() {
        if (this.orderData.orderEquipmentRequirementDTOs === undefined) {
            this.orderData.orderEquipmentRequirementDTOs = [];
        }
        if (this.orderData.orderEquipmentRequirementDTOs.length === 0) {
            const trailerPrefixObj = {
                'trailerPrefix': this.selPrefix
            };
            this.orderData.orderEquipmentRequirementDTOs.push(trailerPrefixObj);
        } else if (this.orderData['orderEquipmentRequirementDTOs'][0].trailerPrefix === undefined) {
            this.orderData['orderEquipmentRequirementDTOs'][0].trailerPrefix = this.selPrefix;
        } else {
            this.orderData['orderEquipmentRequirementDTOs'][0].trailerPrefix = this.selPrefix;
        }
    }
    transform(items: any[], args: string): any {
        return items.filter(item => item.text.toLowerCase().indexOf(args.toLowerCase()) !== -1);
    }
    /*  onBlurChasisNo(value) {
          const orderEquipmentReqObj = {
              'orderNonCompanyEquipmentDetailID': 0,
              'nonCompanyEquipmentPrefix': '',
              'nonCompanyEquipmentNumber': value,
              'equipmentClassificationCode': '',
              'lastUpdateTimestampString': ''
          };
          this.equipSaveParams.orderNonCompanyEquipmentDetails.push(orderEquipmentReqObj);
             this.orderService.saveData(this.orderData);
      }*/
    ngOnInit(): void {
        this.operationInformationDetail = this.orderFormBuilder.orderForm.controls['operationInformationDetail'];
        this.debounceValue = this.jbhGlobals.settings.debounce;
        const me = this;
        this.jbhGlobals.utils.forIn(this.operationInformationDetail.controls, function (value, name, object) {
            (<FormControl>me.operationInformationDetail.controls[name]).setValue('');
            me.operationInformationDetail.controls[name].setErrors(null);
        });
        this.getOrder();
        const eCategory = this.operationInformationDetail['controls']['equipmentClassificationRequiredIndicator'];
        eCategory['valueChanges'].debounceTime(this.debounceValue).distinctUntilChanged().subscribe((equipCateIndicator) => {
            if (equipCateIndicator === true) {
                this.equipSaveParams.equipmentClassificationRequiredIndicator = 'Y';
            }
            if (equipCateIndicator === false) {
                this.equipSaveParams.equipmentClassificationRequiredIndicator = 'N';
            }
        }, (err: Error) => {
            console.log(err);
        });
        const eType = this.operationInformationDetail['controls']['equipmentTypeRequiredIndicator'];
        eType['valueChanges'].debounceTime(this.debounceValue).distinctUntilChanged().subscribe((equipTypeIndicator) => {
            if (equipTypeIndicator === true) {
                this.equipSaveParams.equipmentTypeRequiredIndicator = 'Y';
            }
            if (equipTypeIndicator === false) {
                this.equipSaveParams.equipmentTypeRequiredIndicator = 'N';
            }
        }, (err: Error) => {
            console.log(err);
        });
        const eLen = this.operationInformationDetail['controls']['equipmentLengthRequiredIndicator'];
        eLen['valueChanges'].debounceTime(this.debounceValue).distinctUntilChanged().subscribe((equipLengthIndicator) => {
            if (equipLengthIndicator === true) {
                this.equipSaveParams.equipmentLengthRequiredIndicator = 'Y';
            }
            if (equipLengthIndicator === false) {
                this.equipSaveParams.equipmentLengthRequiredIndicator = 'N';
            }
        }, (err: Error) => {
            console.log(err);
        });
        if (this.isdataLoaded) {
            this.loadProtectionMaterialHandling(null);
        }
        if (this.jbhGlobals.utils.isEmpty(this.orderData.orderEquipmentRequirementDTOs)) {
            this.equipSaveParams = {

                'orderEquipmentRequirementID': '',
                'equipmentID': 0,
                'trailerPreloadedIndicator': 'N',
                'equipmentTypeRequiredIndicator': 'N',
                'equipmentLengthRequiredIndicator': 'N',
                'equipmentClassificationRequiredIndicator': 'N',
                'lastUpdateTimestampString': '',
                'equipmentClassificationTypeAssociationID': 0, // from service pending
                'orderEquipmentRequirementSpecificationAssociations': [],
                'orderNonCompanyEquipmentDetails': [],
                'orderEquipmentRequirementFeatureAssociations': [],
                'order': ''
            };
        }
    }
    categoryTransform(items: any[], args: string): any {
        // filter items array, items which match and return true will be kept, false will be filtered out
        return items.filter(item => item.equipmentClassificationDescription.toLowerCase().indexOf(args.toLowerCase()) !== -1);
    }
    equipListTransform(items: any[], args: string): any {
        // filter items array, items which match and return true will be kept, false will be filtered out
        return items.filter(item => item.associatedDescription.toLowerCase().indexOf(args.toLowerCase()) !== -1);
    }
    frameProtectionSpecificationOrderDTO(obj) {
        if (obj.equipmentRequirementSpecificationDetail !== null) {
            const equipSpecObj = {
                'orderEquipmentRequirementSpecificationAssociationID': '',
                'equipmentRequirementSpecificationAssociationID': obj.equipmentRequirementSpecificationAssociationID,
                'equipmentRequirementSpecificationDetailID':
                obj.equipmentRequirementSpecificationDetail[0].equipmentRequirementSpecificationDetailID,
                'lastUpdateTimestampString': '',
                'orderEquipmentRequirementSpecificationDetails': [{
                    'orderEquipmentRequirementSpecificationDetailID': '',
                    'temperatureLowRange': '',
                    'temperatureHighRange': '',
                    'unitOfTemperatureMeasurementCode': '',
                    'lastUpdateTimestampString': '',
                    'specificationDetailValue': '',
                    'frontZoneprecoolTemperature': '',
                    'rearZoneprecoolTemperature': ''
                }]
            };
            this.equipSaveParams.orderEquipmentRequirementSpecificationAssociations.push(equipSpecObj);
        } else {
            const equipSpecObj = {
                'orderEquipmentRequirementSpecificationAssociationID': '',
                'equipmentRequirementSpecificationAssociationID': obj.equipmentRequirementSpecificationAssociationID,
                'equipmentRequirementSpecificationDetailID': '',
                'lastUpdateTimestampString': '',
                'orderEquipmentRequirementSpecificationDetails': [{
                    'orderEquipmentRequirementSpecificationDetailID': '',
                    'temperatureLowRange': '',
                    'temperatureHighRange': '',
                    'unitOfTemperatureMeasurementCode': '',
                    'lastUpdateTimestampString': '',
                    'specificationDetailValue': '',
                    'frontZoneprecoolTemperature': '',
                    'rearZoneprecoolTemperature': ''
                }]
            };
            this.equipSaveParams.orderEquipmentRequirementSpecificationAssociations.push(equipSpecObj);
            if (this.isCurrViewTemplate) {
                this.templateEquipReqSpecFrammer(obj);
            }
        }
    }
    removeProtectionSpecificationOrderDTO(obj) {
        for (let i = 0; i < this.equipSaveParams.orderEquipmentRequirementSpecificationAssociations.length; i++) {
            const equipDesc = this.equipSaveParams.orderEquipmentRequirementSpecificationAssociations[i].
                equipmentRequirementSpecificationAssociationID;
            if (equipDesc === obj.equipmentRequirementSpecificationAssociationID) {
                this.equipSaveParams.orderEquipmentRequirementSpecificationAssociations.splice(i, 1);
            }
        }
    }
    frameEquipSpecificationOrderDTO(obj) {
        const equipSpecObj = {
            'orderEquipmentRequirementSpecificationAssociationID': '',
            'equipmentRequirementSpecificationAssociationID':
            obj.equipmentRequirementSpecificationAssociationID,
            'equipmentRequirementSpecificationDetailID':
            obj.equipmentRequirementSpecificationDetail[0].equipmentRequirementSpecificationDetailID,
            'lastUpdateTimestampString': '',
            'orderEquipmentRequirementSpecificationDetails': [{
                'orderEquipmentRequirementSpecificationDetailID': '',
                'temperatureLowRange': '',
                'temperatureHighRange': '',
                'lastUpdateTimestampString': '',
                'unitOfTemperatureMeasurementCode': '',
                'specificationDetailValue': '',
                'frontZoneprecoolTemperature': '',
                'rearZoneprecoolTemperature': ''
            }]
        };
        this.equipSaveParams.orderEquipmentRequirementSpecificationAssociations.push(equipSpecObj);
        if (this.isCurrViewTemplate) {
            this.templateEquipReqSpecFrammer(obj);
        }
    }
    removeEquipSpecificationOrderDTO(obj) {
        console.log(this.equipSaveParams);
        for (let i = 0; i <
            this.equipSaveParams.orderEquipmentRequirementSpecificationAssociations.length; i++) {
            const equipDesc = this.equipSaveParams.orderEquipmentRequirementSpecificationAssociations[i].
                equipmentRequirementSpecificationAssociationID;
            if (equipDesc === obj.equipmentRequirementSpecificationAssociationID) {
                this.equipSaveParams.orderEquipmentRequirementSpecificationAssociations.splice(i, 1);
            }
        }
        if (this.isCurrViewTemplate) {
            this.removeEquipSpecTemplate(obj);
        }
    }
    frameFeatureSpecificationOrderDTO(featureObj) {
        const eqFtObj = {
            'orderEquipmentRequirementFeatureAssociationID': '', // pend
            'equipmentClassificationTypeFeatureAssociationID': featureObj.equipmentClassificationTypeFeatureAssociationID,
            'orderEquipmentRequirementFeatureValue': null,
            'lastUpdateTimestampString': ''
        };
        this.equipSaveParams.orderEquipmentRequirementFeatureAssociations.push(eqFtObj);
    }
    getOrder() {
        this.subscription = this.orderService.getData().subscribe(sharedOrderData => {
            this.orderData = sharedOrderData;
            if (!this.jbhGlobals.utils.isEmpty(this.orderData)) {
                this.callPopulateMethod();
                if (this.orderData.serviceOfferingCode && this.orderData.financeBusinessUnitCode) {
                    if (this.serviceOfferingValue !== this.orderData.serviceOfferingCode ||
                        this.financeBUValue !== this.orderData.financeBusinessUnitCode) {
                        this.serviceOfferingValue = this.orderData.serviceOfferingCode;
                        this.financeBUValue = this.orderData.financeBusinessUnitCode;
                        if (this.financeBUValue === 'ICS' && this.serviceOfferingValue === 'LTL' ||
                            this.financeBUValue === 'DCS' && this.serviceOfferingValue === 'FinalMile') {
                            this.showEquipment = false;
                            this.disabletab = false;
                        } else if (this.financeBUValue === 'ICS' &&
                            this.serviceOfferingValue === 'Flatbed' && !this.isCurrViewTemplate) {
                            this.disabletab = true;
                            this.showEquipment = true;
                            this.onClickTrailerEquip(true);
                        } else if (this.financeBUValue === 'DCS' &&
                            this.serviceOfferingValue === 'Backhaul') {
                            this.disabletab = false;
                            this.showEquipment = true;
                            this.operationInformationDetail['controls']['equipmentCategoryCode'].setValidators(
                                this.cateval === 'undefined' ? [Validators.required] : []);
                            this.operationInformationDetail['controls']['equipmentCategoryCode'].updateValueAndValidity(
                                { onlySelf: true, emitEvent: false });
                            this.operationInformationDetail['controls']['equipmentTypeCode'].setValidators(
                                this.typval === 'undefined' ? [Validators.required] : []);
                            this.operationInformationDetail['controls']['equipmentTypeCode'].updateValueAndValidity(
                                { onlySelf: true, emitEvent: false });
                            this.operationInformationDetail['controls']['equipmentLengthCode'].setValidators(
                                this.lenval === 'undefined' ? [Validators.required] : []);
                            this.operationInformationDetail['controls']['equipmentLengthCode'].updateValueAndValidity(
                                { onlySelf: true, emitEvent: false });
                            this.operationInformationDetail.updateValueAndValidity(
                                { onlySelf: true, emitEvent: false });
                        } else {
                            this.operationInformationDetail['controls']['equipmentCategoryCode'].setValidators([]
                            );
                            this.operationInformationDetail['controls']['equipmentCategoryCode'].updateValueAndValidity(
                                { onlySelf: true, emitEvent: false });
                            this.operationInformationDetail['controls']['equipmentTypeCode'].setValidators([]
                            );
                            this.operationInformationDetail['controls']['equipmentTypeCode'].updateValueAndValidity(
                                { onlySelf: true, emitEvent: false });
                            this.operationInformationDetail['controls']['equipmentLengthCode'].setValidators([]
                            );
                            this.operationInformationDetail['controls']['equipmentLengthCode'].updateValueAndValidity(
                                { onlySelf: true, emitEvent: false });
                            this.operationInformationDetail.updateValueAndValidity(
                                { onlySelf: true, emitEvent: false });
                            this.showEquipment = true;
                            this.disabletab = false;
                        }
                        this.getEquipmentCategory();
                    }
                }
            }
        });
    }
    onRemoveTrailerNumber(value: any): void { }
    onTypeTrailerNumber(selectedNumber: any): void {
        if (selectedNumber !== undefined && selectedNumber.length > 5) {
            this.loadTrailerPrefixByNumber(selectedNumber);
        }
    }
    onRemovePrefix(value: any): void { }
    refreshValue(value: any): void {
        this.value = value;
    }
    callPopulateMethod() {
        if (this.isCurrViewTemplate) {
            setTimeout(() => {
                if (this.isEditOrder) {
                    this.populateData();
                }
            }, 500);
        } else {
            if (this.isEditOrder) {
                this.populateData();
            }

        }
    }
    populateData() {
        this.isEditOrder = false;
        if (this.orderData.orderEquipmentRequirementDTOs.length !== 0) {
            if (!this.jbhGlobals.utils.isEmpty(this.orderData.orderEquipmentRequirementDTOs[0].orderEquipmentRequirement)) {
                this.equipSaveParams =
                    this.orderData.orderEquipmentRequirementDTOs[0].orderEquipmentRequirement;
                const associationId = this.equipSaveParams.equipmentClassificationTypeAssociationID;
                this.getEquipmentOption(associationId, null);
            }
        }
        if (this.orderData.orderEquipmentRequirementDTOs.length !== 0) {
            if (this.orderData.orderEquipmentRequirementDTOs[0].orderEquipmentRequirement.trailerPreloadedIndicator === 'Y' &&
                this.orderData.orderEquipmentRequirementDTOs[0].trailerNumber !== null) {
                this.onClickTrailerEquip(false);
                this.flag = false;
                const trailNum = this.orderData.orderEquipmentRequirementDTOs[0].trailerNumber.trim();
                const trailpre = this.orderData.orderEquipmentRequirementDTOs[0].trailerPrefix.trim();
                if (this.orderData.orderEquipmentRequirementDTOs[0].orderEquipmentRequirement.equipmentID === 0) {
                    this.operationInformationDetail['controls']['trailerNumber'].setValue(trailNum);
                    this.operationInformationDetail['controls']['trailerPrefixtxt'].setValue(trailpre);
                } else {
                    this.noncompany = false;
                    setTimeout(() => {
                        this.trailerpreTag.active.push({
                            'id': trailpre,
                            'text': trailpre
                        });
                        this.loadTrailerPrefixByNumber(trailNum);
                    }, 1000);
                    this.operationInformationDetail['controls']['trailerNumber'].setValue(trailNum);
                }
            } else {
                if (!this.jbhGlobals.utils.isEmpty(this.orderData.orderEquipmentRequirementDTOs[0].orderEquipmentTypeCategoryDetailDTO)) {
                    this.equipTypeInitialValue =
                        this.orderData.orderEquipmentRequirementDTOs[0].orderEquipmentTypeCategoryDetailDTO.equipmentTypeCode;
                    this.equipCategoryIntialValue =
                        this.orderData.orderEquipmentRequirementDTOs[0].orderEquipmentTypeCategoryDetailDTO.equipmentCategoryDescription;
                    this.cateval = this.equipCategoryIntialValue.trim();
                    this.typval = this.equipTypeInitialValue.trim();
                    if (this.cateval) {
                        this.getEquipmentType(this.cateval);
                    }
                    this.getFreightSecurement(this.equipSaveParams.equipmentClassificationTypeAssociationID);
                    if (!this.jbhGlobals.utils.isEmpty(this.equipTypeInitialValue) &&
                        !this.jbhGlobals.utils.isEmpty(this.equipCategoryIntialValue)) {
                        this.equipCategory = this.equipCategoryIntialValue;
                        this.equipType = this.equipTypeInitialValue;
                    }
                }
                this.onClickTrailerEquip(true);
                this.flag = true;
                if (!this.jbhGlobals.utils.isEmpty(
                    this.orderData.orderEquipmentRequirementDTOs[0].orderEquipmentRequirementSpecificationAssociationDTOs)) {
                    const reqDTO = this.orderData.orderEquipmentRequirementDTOs[0].orderEquipmentRequirementSpecificationAssociationDTOs;
                    for (const equipReq of reqDTO) {
                        const equipTypeCode = equipReq.equipmentRequirementTypeCode;
                        switch (equipTypeCode) {
                            case 'Floor':
                            case 'Door':
                            case 'Roof':
                                this.equipOptSelectedArray.push({
                                    'id': equipReq.equipmentRequirementSpecificationDescription + '&nbsp;' + equipTypeCode,
                                    'text': equipReq.equipmentRequirementSpecificationDescription + '&nbsp;' + equipTypeCode
                                });
                                break;
                            case 'Freight':
                                this.freightSecSelectedArray.push({
                                    'id': equipTypeCode,
                                    'text': equipReq.equipmentRequirementSpecificationDescription
                                });
                                break;
                            case 'MatHandEqu':
                            case 'PersnalPro':
                                const val = {
                                    'id': equipReq.equipmentRequirementSpecificationDescription,
                                    'text': equipReq.equipmentRequirementSpecificationDescription
                                };
                                this.protectionmaterialTag.active.push({
                                    'id': equipTypeCode,
                                    'text': equipReq.equipmentRequirementSpecificationDescription
                                });
                                this.loadProtectionMaterialHandling(val);
                                break;
                            case 'Length':
                                this.lenval = equipReq.equipmentRequirementSpecificationDescription;
                                const AssociationId =
                                    this.orderData.orderEquipmentRequirementDTOs[0].
                                        orderEquipmentRequirement.equipmentClassificationTypeAssociationID;
                                this.getEquipmentLength(AssociationId);
                                break;
                            default:
                                break;
                        }
                    }
                    if (this.equipOptSelectedArray.length > 0) {
                        this.getEquipmentOption(this.equipSaveParams.equipmentClassificationTypeAssociationID, this.equipOptSelectedArray);
                    }
                    this.operationInformationDetail.controls['equipOption'].setValue(this.equipOptSelectedArray);
                    this.operationInformationDetail.controls['freightSecurement'].setValue(this.freightSecSelectedArray);

                }
                if (!this.jbhGlobals.utils.isEmpty(
                    this.orderData.orderEquipmentRequirementDTOs[0].orderEquipementRequirementFeatureAssociationDTOs)) {
                    const reqDTO = this.orderData.orderEquipmentRequirementDTOs[0].orderEquipementRequirementFeatureAssociationDTOs;
                    for (const equipReq of reqDTO) {
                        this.equipmentoptionTag.active.push({
                            'id': equipReq.equipmentFeatureDescription + '&nbsp;' + 'Other',
                            'text': equipReq.equipmentFeatureDescription + '&nbsp;' + 'Other'
                        });

                    }
                }
                if (this.orderData.orderEquipmentRequirementDTOs[0]) {
                    console.log(this.orderData.orderEquipmentRequirementDTOs[0]);
                }
                if (this.orderData.orderEquipmentRequirementDTOs[0].
                    orderEquipmentRequirement.equipmentClassificationRequiredIndicator === 'Y') {
                    this.operationInformationDetail['controls']['equipmentClassificationRequiredIndicator'].setValue('true');
                }
                if (this.orderData.orderEquipmentRequirementDTOs[0].
                    orderEquipmentRequirement.equipmentLengthRequiredIndicator === 'Y') {
                    this.operationInformationDetail['controls']['equipmentLengthRequiredIndicator'].setValue('true');
                }
                if (this.orderData.orderEquipmentRequirementDTOs[0].orderEquipmentRequirement.equipmentTypeRequiredIndicator === 'Y') {
                    this.operationInformationDetail['controls']['equipmentTypeRequiredIndicator'].setValue('true');
                }
            }
        }
    }
    onSaveSelectedOptions(selVal) {
        const equipRequirementObj = this.transformEquip(this.equipList, selVal)[0];
        if (equipRequirementObj) {
            for (let i = 0; i < this.selectedEquipList.length; i++) {
                if (this.selectedEquipList[i].type === equipRequirementObj.code) {
                    if (this.selectedEquipmentTags.length > 1) {
                        this.selectedEquipmentTags.splice(this.selectedEquipmentTags.indexOf(this.selectedEquipList[i].desc), 1);
                        this.jbhGlobals.notifications.alert('Failure', 'Only one ' + equipRequirementObj.code + ' can be selected');
                    }
                }
            }
            const equipObj = {
                'type': equipRequirementObj.code,
                'desc': equipRequirementObj.description
            };
            const isPresent = this.jbhGlobals.utils.find(this.selectedEquipList, {
                'type': equipRequirementObj.code
            });
            if (this.jbhGlobals.utils.isEmpty(isPresent)) {
                this.selectedEquipList.push(equipObj);
            }
        }
    }
    onValidateForm() {
        const me = this;
        this.jbhGlobals.utils.forIn(this.operationInformationDetail.controls,
            function (value, name, object) {
                me.operationInformationDetail.controls[name].markAsTouched();
            });
    }
    templateEquipReqSpecFrammer(data) {
        const obj = {
            'equipmentRequirementSpecificationAssociationID': data.equipmentRequirementSpecificationAssociationID,
            'equipmentRequirementSpecificationCode': data.associatedCode ?
                data.associatedCode : data.equipmentRequirementSpecification.equipmentRequirementSpecificationCode,
            'equipmentRequirementSpecificationDescription': data.associatedDescription ?
                data.associatedDescription : data.equipmentRequirementSpecification.equipmentRequirementSpecificationDescription,
            'equipmentRequirementSpecificationDetail': null,
            'equipmentRequirementTypeCode': data.code ?
                data.code : data.equipmentRequirementType.equipmentRequirementTypeCode,
            'equipmentRequirementTypeDescription': data.description ?
                data.description : data.equipmentRequirementType.equipmentRequirementTypeDescription,
            'orderEquipmentRequirementSpecificationAssociationID': null
        };
        if (!this.orderData.orderEquipmentRequirementSpecificationAssociationDTO) {
            this.orderData.orderEquipmentRequirementSpecificationAssociationDTO = [];
        }
        this.orderData.orderEquipmentRequirementSpecificationAssociationDTO.push(obj);
    }
    removeEquipSpecTemplate(data) {
        const specDTO = this.orderData.orderEquipmentRequirementSpecificationAssociationDTO;
        if (data) {
            for (let i = 0; i < specDTO.length; i++) {
                const equipDesc = this.orderData.orderEquipmentRequirementSpecificationAssociationDTO[i].
                    equipmentRequirementSpecificationAssociationID;
                if (equipDesc === data.equipmentRequirementSpecificationAssociationID) {
                    this.orderData.orderEquipmentRequirementSpecificationAssociationDTO.splice(i, 1);
                }
            }
        }
    }
    tempCatObjFrammer(catData, typeData) {
        if (catData) {
            this.category = catData;
        }
        if (typeData) {
            this.type = typeData;
        }
        if (this.category && this.type) {
            const obj = {
                'equipmentCategoryClassificationTypeAssociationID': null,
                'equipmentCategoryCode': this.category ? this.category : null,
                'equipmentCategoryDescription': this.category ? this.category : null,
                'equipmentTypeCode': this.type ? this.type.id : null,
                'equipmentTypeDescription': this.type ? this.type.text : null
            };
            if (!(this.orderData.orderEquipmentRequirementDTOs[0] &&
                this.orderData.orderEquipmentRequirementDTOs[0].orderEquipmentTypeCategoryDetailDTO)) {
                if (!this.orderData.orderEquipmentRequirementDTOs[0]) {
                    this.orderData.orderEquipmentRequirementDTOs = [{}];
                }
                this.orderData.orderEquipmentRequirementDTOs[0].orderEquipmentTypeCategoryDetailDTO = {};
            }
            this.orderData.orderEquipmentRequirementDTOs[0].orderEquipmentTypeCategoryDetailDTO = obj;
        }
    }
    enterToClick(field, event) {
        if (event.keyCode === 13) {
            if (field === 'equipTypeFlex') {
                this.equipTypeFlex.nativeElement.click();
            } else if (field === 'equipLengthFlex') {
                this.equipLengthFlex.nativeElement.click();
            } else if (field === 'equipCategoryFlex') {
                this.equipCategoryFlex.nativeElement.click();
            } else { }
        }
    }
}
