import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Response } from '@angular/http';

import { JBHGlobals } from '../../../../../app.service';

@Injectable()
export class ItemService {

  constructor(private jbhGlobals: JBHGlobals) { }

  getTransItemDescription(value) {
      const url = this.jbhGlobals.endpoints.order.getTransTypeahead + '/' + value;
      return this.jbhGlobals.apiService.getData(url, null, false);
  }
  getSavedItemDescription(value) {
      const url = this.jbhGlobals.endpoints.order.getSavedItem + '/' + value;
      return this.jbhGlobals.apiService.getData(url, null, false);
  }
  addItem(url, params): Observable<Response[]> {
    return this.jbhGlobals.apiService.addData(url, params);
  }
  updateItem(url, params): Observable<Response[]> {
    return this.jbhGlobals.apiService.updateData(url, params);
  }
  getBarCode(url): Observable<Response[]> {
    return this.jbhGlobals.apiService.getData(url, null, false);
  }
  getItemService(url, param): Observable<Response[]> {
    return this.jbhGlobals.apiService.getData(url, param, false);
  }
  getModelNumber(url, param): Observable<Response[]> {
    return this.jbhGlobals.apiService.getData(url, param, false);
  }
  getItemCharacteristics(url): Observable<Response[]> {
    return this.jbhGlobals.apiService.getData(url, null, false);
  }
  getExtremeLength(url, params): Observable<Response[]> {
    return this.jbhGlobals.apiService.getData(url, params, false);
  }
  getSavedItemListService(url, params): Observable<Response[]> {
    return this.jbhGlobals.apiService.getData(url, params, false);
  }
  transItemDescription(url): Observable<Response[]> {
    return this.jbhGlobals.apiService.getData(url, null, false);
  }
  savedItemDescription(url): Observable<Response[]> {
    return this.jbhGlobals.apiService.getData(url, null, false);
  }
}
