import { inject, TestBed } from '@angular/core/testing';

import { AppointmentDetailsUtilsService } from './appointment-details-utils.service';

describe('AppointmentDetailsUtilsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AppointmentDetailsUtilsService]
    });
  });

  it('should be created', inject([AppointmentDetailsUtilsService], (service: AppointmentDetailsUtilsService) => {
    expect(service).toBeTruthy();
  }));
});
