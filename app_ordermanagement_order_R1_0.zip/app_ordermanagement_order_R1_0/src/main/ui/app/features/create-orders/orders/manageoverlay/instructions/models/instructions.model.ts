export class InstructionsModel {
insArr: Array < string > = [];
instructionStopData: any;
insComments = [];
innerHtmlIns: any = '';
orderId: number;
showEditInsBtn: boolean;
subscription: any;
stopServiceId: any;
editDelIndex: number;
orderData: any;
instructionIndex: any = [];
viewInstructionIndex: any = [];
currentPage: any;
editCall = false;
editViewInstruction: any = [];
showdelInsBtn: boolean;
saveCall: boolean;
cancelBtn = false;
editIns: any;
selectedInstDiv: any;
stopID: any;
selectedInsDivv: any;
stopUniqueId: any;
instructionObj: any;
instructionDTO: any;
}
