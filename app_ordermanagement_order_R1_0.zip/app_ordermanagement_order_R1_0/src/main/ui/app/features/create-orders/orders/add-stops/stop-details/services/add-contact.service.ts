import { Injectable } from '@angular/core';

import { JBHGlobals } from '../../../../../../app.service';

@Injectable()
export class AddContactService {

 constructor(public jbhGlobals: JBHGlobals) { }

  loadServices(url) {
    return this.jbhGlobals.apiService.getData(url);
  }

  addContactDetails(url, params) {
    return this.jbhGlobals.apiService.addData(url, params);
  }
}
