import { inject, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';

import { ItemService } from './item.service';

import { AppModule } from '../../../../../app.module';

describe('ItemService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
imports: [AppModule, RouterTestingModule],
       providers: [ItemService]
    });
  });

  it('should be created', inject([ItemService], (service: ItemService) => {
    expect(service).toBeTruthy();
  }));
});
