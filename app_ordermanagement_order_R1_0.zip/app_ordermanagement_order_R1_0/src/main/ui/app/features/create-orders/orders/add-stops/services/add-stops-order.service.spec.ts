import { inject, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';

import { AddStopsOrderService } from './add-stops-order.service';

import { AppModule } from '../../../../../app.module';

describe('AddStopsOrderService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
imports: [AppModule, RouterTestingModule],
      providers: [AddStopsOrderService]
    });
  });

  it('should be created', inject([AddStopsOrderService], (service: AddStopsOrderService) => {
    expect(service).toBeTruthy();
  }));
});
