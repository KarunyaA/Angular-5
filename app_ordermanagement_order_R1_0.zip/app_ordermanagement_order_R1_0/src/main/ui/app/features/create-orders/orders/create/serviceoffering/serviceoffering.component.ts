import { Component, ChangeDetectorRef, Input, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import  * as moment  from  'moment';
import { JBHGlobals } from '../../../../../app.service';

import { IMyDateModel, IMyOptions } from 'mydatepicker';

import { OrderService } from '../../services/order.service';
import { OrderFormBuilderService } from '../../services/order-form-builder.service';

@Component({
    selector: 'app-serviceoffering',
    templateUrl: './serviceoffering.component.html',
    styleUrls: ['./serviceoffering.component.scss']
})
export class ServiceofferingComponent implements OnInit, OnDestroy {
    @ViewChild('businessunit') businessunitTag;
    @ViewChild('orderserviceTag') orderserviceTag;
    transitMode: string;
    dollarInputRequired = false;
    orginCustomerDrayFlag = false;
    orginCusFlag = false;
    businessUnitList: any[];
    selected = false;
    serviceLevelList: any[];
    tradingPartnerList: any[] = [];
    freightChargeList: any[];
    freightChargeFlag = true;
    serviceOfferingList: any[];
    serviceOfferingArray: any[];
    operationalServicesList: any[];
    operationalServicesListDescription: any[];
    operationalOwnerListDescription: any[] = [];
    operationalOwnerIconDetails: any;
    oprOwnerValue: string;
    debounceValue: number;
    selectedBunit: string;
    selectedServiceOffering: string;
    isEditFlag = true;
    isLoadOwnerListFlag = false;
    currentDate: any = new Date();
    currentYear: number = this.currentDate.getFullYear();
    currentMonth: number = this.currentDate.getMonth() + 1;
    currentDay: number = this.currentDate.getDate() - 1;
    myDatePickerOptionsStartDate: IMyOptions = {
        todayBtnTxt: 'Today',
        dateFormat: 'mm/dd/yyyy',
        firstDayOfWeek: 'mo',
        showTodayBtn: false,
        showClearDateBtn: false,
        editableDateField: false,
        sunHighlight: true,
        height: '34px',
        width: '170px',
        inline: false,
        disableUntil: {
            year: this.currentYear,
            month: this.currentMonth,
            day: this.currentDay
        },
        // disableUntil: {year: 2016, month: 8, day: 10},
        dayLabels: {
            su: 'S',
            mo: 'M',
            tu: 'T',
            we: 'W',
            th: 'T',
            fr: 'F',
            sa: 'S'
        },
        selectionTxtFontSize: '14px'
    };

    @Input() serviceOfferingDetail: any;
    @Input() isCurrViewTemplate: boolean;
    subscriptions: any = [];
    orderData: any;
    placeholder = 'Operational Services';
    dateValue: any;

    constructor(public jbhGlobals: JBHGlobals,
        public orderService: OrderService,
        public orderFormBuilder: OrderFormBuilderService,
		private changeDetector: ChangeDetectorRef) {
    }

    ngOnInit(): void {
        this.serviceOfferingDetail = this.orderFormBuilder.orderForm.controls['serviceOfferingDetail'];
        this.debounceValue = this.jbhGlobals.settings.debounce;
        const me = this;
        this.jbhGlobals.utils.forIn(this.serviceOfferingDetail.controls, function (value, name, object) {
            (<FormControl>me.serviceOfferingDetail.controls[name]).setValue('');
            me.serviceOfferingDetail.controls[name].setErrors(null);
        });
        this.getOrder();
        this.loadBusinessUnit(null);

        //        if (this.isCurrViewTemplate) {
        //            if (!this.orderData.tradingPartnerCode) {
        //                this.loadTradingPartner(null);
        //            }
        //        };
        this.subscriptions.push(this.serviceOfferingDetail['controls']['projectCode']['valueChanges']
            .debounceTime(this.debounceValue)
            .distinctUntilChanged()
            .subscribe((selectedValue) => {
                if (this.jbhGlobals.utils.isEmpty(selectedValue)) {
                    this.isLoadOwnerListFlag = true;
                    this.operationalOwnerListDescription = [];
                    if (this.orderData) {
                        const operDto = this.orderData.orderOperationalElementDTOs;
                        if (operDto && operDto.length > 0) {
                            if (operDto[0].orderOperationalElement) {
                                operDto[0].orderOperationalElement['projectCode'] = '';
                                this.orderService.saveData(this.orderData);
                            }
                        }
                    }
                }
                if (!this.jbhGlobals.utils.isEmpty(selectedValue) && selectedValue.length > 2) {
                    if (this.isLoadOwnerListFlag && selectedValue.indexOf(' ') === -1) {
                        this.loadOperationalOwner(selectedValue);
                    }
                }
            }, (err: Error) => {
                console.log(err);
            }));
        if (this.isCurrViewTemplate) {
            this.subscriptions.push(this.serviceOfferingDetail['controls']['tradingPartnerCode']['valueChanges']
                .debounceTime(this.debounceValue)
                .distinctUntilChanged()
                .subscribe((selectedValue) => {
                    if (!this.jbhGlobals.utils.isEmpty(selectedValue) && selectedValue.length > 2 && (!this.selected)) {
                        this.loadTradingPartner(selectedValue);
                    }
                    this.selected = false;
                }, (err: Error) => {
                    console.log(err);
                }));
        }
    }
    ngOnDestroy(): void {
        this.serviceOfferingDetail.reset();
        for (const subs of this.subscriptions) {
            subs.unsubscribe();
        }
    }
    getOrder() {
        const orderSubscribe = this.orderService.getData().subscribe(sharedOrderData => {
            this.orderData = sharedOrderData;
            if (!this.jbhGlobals.utils.isEmpty(this.orderData)) {
                this.callPopulateMethod();
                if (this.freightChargeFlag) {
                    this.loadFreightChargeTerms('Prepaid');
                    this.freightChargeFlag = false;
                }
            }
        });
        this.subscriptions.push(orderSubscribe);
    }
    callPopulateMethod() {
        setTimeout(() => {
            if (this.isEditFlag) {
                this.orderserviceTag.active = [];
                this.populateData();
            }
        }, 500);
    }
    populateData() {
        this.isEditFlag = false;
        if (!this.jbhGlobals.utils.isEmpty(this.orderData.financeBusinessUnitCode)) {
            this.loadBusinessUnit(this.orderData.financeBusinessUnitCode);
        }
        if (!this.jbhGlobals.utils.isEmpty(this.orderData.serviceOfferingCode)) {
            this.loadServiceOfferingList(this.orderData.financeBusinessUnitCode, this.orderData.serviceOfferingCode);
        }
        if (!this.jbhGlobals.utils.isEmpty(this.orderData.transitModeCode)) {
            this.transitMode = this.orderData.transitModeCode;
        }
        if (!this.jbhGlobals.utils.isEmpty(this.orderData.requestedServiceLevelCode)) {
            this.loadServiceLevels(this.orderData.requestedServiceLevelCode);
        } else {
            this.serviceOfferingDetail['controls']['requestedServiceLevelCode'].setValue([{ 'id': 'Standard', 'text': 'Standard' }]);
            this.orderData.requestedServiceLevelCode = 'Standard';
        }
        if (!this.jbhGlobals.utils.isEmpty(this.orderData.orderBillingDetailDTOs)) {
            const freightValue = this.orderData.orderBillingDetailDTOs[0].freightChargeTermTypeCode;
            this.loadFreightChargeTerms(freightValue ? freightValue.trim() : null);
        }
        if (!this.jbhGlobals.utils.isEmpty(this.orderData.orderOperationalElementDTOs) &&
            this.jbhGlobals.utils.isArray(this.orderData.orderOperationalElementDTOs)) {
            if (this.orderData.orderOperationalElementDTOs.length) {
                this.loadOperationalOwner(this.orderData.orderOperationalElementDTOs[0].orderOperationalElement.projectCode, true);
            }
        }
        if (!this.jbhGlobals.utils.isEmpty(this.orderData.orderServices)) {
            this.loadOperationalServices(this.orderData.orderServices);
        } else {
            this.loadOperationalServices(null);
        }
        if (!this.jbhGlobals.utils.isEmpty(this.orderData.scac)) {
            this.serviceOfferingDetail['controls']['scac'].setValue(this.orderData.scac);
        };
        if (this.orderData.tradingPartnerCode) {
            this.selected = true;
            this.populateTradingPartner(this.orderData.tradingPartnerCode);
        };
    }
    loadBusinessUnit(value) {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getbusinessunit).subscribe(data => {
            const businessUnitLists = data['_embedded']['serviceOfferingBusinessUnitTransitModeAssociations'];
            this.businessUnitList = [];
            for (const businessunit of businessUnitLists) {
                this.businessUnitList.push({
                    'id': businessunit['financeBusinessUnitServiceOfferingAssociation'].financeBusinessUnitCode,
                    'text': businessunit['financeBusinessUnitServiceOfferingAssociation'].financeBusinessUnitCode
                });
                if (!this.jbhGlobals.utils.isEmpty(value) &&
                    value === businessunit['financeBusinessUnitServiceOfferingAssociation'].financeBusinessUnitCode) {
                    this.serviceOfferingDetail.controls.financeBusinessUnitCode.setValue([{
                        'id': value,
                        'text': businessunit['financeBusinessUnitServiceOfferingAssociation'].financeBusinessUnitCode
                    }]);
                }
            }
        });
        if (!this.jbhGlobals.utils.isEmpty(value) && value === 'ICS') {
            this.serviceOfferingDetail.get('projectCode').setValidators([Validators.required]);
            this.serviceOfferingDetail.get('projectCode').updateValueAndValidity();
        }
    }
    loadServiceOfferingList(buvalue, value) {
        const params = {
            'financeBusinessUnitCode': buvalue,
            'projection': 'viewserviceofferingbusinessunittransitmode'
        };
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getserviceoffering, params).subscribe(data => {
            this.serviceOfferingArray = data['_embedded']['serviceOfferingBusinessUnitTransitModeAssociations'];
            this.serviceOfferingList = [];
            for (const serOffer of this.serviceOfferingArray) {
                this.serviceOfferingList.push({
                    'id': serOffer.serviceOfferingCode,
                    'text': serOffer.serviceOfferingCode
                });
                if (!this.jbhGlobals.utils.isEmpty(value) && value === serOffer.serviceOfferingCode) {
                    this.serviceOfferingDetail.controls.serviceOfferingCode.setValue([{
                        'id': value,
                        'text': serOffer.serviceOfferingCode
                    }]);
                }
            }
        });
    }
    loadTradingPartner(value) {
        const params = {
            'partnerCode': value,
            'docType': '990,214'
        }
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.template.getTradingPartners, params).subscribe(data => {
            const tpList = [];
            if (data) {
                for (const trpItem of data) {
                    tpList.push({
                        'code': trpItem['tradingPartnerCode'].trim(),
                        'text': trpItem['tradingPartnerDescription'].trim()
                    });
                    //                value = parseInt(value, 10);
                    //                if (value && value === trpItem['tradingPartnerID']) {
                    //                    this.serviceOfferingDetail.controls.tradingPartnerCode.setValue([{
                    //                        'id': value,
                    //                        'text': trpItem['tradingPartnerName']
                    //                    }]);
                    //                };
                };
                this.tradingPartnerList = tpList;
            }
        });
    }

    populateTradingPartner(code) {
        this.serviceOfferingDetail['controls']['tradingPartnerCode']['setValue'](code);
    }
    loadServiceLevels(value) {
        const params = {
            'financeBusinessUnitCode': this.orderData.financeBusinessUnitCode,
            'serviceOfferingCode': this.orderData.serviceOfferingCode
        };
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getservicelevels, params).subscribe(data => {
            const serviceLevelLists = data['_embedded']['serviceLevelBusinessUnitServiceOfferingAssociations'];
            this.serviceLevelList = [];
            for (const serLevel of serviceLevelLists) {
                this.serviceLevelList.push({
                    'id': serLevel.serviceLevel.serviceLevelCode,
                    'text': serLevel.serviceLevel.serviceLevelDescription
                });
                if (!this.jbhGlobals.utils.isEmpty(value) && value === serLevel.serviceLevel.serviceLevelCode) {
                    this.serviceOfferingDetail.controls.requestedServiceLevelCode.setValue([{
                        'id': value,
                        'text': serLevel.serviceLevel.serviceLevelDescription
                    }]);
                }
            }
        });
    }
    loadFreightChargeTerms(value) {
        const params = {
            'allowedValueType': 'FRGHT CHRG'
        };
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getfreightchargeterms, params).subscribe(data => {
            const freightChargeLists = data['_embedded']['freightChargeTerms'];
            this.freightChargeList = [];
            for (const freightcharge of freightChargeLists) {
                const obj = {
                    'id': freightcharge.freightCode.trim(),
                    'text': freightcharge.freightCode.trim()
                }
                this.freightChargeList.push(obj);
                if (!this.jbhGlobals.utils.isEmpty(value) && value === freightcharge.freightCode.trim()) {
                    this.serviceOfferingDetail.controls.freightChargeTermTypeCode.setValue([obj]);
                    this.onSelectFreightChargeTerms(obj, true);
                }
            }
        });
    }
    loadOperationalOwner(selectedOprOwner, booleanVal?: boolean) {
        const params = {
            'projectCode': selectedOprOwner
        };
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getoperationalowner, params, false).subscribe(data => {
            const operationalOwnerList = data['_embedded']['projects'];
            this.operationalOwnerListDescription = [];
            for (let i = 0; i < operationalOwnerList.length; i++) {
                this.operationalOwnerListDescription.push({
                    'code': operationalOwnerList[i]['projectCode'],
                    'description': operationalOwnerList[i]['projectDescription'].trim()
                });
				this.changeDetector.detectChanges();
                if (booleanVal && selectedOprOwner === operationalOwnerList[i]['projectCode'].trim()) {
                    this.serviceOfferingDetail['controls']['projectCode'].setValue(selectedOprOwner.trim());
                }
            }
        });
    }
    loadOperationalServices(array) {
        const params = {
            'businessUnit': this.orderData.financeBusinessUnitCode,
            'serviceOffering': this.orderData.serviceOfferingCode,
            'serviceCategoryCode': 'ReqServ'
        };
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getoperationalservices, params).subscribe(data => {
            this.operationalServicesList = data;
            this.operationalServicesListDescription = [];
            for (const operServ of this.operationalServicesList) {
                this.operationalServicesListDescription.push({
                    'id': operServ['serviceTypeCode'],
                    'text': operServ['serviceTypeDescription']
                });

                if (array) {
                    for (let i = 0; i < array.length; i++) {
                        if (array[i]['serviceType'] === operServ['serviceTypeCode']) {
                            this.orderserviceTag.active.push({
                                'id': array[i]['serviceType'],
                                'text': operServ['serviceTypeDescription']
                            });
                        }
                    }
                }
            }
        });
        if (array) {
            for (const i of array) {
                if (i['serviceType'] === 'OrgCusDray') {
                    this.orginCustomerDrayFlag = true;
                    const appStartDate: Date = new Date(i['serviceEstimatedTimestamp']);
                    this.serviceOfferingDetail['controls']['estimatedInGateDate'].setValue({
                        date: {
                            year: appStartDate.getFullYear(),
                            month: appStartDate.getMonth() + 1,
                            day: appStartDate.getDate() + 1
                        }
                    });
                }
            }
        }
    }
    onClickOpr() {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getOperationalOwnerIcon).subscribe(data => {
            this.operationalOwnerIconDetails = data;
        });
    }
    onMailing() {
        window.location.href = 'mailto:' + this.operationalOwnerIconDetails.emailAddress;
    }
    onCalling() {
        window.location.href = 'tel:' + this.operationalOwnerIconDetails.phoneNumber;
    }
    onChating() {
        window.location.href = 'sip:Justin.Horton@jbhunt.com';
    }
    ngSelectOnBlur(event, selectComponent) {
        const compName = selectComponent.element.nativeElement.id;
        if ((this.serviceOfferingDetail.get(compName).value === null ||
            this.serviceOfferingDetail.get(compName).value.length === 0) && event.innerText === '') {
            this.serviceOfferingDetail.get(compName).markAsTouched();
            if (this.serviceOfferingDetail.get('financeBusinessUnitCode').value.length > 0) {
                this.serviceOfferingDetail.get('serviceOfferingCode').setErrors(
                    compName === 'serviceOfferingCode' ? {
                        'mandatory': true
                    } : null);
            }
        }
    }
    onClearOrChangeBusinessUnit(booleanVal?: any) {
        this.serviceOfferingDetail.get('serviceOfferingCode').setValidators(
            booleanVal ? [] : [this.jbhGlobals.customValidator.mandatory]);
        this.serviceOfferingDetail.get('serviceOfferingCode').updateValueAndValidity();
        this.serviceOfferingDetail.get('serviceOfferingCode').setValue(null);
        this.serviceOfferingDetail.get('requestedServiceLevelCode').setValue(null);
        this.serviceOfferingDetail.controls.serviceOfferingCode.setValue('');
        this.serviceOfferingDetail.controls.requestedServiceLevelCode.setValue('');
        this.transitMode = '';
        this.orderData.serviceOfferingCode = null;
        this.orderData.transitModeCode = null;
        this.orderData.requestedServiceLevelCode = null;
        this.orderService.saveData(this.orderData);
        this.serviceOfferingList = [];
    }
    onSelectBusinessUnit(event, selectBoolean) {
        const selectedBusinessUnit = selectBoolean ? event.text : null;
        this.selectedBunit = selectedBusinessUnit;
        this.orderData.financeBusinessUnitCode = this.selectedBunit;
        this.onClearOrChangeBusinessUnit(selectBoolean ? false : true);
        if (selectBoolean) {
            this.loadServiceOfferingList(selectedBusinessUnit, null);
        }
        if (selectedBusinessUnit === 'ICS') {
            this.serviceOfferingDetail.get('projectCode').setValidators([Validators.required]);
        } else {
            this.serviceOfferingDetail.get('projectCode').setValidators([]);
        }
        this.serviceOfferingDetail.get('projectCode').updateValueAndValidity();
    }
    onSelectServiceOffering(event, selectBoolean) {
        const obj = this.transform(this.serviceOfferingArray, event.id)[0];
        this.selectedServiceOffering = selectBoolean ? event.id : null;
        this.transitMode = selectBoolean ? obj.transitModeCode : null;
        this.orderData.transitModeCode = selectBoolean ? this.transitMode : null;
        this.orderData.serviceOfferingCode = selectBoolean ? this.selectedServiceOffering : null;
        this.orderData.requestedServiceLevelCode = selectBoolean ? 'Standard' : null;
        this.orderService.saveData(this.orderData);
        if (selectBoolean) {
            this.loadServiceLevels('Standard');
            this.loadOperationalServices(null);
        }
    }
    onSelectServiceLevel(event, selectBoolean) {
        this.orderData.requestedServiceLevelCode = selectBoolean ? event.id : null;
        this.orderService.saveData(this.orderData);
    }
    onSelectFreightChargeTerms(event, selectBoolean) {
        if (this.jbhGlobals.utils.isArray(this.orderData.orderBillingDetailDTOs)) {
            if (this.orderData.orderBillingDetailDTOs.length === 0) {
                const freightObj = {
                    'freightChargeTermTypeCode': event.id
                };
                this.orderData.orderBillingDetailDTOs.push(selectBoolean ? freightObj : {});
            }
            this.orderData.orderBillingDetailDTOs[0].freightChargeTermTypeCode = selectBoolean ? event.id : null;
        } else {
            this.orderData.orderBillingDetailDTOs = [];
            const freightObj = {
                'freightChargeTermTypeCode': event.id
            };
            this.orderData.orderBillingDetailDTOs.push(selectBoolean ? freightObj : {});
        }
        this.orderService.saveData(this.orderData);
    }
    onSelectOperationalOwner(event) {
        this.oprOwnerValue = event.value.trim();
        this.isLoadOwnerListFlag = false;
        this.serviceOfferingDetail.controls.projectCode.setValue(event.item.description.trim());
        this.operationalOwnerListDescription = [];
        if (this.jbhGlobals.utils.isArray(this.orderData.orderOperationalElementDTOs)) {
            if (this.orderData.orderOperationalElementDTOs.length === 0) {
                const oprObj = {
                    'orderOperationalElement': {
                        'projectCode': ''
                    }
                };
                this.orderData.orderOperationalElementDTOs.push(oprObj);
            }
            this.orderData['orderOperationalElementDTOs'][0].orderOperationalElement.projectCode = this.oprOwnerValue;
        } else {
            this.orderData.orderOperationalElementDTOs = [];
            const oprObj = {
                'orderOperationalElement': {
                    'projectCode': this.oprOwnerValue
                }
            };
            this.orderData.orderOperationalElementDTOs.push(oprObj);
        }
        this.orderService.saveData(this.orderData);
    }
    onSelectOperationalService(event) {
        if (event.text === 'Limitation of Liability') {
            this.dollarInputRequired = true;
        }
        else if (event.text === 'Origin Customer Dray') {
            this.orginCustomerDrayFlag = true;
        }
        const oprServiceObj = this.oprTransform(this.operationalServicesList, event.id)[0];
        const OrderServicesObj = {
            'serviceCount': 1,
            'serviceLevelTypeCode': 'ORDER',
            'serviceType': oprServiceObj.serviceTypeCode,
            'serviceEstimatedTimestamp': '',
            'stopID': '',
            'unitOfServiceMeasurementCode': 'Hours',
            '@type': 'OrderService'
        };
        if (!this.orderData.orderServices) {
            this.orderData.orderServices = [];
        }
        this.orderData.orderServices.push(OrderServicesObj);
        if (this.serviceOfferingDetail.get('estimatedInGateDate')) {
            this.serviceOfferingDetail.get('estimatedInGateDate').setValidators([Validators.required]);
            this.serviceOfferingDetail.get('estimatedInGateDate').updateValueAndValidity();
        }
        this.orderService.saveData(this.orderData);
    }
    onRemoveOperationalService(event) {
        if (event.text === 'Limitation of Liability') {
            this.dollarInputRequired = false;
        }
        else if (event.text === 'Origin Customer Dray') {
            this.orginCustomerDrayFlag = false;
        }

        const oprServiceObj = this.oprTransform(this.operationalServicesList, event.id)[0];
        for (let i = 0; i < this.orderData.orderServices.length; i++) {
            if (this.orderData.orderServices[i].serviceType === oprServiceObj.serviceTypeCode) {
                this.orderData.orderServices.splice(i, 1);
            }
        }
        if (this.serviceOfferingDetail.get('estimatedInGateDate')) {
            this.serviceOfferingDetail.get('estimatedInGateDate').reset();
            this.serviceOfferingDetail.get('estimatedInGateDate').setValidators([]);
            this.serviceOfferingDetail.get('estimatedInGateDate').updateValueAndValidity();
        }
        this.orderService.saveData(this.orderData);
    }
    onStartDateChanged(event) {
        this.dateValue = event.formatted + ' ' + '00:00:00.0';
        for (let i = 0; i < this.orderData.orderServices.length; i++) {
            if (this.orderData.orderServices[i]['serviceType'] === 'OrgCusDray') {
                const dateFormatChange = moment(this.dateValue).format('YYYY-MM-DDTHH:mm:ss.000+00:00');
                this.orderData.orderServices[i]['serviceEstimatedTimestamp'] = dateFormatChange;
            }
        }
        this.serviceOfferingDetail.get('estimatedInGateDate').setValidators([]);
        this.serviceOfferingDetail.get('estimatedInGateDate').updateValueAndValidity();
    }
    transform(items: any[], args: string): any {
        return items.filter(item => item.serviceOfferingCode.toLowerCase().indexOf(args.toLowerCase()) !== -1);
    }
    oprTransform(items: any[], args: string): any {
        return items.filter(item => item.serviceTypeCode.toLowerCase().indexOf(args.toLowerCase()) !== -1);
    }
    onRemoveServiceTypes(items: any[], args: string): any {
        return items.filter(item => item.serviceTypeDescription.toLowerCase().indexOf(args.toLowerCase()) === -1);
    }
    saveScac(eve) {
        this.orderData.scac = eve.target.value;
        this.orderService.saveData(this.orderData);
    }
    saveTradingPartner(eve) {
        this.orderData.tradingPartnerCode = eve.item.code;
        this.orderService.saveData(this.orderData);
        this.selected = true;
    }
    onValidateForm() {
        const me = this;
        this.jbhGlobals.utils.forIn(this.serviceOfferingDetail.controls,
            function (value, name, object) {
                me.serviceOfferingDetail.controls[name].markAsTouched();
            });
    }
}
