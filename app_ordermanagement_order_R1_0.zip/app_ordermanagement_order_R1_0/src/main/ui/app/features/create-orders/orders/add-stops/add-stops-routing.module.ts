import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { TypeaheadModule } from 'app/shared/jbh-typeahead/typeahead.module';

import { AddStopsComponent } from './add-stops.component';

const routes: Routes = [{
     path: '', component: AddStopsComponent
    }];

@NgModule({
  imports: [
      TypeaheadModule.forRoot(),
      RouterModule.forChild(routes)
  ],
  exports: [RouterModule],
  providers: []
})

export class AddStopsRoutingModule { }
