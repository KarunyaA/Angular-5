export class StopResequenceModel {
    source: any;
    selectedItem: any;
    tempArray = [];
    sortedArray = [];
    appointmentDateTimeDetails: any;
    newStopIndex: any;
    tempAppointmentArray: any;
    tempAppointmentArray2: any;
    newSequenceNumber: any;
    subscriberFlag: any;
}
