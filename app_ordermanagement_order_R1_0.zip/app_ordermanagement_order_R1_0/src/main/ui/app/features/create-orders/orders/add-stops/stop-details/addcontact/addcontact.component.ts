import { Component, Input, OnDestroy, OnInit, ViewChild } from '@angular/core';
// import { ModalDirective } from 'ngx-bootstrap/modal';
import { FormControl, Validators } from '@angular/forms';
import { OrderFormBuilderService } from '../../../services/order-form-builder.service';
import { ActivatedRoute } from '@angular/router';
import { OrderService } from '../../../services/order.service';
import { JBHGlobals } from '../../../../../../app.service';

@Component({
  selector: 'app-addcontact',
  templateUrl: './addcontact.component.html',
  styleUrls: ['./addcontact.component.scss']
})
export class AddcontactComponent implements OnInit, OnDestroy {
  @ViewChild('autoShownModal') autoShownModal: any;
  @Input() contactDetails: any;
  preferredContact: any[] = [];
  subscription: any;
  orderData: any;
  stopData: any;
  orderdtoList: any;
  formValue: any;
  orderId: any;
  partyId: any;
  partyType: any;
  stopComponent: any;
  checkParams: any;
  myModel = '';
  mask = ['(', /[1-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];

  constructor(
    public jbhGlobals: JBHGlobals,
    public orderFormBuilder: OrderFormBuilderService,
    public orderService: OrderService,
    public route: ActivatedRoute) { }

  ngOnDestroy(): void {
    this.contactDetails.reset();
  }

  ngOnInit(): void {
    this.route.queryParams.subscribe(
      (queryParam: any) => {
        if (!this.jbhGlobals.utils.isEmpty(queryParam['id'])) {
          this.orderId = queryParam['id'];
        }
      });
    this.contactDetails = this.orderFormBuilder.orderForm['controls']['contactDetails'];
    const me = this;
    this.jbhGlobals.utils.forIn(this.contactDetails.controls, function (value, name, object) {
      (<FormControl>me.contactDetails.controls[name]).setValue('');
      me.contactDetails.controls[name].setErrors(null);
    });
    this.preferredContact.push({'id':'0','text':'Phone Number'},{'id':'1','text':'Email Id'});
  }

  showModal(stopComp): void {
    this.autoShownModal.show();
    this.stopComponent = stopComp;
  }

  hideModal(autoShownModal): void {
    this.autoShownModal.hide();

  }
  onChangeDropDown(value) {
    if (value === 'Phone Number') {
      this.contactDetails['controls']['email'].setValidators([]);
      this.contactDetails['controls']['email'].updateValueAndValidity({ onlySelf: true, emitEvent: false });
      this.contactDetails['controls']['phone'].setValidators([Validators.required]);
      this.contactDetails['controls']['phone'].updateValueAndValidity({ onlySelf: true, emitEvent: false });
    } else if (value === 'Email Id') {
      this.contactDetails['controls']['phone'].setValidators([]);
      this.contactDetails['controls']['phone'].updateValueAndValidity({ onlySelf: true, emitEvent: false });
      this.contactDetails['controls']['email'].setValidators([Validators.required,
      this.jbhGlobals.customValidator.emailValidator]);
      this.contactDetails['controls']['email'].updateValueAndValidity({ onlySelf: true, emitEvent: false });
    }
  }
  onsubmit(autoShownModal) {
    this.autoShownModal.hide();
    this.partyId = this.stopComponent.locationCode;
    this.partyType = this.stopComponent.reasonType
    this.formValue = this.contactDetails.value;
    const value = this.formValue.extn + '-' + this.formValue.phone;
    if (this.formValue.phone) {
      this.formValue.phone = this.formValue.phone.replace(/\(|\)/g, '').replace(/-/g, '').replace(/ /g, '');
      this.formValue.phone = this.formValue.phone.substr(0, 3) + '-' + this.formValue.phone.substr(3, );
      this.checkParams = {
        'contactMethod': 'TELEPHONE',
        'phoneNumber': this.formValue.phone,
        'extension': '044',
        'firstName': this.formValue.firstName,
        'lastName': this.formValue.lastName,
        'typeCode': 'Facility',
        'typeDescription': 'Facility'
      };
    } else
      if (this.formValue.email) {
        this.checkParams = {
          'contactMethod': 'EMAIL',
          'email': this.formValue.email,
          'extension': '044',
          'firstName': this.formValue.firstName,
          'lastName': this.formValue.lastName,
          'typeCode': 'Facility',
          'typeDescription': 'Facility'
        };
      }
    const uncheckParams = {
      'contactAddressLine1': null,
      'contactAddressLine2': null,
      'contactAddressStateCode': null,
      'contactAddressCityName': null,
      'contactAddressPostalCode': null,
      'contactPhoneNumber': this.formValue.phone,
      'contactPhoneNumberExtension': this.formValue.extn,
      'contactEmailAddress': this.formValue.email,
      'partyRoleCode': 'Facility',
      'partyID': null,
      'locationID': null,
      'contactFirstName': this.formValue.firstName,
      'contactMiddleName': null,
      'contactLastName': this.formValue.lastName,
      'preferredContactMethodType': null,
      'order': '/' + this.orderId

    }
    if (this.contactDetails.value.checkbox === true) {
      this.jbhGlobals.apiService.addData(this.jbhGlobals.endpoints.order.getlocaddcontactcheck + this.partyId + '/contacts/' +
        this.partyType, this.checkParams).subscribe(data => {
          this.jbhGlobals.notifications.success('Add Contact', 'Contact Saved.');
          this.stopComponent.onSelectContactType(this.stopComponent.locationCode, this.stopComponent.roleTypes);
          this.contactDetails.reset();
        }, (err: Error) => {
          console.log(err);
        });
    } else {
      this.jbhGlobals.apiService.addData(this.jbhGlobals.endpoints.order.getaddcontactUnCheck, uncheckParams).subscribe(data => {
        this.jbhGlobals.notifications.success('Add Uncheck Contact', 'Contact Saved.');
        this.stopComponent.onSelectContactType(this.stopComponent.locationCode, this.stopComponent.roleTypes);
        this.contactDetails.reset();
      });
      // getaddcontactUnCheck
    }
    //}
  }
}
