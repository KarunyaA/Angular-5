import { inject, TestBed } from '@angular/core/testing';

import { ReferenceUtilityService } from './reference-utility.service';

describe('CommentsUtilityService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ReferenceUtilityService]
    });
  });

  it('should be created', inject([ReferenceUtilityService], (service: ReferenceUtilityService) => {
    expect(service).toBeTruthy();
  }));
});
