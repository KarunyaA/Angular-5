// declare module namespace {

export interface InternationalOrderElement {
    bondType: string;
    bondHolder: string;
    portOfEntry: string;
    portOfExit: string;
    bondNumber: string;
    entryNumber: string;
    voyageNumber: string;
    vesselNumber: string;
    bondHolderCarrierName?: any;
    lastUpdateTimestampString: Date;
}

export interface OrderMonitorInformation {
    orderMonitorInformationID: number;
    destinationMonitorArea: string;
    originMonitorArea: string;
    lastUpdateTimestampString: Date;
}

export interface OrderOperationalElement {
    orderOperationalElementID: number;
    projectCode: string;
    fleetCode: string;
    lastUpdateTimestampString: Date;
}

export interface OrderFoodSafetyDetail {
    orderFoodSafetyDetailID: string;
}

export interface OrderRequestorDetail {
    orderRequestorDetailID: number;
    contactID: number;
    contactTypeCode: string;
    solicitorCode: string;
    lastUpdateTimestampString: Date;
}

export interface OrderBillingAdditionalInstruction {
    additionalInstructionId: string;
    additionalInstructionText: string;
    additionalInstructionType: string;
}

export interface OrderBillingDetail {
    orderBillingDetailID: number;
    autoRateIndicator: string;
    billToCode: string;
    contactID: number;
    contactTypeCode: string;
    freightChargeTermTypeCode: string;
    ratingCycleType: string;
    orderBillingAdditionalInstruction: OrderBillingAdditionalInstruction[];
}

export interface InternationalService {
    serviceID: string;
    serviceType: string;
    serviceCount: string;
    unitOfServiceMeasurementCode: string;
    serviceLevelTypeCode: string;
}

export interface OrderUnifiedCustomerRequestAssociation {
    orderUnifiedCustomerRequestAssociationID: string;
    unifiedCustomerRequestID: string;
}

export interface OrderAdditionalInstruction {
    additionalInstructionId: string;
    additionalInstructionText: string;
    additionalInstructionType: string;
}

export interface OrderCarrierDetail {
    orderCarrierDetailID: string;
    carrierName: string;
    carrierQuoteNumber: string;
    carrierBoothNumber: string;
}

export interface OrderStatusWorkflow {
    orderStatusWorkflowID: string;
    orderProgressStatusCode: string;
}

export interface OrderStatusEvent {
    orderStatusEventID: string;
    orderStatusEventComment: string;
    orderStatusEventReasonID: string;
}

export interface OrderMaterialHandlingRequirementAssociation {
    orderMaterialHandlingRequirementAssociationID: number;
    materialHandlingRequirementCode: string;
    materialHandlingRequirementQuantity: number;
    lastUpdateTimestampString: Date;
}

export interface OrderCharge {
    chargeID: number;
    chargeCode: string;
    chargeQuantity: number;
    chargeUnitCode: string;
    chargeUnitRateAmount: number;
    customerAuthorizationFirstName: string;
    customerAuthorizationLastName: string;
    customerAuthorizationNumber: string;
    chargeLevelTypeCode: string;
}

export interface OrderEquipmentRequirementFeatureAssociation {
    orderEquipmentRequirementFeatureAssociationID: number;
    equipmentClassificationTypeFeatureAssociationID: number;
    orderEquipmentRequirementFeatureValue: string;
}

export interface OrderNonCompanyEquipmentDetail {
    orderNonCompanyEquipmentDetailID: string;
    nonCompanyTrailerPrefix: string;
    nonCompanyTrailerNumber: string;
    nonCompanyChassisPrefix: string;
    nonCompanyChassisNumber: string;
    equipmentClassificationCode: string;
}

export interface OrderEquipmentRequirementSpecificationDetail {
    OrderEquipmentRequirementSpecificationDetailID: number;
    temperatureLowRange: number;
    temperatureHighRange: number;
    unitOfTemperatureMeasurementCode: string;
    specificationDetailValue: number;
    frontZonePrecoolTemperature: number;
    rearZonePrecoolTemperature: number;
}

export interface OrderEquipmentRequirementSpecificationAssociation {
    orderEquipmentRequirementSpecificationAssociationID: number;
    equipmentRequirementSpecificationAssociationID: number;
    equipmentRequirementSpecificationDetailID: number;
    orderEquipmentRequirementSpecificationDetails: OrderEquipmentRequirementSpecificationDetail[];
}

export interface OrderEquipmentRequirement {
    orderEquipmentRequirementID: number;
    equipmentID: number;
    equipmentClassificationTypeAssociationID: number;
    equipmentLengthRequiredIndicator: string;
    equipmentTypeRequiredIndicator: string;
    trailerPreloadedIndicator: string;
    orderEquipmentRequirementFeatureAssociations: OrderEquipmentRequirementFeatureAssociation[];
    OrderNonCompanyEquipmentDetails: OrderNonCompanyEquipmentDetail[];
    orderEquipmentRequirementSpecificationAssociations: OrderEquipmentRequirementSpecificationAssociation[];
}

export interface OrderFoodSafetyDetail2 {
    OrderEquipmentRequirementSpecificationDetailID: number;
    lastUpdateTimestampString?: any;
}

export interface OrderOperationalElement2 {
    projectCode?: any;
    fleetCode?: any;
    lastUpdateTimestampString?: any;
}

export interface OrderAssociatedParty {
    OrderAssociatedPartyID: number;
    partyCode: string;
    partyRoleCode: string;
}

export interface StopCharge {
    chargeID: string;
    chargeCode: string;
    chargeQuantity: number;
    chargeUnitCode: string;
    chargeUnitRateAmount: number;
    customerAuthorizationFirstName: string;
    customerAuthorizationLastName: string;
    customerAuthorizationNumber: string;
    chargeLevelTypeCode: string;
}

export interface StopComment {
    commentID: number;
    remark: string;
    commentTypeCode: string;
    location: string;
    commentLevelTypeCode: string;
}

export interface StopService {
    serviceID: number;
    serviceType: string;
    serviceCount: number;
    unitOfServiceMeasurementCode: string;
    serviceLevelTypeCode: string;
}

export interface ReferenceNumber {
    referenceNumberID: number;
    referenceNumberTypeCode: string;
    referenceNumberValue: string;
    referenceNumberLevelTypeCode: string;
}

export interface AssociatedReferenceNumber {
    referenceNumber: ReferenceNumber;
}

export interface StopReferenceNumber {
    referenceNumberID: number;
    referenceNumberTypeCode: string;
    referenceNumberValue: string;
    referenceNumberLevelTypeCode: string;
    associatedReferenceNumber: AssociatedReferenceNumber[];
}

export interface AppointmentDetail {
    appointmentDetailID: string;
    AppointmentSetReasonCode: string;
}

export interface AppointmentInstructionAssociation {
    appointmentInstructionAssociationID: string;
    appointmentInstruction: string;
    appointmentInstructionAdditionalDetail: string;
}

export interface AppointmentDateTimeDetail {
    appointmentDateTimeDetailID: string;
    appointmentStartTimestamp: string;
    appointmentEndTimestamp: string;
    primaryAppointmentIndicator: string;
}

export interface Appointment {
    appointmentID: string;
    appointmentTypeCode: string;
    appointmentConfirmationNumber: string;
    requestCallBackIndicator: string;
    recommendedAppointmentTimeStamp: string;
    appointmentInboundDate: string;
    appointmentDetails: AppointmentDetail[];
    appointmentInstructionAssociation: AppointmentInstructionAssociation[];
    appointmentDateTimeDetails: AppointmentDateTimeDetail[];
}

export interface ItemHandlingDetail {
    itemHandlingDetailID: string;
    itemHandlingTypeCode: string;
    itemHandlingTypeQuantity: string;
    itemHandlingUnitHeight: string;
    itemHandlingUnitLength: string;
    itemHandlingUnitWidth: string;
    unitOfLengthMeasurementCode: string;
    itemHandlingUnitVolume: string;
    unitOfVolumeMeasurementCode: string;
    itemHandlingUnitWeight: string;
    unitOfWeightMeasurementCode: string;
    itemHandlingUnitDensity: string;
    unitOfDensityMeasurementCode: string;
}

export interface StopItemHazardousMaterialDetail {
    stopItemHazardousMaterialDetailID: string;
    driverCertificationRequiredIndicator: string;
    emergencyResponsePhoneNumber: string;
    hazardousMaterialSpecificationID: string;
    providerContractNumber: string;
    unitOfWeightMeasurementCode: string;
    netExplosiveMassQuantity: string;
    limitedQuantityIndicator: string;
    reportableQuantityIndicator: string;
    hazardousMaterialTechnicalname: string;
}

export interface StopItemSerialNumberDetail {
    stopitemSerialNumberDetailID: string;
    stopItemSerialNumber: string;
}

export interface StopItemServiceDetail {
    stopItemServiceDetailID: string;
    itemServiceID: string;
    itemServiceTypeCode: string;
    itemServiceDescription: string;
    itemServiceQuantity: string;
}

export interface StopReferenceNumber2 {
    referenceNumberID: string;
    referenceNumberTypeCode: string;
    referenceNumberValue: string;
    referenceNumberLevelTypeCode: string;
}

export interface StopItemReferenceNumberAssociation {
    stopItemReferenceNumberAssociationID: string;
    stopReferenceNumber: StopReferenceNumber2[];
}

export interface StopItem {
    stopItemID: string;
    packagingUnitTypeQuantity: string;
    freightClassCode: string;
    itemDensity: string;
    itemDescription: string;
    itemHeight: string;
    itemLength: string;
    itemQuantity: string;
    itemLengthType: string;
    itemVolumeType: string;
    itemStackingType: string;
    itemVolume: string;
    itemWeight: string;
    itemWidth: string;
    nmfcNumber: string;
    packagingUnitTypeCode: string;
    skuNumber: string;
    unitOfLengthMeasurementCode: string;
    unitOfVolumeMeasurementCode: string;
    unitOfWeightMeasurementCode: string;
    unitOfDensityMeasurementCode: string;
    stopItemHazardousMaterialDetails: StopItemHazardousMaterialDetail[];
    itemModelNumber: string;
    itemExtremeLengthIndicator: string;
    itemClassificationCode: string;
    itemTemperatureControlMethodCode: string;
    supplierSKU: string;
    itemMake: string;
    itemManufacturer: string;
    itemCategory: string;
    itemPartNumber: string;
    ItemProtectionType: string;
    itemUniversalProductCode: string;
    stopItemSerialNumberDetail: StopItemSerialNumberDetail[];
    stopItemServiceDetail: StopItemServiceDetail[];
    StopItemReferenceNumberAssociation: StopItemReferenceNumberAssociation[];
}

export interface StopItemHandlingDetailAssociation {
    stopItemHandlingDetailAssociationID: string;
    itemHandlingDetail: ItemHandlingDetail;
    stopItem: StopItem;
}

export interface OrderReferenceNumber {
    referenceNumberID: number;
    referenceNumberTypeCode: string;
    referenceNumberValue: string;
    referenceNumberLevelTypeCode: string;
}

export interface OrderCrossBorderDetail {
    orderCrossBorderDetailID: string;
    clearanceCountryCode: string;
    customsBrokerCode: string;
}

export interface OrderService {
    serviceID: string;
    serviceType: string;
    serviceCount: number;
    unitOfServiceMeasurementCode: string;
    serviceLevelTypeCode: string;
}

export interface OrderComment {
    commentID: string;
    remark: string;
    commentTypeCode: string;
    location: string;
    commentLevelTypeCode: string;
}

export interface OrderOwnership {
    taskAssignmentID: string;
    backupTaskAssignmentID: string;
    appointmentID: string;
    effectiveTimestamp?: string;
    expirationTimestamp?: string;
}

export interface Stop {
    stopID: string;
    locationCode: string;
    locationContactID: string;
    locationContactType: string;
    highCostDeliveryIndicator: string;
    stopReason: string;
    stopSequenceNumber: string;
    totalStopWeight: string;
    unitOfWeightMeasurementCode: string;
    initialOfferedDate: string;
    stopCharges: StopCharge[];
    stopComments: StopComment[];
    stopServices: StopService[];
    stopReferenceNumbers: StopReferenceNumber[];
    appointment: Appointment[];
    stopItemHandlingDetailAssociation: StopItemHandlingDetailAssociation[];
    orderReferenceNumbers: OrderReferenceNumber[];
    orderServices: OrderService[];
    orderComments: OrderComment[];
}

export interface IOrderEntityModel {
    orderID: number;
    customerID: number;
    serviceOfferingCode: string;
    requestedServiceLevelCode?: any;
    servicePriorityTypeCode: string;
    transitModeCode: string;
    financeBusinessUnitCode: string;
    orderSourceCode: string;
    orderStatusCode: string;
    inits: string;
    orderTypeCode: string;
    orderSubTypeCode: string;
    orderGroupingID: number;
    orderTrackingNumber: string;
    orderValueAmount: number;
    orderRefrigeratedIndicator: string;
    internationalOrderElement: InternationalOrderElement[];
    orderMonitorInformations: OrderMonitorInformation[];
    orderOperationalElement: OrderOperationalElement[];
    OrderFoodSafetyDetail: OrderFoodSafetyDetail[];
    orderRequestorDetail: OrderRequestorDetail[];
    orderBillingDetail: OrderBillingDetail[];
    internationalServices: InternationalService[];
    orderUnifiedCustomerRequestAssociations: OrderUnifiedCustomerRequestAssociation[];
    orderAdditionalInstructions: OrderAdditionalInstruction[];
    orderCarrierDetails: OrderCarrierDetail[];
    orderStatusWorkflows: OrderStatusWorkflow[];
    orderStatusEvents: OrderStatusEvent[];
    orderMaterialHandlingRequirementAssociations: OrderMaterialHandlingRequirementAssociation[];
    orderValueTypeCode: string;
    orderVolumeTypeCode: string;
    shipmentIdentificationNumber: string;
    orderCharges: OrderCharge[];
    orderEquipmentRequirement: OrderEquipmentRequirement[];
    orderFoodSafetyDetails: OrderFoodSafetyDetail2[];
    orderOperationalElements: OrderOperationalElement2[];
    orderAssociatedParties: OrderAssociatedParty[];
    orderCrossBorderDetails: OrderCrossBorderDetail[];
    orderOwnership: OrderOwnership[];
    stops: Stop[];
}

// }
