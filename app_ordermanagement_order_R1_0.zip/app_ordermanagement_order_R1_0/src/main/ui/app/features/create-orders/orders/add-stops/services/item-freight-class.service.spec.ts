import { inject, TestBed } from '@angular/core/testing';

import { ItemFreightClassService } from './item-freight-class.service';

describe('ItemFreightClassService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ItemFreightClassService]
    });
  });

  it('should be created', inject([ItemFreightClassService], (service: ItemFreightClassService) => {
    expect(service).toBeTruthy();
  }));
});
