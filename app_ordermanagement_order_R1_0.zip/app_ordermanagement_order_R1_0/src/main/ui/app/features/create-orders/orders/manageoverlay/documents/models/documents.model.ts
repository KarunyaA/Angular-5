export class DocumentsModel {
    // @ViewChild('duplicateDocumentModal') duplicateDocumentModal: any;
    // public orderData: any;
     orderId: any;
     documentTypeList: any[];
     documentDetails: any;
     getFile: any;
     fileLength: any;
     fileName: any;
     ListDataLoaded: any = false;
     fileExtension: any;
     documentTypeErrorFlag = false;
     searchFileErrorFlag = false;
     selectDocumentType: any;
     documentDetailsFindAll: any;
     listLoaded = false;
     selectItems: any ;
}
