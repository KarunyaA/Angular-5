import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RouterTestingModule } from '@angular/router/testing';

import { AppModule } from '../../../../../../app.module';
import { CreateOrdersModule } from '../../../../create-orders.module';
import { OrdersModule } from '../../../orders.module';
import { AddStopsModule } from '../../add-stops.module';

import { AddcontactComponent } from './addcontact.component';

describe('AddcontactComponent', () => {
  let component: AddcontactComponent;
  let fixture: ComponentFixture<AddcontactComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
          AppModule,
          RouterTestingModule,
          CreateOrdersModule,
          AddStopsModule,
          OrdersModule
       ],
      declarations: [  ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddcontactComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
