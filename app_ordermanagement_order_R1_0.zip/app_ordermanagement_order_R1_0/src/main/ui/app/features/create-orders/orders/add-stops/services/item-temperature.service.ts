import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { JBHGlobals } from 'app/app.service';

@Injectable()
export class ItemTemperatureService {
  sharingData: BehaviorSubject < any[] > ;

  constructor(public jbhGlobals: JBHGlobals) {
        this.sharingData = < BehaviorSubject < any[] >> new BehaviorSubject([]);
        this.init();
  }

  init(): void {
     this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getItemTemperatureControl).subscribe(data => {
            this.saveData(data['_embedded']['itemTemperatureControlMethods']);
     });
  }
  saveData(data): void {
       this.sharingData.next(data);
  }
  getData() {
      return this.sharingData.asObservable();
  }
}
