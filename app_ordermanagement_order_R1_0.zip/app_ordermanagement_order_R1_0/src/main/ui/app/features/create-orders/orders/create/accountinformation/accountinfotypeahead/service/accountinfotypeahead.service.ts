import {
    Injectable
} from '@angular/core';
import {
    Observable
} from 'rxjs/Observable';
import {
    Response
} from '@angular/http';

import {
    JBHGlobals
} from '../../../../../../../app.service';

@Injectable()
export class AccountinfotypeaheadService {
    constructor(private jbhGlobals: JBHGlobals) { }

    getTypeaheadList(typeaheadurl, params): Observable<Response[]> {
        return this.jbhGlobals.apiService
            .addData(typeaheadurl, params, false);
    }
    getContactList(contacturl, params): Observable<Response[]> {
        return this.jbhGlobals.apiService
            .getData(contacturl, params, true);
    }
    getOutSourcingFlag(outsourceUrl, params): Observable<Response[]> {
        return this.jbhGlobals.apiService
            .getData(outsourceUrl, params);
    }
    getCreditStatus(url): Observable<Response[]> {
        return this.jbhGlobals.apiService
            .getData(url);
    }
    getAccountRolesList(accountRolesUrl): Observable<Response[]> {
        return this.jbhGlobals.apiService
            .getData(accountRolesUrl);
    }
    getCustomerIdService(url, params): Observable<Response[]> {
        return this.jbhGlobals.apiService
            .getData(url, params);
    }
}
