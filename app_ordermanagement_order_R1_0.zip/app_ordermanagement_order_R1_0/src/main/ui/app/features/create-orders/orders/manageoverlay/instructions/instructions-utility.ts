import {
    FormBuilder,
    FormControl,
    FormGroup,
    Validators
} from '@angular/forms';

export class InstructionsUtility {
    static onInstructionSave(instructionsComponent) {
        if (instructionsComponent.instructionsModel.innerHtmlIns.length > 50) {
            if (instructionsComponent.instructionsModel.editCall === false) {
                if (instructionsComponent.instructionsModel.currentPage !== 'vieworder') {
                    const obj = {
                        instDesc: null,
                        instrTagInst: null,
                        lastUpdateTimestampString: null
                    };
                    obj.instDesc = instructionsComponent.addInstructionDetail.value.instDesc;
                    obj.instrTagInst = instructionsComponent.addInstructionDetail.value.instrTagInst[0].id;
                    obj.lastUpdateTimestampString = new Date();
                    instructionsComponent.instructionsModel.instructionObj = {
                        'additionalInstructionText': instructionsComponent.addInstructionDetail.value.instDesc,
                        'additionalInstructionId': '',
                        'additionalInstructionType': instructionsComponent.addInstructionDetail.value.instrTagInst[0].id,
                        'order': '/' + instructionsComponent.instructionsModel.orderData['orderID'],
                        'orderBillingDetail': '',
                        'stop': '',
                        'orderEquipmentRequirement': '',
                        'lastUpdateTimestampString': ''
                    };
                    instructionsComponent.saveServiceInstruction(instructionsComponent.instructionsModel.instructionObj, false); // from add
                } else if (instructionsComponent.instructionsModel.currentPage === 'vieworder') {
                    const obj = {
                        instDesc: null,
                        instrTagInst: null,
                        lastUpdateTimestampString: null
                    };
                    obj.instDesc = instructionsComponent.addInstructionDetail.value.instDesc;
                    obj.instrTagInst = instructionsComponent.addInstructionDetail.value.instrTagInst[0].id;
                    obj.lastUpdateTimestampString = new Date();
                    instructionsComponent.instructionObj = {
                        'additionalInstructionId': null,
                        'additionalInstructionText': instructionsComponent.addInstructionDetail.value.instDesc,
                        'additionalInstructionType': instructionsComponent.addInstructionDetail.value.instrTagInst[0].id,
                        'orderBillingDetail': null,
                        'stop': null,
                        'order': null,
                        'orderEquipmentRequirement': null,
                        'lastUpdateTimestampString': null
                    };
                    instructionsComponent.viewEditSaveInstruction(instructionsComponent.instructionObj, false);
                }
            } else {
                if (instructionsComponent.instructionsModel.editIns.additionalInstructionText &&
                    instructionsComponent.instructionsModel.editIns.additionalInstructionType ||
                    instructionsComponent.addInstructionDetail.value.instrTagInst[0].text) {

                    if (instructionsComponent.instructionsModel.currentPage !== 'vieworder') {
                        const obj = {
                            instDesc: null,
                            instrTagInst: null,
                            lastUpdateTimestampString: null
                        };
                        obj.instDesc = instructionsComponent.addInstructionDetail.value.instDesc;
                        obj.instrTagInst = instructionsComponent.additionTagInstruction._active[0].text;
                        obj.lastUpdateTimestampString = new Date().toLocaleString();
                        const instructionObj = {
                            'additionalInstructionText': instructionsComponent.addInstructionDetail.value.instDesc,
                            'additionalInstructionId': instructionsComponent.addInstructionDetail.value.additionalInstructionId,
                            'additionalInstructionType': instructionsComponent.additionTagInstruction._active[0].text,
                            'order': '/' + instructionsComponent.instructionsModel.orderData['orderID'],
                            'orderBillingDetail': '',
                            'stop': '',
                            'orderEquipmentRequirement': '',
                            'lastUpdateTimestampString': ''

                        };
                        instructionsComponent.saveServiceInstruction(instructionObj, true); // from edit
                    } else if (instructionsComponent.instructionsModel.currentPage === 'vieworder') {
                        const obj = {
                            instDesc: null,
                            instrTagInst: null,
                            lastUpdateTimestampString: null
                        };
                        obj.instDesc = instructionsComponent.addInstructionDetail.value.instDesc;
                        obj.instrTagInst = instructionsComponent.additionTagInstruction._active[0].text;
                        obj.lastUpdateTimestampString = new Date().toLocaleString();
                        instructionsComponent.instructionsModel.instructionObj = {
                            'additionalInstructionText': instructionsComponent.addInstructionDetail.value.instDesc
                        };
                        instructionsComponent.viewEditSaveInstruction(instructionsComponent.instructionsModel.instructionObj, true);
                    }

                } else {
                    instructionsComponent.jbhGlobals.notifications.error('Error', 'Please fill all the fields');
                    return false;
                }
            }

        } else {
            instructionsComponent.jbhGlobals.notifications.error('Error', 'Please enter more than 50 characters');
            return false;
        }
    }

    static addInstructionFormBuilder(instructionsComponent) {
        instructionsComponent.addInstructionDetail = instructionsComponent.formBuilder.group({
            'instDesc': ['', Validators.compose([Validators.required,
                instructionsComponent.jbhGlobals.customValidator.maxminLengthValidator
            ])],
            'instrTagInst': ['', Validators.required],
            'additionalInstructionId': '',
            'lastUpdateTimestampString': ''

        });
    }
    static saveServiceInstruction(instructionObj, fromEditflag, instructionsComponent) {
        switch (instructionObj.additionalInstructionType) {
            case 'Order':
                {
                    instructionObj['order'] = '/' + instructionsComponent.instructionsModel.orderData.orderID;
                    instructionsComponent.instructionsModel.showEditInsBtn = false;
                    instructionsComponent.instructionsModel.showdelInsBtn = false;
                    instructionsComponent.addInstructionDetail.reset();
                    instructionsComponent.instructionsModel.innerHtmlIns = '';
                    if (!fromEditflag) {
                        instructionsComponent.onAdditionalInstruction(instructionsComponent.instructionsModel.instructionObj); // on add
                    } else {
                        instructionsComponent.onupdateInstruction(instructionObj); // on edit
                    }
                    break;
                }
            case 'Billing & Rating':
                {
                    instructionObj['order'] = '/' + instructionsComponent.instructionsModel.orderData.orderID;
                    instructionObj['orderBillingDetail'] =
                    instructionsComponent.instructionsModel.orderData['orderBillingDetailDTOs'][0]['orderBillingDetailID'];
                    instructionsComponent.instructionsModel.showEditInsBtn = false;
                    instructionsComponent.instructionsModel.showdelInsBtn = false;
                    instructionsComponent.addInstructionDetail.reset();
                    instructionsComponent.instructionsModel.innerHtmlIns = '';
                    if (!fromEditflag) {
                        instructionsComponent.onAdditionalInstruction(instructionsComponent.instructionsModel.instructionObj);
                    } else {
                        instructionsComponent.onupdateInstruction(instructionObj); // on edit
                    }
                    break;
                }
            case 'Equipment':
                {
                    instructionObj['order'] = '/' + instructionsComponent.instructionsModel.orderData.orderID;
                    instructionObj['orderEquipmentRequirement'] = '/' +
                    instructionsComponent.instructionsModel.orderData['orderEquipmentRequirementDTOs'][0]['orderEquipmentRequirement']
                    ['orderEquipmentRequirementID'];
                    instructionsComponent.instructionsModel.showEditInsBtn = false;
                    instructionsComponent.instructionsModel.showdelInsBtn = false;
                    instructionsComponent.addInstructionDetail.reset();
                    instructionsComponent.instructionsModel.innerHtmlIns = '';
                    if (!fromEditflag) {
                        instructionsComponent.onAdditionalInstruction(instructionsComponent.instructionsModel.instructionObj);
                    } else {
                        instructionsComponent.onupdateInstruction(instructionObj); // on edit
                    }
                    break;
                }
            default:
                if (instructionsComponent.additionTagInstruction && instructionsComponent.additionTagInstruction.active) {
                    const stopTag = instructionsComponent.additionTagInstruction.active[0].id;
                    instructionsComponent.instructionsModel.stopUniqueId =
                        instructionsComponent.additionTagInstruction.active[0].id.substring(stopTag.length, stopTag.length - 1);
                    if (instructionsComponent.instructionsModel.stopUniqueId &&
                        instructionsComponent.instructionsModel.instructionStopData &&
                        instructionsComponent.instructionsModel.instructionStopData.length !== 0) {

                        for (let i = 0; i < instructionsComponent.instructionsModel.instructionStopData.length; i++) {
                            if (instructionsComponent.instructionsModel.instructionStopData[i].stop.stopSequenceNumber !== null &&
                                instructionsComponent.instructionsModel.instructionStopData[i].stop.stopID !== '' &&
                                instructionsComponent.instructionsModel.instructionStopData[i].stop.stopSequenceNumber.toString() ===
                                instructionsComponent.instructionsModel.stopUniqueId) {
                                instructionsComponent.instructionsModel.stopServiceId =
                            instructionsComponent.instructionsModel.instructionStopData[i].stop.stopID;
                            }

                        }
                    }
                }
                instructionObj['stop'] = '/' + instructionsComponent.instructionsModel.stopServiceId;
                instructionsComponent.instructionsModel.showEditInsBtn = false;
                instructionsComponent.instructionsModel.showdelInsBtn = false;
                instructionsComponent.addInstructionDetail.reset();
                instructionsComponent.instructionsModel.innerHtmlIns = '';
                if (!fromEditflag) {
                    instructionsComponent.onAdditionalInstruction(instructionsComponent.instructionsModel.instructionObj);
                } else {
                    instructionsComponent.onupdateInstruction(instructionObj); // on edit
                }
        }

    }

    static viewEditSaveInstruction(instructionObj, fromEditflag, instructionsComponent) {
        switch (instructionObj.additionalInstructionType) {
            case 'Order':
                {
                    instructionsComponent.instructionsModel.showEditInsBtn = false;
                    instructionsComponent.instructionsModel.showdelInsBtn = false;
                    instructionsComponent.addInstructionDetail.reset();
                    instructionsComponent.instructionsModel.innerHtmlIns = '';
                    if (!fromEditflag) {
                        instructionsComponent.onViewAdditionalInstruction(instructionObj); // on add
                    } else {
                        instructionsComponent.onViewUpdateInstruction(instructionObj); // on edit
                    }
                    break;
                }
            case 'Billing & Rating':
                {
                    instructionsComponent.instructionsModel.showEditInsBtn = false;
                    instructionsComponent.instructionsModel.showdelInsBtn = false;
                    instructionsComponent.addInstructionDetail.reset();
                    instructionsComponent.instructionsModel.innerHtmlIns = '';
                    if (!fromEditflag) {
                        instructionsComponent.onViewAdditionalInstruction(instructionObj);
                    } else {
                        instructionsComponent.onViewUpdateInstruction(instructionObj); // on edit
                    }
                    break;
                }
            case 'Equipment':
                {
                    instructionsComponent.instructionsModel.showEditInsBtn = false;
                    instructionsComponent.instructionsModel.showdelInsBtn = false;
                    instructionsComponent.addInstructionDetail.reset();
                    instructionsComponent.instructionsModel.innerHtmlIns = '';
                    if (!fromEditflag) {
                        instructionsComponent.onViewAdditionalInstruction(instructionObj);
                    } else {
                        instructionsComponent.onViewUpdateInstruction(instructionObj); // on edit
                    }
                    break;
                }
            default:
                instructionsComponent.instructionsModel.showEditInsBtn = false;
                instructionsComponent.instructionsModel.showdelInsBtn = false;
                instructionsComponent.addInstructionDetail.reset();
                instructionsComponent.instructionsModel.innerHtmlIns = '';
                if (!fromEditflag) {
                    instructionsComponent.onViewAdditionalInstruction(instructionObj);
                } else {
                    instructionsComponent.onViewUpdateInstruction(instructionObj); // on edit
                }
        }
    }
}
