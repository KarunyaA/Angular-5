import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Response } from '@angular/http';
import { JBHGlobals } from '../../../../../../app.service';

@Injectable()
export class DocumentsService {

  constructor(private jbhGlobals: JBHGlobals) { }
 getDocumentTypesList(documentsUrl): Observable < Response[] > {
        return this.jbhGlobals.apiService
            .getData(documentsUrl);
    }
 //    SaveComments(commentsUrl, params): Observable < Response[] > {
 //        return this.jbhGlobals.apiService
 //            .addData(commentsUrl, params);
 //    }

}
