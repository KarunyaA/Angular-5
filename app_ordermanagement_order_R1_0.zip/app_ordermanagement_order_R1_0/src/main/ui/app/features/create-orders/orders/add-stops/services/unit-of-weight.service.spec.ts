import { inject, TestBed } from '@angular/core/testing';

import { UnitOfWeightService } from './unit-of-weight.service';

describe('UnitOfWeightService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [UnitOfWeightService]
    });
  });

  it('should be created', inject([UnitOfWeightService], (service: UnitOfWeightService) => {
    expect(service).toBeTruthy();
  }));
});
