import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { JBHGlobals } from '../../../../../app.service';
import { DocumentsModel } from './models/documents.model';
import { DocumentsService } from './services/documents.service';

@Component({
    selector: 'app-documents',
    templateUrl: './documents.component.html',
    styleUrls: ['./documents.component.scss', '../instructions/instructions.component.scss'],
    providers: [DocumentsService]
})

export class DocumentsComponent implements OnInit {
    // tslint:disable:member-access
    addDocumentDetail: FormGroup;
    documentsModel: DocumentsModel;
    // public initFlag = true;
    @ViewChild('fileSearch') fileSearch: ElementRef;
    @ViewChild('popInstance') popInstance: any;

    constructor(public formBuilder: FormBuilder, public jbhGlobals: JBHGlobals, public route: ActivatedRoute,
                public documentsService: DocumentsService) { }

    ngOnInit(): void {
        this.documentsModel = new DocumentsModel();
        this.addDocumentFormBuilder();
    }

    documentTabClick() {
        this.getDocumentType();
        this.route.queryParams.subscribe(
            (queryParam: any) => {
                if (!this.jbhGlobals.utils.isEmpty(queryParam['id'])) {
                    this.documentsModel.orderId = queryParam['id'];
                    this.getDocumentdetails();
                }
            });
    }

    addDocumentFormBuilder() {
        this.addDocumentDetail = this.formBuilder.group({
            'fileText': ['', Validators.required],
            'fileType': ['', Validators.required],
            'fileSearchName': ['']
        });
    }

    getDocumentType() {
        this.documentsService.getDocumentTypesList(this.jbhGlobals.endpoints.order.getDocumenttypes).subscribe(data => {
            this.documentsModel.documentTypeList = [];
            for (const i of Object.keys(data)) {
                this.documentsModel.documentTypeList.push({
                    'id': data[i],
                    'text': i
                });
            }
            // this.documentsModel.documentTypeList = Object.keys(data);
        });
    }
    getDocumentdetails() {
        const url = this.jbhGlobals.endpoints.order.getDocumentDetails + '' + this.documentsModel.orderId + '/findall';
        this.jbhGlobals.apiService.getData(url).subscribe(data => {
            this.documentsModel.documentDetailsFindAll = data;
            if (!this.jbhGlobals.utils.isEmpty(this.documentsModel.documentDetailsFindAll)) {
                this.documentsModel.ListDataLoaded = true;
                this.documentsModel.listLoaded = true; // List Loaded Flag
            }
        });
    }

    documentFlag(event, selectItems) {
        this.documentsModel.documentTypeErrorFlag = false;
        this.documentsModel.selectItems = selectItems;
    }

    onClickOfBrowseFile(fileSearch) {
        fileSearch.click();
    }

    searchFlag() {
        this.documentsModel.searchFileErrorFlag = false;
    }

    onSelectFile(event) {
        this.documentsModel.getFile = event.target.value.split('\\');
        this.documentsModel.fileLength = this.documentsModel.getFile.length - 1;
        this.documentsModel.fileName = this.documentsModel.getFile[this.documentsModel.fileLength];
        this.addDocumentDetail['controls']['fileText'].setValue(this.documentsModel.fileName);
    }

    onClickSaveDocument(selectDocumentType) {
        this.documentsModel.selectDocumentType = selectDocumentType.activeOption.id;
        if (this.documentsModel.fileName && selectDocumentType.active.length > 0) {
            this.documentsModel.fileExtension = this.documentsModel.fileName.substr(this.documentsModel.fileName.lastIndexOf('.') + 1);
            // if (this.fileExtension === 'jpg' || this.fileExtension === 'zip' || this.fileExtension === 'doc' ||
            //     this.fileExtension === 'gif' || this.fileExtension === 'pdf' || this.fileExtension === 'docx'
            // ) {
            // this.ignoreDuplicate();
            this.calculateByteArray();
            // } else {
            //     this.jbhGlobals.notifications.error('Invalid', 'Please choose a valid Document.');
            // }
            selectDocumentType.active = []; // resetting form field
            this.addDocumentDetail['controls']['fileText'].setValue(''); // resetting form field
            this.resetFileName();
            // const obj = {
            //   'documentID': '{9540EDCD-0620-41DB-9E34-005EEEFA7FFA}',
            //   'fileName' : this.fileName,
            //   'fileFormat' : null,
            //   'fileContent' : null,
            //   'documentType' : this.fileExtension,
            //   'documentClass' : null,
            //   'documentVersion' : '1',
            //   'orderID' : 1,
            //   'loadNumber' : null,
            //   'lastUpdateUserId' : 'jcon741',
            //   'lastUpdateTimestamp' : [2017, 5, 2, 14, 59, 5, 203000000]
            // };
            // this.documentDetails.push(obj);
        } else if (selectDocumentType.active.length <= 0) {
            if (!this.documentsModel.fileName) {
                this.documentsModel.searchFileErrorFlag = true;
                this.documentsModel.documentTypeErrorFlag = true;
            } else {
                this.documentsModel.documentTypeErrorFlag = true;
            }
        } else if (!this.documentsModel.fileName) {
            this.documentsModel.searchFileErrorFlag = true;
        } else { }
    }
    onDelete(eve) {
        if (eve.flag) {
            this.documentsModel.selectItems.active = [];
            this.addDocumentDetail['controls']['fileText'].setValue(''); // resetting form field
            this.addDocumentDetail['controls']['fileSearchName'].setValue('');
            eve.model.hide();
        } else {
            document.querySelector('body').removeChild(this.popInstance.deleteButtonModal._element.nativeElement);
            eve.model.hide();
        }
    }
    onCancel() {
        document.querySelector('body').appendChild(this.popInstance.deleteButtonModal._element.nativeElement);
        this.popInstance.deleteButtonModal.show();
    }

    calculateByteArray() {
        // const formData: FormData = new FormData();
        // let files = this.fileSearch.nativeElement.files[0];
        // formData.append('',files);
        // console.log(formData);
        // this.saveDocument(formData);
        const me = this;
        let byteArray;
        /*let files = this.fileSearch.nativeElement.files;
        this.fileData = new Blob([this.fileSearch.nativeElement.files[0]]);*/
        const reader = new FileReader();
        reader.readAsArrayBuffer(new Blob([this.fileSearch.nativeElement.files[0]]));
        reader.onload = function () {
            const arrayBuffer = reader.result;
            byteArray = new Uint8Array(arrayBuffer);
            if (byteArray) {
                me.saveDocument(byteArray);
            }
        };
    }

    saveDocument(byteArray) {
        const convertedarray = Array.from(byteArray);
        console.log(this.documentsModel.selectDocumentType);
        if (this.documentsModel.fileName && this.documentsModel.fileExtension &&
            this.documentsModel.selectDocumentType && this.documentsModel.orderId) {
            const params = {
                'fileName': this.documentsModel.fileName,
                'fileFormat': this.documentsModel.fileExtension,
                'documentType': 'ORDER',
                'fileContent': convertedarray,
                'documentClass': this.documentsModel.selectDocumentType,
                'orderID': this.documentsModel.orderId
            };
            // console.log(convertedarray);
            console.log(params);
            this.jbhGlobals.apiService.addData(this.jbhGlobals.endpoints.order.saveDocumentDetails, params)
                .subscribe(data => {
                    if (data) {
                        this.jbhGlobals.notifications.success('Success',
                            'Document is successfully uploaded.');
                        this.documentsModel.documentDetails = data;
                        this.getDocumentdetails();
                        console.log(this.documentsModel.documentDetailsFindAll);
                        this.documentsModel.fileName = '';
                    }
                });
        } else {
            console.log('Empty parameters');
        }
    }

    // public ignoreDuplicate() {
    //         const orderid: any = parseInt(this.orderId);
    //        for (let i = 0; i < this.documentDetailsFindAll.length; i++) {
    //            if (this.fileName === this.documentDetailsFindAll[i].fileName &&
    //                orderid === this.documentDetailsFindAll[i].orderID) {
    //                this.duplicateFlag = false;
    //                alert();
    //                  // this.duplicatedocumentmodal.show();
    //            }
    //        }
    //    }
    resetFileName() {
        this.addDocumentDetail['controls']['fileSearchName'].setValue('');
    }
}
