import {
    OrderFormBuilderService
} from '../../services/order-form-builder.service';
import {
    Component,
    OnInit,
    ViewChild
} from '@angular/core';
import {
    OrderService
} from '../../services/order.service';
import {
    JBHGlobals
} from '../../../../../app.service';
import {
    StopSharedDataService
} from '../../../orders/add-stops/services/stop-shared-data.service';
import {
    OrdersComponent
} from '../../orders.component';
import {
    FormBuilder,
    FormControl,
    FormGroup,
    Validators
} from '@angular/forms';
import {
    ViewOrderService
} from '../../../../view-order/services/view-order.service';
import {
    Router
} from '@angular/router';
import {
    ActivatedRoute
} from '@angular/router';
import {
    InstructionsModel
} from './models/instructions.model';
import {
    InstructionsService
} from './services/instructions.service';
import {
    InstructionsUtility
} from './instructions-utility';

@Component({
    selector: 'app-instructions',
    templateUrl: './instructions.component.html',
    providers: [InstructionsService],
    styleUrls: ['./instructions.component.scss', '../comments/comments.component.scss']
})
export class InstructionsComponent implements OnInit {
    instructionsModel: InstructionsModel;
    @ViewChild('additionInstructionKey') additionInstructionKey: any;
    @ViewChild('additionTagInstruction') additionTagInstruction: any;
    addInstructionDetail: FormGroup;
    instructionTagInput: string[] = ['Order'];
    constructor(
        public formBuilder: FormBuilder,
        public orderService: OrderService,
        public jbhGlobals: JBHGlobals,
        public stopSharedDataService: StopSharedDataService,
        public orderFormBuilder: OrderFormBuilderService,
        public ordersComponent: OrdersComponent,
        public router: Router, public route: ActivatedRoute,
        public viewOrderService: ViewOrderService,
        private instructionsService: InstructionsService) { }

    ngOnInit(): void {
        this.instructionsModel = new InstructionsModel(); // Model instance
        this.addInstructionFormBuilder();
        this.getDataService();
        this.stopSharedDataService.getData().subscribe(data => {
            if (!this.jbhGlobals.utils.isEmpty(data)) {
                if (data[0].action === 'add') {
                    this.instructionsModel.instructionStopData = data[0].data;
                    this.stopInstructionTag();
                }
            };

        });
        this.instructionTabClick();
        this.instructionsModel.currentPage = this.router.url.split('?')[0].substring(1, this.router
            .url.length).toString().toLowerCase();

        this.route.queryParams.subscribe(
            (queryParam: any) => {
                if (!this.jbhGlobals.utils.isEmpty(queryParam['id'])) {
                    this.instructionsModel.orderId = Number(queryParam['id']);
                };
            });
    }
    instructionTabClick() {
        if (this.jbhGlobals.utils.isEmpty(this.instructionsModel.orderData)) {
            this.instructionsModel.subscription = this.orderService.getData().subscribe(sharedOrderData => {
                this.instructionsModel.orderData = sharedOrderData;
                if (!this.jbhGlobals.utils.isEmpty(this.instructionsModel.orderData) && this.instructionsModel.orderData.length !== 0) {
                    this.billingInstructionTag();
                    this.equipmentInstructionTag();
                }
            });
        }
    }

    stopInstructionTag() {

        if (this.instructionsModel.instructionStopData && this.instructionsModel.instructionStopData.length !== 0) {
            for (let i = 0; i < this.instructionsModel.instructionStopData.length; i++) {
                if (this.instructionsModel.instructionStopData[i].stop.stopID !== null &&
                    this.instructionsModel.instructionStopData[i].stop.stopID !== '') {
                    const stpNubr = this.instructionsModel.instructionStopData[i]['stop']['stopSequenceNumber'];
                    this.instructionTagInput.push('Stop ' + stpNubr);
                    this.instructionTagInput = this.jbhGlobals.utils.uniq(this.instructionTagInput);
                }
            }
        }
    }

    billingInstructionTag() {
        if (this.instructionsModel.orderData.orderBillingDetailDTOs &&
            this.instructionsModel.orderData.orderBillingDetailDTOs.length !== 0) {
            if (this.instructionsModel.orderData.orderBillingDetailDTOs[0].orderBillingDetailID !== null &&
                this.instructionsModel.orderData.orderBillingDetailDTOs[0].orderBillingDetailID !== undefined &&
                this.instructionsModel.orderData.orderBillingDetailDTOs[0].orderBillingDetailID !== '') {
                this.instructionTagInput.push('Billing & Rating');
                this.instructionTagInput = this.jbhGlobals.utils.uniq(this.instructionTagInput);
            }
        }
    }

    equipmentInstructionTag() {
        if (this.instructionsModel.orderData.orderEquipmentRequirementDTOs &&
            this.instructionsModel.orderData.orderEquipmentRequirementDTOs.length !== 0) {
            if (this.instructionsModel.orderData.orderEquipmentRequirementDTOs[0].orderEquipmentRequirement.orderEquipmentRequirementID !==
                null &&
                this.instructionsModel.orderData.orderEquipmentRequirementDTOs[0].orderEquipmentRequirement.orderEquipmentRequirementID !==
                undefined &&
                this.instructionsModel.orderData.orderEquipmentRequirementDTOs[0].orderEquipmentRequirement.orderEquipmentRequirementID !==
                '') {
                this.instructionTagInput.push('Equipment');
                this.instructionTagInput = this.jbhGlobals.utils.uniq(this.instructionTagInput);
            }
        }
    }

    addInstructionFormBuilder() {
        InstructionsUtility.addInstructionFormBuilder(this);
    }

    onInstructionSave() {
        InstructionsUtility.onInstructionSave(this);
    }

    saveServiceInstruction(instructionObj, fromEditflag) {
        InstructionsUtility.saveServiceInstruction(instructionObj, fromEditflag, this)
    }

    viewEditSaveInstruction(instructionObj, fromEditflag) {
        InstructionsUtility.viewEditSaveInstruction(instructionObj, fromEditflag, this)
    }

    getDataService() {
        let getInstructionData;
        const me = this;
        getInstructionData = this.jbhGlobals.endpoints.order.getInstruction + this.route.snapshot.queryParams.id +
            '/additionalinstructions';
        this.instructionsService.readInstruction(getInstructionData).subscribe(instructionData => {
            if (!this.jbhGlobals.utils.isEmpty(instructionData)) {
                this.jbhGlobals.logger.info('Getting Instruction data list --->');
                this.jbhGlobals.logger.info(instructionData);
                me.instructionsModel.insArr = [];
                if (instructionData['_embedded']['additionalInstructions'].length === 1) {

                    me.instructionsModel.insArr.push(instructionData['_embedded']['additionalInstructions'][0]);
                } else {
                    const data = instructionData['_embedded']['additionalInstructions'];
                    const arrLen = data.length;
                    for (let i = 0; i < arrLen; i++) {
                        me.instructionsModel.insArr.push(data[i]);
                    }
                }
                this.instructionsModel.insArr = this.jbhGlobals.utils.sortBy(this.instructionsModel.insArr, ['lastUpdateTimestampString']).reverse();
            }
        });
    }

    onAdditionalInstruction(instructionObj) {
        /*const stopVal = instructionObj['additionalInstructionType'].split(' ');
         instructionObj['additionalInstructionType'] = stopVal[0];
         const stopindex = stopVal[1] - 1;
        if (instructionObj['additionalInstructionType'].indexOf('St') >= 0) {
             instructionObj['additionalInstructionType'] = instructionObj['additionalInstructionType'].slice(0, -1)
        }*/
        // if (instructionObj.additionalInstructionType.toLowerCase() === 'stop') {
        /*const stopInstructionType = instructionObj.additionalInstructionType.substring(0, 4);
        instructionObj.additionalInstructionType = stopInstructionType;*/
        // }
        this.instructionsService.createInstruction(instructionObj).subscribe(instructionData => {
            if (!this.jbhGlobals.utils.isEmpty(instructionData)) {
                console.log(instructionObj);
                this.jbhGlobals.logger.info('Adding instructionData --->');
                this.jbhGlobals.logger.info(instructionData);
                this.instructionsModel.saveCall = false;
                this.getDataService();
            }
        });

    }

    onupdateInstruction(instructionObj) {
        this.instructionsService.updateInstruction(instructionObj).subscribe(instructionData => {
            if (!this.jbhGlobals.utils.isEmpty(instructionData)) {
                this.jbhGlobals.logger.info('Adding instructionData --->');
                this.jbhGlobals.logger.info(instructionData);
                this.instructionsModel.saveCall = false;
                this.getDataService();
            }
        });
    }

    instructionViewList() {
        if (this.instructionsModel.insArr && this.instructionsModel.insArr.length !== 0) {
            for (let i = 0; i < this.instructionsModel.insArr.length; i++) {
                this.instructionsModel.instructionIndex.push(this.instructionsModel.insArr[i]);
            }
        }
    }

    onViewAdditionalInstruction(instructionObj) {
        const viewInstructionIndex = this.instructionsModel.instructionIndex.length;
        const editInstruction = {
            'orderVal': [{
                'op': 'add',
                'path': '/additionalinstructions/' + viewInstructionIndex,
                'value': instructionObj
            }]
        };
        this.instructionViewList();
        const url = this.jbhGlobals.endpoints.viewOrder.orderUpdate + this.instructionsModel.orderId + '/warningoverriden/' + false;
        this.viewOrderService.updateOrder(url, editInstruction).subscribe(data => {
            if (this.jbhGlobals.utils.isEmpty(data)) {
                console.log(data);
                this.viewOrderService.loadOrder(this.instructionsModel.orderId);
                this.getDataService();
                this.viewOrderService.errorHandling(data);
            }
        });
    }

    onViewUpdateInstruction(instructionObj) {
        const viewUpdateIndex = this.instructionsModel.viewInstructionIndex;
        const editInstruction = {
            'orderVal': [{
                'op': 'replace',
                'path': '/additionalinstructions/' + viewUpdateIndex + '/additionalInstructionText',
                'value': instructionObj.additionalInstructionText

            }]
        };
        this.instructionViewList();
        const url = this.jbhGlobals.endpoints.viewOrder.orderUpdate + this.route.snapshot.queryParams.id + '/warningoverriden/' + false;
        this.viewOrderService.updateOrder(url, editInstruction).subscribe(data => {
            if (!this.jbhGlobals.utils.isEmpty(data)) {
                console.log(data);
                this.viewOrderService.loadOrder(this.instructionsModel.orderId);
                this.getDataService();
                this.viewOrderService.errorHandling(data);
            }
        });
    }
    enableChargeEdit(chargeIndex) {
        this.instructionsModel.showEditInsBtn = true;
        this.instructionsModel.showdelInsBtn = true;
        this.instructionsModel.editDelIndex = chargeIndex;
    }
    onEditCommentSection(index) {
        if (this.instructionsModel.currentPage !== 'vieworder') {
            this.instructionsModel.editCall = true;
            this.instructionsModel.cancelBtn = true;

            this.instructionsModel.editIns = this.instructionsModel.insArr[index];
            this.addInstructionDetail.patchValue(this.instructionsModel.editIns);
            this.instructionsModel.innerHtmlIns = this.instructionsModel.editIns.additionalInstructionText;
            // this.additionTagInstruction.active = [];
            this.additionTagInstruction.active.push({
                'id': this.instructionsModel.editIns.additionalInstructionType,
                'text': this.instructionsModel.editIns.additionalInstructionType
            });
        } else {
            this.viewEditUpdateInstruction(index);
        }

        if (this.additionTagInstruction && this.additionTagInstruction.active) {
            const stopTag = this.additionTagInstruction.active[0].id;
            this.instructionsModel.stopUniqueId = this.additionTagInstruction.active[0].id.substring(stopTag.length, stopTag.length - 1);
            if (this.instructionsModel.stopUniqueId && this.instructionsModel.instructionStopData &&
                this.instructionsModel.instructionStopData.length !== 0) {

                for (let i = 0; i < this.instructionsModel.instructionStopData.length; i++) {
                    if (this.instructionsModel.instructionStopData[i].stop.stopSequenceNumber !==
                        null && this.instructionsModel.instructionStopData[i].stop.stopID !== '' &&
                        this.instructionsModel.instructionStopData[i].stop.stopSequenceNumber.toString() ===
                        this.instructionsModel.stopUniqueId) {
                        this.instructionsModel.stopServiceId = this.instructionsModel.instructionStopData[i].stop.stopID;
                    }

                }
            }
        }
    }
    viewEditUpdateInstruction(index) {
        this.instructionsModel.editCall = true;
        this.instructionsModel.cancelBtn = true;

        this.instructionsModel.editIns = this.instructionsModel.insArr[index];
        this.addInstructionDetail.patchValue(this.instructionsModel.editIns);
        this.instructionsModel.innerHtmlIns = this.instructionsModel.editIns.additionalInstructionText;
        // this.additionTagInstruction.active = [];
        this.additionTagInstruction.active.push({
            'id': this.instructionsModel.editIns.additionalInstructionType,
            'text': this.instructionsModel.editIns.additionalInstructionType
        });
        this.instructionsModel.viewInstructionIndex = index;
    }
    onDelCommentSection(i) {
        this.instructionsModel.cancelBtn = false;
        this.instructionsModel.selectedInstDiv = i;
        this.instructionsModel.showdelInsBtn = true;
        this.instructionsModel.selectedInsDivv = i;
    }

    onInstPmntDel(index) {
        if (this.instructionsModel.editCall === false) {
            const instructionId = this.instructionsModel.insArr[index]['additionalInstructionId'];
            this.instructionsModel.insArr.splice(index, 1);
            this.deleteInstructionService(instructionId);
        } else {
            const instructionId = this.instructionsModel.insArr[index]['additionalInstructionId'];
            this.instructionsModel.insArr.splice(index, 1);
            this.viewUpdateDeleteService(instructionId);
        }
    }

    deleteInstructionService(instructionId) {
        this.instructionsService.deleteInstruction(instructionId).subscribe(instructionData => {
            this.getDataService();
            this.addInstructionDetail.reset();
            this.instructionsModel.editDelIndex = null;
            this.instructionsModel.selectedInstDiv = null;
            this.instructionsModel.innerHtmlIns = '';
        });
    }
    viewUpdateDeleteService(instructionId) {
        const editInstruction = {
            'order': [{
                'op': 'remove',
                'path': '/additionalinstructions/0',
                'value': instructionId

            }]
        };

        const url = this.jbhGlobals.endpoints.viewOrder.orderUpdate + this.route.snapshot.queryParams.id + '/warningoverriden/' + false;
        this.viewOrderService.updateOrder(url, editInstruction).subscribe(data => {
            if (this.jbhGlobals.utils.isEmpty(data)) {
                console.log(data);
                this.getDataService();
                this.viewOrderService.errorHandling(data);
            }
        });

    }

    onUndoDelInstSection(i) {
        this.instructionsModel.selectedInstDiv = null;
    }
    onDelete() {
        this.instructionsModel.cancelBtn = false;
        this.addInstructionDetail.reset();
        this.instructionsModel.innerHtmlIns = '';
        this.instructionsModel.showEditInsBtn = false;
        this.instructionsModel.showdelInsBtn = false;
    }

    /*onCancel() {
        //this.ordersComponent.onShowDeleteModal(this, ' Are you sure you want to cancel this Order?');
    }*/

    // }
}
