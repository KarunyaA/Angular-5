import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Response } from '@angular/http';

import { JBHGlobals } from '../../../../../../app.service';
import * as jsonpatch from 'fast-json-patch';

@Injectable()
export class CommentsService {
  jsonpatch: any;
  constructor(private jbhGlobals: JBHGlobals) {
    this.jsonpatch = jsonpatch;
  }

  loadComments(commentsDto): Observable < Response[] > {
    return this.jbhGlobals.apiService
      .getData(commentsDto.endpoint + commentsDto.commentID + commentsDto.commentPath);
  }
  commentsType(commentsDto): Observable < Response[] > {
    return this.jbhGlobals.apiService
      .getData(commentsDto);
  }
  getCommentSuggestions(commentsUrl, params): Observable < Response[] > {
    return this.jbhGlobals.apiService
      .getData(commentsUrl, params);
  }
  SaveComments(commentsUrl, params): Observable < Response[] > {
    return this.jbhGlobals.apiService
      .addData(commentsUrl, params);
  }
  updateComments(commentsUrl, params): Observable < Response[] > {
    return this.jbhGlobals.apiService
      .updateData(commentsUrl, params);
  }
  deleteComments(commentDeleteUrl): Observable < Response[] > {
    return this.jbhGlobals.apiService
      .removeData(commentDeleteUrl);
  }
  vieworderPatchSave(orderPatchUrl, params): Observable < Response[] > {
    return this.jbhGlobals.apiService
      .patchData(orderPatchUrl, params);
  }
  updateData(url, initialJson, modifiedJson, lastModified ?: string) {
    const saveData = JSON.stringify(this.jsonpatch.compare(initialJson,
      modifiedJson));
    console.log('saving data', saveData);
    const params = {
      patchDetails: window.btoa(saveData)
    };
    console.log(params);
    const headers = {
      'If-Match': lastModified
    };
    console.log(lastModified);
    this.jbhGlobals.apiService.patchData(url, params, headers).subscribe(data => {
      console.log(data);
    });
  }

}
