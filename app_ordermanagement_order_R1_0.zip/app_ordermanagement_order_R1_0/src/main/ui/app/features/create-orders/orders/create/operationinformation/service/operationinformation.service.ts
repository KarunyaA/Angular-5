import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Response } from '@angular/http';

import { JBHGlobals } from '../../../../../../app.service';

@Injectable()
export class OperationinformationService {
  constructor(private jbhGlobals: JBHGlobals) { }

  getEquipment(genericurl, params): Observable<Response[]> {
    return this.jbhGlobals.apiService
      .getData(genericurl, params);
  }
    getEquipmentMultiSelect(genericurl, params): Observable<Response[]> {
    return this.jbhGlobals.apiService
      .getData(genericurl, params, false);
  }
 }
