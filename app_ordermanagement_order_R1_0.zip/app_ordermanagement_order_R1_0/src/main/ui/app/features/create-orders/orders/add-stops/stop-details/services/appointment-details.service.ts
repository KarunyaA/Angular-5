import { Injectable } from '@angular/core';
import * as moment from 'moment';

import { JBHGlobals } from '../../../../../../app.service';

@Injectable()
export class AppointmentDetailsService {

  constructor(public jbhGlobals: JBHGlobals) { }

  loadUpdateService(url, params): any {
    return this.jbhGlobals.apiService.updateData(url, params);
  }

  loadService(url): any {
    return this.jbhGlobals.apiService.getData(url);
  }

  loadAddDataService(url, params): any {
    return this.jbhGlobals.apiService.addData(url, params);
  }

  setDateTimeDetails(dateTime): any {
    if (dateTime !== null && dateTime !== undefined) {
      const dateLimit = dateTime.indexOf('T');
      const finalDate = dateTime.substr(0, dateLimit);
      return finalDate;
    }
  }

  validateDateRange(dateField: string, fldControlName: string, errorMsg: string, apptType: string,
    apptRequested: object, scheduledAppts: object, appointmentForm: object, appointmentDetailsModel: object): boolean {
    let isValid = true;
    const today = new Date();
    const timeDiff = Math.abs(new Date(dateField).getTime() - today.getTime());
    const diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));
    const errorOccured = this.currentDateValidator(dateField, apptType, apptRequested, scheduledAppts, errorMsg, appointmentDetailsModel, appointmentForm);
    if (errorOccured) {
      isValid = false;
    }
    if (diffDays > 180 && !errorOccured) {
      this.jbhGlobals.notifications.alert('Warning', 'The ' + errorMsg + ' should not exceed more than 180 days');
      isValid = false;
      switch (errorMsg) {
        case 'Start Date':
          appointmentDetailsModel['startDate'] = null;
          appointmentForm['controls']['appointmentStartTimestamp'].setValue(null);
          // appointmentDetailsModel['endTimeMeridian'] = false;
          appointmentForm['controls']['appointmentStartDate'].setValue(null);
          appointmentDetailsModel['startTime'] = null;
          break;
        case 'End Date':
          appointmentForm['controls']['appointmentEndTimestamp'].setValue(null);
          // appointmentDetailsModel['endTimeMeridian'] = false;
          appointmentForm['controls']['appointmentEndDate'].setValue(null);
          appointmentDetailsModel['endDate'] = null;
          appointmentDetailsModel['endTime'] = null;
          appointmentDetailsModel['startDate'] = null;
          break;
        default:
      }
    }
    return isValid;
  }

  currentDateValidator(dateField, apptType, apptRequested, scheduledAppts, errorMsg, appointmentDetailsModel, appointmentForm): boolean {
    let currentDate;
    let obtainedDate;
    const today = new Date();
    currentDate = {
      year: today.getFullYear(),
      month: today.getMonth() + 1,
      day: today.getDate()
    };
    obtainedDate = {
      year: Number(dateField.slice(6)),
      month: Number(dateField.slice(0, 2)),
      day: Number(dateField.slice(3, 5))
    };
    if ((apptType === 'Requested' && !apptRequested.appointmentDateTimeDetailID)
      || (apptType === 'Scheduled' && !scheduledAppts.appointmentDateTimeDetailID)) {
      if ((obtainedDate.day - currentDate.day) < 0 && (obtainedDate.year - currentDate.year) <= 0 &&
        (obtainedDate.month - currentDate.month) <= 0 || (obtainedDate.day - currentDate.day) >= 0 &&
        (obtainedDate.year - currentDate.year) <= 0 && (obtainedDate.month - currentDate.month) < 0 ||
        (obtainedDate.day - currentDate.day) <= 0 && (obtainedDate.year - currentDate.year) < 0 &&
        (obtainedDate.month - currentDate.month) >= 0 || (obtainedDate.day - currentDate.day) >= 0 &&
        (obtainedDate.year - currentDate.year) < 0 && (obtainedDate.month - currentDate.month) >= 0) {
        this.jbhGlobals.notifications.alert('Warning', 'The ' + errorMsg + ' should begin from Current Date');
        switch (errorMsg) {
          case 'Start Date':
            appointmentDetailsModel.startDate = null;
            appointmentForm.controls['appointmentStartTimestamp'].setValue(null);
            // appointmentDetailsModel.endTimeMeridian = false;
            appointmentForm.controls['appointmentStartDate'].setValue(null);
            appointmentDetailsModel.startTime = null;
            return true;
          case 'End Date':
            appointmentForm.controls['appointmentEndTimestamp'].setValue(null);
            // appointmentDetailsModel.endTimeMeridian = false;
            appointmentForm.controls['appointmentEndDate'].setValue(null);
            appointmentDetailsModel.endDate = null;
            appointmentDetailsModel.endTime = null;
            appointmentDetailsModel.startDate = null;
            return true;
          default:
            return false;
        }
      }
    }
  }

  appointmentJson(apptType: string, appointmentStartTime: string, appointmentEndTime: string, primaryCallBack: string,
    apptId: number, stopId: number, apptDetailId: number, scheduledAppts: object, apptRequested: object, appointmentDetailsModel: object): any {
    const stopID = stopId;
    let appointmentDateTimeDetailID: any = '';
    let appointmentConfirmationNumber: any = '';
    let appointmentInstructionArr = [];
    if (apptType === 'Scheduled') {
      if (scheduledAppts['appointmentDateTimeDetailID']) {
        appointmentDateTimeDetailID = scheduledAppts['appointmentDateTimeDetailID'];
      }
      const apptScheduled = this.jbhGlobals.utils.find(appointmentDetailsModel['orderData'].stopDTOs.stop.appointment, {
        appointmentTypeCode: apptType
      });
      let apptInstArr = [];
      if (apptScheduled) {
        if (apptScheduled.appointmentInstructionAssociations !== undefined) {
          apptInstArr = this.jbhGlobals.utils.transform(apptScheduled.appointmentInstructionAssociations, function (result, obj) {
            result.push({
              appointmentInstruction: obj.appointmentInstruction,
              appointmentInstructionAdditionalDetail: null,
              appointmentInstructionAssociationID: 0
            });
          }, []);
          if ((apptScheduled.appointmentInstructionAssociations.length === 1 &&
            !apptScheduled.appointmentInstructionAssociations[0].appointmentInstruction) ||
            apptScheduled.appointmentInstructionAssociations.length < 1) {
            appointmentInstructionArr = [];
          } else {
            appointmentInstructionArr = apptInstArr;
          }
        }
        if (apptScheduled.appointmentConfirmationNumber !== undefined) {
          appointmentConfirmationNumber = apptScheduled.appointmentConfirmationNumber;
        }
      }
      return appointmentDetailsModel['apptJson'] =
        this.scheduledAppointmentJsonStructure(apptId, appointmentConfirmationNumber, apptDetailId,
          appointmentDateTimeDetailID, appointmentStartTime, appointmentEndTime, primaryCallBack, appointmentInstructionArr, stopID);
    } else {
      if (apptRequested['appointmentDateTimeDetailID']) {
        appointmentDateTimeDetailID = apptRequested['appointmentDateTimeDetailID'];
      }
      return appointmentDetailsModel['apptJson'] = this.requestedAppointmentJsonStructure(apptId, appointmentStartTime, apptDetailId,
        appointmentDateTimeDetailID, appointmentEndTime, primaryCallBack, stopID)
    }
  }

  scheduledAppointmentJsonStructure(apptId, appointmentConfirmationNumber, apptDetailId, appointmentDateTimeDetailID, appointmentStartTime,
    appointmentEndTime, primaryCallBack, appointmentInstructionArr, stopID): object {
    const  data = {
      'appointmentID': apptId,
      'appointmentTypeCode': 'Scheduled',
      'appointmentConfirmationNumber': appointmentConfirmationNumber,
      'requestCallBackIndicator': 'Y',
      'appointmentInboundDate': '',
      'appointmentDetails': [{
        'appointmentDetailID': apptDetailId,
        'appointmentSetReasonCode': '02'
      }],
      'appointmentDateTimeDetails': [{
        'appointmentDateTimeDetailID': appointmentDateTimeDetailID,
        'appointmentStartTimestamp': appointmentStartTime,
        'appointmentEndTimestamp': appointmentEndTime,
        'primaryAppointmentIndicator': primaryCallBack
      }],
      'appointmentInstructionAssociations': appointmentInstructionArr,
      'stop': {
        'stopID': stopID
      }
    };
    if (data['appointmentInstructionAssociations'] && data['appointmentInstructionAssociations'].length !== 0 &&
        data['appointmentInstructionAssociations'].appointmentInstruction === '') {
        data['appointmentInstructionAssociations'] = [];
    }
    return data;
  }
  requestedAppointmentJsonStructure(apptId, appointmentStartTime, apptDetailId, appointmentDateTimeDetailID, appointmentEndTime,
    primaryCallBack, stopID): object {
    return {
      'appointmentID': apptId,
      'appointmentTypeCode': 'Requested',
      'requestCallBackIndicator': 'Y',
      'appointmentInboundDate': '',
      'appointmentDetails': [{
        'appointmentDetailID': apptDetailId,
        'appointmentSetReasonCode': '02'
      }],
      'appointmentDateTimeDetails': [{
        'appointmentDateTimeDetailID': appointmentDateTimeDetailID,
        'appointmentStartTimestamp': appointmentStartTime,
        'appointmentEndTimestamp': appointmentEndTime,
        'primaryAppointmentIndicator': primaryCallBack
      }],
      'stop': {
        'stopID': stopID
      }
    };
  }

  getApptToStopDto(appType, appointmentDetailsModel): object {
    return this.jbhGlobals.utils.find(appointmentDetailsModel.orderData.stopDTOs.stop.appointment, {
      appointmentTypeCode: appType
    });
  }

  setApptToStopDto(appType, apptResp, apptJson, apptType, apptRequested, scheduledAppts, position, appointmentDetailsModel): object {
    let apptDateTimeDetails;
    if (appType === 'Requested') {
      let requestedApptArr;
      let requestedAppt;
      if (!this.jbhGlobals.utils.isEmpty(apptResp) && apptResp.appointmentDateTimeDetails.length === 1) {
        apptRequested.appointmentDateTimeDetailID = apptResp.appointmentDateTimeDetails[0].appointmentDateTimeDetailID;
      }
      requestedAppt = this.getApptToStopDto(appType, appointmentDetailsModel);
      if (requestedAppt && requestedAppt !== undefined) {
        requestedApptArr = this.crudAppointmentDetails(requestedAppt, apptResp, apptJson, apptType,
          apptRequested, scheduledAppts, position);
        apptDateTimeDetails = requestedApptArr['appointmentDateTimeDetails'];
      }
    } else {
      let scheduledApptArr;
      let scheduledAppt;
      if (!this.jbhGlobals.utils.isEmpty(apptResp) && apptResp.appointmentDateTimeDetails.length === 1) {
        scheduledAppts.appointmentDateTimeDetailID = apptResp.appointmentDateTimeDetails[0].appointmentDateTimeDetailID;
      }
      scheduledAppt = this.getApptToStopDto(appType, appointmentDetailsModel);
      if (scheduledAppt && scheduledAppt !== undefined) {
        scheduledApptArr = this.crudAppointmentDetails(scheduledAppt, apptResp, apptJson, apptType,
          apptRequested, scheduledAppts, position);
        apptDateTimeDetails = scheduledApptArr['appointmentDateTimeDetails'];
      }
    }
    return apptDateTimeDetails;
  }

  crudAppointmentDetails(apptObj, apptResp, apptJson, apptType, apptRequested, scheduledAppts, position): object {
    const reqApptArr = apptObj.appointmentDateTimeDetails;
    let indx;
    if (reqApptArr.length === 1) {
      if (apptType === 'Requested') {
        apptJson.appointmentDateTimeDetails[0].appointmentDateTimeDetailID = apptRequested.appointmentDateTimeDetailID;
      } else {
        apptJson.appointmentDateTimeDetails[0].appointmentDateTimeDetailID = scheduledAppts.appointmentDateTimeDetailID;
      }
      apptObj.appointmentDateTimeDetails.splice(0, 1, apptJson.appointmentDateTimeDetails[0]);
      apptObj.appointmentID = apptResp.appointmentID;
    } else if (reqApptArr.length > 1) {
      if (this.jbhGlobals.utils.isEmpty(apptResp) &&
        !apptJson.appointmentDateTimeDetails[0]['appointmentDateTimeDetailID']) {
        indx = (reqApptArr.length - 1);
        apptObj.appointmentDateTimeDetails.splice(indx, 1, apptJson.appointmentDateTimeDetails[0]);
      } else if (this.jbhGlobals.utils.isEmpty(apptResp) &&
        apptJson.appointmentDateTimeDetails[0]['appointmentDateTimeDetailID']) {
        apptObj.appointmentDateTimeDetails.splice(position, 1, apptJson.appointmentDateTimeDetails[0]);
      } else if (!this.jbhGlobals.utils.isEmpty(apptResp) &&
        apptJson.appointmentDateTimeDetails[0]['appointmentDateTimeDetailID']) {
        apptObj['appointmentDateTimeDetails'] = apptResp['appointmentDateTimeDetails'];
      }
    }
    return apptObj;
  }

  reccommendedApptStructure(appointmentDetailsModel: object, stopData: Array<object>): object {
    if (appointmentDetailsModel['orderData'] && stopData) {
      return {
        'orderID': appointmentDetailsModel['orderData'].orderID ? appointmentDetailsModel['orderData'].orderID : '',
        'serviceOfferingCode': appointmentDetailsModel['orderData'].serviceOfferingCode ?
          appointmentDetailsModel['orderData'].serviceOfferingCode : '',
        'transitModeCode': appointmentDetailsModel['orderData'].transitModeCode ? appointmentDetailsModel['orderData'].transitModeCode : '',
        'financeBusinessUnitCode': appointmentDetailsModel['orderData'].financeBusinessUnitCode ?
          appointmentDetailsModel['orderData'].financeBusinessUnitCode : '',
        'orderStatusCode': appointmentDetailsModel['orderData'].orderStatusCode ? appointmentDetailsModel['orderData'].orderStatusCode : '',
        'orderTypeCode': appointmentDetailsModel['orderData'].orderTypeCode ? appointmentDetailsModel['orderData'].orderTypeCode : '',
        'shipmentIdentificationNumber': appointmentDetailsModel['orderData'].shipmentIdentificationNumber ?
          appointmentDetailsModel['orderData'].shipmentIdentificationNumber : '',
        'orderGroupingID': appointmentDetailsModel['orderData'].orderGroupingID ? appointmentDetailsModel['orderData'].orderGroupingID : '',
        'orderOperationalElement': appointmentDetailsModel['orderData'].orderOperationalElementDTOs ?
          appointmentDetailsModel['orderData'].orderOperationalElementDTOs : '',
        'internationalOrderElement': [],
        'orderAssociatedParties': [],
        'orderCrossBorderDetails': [],
        'orderMonitorInformations': [],
        'orderReferenceNumbers': [],
        'orderComments': [],
        'orderRequestorDetail': appointmentDetailsModel['orderData'].orderRequestorDTOs ?
          appointmentDetailsModel['orderData'].orderRequestorDTOs : '',
        'orderBillingDetail': [{
          'orderBillingDetailID': (appointmentDetailsModel['orderData'].orderBillingDetailDTOs.length > 0 &&
            appointmentDetailsModel['orderData'].orderBillingDetailDTOs['0'].orderBillingDetailID) ?
            appointmentDetailsModel['orderData'].orderBillingDetailDTOs['0'].orderBillingDetailID : ''
        }],
        'orderServices': [],
        'internationalServices': [],
        'orderUnifiedCustomerRequestAssociations': [],
        'orderAdditionalInstructions': null,
        'orderStatusWorkflows': [],
        'orderStatusEvents': [],
        'orderMaterialHandlingRequirementAssociations': [],
        'orderFoodSafetyDetails': [],
        'orderEquipmentRequirement': [
          {
            'trailerPreloadedIndicator': 'N',
            'orderEquipmentRequirementSpecificationAssociations': [],
            'orderEquipmentRequirementFeatureAssociations': [],
            'orderNonCompanyEquipmentDetails': [],
            'orderEquipmentRequirementAdditionalInstructions': []
          }
        ],
        'stops': stopData ? stopData : '',
        'trailerNumber': null,
        'trailerPrefix': null,
        'orderQuantity': null,
        'orderWeight': null,
        'unitOfOrderWeight': null
      }
    }
  }

  primaryIndicatorGenerator(position: number): string {
    if (position === 0) {
      return 'Y';
    } else {
      return 'N';
    }
  }

  startDateTimeGenerator(apptStartDate: string, apptStartTime: string): string {
    if (apptStartDate !== undefined && apptStartTime !== undefined) {
      const appointmentStartTime = apptStartDate + ' ' + apptStartTime;
      return moment(appointmentStartTime).format('YYYY-MM-DDTHH:mm:ss.000+00:00')
    }
  }

  EndDateTimeGenerator(apptEndDate: string, apptEndTime: string): string {
    if (apptEndDate !== undefined && apptEndTime !== undefined) {
      const appointmentEndTime = apptEndDate + ' ' + apptEndTime;
      return moment(appointmentEndTime).format('YYYY-MM-DDTHH:mm:ss.000+00:00')
    }
  }

  showSaveStatus(appointmentDetailsModel: object, apptType: string, inputStatus: string, inputMsg: string): void {
    if (inputStatus === 'Success') {
      if (apptType === 'Requested') {
        appointmentDetailsModel['isApptReqSaved'] = true;
      } else {
        appointmentDetailsModel['isApptScheduledSaved'] = true;
      }
      this.showNotifications(inputStatus, inputMsg, appointmentDetailsModel);
    } else {
      if (apptType === 'Requested') {
        appointmentDetailsModel['isApptReqSaved'] = true;
      } else {
        appointmentDetailsModel['isApptScheduledSaved'] = true;
      }
    }
  }

  showNotifications(inputStatus, inputMsg, appointmentDetailsModel): void {
    if (inputMsg === 'Add') {
      this.jbhGlobals.notifications.success('Success', 'Appointment Added Successfully');
    } else if (inputMsg === 'Edit') {
      if (appointmentDetailsModel.apptJson.appointmentDateTimeDetails[0].appointmentDateTimeDetailID) {
        this.jbhGlobals.notifications.success('Success', 'Appointment Updated Successfully');
      } else {
        this.jbhGlobals.notifications.success('Success', 'Appointment Added Successfully');
      }
    }
  }

}
