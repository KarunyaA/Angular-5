import { inject, TestBed } from '@angular/core/testing';

import { OperationinformationService } from './operationinformation.service';

describe('OperationinformationService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [OperationinformationService]
    });
  });

  it('should be created', inject([OperationinformationService], (service: OperationinformationService) => {
    expect(service).toBeTruthy();
  }));
});
