import {
    ChangeDetectorRef, Component, Input, OnDestroy, OnInit, QueryList, ViewChild, ViewChildren, ViewContainerRef
} from '@angular/core';

import { JBHGlobals } from '../../../../../app.service';
import { OrderService } from '../../services/order.service';
import { OrderFormBuilderService } from '../../services/order-form-builder.service';
import { FormBuilder } from '@angular/forms';
import { AddStopsOrderService } from './../services/add-stops-order.service';
import { ItemDetailsComponent } from '../item-details/item-details.component';
import { StopHandlingComponent } from './stop-handling.component';
import { HandlingtypeService } from '../services/handlingtype.service';
import { UnitOfLengthService } from '../services/unit-of-length.service';
import { UnitOfWeightService } from '../services/unit-of-weight.service';
import { HandlingunitService } from '../services/handlingunit.service';
import { HandlingUnitModel } from '../models/handling-unit.model';
import { StopSharedDataService } from './../services/stop-shared-data.service';

@Component({
    selector: 'app-handling-units',
    templateUrl: './handling-units.component.html',
    styleUrls: ['./handling-units.component.scss']
})
export class HandlingUnitsComponent implements OnInit, OnDestroy {
    @Input() isCurrViewTemplate: any;
    @Input() handlingForm: any;
    @Input() indx: any;
    @Input() serviceList: any;
    @ViewChild('handlingUnitDiv') handlingUnitDiv: any;
    @ViewChild('itemDetailsRef') itemDetailsRef: any;
    @ViewChild('handlingDiv') handlingDiv: any;
    @ViewChildren(ItemDetailsComponent) itemComponent: QueryList<ItemDetailsComponent>;
    @ViewChild('addHandling') addHandling;
    handlingModel: HandlingUnitModel;

    constructor(
        public jbhGlobals: JBHGlobals, public formBuilder: FormBuilder,
        public orderserv: OrderService,
        public orderService: AddStopsOrderService, public orderFormBuilder: OrderFormBuilderService,
        public changeDetector: ChangeDetectorRef, private viewContainerRef: ViewContainerRef,
        public handlingTypeService: HandlingtypeService, public lengthService: UnitOfLengthService,
        public weightService: UnitOfWeightService, public handlingService: HandlingunitService,
        public stopSharedDataService: StopSharedDataService) {
    }
    ngOnInit(): void {
        this.handlingModel = new HandlingUnitModel();
        this.handlingForm = this.orderFormBuilder.addHandlingUnit();
        this.loadHandlingType(null);
        this.loadLength();
        this.loadWeight();
        this.loadOrderData();
        this.handlingModel.debounceValue = this.jbhGlobals.settings.debounce;
    }
    ngOnDestroy(): void {
        this.handlingForm.reset();
        for (const subs of this.handlingModel.subscriptions) {
            subs.unsubscribe();
        }
    }
    getstopHandlingComponent(): StopHandlingComponent {
        return this.viewContainerRef['_data'].componentView.component.viewContainerRef['_view'].component;
    }
    loadHandlingType(populateValue) {
        if (this.jbhGlobals.utils.isEmpty(this.handlingModel.handlingTypeList)) {
            this.handlingTypeService.getData().subscribe(data => {
                // this.handlingModel.handlingTypeList = data;
                this.handlingModel.handlingTypeList = [];
                for (const handlingUnit of data) {
                    const obj = {
                        'id': handlingUnit.itemHandlingTypeCode,
                        'text': handlingUnit.itemHandlingTypeDescription
                    };
                    this.handlingModel.handlingTypeList.push(obj);
                }
                this.onCallOfSetDefaultValue();
                this.setPopulateValue(populateValue);
            });
        } else {
            this.setPopulateValue(populateValue);
        }
    }
    setPopulateValue(populateValue) {
        if (populateValue) {
            for (const handlingUnit of this.handlingModel.handlingTypeList) {
                if (populateValue === handlingUnit.id) {
                    this.handlingForm.controls['itemHandlingTypeCode'].setValue([handlingUnit]);
                }
            }
        }
    }
    loadLength() {
        if (this.jbhGlobals.utils.isEmpty(this.handlingModel.lengthList)) {
            this.lengthService.getData().subscribe(data => {
                this.handlingModel.lengthList = data;
                this.onCallOfSetDefaultValue();
            });
        }
    }
    loadWeight() {
        if (this.jbhGlobals.utils.isEmpty(this.handlingModel.weightList)) {
            this.weightService.getData().subscribe(data => {
                this.handlingModel.weightList = data;
                this.onCallOfSetDefaultValue();
            });
        }
    }
    loadOrderData() {
        this.handlingModel.subscriptions.push(this.orderService.getData().subscribe(sharedOrderData => {
            this.handlingModel.orderData = sharedOrderData;
            if (this.handlingModel.orderData.stopDTOs && this.handlingModel.orderData.stopDTOs.itemHandlingDetailDTOs
                && this.handlingModel.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx]) {
                this.handlingModel.orderId = this.handlingModel.orderData.orderID;
                const handlingData = this.handlingModel.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx].itemHandlingDetail;
                this.handlingModel.handlingDetails = handlingData;
                this.handlingModel.stopId = this.handlingModel.orderData.stopDTOs.stop.stopID;
                this.handlingModel.handlingUnitId = this.handlingModel.handlingDetails.itemHandlingDetailID;
                this.onCallOfSetDefaultValue();
                if (this.handlingModel.stopId) {
                    // this.loadHandlingReference(this.stopId);
                }
                if (!this.handlingModel.isDataLoaded) {
                    this.onBusinessUnitBased();
                    if (this.handlingModel.stopId && this.handlingModel.handlingUnitId) {
                        this.handlingModel.saveHandlingFlag = false;
                        this.populateData(this.handlingModel.handlingDetails);
                    }
                    if (this.isCurrViewTemplate && !this.jbhGlobals.utils.isEmpty(this.handlingModel.orderData)) {
                        this.populateData(this.handlingModel.handlingDetails);
                    }
                }
                this.loadValueChange();
                this.handlingModel.isDataLoaded = true;
            }
        }));
        this.orderserv.getReference().subscribe(reference => {
            if (this.handlingModel.stopId) {
                const params = this.handlingModel.stopId + '/' + 'referencenumbertypes';
                this.handlingService.getHandlingReference(this.jbhGlobals.endpoints.order.getHandlingReference + params).subscribe(data => {
                    this.handlingModel.referenceList = [];
                    const referenceList = data;
                    for (const refObj of referenceList) {
                        this.handlingModel.referenceList.push({
                            'id': refObj['referenceNumber']['referenceNumberID'],
                            'text': refObj['referenceNumber']['referenceNumberTypeCode'] + ' - ' +
                            refObj['referenceNumber']['referenceNumberValue']
                        });
                    }
                });
            }
            /*this.handlingModel.referenceList = [];
            this.handlingModel.handlingReferenceList = reference['Stop'];
            if (this.handlingModel.handlingReferenceList) {
                for (const i in this.handlingModel.handlingReferenceList) {
                    if (this.handlingModel.handlingReferenceList.hasOwnProperty(i)) {
                        this.handlingModel.referenceList.push(this.handlingModel.handlingReferenceList[i]['referenceNumber']);
                    }
                }
            }*/
        });
    }
    onCallOfSetDefaultValue() {
        if (this.handlingModel.handlingDetails && this.handlingModel.handlingTypeList && this.handlingModel.handlingTypeList.length > 0) {
            const handlingUnitValue = this.handlingModel.handlingDetails.itemHandlingTypeCode;
            if (!this.handlingModel.handlingUnitId && !this.isCurrViewTemplate) {
                this.setDefaultValue(this.handlingForm);
            } else if (!handlingUnitValue && this.isCurrViewTemplate) {
                this.setDefaultValue(this.handlingForm);
            }
        }
    }
    setDefaultValue(form) {
        form['controls']['itemHandlingTypeCode'].setValue([{ 'id': 'Pallet', 'text': 'Pallet' }]);
        form['controls']['itemHandlingTypeQuantity'].setValue(1);
        form['controls']['unitOfLengthMeasurementCode'].setValue('Inches');
        form['controls']['unitOfWeightMeasurementCode'].setValue('Pounds');
        this.handlingModel.handlingDetails.itemHandlingTypeCode = 'Pallet';
        this.handlingModel.handlingDetails.itemHandlingTypeQuantity = 1;
        this.handlingModel.handlingDetails.unitOfLengthMeasurementCode = 'Inches';
        this.handlingModel.handlingDetails.unitOfWeightMeasurementCode = 'Pounds';
    }
    loadValueChange() {
        this.handlingModel.subscriptions.push(this.handlingForm.controls['itemHandlingUnitLength']['valueChanges']
            .debounceTime(this.handlingModel.debounceValue)
            .distinctUntilChanged()
            .subscribe((handlinglength) => {
                if (handlinglength) {
                    this.handlingForm.controls['itemHandlingUnitLength'].setValue(handlinglength);
                    this.calculateVolume();
                    this.calculateDensity();
                    this.handlingModel.handlingDetails.itemHandlingUnitLength = handlinglength;
                } else {
                    this.handlingModel.handlingDetails.itemHandlingUnitLength = '';
                    this.setMeasurementEmpty();
                }
            }, (err: Error) => {
                console.log(err);
            }));
        this.handlingModel.subscriptions.push(this.handlingForm.controls['itemHandlingUnitWidth']['valueChanges']
            .debounceTime(this.handlingModel.debounceValue)
            .distinctUntilChanged()
            .subscribe((width) => {
                if (width) {
                    this.handlingForm.controls['itemHandlingUnitWidth'].setValue(width);
                    this.handlingModel.handlingDetails.itemHandlingUnitWidth = width;
                    this.calculateVolume();
                    this.calculateDensity();
                } else {
                    this.handlingModel.handlingDetails.itemHandlingUnitWidth = '';
                    this.setMeasurementEmpty();
                }
            }, (err: Error) => {
                console.log(err);
            }));
        this.handlingModel.subscriptions.push(this.handlingForm.controls['itemHandlingUnitHeight']['valueChanges']
            .debounceTime(this.handlingModel.debounceValue)
            .distinctUntilChanged()
            .subscribe((heigth) => {
                if (heigth) {
                    this.handlingForm.controls['itemHandlingUnitHeight'].setValue(heigth);
                    this.handlingModel.handlingDetails.itemHandlingUnitHeight = heigth;
                    this.calculateVolume();
                    this.calculateDensity();
                } else {
                    this.handlingModel.handlingDetails.itemHandlingUnitHeight = '';
                    this.setMeasurementEmpty();
                }
            }, (err: Error) => {
                console.log(err);
            }));
        this.handlingModel.subscriptions.push(this.handlingForm.controls['unitOfLengthMeasurementCode']['valueChanges']
            .debounceTime(this.handlingModel.debounceValue)
            .distinctUntilChanged()
            .subscribe((unit) => {
                if (unit.length > 0) {
                    this.handlingModel.handlingDetails.unitOfLengthMeasurementCode = unit;
                    this.calculateVolume();
                    this.calculateDensity();
                } else {
                    this.handlingModel.handlingDetails.unitOfLengthMeasurementCode = '';
                    this.setMeasurementEmpty();
                }
            }, (err: Error) => {
                console.log(err);
            }));
        this.handlingModel.subscriptions.push(this.handlingForm.controls['itemHandlingUnitWeight']['valueChanges']
            .debounceTime(this.handlingModel.debounceValue)
            .distinctUntilChanged()
            .subscribe((weight) => {
                if (weight) {
                    // this.handlingForm.controls['itemHandlingUnitWeight'].setValue(parseFloat(weight));
                    this.handlingModel.handlingDetails.itemHandlingUnitWeight = weight;
                    if (this.handlingModel.handlingDimensionFlag) {
                        this.calculateVolume();
                        this.calculateDensity();
                    }
                    this.calculateVolumeConversion();
                } else {
                    this.handlingModel.handlingDetails.itemHandlingUnitWeight = '';
                    this.handlingModel.handlingUnitDensity = '';
                    this.handlingModel.handlingDensityVal = '';
                    this.setDensityEmpty();
                }
            }, (err: Error) => {
                console.log(err);
            }));
        this.handlingModel.subscriptions.push(this.handlingForm.controls['unitOfWeightMeasurementCode']['valueChanges']
            .debounceTime(this.handlingModel.debounceValue)
            .distinctUntilChanged()
            .subscribe((weightunit) => {
                if (weightunit.length > 0) {
                    this.handlingModel.handlingDetails.unitOfWeightMeasurementCode = weightunit;
                    if (this.handlingModel.handlingDimensionFlag) {
                        this.calculateVolume();
                        this.calculateDensity();
                    }
                    this.calculateVolumeConversion();
                } else {
                    this.handlingModel.handlingDetails.unitOfWeightMeasurementCode = '';
                    this.handlingModel.handlingUnitDensity = '';
                }
            }, (err: Error) => {
                console.log(err);
            }));
        this.handlingModel.subscriptions.push(this.handlingForm.controls['itemHandlingUnitVolume']['valueChanges']
            .debounceTime(this.handlingModel.debounceValue)
            .distinctUntilChanged()
            .subscribe((itemVolume) => {
                if (itemVolume) {
                    if (this.handlingForm['controls']['itemHandlingUnitVolume'].valid === true) {
                        this.handlingModel.handlingVolumeVal = itemVolume;
                        this.handlingModel.volMeasureFlag = true;
                        this.handlingForm['controls']['unitOfVolumeMeasurementCode'].setValue('Cubic CM');
                        this.handlingModel.handlingDetails.itemHandlingUnitVolume = itemVolume;
                        this.calculateVolumeConversion();
                    } else {
                        this.handlingModel.handlingVolumeVal = '';
                        this.handlingModel.volMeasureFlag = false;
                        this.handlingModel.handlingDensityVal = '';
                        this.handlingModel.denMeasureFlag = false;
                    }
                } else {
                    this.handlingModel.handlingVolumeVal = '';
                    this.handlingModel.handlingDensityVal = '';
                    this.handlingModel.handlingVolume = '';
                    this.handlingModel.volMeasureFlag = false;
                    this.handlingModel.handlingDetails.itemHandlingUnitVolume = '';
                    this.setDensityEmpty();
                }
            }, (err: Error) => {
                console.log(err);
            }));
        // this.handlingModel.subscriptions.push(this.handlingForm.controls['itemHandlingTypeCode']['valueChanges']
        //     .debounceTime(this.handlingModel.debounceValue)
        //     .distinctUntilChanged()
        //     .subscribe((value) => {

        //     }, (err: Error) => {
        //         console.log(err);
        //     }));
        this.handlingModel.subscriptions.push(this.handlingForm.controls['itemHandlingTypeQuantity']['valueChanges']
            .debounceTime(this.handlingModel.debounceValue)
            .distinctUntilChanged()
            .subscribe((value) => {
                if (value) {
                    this.handlingModel.handlingDetails.itemHandlingTypeQuantity = value;
                } else {
                    this.handlingModel.handlingDetails.itemHandlingTypeQuantity = '';
                }
            }, (err: Error) => {
                console.log(err);
            }));
    }
    /*public loadHandlingReference(stopId) {
        if (stopId) {
            const params = stopId + '/' + 'referencenumbertypes';
            this.handlingService.getHandlingReference(this.jbhGlobals.endpoints.order.getHandlingReference + params).subscribe(data => {
                this.handlingReferenceList = data;
            });
        }
    }*/
    onBusinessUnitBased() {
        switch (this.handlingModel.orderData.financeBusinessUnitCode) {
            case 'DCS':
                this.onServiceOfferingBased();
                break;
            case 'ICS':
                this.onServiceOfferingBased();
                break;
            case 'JBI':
                this.onServiceOfferingBased();
                break;
            case 'JBT':
                this.onServiceOfferingBased();
                break;
            default:
                break;
        }
    }
    onServiceOfferingBased() {
        switch (this.handlingModel.orderData.serviceOfferingCode) {
            case 'Flatbed':
                this.handlingModel.flatbedFlag = true;
                break;
            default:
                break;
        }
    }
    onSelectHandlingUnitType(value, isSelect) {
        this.handlingModel.handlingDetails.itemHandlingTypeCode = isSelect ? value : '';
    }
    setMeasurementEmpty() {
        this.handlingForm.controls['itemHandlingUnitVolume'].setValue('');
        this.handlingForm.controls['itemHandlingUnitDensity'].setValue('');
        this.handlingModel.handlingUnitDensity = '';
        this.handlingModel.handlingUnitVolume = '';
        this.handlingModel.handlingDetails.itemHandlingUnitVolume = '';
        this.handlingModel.handlingDetails.itemHandlingUnitDensity = '';
        this.handlingModel.volMeasureFlag = false;
        this.handlingModel.denMeasureFlag = false;
    }
    handlingUnitSaveCall(handlingFlag): any {
        if (this.handlingModel.stopId && this.handlingForm['valid'] && this.handlingModel.saveHandlingFlag) {
            let form = this.handlingModel.handlingDetails;
            const handlingUnitId = form.itemHandlingDetailID;
            form['itemHandlingDetailID'] = handlingUnitId;
            form = this.formObjectConversion(form);
            if (!handlingUnitId && this.handlingModel.stopId) {
                this.handlingSaveServiceCall(form, this.handlingModel.stopId, handlingFlag);
            } else if (handlingUnitId && this.handlingModel.stopId) {
                this.handlingUpdateServiceCall(form, handlingUnitId, this.handlingModel.stopId, handlingFlag);
            }
        } else if (!this.handlingModel.stopId && !this.isCurrViewTemplate) {
            this.jbhGlobals.notifications.error('Error', 'Stop information should be filled');
            return false;
        } else if (!this.handlingForm['valid'] && this.handlingForm['touched']) {
            this.jbhGlobals.notifications.error('Error', 'Please fill all the required fields');
            return false;
        }
    }
    handlingSaveServiceCall(form, stopId, addHandlingflag) {
        if (form.itemHandlingTypeQuantity) {
            const params = form;
            const url = this.jbhGlobals.endpoints.order.crudHandlingUnit + '/' + stopId + '/itemhandlingdetails';
            this.handlingService.addHandlingData(url, params).subscribe(data => {
                this.saveHandlingResponseToOrder(data, stopId);
                this.jbhGlobals.notifications.success('Success', 'Handling Unit added successfully');
                if (addHandlingflag) {
                    this.addHandlingUnitForm();
                }
                this.stopSharedDataService.getStopsSummary(this.handlingModel.orderData.orderID);
            });
        } else {
            this.jbhGlobals.notifications.error('Error', 'Handling Unit should be filled');
        }
    }
    handlingUpdateServiceCall(form, handlingUnitId, stopId, addHandlingflag) {
        if (form.itemHandlingTypeQuantity) {
            let params = {};
            const url = this.jbhGlobals.endpoints.order.crudHandlingUnit + '/' + stopId + '/itemhandlingdetails/' + handlingUnitId;
            params = form;
            this.handlingService.updateHandlingData(url, params).subscribe(data => {
                const response = data;
                this.saveHandlingResponseToOrder(response, stopId);
                this.jbhGlobals.notifications.success('Success', 'Handling Unit updated successfully');
                if (addHandlingflag) {
                    this.addHandlingUnitForm();
                }
                this.stopSharedDataService.getStopsSummary(this.handlingModel.orderData.orderID);
            });
        } else {
            this.jbhGlobals.notifications.error('Error', 'Handling Unit should be filled');
        }
    }
    saveHandlingResponseToOrder(response, stopId) {
        delete response['@id'];
        delete response['lastUpdateTimestampString'];
        delete response['stopItems'];
        this.handlingModel.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx].itemHandlingDetail = response;
        this.handlingModel.stopId = this.handlingModel.orderData.stopDTOs.stop.stopID;
        this.handlingModel.handlingUnitId = this.handlingModel.handlingDetails.itemHandlingDetailID;
        this.orderService.saveData(this.handlingModel.orderData);
    }
    onClickOfAddHandlingUnit() {
        if (this.isCurrViewTemplate) {
            this.handlingModel.addHandlingUnitFlag = true;
            this.addHandlingUnitForm();
        } else {
            if (this.handlingModel.stopId && this.handlingForm['valid']) {
                let firstItemValidFlag = false;
                if (this.itemComponent.first && this.itemComponent.first.itemModel.stopItemID) {
                    firstItemValidFlag = true;
                }
                if (!firstItemValidFlag) {
                    this.jbhGlobals.notifications.alert('Warning', 'Please add atleast one item associated with handling unit');
                } else {
                    this.handlingModel.addHandlingUnitFlag = true;
                    this.handlingUnitSaveCall(this.handlingModel.addHandlingUnitFlag);
                }
            } else if (!this.handlingModel.stopId && !this.isCurrViewTemplate) {
                this.jbhGlobals.notifications.error('Error', 'Stop information should be filled');
            } else if (!this.handlingForm['valid'] && this.handlingForm['touched']) {
                this.jbhGlobals.notifications.error('Error', 'Please fill all the required fields');
            }
        }
    }
    formObjectConversion(form) {
        if (this.jbhGlobals.utils.isEmpty(this.handlingForm['controls']['itemReference']['value'])) {
            form['itemHandlingDetailReferenceNumberAssociations'] = [];
        }
        return form;
    }
    addHandlingUnitForm() {
        const Obj = JSON.parse(JSON.stringify(this.serviceList['stopMock'].itemHandlingDetailDTOs[0]));
        this.handlingModel.orderData.stopDTOs.itemHandlingDetailDTOs.push(Obj);
        this.handlingModel.addHandlingUnitFlag = false;
        this.changeDetector.markForCheck();
    }
    onClickofRemoveItem(index: number) {
        const itemArray = this.handlingModel.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx].stopItemDTOs;
        if (itemArray.length > 0 && itemArray[index]) {
            const stopItemId = itemArray[index].stopItem.stopItemID;
            if (this.handlingModel.stopId && this.handlingModel.handlingUnitId && stopItemId) {
                this.jbhGlobals.notifications.alert('Warning', 'All the associated data will get deleted');
                const url = this.jbhGlobals.endpoints.order.crudHandlingUnit + '/' + this.handlingModel.stopId + '/stopitems/' + stopItemId;
                this.handlingService.removeItemData(url).subscribe(data => {
                    itemArray.splice(index, 1);
                    this.changeDetector.markForCheck();
                    this.jbhGlobals.notifications.success('Success', 'Item deleted successfully');
                });
            } else {
                this.jbhGlobals.notifications.success('Success', 'Item deleted successfully');
                itemArray.splice(index, 1);
                this.changeDetector.markForCheck();
            }
        }
    }
    onDimensionClick(value) {
        if (value === 'handlingDimension') {
            this.handlingForm.controls['itemHandlingUnitVolume'].setValue('');
            this.handlingModel.handlingDetails.itemHandlingUnitVolume = '';
            this.handlingModel.handlingDimensionFlag = true;
        } else {
            this.handlingForm.controls['itemHandlingUnitLength'].setValue('');
            this.handlingForm.controls['itemHandlingUnitWidth'].setValue('');
            this.handlingForm.controls['itemHandlingUnitHeight'].setValue('');
            this.handlingModel.handlingDetails.itemHandlingUnitLength = '';
            this.handlingModel.handlingDetails.itemHandlingUnitWidth = '';
            this.handlingModel.handlingDetails.itemHandlingUnitHeight = '';
            this.handlingModel.handlingDimensionFlag = false;
        }
    }
    calculateVolume() {
        const val = this.checkValidDimension();
        if (val === true) {
            const handLength = this.handlingForm.value.itemHandlingUnitLength;
            const handWidth = this.handlingForm.value.itemHandlingUnitWidth;
            const handHeigth = this.handlingForm.value.itemHandlingUnitHeight;
            const handUnit = this.handlingForm.value.unitOfLengthMeasurementCode;
            if (handLength && handWidth &&
                handHeigth && !this.jbhGlobals.utils.isEmpty(handUnit)) {
                const length = this.getstopHandlingComponent().conversionToInches(handLength, handUnit);
                const width = this.getstopHandlingComponent().conversionToInches(handWidth, handUnit);
                const height = this.getstopHandlingComponent().conversionToInches(handHeigth, handUnit);
                const volume = (length * width * height) / (12 * 12 * 12);
                const volumeVal = this.validateDimensionAndVolume(volume);
                if (volumeVal) {
                    this.handlingModel.handlingUnitVolume = volume.toFixed(4);
                    this.handlingModel.volMeasureFlag = true;
                    const parseVolumeVal = parseFloat(volume.toFixed(4));
                    this.handlingForm['controls']['itemHandlingUnitVolume'].setValue(parseVolumeVal);
                    this.handlingForm['controls']['unitOfVolumeMeasurementCode'].setValue('Cubic CM');
                    this.handlingModel.handlingDetails.itemHandlingUnitVolume = parseVolumeVal;
                    this.handlingModel.handlingDetails.unitOfVolumeMeasurementCode = 'Cubic CM';
                }
            }
        } else {
            this.handlingForm['controls']['unitOfVolumeMeasurementCode'].setValue('');
            this.handlingForm['controls']['itemHandlingUnitVolume'].setValue('');
            if (this.handlingModel.handlingDetails && this.handlingModel.handlingDetails.itemHandlingDetail) {
                this.handlingModel.handlingDetails.itemHandlingUnitVolume = '';
                this.handlingModel.handlingDetails.unitOfVolumeMeasurementCode = '';
            }
            this.handlingModel.handlingUnitVolume = '';
            this.handlingModel.volMeasureFlag = false;
        }

    }
    calculateDensity() {
        const val = this.checkValidDimension();
        if (val === true) {
            const handLength = this.handlingForm.value.itemHandlingUnitLength;
            const handWidth = this.handlingForm.value.itemHandlingUnitWidth;
            const handHeigth = this.handlingForm.value.itemHandlingUnitHeight;
            const handUnit = this.handlingForm.value.unitOfLengthMeasurementCode;
            const handWeight = this.handlingForm.value.itemHandlingUnitWeight;
            const handWeightUnit = this.handlingForm.value.unitOfWeightMeasurementCode;
            if (handLength && handWidth && handHeigth && !this.jbhGlobals.utils.isEmpty(handUnit) &&
                handWeight && !this.jbhGlobals.utils.isEmpty(handWeightUnit)) {
                const length = this.getstopHandlingComponent().conversionToFeet(handLength, handUnit);
                const width = this.getstopHandlingComponent().conversionToFeet(handWidth, handUnit);
                const height = this.getstopHandlingComponent().conversionToFeet(handHeigth, handUnit);
                const weight = this.getstopHandlingComponent().weightConversion(handWeight, handWeightUnit);
                const density = weight / (length * width * height);
                const densityVal = this.validateDimensionAndVolume(density);
                if (densityVal) {
                    this.handlingModel.handlingUnitDensity = density.toFixed(4);
                    this.setDenityVal(density.toFixed(4));
                }
            }
        } else {
            this.handlingModel.handlingUnitDensity = '';
            this.setDensityEmpty();
        }
    }
    setVolumeEmpty() {
        this.handlingForm['controls']['unitOfVolumeMeasurementCode'].setValue('');
        this.handlingForm['controls']['itemHandlingUnitVolume'].setValue('');
        this.handlingModel.handlingDetails.itemHandlingUnitVolume = '';
        this.handlingModel.handlingDetails.unitOfVolumeMeasurementCode = '';
        this.handlingModel.handlingUnitVolume = '';
    }
    calculateVolumeConversion() {
        const val = this.checkValidDimension();
        if (val === true) {
            const volume = this.handlingForm.value.itemHandlingUnitVolume;
            const weight = this.handlingForm.value.itemHandlingUnitWeight;
            const weightUnit = this.handlingForm.value.unitOfWeightMeasurementCode;
            if (volume && weight && !this.jbhGlobals.utils.isEmpty(weightUnit)) {
                const density = this.getstopHandlingComponent().weightConversion(weight, weightUnit) / volume * (12 * 12 * 12);
                const densityVal = this.validateDimensionAndVolume(density);
                if (densityVal) {
                    this.handlingModel.handlingDensityVal = parseFloat(density.toFixed(4));
                    this.setDenityVal(density.toFixed(4));
                }
            }
        } else {
            this.setDensityEmpty();
            this.handlingModel.handlingDensityVal = '';
        }
    }
    setDensityEmpty() {
        this.handlingModel.denMeasureFlag = false;
        this.handlingForm['controls']['unitOfDensityMeasurementCode'].setValue('');
        this.handlingForm['controls']['itemHandlingUnitDensity'].setValue('');
        this.handlingModel.handlingDetails.itemHandlingUnitDensity = '';
        this.handlingModel.handlingDetails.unitOfDensityMeasurementCode = '';
    }
    setDenityVal(value) {
        this.handlingModel.denMeasureFlag = true;
        this.handlingForm['controls']['itemHandlingUnitDensity'].setValue(parseFloat(value));
        this.handlingForm['controls']['unitOfDensityMeasurementCode'].setValue('GM/CC');
        this.handlingForm.value.itemHandlingUnitDensity = parseFloat(value);
        this.handlingForm.value.unitOfDensityMeasurementCode = 'GM/CC';
        this.handlingModel.handlingDetails.itemHandlingUnitDensity = parseFloat(value);
        this.handlingModel.handlingDetails.unitOfDensityMeasurementCode = 'GM/CC';
    }
    onAddParentReference(event, isSelectFlag) {
        let referenceNumberAssociation = [];
        referenceNumberAssociation = this.handlingModel.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx]
            .itemHandlingDetail.itemHandlingDetailReferenceNumberAssociations;
        const value = (event.id) ? event.id : '';
        if (this.jbhGlobals.utils.isEmpty(referenceNumberAssociation)) {
            this.handlingModel.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx]
                .itemHandlingDetail.itemHandlingDetailReferenceNumberAssociations = [];
        }
        this.handlingModel.referenceObject = {
            'itemHandlingDetailReferenceNumberAssociationID': '',
            'stopReferenceNumber': {
                '@type': 'StopReferenceNumber',
                'referenceNumberID': parseInt(value, 10)
            }
        };
        const referenceArr = JSON.parse(JSON.stringify(this.handlingModel.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx]
            .itemHandlingDetail.itemHandlingDetailReferenceNumberAssociations));
        for (const referenceObj of referenceArr) {
            this.removeProperties(referenceObj);
        }
        const index = this.jbhGlobals.utils.findIndex(referenceArr, this.handlingModel.referenceObject);
        if (isSelectFlag) {
            if (index === -1) {
                this.handlingModel.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx]
                    .itemHandlingDetail.itemHandlingDetailReferenceNumberAssociations.push(this.handlingModel.referenceObject);
            }
        } else {
            this.handlingModel.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx]
                .itemHandlingDetail.itemHandlingDetailReferenceNumberAssociations.splice(index, 1);
        }
        this.handlingModel.referenceValue.push(event);
        this.handlingForm['controls'].itemReference.setValue(this.handlingModel.referenceValue);
        this.handlingUnitSaveCall(false);
    }
    removeProperties(targetJson) {
        const properties = ['createTimestamp', 'createProgramName', 'lastUpdateTimestamp', 'lastUpdateProgramName', 'createUserId',
            'lastUpdateUserId', 'referenceNumberTypeCode', 'referenceNumberValue', 'referenceNumberLevelTypeCode',
            'associatedReferenceNumber', 'lastUpdateTimestampString'];
        const me = this;
        Object.keys(targetJson).forEach(function (key) {
            if (targetJson[key]) {
                if (typeof targetJson[key] === 'object') {
                    me.removeProperties(targetJson[key]);
                } else if (targetJson[key] instanceof Array) {
                    Object.keys(targetJson[key]).forEach(function (obj) {
                        me.removeProperties(targetJson[key][obj]);
                    })
                } else if (properties.indexOf(key) !== -1) {
                    delete targetJson[key];
                }
                if (key === 'itemHandlingDetailReferenceNumberAssociationID') {
                    targetJson[key] = '';
                }
            } else {
                delete targetJson[key];
            }
        });
        return targetJson;
    }
    populateData(handlingDataPopulation) {
        this.handlingForm.patchValue(handlingDataPopulation);
        this.loadHandlingType(handlingDataPopulation.itemHandlingTypeCode);
        if (handlingDataPopulation.itemHandlingDetailReferenceNumberAssociations.length > 0) {
            // const referenceVal = handlingDataPopulation.itemHandlingDetailReferenceNumberAssociations[0].
            //     stopReferenceNumber.referenceNumberID;
            // this.handlingForm['controls'].itemReference.setValue(referenceVal);
            const populateArr = [];
            for (const refArr of handlingDataPopulation.itemHandlingDetailReferenceNumberAssociations) {
                const referenceArr = refArr.stopReferenceNumber;
                const obj = {
                    'id': referenceArr.referenceNumberID,
                    'text': referenceArr.referenceNumberTypeCode + ' - ' + referenceArr.referenceNumberValue
                }
                const index = this.jbhGlobals.utils.findIndex(populateArr, obj);
                if (index === -1) {
                    populateArr.push(obj);
                }
                this.handlingForm['controls'].itemReference.setValue(populateArr);
            }
        }
        if (handlingDataPopulation.itemHandlingUnitVolume &&
            !this.jbhGlobals.utils.isEmpty(handlingDataPopulation.unitOfVolumeMeasurementCode) &&
            !handlingDataPopulation.itemHandlingUnitLength &&
            !handlingDataPopulation.itemHandlingUnitWidth && !handlingDataPopulation.itemHandlingUnitHeight) {
            this.handlingModel.handlingDimensionFlag = false;
            this.handlingModel.handlingVolumeVal = this.handlingForm['controls'].itemHandlingUnitVolume.value;
            this.handlingModel.volMeasureFlag = true;
            if (handlingDataPopulation.itemHandlingUnitWeight &&
                !this.jbhGlobals.utils.isEmpty(handlingDataPopulation.unitOfWeightMeasurementCode)) {
                this.handlingModel.handlingDensityVal = this.handlingForm['controls'].itemHandlingUnitDensity.value;
                this.handlingModel.denMeasureFlag = true;
            }
        } else {
            this.handlingModel.handlingDimensionFlag = true;
            this.handlingModel.handlingVolumeVal = '';
            this.handlingModel.handlingDensityVal = '';
        }
        if (handlingDataPopulation.itemHandlingUnitLength && handlingDataPopulation.itemHandlingUnitWidth &&
            handlingDataPopulation.itemHandlingUnitHeight &&
            !this.jbhGlobals.utils.isEmpty(handlingDataPopulation.unitOfLengthMeasurementCode) &&
            handlingDataPopulation.itemHandlingUnitVolume &&
            !this.jbhGlobals.utils.isEmpty(handlingDataPopulation.unitOfVolumeMeasurementCode)) {
            this.handlingModel.handlingUnitVolume = this.handlingForm['controls'].itemHandlingUnitVolume.value;
            this.handlingModel.volMeasureFlag = true;
            if (handlingDataPopulation.itemHandlingUnitWeight &&
                !this.jbhGlobals.utils.isEmpty(handlingDataPopulation.unitOfWeightMeasurementCode)) {
                this.handlingModel.handlingUnitDensity = this.handlingForm['controls'].itemHandlingUnitDensity.value;
                this.handlingModel.denMeasureFlag = true;
            }
        } else {
            this.handlingModel.handlingUnitVolume = '';
            this.handlingModel.handlingUnitDensity = '';
        }
        this.handlingModel.saveHandlingFlag = true;
    }
    onClickofRemoveHandlingUnit(i: number) {
        const stopId = this.handlingModel.orderData.stopDTOs.stop.stopID;
        const handlingArray = this.handlingModel.orderData.stopDTOs.itemHandlingDetailDTOs;
        const handlingUnitId = handlingArray[i].itemHandlingDetail.itemHandlingDetailID;
        if (stopId && handlingUnitId) {
            this.jbhGlobals.notifications.alert('Warning', 'All the associated items will get removed');
            const url = this.jbhGlobals.endpoints.order.crudHandlingUnit + '/' + stopId + '/itemhandlingdetails/' + handlingUnitId;
            this.handlingService.removeHandlingData(url).subscribe(data => {
                handlingArray.splice(i, 1);
                this.changeDetector.markForCheck();
                this.jbhGlobals.notifications.success('Success', 'Handling unit deleted successfully');
            });
        } else {
            this.jbhGlobals.notifications.success('Success', 'Handling unit deleted successfully');
            handlingArray.splice(i, 1);
            this.changeDetector.markForCheck();
        }
    }
    validateDimensionAndVolume(value): any {
        const val = this.jbhGlobals.utils.floor(value);
        const valLength = val.toString().length;
        if (!isNaN(value) && valLength < 8) {
            return value;
        } else {
            this.setDimensionandVolumeEmpty();
            this.jbhGlobals.notifications.error('Error', 'Please enter proper value for Dimesion or Volume');
            return null;
        }
    }
    setDimensionandVolumeEmpty() {
        if (this.handlingModel.handlingDimensionFlag) {
            this.handlingForm['controls']['itemHandlingUnitLength'].setValue('');
            this.handlingForm['controls']['itemHandlingUnitWidth'].setValue('');
            this.handlingForm['controls']['itemHandlingUnitHeight'].setValue('');
            this.handlingForm['controls']['itemHandlingUnitWeight'].setValue('');
            this.handlingForm['controls']['unitOfVolumeMeasurementCode'].setValue('');
            this.handlingForm['controls']['itemHandlingUnitVolume'].setValue('');
            this.setDensityEmpty();
        } else {
            this.handlingForm['controls']['itemHandlingUnitWeight'].setValue('');
            this.handlingForm['controls']['itemHandlingUnitVolume'].setValue('');
            this.handlingForm['controls']['unitOfVolumeMeasurementCode'].setValue('');
            this.setDensityEmpty();
        }
    }
    checkValidDimension(): boolean {
        if (this.handlingForm['controls']['itemHandlingUnitLength'].invalid ||
            this.handlingForm['controls']['itemHandlingUnitWidth'].invalid ||
            this.handlingForm['controls']['itemHandlingUnitHeight'].invalid ||
            this.handlingForm['controls']['itemHandlingUnitWeight'].invalid ||
            this.handlingForm['controls']['itemHandlingUnitVolume'].invalid) {
            return false;
        } else {
            return true;
        }
    }
    enterToClick(event) {
        if (event.keyCode === 13) {
            event.currentTarget.click();
        }
    }
}
