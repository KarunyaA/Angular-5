import { IMyDateModel, IMyOptions } from 'mydatepicker';

export class AppointmentDetailsModel {
    appointmentForm: any;
    apptStartDate: any;
    apptStartTime: any;
    apptEndDate: any;
    apptEndTime: any;
    apptJson: any;
    apptStartDateTime: any;
    apptEndDateTime: any;
    isApptReqSaved = true;
    isApptScheduledSaved = true;
    orderData: any;
    recommendedJson: any;
    recommendedAppt: any;
    selectedStartDate: any;
    mouseEventSub: any;
    prevDiv: any;
    currDiv: any;
    startTime: any;
    endTime: any;
    myDatePickerOptions: IMyOptions = {
        todayBtnTxt: 'Today',
        dateFormat: 'mm-dd-yyyy',
        firstDayOfWeek: 'mo',
        showTodayBtn: false,
        showClearDateBtn: true,
        editableDateField: false,
        sunHighlight: true,
        height: '34px',
        width: '170px',
        inline: false,
        enableDays: [{ year: 2017, month: 6, day: 12 }, { year: 2017, month: 6, day: 15 }],
        dayLabels: { su: 'S', mo: 'M', tu: 'T', we: 'W', th: 'T', fr: 'F', sa: 'S' },
        selectionTxtFontSize: '14px'
    };
    initialDateSet = false;
    startDate = '';
    endDate = '';
    myEndTime: Date = new Date();
    myStartTime: Date = new Date();
    timeFlag = {
        startTimeDirty: false,
        endTimeDirty: false,
        startTimeIntitallySet: false,
        endTimeIntitallySet: false
    };
    // startTimeMeridian = false;
    // endTimeMeridian = false;
    subscriberFlag = true;
}
