import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';

import { AppModule } from '../../../../../app.module';
import { CreateOrdersModule } from '../../../create-orders.module';
import { OrdersModule } from '../../orders.module';
import { AddStopsModule } from '../add-stops.module';

import { DeliveryHandlingUnitsComponent } from './delivery-handling-units.component';

describe('DeliveryHandlingUnitsComponent', () => {
  let component: DeliveryHandlingUnitsComponent;
  let fixture: ComponentFixture<DeliveryHandlingUnitsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
            imports: [
                  AppModule,
                  RouterTestingModule,
                  CreateOrdersModule,
                  AddStopsModule,
                  OrdersModule// ,
                 // ModalModule.forRoot()
               ],
      declarations: []
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeliveryHandlingUnitsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
