import { Component, Input, ChangeDetectorRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';

import { JBHGlobals } from '../../../../../app.service';
import { OrderService } from '../../services/order.service';
import { OrderFormBuilderService } from '../../services/order-form-builder.service';
import { ShipmentinformationService } from './services/shipmentinformation.service';
import { ShipmentinformationModel } from './models/shipmentinformation.model';
import { CreateService } from '../services/create.service';
import * as moment from 'moment';

@Component({
    selector: 'app-shipmentinformation',
    templateUrl: './shipmentinformation.component.html',
    styleUrls: ['./shipmentinformation.component.scss'],
    providers: [ShipmentinformationService]
})

export class ShipmentinformationComponent implements OnInit, OnDestroy {
    // tslint:disable:member-access
    shipmentinformationModel: ShipmentinformationModel;
    @Input() isCurrViewTemplate: boolean;
    shipmentInformation: any;
    @ViewChild('shipmentRequirementsTagsKey') shipmentRequirementsTagsKey: any;
    @ViewChild('internationalservice') internationalServiceTag: any;
    @ViewChild('inbond') inbondCheckbox: any;
    @ViewChild('precool') precoolCheckBox: any;
    @ViewChild('operating') operatingCheckBox: any;
    @ViewChild('preshowCel') precoolShowCelsius: any;
    @ViewChild('opershowCel') operatingShowCelsius: any;
    @ViewChild('shipmentIdentificationNumber') shipmentIdentificationNumber: any;
    @ViewChild('autoRate') autoRate;
    @ViewChild('addTempZoneBox') addTempZoneBox;
    @ViewChild('preCoolAddTempZone') preCoolAddTempZone;
    @ViewChild('popInstance') popInstance: any;
    brokerValue: any;
    brokVal: any;

    constructor(
        public jbhGlobals: JBHGlobals,
        public formBuilder: FormBuilder,
        public orderService: OrderService,
        public orderFormBuilder: OrderFormBuilderService,
        private shipmentinformationService: ShipmentinformationService,
        private createService: CreateService, private changeDetector: ChangeDetectorRef) { }

    ngOnInit(): void {
        this.shipmentinformationModel = new ShipmentinformationModel();
        this.shipmentInformation = this.orderFormBuilder.orderForm['controls']['shipmentInformation'];
        this.shipmentinformationModel.debounceValue = this.jbhGlobals.settings.debounce;
        const me = this;
        this.jbhGlobals.utils.forIn(this.shipmentInformation.controls, function (value, name, object) {
            (<FormControl>me.shipmentInformation.controls[name]).setValue('');
            me.shipmentInformation.controls[name].setErrors(null);
            me.shipmentInformation.controls[name].reset();
        });
        this.getOrderValues();
        this.loadShipmentRequirement();
        this.onValueChanges();
    }
    ngOnDestroy(): void {
        for (const subs of this.shipmentinformationModel.subscriptions) {
            subs.unsubscribe();
        }
        this.shipmentInformation.reset();
    }
    onValueChanges(): void {
        const valueChangeArray = ['shipmentIdentificationNumber', 'vesselNumber', 'voyageNumber',
            'volcarrierName', 'carrierName', 'customsbrokercarrier', 'entryNumber', 'bondNumber', 'orderValueAmount',
            'fleetCode', 'autorateIndicator'];
        for (const control of valueChangeArray) {
            this.shipmentinformationModel.subscriptions.push(
                this.shipmentInformation.controls[control].valueChanges.debounceTime(
                    this.shipmentinformationModel.debounceValue)
                    .distinctUntilChanged().subscribe((value) => this.getChangedValue(value, control)));
        }
    }
    getChangedValue(value: any, control: string): void {
        switch (control) {
            case 'shipmentIdentificationNumber':
            case 'orderValueAmount':
                this.shipmentinformationModel.orderData[control] = value;
                this.orderService.saveData(this.shipmentinformationModel.orderData);
                break;
            case 'vesselNumber':
            case 'voyageNumber':
            case 'entryNumber':
            case 'bondNumber':
                this.saveChangedInternationalOrderValue(value, control);
                break;
            case 'volcarrierName':
            case 'carrierName':
                if (this.resetArrayOnValueChange(value,
                    (control === 'volcarrierName') ? 'volumecarrierNameList' : 'carrierNameList')) {
                    this.loadCarrierName(value, (control === 'volcarrierName') ? false : true);
                }
                break;
            case 'customsbrokercarrier':
                this.shipmentinformationModel.customsBrokerList = [''];
                if (this.resetArrayOnValueChange(value, 'customsBrokerList', true) && this.checkVal(value)) {
                    this.loadCustomsBroker(value);
                }
                break;
            case 'fleetCode':
                if (this.resetArrayOnValueChange(value, 'fleetCodeList', false, true)) {
                    this.loadFleetCode(value.trim());
                }
                break;
            case 'autorateIndicator':
                if (!this.jbhGlobals.utils.isEmpty(this.shipmentinformationModel.orderData.orderBillingDetailDTOs)) {
                    if (this.shipmentinformationModel.orderData.orderBillingDetailDTOs.length === 0) {
                        const obj = {
                            'autorateIndicator': ''
                        };
                        this.shipmentinformationModel.orderData.orderBillingDetailDTOs.push(obj);
                    }
                    this.shipmentinformationModel.orderData.orderBillingDetailDTOs[0].autorateIndicator = value ? 'Y' : 'N';
                    this.orderService.saveData(this.shipmentinformationModel.orderData);
                }
                break;
            default:
                break;
        }
    }
    resetArrayOnValueChange(value, array, isCustomsBrokerFlag?, isFleetCode?): boolean {
        if (this.jbhGlobals.utils.isEmpty(value)) {
            if (isFleetCode) {
                this.shipmentInformation.get('fleetCode').setValidators([Validators.maxLength(10)]);
                this.shipmentInformation.get('fleetCode').updateValueAndValidity();
            }
            this.shipmentinformationModel[array] = [];
        } else if (value.length > 2) {
            // if (value.indexOf(' ') === -1) {
            if (!isCustomsBrokerFlag) {
                return true;
            } else {
                if (isFleetCode) {
                    return true;
                } else {
                    if (isCustomsBrokerFlag && value.length > 2) {
                        return true;
                    }
                    if (value.length > 3) {
                        return true;
                    }
                }
            }
            // }
        }
        return false;
    }
    checkVal(value): boolean {
        const format = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/;
        if (!format.test(value)) {
            return true;
        } else {
            return false;
        }
    }
    saveChangedInternationalOrderValue(value, control): void {
        if (this.shipmentinformationModel.orderData.internationalOrderElement) {
            if (this.shipmentinformationModel.orderData.internationalOrderElement.length === 0) {
                this.createInternationalOrderElement();
            }
            this.shipmentinformationModel.orderData.internationalOrderElement[0][control] = value;
            this.orderService.saveData(this.shipmentinformationModel.orderData);
        }
    }
    getOrderValues(): void {
        this.shipmentinformationModel.subscriptions.push(this.orderService.getData().subscribe(sharedOrderData => {
            this.shipmentinformationModel.orderData = sharedOrderData;
            if (!this.jbhGlobals.utils.isEmpty(this.shipmentinformationModel.orderData)) {
                this.validateAutoRateIndicator(this.shipmentinformationModel.orderData);
                if (!this.jbhGlobals.utils.isEmpty(this.shipmentinformationModel.orderData.financeBusinessUnitCode) &&
                    !this.jbhGlobals.utils.isEmpty(this.shipmentinformationModel.orderData.serviceOfferingCode)) {
                    if (this.shipmentinformationModel.serviceOfferingValue !==
                        this.shipmentinformationModel.orderData.serviceOfferingCode ||
                        this.shipmentinformationModel.businessUnitValue !==
                        this.shipmentinformationModel.orderData.financeBusinessUnitCode) {
                        this.shipmentInformation['controls']['orderTypeCode'].setValue('');
                        this.shipmentinformationModel.orderData.orderTypeCode = null;
                        this.shipmentInformation['controls']['orderTypeCode'].reset();
                        this.shipmentinformationModel.transitMode = this.shipmentinformationModel.orderData.transitModeCode;
                        this.shipmentinformationModel.serviceOfferingValue = this.shipmentinformationModel.orderData.serviceOfferingCode;
                        this.shipmentinformationModel.businessUnitValue = this.shipmentinformationModel.orderData.financeBusinessUnitCode;
                        if (this.shipmentinformationModel.populateFlag) {
                            this.shipmentRequirementsTagsKey.active = [];
                            this.internationalServiceTag.active = [];
                        }
                        this.businessUnitDependency();
                        this.loadOrderType('Standard');
                    }
                    this.callPopulateMethod();
                } else {
                    this.shipmentInformation['controls']['orderTypeCode'].setValue([{ 'id': 'Standard', 'text': 'Standard' }]);
                }
            }
        }));
    }
    validateAutoRateIndicator(data) {
        if (data && data['orderBillingDetailDTOs'] && data['orderBillingDetailDTOs'][0]
            && data['orderBillingDetailDTOs'][0]['autorateIndicator']) {
            const autoRate = this.shipmentInformation.controls['autorateIndicator'];
            autoRate.setValue(this.shipmentinformationModel.orderData.orderBillingDetailDTOs[0].autorateIndicator
                === 'Y' ? true : false);
        }
    }
    callPopulateMethod(): void {
        if (this.shipmentinformationModel.populateFlag) {
            this.populateData();
        }
    }
    businessUnitDependency(): void {
        if (!this.jbhGlobals.utils.isEmpty(this.shipmentinformationModel.businessUnitValue) &&
            !this.jbhGlobals.utils.isEmpty(this.shipmentinformationModel.serviceOfferingValue) &&
            !this.jbhGlobals.utils.isEmpty(this.shipmentinformationModel.transitMode)) {
            this.checkTransitMode(null);
            this.shipmentRequirementsTagsKey.active = [];
            this.shipmentinformationModel.volship = false;
            this.shipmentinformationModel.tradeshow = false;
            this.shipmentinformationModel.tempcontrol = false;
            this.shipmentinformationModel.intship = false;
            this.shipmentinformationModel.refrigerated = false;
            this.shipmentinformationModel.maritimeflag = false;
            this.shipmentinformationModel.fleetcodeflag = true;
            this.shipmentinformationModel.flatbedFlag = false;
            this.shipmentinformationModel.DCSFMSflag = false;
            this.shipmentinformationModel.ICSLTLflag = false;
            this.orderValueSetValidation(false);
            this.updateRMAOrderflag(false);
            this.serviceOfferingDependency();
        }
    }
    serviceOfferingDependency(): void {
        switch (this.shipmentinformationModel.serviceOfferingValue) {
            case 'Maritime':
                this.shipmentinformationModel.maritimeflag = true;
                break;
            case 'LTL':
                this.shipmentinformationModel.ICSLTLflag = true;
                this.shipmentinformationModel.fleetcodeflag = false;
                break;
            case 'Reefer':
                if (this.addTag({ id: 'Refrigerated', text: 'Refrigerated' })) {
                    this.shipmentinformationModel.refrigerated = true;
                    this.saveRefrigeratedIndicatorValue(true);
                }
                if (this.addTag({ id: 'Temperature Control', text: 'Temperature Control' })) {
                    this.shipmentinformationModel.tempcontrol = true;
                    this.loadTemperatureArray();
                    this.onLoadOperating(this.operatingCheckBox.nativeElement);
                    this.preCoolAutoFlag(this.precoolCheckBox.nativeElement);
                    console.log(this.shipmentRequirementsTagsKey.active);
                }
                console.log(this.shipmentRequirementsTagsKey.active);
                break;
            case 'FinalMile':
                this.shipmentinformationModel.fleetcodeflag = false;
                this.shipmentinformationModel.DCSFMSflag = true;
                break;
            case 'Flatbed':
                this.shipmentinformationModel.flatbedFlag = true;
                break;
            default:
                break;
        }
        this.loadShipmentRequirement();
    }
    checkTransitMode(value): void {
        this.shipmentinformationModel.railintactserviceflag = this.shipmentinformationModel.transitMode === 'Rail' ? true : false;
        if (this.shipmentinformationModel.railintactserviceflag === true) {
            this.loadPortOfExit(value);
        }
    }
    ngSelectOnBlur(event, selectComponent): void { // for validation
        this.shipmentinformationModel.compName = selectComponent.element.nativeElement.id;
        const formValue = this.shipmentInformation.get(this.shipmentinformationModel.compName).value;
        if (formValue && formValue.length === 0 && event.innerText === '') {
            this.shipmentInformation.get(this.shipmentinformationModel.compName).markAsTouched();
            if (this.shipmentinformationModel.compName === 'orderSubTypeCode' && this.shipmentinformationModel.orderSubTypeFlag) {
                this.shipmentInformation.get(this.shipmentinformationModel.compName).setErrors({
                    'mandatory': true
                });
            }
            if (selectComponent.active.length > 0) {
                selectComponent.active = [];
            }
            if (this.shipmentinformationModel.compName === 'orderTypeCode' ||
                this.shipmentinformationModel.compName === 'bondHolder' ||
                this.shipmentinformationModel.compName === 'portOfExit') {
                this.onClearOrChangeSelValue(this.shipmentinformationModel.compName);
            }
        }
    }
    onClearOrChangeSelValue(compName) {
        if (compName === 'orderTypeCode') {
            this.onClearValue('orderSubTypeCode');
            this.shipmentInformation.controls.orderSubTypeCode.setValue('');
            this.shipmentinformationModel.orderData.orderSubTypeCode = null;
        }
        if (compName === 'bondHolder') {
            this.shipmentinformationModel.bondHolderPartyList = [];
            this.onClearValue('bondHolderCarrierName');
            this.shipmentInformation.controls.bondHolderCarrierName.setValue('');
            this.shipmentinformationModel.orderData.internationalOrderElement[0].bondHolderCarrierName = null;
        }
        if (compName === 'portOfExit') {
            this.onClearValue('portOfEntry');
            this.shipmentInformation.controls.portOfEntry.setValue('');
            this.shipmentinformationModel.orderData.internationalOrderElement[0].portOfEntry = null;
        }
        this.orderService.saveData(this.shipmentinformationModel.orderData);
    }
    onClearValue(component) {
        this.shipmentInformation.get(component).setValidators([]);
        this.shipmentInformation.get(component).updateValueAndValidity();
        this.shipmentInformation.get(component).setValue('');
    }
    // service call
    loadOrderType(value): void {
        const params = {
            'financeBusinessUnitCode': this.shipmentinformationModel.businessUnitValue,
            'serviceOfferingCode': this.shipmentinformationModel.serviceOfferingValue
        };
        this.shipmentinformationService.getOrderType(params).subscribe(data => {
            const orderTypeLists = data['_embedded']['orderTypeFinanceBusinessUnitServiceOfferingAssociations'];
            this.shipmentinformationModel.orderTypeList = [];
            for (const ordrtyp of orderTypeLists) {
                this.shipmentinformationModel.orderTypeList.push({
                    'id': ordrtyp.orderType.orderTypeCode,
                    'text': ordrtyp.orderType.orderTypeDescription
                });
                if (!this.jbhGlobals.utils.isEmpty(value) && value === ordrtyp.orderType.orderTypeCode) {
                    this.shipmentInformation.controls.orderTypeCode.setValue([{
                        'id': value,
                        'text': ordrtyp.orderType.orderTypeDescription
                    }]);
                    this.shipmentinformationModel.orderData.orderTypeCode = value;
                    this.shipmentinformationModel.orderType = value;
                    this.shipmentInformation.controls['orderTypeCode'].setErrors(null);
                    this.loadSecondaryOrderType(this.shipmentinformationModel.orderData.orderSubTypeCode);
                }
            }
        });
    }
    loadSecondaryOrderType(value): void {
        if (!this.isCurrViewTemplate) {
            const params = {
                'businessUnit': this.shipmentinformationModel.businessUnitValue,
                'serviceOffering': this.shipmentinformationModel.serviceOfferingValue,
                'orderTypeCode': this.shipmentinformationModel.orderType
            };
            this.shipmentinformationService.getSecOrderType(params).subscribe(data => {
                const secondaryOrderTypeLists = data;
                this.shipmentinformationModel.secondaryOrderTypeList = [];
                for (const ordersub of secondaryOrderTypeLists) {
                    this.shipmentinformationModel.secondaryOrderTypeList.push({
                        'id': ordersub['orderSubType']['orderSubTypeCode'],
                        'text': ordersub['orderSubType']['orderSubTypeDescription']
                    });
                    if (!this.jbhGlobals.utils.isEmpty(value) &&
                        value === ordersub['orderSubType']['orderSubTypeCode'] && !this.isCurrViewTemplate) {
                        this.shipmentInformation.controls.orderSubTypeCode.setValue([{
                            'id': value,
                            'text': ordersub['orderSubType']['orderSubTypeDescription']
                        }]);
                    }
                }
            });
        }
    }
    loadShipmentRequirement(): void {
        this.shipmentinformationService.getShipmentRequirement().subscribe(data => {
            const arr = data;
            this.shipmentinformationModel.shipmentRequirementList = [];
            for (const value of arr) {
                if (!this.isCurrViewTemplate) {
                    this.shipmentinformationModel.shipmentRequirementList.push({ 'id': value, 'text': value });
                } else {
                    const str = '' + value;
                    if (str !== 'Volume Shipment' && str !== 'Trade Show') {
                        this.shipmentinformationModel.shipmentRequirementList.push({ 'id': value, 'text': value });
                    }
                }
            }
            if (this.isCurrViewTemplate) {
                this.populateData();
            }
            if (!this.shipmentinformationModel.flatbedFlag) {
                this.shipmentinformationModel.shipmentRequirementList.push({ 'id': 'Refrigerated', 'text': 'Refrigerated' });
                this.shipmentinformationModel.shipmentRequirementList.push({ 'id': 'Temperature Control', 'text': 'Temperature Control' });
            }
        });
    }
    loadCarrierName(value, booleanVal): void {
        const params = {
            'query': value,
            'limit': 20
        };
        this.shipmentinformationService.getCarrierName(params).subscribe(data => {
            (booleanVal) ? this.shipmentinformationModel.carrierNameList = data :
                this.shipmentinformationModel.volumecarrierNameList = data;
        });
    }
    loadCustomsBroker(value): void {
        const timestamp = moment(new Date()).format('YYYY-MM-DDTHH:mm:ss.SSS') + 'Z';
        const params = {
            'size': 6,
            '_source': [
                'OrganizationName',
                'PartyID',
                'CustomerCode',
                'partyaddresses.AddressLine1',
                'partyaddresses.AddressLine2',
                'partyaddresses.CityName',
                'partyaddresses.StateName',
                'partyaddresses.CountryName',
                'partyaddresses.PostalCode',
                'partyaddresses.PartyRoleTypeDescription',
                'ExpirationTimestamp',
                'OrganizationStatusTypeCode'
            ],
            'query': {
                'bool': {
                    'filter': {
                        'bool': {
                            'should': [
                                {
                                    'range': {
                                        'ExpirationTimestamp': {
                                            'lte': '2111-01-01T05:59:59.453Z'
                                        }
                                    }
                                },
                                {
                                    'range': {
                                        'ExpirationTimestamp': {
                                            'gte': timestamp
                                        }
                                    }
                                }
                            ],
                            'minimum_should_match': 2
                        }
                    },
                    'should': [
                        {
                            'query_string': {
                                'fields': [
                                    'OrganizationName^6',
                                    'CustomerCode^3'
                                ],
                                'query': value + '*',
                                'default_operator': 'and'
                            }
                        },
                        {
                            'nested': {
                                'path': 'partyaddresses',
                                'query': {
                                    'query_string': {
                                        'fields': [
                                            'partyaddresses.AddressLine1^18',
                                            'partyaddresses.AddressLine2^18',
                                            'partyaddresses.CityName^15',
                                            'partyaddresses.StateName^12',
                                            'partyaddresses.PostalCode^9',
                                            'partyaddresses.CountryName',
                                            'OrganizationName'
                                        ],
                                        'query': value + '*',
                                        'default_operator': 'and'
                                    }
                                },
                                'inner_hits': {
                                    'size': 1,
                                    '_source': {
                                        'includes': [
                                            'partyaddresses.AddressLine1',
                                            'partyaddresses.AddressLine2',
                                            'partyaddresses.CityName',
                                            'partyaddresses.StateName',
                                            'partyaddresses.CountryName',
                                            'partyaddresses.PostalCode',
                                            'partyaddresses.PartyRoleTypeDescription'
                                        ]
                                    }
                                }
                            }
                        }
                    ],
                    'minimum_should_match': 1,
                    'must': [
                        {
                            'query_string': {
                                'default_field': 'OrganizationStatusTypeCode.keyword',
                                'query': 'Approved'
                            }
                        },
                        {
                            'nested': {
                                'path': 'partyaddresses',
                                'query': {
                                    'match': {
                                        'partyaddresses.PartyRoleTypeDescription.keyword': 'Customs Broker'
                                    }
                                }
                            }
                        }
                    ]
                }
            }
        }

        this.shipmentinformationService.getCustomsBroker(params).subscribe(data => {
            // this.shipmentinformationModel.customsBrokerList = data['profileDTO'];
            if (!this.jbhGlobals.utils.isEmpty(data) && data['hits']['hits'].length > 0) {
                this.shipmentinformationModel.customsBrokerList = [];
                this.jbhGlobals.utils.map(data['hits']['hits'], (items) => {
                    const obj = {};
                    const source = items['_source']['partyaddresses'][0];
                    obj['name'] = source['AddressLine1'] + ' ' + source['AddressLine2'] + ', ' +
                        source['CityName'] + ', ' + source['StateName'] + ', ' + source['PostalCode'] + ', ' +
                        source['CountryName'] + ', ' + items['_source']['OrganizationName']
                        + ' (' + ((items['_source']['CustomerCode']) ? items['_source']['CustomerCode'] : '') + ')';
                    obj['partyId'] = items['_source']['PartyID'];
                    obj['addressDTO'] = items['_source']['partyaddresses'][0];
                    obj['orgName'] = items['_source']['OrganizationName'];
                    this.shipmentinformationModel.customsBrokerList.push(obj);
                });
            } else {
                this.shipmentinformationModel.customsBrokerList = [];
                this.shipmentinformationModel.customsBrokerList.push({});
            }
        });
    }
    loadClearingCustoms(populateFlag): void {
        const params = {
            'projection': 'clearanceCountry'
        };
        this.shipmentinformationService.getClearingCustoms(params).subscribe(data => {
            const clearingCustomsLists = data['_embedded']['clearanceCountries'];
            this.shipmentinformationModel.clearingCustomsList = [];
            for (const clearingCountry of clearingCustomsLists) {
                this.shipmentinformationModel.clearingCustomsList.push({
                    'id': clearingCountry.clearanceCountryCode, 'text': clearingCountry.clearanceCountryName
                });
            }
            if (populateFlag) {
                this.shipmentinformationModel.customsBrokerDetails = this.loadCustomBroker();
            }
        });
    }
    loadInternationalServices(interService): void {
        const params = {
            'serviceCategoryCode': 'IOS'
        };
        this.shipmentinformationService.getInternationalServices(params).subscribe(data => {
            const internationalServices = data['_embedded']['serviceTypes'];
            this.shipmentinformationModel.internationalServicesList = [];
            this.internationalServiceTag.active = [];
            for (const intServ of internationalServices) {
                this.shipmentinformationModel.internationalServicesList.push({
                    'id': intServ.serviceTypeCode, 'text': intServ.serviceTypeDescription
                });
                if (!this.jbhGlobals.utils.isEmpty(interService) && this.jbhGlobals.utils.isArray(interService) &&
                    interService.length > 0) {
                    for (const setValueObj of interService) {
                        if (!this.jbhGlobals.utils.isEmpty(setValueObj.serviceType) &&
                            setValueObj.serviceType === intServ.serviceTypeCode) {
                            this.internationalServiceTag.active.push({
                                'id': setValueObj.serviceType, 'text': intServ.serviceTypeDescription
                            });
                        }
                    }
                }
            }
        });
    }
    loadBondHolderRole(value): void {
        const params = {
            'businessUnit': this.shipmentinformationModel.businessUnitValue,
            'transitMode': this.shipmentinformationModel.transitMode
        };
        this.shipmentinformationService.getBondHolderRole(params).subscribe(data => {
            const bondHolderList = data;
            this.shipmentinformationModel.bondHolderRoleList = [];
            for (const bondRole of bondHolderList) {
                this.shipmentinformationModel.bondHolderRoleList.push({
                    'id': bondRole['bondHolderCode'], 'text': bondRole['bondHolderDescription']
                });
                if (!this.jbhGlobals.utils.isEmpty(value) && value === bondRole['bondHolderCode']) {
                    this.shipmentInformation.controls.bondHolder.setValue([{
                        'id': value, 'text': bondRole['bondHolderDescription']
                    }]);
                }
            }
        });
    }
    loadBondHolderParty(value): void {
        const params = {
            'bondHolderCode': this.shipmentinformationModel.selectedBondHolderRoleCode
        };
        this.shipmentinformationService.getBondHolderParty(params).subscribe(data => {
            const bondHolderParty = data['_embedded']['bondHolderCarriers'];
            this.shipmentinformationModel.bondHolderPartyList = [];
            for (const bondParty of bondHolderParty) {
                this.shipmentinformationModel.bondHolderPartyList.push({
                    'id': bondParty['bondHolderCarrierName'], 'text': bondParty['bondHolderCarrierTypeDescription']
                });
                if (!this.jbhGlobals.utils.isEmpty(value) && value === bondParty['bondHolderCarrierName']) {
                    this.shipmentInformation.controls.bondHolderCarrierName.setValue([{
                        'id': value, 'text': bondParty['bondHolderCarrierTypeDescription']
                    }]);
                }
            }
        });
    }
    loadBondHolderTypes(value): void {
        this.shipmentinformationService.getBondHolderTypes().subscribe(data => {
            const bondHolderTypes = data['_embedded']['bondTypes'];
            this.shipmentinformationModel.bondHolderTypesList = [];
            for (const bondTypes of bondHolderTypes) {
                this.shipmentinformationModel.bondHolderTypesList.push({
                    'id': bondTypes['bondTypeCode'], 'text': bondTypes['bondTypeDescription']
                });
                if (!this.jbhGlobals.utils.isEmpty(value) && value === bondTypes['bondTypeCode']) {
                    this.shipmentInformation.controls.bondType.setValue([{
                        'id': value, 'text': bondTypes['bondTypeDescription']
                    }]);
                }
            }
        });
    }
    loadPortOfExit(value): void {
        this.shipmentinformationService.getPortOfExit().subscribe(data => {
            const portOfExit = data;
            this.shipmentinformationModel.portOfExitList = [];
            for (const portExit of portOfExit) {
                this.shipmentinformationModel.portOfExitList.push({ 'id': portExit['code'], 'text': portExit['description'] });
                if (value && value === portExit['code']) {
                    this.shipmentInformation.controls.portOfExit.setValue([{ 'id': value, 'text': portExit['description'] }]);
                }
            }
        });
    }
    loadPortOfEntryByExit(value, populatevalue): void {
        this.shipmentinformationService.getPortOfEntryByExit(value).subscribe(data => {
            const portOfEntry = data;
            this.shipmentinformationModel.portOfEntryList = [];
            for (const portEntry of portOfEntry) {
                this.shipmentinformationModel.portOfEntryList.push({ 'id': portEntry['code'], 'text': portEntry['description'] });
                if (populatevalue && populatevalue === portEntry['code']) {
                    this.shipmentInformation.controls.portOfEntry.setValue([{ 'id': portEntry['code'], 'text': portEntry['description'] }]);
                }
            }
        });
    }
    loadFleetCode(value): void {
        const params = {
            'businessunit': this.shipmentinformationModel.businessUnitValue,
            'fleetcode': value
        };
        this.shipmentinformationService.getFleetCode(params).subscribe(data => {
            this.shipmentinformationModel.fleetCodeList = [];
            this.jbhGlobals.utils.map(data, (item) => {
                const obj = {
                    'code': item['id'].trim() + ' ' + item['description'].trim(),
                    'id': item['id'].trim(), 'desc': item['description'].trim()
                };
                this.shipmentinformationModel.fleetCodeList.push(obj);
            });
        });
    }
    // functionality
    onSelectOrderType(event): void {
        this.shipmentinformationModel.orderType = event.id;
        this.shipmentinformationModel.returnOrderFlag = false;
        switch (event.id) {
            case 'Standard':
                this.shipmentinformationModel.rmaorderflag = false;
                this.orderSubTypeSetValidation(false);
                break;
            case 'Return':
                this.shipmentinformationModel.returnOrderFlag = true;
                this.orderSubTypeSetValidation(false);
                this.rmaNumberDisplay();
                break;
            case 'Other':
                this.orderSubTypeSetValidation(true);
                this.shipmentinformationModel.rmaorderflag = false;
                break;
            default:
                break;
        }
        this.shipmentinformationModel.orderData.orderTypeCode = event.id;
        this.orderService.saveData(this.shipmentinformationModel.orderData);
        this.loadSecondaryOrderType(null);
        if (!this.isCurrViewTemplate) {
            this.shipmentInformation.controls.orderSubTypeCode.setValue('');
        }
    }
    onSelectOrderSubType(event): void {
        this.shipmentinformationModel.orderData.orderSubTypeCode = event.id;
        this.orderService.saveData(this.shipmentinformationModel.orderData);
        this.rmaNumberDisplay();
    }
    rmaNumberDisplay() {
        if ((this.shipmentinformationModel.ICSLTLflag && this.shipmentinformationModel.orderData.orderSubTypeCode === 'CON') ||
            (this.shipmentinformationModel.DCSFMSflag)) {
            if (this.shipmentinformationModel.returnOrderFlag) {
                this.updateRMAOrderflag(true);
            }
            this.shipmentinformationModel.fleetcodeflag = false;
            this.shipmentinformationModel.maritimeflag = false;
        } else {
            this.shipmentinformationModel.fleetcodeflag = true;
            this.updateRMAOrderflag(false);
        }
    }
    updateRMAOrderflag(flag) {
        this.shipmentInformation.get('rmaNumber').setValidators(flag ? [this.jbhGlobals.customValidator.mandatory,
        this.jbhGlobals.customValidator.alphaNumeric,
        Validators.maxLength(30)] : [this.jbhGlobals.customValidator.alphaNumeric,
        Validators.maxLength(30)]);
        this.shipmentInformation.get('rmaNumber').updateValueAndValidity();
        this.shipmentinformationModel.rmaorderflag = flag;
    }
    orderSubTypeSetValidation(booleanVal): void {
        const subTyp = this.shipmentInformation.get('orderSubTypeCode');
        subTyp.setValidators(booleanVal ? [this.jbhGlobals.customValidator.mandatory] : []);
        this.shipmentinformationModel.orderSubTypeFlag = true;
        subTyp.setErrors(booleanVal ? { 'mandatory': true } : null);
        subTyp.updateValueAndValidity();
    }
    onShipmentRequirementTagSelection(e, precool, operating, booleanvalue): void {
        switch (e.text) {
            case 'High Value Shipment':
                this.orderValueSetValidation(booleanvalue);
                this.shipmentinformationModel.orderData.orderValueTypeCode = booleanvalue ? 'High' : null;
                this.orderService.saveData(this.shipmentinformationModel.orderData);
                break;
            case 'Trade Show':
                this.orderValueSetValidation(false);
                this.shipmentinformationModel.tradeshow = booleanvalue;
                if (this.shipmentinformationModel.tradeshow) {
                    this.jbhGlobals.notifications.alert('Warning',
                        'Standard rates will not apply');
                }
                this.tradeShowSetValidation();
                break;
            case 'Volume Shipment':
                this.orderValueSetValidation(false);
                this.shipmentinformationModel.volship = booleanvalue;
                if (this.shipmentinformationModel.volship) {
                    this.jbhGlobals.notifications.alert('Warning',
                        'Standard rates will not apply and delayed pickup and delivery should be expected');
                }
                this.volumeShipmentSetValidation();
                break;
            case 'Temperature Control':
                this.orderValueSetValidation(false);
                this.shipmentinformationModel.tempcontrol = booleanvalue;
                if (booleanvalue) {
                    this.onLoadOperating(operating);
                    this.preCoolAutoFlag(precool);
                    this.loadTemperatureArray();
                } else {
                    this.shipmentinformationModel.operatingflag = false;
                    this.onClickCancelTempZone(true);
                    this.shipmentinformationModel.otemperaturezone = [];
                    this.shipmentinformationModel.otemperaturezoneinFah = [];
                    this.shipmentinformationModel.precoolflag = false;
                    this.onClickCancelTempZone(false);
                    this.shipmentinformationModel.ptemperaturezone = [];
                    this.shipmentinformationModel.ptemperaturezoneinFah = [];
                }
                break;
            case 'International Shipment':
                this.shipmentinformationModel.intship = booleanvalue;
                this.orderValueSetValidation(false);
                if (this.shipmentinformationModel.intship) {
                    this.loadInternationalServices(null);
                } else {
                    this.shipmentInformation['controls']['serviceType'].setValue(null);
                    this.shipmentInformation['controls']['serviceType'].reset();
                    this.inbondfreight(false);
                    this.inbondCheckbox.nativeElement.checked = false;
                    this.shipmentinformationModel.addcustombrokerflag = false;
                    this.shipmentinformationModel.orderData.internationalService = [];
                    this.shipmentinformationModel.customsBrokerDetails = [];
                    this.shipmentinformationModel.orderData.orderCrossesBorderDetailDTOs = [];
                    this.shipmentinformationModel.orderData.internationalOrderElement = [];
                    this.orderService.saveData(this.shipmentinformationModel.orderData);
                }
                break;
            case 'Refrigerated':
                this.orderValueSetValidation(false);
                this.shipmentinformationModel.refrigerated = booleanvalue;
                this.saveRefrigeratedIndicatorValue(booleanvalue);
                this.orderService.saveData(this.shipmentinformationModel.orderData);
                this.preCoolAutoFlag(precool);
                break;
            case 'Food Safety':
                this.orderValueSetValidation(false);
                this.shipmentinformationModel.foodsafety = booleanvalue;
                if (!this.jbhGlobals.utils.isArray(this.shipmentinformationModel.orderData.orderFoodSafetyDetails)) {
                    this.shipmentinformationModel.orderData.orderFoodSafetyDetails = [];
                }
                if (booleanvalue) {
                    const obj = {
                        orderFoodSafetyDetailID: 1
                    };
                    this.shipmentinformationModel.orderData.orderFoodSafetyDetails.push(obj);
                    this.orderService.saveData(this.shipmentinformationModel.orderData);
                } else {
                    this.shipmentinformationModel.orderData.orderFoodSafetyDetails = [];
                    this.orderService.saveData(this.shipmentinformationModel.orderData);
                }
                this.preCoolAutoFlag(precool);
                break;
            default:
                break;
        }
    }
    tradeShowSetValidation(): void {
        this.carrierDetailsSetValidation(this.shipmentinformationModel.tradeshowarray,
            this.shipmentinformationModel.tradeshow, 'carrierName', 'TrdShwShip');
    }
    volumeShipmentSetValidation(): void {
        this.carrierDetailsSetValidation(this.shipmentinformationModel.volshiparray,
            this.shipmentinformationModel.volship, 'volcarrierName', 'VolShip');
    }
    carrierDetailsSetValidation(array, flag, formName, typeCode) {
        for (const control of array) {
            if (!flag) {
                this.shipmentInformation.get(control).setValidators(
                    control === formName ? [] : [Validators.maxLength(30)]);
                this.shipmentInformation['controls'][control]['setValue']('');
            } else {
                this.shipmentInformation.get(control).setValidators(
                    control === formName ? [this.jbhGlobals.customValidator.mandatory] : [this.jbhGlobals.customValidator.mandatory,
                    Validators.maxLength(30)
                    ]);
            }
            this.shipmentInformation.get(control).updateValueAndValidity();
            this.shipmentInformation['controls'][control].reset();
        }
        if (!flag) {
            if (this.jbhGlobals.utils.isArray(this.shipmentinformationModel.orderData.orderCarrierDetailDTOs) &&
                this.shipmentinformationModel.orderData.orderCarrierDetailDTOs.length > 0) {
                for (let i = 0; i < this.shipmentinformationModel.orderData.orderCarrierDetailDTOs.length; i++) {
                    if (this.shipmentinformationModel.orderData.orderCarrierDetailDTOs[i]
                    ['orderCarrierDetail'].orderVolumeTradeShowTypeCode === typeCode) {
                        this.shipmentinformationModel.orderData.orderCarrierDetailDTOs.splice(i, 1);
                    }
                }
            }
        }
    }
    saveRefrigeratedIndicatorValue(booleanvalue): void {
        this.shipmentinformationModel.orderData.orderRefrigeratedIndicator = booleanvalue ? 'Y' : 'N';
    }
    orderValueSetValidation(booleanVal): void {
        const orderValue = this.shipmentInformation.controls['orderValueAmount'];
        orderValue.setValidators(booleanVal ? [this.jbhGlobals.customValidator.mandatory,
        this.jbhGlobals.customValidator.decimalNumber, Validators.maxLength(20)
        ] : [this.jbhGlobals.customValidator.decimalNumber, Validators.maxLength(20)]);
        this.shipmentInformation.get('orderValueAmount').updateValueAndValidity();
    }
    onCarrierDetailSelect(isTradeShowFlag, quote, booth, event?: any): void {
        if (!this.jbhGlobals.utils.isArray(this.shipmentinformationModel.orderData.orderCarrierDetailDTOs)) {
            this.shipmentinformationModel.orderData.orderCarrierDetailDTOs = [];
        }
        if (event) {
            isTradeShowFlag ? this.shipmentinformationModel.tscarrierId = event.item.carrierID :
                this.shipmentinformationModel.vscarrierId = event.item.carrierID;
            isTradeShowFlag ? this.shipmentinformationModel.carrierNameList = [] :
                this.shipmentinformationModel.volumecarrierNameList = [];
        }
        if (isTradeShowFlag) {
            if (quote.value && booth.value && this.shipmentinformationModel.tscarrierId) {
                this.setCarrierDetailsValues('TrdShwShip', 'tscarrierId', quote.value, booth.value);
            }
        } else {
            if (quote.value && this.shipmentinformationModel.vscarrierId) {
                this.setCarrierDetailsValues('VolShip', 'vscarrierId', quote.value);
            }
        }
    }
    setCarrierDetailsValues(typeCode, carrierId, quoteValue, boothValue?) {
        if (this.shipmentinformationModel.orderData.orderCarrierDetailDTOs.length > 0) {
            const carrierDetailsArray = this.shipmentinformationModel.orderData.orderCarrierDetailDTOs;
            for (let i = 0; i < carrierDetailsArray.length; i++) {
                if (carrierDetailsArray[i].orderCarrierDetail.orderVolumeTradeShowTypeCode === typeCode) {
                    carrierDetailsArray[i].orderCarrierDetail.carrierQuoteNumber = quoteValue;
                    carrierDetailsArray[i].orderCarrierDetail.carrierBoothNumber = boothValue ? boothValue : null;
                    carrierDetailsArray[i].orderCarrierDetail.carrierName = this.shipmentinformationModel[carrierId];
                } else {
                    this.carrierDetailsObjectCreation(this.shipmentinformationModel[carrierId], quoteValue, boothValue);
                }
            }
        } else {
            this.carrierDetailsObjectCreation(this.shipmentinformationModel[carrierId], quoteValue, boothValue);
        }
        this.orderService.saveData(this.shipmentinformationModel.orderData);
    }
    carrierDetailsObjectCreation(carrierId, quoteValue, boothValue?: any): void {
        const obj = {
            'orderCarrierDetail': {
                'orderCarrierDetailID': '',
                'orderVolumeTradeShowTypeCode': boothValue ? 'TrdShwShip' : 'VolShip',
                'carrierName': carrierId,
                'carrierQuoteNumber': quoteValue,
                'carrierBoothNumber': boothValue ? boothValue : null
            }
        };
        if (this.jbhGlobals.utils.findIndex(this.shipmentinformationModel.orderData.orderCarrierDetailDTOs, obj) === -1) {
            this.shipmentinformationModel.orderData.orderCarrierDetailDTOs.push(obj);
        }
    }
    createInternationalOrderElement(): void {
        const obj = {
            'bondHolder': null,
            'bondHolderCarrierName': null,
            'bondNumber': '',
            'bondType': null,
            'entryNumber': '',
            'portOfEntry': null,
            'portOfExit': null,
            'vesselNumber': null,
            'voyageNumber': null
        };
        this.shipmentinformationModel.orderData.internationalOrderElement.push(obj);
    }
    inbondfreight(check: boolean): void {
        this.shipmentinformationModel.inbondflag = check;
        const arr = ['bondHolder', 'bondNumber', 'entryNumber'];
        if (check) {
            for (const control of arr) {
                this.shipmentInformation.get(control).setValidators(control === 'bondHolder' ?
                    [this.jbhGlobals.customValidator.mandatory] : [Validators.maxLength(20)]);
                this.shipmentInformation.get(control).updateValueAndValidity();
            }
            this.loadBondHolderRole(null);
            this.loadBondHolderTypes(null);
            if (this.shipmentinformationModel.railintactserviceflag === true) {
                this.loadPortOfExit(null);
            }
        } else {
            for (const control of arr) {
                this.shipmentInformation.get(control).setValidators(control === 'bondHolder' ? [] : [Validators.maxLength(20)]);
                this.shipmentInformation.get(control).updateValueAndValidity();
            }
            const inbondFreightArray = ['bondHolder', 'bondHolderCarrierName', 'bondType', 'portOfExit',
                'portOfEntry', 'vesselNumber', 'voyageNumber', 'bondNumber', 'entryNumber'];
            for (const formControl of inbondFreightArray) {
                this.shipmentInformation['controls'][formControl].setValue('');
                this.shipmentInformation['controls'][formControl].reset();
            }
        }
    }
    onChangeInternationalService(event, isSelectFlag): void {
        const internationalServiceArray = this.shipmentinformationModel.orderData.internationalService;
        if (this.jbhGlobals.utils.isEmpty(internationalServiceArray)) {
            this.shipmentinformationModel.orderData.internationalService = [];
        }
        const obj = {
            'serviceLevelTypeCode': 'IOS',
            'serviceType': event.id,
            '@type': 'InternationalService',
            'lastUpdateTimestampString': null,
            'serviceCount': null,
            'serviceID': null,
            'unitOfServiceMeasurementCode': null
        };
        const intArray = JSON.parse(JSON.stringify(this.shipmentinformationModel.orderData.internationalService));
        for (let i = 0; i < intArray.length; i++) {
            intArray[i].lastUpdateTimestampString = null;
            intArray[i].serviceID = null;
            intArray[i].serviceCount = null;
            intArray[i].unitOfServiceMeasurementCode = null;
        }
        if (this.jbhGlobals.utils.findIndex(intArray, obj) === -1) {
            this.shipmentinformationModel.orderData.internationalService.push(obj);
        } else {
            if (!isSelectFlag) {
                this.shipmentinformationModel.orderData.internationalService.splice(this.jbhGlobals.utils.findIndex(intArray, obj), 1);
            }
        }
        this.orderService.saveData(this.shipmentinformationModel.orderData);

    }
    onSelectBondHolderRole(event): void {
        this.shipmentinformationModel.selectedBondHolderRoleCode = event.id;
        this.shipmentInformation.controls.bondHolderCarrierName.setValue(null);
        this.saveChangedInternationalOrderValue(event.id, 'bondHolder');
        this.loadBondHolderParty(null);
    }
    onSelectBondHolderParty(event): void {
        this.saveChangedInternationalOrderValue(event.id, 'bondHolderCarrierName');
    }
    onSelectBondType(event): void {
        this.saveChangedInternationalOrderValue(event.id, 'bondType');
    }
    onChangePortOfEntry(event): void {
        this.saveChangedInternationalOrderValue(event.id, 'portOfEntry');
    }
    onChangePortOfExit(event): void {
        this.saveChangedInternationalOrderValue(event.id, 'portOfExit');
        this.shipmentInformation.controls.portOfEntry.setValue('');
        this.loadPortOfEntryByExit(event.id, null);
    }
    onSelectFleetCode(value): void {
        this.shipmentInformation.get('fleetCode').setValidators([]);
        this.shipmentInformation.get('fleetCode').updateValueAndValidity();
        const fleetCodeObj = this.transform(this.shipmentinformationModel.fleetCodeList, value)[0];
        this.shipmentInformation['controls']['fleetCode']['setValue'](fleetCodeObj['desc'].trim());
        if (!this.jbhGlobals.utils.isArray(this.shipmentinformationModel.orderData.orderOperationalElementDTOs)) {
            this.shipmentinformationModel.orderData.orderOperationalElementDTOs = [];
        }
        if (this.shipmentinformationModel.orderData.orderOperationalElementDTOs &&
            this.jbhGlobals.utils.isArray(this.shipmentinformationModel.orderData.orderOperationalElementDTOs)) {
            if (this.shipmentinformationModel.orderData.orderOperationalElementDTOs.length === 0) {
                const obj = {
                    'orderOperationalElement': {
                        'fleetCode': ''
                    }
                };
                this.shipmentinformationModel.orderData.orderOperationalElementDTOs.push(obj);
            }
            if (this.isCurrViewTemplate) {
                this.shipmentinformationModel.orderData.orderOperationalElementDTOs[0]['description'] = fleetCodeObj['desc'];
            }
            this.shipmentinformationModel.orderData.orderOperationalElementDTOs[0]['orderOperationalElement']
            ['fleetCode'] = fleetCodeObj['id'].trim();
            this.orderService.saveData(this.shipmentinformationModel.orderData);
        }
        this.shipmentinformationModel.fleetCodeList = [];
    }

    transform(items: any[], args: string): any {
        return items.filter(item => item.code.toLowerCase().trim().indexOf(args.toLowerCase().trim()) !== -1);
    }

    onTemperatureSelect(temperature, check): void {
        switch (temperature.id) {
            case 'pre-cool-temperature':
                this.shipmentinformationModel.precoolflag = check;
                if (check === false) {
                    this.shipmentinformationModel.ptemperaturezone = [];
                    this.shipmentinformationModel.ptemperaturezoneinFah = [];
                    this.onClickCancelTempZone(false);
                } else {
                    if ((this.jbhGlobals.utils.isEmpty(this.shipmentInformation.controls.frontZonePrecoolTemperature.value)) ||
                        (this.jbhGlobals.utils.isEmpty(this.shipmentInformation.controls.rearZonePrecoolTemperature.value))) {
                        this.shipmentInformation.get('frontZonePrecoolTemperature').setErrors({ 'mandatory': true });
                        this.shipmentInformation.get('rearZonePrecoolTemperature').setErrors({ 'mandatory': true });
                    }
                    if (this.shipmentinformationModel.ptemperaturezone.length === 0) {
                        this.setValidationTemperatureControl(true, this.shipmentinformationModel.precoolflag);
                    }
                }
                break;
            case 'operating-temperature':
                this.shipmentinformationModel.operatingflag = check;
                if (check === false) {
                    this.shipmentinformationModel.otemperaturezone = [];
                    this.shipmentinformationModel.otemperaturezoneinFah = [];
                    this.onClickCancelTempZone(true);
                } else {
                    if ((this.jbhGlobals.utils.isEmpty(this.shipmentInformation.controls.temperatureLowRange.value)) ||
                        (this.jbhGlobals.utils.isEmpty(this.shipmentInformation.controls.temperatureHighRange.value))) {
                        this.shipmentInformation.get('temperatureLowRange').setErrors({ 'mandatory': true });
                        this.shipmentInformation.get('temperatureHighRange').setErrors({ 'mandatory': true });
                    }
                    if (this.shipmentinformationModel.otemperaturezone.length === 0) {
                        this.setValidationTemperatureControl(true, this.shipmentinformationModel.operatingflag);
                    }
                }
                break;
            default:
                break;
        }
    }
    preCoolAutoFlag(precool): void {
        if (this.shipmentinformationModel.refrigerated === true &&
            this.shipmentinformationModel.foodsafety === true &&
            this.shipmentinformationModel.tempcontrol === true) {
            precool.checked = true;
            this.shipmentinformationModel.precoolflag = true;
            if (this.shipmentinformationModel.ptemperaturezone.length === 0) {
                this.setValidationTemperatureControl(true, this.shipmentinformationModel.precoolflag);
            }
        } else {
            precool.checked = false;
            this.shipmentinformationModel.precoolflag = false;
        }
    }
    onLoadOperating(operating): void {
        operating.checked = true;
        this.shipmentinformationModel.operatingflag = true;
        if (this.shipmentinformationModel.otemperaturezone.length === 0) {
            this.setValidationTemperatureControl(true, this.shipmentinformationModel.operatingflag);
        }
    }
    loadTemperatureArray() {
        const equipmentReqDto = this.shipmentinformationModel.orderData.orderEquipmentRequirementDTOs;
        if (!this.jbhGlobals.utils.isEmpty(equipmentReqDto) && this.jbhGlobals.utils.isArray(equipmentReqDto)) {
            if (equipmentReqDto.length > 0 && !this.jbhGlobals.utils.isEmpty(equipmentReqDto[0].orderEquipmentRequirement)) {
                this.shipmentinformationModel.params = equipmentReqDto[0].orderEquipmentRequirement;
            }
        }
        const paramsAssArray = this.shipmentinformationModel.params['orderEquipmentRequirementSpecificationAssociations'];
        for (const paramsAssObj of paramsAssArray) {
            const paramsSpecArr = paramsAssObj['orderEquipmentRequirementSpecificationDetails'];
            if (paramsSpecArr) {
                for (const paramsSpecObj of paramsSpecArr) {
                    if (!this.jbhGlobals.utils.isEmpty(paramsSpecObj['unitOfTemperatureMeasurementCode'])) {
                        this.shipmentinformationModel.temperatureArray.push(paramsSpecObj);
                    }
                }
                this.createService.setEquipmentRequirementResponse(this.shipmentinformationModel.temperatureArray);
            }
        }
    }
    onClickAddTempZone(booleanValue): void {
        if (booleanValue) { // operating
            this.onDisplayingTemperatureFields('omaximumerrorflag', 'operaddtemperatureflag', booleanValue, 'otemperaturezone');
        } else { // precool
            this.onDisplayingTemperatureFields('maximumerrorflag', 'precooladdtemperatureflag', booleanValue, 'ptemperaturezone');
        }
    }
    onDisplayingTemperatureFields(errorFlag, displayFlag, booleanValue, array): void {
        this.shipmentinformationModel[errorFlag] = false;
        this.shipmentinformationModel[displayFlag] = true;
        if (this.shipmentinformationModel[array].length === 0) {
            this.setValidationTemperatureControl(booleanValue, true);
        } else if (this.shipmentinformationModel[array].length < 2) {
            this.setValidationTemperatureControl(booleanValue, false);
        } else {
            this.shipmentinformationModel[errorFlag] = true;
            this.shipmentinformationModel[displayFlag] = false;
            this.onClickCancelTempZone(booleanValue);
        }
    }
    setValidationTemperatureControl(flag, isNull): void {
        if (flag) {
            this.setErrorValidation('temperatureLowRange', isNull);
            this.setErrorValidation('temperatureHighRange', isNull);
        } else {
            this.setErrorValidation('frontZonePrecoolTemperature', isNull);
            this.setErrorValidation('rearZonePrecoolTemperature', isNull);
        }
    }
    setErrorValidation(control, isNull): void {
        this.shipmentInformation.get(control).setErrors(isNull ? { 'mandatory': true } : null);
        this.shipmentInformation.controls[control].setValidators(isNull ? this.jbhGlobals.customValidator.mandatory : []);
        this.shipmentInformation.controls[control].updateValueAndValidity();
    }
    onBlurAddTempZone(booleanValue): void {
        if (booleanValue) { // operating
            this.shipmentinformationModel.omaximumerrorflag = false;
        } else { // precool
            this.shipmentinformationModel.maximumerrorflag = false;
        }
    }
    onClickCancelTempZone(booleanValue): void {
        if (booleanValue) {
            this.shipmentinformationModel.operaddtemperatureflag = false;
            this.shipmentInformation.controls['temperatureLowRange'].setValue(null);
            this.shipmentInformation.controls['temperatureHighRange'].setValue(null);
            this.shipmentinformationModel.errorflag = false;
            if (this.shipmentinformationModel.otemperaturezone.length === 0) {
                this.setValidationTemperatureControl(booleanValue, this.shipmentinformationModel.operatingflag);
            }
        } else {
            this.shipmentinformationModel.precooladdtemperatureflag = false;
            this.shipmentInformation.controls['frontZonePrecoolTemperature'].setValue('');
            this.shipmentInformation.controls['rearZonePrecoolTemperature'].setValue('');
            this.shipmentinformationModel.precoolerrorflag = false;
            if (this.shipmentinformationModel.ptemperaturezone.length === 0) {
                this.setValidationTemperatureControl(booleanValue, this.shipmentinformationModel.precoolflag);
            }
        }
    }
    showTempInCel(showCel, flag, fromCheckBox): void {
        this.convertFahtoCel(showCel, flag, fromCheckBox);
        this.shipmentinformationModel.ptemperaturezone =
            this.jbhGlobals.utils.uniqWith(this.shipmentinformationModel.ptemperaturezone, this.jbhGlobals.utils.isEqual);
        this.shipmentinformationModel.otemperaturezone =
            this.jbhGlobals.utils.uniqWith(this.shipmentinformationModel.otemperaturezone, this.jbhGlobals.utils.isEqual);
    }
    convertFahtoCel(toCel, flag, fromCheckBox): void {
        if (flag) { // oper
            this.shipmentinformationModel.otemperaturezone = [];
            this.toCelsius(this.shipmentinformationModel.otemperaturezoneinFah, flag, toCel, fromCheckBox);
        } else { // pre
            this.shipmentinformationModel.ptemperaturezone = [];
            this.toCelsius(this.shipmentinformationModel.ptemperaturezoneinFah, flag, toCel, fromCheckBox);
        }
    }
    toCelsius(array, flag, toCel, fromCheckBox): void {
        for (let i = 0; i < array.length; i++) {
            const tempObj = {
                min: null,
                max: null
            };
            if (fromCheckBox) {
                this.saveTemperatureControl(flag, array[i].min, array[i].max, toCel);
            }
            if (toCel) {
                tempObj.min = Math.round((array[i].min - 32) * (5 / 9));
                tempObj.max = Math.round((array[i].max - 32) * (5 / 9));
            } else {
                tempObj.min = array[i].min;
                tempObj.max = array[i].max;
            }
            if (flag) { // operating
                this.shipmentinformationModel.otemperaturezone.push(tempObj);
            } else { // pre cool
                this.shipmentinformationModel.ptemperaturezone.push(tempObj);
            }
        }
    }
    addingTempZone(event, minTempZone, maxTempZone, flag, showCel): void {
        if (!this.jbhGlobals.utils.isEmpty(event.relatedTarget)) {
            if (event.relatedTarget.id === 'pre-cool-cancel-button' || event.relatedTarget.id === 'operating-cancel-button') {
                event.preventDefault();
                this.onClickCancelTempZone(flag);
            } else {
                this.addTempZone(minTempZone, maxTempZone, flag, showCel);
            }
        } else {
            this.addTempZone(minTempZone, maxTempZone, flag, showCel);
        }
    }
    addTempZone(minTempZone, maxTempZone, flag, showCel): void {
        if (!this.jbhGlobals.utils.isEmpty(minTempZone) && !this.jbhGlobals.utils.isEmpty(maxTempZone)) {
            const minVal = parseInt(minTempZone, 10);
            const maxVal = parseInt(maxTempZone, 10);
            if (minVal >= -10 && minVal < 80 && minVal < maxVal && maxVal > -10 && maxVal > minVal && maxVal <= 80) {
                const tempObj = {
                    min: null,
                    max: null
                };
                tempObj.min = minVal;
                tempObj.max = maxVal;
                if (flag) { // operating temperature
                    this.shipmentinformationModel.addoptemperaturezoneflag = true;
                    this.shipmentinformationModel.operaddtemperatureflag = false;
                    this.shipmentinformationModel.otemperaturezoneinFah.push(tempObj);
                    this.shipmentInformation.controls['temperatureLowRange'].setValue('');
                    this.shipmentInformation.controls['temperatureHighRange'].setValue('');
                    this.shipmentinformationModel.errorflag = false;
                } else { // pre cool temperature
                    this.shipmentinformationModel.addtemperaturezoneflag = true;
                    this.shipmentinformationModel.precooladdtemperatureflag = false;
                    this.shipmentinformationModel.ptemperaturezoneinFah.push(tempObj);
                    this.shipmentInformation.controls['frontZonePrecoolTemperature'].setValue('');
                    this.shipmentInformation.controls['rearZonePrecoolTemperature'].setValue('');
                    this.shipmentinformationModel.precoolerrorflag = false;
                }
                this.setValidationTemperatureControl(flag, false);
                this.showTempInCel(showCel, flag, false);
                this.saveTemperatureControl(flag, minVal, maxVal, showCel);
            } else { // error message
                if (flag) {
                    this.shipmentinformationModel.errorflag = true;
                } else {
                    this.shipmentinformationModel.precoolerrorflag = true;
                }
            }
        }
    }

    saveTemperatureControl(flag, minVal, maxVal, showCel?: any): void {
        const obj = {
            'orderEquipmentRequirementSpecificationDetailID': '',
            'temperatureLowRange': '',
            'temperatureHighRange': '',
            'unitOfTemperatureMeasurementCode': '',
            'specificationDetailValue': '',
            'frontZonePrecoolTemperature': '',
            'rearZonePrecoolTemperature': '',
            'lastUpdateTimestampString': ''
        };
        if (flag) {
            obj.temperatureLowRange = minVal.toString();
            obj.temperatureHighRange = maxVal.toString();
        } else {
            obj.frontZonePrecoolTemperature = minVal.toString();
            obj.rearZonePrecoolTemperature = maxVal.toString();
        }
        obj.unitOfTemperatureMeasurementCode = showCel ? 'Celsius' : 'Fahrenheit';
        this.onSaveTemperatureCall(obj, flag);
    }
    onSaveTemperatureCall(obj, flag) {
        let specDetails = this.createService.getEquipmentRequirementResponse();
        if (!this.shipmentinformationModel.params.orderEquipmentRequirementID) {
            this.shipmentinformationModel.params.order = '/' + this.shipmentinformationModel.orderData.orderID;
            if (specDetails.length === 0) {
                specDetails.push(obj);
                specDetails = this.jbhGlobals.utils.uniqWith(specDetails, this.jbhGlobals.utils.isEqual);
                if (this.isCurrViewTemplate) {
                    const specObj = {
                        'equipmentRequirementSpecificationAssociationID': 0,
                        'orderEquipmentRequirementSpecificationDetails': null
                    };
                    specObj.orderEquipmentRequirementSpecificationDetails = [];
                    specObj.orderEquipmentRequirementSpecificationDetails.push(obj);
                    this.shipmentinformationModel.orderData.tempSpec = specObj;
                } else {
                    this.createService.setEquipmentRequirementResponse(specDetails);
                }
            } else {
                this.updateTemperatureControl(obj, specDetails, flag);
            }
        } else {
            this.updateTemperatureControl(obj, specDetails, flag);
        }
    }
    updateTemperatureControl(obj, specDetails, flag) {
        let notSameFlag = true;
        if (specDetails.length > 0) {
            for (let i = 0; i < specDetails.length; i++) {
                if (specDetails[i]['orderEquipmentRequirementSpecificationDetailID']) {
                    if (flag) {
                        if (specDetails[i]['temperatureLowRange'] === parseInt(obj['temperatureLowRange'], 10) &&
                            specDetails[i]['temperatureHighRange'] === parseInt(obj['temperatureHighRange'], 10)) {
                            obj['orderEquipmentRequirementSpecificationDetailID'] =
                                specDetails[i]['orderEquipmentRequirementSpecificationDetailID'];
                            specDetails.splice(i, 1);
                            specDetails.push(obj);
                            notSameFlag = false;
                        }
                    } else {
                        if (specDetails[i]['frontZonePrecoolTemperature'] === parseInt(obj['frontZonePrecoolTemperature'], 10) &&
                            specDetails[i]['rearZonePrecoolTemperature'] === parseInt(obj['rearZonePrecoolTemperature'], 10)) {
                            obj['orderEquipmentRequirementSpecificationDetailID'] =
                                specDetails[i]['orderEquipmentRequirementSpecificationDetailID'];
                            specDetails.splice(i, 1);
                            specDetails.push(obj);
                            notSameFlag = false;
                        }
                    }
                }
            }
        } else {
            specDetails.push(obj);
            notSameFlag = false;
        }
        if (notSameFlag) {
            specDetails.push(obj);
        }
        specDetails = this.jbhGlobals.utils.uniqWith(specDetails, this.jbhGlobals.utils.isEqual);
        if (this.isCurrViewTemplate) {
            const specObj = {
                'equipmentRequirementSpecificationAssociationID': 0,
                'orderEquipmentRequirementSpecificationDetails': null
            };
            specObj.orderEquipmentRequirementSpecificationDetails = specDetails;
            this.shipmentinformationModel.orderData.tempSpec = specObj;
        } else {
            this.createService.setEquipmentRequirementResponse(specDetails);
        }
    }
    onRemoveTempZone(recordIndex, flag): void {
        this.shipmentinformationModel.recordIndex = recordIndex;
        this.shipmentinformationModel.flag = flag;
        this.shipmentinformationModel.confirmMessage = 'Are you sure want to delete this TemperatureZone?';
        this.shipmentinformationModel.deleteElement = 'tempZone';
        this.popInstance.deleteButtonModal.show();
    }
    onTempZoneDelete() {
        let removeArray: any[] = [];
        if (this.shipmentinformationModel.flag) {
            removeArray = this.shipmentinformationModel.otemperaturezoneinFah.splice(this.shipmentinformationModel.recordIndex, 1);
            this.shipmentinformationModel.otemperaturezone.splice(this.shipmentinformationModel.recordIndex, 1);
            this.onRemoveSaveTempZone(this.shipmentinformationModel.flag, removeArray[0].min, removeArray[0].max);
            if (this.shipmentinformationModel.otemperaturezone.length === 0) {
                this.onClickCancelTempZone(this.shipmentinformationModel.flag);
            }
        } else {
            removeArray = this.shipmentinformationModel.ptemperaturezoneinFah.splice(this.shipmentinformationModel.recordIndex, 1);
            this.shipmentinformationModel.ptemperaturezone.splice(this.shipmentinformationModel.recordIndex, 1);
            this.onRemoveSaveTempZone(this.shipmentinformationModel.flag, removeArray[0].min, removeArray[0].max);
            if (this.shipmentinformationModel.ptemperaturezone.length === 0) {
                this.onClickCancelTempZone(this.shipmentinformationModel.flag);
            }
        }
    }
    onDelete(eve) {
        if (eve.flag) {
            (this.shipmentinformationModel.deleteElement === 'tempZone') ? this.onTempZoneDelete() : this.onCustomBrokerDelete();
            eve.model.hide();
        } else {
            eve.model.hide();
        }
    }
    onRemoveSaveTempZone(flag, min, max): void {
        let specDetails = this.createService.getEquipmentRequirementResponse();
        if (this.isCurrViewTemplate && this.shipmentinformationModel.orderData.tempSpec) {
            specDetails = this.shipmentinformationModel.orderData.tempSpec['orderEquipmentRequirementSpecificationDetails'];
        }
        let delflag = false;
        let index: number = null;
        if (flag) {
            for (let i = 0; i < specDetails.length; i++) {
                if ((specDetails[i].temperatureLowRange === min.toString()) &&
                    (specDetails[i].temperatureHighRange === max.toString())) {
                    delflag = true;
                    index = i;
                }
            }
        } else {
            for (let i = 0; i < specDetails.length; i++) {
                if ((specDetails[i].frontZonePrecoolTemperature === min.toString()) &&
                    (specDetails[i].rearZonePrecoolTemperature === max.toString())) {
                    delflag = true;
                    index = i;
                }
            }
        }
        if (delflag) {
            specDetails.splice(index, 1);
            this.createService.setEquipmentRequirementResponse(specDetails);
        }
    }
    onAddAdditionalCustomBroker(): void {
        const arr = ['clearingCountryCode', 'customsbrokercarrier'];
        this.shipmentinformationModel.addcustombrokerflag = this.shipmentinformationModel.customsBrokerDetails.length < 3 ? true : false;
        for (const control of arr) {
            this.setErrorValidation(control, this.shipmentinformationModel.addcustombrokerflag ? true : false);
        }
    }
    onCustomBrokerSelect(e): void {
        const code = e.value.split('(');
        const temp = e.item.addressDTO;
        this.brokerValue = e.item.orgName + ' (' + code[1];
        this.brokVal = temp.AddressLine1 +
            temp.AddressLine2 + ' , ' + temp.CityName + ',' + temp.StateName + ' ,' + temp.PostalCode + ' , ' + temp.CountryName;
        this.shipmentinformationModel.customsbrokerId = e.item.partyId;
        this.shipmentinformationModel.customsBrokerList = [];
        this.shipmentInformation.controls['customsbrokercarrier'].setValue(e.item.name);
        // this.shipmentInformation.controls['customsbrokercarrier'].setValue((e.item.name ? e.item.name : '') +
        //     '-' + (e.item.addressDTO.AddressLine1 ? e.item.addressDTO.AddressLine1 : '') + ' ' +
        //     (e.item.addressDTO.AddressLine2 ? e.item.addressDTO.AddressLine2 : '') + ',' +
        //     (e.item.addressDTO.CityName ? e.item.addressDTO.CityName : '') + ' ' +
        //     (e.item.addressDTO.CountryName ? e.item.addressDTO.CountryName : '') + ' ' +
        //     (e.item.addressDTO.StateName ? e.item.addressDTO.StateName : '') + ' ' +
        //     (e.item.addressDTO.PostalCode ? e.item.addressDTO.PostalCode : '') + ' ' +
        //     (e.item.code ? e.item.partyId : ''));
        this.loadClearingCustoms(false);
        if (this.isCurrViewTemplate) {
            this.shipmentinformationModel.brokerProfile = this.customBrokerFormatter(e.item);
        }
        const params = {
            partyId: this.shipmentinformationModel.customsbrokerId
        };
        this.shipmentinformationService.getOutSourcingFlag(params).subscribe(data => {
            console.log(data);
            const outsourceflag = data;
            if (outsourceflag['outsourcingStatus'] === true) {
                this.shipmentinformationModel.outsourcingVal = 'Outsourcing Allowed';
            } else if (outsourceflag['outsourcingStatus'] === false) {
                this.shipmentinformationModel.outsourcingVal = 'Outsourcing Not Allowed';
            } else {
                this.shipmentinformationModel.outsourcingVal = '';
            }
        });
        const url = this.jbhGlobals.endpoints.order.getCreditStatus + '' + this.shipmentinformationModel.customsbrokerId;
        this.shipmentinformationService.getCreditStatus(url).subscribe(data => {
            console.log(data);
            if (!this.jbhGlobals.utils.isEmpty(data)) {
                // if (data['iscreditstatusapproved'] === true) {
                //     this.shipmentinformationModel.creditStatus = 'Approved';
                // } else if (data['iscreditstatusapproved'] === false) {
                //     this.shipmentinformationModel.creditStatus = 'Not Approved';
                // }
                this.shipmentinformationModel.creditStatus = data['creditStatus'];
            }
        });
    }
    customBrokerFormatter(data) {
        if (data && data['addressDTO'] && data['name']) {
            const value = data['name'].split(',');
            const obj = {
                'addressDTO': {
                    'addressLineOne': data['addressDTO']['AddressLine1'],
                    'addressLineTwo': data['addressDTO']['AddressLine2'],
                    'city': data['addressDTO']['CityName'],
                    'cityID': '',
                    'country': data['addressDTO']['CountryName'],
                    'state': data['addressDTO']['StateName'],
                    'zipCode': data['addressDTO']['PostalCode']
                },
                'contactDTO': {},
                'partyID': data['partyId'],
                'partyName': value[0],
                'partyStatus': '',
                'partyType': ''
            };
            return obj;
        }
    }
    onRemoveCustomBroker(recordIndex): void {
        this.shipmentinformationModel.brokerRecordIndex = recordIndex;
        this.shipmentinformationModel.confirmMessage = 'Are you sure want to delete this Custom Broker?';
        this.shipmentinformationModel.deleteElement = 'customBroker';
        this.popInstance.deleteButtonModal.show();
    }
    onCustomBrokerDelete() {
        const arr = ['clearingCountryCode', 'customsbrokercarrier'];
        this.shipmentinformationModel.customsBrokerDetails.splice(this.shipmentinformationModel.brokerRecordIndex, 1);
        const url = this.jbhGlobals.endpoints.order.savecustomsbroker;
        if (!this.isCurrViewTemplate) {
            this.jbhGlobals.apiService.removeData(url + '/' + this.shipmentinformationModel.ordercrossborderdetailid).subscribe(data => {
            });
        } else {
            this.shipmentinformationModel.orderData.orderCrossesBorderDetailDTOs = this.shipmentinformationModel.customsBrokerDetails;
        }
        if (this.shipmentinformationModel.customsBrokerDetails.length === 0) {
            this.shipmentinformationModel.customsbrokersdisplayflag = false;
            for (const control of arr) {
                this.setErrorValidation(control, false);
            }
        }
    }
    onChangeClearingCustoms(event, customsbroker, clearingscustoms): void {
        const arr = ['clearingCountryCode', 'customsbrokercarrier'];
        if (this.shipmentInformation.controls['customsbrokercarrier'].value && event.text) {
            const customsBrokerObj = {
                custombroker: null,
                clearingcustoms: null
            };
            customsBrokerObj.custombroker = this.shipmentInformation.controls['customsbrokercarrier'].value;
            customsBrokerObj.clearingcustoms = event.text.toUpperCase();
            if (!this.jbhGlobals.utils.find(this.shipmentinformationModel.customsBrokerDetails, customsBrokerObj)) {
                this.shipmentinformationModel.customsErrorFlag = false;
                this.shipmentinformationModel.customsBrokerDetails.push(customsBrokerObj);
            } else {
                this.shipmentinformationModel.customsErrorFlag = true;
            }
            this.shipmentinformationModel.customsBrokerDetails =
                this.jbhGlobals.utils.uniqWith(this.shipmentinformationModel.customsBrokerDetails, this.jbhGlobals.utils.isEqual);
            this.shipmentinformationModel.clearingcountrycode = event.id;
            if (!this.isCurrViewTemplate) {
                if (!this.shipmentinformationModel.customsErrorFlag) {
                    this.saveCustomsBroker();
                } else {
                    this.jbhGlobals.notifications.error('Error', 'Duplicate Customs Broker');
                }
            } else if (!this.shipmentinformationModel.customsErrorFlag) {
                this.orderCrossBorderDetailFormatter(event['text'], clearingscustoms);
            }
            for (const control of arr) {
                this.shipmentInformation.controls[control].setValue('');
                this.setErrorValidation(control, false);
            }
            this.shipmentinformationModel.addcustombrokerflag = false;
            this.shipmentinformationModel.customsbrokersdisplayflag = true;
        }
    }
    orderCrossBorderDetailFormatter(broker, customs): void {
        const obj = {
            'clearingCountryCode': this.shipmentinformationModel.clearingcountrycode,
            'clearingCountryCodeDescription': broker,
            'profileDTO': this.shipmentinformationModel.brokerProfile
        };
        if (!this.shipmentinformationModel.orderData.orderCrossesBorderDetailDTOs) {
            this.shipmentinformationModel.orderData.orderCrossesBorderDetailDTOs = [];
        }
        this.shipmentinformationModel.orderData.orderCrossesBorderDetailDTOs.push(obj);

    }
    saveCustomsBroker(): void {
        const params = {
            'orderCrossBorderDetailID': '',
            'customsBrokerID': this.shipmentinformationModel.customsbrokerId,
            'clearanceCountryCode': this.shipmentinformationModel.clearingcountrycode,
            'order': '/' + this.shipmentinformationModel.orderData.orderID
        };
        this.jbhGlobals.apiService.addData(this.jbhGlobals.endpoints.order.savecustomsbroker, params).subscribe(data => {
            this.shipmentinformationModel.ordercrossborderdetailid = data['orderCrossBorderDetailID'];
        }, (err: Error) => {
            this.jbhGlobals.logger.info(err);
        });
    }
    saveRmaNumber(selectedrmanumber): void {
        if (this.shipmentInformation['valid']) {
            const params = {
                'order': '/' + this.shipmentinformationModel.orderData.orderID,
                'referenceNumberID': '',
                'referenceNumberTypeCode': 'ReturnNbr',
                'referenceNumberLevelTypeCode': 'ORDER',
                'referenceNumberValue': selectedrmanumber,
                'stopId': '',
                '@type': 'OrderReferenceNumber'
            };
            if (!this.isCurrViewTemplate) {
                const url = this.jbhGlobals.endpoints.order.postReferencesType;
                this.jbhGlobals.apiService.addData(url, params).subscribe(data => { }, (err: Error) => {
                    this.jbhGlobals.logger.info(err);
                });
            }
        }
    }
    populateData(): void {
        this.shipmentinformationModel.populateFlag = false;
        if (this.shipmentinformationModel.orderData.orderTypeCode) {
            this.shipmentinformationModel.orderType = this.shipmentinformationModel.orderData.orderTypeCode;
            this.loadOrderType(this.shipmentinformationModel.orderData.orderTypeCode);
        }
        if (this.shipmentinformationModel.orderData.orderSubTypeCode) {
            this.loadSecondaryOrderType(this.shipmentinformationModel.orderData.orderSubTypeCode);
        }
        for (let i = 0; i < this.shipmentinformationModel.array.length; i++) {
            if (this.shipmentinformationModel.orderData[this.shipmentinformationModel.array[i]]) {
                this.shipmentInformation['controls'][this.shipmentinformationModel.array[i]]['setValue']
                    (this.shipmentinformationModel.orderData[this.shipmentinformationModel.array[i]]);
            }
        }
        if (this.shipmentinformationModel.orderData.orderValueTypeCode === 'High') {
            if (this.addTag({ id: 'High Value Shipment', text: 'High Value Shipment' })) {
                this.orderValueSetValidation(true);
            }
        }
        if (this.shipmentinformationModel.orderData.orderRefrigeratedIndicator === 'Y') {
            if (this.addTag({ id: 'Refrigerated', text: 'Refrigerated' })) {
                this.shipmentinformationModel.refrigerated = true;
            }
        }
        const interService = this.shipmentinformationModel.orderData.internationalService;
        const crossBorder = this.shipmentinformationModel.orderData.orderCrossesBorderDetailDTOs;
        const interOrderElem = this.shipmentinformationModel.orderData.internationalOrderElement;
        if (!this.jbhGlobals.utils.isEmpty(interService) &&
            this.jbhGlobals.utils.isArray(interService)) {
            if (interService.length > 0) {
                this.addInternationalTag();
                this.loadInternationalServices(interService);
            }
        }
        if (!this.jbhGlobals.utils.isEmpty(crossBorder) && this.jbhGlobals.utils.isArray(crossBorder)
            && crossBorder.length > 0) {
            this.shipmentinformationModel.customsbrokersdisplayflag = true;
            this.shipmentinformationModel.customsBrokerDetails = [];
            this.addInternationalTag();
            this.loadClearingCustoms(true);
            console.log(this.shipmentinformationModel.orderData.orderCrossesBorderDetailDTOs[0]);
            console.log(this.shipmentinformationModel.orderData.orderCrossesBorderDetailDTOs[0].clearingCountryCode);
        }
        if (!this.jbhGlobals.utils.isEmpty(interOrderElem) && this.jbhGlobals.utils.isArray(interOrderElem) &&
            interOrderElem.length > 0) {
            if (!this.jbhGlobals.utils.isEmpty(interOrderElem[0]['bondHolder'])) {
                this.shipmentinformationModel.inbondflag = true;
                this.shipmentinformationModel.selectedBondHolderRoleCode = interOrderElem[0]['bondHolder'];
                this.addInternationalTag();
                if (this.jbhGlobals.utils.isEmpty(this.shipmentinformationModel.internationalServicesList)) {
                    this.loadInternationalServices(null);
                }
                this.checkTransitMode(interOrderElem[0]['portOfExit']);
                this.shipmentInformation['controls']['inbondFreight']['patchValue'](true);
                for (let i = 0; i < this.shipmentinformationModel.internationalshipmentarray.length; i++) {
                    this.shipmentInformation['controls'][this.shipmentinformationModel.internationalshipmentarray[i]]
                    ['patchValue'](interOrderElem[0][this.shipmentinformationModel.internationalshipmentarray[i]]);
                }
                this.loadBondHolderRole(interOrderElem[0]['bondHolder']);
                this.loadBondHolderParty(interOrderElem[0]['bondHolderCarrierName']);
                this.loadBondHolderTypes(interOrderElem[0]['bondType']);
                if (this.shipmentinformationModel.railintactserviceflag === true) {
                    this.loadPortOfEntryByExit(interOrderElem[0]['portOfExit'], interOrderElem[0]['portOfEntry']);
                }
            }
            if (interOrderElem[0].vesselNumber || interOrderElem[0].voyageNumber) {
                this.shipmentinformationModel.maritimeflag = true;
                this.shipmentInformation['controls']['vesselNumber'].setValue(interOrderElem[0].vesselNumber);
                this.shipmentInformation['controls']['voyageNumber'].setValue(interOrderElem[0].voyageNumber);
            }
        }
        if (!this.jbhGlobals.utils.isEmpty(this.shipmentinformationModel.orderData.orderFoodSafetyDetails) &&
            this.jbhGlobals.utils.isArray(this.shipmentinformationModel.orderData.orderFoodSafetyDetails)) {
            if (this.shipmentinformationModel.orderData.orderFoodSafetyDetails.length > 0) {
                if (this.addTag({ id: 'Food Safety', text: 'Food Safety' })) {
                    this.shipmentinformationModel.foodsafety = true;
                }
            }
        }
        const carrierDetails = this.shipmentinformationModel.orderData.orderCarrierDetailDTOs;
        if (!this.jbhGlobals.utils.isEmpty(carrierDetails) && this.jbhGlobals.utils.isArray(carrierDetails)) {
            for (let i = 0; i < carrierDetails.length; i++) {
                if (carrierDetails[i]['orderCarrierDetail']['orderVolumeTradeShowTypeCode'] === 'TrdShwShip') {
                    if (this.addTag({ id: 'Trade Show', text: 'Trade Show' })) {
                        this.shipmentinformationModel.tradeshow = true;
                        this.tradeShowSetValidation();
                    }
                    for (let j = 0; j < this.shipmentinformationModel.tradeshowarray.length; j++) {
                        if (this.shipmentinformationModel.tradeshowarray[j] === 'carrierName') {
                            this.shipmentInformation['controls']['carrierName']['setValue'](carrierDetails[i]['name']);
                            this.shipmentinformationModel.tscarrierId = carrierDetails[i]['name'];
                        } else {
                            this.shipmentInformation['controls'][this.shipmentinformationModel.tradeshowarray[j]]['setValue']
                                (carrierDetails[i]['orderCarrierDetail'][this.shipmentinformationModel.tradeshowarray[j]]);
                        }
                    }
                } else if (carrierDetails[i]['orderCarrierDetail']['orderVolumeTradeShowTypeCode'] === 'VolShip') {
                    if (this.addTag({ id: 'Volume Shipment', text: 'Volume Shipment' })) {
                        this.shipmentinformationModel.volship = true;
                        this.volumeShipmentSetValidation();
                    }
                    for (let k = 0; k < this.shipmentinformationModel.volshiparray.length; k++) {
                        if (this.shipmentinformationModel.volshiparray[k] === 'volcarrierName') {
                            this.shipmentInformation['controls']['volcarrierName']['setValue'](carrierDetails[i]['name']);
                            this.shipmentinformationModel.tscarrierId = carrierDetails[i]['name'];
                        } else {
                            this.shipmentInformation['controls'][this.shipmentinformationModel.volshiparray[k]]['setValue']
                                (carrierDetails[i]['orderCarrierDetail'][this.shipmentinformationModel.tradeshowarray[k]]);
                        }
                    }
                }
            }
        }
        if (!this.jbhGlobals.utils.isEmpty(this.shipmentinformationModel.orderData.orderBillingDetailDTOs) &&
            this.jbhGlobals.utils.isArray(this.shipmentinformationModel.orderData.orderBillingDetailDTOs)) {
            if (this.shipmentinformationModel.orderData.orderBillingDetailDTOs.length > 0) {
                const autoRate = this.shipmentInformation.controls['autorateIndicator'];
                autoRate.setValue(this.shipmentinformationModel.orderData.orderBillingDetailDTOs[0].autorateIndicator
                    === 'Y' ? true : false);
            }
        }
        const operationalDto = this.shipmentinformationModel.orderData.orderOperationalElementDTOs;
        if (!this.jbhGlobals.utils.isEmpty(operationalDto) && this.jbhGlobals.utils.isArray(operationalDto)) {
            if (operationalDto.length > 0) {
                const fleetCodeValue = operationalDto[0].description ? operationalDto[0].description.trim() : operationalDto[0].description;
                this.shipmentInformation['controls']['fleetCode'].setValue(fleetCodeValue);
                this.shipmentInformation.get('fleetCode').setValidators([]);
                this.shipmentInformation.get('fleetCode').updateValueAndValidity();
            }
        }
        if (!this.jbhGlobals.utils.isEmpty(this.shipmentinformationModel.orderData.orderEquipmentRequirementDTOs) &&
            this.jbhGlobals.utils.isArray(this.shipmentinformationModel.orderData.orderEquipmentRequirementDTOs)) {
            if (this.shipmentinformationModel.orderData.orderEquipmentRequirementDTOs.length > 0) {
                const equipReq = this.shipmentinformationModel.orderData.orderEquipmentRequirementDTOs[0]['orderEquipmentRequirement'];
                const equipAss = equipReq['orderEquipmentRequirementSpecificationAssociations'];
                this.shipmentinformationModel.ptemperaturezoneinFah = [];
                this.shipmentinformationModel.otemperaturezoneinFah = [];
                if (!this.jbhGlobals.utils.isEmpty(equipAss) && this.jbhGlobals.utils.isArray(equipAss) && equipAss.length > 0) {
                    for (const equipAssObj of equipAss) {
                        const equipSpec = equipAssObj['orderEquipmentRequirementSpecificationDetails'];
                        if (!this.jbhGlobals.utils.isEmpty(equipSpec) && this.jbhGlobals.utils.isArray(equipSpec) && equipSpec.length > 0) {
                            for (const value of equipSpec) {
                                if (value['frontZonePrecoolTemperature'] && value['rearZonePrecoolTemperature']) {
                                    this.onPopulateTemperature(value, true, 'frontZonePrecoolTemperature', 'rearZonePrecoolTemperature');
                                } else if (value['temperatureLowRange'] && value['temperatureHighRange']) {
                                    this.onPopulateTemperature(value, false, 'temperatureLowRange', 'temperatureHighRange');
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    loadCustomBroker() {
        const arr = [];
        if (this.shipmentinformationModel.orderData &&
            this.shipmentinformationModel.orderData.orderCrossesBorderDetailDTOs) {
            const crossBorder = this.shipmentinformationModel.orderData.orderCrossesBorderDetailDTOs,
                crossBroderLeng = crossBorder.length;
            for (let i = 0; i < crossBroderLeng; i++) {
                if (crossBorder[i]['profileDTO'] && crossBorder[i]['profileDTO']['addressDTO']) {
                    const profileDTO = crossBorder[i]['profileDTO'];
                    const addressdto = profileDTO['addressDTO'];
                    const code = profileDTO.locationCode ? profileDTO.locationCode : ' ';
                    this.brokerValue = profileDTO.partyName + ' (' + code + ')';
                    this.brokVal = addressdto.addressLineOne + addressdto.addressLineTwo + ' ,' + addressdto.city + ' ,' +
                        addressdto.state + ' ,' + addressdto.zipCode + ' ,' + addressdto.country;
                    const customsBrokerName = (profileDTO.partyName ? profileDTO.partyName : '')
                        + '-' + (addressdto.addressLineOne ? addressdto.addressLineOne : '') + ' '
                        + (addressdto.addressLineTwo ? addressdto.addressLineTwo : '') + ','
                        + (addressdto.city ? addressdto.city : '') + ' '
                        + (addressdto.country ? addressdto.country : '') + ' '
                        + (addressdto.state ? addressdto.state : '') + ' '
                        + (addressdto.zipCode ? addressdto.zipCode : '') + ' '
                        + (profileDTO.partyID ? profileDTO.partyID : '');
                    arr.push({
                        'custombroker': customsBrokerName,
                        'clearingcustoms': this.getCountryDesccription(crossBorder[i].clearingCountryCode)
                    });
                }
            }
        }
        return arr;
    }
    getCountryDesccription(key) {
        const data = this.shipmentinformationModel.clearingCustomsList;
        if (data && data.length > 0) {
            const dataLength = data.length;
            for (let i = 0; i < dataLength; i++) {
                if (data[i]['id'] === key) {
                    return data[i]['text'];
                }
            }
        }
    }
    onPopulateTemperature(value, isPrecoolFlag, lowTemp, highTemp): void {
        if (this.addTag({ id: 'Temperature Control', text: 'Temperature Control' })) {
            this.shipmentinformationModel.tempcontrol = true;
            this.loadTemperatureArray();
        }
        (isPrecoolFlag) ? this.shipmentinformationModel.addtemperaturezoneflag = true :
            this.shipmentinformationModel.addoptemperaturezoneflag = true;
        (isPrecoolFlag) ? this.precoolCheckBox.nativeElement.checked = true : this.operatingCheckBox.nativeElement.checked = true;
        (isPrecoolFlag) ? this.shipmentinformationModel.precoolflag = true : this.shipmentinformationModel.operatingflag = true;
        const obj = { 'min': value[lowTemp], 'max': value[highTemp] };
        (isPrecoolFlag) ? this.shipmentinformationModel.ptemperaturezoneinFah.push(obj) :
            this.shipmentinformationModel.otemperaturezoneinFah.push(obj);
        this.setValidationTemperatureControl(!isPrecoolFlag, false);
        if (value['unitOfTemperatureMeasurementCode']) {
            const showCel = value['unitOfTemperatureMeasurementCode'] === 'Fahrenheit' ? false : true;
            (isPrecoolFlag) ? this.precoolShowCelsius.nativeElement.checked = showCel ? true : false :
                this.operatingShowCelsius.nativeElement.checked = showCel ? true : false;
            this.showTempInCel(showCel, !isPrecoolFlag, false);
        }
    }
    addInternationalTag(): void {
        if (this.addTag({ id: 'International Shipment', text: 'International Shipment' })) {
            this.shipmentinformationModel.intship = true;
        }
    }
    addTag(obj): boolean {
        if (this.jbhGlobals.utils.findIndex(this.shipmentRequirementsTagsKey.active, obj) === -1) {
            this.shipmentRequirementsTagsKey.active.push(obj);
            return true;
        } else {
            return false;
        }
    }
    // public numberCheck(e): void {
    //     const key = e.keyCode ? e.keyCode : e.which;
    //     if (!([8, 9, 13, 27, 46, 190].indexOf(key) !== -1 ||
    //         (key === 65 && (e.ctrlKey || e.metaKey)) ||
    //         (key >= 35 && key <= 40) ||
    //         (key >= 48 && key <= 57 && !(e.shiftKey || e.altKey)) ||
    //         (key >= 96 && key <= 105)
    //     )) {
    //         e.preventDefault();
    //     }
    // }
    onValidateForm(): void {
        const me = this;
        this.jbhGlobals.utils.forIn(this.shipmentInformation.controls,
            function (value, name, object) {
                me.shipmentInformation.controls[name].markAsTouched();
            });
    }
    enterToClick(field, event) {
        if (event.keyCode === 13) {
            if (field === 'autoRate') {
                this.autoRate.nativeElement.click();
            } else if (field === 'preCool') {
                this.precoolCheckBox.nativeElement.click();
            } else if (field === 'operating') {
                this.operatingCheckBox.nativeElement.click();
            } else if (field === 'addTempZoneBox') {
                this.addTempZoneBox.nativeElement.click();
            } else if (field === 'opershowCel') {
                this.operatingShowCelsius.nativeElement.click();
            } else if (field === 'preCoolAddTempZone') {
                this.preCoolAddTempZone.nativeElement.click();
            } else if (field === 'preshowCel') {
                this.precoolShowCelsius.nativeElement.click();
            } else if (field === 'operating') {
                this.operatingCheckBox.nativeElement.click();
            } else if (field === 'operating') {
                this.operatingCheckBox.nativeElement.click();
            } else { }
        }
    }
}
