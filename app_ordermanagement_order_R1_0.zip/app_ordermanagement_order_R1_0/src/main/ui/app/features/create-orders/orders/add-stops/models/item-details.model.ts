export class ItemDetailsModel {
  itemData: any;
  subscription: any;
  orderData: any;
  serialNumberFlag: boolean;
  itemDetailsForm: any;
  barcodeFlag: boolean;
  serviceFlag: boolean;
  transItemFlag = true;
  itemDimensionFlag = true;
  showTransDetailIcon = false;
  showSaveDetailIcon = false;
  showHazmat = false;
  showTemperature = false;
  itemServiceList: any[] = [];
  itemBarCodeTypeList: any[];
  itemCharacteristicsList: any[] = [];
  itemDescriptionList: any[] = [];
  popUpItemDescriptionList: any[] = [];
  nmfcNumberList: any[] = [];
  transTypeaheadList: any[] = [];
  saveItemList: any[] = [];
  debounceValue: any;
  onSelectTransValue = false;
  onSelectPopupValue = false;
  onSelectPopupNmfcValue = false;
  transSearchFlag = false;
  saveSearchFlag = false;
  itemPopupHeading: string;
  itemPopupButton: string;
  itemVolume: any;
  itemDensity: any;
  volumeVal: any;
  itemDescriptionNMFC: any;
  popUpItemDescriptionNMFC: any;
  itemdetailsForm: any;
  stopDetails: any;
  itemDescriptionSaved: any;
  transEditFlag = false;
  saveEditFlag = false;
  popupFlag = false;
  typeaheadFlag = true;
  dcsFlag = false;
  extremeLength: any;
  icsLTLFlag = false;
  icsLTLDirFlag = false;
  validataDimensionFlag = true;
  itemDenistyVal: any;
  itemVolumeVal: any;
  itemServiceDescription: any;
  itemServiceCode: any;
  itemClassificationFlag = false;
  transPopCloseFlag = false;
  savedPopCloseFlag = false;
  stopID: any;
  handlingUnitID: any;
  modelNumberFlag = false;
  flatbedFlag = false;
  newModelNumberFlag: any;
  standardServicesList: any[] = [];
  standardServiceFlag = false;
  emptyObj: any;
  handlingData: any;
  addItemFlag = false;
  serviceId: any;
  stopItemID: any;
  barCodeDetails: any[] = [];
  itemBarCodeType: any = '';
  isDataLoaded = false;
  orderId: any;
  hazmatData: any[] = [];
  propershippingname: any[] = [];
  timer;
  saveItemFlag = true;
  volMeasureFlag = false;
  denMeasureFlag = false;
  ticks = 0;
  stopItemLength = 0;
  subscriptions: any = [];
  lengthList: any[] = [];
  weightList: any = [];
  temperatureList: any = [];
  categoryList: any = [];
  freightClass: any = [];
  freightClassList: any = [];
  packageList: any;
  removeSerialNum = true;
  barCoderemove = true;
  itemserv = true;
  itemDescriptionObj = {
    'itemMake': '',
    'upc': '',
    'itemManufacturer': '',
    'modelNumber': '',
    'sku': '',
    'supplierSKU': '',
    'itemCategory': '',
    'itemClassification': '',
    'itemDescription': '',
    'nmfcNumber': '',
    'itemPartNumber': ''
  };
  editItemArray = ['nmfcNumber', 'skuNumber', 'supplierSKU', 'itemMake',
    'itemModelNumber', 'itemManufacturer', 'itemCategory',
    'itemPartNumber', 'itemUniversalProductCode', 'itemClassificationCode'];
  editItemObjArray = ['nmfcNumber', 'sku', 'supplierSKU', 'itemMake',
    'modelNumber', 'itemManufacturer', 'itemCategory',
    'itemPartNumber', 'upc', 'itemClassification'];
  hazmatObj: any;
  handlingUnitSave: boolean;
}
