import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { MyDatePickerModule } from 'mydatepicker';
import { TypeaheadModule } from '../../../../shared/jbh-typeahead/typeahead.module';
import { TextMaskModule } from 'angular2-text-mask';
// import { DateTimePickerModule } from 'ng-pick-datetime';
import { PopoverModule } from 'ngx-bootstrap/popover';
import { TagInputModule } from 'ng2-tag-input';
import { AccordionModule } from 'ngx-bootstrap';
import { DragulaModule } from 'ng2-dragula';
import { ModalModule } from 'ngx-bootstrap';
// import { TimepickerModule } from '../../../../shared/timepicker/timepicker.module';
import { TimepickerModule } from 'ngx-bootstrap';

import { AddStopsRoutingModule } from './add-stops-routing.module';
import { AddStopsComponent } from './add-stops.component';
import { HandlingUnitsComponent } from './handling-units/handling-units.component';
import { ItemDetailsComponent } from './item-details/item-details.component';
import { StopDetailsComponent } from './stop-details/stop-details.component';
import { AppointmentDetailsComponent } from './stop-details/appointment-details.component';
import { ItemHazmatComponent } from './item-details/item-hazmat.component';
import { SiteProfileModule } from '../../../../shared/site-profile/site-profile.module';
import { StopHandlingComponent } from './handling-units/stop-handling.component';
import { DeliveryHandlingUnitsComponent } from './delivery-handling-units/delivery-handling-units.component';
import {
    TemplatesDeliveryHandlingComponent
} from '../../templates/templates-stops/templates-delivery-handling/templates-delivery-handling.component';
import {
    TemplateAppointmentDetailsComponent
} from '../../templates/templates-stops/templates-appointments/templates-appointment-details.component';
import { SocketLoaderModule } from '../socket-loader/socket-loader.module';

import { SelectModule } from '../../../../shared/select';
import { SharedModule } from '../../../../shared/shared.module';
import { ConfirmationPopupModule } from '../../../../shared/confirmation-popup/confirmation-popup.module';
import { StopResequenceComponent } from './stop-details/stop-resequence/stop-resequence.component';
import { AddcontactComponent } from './stop-details/addcontact/addcontact.component';
import { CreateLocationComponent } from './stop-details/create-location/create-location.component';
import { AddStopsOrderService } from './services/add-stops-order.service';
import { HandlingtypeService } from './services/handlingtype.service';
import { UnitOfLengthService } from './services/unit-of-length.service';
import { UnitOfWeightService } from './services/unit-of-weight.service';
import { ItemTemperatureService } from './services/item-temperature.service';
import { ItemPackageService } from './services/item-package.service';
import { ItemFreightClassService } from './services/item-freight-class.service';
import { ItemCategoryService } from './services/item-category.service';
import { HandlingunitService } from './services/handlingunit.service';
import { DndModule } from 'ng2-dnd';

@NgModule({
    imports: [
        CommonModule,
        AddStopsRoutingModule,
        PopoverModule.forRoot(),
        MyDatePickerModule,
        TypeaheadModule.forRoot(),
        //  DatepickerModule.forRoot(),
        BsDropdownModule.forRoot(),
        AccordionModule.forRoot(),
        ReactiveFormsModule,
        TagInputModule,
        TextMaskModule,
        //  DateTimePickerModule,
        ModalModule.forRoot(),
        SelectModule,
        SiteProfileModule,
        SharedModule,
        DragulaModule,
        SocketLoaderModule,
        TimepickerModule.forRoot(),
        DndModule.forRoot(),
        ConfirmationPopupModule
    ],

    declarations: [
        AddStopsComponent,
        AppointmentDetailsComponent,
        HandlingUnitsComponent,
        ItemDetailsComponent,
        StopDetailsComponent,
        ItemHazmatComponent,
        StopHandlingComponent,
        DeliveryHandlingUnitsComponent,
        StopResequenceComponent,
        AddcontactComponent,
        CreateLocationComponent,
        TemplatesDeliveryHandlingComponent,
        TemplateAppointmentDetailsComponent
    ],
    providers: [AddStopsOrderService, HandlingtypeService, UnitOfLengthService, UnitOfWeightService,
        ItemTemperatureService, ItemPackageService, ItemFreightClassService, ItemCategoryService, HandlingunitService],
    exports: [
        AddStopsComponent,
        AppointmentDetailsComponent,
        HandlingUnitsComponent,
        ItemDetailsComponent,
        StopDetailsComponent,
        ItemHazmatComponent,
        StopHandlingComponent,
        DeliveryHandlingUnitsComponent,
        StopResequenceComponent,
        CreateLocationComponent,
        TemplatesDeliveryHandlingComponent,
        TemplateAppointmentDetailsComponent
    ]
})

export class AddStopsModule { }
