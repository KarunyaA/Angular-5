import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
    {
        path: '',
        redirectTo: 'template',
        pathMatch: 'full'
    },
    {
        path: 'template',
        loadChildren: './templates/templates.module#TemplatesModule'
    },
    {
        path: 'order',
        loadChildren: './orders/orders.module#OrdersModule'
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
    providers: []
})

export class CreateOrdersRoutingModule { }
