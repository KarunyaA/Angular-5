import { JBHGlobals } from '../../../../../app.service';
import * as moment from 'moment';
import { Component, ElementRef, ChangeDetectorRef, Input, OnInit, ViewChild, ViewChildren } from '@angular/core';
// import {AppointmentDetailsComponent} from './appointment-details.component';
import { SiteProfileComponent } from '../../../../../shared/site-profile/site-profile.component';
import { AddcontactComponent } from './addcontact/addcontact.component';
import { Router } from '@angular/router';
import { FormGroup } from '@angular/forms';
import { FormControl, Validators } from '@angular/forms';
import { OrderFormBuilderService } from '../../services/order-form-builder.service';
import { OrderService } from '../../services/order.service';
import { StopSharedDataService } from './../services/stop-shared-data.service';
import { AddStopsOrderService } from './../services/add-stops-order.service';
import { TemplateService } from './../../../templates/template.service';

@Component({
    selector: 'app-stop-details',
    templateUrl: './stop-details.component.html',
    styleUrls: ['./stop-details.component.scss']
})
export class StopDetailsComponent implements OnInit {
    @ViewChildren('apptRequestedChild') apptRequestedChild: any;
    @ViewChildren('apptScheduledChild') apptScheduledChild: any;
    @ViewChild('contactTag') contactTag: any;
    @ViewChild('serviceTypeCodeTag') serviceTypeCodeTag: any;
    @ViewChild('appointmentNumber') appointmentNumber: ElementRef;
    @ViewChild('appointmentInsTag') appointmentInsTag: any;
    @ViewChild(AddcontactComponent) addcontact: AddcontactComponent;
    @ViewChild('itemDetailsRef') itemDetailsRef: any;
    @ViewChild('locDet') locDet: ElementRef;
    @ViewChild('handlingUnit') handlingUnit: any;
    @ViewChild('pickuptrailerModal') pickuptrailerModal: any;
    @Input() stopNumber;
    @Input() finalStop;
    @Input() stopDataLoaded;
    @Input() isCurrViewTemplate: boolean;
    @Input() stopResequenceList: any;
    @Input() currentTotalStopWeight: any;
    @ViewChild('handlingUnitRef') handlingUnitRef: any;
    @ViewChild(SiteProfileComponent) siteprofile: SiteProfileComponent;
    @ViewChild('popover') popover: any;
    @ViewChild('popoverDiv') popoverDiv: any;
    @Input() stopResequenceDetails: any;
    @Input() currentStopId: number;
    @ViewChild('addAppoint') addAppoint;
    @ViewChild('scheduleAppoint') scheduleAppoint;
    @ViewChild('appSiteProfile') appSiteProfile: any;
    locValue: any;
    locPopValue: any;
    isScheduledExist = true;
    stopForm: any;
    stopDetails: any;
    stopSaveActionSuccess = true;
    requestedAppts: any = {};
    stopServicesData: any = {};
    scheduledAppts: any = {};
    stopServices: FormGroup;
    stopServiceObject: any;
    stopJson: any;
    appType: any;
    sequenceID: any;
    scheduledApptData: any;
    stopReasonList: any[] = [];
    intermediateStopReasonList: any[] = [];
    isStopMiles = false;
    totalMilesList: string[] = [];
    appointmentInstructionListObj: any;
    appointmentInstructionObj: string[] = [];
    serviceLevelTypeCodeListObj: any;
    serviceLevelTypeCodeObj: Array<string> = [];
    locationLoading: boolean;
    locationNoResults: boolean;
    isFirstStop = false;
    locationContactHide = false;
    roleType: string;
    stopTotalMiles = 0;
    resequenceFlagReq = false;
    locationCode: string;
    preStopNumber: number;
    curStopZip: any;
    prevStopZip: any;
    zipCode: string;
    debounceValue: number;
    scheduledForm: any;
    appointmentInstruction: FormGroup;
    orderData: any;
    appointmentSequence: any;
    stopId: number;
    stopReasonType;
    reasonType: string;
    stopReason: any;
    locationRes: any;
    prevStopCountry: string;
    curStopCountry: string;
    isDataLoaded = false;
    locationContactTypeRes: any[] = [];
    locationContactList: any[] = [];
    appointmentInstructionList: any[] = [];
    serviceLevelTypeCodeList: any[] = [];
    typeAheadList: any[] = [];
    stopLoadFlag = false;
    stopReasonLoadFlag = false;
    businessUnit: any;
    serviceOffering: any;
    pickupReason: any;
    requestedStop: any;
    showDetailsIcon = false;
    pickupTrailerCount = 0;
    extraLaborFlag = false;
    showLabel = false;
    appointmentForm;
    isHighCost = false;
    DCSFMSStandardFlag = false;
    roleTypes: any;
    contactId: any;
    contactMethod: any;
    popOverFlag = false;
    isAppointmentNumberAdded = false;
    isAppointmentInsAdded = false;
    trailerPreloadedIndicator: any;
    trailerLiveUnLoadIndicator: any;
    recommendedAppt = '';
    private stopMock: any;
    constructor(
        public orderFormBuilder: OrderFormBuilderService, public router: Router, public jbhGlobals: JBHGlobals,
        public orderService: OrderService,
        public stopSharedDataService: StopSharedDataService,
        public addStopsOrderService: AddStopsOrderService,
        public templateService: TemplateService, private changeDetector:ChangeDetectorRef) { }
    ngOnInit(): void {
        this.stopForm = this.orderFormBuilder.getStopDetailList();
        this.scheduledForm = this.orderFormBuilder.scheduledAppointments();
        if (this.stopNumber === 0) {
            this.isFirstStop = true;
        } else {
            this.isFirstStop = false;
        }
        this.loadStopReason();
        this.loadStopMock();
        this.stopForm = this.orderFormBuilder.getStopDetailList();
        this.loadOrderData();
        this.debounceValue = this.jbhGlobals.settings.debounce;
        this.stopServices = this.stopForm['controls']['stopServices']['controls'][0];
        this.appointmentInstruction = this.orderFormBuilder.getAppointmentInstruction();
        this.stopForm['controls']['locationID']['valueChanges']
            .debounceTime(this.debounceValue)
            .distinctUntilChanged()
            .subscribe((value) => {
                this.typeAheadList = [''];
                if (value !== undefined && value.length === 0) {
                    if (value === '') {
                        this.locationContactHide = false;
                        this.showDetailsIcon = false;
                    }
                    this.stopForm['controls']['locationContactType']['setValue']('');
                    this.locationContactTypeRes = [];
                }
                if (value && value.length > 2 && this.checkVal(value)) {
                    this.getLocationTypeAhead(value, this.roleType);
                }
            }, (err: Error) => {
                console.log(err);
            });
        // this.loadStopServicesList();
        this.loadAppointmentInstruction();
    }
    checkVal(value): boolean {
        const format = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/;
        if (!format.test(value)) {
            return true;
        } else {
            return false;
        }
    }
    loadStopMock() {
        const url = this.jbhGlobals.endpoints.order.getstopmockdata;
        this.jbhGlobals.apiService.getData(url).subscribe(data => {
            this.stopMock = data;
        });
    }
    loadStopDetails(stopId: number) {
        let stopUrl: string;
        this.showLabel = true;
        if (stopId) {
            const stopParam = this.orderData.orderID + '/stops/' + stopId;
            stopUrl = this.jbhGlobals.endpoints.order.getstopbyid + stopParam;
        } else {
            stopUrl = this.jbhGlobals.endpoints.order.getstopmockdata;
        }
        if (this.stopNumber === 0) {
            this.stopForm.controls['stopReason'].setValue([{
                'id': 'Pickup',
                'text': 'Pickup Stop'
            }]);
            this.stopReasonType = 'Pickup';
            this.reasonType = 'Shipper';
            // this.onSelectContactType(this.locationCode, this.roleType);
        } else if (this.finalStop) {
            this.stopForm.controls['stopReason'].setValue([{
                id: 'Delivery',
                text: 'Delivery Stop'
            }]);
            this.stopReasonType = 'Delivery';
            this.reasonType = 'Receiver';
            // this.onSelectContactType(this.locationCode, this.roleType);
        }
        const stopList = this.templateService.getStopList(),
            stopListLength = stopList.length,
            stopNumberVal = this.stopNumber;
        if (this.isCurrViewTemplate && stopListLength > 0 && stopList[stopNumberVal]['locationDTO']) {
            if (this.orderData && this.orderData.stopDTOs) {
                this.orderData.stopDTOs = JSON.parse(JSON.stringify(stopList[stopNumberVal]));
                this.addStopsOrderService.saveData(this.orderData);
                if (!this.jbhGlobals.utils.isEmpty(this.orderData.stopDTOs)) {
                    this.populateStopData(this.orderData.stopDTOs);
                }
                if (this.orderData.stopDTOs.stop.appointment) {
                    this.appointmentGenerator();
                }
                this.stopLoadFlag = true;
            }
        } else {
            this.jbhGlobals.apiService.getData(stopUrl).subscribe(data => {
                // console.log('stopUrl ', stopUrl);
                if (!this.jbhGlobals.utils.isEmpty(data)) {
                    this.stopDetails = data['stop'];
                    this.orderData.stopDTOs = data;
                    this.addStopsOrderService.saveData(this.orderData);
                    this.stopId = this.orderData.stopDTOs.stop.stopID;
                    if (this.stopId) {
                        if ((!this.DCSFMSStandardFlag && this.orderData.stopDTOs.stop.stopReason === 'Pickup') ||
                            (this.DCSFMSStandardFlag && this.orderData.stopDTOs.stop.stopReason === 'Delivery')) {
                            this.handlingArrayCreator();
                        }
                        this.populateStopData(this.orderData.stopDTOs);
                    }
                    if (this.orderData.stopDTOs.stop.appointment) {
                        this.appointmentGenerator();
                    }
                    if (this.orderData.stopDTOs.stop.stopServices) {
                        const stopService = this.orderFormBuilder.getStopServices();
                        if (this.orderData.stopDTOs.stop.stopServices.length === 0) {
                            this.stopServiceObject = [stopService.value];
                        } else {
                            this.stopServiceObject = this.orderData.stopDTOs.stop.stopServices;
                        }
                    }
                    this.stopLoadFlag = true;
                }
            }, (err: Error) => {
                return false;
            });
        }
        if (this.stopNumber > 0) {
            this.stopTotalMiles = 0;
            this.totalMilesList = this.jbhGlobals.utils.clone(this.stopResequenceDetails);
            const currentStopResequenceList = this.totalMilesList.slice(0, this.stopNumber + 1);
            for (const resequenceObj of currentStopResequenceList) {
                if (resequenceObj['stopMiles'] >= 0 && resequenceObj['stopMiles'] !== undefined) {
                    this.stopTotalMiles = (this.stopTotalMiles + resequenceObj['stopMiles']);
                    this.isStopMiles = true;
                }
            }
            this.roleType = 'Shipper';
        }
        const orderId = this.orderData.orderID;
        if (orderId) {
            const url = this.jbhGlobals.endpoints.order.getorder + orderId;
            this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getstopresequencelist + orderId).subscribe(data => {
                if (!this.jbhGlobals.utils.isEmpty(data)) {
                    this.trailerPreloadedIndicator = data['trailerPreloadedIndicator'];
                    this.trailerLiveUnLoadIndicator = data['trailerLiveUnLoadIndicator'];
                    //console.log('trailerPreloadedIndicator ' + this.trailerPreloadedIndicator);
                    //console.log('trailerLiveUnLoadIndicator ' + this.trailerLiveUnLoadIndicator);
                }
            })
        }
    }
    locationContactTypeChange(eve) {
        console.log(eve);
        if (eve.id === 'Add Contact') {
            if (this.stopReasonType) {
                this.addcontact.showModal(this);
            } else {
                this.jbhGlobals.notifications.error('Error', 'Please choose the Stop Reason');
            }
        }
        if (eve.id !== 'Add Contact') {
            this.contactId = eve.id.split(',')[2];
            this.contactMethod = eve.id.split(',')[3];
        }
        if (this.isCurrViewTemplate && eve['text'] && eve.id !== 'Add Contact' &&
            this.orderData.stopDTOs && this.orderData.stopDTOs.locationDTO) {
            const str = eve['text'].split(' '),
                str1 = str[0],
                str2 = str[1],
                str3 = str[3];
            const Obj = {
                'firstName': str1,
                'lastName': str2,
                'contactValue': str3
            };
            this.orderData.stopDTOs.locationDTO['contactDTO'] = Obj;
            this.orderData.stopDTOs['stop']['locationContactID'] = this.contactId;
            this.orderData.stopDTOs['stop']['locationContactType'] = this.contactMethod;
            // contact save integrate here
        }
    }
    handlingArrayCreator() {
        if (this.orderData.stopDTOs && this.orderData.stopDTOs.itemHandlingDetailDTOs) {
            const handlingArray = this.orderData.stopDTOs.itemHandlingDetailDTOs;
            if (handlingArray.length < 1) {
                this.orderData.stopDTOs.itemHandlingDetailDTOs.push(this.stopMock['itemHandlingDetailDTOs'][0]);
            } else if (handlingArray.length > 0) {
                for (let i = 0; i < handlingArray.length; i++) {
                    if (this.jbhGlobals.utils.isEmpty(handlingArray[i].stopItemDTOs) || handlingArray[i].stopItemDTOs.length < 1) {
                        const mock = this.stopMock['itemHandlingDetailDTOs'][0]['stopItemDTOs'][0];
                        this.orderData.stopDTOs.itemHandlingDetailDTOs[i]['stopItemDTOs'][0] = mock;
                    }
                }
            }
        }
    }
    appointmentGenerator() {
        if (this.orderData.stopDTOs.stop.appointment.length === 0) {
            this.orderData.stopDTOs.stop.appointment = this.stopMock['stop']['appointment'];
        }
        const apptArr = this.orderData.stopDTOs.stop.appointment;
        if (apptArr.length === 2) {
            const mockArray = this.stopMock['stop']['appointment'];
            if (apptArr[0].appointmentTypeCode === 'Requested') {
                if (apptArr[1].appointmentTypeCode === 'Recmmended') {
                    apptArr[2] = mockArray[1];
                } else {
                    apptArr[1] = mockArray[1];
                }
            } else if (apptArr[0].appointmentTypeCode === 'Scheduled') {
                if (apptArr[1].appointmentTypeCode === 'Recmmended') {
                    const apptData = apptArr[0];
                    apptArr[0] = mockArray[0];
                    apptArr[2] = apptData;
                } else {
                    const apptData = apptArr[0];
                    apptArr[0] = mockArray[0];
                    apptArr[1] = apptData;
                }
            }
            this.orderData.stopDTOs.stop.appointment = apptArr;
        }
        this.appointmentSequence = this.orderData.stopDTOs.stop.appointment;
        let requestedExist = false;
        let scheduledExist = false;
        const schedeuledAppt = this.jbhGlobals.utils.find(apptArr, {
            appointmentTypeCode: 'Scheduled'
        })
        this.isScheduledExist = true;
        this.scheduledForm.controls['appointmentConfirmationNumber'].disable();
        if (schedeuledAppt && schedeuledAppt['appointmentDateTimeDetails'] && (schedeuledAppt['appointmentDateTimeDetails'][0].appointmentStartTimestamp ||
            schedeuledAppt['appointmentDateTimeDetails'][0].appointmentEndTimestamp)) {
            this.isScheduledExist = false;
            this.scheduledForm.controls['appointmentConfirmationNumber'].enable();
        }
        const apptInstruction = this.orderFormBuilder.getAppointmentInstruction();
        for (const appts of apptArr) {
            if (appts['appointmentTypeCode'] === 'Requested') {
                requestedExist = true;
                this.requestedAppts = appts;
            } else if (appts['appointmentTypeCode'] === 'Scheduled') {
                this.scheduledAppts = appts;
                scheduledExist = true;
                if (!this.scheduledAppts.appointmentInstructionAssociations) {
                    this.scheduledAppts.appointmentInstructionAssociations = [apptInstruction.value];
                }
            } else if (appts['appointmentTypeCode'] === 'Recmmended') {
                this.setRecommendedTime(appts);
            }
        }
        if (!requestedExist) {
            this.addAppointments(0);
        }
        if (!scheduledExist) {
            this.addAppointments(1);
        }
    }

    loadStopReason() {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getstopreason).subscribe(data => {
            // this.stopReasonList = this.jbhGlobals.utils.filter(data['_embedded']['stopReasons'], function(n) {
            for (const n of data['_embedded']['stopReasons']) {
                if (n.stopReasonCode === 'Pickup' || n.stopReasonCode === 'Delivery') {
                    const obj = {
                        'id': n.stopReasonCode,
                        'text': n.stopReasonDescription
                    };
                    this.stopReasonList.push(obj);
                }
            }
            // });
            this.intermediateStopReasonList = this.stopReasonList;
            this.showLabel = true;
            this.stopReasonLoadFlag = true;
            this.loadStopServicesList();
        }, (err: Error) => {
            return false;
        });
    }

    appointmentInsOnBlur(event) {
    }
    loadAppointmentInstruction() {
        if (this.scheduledApptData && this.scheduledApptData.appointmentInstructionAssociations) {
            this.appointmentInstructionObj = this.scheduledApptData.appointmentInstructionAssociations;
        }
        const params = {
            'businessUnit': (this.businessUnit) ? this.businessUnit : '',
            'serviceOffering': (this.serviceOffering) ? this.serviceOffering : '',
            'stopReason': this.stopReasonType
        };
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getappointmentinstruction, params).subscribe(data => {
            if (!this.jbhGlobals.utils.isEmpty(data)) {
                this.appointmentInstructionList = this.jbhGlobals.utils.uniqBy(data, 'appointmentInstructionText');
                this.appointmentInstructionListObj = this.jbhGlobals.utils.clone(this.appointmentInstructionList);
                this.appointmentInstructionList = this.jbhGlobals.utils.map(this.appointmentInstructionList, 'appointmentInstructionText');
                const insData = this.appointmentInstructionListObj;
                this.appointmentInstructionList = [];
                for (let i = 0; i < insData.length; i++) {
                    this.appointmentInstructionList.push({
                        id: insData[i].appointmentInstructionID,
                        text: insData[i].appointmentInstructionText
                    })
                }
                if (!this.jbhGlobals.utils.isEmpty(this.scheduledApptData)) {
                    const apptInstAsso = this.scheduledApptData.appointmentInstructionAssociations;
                    if (this.appointmentInsTag && this.appointmentInsTag.active && apptInstAsso.length > 0) {
                        this.appointmentInstructionObj = [];
                        this.appointmentInsTag.active = [];
                        for (let i = 0; i < apptInstAsso.length; i++) {
                            const apptInstData = this.jbhGlobals.utils.find(this.appointmentInstructionListObj, {
                                appointmentInstructionID: Number(apptInstAsso[i].appointmentInstruction)
                            });
                            if (apptInstData) {
                                const appointmentInsObj: any = {
                                    appointmentInstructionAssociationID: 0,
                                    appointmentInstruction: apptInstData.appointmentInstructionID,
                                    appointmentInstructionAdditionalDetail: null
                                };
                                this.appointmentInstructionObj.push(appointmentInsObj);
                            }
                            if (apptInstData) {
                                this.appointmentInsTag.active.push({
                                    'id': apptInstData['appointmentInstructionID'],
                                    'text': apptInstData['appointmentInstructionText']
                                });
                            }
                        }
                    }
                    if (this.appointmentNumber && this.appointmentNumber !== undefined) {
                        this.appointmentNumber.nativeElement.value = this.scheduledApptData.appointmentConfirmationNumber;
                    }
                }
            }
        }, (err: Error) => {
            return false;
        });
    }
    loadStopServicesList() {
        if (this.businessUnit && this.serviceOffering) {
            const params = {
                'businessUnit': this.businessUnit,
                'serviceOffering': this.serviceOffering,
                'serviceCategoryCode': 'StopServ',
                'stopReason': this.stopReasonType
            };
            this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getstopserviceslist, params).subscribe(data => {
                this.serviceLevelTypeCodeList = this.jbhGlobals.utils.uniqBy(data, 'serviceTypeDescription');
                this.serviceLevelTypeCodeListObj = this.jbhGlobals.utils.clone(this.serviceLevelTypeCodeList);
                this.serviceLevelTypeCodeList = this.jbhGlobals.utils.map(this.serviceLevelTypeCodeList, 'serviceTypeDescription');
                if (this.orderData && this.orderData.stopDTOs && this.orderData.stopDTOs['stop'] &&
                    this.orderData.stopDTOs['stop']['stopServices']) {
                    this.stopServicesData = this.orderData.stopDTOs['stop']['stopServices'];
                    this.serviceLevelTypeCodeObj = this.orderData.stopDTOs['stop']['stopServices'];
                }
                if (!this.jbhGlobals.utils.isEmpty(this.stopServicesData)) {
                    if (this.serviceTypeCodeTag && this.serviceTypeCodeTag.active && this.stopServicesData.length > 0) {
                        for (let i = 0; i < this.stopServicesData.length; i++) {
                            const stopServiceObj = this.jbhGlobals.utils.find(this.serviceLevelTypeCodeListObj, {
                                serviceTypeCode: this.stopServicesData[i].serviceType
                            });
                            if (stopServiceObj) {
                                const obj = {
                                    'id': stopServiceObj['serviceTypeCode'],
                                    'text': stopServiceObj['serviceTypeDescription']
                                };
                                const isNewTag = this.checkActiveTags(this.serviceTypeCodeTag.active, obj.text).length === 0;
                                if (isNewTag) {
                                    this.serviceTypeCodeTag.active.push(obj);
                                }
                            }
                        }
                    }
                }
            }, (err: Error) => {
                return false;
            });
        }
    }
    onStopServiceSelection(eve) {
        // this.requestedStop = eve.text;
        // if(this.requestedStop === 'Pickup Trailer' || this.requestedStop === 'Drop Trailer') {
        //     this.jbhGlobals.utils.pullAt(this.serviceLevelTypeCodeList,[1,2]);
        //     console.log(this.serviceLevelTypeCodeList);
        // }
        // if(this.requestedStop === 'Drop Trailer' || this.requestedStop === 'Pickup Trailer')
        // {
        //     this.addStopsOrderService.setRequestedStopFlag();
        // }
        // this.requestedStop = eve.text;
        // this.equipmentOptionCheck();
        console.log(eve); this.stopForm.controls.stopServices.controls[0].controls.serviceLevelTypeCode.markAsDirty();
        const serviceTypeVal = this.jbhGlobals.utils.find(this.serviceLevelTypeCodeListObj, {
            serviceTypeDescription: eve.text
        });
        const stopServiceObject: any = {
            serviceID: '',
            serviceCount: '',
            unitOfServiceMeasurementCode: 'HOURS',
            serviceLevelTypeCode: 'STOP',
            '@type': 'StopService',
            serviceType: serviceTypeVal.serviceTypeCode
        };
        // this.stopForm.controls.stopServices.controls.serviceLevelTypeCode.setValue([
        // { 'id': serviceTypeVal.serviceTypeCode, 'text': eve.text }]);
        this.serviceLevelTypeCodeObj.push(stopServiceObject);
        this.trailerPreLoadIndicatorChange(eve.text, 'Y');
        this.checkForTrailerAndDriver(eve.text);
        this.setNumberOfHoursFlag(eve.text, true);
        if (this.orderData.financeBusinessUnitCode === 'ICS') {
            switch (eve.text.toLowerCase()) {
                case 'pickup trailer':
                case 'drop trailer':
                    this.jbhGlobals.notifications.error('Order',
                        'In order for this load to be booked for ICS, you must call the customer and have it changed to Live Load');
                default:
                    break;
            }
        }
        ;
        if (this.stopReasonType !== undefined && this.orderData.stopDTOs.stop.locationID) {
            this.stopDetailSaveForm('cur', 'noCallBack');
        }
    }
    setNumberOfHoursFlag(selectedTag, tagAction) {
        if (selectedTag === 'Extra Labor') {
            this.extraLaborFlag = tagAction;
        }
    }
    checkForTrailerAndDriver(selectedTag) {
        switch (selectedTag) {
            case 'Pickup Trailer':
                this.disableOption(selectedTag, 'Driver Loads Freight');
                break;
            case 'Drop Trailer':
                this.disableOption(selectedTag, 'Driver Unloads Freight');
                break;
            case 'Driver Loads Freight':
                this.disableOption(selectedTag, 'Pickup Trailer');
                break;
            case 'Driver Unloads Freight':
                this.disableOption(selectedTag, 'Drop Trailer');
                break;
            default:
                break;
        }
    }
    disableOption(selectedTag, optionToBeDisable) {
        const activeTags = this.serviceTypeCodeTag.active;
        const tagPresent = this.checkActiveTags(activeTags, optionToBeDisable);
        if ((tagPresent.length > 0) || (this.trailerPreloadedIndicator === 'Y' && this.stopReasonType === 'Delivery'
            && selectedTag === 'Driver Unloads Freight') || (this.trailerPreloadedIndicator === 'Y' && this.stopReasonType === 'Pickup'
                && selectedTag === 'Driver Loads Freight')) {
            const tagToRemove = {
                id: optionToBeDisable,
                text: optionToBeDisable
            };
            activeTags.splice(activeTags.indexOf(tagToRemove), 1);
            this.serviceLevelTypeCodeObj.splice(-1, 1);
            this.jbhGlobals.notifications.alert('Warning', selectedTag + ' cannot be selected');
        }
    }
    checkActiveTags(activeTags, optionToBeDisable) {
        return activeTags.filter(item => item.text.toLowerCase().indexOf(optionToBeDisable.toLowerCase()) !== -1);
    }
    trailerPreLoadIndicatorChange(preloadValue, Indicator) {
        const activeTags = this.serviceTypeCodeTag.active;
        if (preloadValue === 'Pickup Trailer' && this.orderData.orderEquipmentRequirementDTOs &&
            this.orderData.orderEquipmentRequirementDTOs[0]) {
            if (Indicator === 'Y') {
                this.orderData.orderEquipmentRequirementDTOs[0]
                    .orderEquipmentRequirement.trailerPreloadedIndicator = Indicator;
                this.orderData.trailerPreloadedIndicator = Indicator;
                // this.pickuptrailerModal.show()
                this.pickupTrailerCount++;
            } else {
                if (--this.pickupTrailerCount === 0) {
                    this.orderData.orderEquipmentRequirementDTOs[0]
                        .orderEquipmentRequirement.trailerPreloadedIndicator = Indicator;
                    this.orderData.trailerPreloadedIndicator = Indicator;
                }
            }
        }
        // this.stopSharedDataService.setTrailerPreloadedIndicator(Indicator);
        // this.checkForLiveLoadAndUnload(activeTags);
        // console.log(this.jbhGlobals.commonDataService.getLiveFlagStatus(),this.pickupTrailerCount);
    }
    checkForLiveLoadAndUnload(activeTags) {
        // if(this.jbhGlobals.commonDataService.getLiveFlagStatus() == true){
        if (this.checkPickupDropTrialer(activeTags, 'Pickup Trailer') &&
            this.checkPickupDropTrialer(activeTags, 'Drop Trailer')) {
            this.jbhGlobals.commonDataService.setLiveFlagStatus(false);
            console.log(this.jbhGlobals.commonDataService.getLiveFlagStatus());
        } else {
            this.jbhGlobals.commonDataService.setLiveFlagStatus(true);
        }
        // }
    }
    checkPickupDropTrialer(items: any[], arg: string) {
        // check wheather the args is present in the items array and then return true if the array returned by filter() is > 0
        return items.filter(item => item.text.toLowerCase().indexOf(arg.toLowerCase()) !== -1).length > 0;
    }
    deleteEquipmentOptions() {
        this.router.navigateByUrl('/createorders/order/create?id=' + this.orderData.orderID);
        console.log(this.orderData.orderEquipmentRequirementDTOs[0].orderEquipmentRequirement);
    }
    appointmentNumberChanged(val) {
        const apptArr = this.orderData.stopDTOs.stop.appointment;
        const scheduledAppt = this.jbhGlobals.utils.find(apptArr, {
            appointmentTypeCode: 'Scheduled'
        });
        scheduledAppt.appointmentConfirmationNumber = Number(val);
        this.isAppointmentNumberAdded = true;
    }
    onApptInstructionSelection(eve) {
        this.isAppointmentInsAdded = true;
        const apptInstruction = this.jbhGlobals.utils.find(this.appointmentInstructionListObj, {
            appointmentInstructionText: eve.text
        });
        const appointmentInsObj: any = {
            appointmentInstructionAssociationID: 0,
            appointmentInstruction: apptInstruction.appointmentInstructionID,
            appointmentInstructionAdditionalDetail: null
        };
        this.appointmentInstructionObj.push(appointmentInsObj);
        const apptArr = this.orderData.stopDTOs.stop.appointment;
        let scheduledAppt = this.jbhGlobals.utils.find(apptArr, {
            appointmentTypeCode: 'Scheduled'
        });
        if (!this.jbhGlobals.utils.isEmpty(apptArr)) {
            scheduledAppt.appointmentInstructionAssociations = [];
            scheduledAppt.appointmentInstructionAssociations = this.appointmentInstructionObj;
        }
    }
    onApptInstructionRemove(eve) {
        this.isAppointmentInsAdded = true;
        const scheduledAppt = this.jbhGlobals.utils.find(this.orderData.stopDTOs.stop.appointment, {
            appointmentTypeCode: 'Scheduled'
        });
        this.jbhGlobals.utils.remove(this.appointmentInstructionObj, {
            appointmentInstruction: eve.id
        });
        scheduledAppt.appointmentInstructionAssociations = this.appointmentInstructionObj;
    }
    onStopServiceRemove(eve) {
        const serviceTypeVal = this.jbhGlobals.utils.find(this.serviceLevelTypeCodeListObj, {
            serviceTypeDescription: eve.text
        });
        // const activeTags = this.serviceTypeCodeTag.active;
        this.jbhGlobals.utils.remove(this.serviceLevelTypeCodeObj, {
            serviceType: serviceTypeVal.serviceTypeCode
        });
        this.stopForm.controls.stopServices.controls[0].controls.serviceLevelTypeCode.markAsDirty();
        this.trailerPreLoadIndicatorChange(eve.text, 'N');
        this.setNumberOfHoursFlag(eve.id, false);
        if (this.stopReasonType !== undefined && this.orderData.stopDTOs.stop.locationID) {
            this.stopDetailSaveForm('cur', 'noCallBack');
        }
        // this.checkForLiveLoadAndUnload(activeTags);
        // console.log(this.jbhGlobals.commonDataService.getLiveFlagStatus())
    }
    getCurrentStopMile(currentStopMile, currentStopResequenceList) {
        this.stopTotalMiles = 0;
        for (const resequenceObj of currentStopResequenceList) {
            if (resequenceObj['stopMiles'] >= 0 && resequenceObj['stopMiles'] !== undefined) {
                this.stopTotalMiles = (this.stopTotalMiles + resequenceObj['stopMiles']);
                this.isStopMiles = true;
            }
        }
        if (this.isCurrViewTemplate) {
            this.orderData.stopDTOs.stopMiles = currentStopMile;
        }
        this.stopTotalMiles = (this.stopTotalMiles + currentStopMile);
    }

    typeaheadOnSelect(eve) {
        const code = eve.value.split('(');
        const temp = eve.item.addressDTO;
        this.locValue = eve.item.OrgName + ' (' + code[1];
        this.locPopValue = temp.AddressLine1 +
            temp.AddressLine2 + ' , ' + temp.CityName + ' , ' + temp.StateName + ' , ' + temp.PostalCode + ' , ' + temp.CountryName;
        this.locationCode = eve.item.partyId;
        // this.locationCode = '1002';
        this.locationContactHide = true;
        this.orderData.stopDTOs.stop.locationID = this.locationCode;
        this.orderData.stopDTOs.stop.stopReason = this.stopReasonType;
        if (this.isCurrViewTemplate) {
            this.orderData.stopDTOs.locationDTO = this.locationDtoFramer(eve.item);
        }
        this.orderData.stopDTOs.stop.stopSequenceNumber = this.stopResequenceDetails[this.stopNumber]['stop']['stopSequenceNumber'];
        this.stopForm['controls']['locationID']['setValue'](eve.item.name);
        this.stopForm['controls']['locationID'].setValidators([Validators.required]);
        this.stopForm['controls']['locationID'].updateValueAndValidity();
        this.showDetailsIcon = true;
        if (this.stopReasonType !== undefined) {
            this.stopDetailSaveForm('cur', 'noCallBack', true);
        }
        this.roleType = 'Shipper';
        this.onSelectContactType(this.locationCode, this.roleType);
        // this.onLoadLocationContact();
        if (this.stopNumber > 0) {
            this.preStopNumber = (this.stopNumber - 1);
            this.curStopZip = eve.item.addressDTO.PostalCode;
            this.prevStopZip = this.stopResequenceDetails[this.preStopNumber]['locationDTO']['addressDTO']['zipCode'];
            this.prevStopCountry = this.stopResequenceDetails[this.preStopNumber]['locationDTO']['addressDTO']['country'];
            if (this.prevStopZip.length > 5) {
                this.prevStopZip = this.prevStopZip.substring(0, 5);
            }
            if (this.curStopZip.length > 5) {
                this.curStopZip = this.curStopZip.substring(0, 5);
            }
            this.curStopCountry = eve.item['addressDTO'].CountryCode;
            this.zipCode = 'zip/' + this.prevStopZip + '/' + this.prevStopCountry + '/zip/' + this.curStopZip + '/' + this.curStopCountry;
            this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getstopmiles + this.zipCode).subscribe(data => {
                if (data && data !== undefined) {
                    const currentStopMile = data;
                    this.totalMilesList = this.jbhGlobals.utils.clone(this.stopResequenceDetails);
                    const currentStopResequenceList = this.totalMilesList.slice(0, this.stopNumber);
                    this.getCurrentStopMile(currentStopMile, currentStopResequenceList);
                }
            }, (err: Error) => {
                return false;
            });
        }
    }
    typeaheadOnBlur() {
        if (this.isCurrViewTemplate) {
            const locationVal = this.stopForm['controls']['locationID']['_value'];
            if (!locationVal) {
                this.orderData['stopDTOs']['stop']['locationID'] = '';
            }
        }
        if (this.stopReasonType === 'Delivery' &&
            this.orderData.financeBusinessUnitCode === 'ICS' &&
            this.orderData.serviceOfferingCode === 'LTL') {
            this.isHighCost = true;
        }
    }
    addDataDeliveryStop() {
        const obj = {
            'businessUnit': this.orderData.financeBusinessUnitCode ? this.orderData.financeBusinessUnitCode : null,
            'billingParty': this.orderData['partyID'] ? this.orderData['partyID'] : null,
            'deliveryServiceType': null,
            'destinationMarketingArea': null,
            'destinationRamp': null,
            'destinationSite': null,
            'lineOfBusiness': null,
            'ldcLocation': null,
            'nationalAccount': this.orderData['stopDTOs']['stop']['locationID'] ? this.orderData['stopDTOs']['stop']['locationID'] : null,
            'originMarketingArea': null,
            'originRamp': null,
            'originSite': null
        }
        if (this.isFirstStop) {
            obj['originSite'] = this.orderData['stopDTOs']['stop']['locationID'] ? this.orderData['stopDTOs']['stop']['locationID'] : null;
        } else {
            obj['destinationSite'] = this.orderData['stopDTOs']['stop']['locationID'] ?
                this.orderData['stopDTOs']['stop']['locationID'] : null;
        }
        this.jbhGlobals.apiService.addData(this.jbhGlobals.endpoints.order.orderOwner, obj).subscribe(data => {
            const params = { 'orderOwnership': [] };
            if (data['taskAssignmentDTOs'].length > 0 || data['backupTaskAssignmentDTOs'].length > 0) {
                const assignmentFlag = data['taskAssignmentDTOs'].length > 0;
                const assignments = assignmentFlag ? data['taskAssignmentDTOs'] : data['backupTaskAssignmentDTOs'];
                const currentDateTimeStamp = new Date();
                const val = moment(currentDateTimeStamp).format('YYYY-MM-DDTHH:mm:ss');
                console.log(val);
                this.jbhGlobals.utils.map(assignments, (value) => {
                    const task = {
                        'taskAssignmentID': assignmentFlag ? value.taskAssignmentID : null,
                        'backupTaskAssignmentID': !assignmentFlag ? value.backupTaskAssignmentID : null,
                        'appointmentID': value.appointmentID ? value.appointmentID : null,
                        'effectiveTimestamp': value.effectiveTimestamp ? value.effectiveTimestamp : val,
                        'expirationTimestamp': value.expirationTimestamp ? value.expirationTimestamp : val
                    };
                    params['orderOwnership'].push(task);
                });
            }
            this.jbhGlobals.apiService.patchData(this.jbhGlobals.endpoints.order.saveOwnerDetails +
                this.orderData.orderID, params).subscribe(response => {
                    console.log(response);
                });
        });
    }

    locationDtoFramer(data): Object {
        if (data && data['addressDTO']) {
            const obj = {
                'partyID': data['code'],
                'partyName': data['name'],
                'partyType': 'SHIPPER',
                'partyStatus': 'active',
                'addressDTO': {
                    'addressLineOne': data['addressDTO']['AddressLine1'],
                    'addressLineTwo': data['addressDTO']['AddressLine2'],
                    'city': data['addressDTO']['CityName'],
                    'state': data['addressDTO']['StateName'],
                    'zipCode': data['addressDTO']['PostalCode'],
                    'country': data['addressDTO']['CountryCode'],
                    'cityID': data['addressDTO']['cityID']
                },
                'contactDTO': {}
            };
            return obj;
        }
        return {};
    }
    onSelectContactType(locationCode, roleType, contactComboValue?: any) {
        if (locationCode) {
            this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getlocationprofile + ''
                + locationCode, false).subscribe(data => {
                    if (data && data['locationProfileDTO'] && data['locationProfileDTO']['contactDTO']) {
                        this.locationContactList = [];
                        this.locationContactTypeRes = data['locationProfileDTO']['contactDTO'];
                        for (let i = 0; i < this.locationContactTypeRes.length; i++) {
                            const value1 = this.locationContactTypeRes[i].firstName + ' ' + this.locationContactTypeRes[i].lastName;
                            const value = value1 + ' , ' + this.locationContactTypeRes[i].contactValue;
                            const test = value + ',' + this.locationContactTypeRes[i].contactId + ',' +
                                this.locationContactTypeRes[i].contactMethod;
                            this.locationContactList.push({
                                'id': test,
                                'text': value
                            });
                        }
                        this.locationContactList.push({
                            'id': 'Add Contact',
                            'text': 'Add Contact'
                        });
                        if (!this.jbhGlobals.utils.isEmpty(contactComboValue)) {
                            const contactName = contactComboValue.firstName + ' ' + contactComboValue.lastName;
                            const contactValue = contactName + ' , ' + contactComboValue.contactValue;
                            this.contactTag.active.push({
                                'id': contactValue,
                                'text': contactValue
                            });
                        }
                        if (this.isCurrViewTemplate && this.orderData.stopDTOs.locationDTO &&
                            this.orderData.stopDTOs.locationDTO.contactDTO &&
                            this.orderData.stopDTOs.locationDTO.contactDTO['contactValue']) {
                            const populateValue = this.orderData.stopDTOs.locationDTO.contactDTO['firstName'] + ' ' +
                                this.orderData.stopDTOs.locationDTO.contactDTO['lastName'] + ' , ' +
                                this.orderData.stopDTOs.locationDTO.contactDTO['contactValue'];
                            if (populateValue) {
                                this.stopForm['controls']['locationContactType'].setValue([{
                                    'id': populateValue,
                                    'text': populateValue
                                }]);
                            }
                        }
                    }
                }, (err: Error) => {
                    return false;
                });
        }
    }
    loadOrderData() {
        this.orderService.getData().subscribe(sharedOrderData => {
            if (!this.jbhGlobals.utils.isEmpty(sharedOrderData)) {
                if (!this.isDataLoaded) {
                    this.orderData = sharedOrderData;
                    if (sharedOrderData && sharedOrderData['orderBillingDetailDTOs'] &&
                        sharedOrderData['orderBillingDetailDTOs'][0] &&
                        sharedOrderData['orderBillingDetailDTOs'][0]['profileDTO']) {
                        this.orderData.partyID = sharedOrderData['orderBillingDetailDTOs'][0]['profileDTO'].partyID;
                    }
                    this.businessUnit = this.orderData.financeBusinessUnitCode;
                    this.serviceOffering = this.orderData.serviceOfferingCode;
                    this.loadStopDetails(this.currentStopId);
                    this.isDataLoaded = true;
                    this.checkDCSFinalMile();
                }
            }
        }, (err: Error) => {
            return false;
        });
        this.stopSharedDataService.getData().subscribe(data => {
            if (this.jbhGlobals.utils.isEmpty(data)) {
                this.stopResequenceDetails = data[0].data;
                // this.loadStopDetails(this.currentStopId);
            }
        });
    }
    getResequenceList() {
        let orderId: any;
        if (this.orderData && this.orderData.orderID) {
            orderId = this.orderData.orderID + '/stops';
            this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getstopresequencelist + orderId).subscribe(data => {
                if (!this.jbhGlobals.utils.isEmpty(data)) {
                    if (data['content'] && data['content'] !== undefined) {
                        this.stopResequenceDetails = data['content'];
                    } else {
                        this.stopResequenceDetails = data;
                    }
                } else if (this.jbhGlobals.utils.isEmpty(data)) {
                    this.stopResequenceDetails = [];
                }
            }, (err: Error) => {
                return false;
            });
        }
    }
    getStopJson(orderId): any {
        const stopId = this.orderData.stopDTOs.stop.stopID;
        let orderID;
        orderID = {
            'orderID': orderId
        };
        let stopServices = '';
        if (this.orderData.stopDTOs.stop.stopServices.length >= 1) {
            stopServices = this.orderData.stopDTOs.stop.stopServices;
        }
        // 'locationContactID': this.orderData.stopDTOs.stop.locationID,
        // 'locationContactType': this.orderData.stopDTOs.stop.locationContactType,
        this.stopJson = {
            'stopID': stopId,
            'locationID': this.orderData.stopDTOs.stop.locationID,
            'locationContactID': this.contactId ? this.contactId : this.orderData.stopDTOs.stop.locationID,
            'locationContactType': this.contactMethod ? this.contactMethod : '',
            'highCostDeliveryIndicator': 'N',
            'stopReason': this.orderData.stopDTOs.stop.stopReason,
            'stopSequenceNumber': this.orderData.stopDTOs.stop.stopSequenceNumber,
            'unitOfWeightMeasurementCode': this.orderData.stopDTOs.stop.unitOfWeightMeasurementCode,
            'initialOfferedDate': this.orderData.stopDTOs.stop.initialOfferedDate,
            'stopServices': stopServices,
            'order': orderID
        };
        if (this.orderData.stopDTOs.stop.stopServices.length < 1) {
            delete this.stopJson['stopServices'];
        }
        return this.stopJson;
    }
    onStopReasonChange(reason: string) {
        this.stopReasonType = reason.trim();
        if (this.stopReasonType === 'Pickup') {
            this.reasonType = 'Shipper';
        } else if (this.stopReasonType === 'Delivery') {
            this.reasonType = 'Receiver';
        }
        this.orderData.stopDTOs.stop.stopReason = this.stopReasonType;
        this.orderData.stopDTOs.stop.stopSequenceNumber = this.stopResequenceDetails[this.stopNumber]['stop']['stopSequenceNumber'];
        if (this.orderData.stopDTOs.stop.locationID !== undefined) {
            this.stopDetailSaveForm('cur', 'noCallBack');
        }
        this.loadStopServicesList();
        this.loadAppointmentInstruction();
        // this.equipmentOptionCheck();
        this.showLabel = true;
        if (this.stopReasonType === 'Delivery' &&
            this.orderData.financeBusinessUnitCode === 'ICS' &&
            this.orderData.serviceOfferingCode === 'LTL') {
            this.isHighCost = true;
        }
    }
    // equipmentOptionCheck() {
    //     if(this.requestedStop === 'Pickup Trailer') {
    //         if( this.isFirstStop) {
    //             this.pickuptrailerModal.show();
    //         }
    //         else if (this.stopReasonType === 'pickup')
    //          {
    //              this.pickuptrailerModal.show();
    //          }
    //       }
    // }
    getLocationTypeAhead(value, roleType) {
        const params = {
            'size': 6,
            '_source': [
                'LocationName',
                'LocationCode',
                'LocationID',
                'locations.AddressLine1',
                'locations.AddressLine2',
                'locations.CityName',
                'locations.StateName',
                'locations.CountryName',
                'locations.PostalCode',
                'locations.LocationRoleTypeDescription',
                'locations.AddressID',
                'locations.CountryCode'
            ],
            'query': {
                'bool': {
                    'should': [
                        {
                            'query_string': {
                                'fields': [
                                    'LocationName^6',
                                    'LocationCode^3'
                                ],
                                'query': value + '*',
                                'default_operator': 'and'
                            }
                        },
                        {
                            'nested': {
                                'path': 'locations',
                                'query': {
                                    'query_string': {
                                        'fields': [
                                            'locations.AddressLine1^18',
                                            'locations.AddressLine2^18',
                                            'locations.CityName^15',
                                            'locations.StateName^12',
                                            'locations.PostalCode^9',
                                            'locations.CountryName'
                                        ],
                                        'query': value + '*',
                                        'default_operator': 'and'
                                    }
                                }
                            }
                        }
                    ],
                    'minimum_should_match': 1,
                    'must': [
                        {
                            'nested': {
                                'path': 'locations',
                                'query': {
                                    'query_string': {
                                        'fields': [
                                            'locations.LocationRoleTypeDescription.keyword'
                                        ],
                                        'query': '(Shipper)(Receiver)',
                                        'split_on_whitespace': false
                                    }
                                },
                                'inner_hits': {
                                    'size': 1,
                                    '_source': {
                                        'includes': [
                                            'locations.AddressLine1',
                                            'locations.AddressLine2',
                                            'locations.CityName',
                                            'locations.StateName',
                                            'locations.CountryName',
                                            'locations.PostalCode',
                                            'locations.LocationRoleTypeDescription',
                                            'locations.AddressID',
                                            'locations.CountryCode'
                                        ]
                                    }
                                }
                            }
                        }
                    ]
                }
            }
        };

        this.jbhGlobals.apiService.addData(this.jbhGlobals.endpoints.order.gettypeaheadlocation, params, false).subscribe(data => {
            // if (data['profileDTO'] !== undefined) {
            //     this.typeAheadList = data['profileDTO'];
            // }
            if (!this.jbhGlobals.utils.isEmpty(data) && data['hits']['hits'].length > 0) {
                this.typeAheadList = [];
                this.jbhGlobals.utils.map(data['hits']['hits'], (items) => {
                    const obj = {},
                        source = items['_source']['locations'][0];
                    obj['name'] = source['AddressLine1'] + ' ' + source['AddressLine2'] + ', ' +
                        source['CityName'] + ', ' + source['StateName'] + ', ' + source['PostalCode'] + ', ' +
                        source['CountryName'] + ', ' + items['_source']['LocationName']
                        + ' (' + ((items['_source']['LocationCode']) ? items['_source']['LocationCode'] : '') + ')';
                    obj['partyId'] = items['_source']['LocationID'];
                    obj['OrgName'] = items['_source']['LocationName'];
                    obj['addressDTO'] = source;
                    this.typeAheadList.push(obj);
					this.changeDetector.detectChanges();
                });
            } else {
                this.typeAheadList = [];
                this.typeAheadList.push({});
            }
        }, (err: Error) => {
            return false;
        });
    }

    addAppointments(appt: number) {
        let count = 0;
        let isReqApptFormValid;
        // let isSchdApptFormValid;
        const stopCtrl = this.orderFormBuilder.getInitDateTimeDetails();
        const apptInstruction = this.orderFormBuilder.getAppointmentInstruction();
        if (appt === 0) {
            if (!this.jbhGlobals.utils.isEmpty(this.apptRequestedChild)) {
                // const isReqApptFormValid = this.jbhGlobals.utils.findIndex(this.apptRequestedChild._results, function (obj) {
                //     return obj.appointmentForm.valid === false;
                // });
                // if (isReqApptFormValid !== -1) {
                //     this.jbhGlobals.notifications.alert('Warning', 'Please enter all the required fields');
                //     return;
                // }
                for (let i = 0; i < this.apptRequestedChild._results.length; i++) {
                    if (this.apptRequestedChild._results[i].apptRequested.appointmentDateTimeDetailID !== '') {
                        count++;
                    }
                }
                if (count === this.apptRequestedChild._results.length) {
                    isReqApptFormValid = true;
                } else {
                    isReqApptFormValid = false;
                }
                if (!isReqApptFormValid) {
                    this.jbhGlobals.notifications.alert('Warning', 'Please enter all the required fields');
                    return;
                }
            }
            if (!this.requestedAppts.appointmentDateTimeDetails) {
                this.requestedAppts.appointmentDateTimeDetails = [stopCtrl.value];
            } else {
                this.requestedAppts.appointmentDateTimeDetails.push(stopCtrl.value);
            }
        } else if (appt === 1) {
            if (!this.jbhGlobals.utils.isEmpty(this.apptScheduledChild)) {
                // const isSchdApptFormValid = this.jbhGlobals.utils.findIndex(this.apptScheduledChild._results, function (obj) {
                //     return obj.appointmentForm.valid === false;
                // });
                for (let i = 0; i < this.apptScheduledChild._results.length; i++) {
                    if (this.apptScheduledChild._results[i].scheduledAppts.appointmentDateTimeDetailID !== '') {
                        count++;
                    }
                }
                if (count === this.apptScheduledChild._results.length) {
                    isReqApptFormValid = true;
                } else {
                    isReqApptFormValid = false;
                }
                if (!isReqApptFormValid) {
                    this.jbhGlobals.notifications.alert('Warning', 'Please enter all the required fields');
                    return;
                }
            }
            if (!this.scheduledAppts.appointmentDateTimeDetails) {
                this.scheduledAppts.appointmentDateTimeDetails = [stopCtrl.value];
            } else {
                this.scheduledAppts.appointmentDateTimeDetails.push(stopCtrl.value);
            }
            if (!this.scheduledAppts.appointmentInstructionAssociations) {
                this.scheduledAppts.appointmentInstructionAssociations = [apptInstruction.value];
            }
        }
    }
    onClickSiteProfileShow(comp, locationId) {
        // this[comp].hide();
        this.popOverFlag = true;
        this.siteprofile.onShowSiteProfileModal(locationId, this.orderData.partyID);
    }
    addStopDetails(stopForm, page, isCallBack, isOrderOwner?): boolean {
        delete stopForm['totalStopWeight'];
        let saveStatus = true;
        if (isOrderOwner && (this.isFirstStop || this.finalStop)) {
            // this.addDataDeliveryStop(); Don't delete this
        }
        this.jbhGlobals.apiService.addData(this.jbhGlobals.endpoints.order.crudStopDetails, stopForm).subscribe(stopData => {
            if (!this.jbhGlobals.utils.isEmpty(stopData)) {
                if (stopData['stopID']) {
                    this.getRecommendedAppt(stopData['stopID']);
                    this.orderData.stopDTOs.stop.stopID = stopData['stopID'];
                    this.addStopsOrderService.saveData(this.orderData);
                    // this.orderService.setWarningFlag(true);
                    this.jbhGlobals.notifications.success('Success', 'Stop Added Successfully');
                    if (page === 'prev') {
                        this.router.navigateByUrl('/createorders/order/create?id=' + this.orderData.orderID);
                    }
                }
                saveStatus = true;
                if (isCallBack !== 'noCallBack') {
                    isCallBack(saveStatus);
                }
                this.stopSharedDataService.getStopsSummary(this.orderData.orderID);
                this.orderService.loadOrder(this.orderData.orderID);
            }
        }, (err: Error) => {
            saveStatus = false;
            if (isCallBack !== 'noCallBack') {
                isCallBack(saveStatus);
            }
        });
        return saveStatus;
    }
    checkDCSFinalMile() {
        if (this.orderData.financeBusinessUnitCode === 'DCS' &&
            this.orderData.serviceOfferingCode === 'FinalMile' &&
            this.orderData.orderTypeCode === 'Standard') {
            this.DCSFMSStandardFlag = true;
        }
    }
    updateStopDetails(stopId, stopForm, page, isCallBack, isOrderOwner): boolean {
        stopForm['totalStopWeight'] = this.currentTotalStopWeight;
        let saveStatus = true;
        if (isOrderOwner && (this.isFirstStop || this.finalStop)) {
            // this.addDataDeliveryStop(); Don't delete this
        }
        this.updateAppointmentDetails();
        this.jbhGlobals.apiService.updateData(this.jbhGlobals.endpoints.order.crudStopDetails + stopId, stopForm).subscribe(stopData => {
            if (!this.jbhGlobals.utils.isEmpty(stopData)) {
                this.getRecommendedAppt(stopData['stopID']);
                this.jbhGlobals.notifications.success('Success', 'Stop Updated Successfully');
                if (page === 'prev') {
                    this.router.navigateByUrl('/createorders/order/create?id=' + this.orderData.orderID);
                }
                saveStatus = true;
                if (isCallBack !== 'noCallBack') {
                    isCallBack(saveStatus);
                }
                this.stopSharedDataService.getStopsSummary(this.orderData.orderID);
                this.orderService.loadOrder(this.orderData.orderID);
            }
        }, (err: Error) => {
            saveStatus = false;
            if (isCallBack !== 'noCallBack') {
                isCallBack(saveStatus);
            }
        });
        return saveStatus;
    }
    /* populateApptInst(eve: any) {
         if (!this.appointmentInsTag.active && this.appointmentInstructionList.length > 0) {
             this.appointmentInsTag.active = [this.appointmentInstructionList[0]];
         }
      } */
    getRecommendedAppt(stopID) {
        const stopParam = this.orderData.orderID + '/stops/' + stopID;
        const stopUrl = this.jbhGlobals.endpoints.order.getstopbyid + stopParam;
        this.jbhGlobals.apiService.getData(stopUrl).subscribe(data => {
            if (data && data !== undefined) {
                data['stop']['appointment'].forEach(appointment => {
                    console.log(appointment['appointmentTypeCode']);
                    if (appointment['appointmentTypeCode'] === 'Recmmended') {
                        this.setRecommendedTime(appointment);
                    }
                });
            }
        });
    }
    setRecommendedTime(appointment) {
        const startDate = moment(appointment['appointmentDateTimeDetails'][0]['appointmentStartTimestamp']).format('MM/DD/YYYY');
        const startTime = moment(appointment['appointmentDateTimeDetails'][0]['appointmentStartTimestamp']).format('h:mm A');
        const startTimeStamp = startDate + ' ' + startTime;
        const endDate = moment(appointment['appointmentDateTimeDetails'][0]['appointmentEndTimestamp']).format('MM/DD/YYYY');
        const endTime = moment(appointment['appointmentDateTimeDetails'][0]['appointmentEndTimestamp']).format('h:mm A');
        const endTimeStamp = endDate + ' ' + endTime;
        this.recommendedAppt = startTimeStamp + ' - ' + endTimeStamp;
    }
    populateStopData(stopData) {
        if (this.isCurrViewTemplate && this.orderData.stopDTOs &&
            this.orderData.stopDTOs.stop) {
            this.locationCode = this.orderData.stopDTOs.stop.locationID;
            this.roleType = 'Shipper';
            this.onSelectContactType(this.locationCode, this.roleType);
        }
        this.serviceTypeCodeTag.active = [];
        const stopLocation = stopData.locationDTO;
        if (stopLocation && stopLocation.addressDTO) {
            const code = stopLocation.locationCode ? stopLocation.locationCode : ' ';
            const partyName = !this.jbhGlobals.utils.isEmpty(stopLocation.partyName) ? stopLocation.partyName : '';
            const addressLine1 = !this.jbhGlobals.utils.isEmpty(stopLocation.addressDTO.addressLineOne) ?
                stopLocation.addressDTO.addressLineOne : '';
            const addressLine2 = !this.jbhGlobals.utils.isEmpty(stopLocation.addressDTO.addressLineTwo) ?
                stopLocation.addressDTO.addressLineTwo : '';
            const city = !this.jbhGlobals.utils.isEmpty(stopLocation.addressDTO.city) ? stopLocation.addressDTO.city : '';
            const country = !this.jbhGlobals.utils.isEmpty(stopLocation.addressDTO.country) ? stopLocation.addressDTO.country : '';
            const state = !this.jbhGlobals.utils.isEmpty(stopLocation.addressDTO.state) ? stopLocation.addressDTO.state : '';
            const zip = stopLocation.addressDTO.zipCode ? stopLocation.addressDTO.zipCode : '';
            this.stopForm['controls']['locationID']['setValue'](partyName + '-' + addressLine1 + ' ' + addressLine2 +
                ',' + city + ' ' + country + ' ' + state + ' ' + zip);
            this.locValue = partyName + ' (' + code + ')';
            this.locPopValue = addressLine1 + ' ' + addressLine2 + ' , ' + city + ' , ' + state + ' , ' + zip + ' , ' + country;
            this.showDetailsIcon = true;
            this.stopForm['controls']['locationID'].setValidators([Validators.required]);
            this.stopForm['controls']['locationID'].updateValueAndValidity();
        }
        this.locationContactHide = true;
        const locationID = this.orderData.stopDTOs.stop.locationID;
        if (!this.isFirstStop && !this.finalStop) {
            this.stopForm['controls']['stopReason']['setValue']([{
                id: stopData.stop.stopReason, text: stopData.stop.stopReason + ' Stop'
            }]);
            this.stopReasonType = stopData.stop.stopReason;
        } else {
            this.orderData.stopDTOs.stop.stopReason = this.stopReasonType;
        }
        this.orderData.stopDTOs.stop.locationID = this.locationCode;
        if (this.stopResequenceDetails[this.stopNumber] && this.stopResequenceDetails[this.stopNumber]['stop'] &&
            this.stopResequenceDetails[this.stopNumber]['stop']['stopSequenceNumber']) {
            this.orderData.stopDTOs.stop.stopSequenceNumber = this.stopResequenceDetails[this.stopNumber]['stop']['stopSequenceNumber'];
        }
        // this.stopForm['controls']['locationContactType']['setValue'](stopData.stop.locationContactType);
        if (stopData.stop.locationContactID && stopData.stop.locationContactType) {
            if (stopData.locationDTO && stopData.locationDTO.contactDTO && stopData.locationDTO.contactDTO.length === 1) {
                const contactComboValue = stopData.locationDTO.contactDTO[0];
                this.onSelectContactType(stopData.locationDTO.partyID, this.roleType, contactComboValue);
            }
        }
        this.locationCode = stopData.locationDTO.partyID;
        this.onSelectContactType(stopData.locationDTO.partyID, this.roleType);
        this.orderData.stopDTOs.stop.locationID = locationID;
        this.scheduledApptData = this.jbhGlobals.utils.find(stopData.stop.appointment, {
            appointmentTypeCode: 'Scheduled'
        });
        // for (let i = 0; i < stopServices.length; i++) {
        //  this.serviceTypeCodeTag.active.push({
        //     id: stopServices[i].serviceLevelTypeCode,
        //    text: stopServices[i].serviceType
        //  });
        // }

        if (stopData.stop.highCostDeliveryIndicator === 'Y') {
            this.isHighCost = true;
            this.stopForm['controls']['highCostDeliveryIndicator']['setValue']([{
                checked: 'checked'
            }]);
        }
        setTimeout(() => {
            this.loadAppointmentInstruction();
        }, 500);
    }
    stopDetailSaveForm(page, saveStatus, isOrderOwner?): boolean {
        let isFormTouched = false;
        let apptArr: any = '';
        let scheduledAppt = {};
        if (this.stopForm.touched && this.stopForm.dirty) {
            if (this.stopServices.touched && this.stopServices.dirty) {
                this.orderData.stopDTOs.stop.stopServices = [];
                this.orderData.stopDTOs.stop.stopServices = this.serviceLevelTypeCodeObj;
            }
            isFormTouched = true;
        }
        if (this.scheduledForm.touched && this.scheduledForm.dirty) {
            if (this.orderData.stopDTOs.stop &&
                !this.jbhGlobals.utils.isEmpty(this.orderData.stopDTOs.stop.appointment)) {
                apptArr = this.orderData.stopDTOs.stop.appointment;
                scheduledAppt = this.jbhGlobals.utils.find(apptArr, {
                    appointmentTypeCode: 'Scheduled'
                });
            }
            scheduledAppt['appointmentConfirmationNumber'] = this.appointmentNumber.nativeElement.value;
            isFormTouched = true;
        }
        if (this.appointmentInstruction.touched && this.appointmentInstruction.dirty) {
            if (scheduledAppt && scheduledAppt !== undefined) {
                scheduledAppt['appointmentInstructionAssociations'] = [];
                scheduledAppt['appointmentInstructionAssociations'] = this.appointmentInstructionObj;
            }
            isFormTouched = true;
        }
        if (isFormTouched) {
            if (this.isCurrViewTemplate) {
                // const orderID = this.orderData.orderID;
                // this.stopJson = this.getStopJson(orderID);
                // this.orderService.saveData(this.orderData);
                this.addStopsOrderService.saveData(this.orderData);
            } else {
                let stopID = this.orderData.stopDTOs.stop.stopID;
                const orderID = this.orderData.orderID;
                this.stopJson = this.getStopJson(orderID);
                if (stopID && stopID !== undefined) {
                    stopID = '/' + stopID;
                    return this.updateStopDetails(stopID, this.stopJson, page, saveStatus, isOrderOwner);
                } else {
                    return this.addStopDetails(this.stopJson, page, saveStatus, isOrderOwner);
                }
            }
        } else if (!isFormTouched && page === 'prev' && !this.isCurrViewTemplate) {
            this.router.navigateByUrl('/createorders/order/create?id=' + this.orderData.orderID);
            this.jbhGlobals.commonDataService.setFromStopCheckFlag(true);
        }
    }
    enterToClick(event) {
        if (event.keyCode === 13) {
            event.currentTarget.click();
        }

    }
    popoverSelected(value, popover) {
        if (value === 'Requested') {
            this.appType = 'Requested';
        } else if (value === 'Scheduled') {
            this.appType = 'Scheduled';
        }
    }
    resequencedDetails(value) {
        for (const appts of value) {
            if (appts['appointmentTypeCode'] === 'Requested') {
                this.requestedAppts = appts;
            } else if (appts['appointmentTypeCode'] === 'Scheduled') {
                this.scheduledAppts = appts;
            }
        }
        this.orderData.stopDTOs.stop.appointment = value;
        this.resequenceFlagReq = true;
    }
    highCost(event) {
        const stopId = this.orderData.stopDTOs.stop.stopID;
        const stopUrl = this.jbhGlobals.endpoints.order.highCost + stopId;
        const obj = { 'stopID': stopId, 'highCostDeliveryIndicator': null };
        if (event.target.checked) {
            obj.highCostDeliveryIndicator = 'Y';
        } else {
            obj.highCostDeliveryIndicator = 'N';
        }
        this.jbhGlobals.apiService.patchData(stopUrl, obj).subscribe(response => {
            console.log(response);
        });
    }
    updateAppointmentDetails() {
        const scheduledAppt = this.jbhGlobals.utils.find(this.orderData.stopDTOs.stop.appointment, {
            appointmentTypeCode: 'Scheduled'
        });
        if (scheduledAppt !== undefined && this.isAppointmentNumberAdded || this.isAppointmentInsAdded) {
            let data = {
                'appointmentID': scheduledAppt.appointmentID,
                'appointmentTypeCode': 'Scheduled',
                'appointmentConfirmationNumber': scheduledAppt.appointmentConfirmationNumber,
                'requestCallBackIndicator': 'Y',
                'appointmentInboundDate': '',
                'appointmentDetails': [{
                    'appointmentDetailID': scheduledAppt.appointmentDetails['0'].appointmentDetailID,
                    'appointmentSetReasonCode': '02'
                }],
                'appointmentDateTimeDetails': scheduledAppt.appointmentDateTimeDetails,
                'appointmentInstructionAssociations': scheduledAppt.appointmentInstructionAssociations,
                'stop': {
                    'stopID': this.orderData.stopDTOs.stop.stopID
                }
            };
            if (data['appointmentInstructionAssociations'] && data['appointmentInstructionAssociations'].length !== 0 &&
                !data['appointmentInstructionAssociations'].appointmentInstruction) {
                data['appointmentInstructionAssociations'] = [];
            }
            this.isAppointmentNumberAdded = false;
            this.isAppointmentInsAdded = false;
            this.jbhGlobals.apiService.updateData(this.jbhGlobals.endpoints.order.crudApptDetails + '/' +
                scheduledAppt['appointmentID'], data).subscribe(apptData => { });
        }
    }
    scheduledApptDetail(value) {
        this.isScheduledExist = false;
        this.scheduledForm.controls['appointmentConfirmationNumber'].enable();
    }
    recommendedApptDetail(value) {
        this.recommendedAppt = value;
    }
    onPopOverBlur(popup): void {
        const scope = this;
        this.popOverFlag = true;
        setTimeout(() => {
            const popOVerList = this.popoverDiv['nativeElement'];
            popOVerList.setAttribute('tabindex', '1');
            popOVerList.focus();
            popOVerList.addEventListener('blur', function (event) {
                if (scope.popOverFlag) {
                    popup.hide();
                    scope.popOverFlag = false;
                }
            });
        }, 500);
    }
}
