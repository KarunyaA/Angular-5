import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { JBHGlobals } from 'app/app.service';

@Injectable()
export class StopSharedDataService {
    sharingData: BehaviorSubject<any[]>;
    indicator: string;
    constructor(public jbhGlobals: JBHGlobals) {
        this.sharingData = <BehaviorSubject<any[]>>new BehaviorSubject([]);
    }

    getStopsSummary(orderNo): void {
        // if (!this.jbhGlobals.utils.isEmpty(orderNo)) {
        const orderId = Number(orderNo);
        const url = this.jbhGlobals.endpoints.order.getstopresequencelist + orderId + '/stops';
        this.jbhGlobals.apiService.getData(url).subscribe(data => {
            const stops = this.addDefaultStops(data);
            this.saveData(stops, 'add');
        });
        // }
    }
    addDefaultStops(data): any {
        let stopCtrl;
        if (data.length === 1) {
            if (data[0]['stop']['stopSequenceNumber'] === 1) {
                stopCtrl = {
                    'stop': {
                        'stopID': '',
                        'stopSequenceNumber': 2
                    }
                };
                data.push(stopCtrl);
            } else {
                stopCtrl = {
                    'stop': {
                        'stopID': '',
                        'stopSequenceNumber': 1
                    }
                };
                data.splice(0, 0, stopCtrl);
            }
        } else if (data.length === 0) {
            data.push({
                stop: {
                    stopID: null,
                    stopSequenceNumber: 1
                }
            });
            data.push({
                stop: {
                    stopID: null,
                    stopSequenceNumber: 2
                }
            });
        } else if (data.length > 1) {
            if (data[(data.length - 1)]['stop']['stopReason'] === 'Pickup') {
                const lastStop = data[(data.length - 1)]['stop']['stopSequenceNumber'];
                stopCtrl = {
                    'stop': {
                        'stopID': '',
                        'stopSequenceNumber': (lastStop + 1)
                    }
                };
                data.push(stopCtrl);
            }
        }
        return data;
    }
    saveData(stopData, action?): void {
        const data = [{
            action: action,
            data: stopData
        }];
        this.sharingData.next(data);
    }
    getData() {
        return this.sharingData.asObservable();
    }
    setTrailerPreloadedIndicator(indicator: string): void {
        this.indicator = indicator;
    }
    getTrailerPreloadedIndicator(): string {
        return this.indicator;
    }
}
