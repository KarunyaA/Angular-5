import { Component, Input, OnDestroy, OnInit, ViewContainerRef } from '@angular/core';
import { JBHGlobals } from '../../../../../app.service';
import { AddStopsOrderService } from './../services/add-stops-order.service';
import { HandlingunitService } from '../services/handlingunit.service';

@Component({
  selector: 'app-delivery-handling-units',
  templateUrl: './delivery-handling-units.component.html',
  styleUrls: ['./delivery-handling-units.component.scss']
})
export class DeliveryHandlingUnitsComponent implements OnInit, OnDestroy {
  @Input() isCurrViewTemplate: any;
  handlingUnitList: Array<Object>;
  handlingUnitSelectedList: Array<Object>;
  orderData: any;
  stopId: any;
  orderId: any;
  isDataLoaded = true;
  private subscriptions: any = [];

  constructor(public jbhGlobals: JBHGlobals,
              public orderService: AddStopsOrderService,
              private viewContainerRef: ViewContainerRef,
              public handlingService: HandlingunitService) { }

  ngOnInit(): void {
    this.loadOrderData();
  }
  ngOnDestroy(): void {
    for (const subs of this.subscriptions) {
      subs.unsubscribe();
    }
   }
  loadOrderData() {
       this.subscriptions.push(this.orderService.getData().subscribe( sharedOrderData => {
            this.orderData = sharedOrderData;
            if (this.orderData.stopDTOs) {
              this.stopId = this.orderData.stopDTOs.stop.stopID;
              this.orderId = this.orderData.orderID;
              if (this.stopId && this.isDataLoaded) {
                this.stopServiceCall();
              }
            }
            this.isDataLoaded = false;
        }));
  }
  stopServiceCall(): void {
    const url = this.jbhGlobals.endpoints.order.getstopbyid + '' + this.orderId + '/stops/' + this.stopId;
    this.handlingService.getStopDetails(url).subscribe(data => {
      if (data) {
        const list = data['itemHandlingDetailDTOs'];
        this.handlingUnitSelectedList = list;
        this.servicecall();
      } else {
        this.servicecall();
      }
    });
  }

  servicecall(): void {
    const url = this.jbhGlobals.endpoints.order.updateorder + '' + this.orderId + '/fetchUnDeliveredItems';
    this.handlingService.fetchUndeliveredHandling(url).subscribe(data => {
      this.handlingUnitList = data;
      console.log(this.handlingUnitList);
    }
    );
  }

  saveCallOnClick(obj: Object, parent: any): void {
    const stopId = this.stopId,
      checkbox = event.target;
    if (checkbox['checked']) {
      this.formSaveServiceCall(obj, stopId, parent, checkbox);
    } else {
      const itemhandLingId = obj['itemHandlingDetail']['itemHandlingDetailID'];
      this.formDeleteServiceCall(stopId, itemhandLingId, 'Delivery', parent, checkbox);
    }
  }
  formSaveServiceCall(obj, stopId, parent, checkbox) {
    let params = {};
    if (stopId) {
        const url = this.jbhGlobals.endpoints.order.crudHandlingUnit + '/' + stopId + '/itemhandlingdetails';
        params = obj;
        this.handlingService.addHandlingData(url, params).subscribe(data => {
          this.stopServiceCall();
        }, (err: Error) => {
          checkbox['checked'] = false;
        });
    }
  }

  formDeleteServiceCall(stopId, handlingUnitId, reason, parent, checkbox) {
    const url = this.jbhGlobals.endpoints.order.crudHandlingUnit + '/' + stopId + '/itemhandlingdetails/' + handlingUnitId;
    this.handlingService.removeHandlingData(url).subscribe(data => {
      this.stopServiceCall();
    }, (err: Error) => {
      checkbox['checked'] = true;
    });
  }
}
