import { inject, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';

import { StopSharedDataService } from './stop-shared-data.service';

import { AppModule } from '../../../../../app.module';

describe('StopSharedDataService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
imports: [AppModule, RouterTestingModule],
      providers: [StopSharedDataService]
    });
  });

  it('should be created', inject([StopSharedDataService], (service: StopSharedDataService) => {
    expect(service).toBeTruthy();
  }));
});
