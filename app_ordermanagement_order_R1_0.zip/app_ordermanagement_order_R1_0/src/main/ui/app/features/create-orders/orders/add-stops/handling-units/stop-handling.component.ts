import { Component, Input, OnDestroy, OnInit, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { JBHGlobals } from '../../../../../app.service';
import { AddStopsOrderService } from './../services/add-stops-order.service';
import { OrderFormBuilderService } from '../../services/order-form-builder.service';
import { HandlingUnitsComponent } from '../handling-units/handling-units.component';
import { HandlingunitService } from '../services/handlingunit.service';

@Component({
  selector: 'app-stop-handling',
  templateUrl: './stop-handling.component.html',
  providers: [HandlingunitService],
  styleUrls: ['./stop-handling.component.scss']
})
export class StopHandlingComponent implements OnInit, OnDestroy {
    @Input() isCurrViewTemplate: any;
    @ViewChild('handlingUnit') handlingUnit: any;
    @ViewChild('itemDetailsRef') itemDetailsRef: any;
    getHandlingData: any;
    handlingForm: any;
    orderData: any;
    private subscriptions: any = [];
    volumeVal: any;
    itemDensity: any;
    itemDensityVal: any;
    serviceList = {};
    @ViewChildren(HandlingUnitsComponent) handlingComponent: QueryList<HandlingUnitsComponent>;

  constructor(public jbhGlobals: JBHGlobals,
              public orderService: AddStopsOrderService,
              public orderFormBuilder: OrderFormBuilderService,
              private handlingService: HandlingunitService) {}

   ngOnInit(): void {
      this.handlingForm =  this.orderFormBuilder.addHandlingUnit();
      this.loadOrderData();
      this.loadHandlingWeight();
      this.loadStopMock();
  }
  ngOnDestroy(): void {
    this.handlingForm.reset();
    for (const subs of this.subscriptions) {
          subs.unsubscribe();
        }
   }
   loadOrderData() {
       this.subscriptions.push(this.orderService.getData().subscribe( sharedOrderData => {
             if (!this.jbhGlobals.utils.isEmpty(sharedOrderData)) {
                    this.orderData = sharedOrderData;
                 }
       }));
    }
    loadHandlingWeight() {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getUnitOfWeight).subscribe(data => {
            this.serviceList['weight'] = data['_embedded']['unitOfWeightMeasurements'];
        });
    }
   loadStopMock() {
        const url = this.jbhGlobals.endpoints.order.getstopmockdata;
        this.jbhGlobals.apiService.getData(url).subscribe(data => {
            this.serviceList['stopMock'] = data;
        });
    }
   conversionToInches(value, unit) {
        let measurement;
        switch (unit) {
            case 'Centimeter':
                measurement = parseFloat(value) / 2.54;
                break;
            case 'Feet':
                measurement = parseFloat(value) * 12;
                break;
            case 'Kilometers':
                measurement = parseFloat(value) * 39379.96;
                break;
            case 'Meter':
                measurement = parseFloat(value) / 0.0254;
                break;
            case 'Miles':
                measurement = parseFloat(value) * 63360;
                break;
            case 'Inches':
                measurement = parseFloat(value);
                break;
            default:
                break;
        }
        return measurement;
    }
    conversionToFeet(value, unit) {
        switch (unit) {
            case 'Centimeter':
                value = parseFloat(value) / 30.48;
                break;
            case 'Inches':
                value = parseFloat(value) / 12;
                break;
            case 'Kilometers':
                value = parseFloat(value) * 3280.8398950131;
                break;
            case 'Meter':
                value = parseFloat(value) / 0.3048;
                break;
            case 'Miles':
                value = parseFloat(value) * 5280;
                break;
            case 'Inches':
                value = parseFloat(value);
                break;
            default:
                break;
        }
        return value;
    }
    weightConversion(value, unit) {
        let weight;
        switch (unit) {
            case 'Grams':
                weight = parseFloat(value) / 453.59237;
                break;
            case 'Kilogram':
                weight = parseFloat(value) / 0.45359237;
                break;
            case 'MetricTons':
                weight = parseFloat(value) / 0.00045359237;
                break;
            case 'Ounces':
                weight = parseFloat(value) / 16;
                break;
            case 'Tons':
                weight = parseFloat(value) / 0.00045359237;
                break;
            case 'Pounds':
                weight = parseFloat(value);
                break;
            default:
                break;
        }
        return weight;
    }
}
