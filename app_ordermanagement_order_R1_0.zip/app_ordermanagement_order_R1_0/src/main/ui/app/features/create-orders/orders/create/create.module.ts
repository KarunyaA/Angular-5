import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RlTagInputModule } from '../../../../shared/tag-input';
import { TagInputModule } from 'ng2-tag-input';
import { TypeaheadModule } from '../../../../shared/jbh-typeahead/typeahead.module';
import { PopoverModule } from 'ngx-bootstrap/popover';
import { ModalModule } from 'ngx-bootstrap';
import { TextMaskModule } from 'angular2-text-mask';
// import { SelectModule } from 'ng2-select';
import { SelectModule } from '../../../../shared/select';
import { JBHDataTableModule } from 'app/shared/jbh-data-table/jbh-data-table.module';

import { CreateRoutingModule } from './create-routing.module';
import { CreateComponent } from './create.component';
import { AccountinformationComponent } from './accountinformation/accountinformation.component';
import { ServiceofferingComponent } from './serviceoffering/serviceoffering.component';
import { ShipmentinformationComponent } from './shipmentinformation/shipmentinformation.component';
import { OperationinformationComponent } from './operationinformation/operationinformation.component';
import { AccountInfoTypeaheadComponent } from './accountinformation/accountinfotypeahead/accountinfotypeahead.component';
// import { ManageoverlayModule } from '../manageoverlay/manageoverlay.module';
// import { AddcontactComponent } from './accountinformation/addcontact/addcontact.component';
// import { OrderFormBuilderService} from '../services/order-form-builder.service';
import { SharedModule } from '../../../../shared/shared.module';
import { ConfirmationPopupModule } from '../../../../shared/confirmation-popup/confirmation-popup.module';
import { CreateService } from './services/create.service';
import { AddcontactsModule } from '../addcontacts/addcontacts.module';
import { MyDatePickerModule } from 'mydatepicker';

@NgModule({
  imports: [
    CommonModule,
    JBHDataTableModule,
    PopoverModule.forRoot(),
    ModalModule.forRoot(),
    FormsModule,
    ReactiveFormsModule,
    TypeaheadModule.forRoot(),
    RlTagInputModule,
    CreateRoutingModule,
    MyDatePickerModule,
    SharedModule,
    TextMaskModule,
    AddcontactsModule,
    // ManageoverlayModule,
    TagInputModule,
    SelectModule,
    ConfirmationPopupModule
  ],
  providers: [CreateService],
  declarations: [
    CreateComponent,
    AccountinformationComponent,
    ServiceofferingComponent,
    ShipmentinformationComponent,
    OperationinformationComponent,
    AccountInfoTypeaheadComponent

  ],
  exports: [
    CreateComponent,
    AccountinformationComponent,
    ServiceofferingComponent,
    ShipmentinformationComponent,
    OperationinformationComponent
  ]
})

/*
  CreateModule - This module contains create component module and manage overlay module
                    - It helps to generate an order by its components.
*/
export class CreateModule { }
