import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { CreateOrdersRoutingModule } from './create-orders-routing.module';
import { CreateOrdersComponent } from './create-orders.component';
import { OrderService } from './orders/services/order.service';
import { StopSharedDataService } from './orders/add-stops/services/stop-shared-data.service';
import { TemplateJsonTransformerService } from './templates/template-json-transformer.service';
import { JbhJsonTransformerService } from './orders/services/jbh-json-transformer.service';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        CreateOrdersRoutingModule
    ],
    declarations: [CreateOrdersComponent],
    providers: [OrderService,
        StopSharedDataService,
        JbhJsonTransformerService,
        TemplateJsonTransformerService]
})

export class CreateOrdersModule { }
