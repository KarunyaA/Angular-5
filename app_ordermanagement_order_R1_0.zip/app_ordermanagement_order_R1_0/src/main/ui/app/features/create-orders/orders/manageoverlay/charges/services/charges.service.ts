import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Response } from '@angular/http';

import { JBHGlobals } from '../../../../../../app.service';

@Injectable()
export class ChargesService {
  constructor(private jbhGlobals: JBHGlobals) { }

  createCharge(chargeDTO, addcharges): Observable<Response[]> {
    return this.jbhGlobals.apiService
      .addData(chargeDTO.endpoint, addcharges);
  }
  readCharge(chargeDTO): Observable<Response[]> {
    return this.jbhGlobals.apiService
      .getData(chargeDTO.endpoint + chargeDTO.chargeID + chargeDTO.chargePath);
  }
  updateCharge(chargeDTO, udpateCharges): Observable<Response[]> {
    return this.jbhGlobals.apiService
      .updateData(chargeDTO.endpoint + chargeDTO.chargeID, udpateCharges);
  }
  deleteCharge(chargeDTO): Observable<Response[]> {
    return this.jbhGlobals.apiService
      .removeData(chargeDTO.endpoint + chargeDTO.chargeID);
  }
  retreiveChargeCode(endpoint): Observable<Response[]> {
    return this.jbhGlobals.apiService
      .getData(endpoint);
  }
  retreiveUnitCode(endpoint, param): Observable<Response[]> {
    return this.jbhGlobals.apiService
      .getData(endpoint, param);
  }
}
