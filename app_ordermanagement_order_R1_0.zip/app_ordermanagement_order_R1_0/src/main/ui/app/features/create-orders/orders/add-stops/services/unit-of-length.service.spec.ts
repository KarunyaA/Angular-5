import { inject, TestBed } from '@angular/core/testing';

import { UnitOfLengthService } from './unit-of-length.service';

describe('UnitOfLengthService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [UnitOfLengthService]
    });
  });

  it('should be created', inject([UnitOfLengthService], (service: UnitOfLengthService) => {
    expect(service).toBeTruthy();
  }));
});
