export class AddContactModel {
    subscriberFlag: any;
    orderData: any;
    orderdtoList: any;
    formValue: any;
}
