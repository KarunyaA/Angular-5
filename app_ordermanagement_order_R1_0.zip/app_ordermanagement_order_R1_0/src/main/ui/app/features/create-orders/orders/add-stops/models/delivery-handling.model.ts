export class DeliveryHandling {
}
