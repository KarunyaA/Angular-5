import { OrderRuleCriteriaDetail } from '../model/orderrulecriteriadetail.model';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/finally';
import { OrderRuleCriteriaSet } from '../model/orderrulecriteriaset.model';
import { FormArray, FormBuilder, Validators } from '@angular/forms';
import { OrderRuleParameter } from '../model/orderruleparameter.model';
import { RulesService } from '../rules.service';
import { JBHGlobals } from '../../../app.service';
import { IMyDate, IMyDateModel, IMyOptions } from 'mydatepicker';
import { DatePipe } from '@angular/common';
import * as moment from 'moment';

@Component({
    selector: 'app-configure-rule',
    templateUrl: './configure-rule.component.html',
    styleUrls: ['./configure-rule.component.scss'],
    providers: [DatePipe]
})

export class ConfigureRuleComponent implements OnInit {
    rule: Observable<OrderRuleCriteriaSet>;
    isLoading = false;
    selectedRule: any;
    ruleForm: any;
    orderRuleDetailID: number;
    orderRuleCriteriaSetID: number;
    orderRuleName: string;
    orderRuleDescription: string;
    associationLevel: string;
    businessUnit: string;
    businessUnitServiceOffering: string;
    isBusinessUnitLevelRules: boolean;
    isCustomerLevelRules: boolean;
    billTo: Object;
    mode: string;
    resultantActions: any[] = [];
    title: string;
    attributesList: any;
    orderRuleCriteriaList: any;
    buSoList: any[] = [];
    channelList: any[] = [];
    orderRuleParameterTypeList: any;
    serviceOfferingList: any[] = [];
    selectedParamType = '';
    orderRuleOperatorsList: any;
    isMulAllowed = false;
    // locationLoading:  boolean;
    // locationNoResults:  boolean;
    @ViewChild('ruleFormId') ruleFormId: any;
    focusFlag = 0;
    effectiveDateFlag = false;
    expirationDateFlag = false;
    dateCompareFlag = false;
    timeCompareFlag = false;
    effTimeError = 'Effective time';
    expTimeError = 'Expiration time';
    orderChannel = 'Order creation channel';
    @ViewChild('formHeaderSectionKey') formHeaderSectionKey;
    @ViewChild('formMiddleSectionKey') formMiddleSectionKey;
    @ViewChild('formBottomSectionKey') formBottomSectionKey;
    @ViewChild('serviceOfferingKey') serviceOfferingKey: ElementRef;
    @ViewChild('ruleOverviewKey') ruleOverviewKey: ElementRef;
    @ViewChild('AttributeViewComponent') AttributeViewComponent;
    @ViewChild('effectiveDatePicker') effectiveDatePicker;
    @ViewChild('expirationDatePicker') expirationDatePicker;
    @ViewChild('bu') bu;
    @ViewChild('so') so;
    displayBU = false;
    displaySO = false;
    roleType: string;
    datePickerOptions: IMyOptions = {
        todayBtnTxt: 'Today',
        dateFormat: 'mm-dd-yyyy',
        firstDayOfWeek: 'mo',
        showClearDateBtn: false,
        editableDateField: false,
        sunHighlight: true,
        height: '34px',
        inline: false,
        selectionTxtFontSize: '14px'
    };
    selEffDate: IMyDate = {
        year: 0,
        month: 0,
        day: 0
    };
    selExpDate: IMyDate = {
        year: 0,
        month: 0,
        day: 0
    };
    effectiveDate: number;
    expirationDate: number;
    effectiveTime: any;
    expirationTime: any;
    effectiveTimeMinutes: any;
    expirationTimeMinutes: any;
    validBUSOValues: any[] = [];
    bindValidSOValues: any[] = [];
    bindValidBUValues: any[] = [];
    orderRuleCategoryDescription: any;
    saveFlag = false;
    soRadioCheck: boolean;
    buRadioCheck: boolean;

    startTimeMeridian = false;
    endTimeMeridian = false;
    apptStartTime: any;
    apptEndTime: any;
    myEndTime: Date = new Date();
    myStartTime: Date = new Date();

    constructor(private router: Router, private fb: FormBuilder, private datePipeObj: DatePipe,
                private ruleService: RulesService,
                private jbhGlobals: JBHGlobals) {
        this.createForm();
        this.setRuleOverviewDetails();
    }
    busoRadioCheck() {
        if (this.mode === 'new') {
            this.buRadioCheck = true;
        } else {
            if (!this.jbhGlobals.utils.isEmpty(this.businessUnit) && this.jbhGlobals.utils.isArray(this.businessUnit)) {
                if (this.businessUnit.length > 0) {
                    this.buRadioCheck = true;
                }
            } else if (this.associationLevel === 'BusUnit') {
                this.buRadioCheck = true;
            } else {
                this.soRadioCheck = true;
            }
        }
    }
    binValidBUSO() {
        if (!this.jbhGlobals.utils.isEmpty(this.validBUSOValues) && this.jbhGlobals.utils.isArray(this.validBUSOValues)) {
            for (let i = 0; i < this.validBUSOValues.length; i++) {
                if (this.validBUSOValues[i].businessUnit !== null && this.validBUSOValues[i].serviceOffering !== null) {
                    if (this.validBUSOValues[i].serviceOffering === 'All') {
                        this.bindValidBUValues.push(this.validBUSOValues[i].businessUnit);
                    } else {
                        this.bindValidSOValues.push(this.validBUSOValues[i].businessUnit + '-' + this.validBUSOValues[i].serviceOffering);
                    }
                } else if (this.validBUSOValues[i].businessUnit !== null && this.validBUSOValues[i].serviceOffering === null) {
                    this.bindValidBUValues.push(this.validBUSOValues[i].businessUnit);
                }
            }
        }
    }
    createForm() {
        const ruleDet = this.ruleService.ruleDetails;
        this.ruleForm = this.fb.group({
            orderRuleCriteriaSetID: ruleDet.orderRuleCriteriaSetID,
            orderRuleDetailID: ruleDet.orderRuleDetailID,
            serviceOffering: [
                [], this.jbhGlobals.customValidator.mandatorySelect
            ],
            businessUnit: [
                [], this.jbhGlobals.customValidator.mandatorySelect
            ],
            orderCreationChannel: [
                [], Validators.compose([this.jbhGlobals.customValidator.mandatorySelect])
            ],
            orderRuleSupersedeTypeCode: (ruleDet.orderRuleSupersedeTypeCode === 'Suprsed') ? true : false,
            effectiveDate: ['', Validators.required],
            expirationDate: ['', Validators.required],
            effectiveTime: ['', this.jbhGlobals.customValidator.mandatory],
            expirationTime: ['', this.jbhGlobals.customValidator.mandatory],
            effectiveTimestamp: '',
            expirationTimestamp: '',
            orderRuleCriteriaDetail: this.fb.array([
                this.initCriteriaDetails(null)
            ]),
            orderRuleParameterDetail: this.ruleService.ruleDetails.mode === 'new' ? null : this.fb.array([
                this.initOrderRuleParameterDetails(null)
            ])
        });
    }

    initCriteriaDetails(currSet) {
        const orderRuleCriteriaDescriptionVal = (currSet !== null) ? currSet.orderRuleCriteriaDescription : '';
        const orderRuleLogicalOperatorCodeVal = (currSet !== null) ? currSet.orderRuleLogicalOperatorDTO.orderRuleLogicalOperatorCode : '';
        return this.fb.group({
            orderRuleLogicalOperatorDTO: this.fb.group({
                orderRuleLogicalOperatorCode: [orderRuleLogicalOperatorCodeVal, this.jbhGlobals.customValidator.mandatorySelect]
            }),
            orderRuleCriteriaValue: [(currSet !== null) ? currSet.orderRuleCriteriaValue : '', this.jbhGlobals.customValidator.mandatory],
            orderRuleCriteriaValueEnd: (currSet !== null) ? currSet.orderRuleCriteriaValueEnd : '',
            orderRuleCriteriaDetailEndLimitID: (currSet !== null) ? currSet.orderRuleCriteriaDetailEndLimitID : null,
            orderRuleCriteriaDetailID: (currSet !== null) ? currSet.orderRuleCriteriaDetailID : null,
            orderRuleCriteriaDescription: [orderRuleCriteriaDescriptionVal],
            orderRuleCriteriaCode: [(currSet !== null) ? currSet.orderRuleCriteriaCode : '', this.jbhGlobals.customValidator.mandatory]
        });
    }
    initOrderRuleParameterDetails(currSet) {
        const isValid = (currSet !== null);
        const isTypeValid = (currSet !== null && currSet.orderRuleParameterTypeDTO !== null);
        return this.fb.group({
            orderRuleParameterID: isValid ? currSet.orderRuleParameterID : '',
            orderParameterName: isValid ? currSet.orderParameterName : '',
            orderParameterNumberValue: isValid ? currSet.orderParameterNumberValue : '',
            orderParameterCharValue: isValid ? currSet.orderParameterCharValue : '',
            orderParameterDateValue: isValid ? currSet.orderParameterDateValue : '',
            orderRuleParameterTypeDTO: (currSet !== null) ? this.fb.group({
                orderRuleParameterTypeCode: isTypeValid ? currSet.orderRuleParameterTypeDTO.orderRuleParameterTypeCode : '',
                orderRuleParameterTypeDescription: isTypeValid ? currSet.orderRuleParameterTypeDTO.orderRuleParameterTypeDescription : '',
                orderRuleParameterValueTypeCode: isTypeValid ? currSet.orderRuleParameterTypeDTO.orderRuleParameterValueTypeCode : ''
            }) : null
        });
    }
    initOrderRuleParameterDetailsOnRuleCreation(pName, pTypeCode, pValTypeCode) {
        return this.fb.group({
            orderRuleParameterID: null,
            orderParameterName: pName,
            orderParameterType: pTypeCode,
            orderParameterNumberValue: null,
            orderParameterCharValue: null,
            orderParameterDateValue: null,
            orderRuleParameterTypeDTO: this.fb.group({
                orderRuleParameterTypeCode: pTypeCode,
                orderRuleParameterTypeDescription: pTypeCode,
                orderRuleParameterValueTypeCode: pValTypeCode
            })
        });
    }
    ngOnInit(): void {
        this.loadOrderRuleCriterias();
        this.setUpKeyboardShortcuts();
        this.myStartTime = this.setInitialTime();
        this.myEndTime = this.setInitialTime();
    }
    loadAllAttributes() {
        // Get all Attributes
        const loadAttrURL = this.jbhGlobals.endpoints.automationrules.getAllAttributeTypes;
        this.jbhGlobals.apiService.getData(loadAttrURL).subscribe(data => {
            this.attributesList = data['attributes'];
            this.getRule();
        });
    }
    getRule() {
        this.selectedRule = this.ruleService.selectedCriteriaDetails;
        if (this.selectedRule !== null) {
            this.ruleForm.reset({
                orderRuleCriteriaSetID: this.ruleService.ruleDetails.orderRuleCriteriaSetID,
                orderRuleDetailID: this.ruleService.ruleDetails.orderRuleDetailID,
                /*serviceOffering: this.selectedRule.serviceOffering,
                orderCreationChannel: this.selectedRule.orderCreationChannel,*/
                orderRuleSupersedeTypeCode: this.selectedRule.orderRuleSupersedeTypeCode
            });
            this.setDateTime(this.ruleService.ruleDetails.effectiveTimestamp, this.ruleService.ruleDetails.expirationTimestamp);
            this.setOrderRuleCriterias(this.selectedRule.orderRuleCriteriaDetailDTO);
            this.setOrderRuleParameters(this.selectedRule.orderRuleParameterDTO);
        } else if (this.selectedRule === null &&
            this.resultantActions !== null &&
            this.resultantActions['resultantParameterDTO'] !== undefined &&
            this.resultantActions['resultantParameterDTO'].length > 0) {
            this.setOrderRuleParametersOnRuleCreation(this.resultantActions['resultantParameterDTO']);
        }
    }
    setDateTime(effDate, expDate) {
        this.selEffDate = this.getDateFormat(effDate);
        this.selExpDate = this.getDateFormat(expDate);
        this.myStartTime = effDate;
        this.myEndTime = expDate;
        this.startTimeMeridian = true;
        this.endTimeMeridian = true;
    }
    getDateFormat(date) {
        const dt: Date = new Date(date);
        return {
            year: dt.getFullYear(),
            month: dt.getMonth() + 1,
            day: dt.getDate()
        };
    }
    setDateTimeFormat(date, time) {
        const dateTime = new Date(date);
        dateTime.setHours(time.getHours());
        dateTime.setMinutes(time.getMinutes());
        const hoursFormat = ('0' + dateTime.getHours()).slice(-2);
        const minsFormat = ('0' + dateTime.getMinutes()).slice(-2);
        return moment(dateTime).format('YYYY-MM-DDTHH:mm:ss');
    }
    setDateTimeFormatFromDt(date, time) {
        const dateTime = new Date();
        dateTime.setFullYear(date.year);
        dateTime.setMonth(date.month - 1);
        dateTime.setDate(date.day);
        dateTime.setHours(new Date(time).getHours());
        dateTime.setMinutes(new Date(time).getMinutes());
        dateTime.setSeconds(0);
        return moment(dateTime).format('YYYY-MM-DDTHH:mm:ss');
    }
    setOrderRuleCriterias(orderRuleCriteriaDetail: OrderRuleCriteriaDetail[]) {
        const orderRuleCDFG: any = [];
        const bu = '';
        const so = '';
        const buId = null;
        const soId = null;
        const ordChhArr = [];
        const buValues = [];
        const busoValues = [];
        for (let cnt = 0; cnt < orderRuleCriteriaDetail.length; cnt++) {
            const criDet = orderRuleCriteriaDetail[cnt];
            const code = criDet['orderRuleCriteriaCode'];
            if (code !== undefined && this.filterAttributes(code)) {
                const selOpt = criDet['orderRuleLogicalOperatorDTO']['orderRuleLogicalOperatorCode'];
                if ((selOpt === 'EqlGrtThn' || selOpt === 'EqlLesThn' || selOpt === 'GrtThn' || selOpt === 'LessThan' || selOpt === 'Between') &&
                    (orderRuleCriteriaDetail[cnt]['isDisabled'] !== true)) {
                    const findNextSelDetail = this.findNextAvailDetail(orderRuleCriteriaDetail, cnt, code, selOpt);
                    if (findNextSelDetail !== null) {
                        orderRuleCriteriaDetail[cnt]['orderRuleCriteriaValueEnd'] =
                            orderRuleCriteriaDetail[findNextSelDetail]['orderRuleCriteriaValue'];
                        orderRuleCriteriaDetail[cnt]['orderRuleCriteriaDetailEndLimitID'] =
                            orderRuleCriteriaDetail[findNextSelDetail]['orderRuleCriteriaDetailID'];
                        orderRuleCriteriaDetail[findNextSelDetail]['isDisabled'] = true;
                        orderRuleCriteriaDetail[cnt]['orderRuleLogicalOperatorDTO']['orderRuleLogicalOperatorCode'] = 'GrtLessThn';
                    }

                    const currIns = this.initCriteriaDetails(orderRuleCriteriaDetail[cnt]);
                    orderRuleCDFG.push(currIns);
                } else if (orderRuleCriteriaDetail[cnt]['isDisabled'] !== true) {
                    const currIns = this.initCriteriaDetails(orderRuleCriteriaDetail[cnt]);
                    orderRuleCDFG.push(currIns);
                }
            } else if (typeof (criDet) === 'object') {
                switch (code) {
                    case 'OrdChannel':
                        ordChhArr.push({
                            'id': criDet.orderRuleCriteriaDetailID,
                            'text': criDet.orderRuleCriteriaValue
                        });
                        break;
                    case 'BusUnit':
                        buValues.push({
                            'id': criDet.orderRuleCriteriaDetailID,
                            'text': criDet.orderRuleCriteriaValue
                        });
                        break;
                    case 'BUServOffr':
                        busoValues.push({
                            'id': criDet.orderRuleCriteriaDetailID,
                            'text': criDet.orderRuleCriteriaValue
                        });
                        break;
                    default:
                        break;
                }
            }
        }
        this.ruleForm['controls']['orderCreationChannel']['setValue'](ordChhArr);
        this.ruleForm['controls']['businessUnit']['setValue'](buValues);
        this.ruleForm['controls']['serviceOffering']['setValue'](busoValues);
        const ruleFormArray = this.fb.array(orderRuleCDFG);
        this.ruleForm.setControl('orderRuleCriteriaDetail', ruleFormArray);
    }
    setOrderRuleParameters(orderRuleParameter: OrderRuleParameter[]) {
        const orderRulePDFG: any = [];
        for (let cnt = 0; cnt < orderRuleParameter.length; cnt++) {
            const currIns = this.initOrderRuleParameterDetails(orderRuleParameter[cnt]);
            orderRulePDFG.push(currIns);
        }
        const ruleFormArray = this.fb.array(orderRulePDFG);
        this.ruleForm.setControl('orderRuleParameterDetail', ruleFormArray);
    }
    setOrderRuleParametersOnRuleCreation(resultantActions) {
        const orderRulePDFG: any = [];
        for (let cnt = 0; cnt < resultantActions.length; cnt++) {
            const pName: string = resultantActions[cnt].parameterName;
            const pTypeCode: string = resultantActions[cnt].parameterType;
            const pValTypeCode: string = resultantActions[cnt].parameterValueType;
            const currIns = this.initOrderRuleParameterDetailsOnRuleCreation(pName, pTypeCode, pValTypeCode);
            orderRulePDFG.push(currIns);
        }
        const ruleFormArray = this.fb.array(orderRulePDFG);
        this.ruleForm.setControl('orderRuleParameterDetail', ruleFormArray);
    }

    get orderRuleCriteriaDetail(): FormArray {
        return this.ruleForm.get('orderRuleCriteriaDetail') as FormArray;
    }

    get orderRuleParameterDetail(): FormArray {
        return this.ruleForm.get('orderRuleParameterDetail') as FormArray;
    }
    findNextAvailDetail(orderRuleCriteriaDetail, cnt1, code, selOpt) {
        for (let cnt = cnt1 + 1; cnt < orderRuleCriteriaDetail.length; cnt++) {
            const currObj = orderRuleCriteriaDetail[cnt];
            if (currObj['orderRuleLogicalOperatorDTO']['orderRuleLogicalOperatorCode'] === 'LessThan' &&
                currObj['orderRuleCriteriaCode'] === code) {
                return cnt;
            }
        }
        return null;
    }
    addNewAttribute() {
        const control = <FormArray>this.ruleForm.controls['orderRuleCriteriaDetail'];
        const addrCtrl = this.initCriteriaDetails(null);
        control.push(addrCtrl);
    }
    removeAttribute(event) {
        // Remove Attribute
        if (event.values.detailId === null || event.values.detailId === undefined || event.values.detailId === '') {
            this.ruleForm.controls.orderRuleCriteriaDetail.removeAt(event.values.id);
        } else {
            const detUrl = this.jbhGlobals.endpoints.automationrules.deleteAttr;
            this.jbhGlobals.apiService.removeData(detUrl + '/' + event.values.criSetId + '/' + event.values.detailId).subscribe(data => {
                this.ruleForm.controls.orderRuleCriteriaDetail.removeAt(event.values.id);
            });
        }
    }
    onCancel(msg) {
        if (this.ruleForm.touched) {
            msg.show();
        } else {
            this.loadCriteriaList();
        }
    }
    proceed() {
        this.loadCriteriaList();
    }
    formCancel(alertMsg) {
        alertMsg.hide();
    }
    loadCriteriaList() {
        this.router.navigateByUrl('/automationrules');
    }
    loadOrderRuleCriterias() {
        // Get all Order Rule Criterias
        const filterList = [];
        const thisVal = this;
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.automationrules.getOrderRuleCriterias).subscribe(data => {
            this.orderRuleCriteriaList = data;
            this.loadOrderCreationChannel();
            this.loadOrderRuleParameterTypes();
            this.loadAllAttributes();
        });
        /* this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.automationrules.getOrderRuleCriterias)
            .flatMap(function(data) {
                return data;
            })
            .filter(function(attribute) {
                return thisVal.filterAttributes(attribute['orderRuleCriteriaCode']);
            })
            .map(function(attribute) {
                return attribute;
            })
            .subscribe(function(data) {
                filterList.push(data);
            });
        this.orderRuleCriteriaList = filterList; */
    }
    filterAttributes(code) {
        const isBuss = this.isBusinessUnitLevelRules;
        const isCus = this.isCustomerLevelRules;
        const bussFilter = (isBuss && code !== 'OrdChannel' && code !== 'BusUnit' && code !== 'BUServOffr' && code !== 'Supersede');
        const cusFilter = (isCus && code !== 'OrdChannel' && code !== 'Supersede');
        return (bussFilter || cusFilter);
    }
    loadOrderCreationChannel() {
        // Get all Order Creation Channel
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.automationrules.getOrderCreationChannel).subscribe(data => {
            this.channelList = data['_embedded']['ordercreationchannel'];
        });
    }
    loadOperators() {
        // Get all Order Rule Criterias
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.automationrules.getOrderRuleOperators).subscribe(data => {
            this.orderRuleOperatorsList = data['_embedded']['orderRuleLogicalOperators'];
        });
    }

    loadOrderRuleParameterTypes() {
        // Get all Order Rule Criterias
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.automationrules.getOrderRuleParameterTypes).subscribe(data => {
            this.orderRuleParameterTypeList = data['_embedded']['orderRuleParameterTypes'];
        });
    }
    onRemoved() {

    }
    onOrdChnRemoved(event) {
        // Remove Order Channel
        if (event['id'] !== null) {
            const detUrl = this.jbhGlobals.endpoints.automationrules.deleteAttr;
            this.jbhGlobals.apiService.removeData(detUrl + '/' +
                this.orderRuleCriteriaSetID + '/' + event['id']).subscribe(data => { });
        }
    }
    onSelected(eve) {
        if (typeof (eve['id']) === 'string') {
            eve['id'] = null;
        }
    }
    setDates(eve, type) {
        switch (type) {
            case 'effDt':
                this.selEffDate = this.getDateFormat(eve.jsdate);
                this.effectiveDateFlag = false;
                break;
            case 'expDt':
                this.selExpDate = this.getDateFormat(eve.jsdate);
                this.expirationDateFlag = false;
                break;
            default:
                break;
        }
    }
    validateDates() {
        if (!this.isDateEmpty(this.selEffDate) && !this.isDateEmpty(this.selExpDate) && this.expirationTime !== undefined &&
            this.effectiveTime !== undefined) {
            const effDtTime = this.setDateTimeFormatFromDt(this.selEffDate, this.myStartTime);
            const expDtTime = this.setDateTimeFormatFromDt(this.selExpDate, this.myEndTime);
            if (effDtTime > expDtTime) {
                this.dateCompareFlag = true;
            } else {
                this.dateCompareFlag = false;
            }
        }
        return !this.dateCompareFlag;
    }
    isDateEmpty(dtObj) {
        return (dtObj.year === 0 && dtObj.month === 0 && dtObj.day === 0);
    }
    onpickUpDateChanged(event: IMyDateModel) {
        let jsDt;
        this.effectiveDateFlag = false;
        this.effectiveDate = event.epoc;
        jsDt = this.datePipeObj.transform(event.jsdate, 'yyyy-MM-ddTHH:mm:ss');
        event.jsdate = jsDt;
        this.ruleForm.controls.effectiveDate.setValue(event);
        this.validateDates();
    }
    ondeliveryDateChanged(event: IMyDateModel) {
        let jsDt;
        this.expirationDateFlag = false;
        this.expirationDate = event.epoc;
        jsDt = this.datePipeObj.transform(event.jsdate, 'yyyy-MM-ddTHH:mm:ss');
        event.jsdate = jsDt;
        this.ruleForm.controls.expirationDate.setValue(event);
        this.validateDates();
    }
    onParamTypeChange(eve) {
        const paramDet = this.ruleForm.controls.orderRuleParameterDetail.controls[0].controls;
        this.selectedParamType = eve;
        paramDet.orderParameterCharValue.setValue(null);
        paramDet.orderParameterDateValue.setValue(null);
        paramDet.orderParameterNumberValue.setValue(null);
    }
    focusReady(event) {
        if (event.key === 'Enter' && this.focusFlag === 0 && (event.target.childNodes[4].focus())) {
            event.target.childNodes[4].focus();
            this.focusFlag++;
        }

    }
    setFocusFlag() {
        this.focusFlag = 0;
    }
    selectvalidation(event, selectComponent) {
        const compName = selectComponent.element.nativeElement.id;
        if (event.innerText === '' && selectComponent.multiple !== true) {
            this.ruleForm.get(compName).markAsTouched();
            this.ruleForm.get(compName).setErrors(
                compName === 'orderCreationChannel' || compName === 'serviceOffering' || compName === 'businessUnit' ? {
                    'mandatory': true
                } : null);
            if (selectComponent.multiple !== true && selectComponent.active.length > 0) {
                selectComponent.active = [];

            }
        } else if (selectComponent.multiple === true && selectComponent._active.length === 0) {
            this.ruleForm.get(compName).markAsTouched();
            this.ruleForm.get(compName).setErrors(
                compName === 'orderCreationChannel' || compName === 'serviceOffering' || compName === 'businessUnit' ? {
                    'mandatory': true
                } : null);
        }
    }
    onSave(mode) {
        if (this.ruleForm.get('orderCreationChannel').value === null || this.ruleForm.get('orderCreationChannel').value.length === 0) {
            this.ruleForm.get('orderCreationChannel').markAsTouched();
            this.ruleForm.get('orderCreationChannel').setErrors({
                'mandatorySelect': true
            });
        }
        if (this.so.nativeElement.checked === true) {
            if (this.ruleForm.get('serviceOffering').value === null || this.ruleForm.get('serviceOffering').value.length === 0) {
                this.ruleForm.get('serviceOffering').markAsTouched();
                this.ruleForm.get('serviceOffering').setErrors({
                    'mandatorySelect': true
                });
            }
            this.ruleForm.get('businessUnit').setValidators([]);
            this.ruleForm.get('businessUnit').updateValueAndValidity();
        }
        if (this.bu.nativeElement.checked === true) {
            if (this.ruleForm.get('businessUnit').value === null || this.ruleForm.get('businessUnit').value.length === 0) {
                this.ruleForm.get('businessUnit').markAsTouched();
                this.ruleForm.get('businessUnit').setErrors({
                    'mandatorySelect': true
                });
            }
            this.ruleForm.get('serviceOffering').setValidators([]);
            this.ruleForm.get('serviceOffering').updateValueAndValidity();
        }
        if (this.associationLevel === 'Customer' && this.orderRuleCategoryDescription === 'Auto Updates Category') {
            if (this.checkAttrArray('BillParty') && this.ruleForm.controls.businessUnit.value.length !== 0) {
                this.saveFlag = true;
            } else if (!this.checkAttrArray('BillParty') && this.ruleForm.controls.businessUnit.value.length === 0) {
                this.jbhGlobals.notifications.alert('Failure', 'Please add Business unit');
                this.saveFlag = false;
            } else {
                this.jbhGlobals.notifications.alert('Failure', 'Please add Billing Party Attribute');
                this.saveFlag = false;
            }
        } else if (this.associationLevel === 'Customer') {
            if (this.checkAttrArray('Customer') || this.checkAttrArray('BillParty') || this.checkAttrArray('LOB')) {
                this.saveFlag = true;
            } else {
                this.jbhGlobals.notifications.alert('Failure', 'Please add Customer/Billing party/Line Of Business Attribute');
                this.saveFlag = false;
            }
        } else {
            this.saveFlag = true;
        }

        if (this.ruleForm.valid && this.validateDates() && this.saveFlag === true) {
            const saveUrl = this.jbhGlobals.endpoints.automationrules.saverule;
            const val = this.ruleForm.value;
            const orderCrChn = val.orderCreationChannel;
            const so = val.serviceOffering;
            const bu = val.businessUnit;
            const cDet = val.orderRuleCriteriaDetail;
            const effTimeStamp = this.setDateTimeFormat(val.effectiveDate.jsdate, val.effectiveTime);
            const expTimeStamp = this.setDateTimeFormat(val.expirationDate.jsdate, val.expirationTime);
            const obj = {
                'orderRuleCriteriaSetID': (mode === 'copy') ? null : val.orderRuleCriteriaSetID,
                'orderRuleDetailID': val.orderRuleDetailID,
                'orderRuleSupersedeTypeCode': (val.orderRuleSupersedeTypeCode === true) ? 'Suprsed' : 'NotSuprsed',
                'effectiveTimestamp': effTimeStamp,
                'expirationTimestamp': expTimeStamp,
                'orderRuleCriteriaDetailDTO': [],
                'orderRuleParameterDTO': val.orderRuleParameterDetail
            };
            if (orderCrChn !== null && orderCrChn !== '' && orderCrChn.length > 0) {
                for (let cnt = 0; cnt < orderCrChn.length; cnt++) {
                    obj.orderRuleCriteriaDetailDTO.push({
                        'orderRuleCriteriaValue': orderCrChn[cnt].text,
                        'orderRuleCriteriaDetailID': (mode === 'copy') ? null : orderCrChn[cnt].id,
                        'orderRuleCriteriaDescription': '',
                        'orderRuleCriteriaCode': 'OrdChannel'
                    });
                }
            }
            if (this.so.nativeElement.checked === true) {
                if (so !== null && so !== '' && so.length > 0) {
                    for (let cnt1 = 0; cnt1 < so.length; cnt1++) {
                        obj.orderRuleCriteriaDetailDTO.push({
                            'orderRuleCriteriaValue': so[cnt1]['text'],
                            'orderRuleCriteriaDetailID': (mode === 'copy') ? null : ((so[cnt1]['id'] !== null) ? so[cnt1]['id'] : null),
                            'orderRuleCriteriaDescription': '',
                            'orderRuleCriteriaCode': 'BUServOffr'
                        });
                    }
                }
            }
            if (this.bu.nativeElement.checked === true) {
                if (bu !== null && bu !== '' && bu.length > 0) {
                    for (let cnt1 = 0; cnt1 < bu.length; cnt1++) {
                        obj.orderRuleCriteriaDetailDTO.push({
                            'orderRuleCriteriaValue': bu[cnt1]['text'],
                            'orderRuleCriteriaDetailID': (mode === 'copy') ? null : ((bu[cnt1]['id'] !== null) ? bu[cnt1]['id'] : null),
                            'orderRuleCriteriaDescription': '',
                            'orderRuleCriteriaCode': 'BusUnit'
                        });
                    }
                }
            }
            for (let attrCnt = 0; attrCnt < cDet.length; attrCnt++) {
                cDet[attrCnt].orderRuleCriteriaDetailID = (mode === 'copy') ? null : cDet[attrCnt].orderRuleCriteriaDetailID;
                const selOpt = cDet[attrCnt].orderRuleLogicalOperatorDTO.orderRuleLogicalOperatorCode;
                if ((selOpt === 'EqlGrtThn' || selOpt === 'EqlLesThn' || selOpt === 'GrtLessThn' || selOpt === 'Between') &&
                    (cDet[attrCnt].orderRuleCriteriaValue !== null && cDet[attrCnt].orderRuleCriteriaValueEnd !== null)) {
                    cDet[attrCnt].orderRuleLogicalOperatorDTO['effectiveTimestamp'] = effTimeStamp;
                    cDet[attrCnt].orderRuleLogicalOperatorDTO['expirationTimestamp'] = expTimeStamp;

                    cDet[attrCnt].orderRuleLogicalOperatorDTO['orderRuleLogicalOperatorCode'] = 'GrtThn';
                    obj.orderRuleCriteriaDetailDTO.push(cDet[attrCnt]);
                    const endVal = Object.assign({}, cDet[attrCnt], {
                        orderRuleCriteriaDetailID: cDet[attrCnt].orderRuleCriteriaDetailEndLimitID,
                        orderRuleCriteriaValue: cDet[attrCnt].orderRuleCriteriaValueEnd,
                        orderRuleLogicalOperatorDTO: {
                            orderRuleLogicalOperatorCode : 'LessThan',
                            effectiveTimestamp: effTimeStamp,
                            expirationTimestamp: expTimeStamp
                        }
                    });
                    obj.orderRuleCriteriaDetailDTO.push(endVal);
                } else {
                    cDet[attrCnt].orderRuleLogicalOperatorDTO['effectiveTimestamp'] = effTimeStamp;
                    cDet[attrCnt].orderRuleLogicalOperatorDTO['expirationTimestamp'] = expTimeStamp;
                    obj.orderRuleCriteriaDetailDTO.push(cDet[attrCnt]);
                }
            }
            for (let cnt = 0; cnt < obj.orderRuleCriteriaDetailDTO.length; cnt++) {
                obj.orderRuleCriteriaDetailDTO[cnt].effectiveTimestamp = effTimeStamp;
                obj.orderRuleCriteriaDetailDTO[cnt].expirationTimestamp = expTimeStamp;
            }
            for (let cnt1 = 0;
                (obj.orderRuleParameterDTO !== null && cnt1 < obj.orderRuleParameterDTO.length); cnt1++) {
                const pId = obj.orderRuleParameterDTO[cnt1].orderRuleParameterID;
                obj.orderRuleParameterDTO[cnt1].orderRuleParameterID = (mode === 'copy') ? null : pId;
                obj.orderRuleParameterDTO[cnt1].effectiveTimestamp = effTimeStamp;
                obj.orderRuleParameterDTO[cnt1].expirationTimestamp = expTimeStamp;
            }
            this.jbhGlobals.apiService.patchData(saveUrl, obj).subscribe(data => {
                const isSuccess = data['status'] === 'success';
                if (isSuccess) {
                    this.jbhGlobals.notifications.success('Success', 'Rule Configured Successfully');
                    this.loadCriteriaList();
                } else {
                    this.jbhGlobals.notifications.alert('Failure', 'Rule Configuration Failed');
                }
            });
        } else if (!this.ruleForm.valid || !this.validateDates()) {
            const me = this;
            if (this.ruleForm.controls.serviceOffering.value === null || this.ruleForm.controls.serviceOffering.value.length === 0) {
                this.jbhGlobals.utils.forIn(this.ruleForm.controls.serviceOffering,
                    function (value, name, object) {
                        me.ruleForm.controls.serviceOffering.markAsTouched();

                    });
                this.ruleForm.get('serviceOffering').setErrors({
                    'mandatorySelect': true
                });
            }
            if (this.ruleForm.controls.businessUnit.value === null || this.ruleForm.controls.businessUnit.value.length === 0) {
                this.jbhGlobals.utils.forIn(this.ruleForm.controls.businessUnit,
                    function (value, name, object) {
                        me.ruleForm.controls.businessUnit.markAsTouched();

                    });
                this.ruleForm.get('businessUnit').setErrors({
                    'mandatorySelect': true
                });
            }
            /* if (this.ruleForm.controls.effectiveTime.value == null) {
                this.jbhGlobals.utils.forIn(this.ruleForm.controls.effectiveTime,
                    function(value, name, object) {
                        me.ruleForm.controls.effectiveTime.markAsTouched();
                    });
                this.ruleForm.get('effectiveTime').setErrors({
                    'mandatorySelect': true
                });
            } */
            if (this.effectiveDatePicker.selectionDayTxt === '') {
                this.effectiveDateFlag = true;
            } else {
                this.effectiveDateFlag = false;
            }
            /* if (this.ruleForm.controls.expirationTime.value == null) {
                this.jbhGlobals.utils.forIn(this.ruleForm.controls.expirationTime,
                    function(value, name, object) {
                        me.ruleForm.controls.expirationTime.markAsTouched();
                    });
                this.ruleForm.get('expirationTime').setErrors({
                    'mandatorySelect': true
                });
            } */
            if (this.expirationDatePicker.selectionDayTxt === '') {
                this.expirationDateFlag = true;
            } else {
                this.expirationDateFlag = false;
            }
            if (this.ruleForm.get('orderCreationChannel').value === null ||
                this.ruleForm.controls.orderCreationChannel.value.length === 0) {
                this.jbhGlobals.utils.forIn(this.ruleForm.controls.orderCreationChannel,
                    function (value, name, object) {
                        me.ruleForm.controls.orderCreationChannel.markAsTouched();
                    });
                this.ruleForm.get('orderCreationChannel').setErrors({
                    'mandatorySelect': true
                });
            }
            const attrlen = me.ruleForm.controls.orderRuleCriteriaDetail.controls.length;
            for (let i = 0; i < attrlen; i++) {
                this.AttributeViewComponent.attrValidation(this.ruleForm.controls['orderRuleCriteriaDetail'].controls[i], i);
            }
            this.jbhGlobals.notifications.alert('Failure', 'Please enter required details');
        }
    }
    checkAttrArray(attr) {
        let flag = false;
        const attrArray = [];
        const attrForm = this.ruleForm.controls.orderRuleCriteriaDetail;
        const controlsLength = attrForm.controls.length;
        for (let i = 0; i < attrForm.controls.length; i++) {
            const getAttr = attrForm.controls[i].controls.orderRuleCriteriaCode.value;
            attrArray.push(getAttr);
        }
        for (let i = 0;
            (attrArray !== undefined && i < attrArray.length); i++) {
            if (attrArray[i] === attr) {
                flag = true;
                break;
            }
        }
        return flag;
    }
    onStartTimeChanged(): any {
        this.startTimeMeridian = true;
        this.timeValidator(this.myStartTime, 'Start');
    }
    onEndTimeChanged() {
        this.endTimeMeridian = true;
        this.timeValidator(this.myEndTime, 'End');
    }
    setInitialTime() {
        const initialTime = new Date();
        initialTime.setHours(0);
        initialTime.setMinutes(0);
        return initialTime;
    }
    timeValidator(time, key) {
        const hour = Number(moment(time).format('HH'));
        const minute = Number(moment(time).format('mm'));
        if ((hour === 0 && minute === 0)) {
            switch (key) {
                case 'Start':
                    this.myStartTime = this.setInitialTime();
                    break;
                case 'End':
                    this.myEndTime = this.setInitialTime();
                    break;
                default:
            }
        }
        if (hour !== 0 && minute === 0) {
            this.conditonalValidator(time, key);

        }
        if (hour === 0 && minute !== 0) {
            this.conditonalValidator(time, key);

        }
        if (hour !== 0 && minute !== 0) {
            this.conditonalValidator(time, key);
        }
    }
    conditonalValidator(myTime, key) {
        switch (key) {
            case 'Start':
                this.myStartTime = this.hoursMinsSetter(myTime, key);
                break;
            case 'End':
                this.myEndTime = this.hoursMinsSetter(myTime, key);
                break;
            default:
        }
    }
    hoursMinsSetter(time, key) {
        let hour = Number(moment(time).format('HH'));
        let minute = Number(moment(time).format('mm'));
        hour = hour !== 0 ? hour : 0;
        minute = minute !== 0 ? minute : 0;
        const setTime = new Date();
        setTime.setHours(hour);
        setTime.setMinutes(minute);
        return setTime;
    }
    private setRuleOverviewDetails() {
        const ruleDet = this.ruleService.ruleDetails;
        this.orderRuleDetailID = ruleDet.orderRuleDetailID;
        this.orderRuleCriteriaSetID = ruleDet.orderRuleCriteriaSetID;
        this.orderRuleName = ruleDet.orderRuleName;
        this.orderRuleDescription = ruleDet.orderRuleDescription;
        this.associationLevel = ruleDet.associationLevel;
        this.businessUnit = ruleDet.businessUnit;
        this.businessUnitServiceOffering = ruleDet.businessUnitServiceOffering;
        this.isBusinessUnitLevelRules = ruleDet.isBusinessUnitLevelRules;
        this.isCustomerLevelRules = ruleDet.isCustomerLevelRules;
        this.billTo = ruleDet.billTo;
        this.mode = ruleDet.mode;
        this.resultantActions = ruleDet.resultantActions;
        this.orderRuleCategoryDescription = ruleDet.orderRuleCategoryDescription;

        this.title = (this.mode === 'edit') ? 'View and Edit Rule' : (this.mode === 'copy' ? 'Copy Rule' : 'Configure New Rule');
        this.validBUSOValues = ruleDet.validationSet;
        this.binValidBUSO();
        this.busoRadioCheck();
    }
    private setUpKeyboardShortcuts() {
        this.jbhGlobals.shortkeys.getData().subscribe(data => {
            if (data.keyCode === 'alt+1') { } else if (data.keyCode === 'alt+3') {
                this.ruleOverviewKey.nativeElement.focus();
            }
        });
    }
}
