import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OrderRuleParamViewComponent } from './order-rule-param-view.component';

describe('OrderRuleParamViewComponent', () => {
  let component: OrderRuleParamViewComponent;
  let fixture: ComponentFixture<OrderRuleParamViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrderRuleParamViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrderRuleParamViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
