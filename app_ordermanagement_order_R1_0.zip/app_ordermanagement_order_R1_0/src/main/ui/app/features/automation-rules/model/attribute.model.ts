export class AttributeModel {
  attribute = '';
  operator = '';
  value = '';
}
