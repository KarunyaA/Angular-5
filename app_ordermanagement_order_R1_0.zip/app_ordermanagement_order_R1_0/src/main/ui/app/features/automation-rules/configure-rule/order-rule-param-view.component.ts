import { AfterContentInit, Component, Input, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';

@Component({
    selector: 'app-order-rule-param-view',
    templateUrl: './order-rule-param-view.component.html',
    styleUrls: ['./order-rule-param-view.component.scss']
})
export class OrderRuleParamViewComponent implements OnInit, AfterContentInit {
    @Input() paramcontrol: FormGroup;
    isNumber: boolean;
    isChar: boolean;
    isDate: boolean;
    constructor() { }
    ngAfterContentInit() {
        this.loadParameterTypes();
    }
    ngOnInit(): void { }
    loadParameterTypes() {
        /* Bind Parameters */
        const prmType = this.paramcontrol['controls']['orderRuleParameterTypeDTO'];
        if (prmType.value === null) {
            return;
        }
        const prmTypeVal = prmType['controls']['orderRuleParameterValueTypeCode'].value;
        switch (prmTypeVal) {
            case 'Number':
                this.isNumber = true;
                break;
            case 'Char':
                this.isChar = true;
                break;
            case 'String':
                this.isChar = true;
                break;
            case 'Boolean':
                this.isChar = true;
                break;
            case 'Date':
                this.isDate = true;
                break;
            default:
                this.isNumber = true;
                break;
        }
    }
}
