import { OrderRuleCriteriaDetail } from './orderrulecriteriadetail.model';
import { OrderRuleParameter } from './orderruleparameter.model';

export class OrderRuleCriteriaSet {
    orderRuleCriteriaSetID: number;
    orderRuleDetailID: number;
    serviceOffering: string;
    orderCreationChannel: string;
    globalOverride: boolean;
    effectiveTimestamp: Date;
    expirationTimestamp: Date;
    orderRuleCriteriaDetail: OrderRuleCriteriaDetail[];
    orderRuleParameter: OrderRuleParameter[];
}
export const values = ['V 1', 'V 2', 'V 3', 'V 4'];
