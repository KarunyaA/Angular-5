import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfiguredRulesListComponent } from './configured-rules-list.component';

describe('ConfiguredRulesListComponent', () => {
  let component: ConfiguredRulesListComponent;
  let fixture: ComponentFixture<ConfiguredRulesListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ConfiguredRulesListComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfiguredRulesListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
