import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PopoverModule } from 'ngx-bootstrap/popover';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BsDropdownModule } from 'ngx-bootstrap';
import { AutomationRulesRoutingModule } from './automation-rules-routing.module';
import { RulesListComponent } from './rules-list/rules-list.component';
import { DateTimePickerModule } from 'ng-pick-datetime';
import { ModalModule } from 'ngx-bootstrap';
import { TimepickerModule } from 'ngx-bootstrap';

import { JBHDataTableModule } from '../../../app/shared/jbh-data-table/jbh-data-table.module';
import { ConfigureRuleComponent } from './configure-rule/configure-rule.component';
import { RulesService } from './rules.service';
import { JbhSearchFilterModule } from '../../../app/shared/jbh-search-filter/jbh-search-filter.module';
import { ConfiguredRulesListComponent } from './rules-list/configured-rules-list.component';
import { SharedModule } from './../../shared/shared.module';
import { TypeaheadModule } from 'app/shared/jbh-typeahead/typeahead.module';
import { SelectModule } from '../../../app/shared/select';
import { MyDatePickerModule } from 'mydatepicker';
import { OrderRuleParamViewComponent } from './configure-rule/order-rule-param-view.component';
import { ViewRuleComponent } from './configure-rule/view-rule/view-rule.component';
import { AttributeViewComponent } from './configure-rule/attribute-view.component';
import { OperatorViewComponent } from './configure-rule/operator-view.component';

@NgModule({
    imports: [
        CommonModule,
        AutomationRulesRoutingModule,
        JBHDataTableModule,
        PopoverModule.forRoot(),
        TypeaheadModule.forRoot(),
        SelectModule,
        BsDropdownModule.forRoot(),
        FormsModule,
        ReactiveFormsModule,
        JbhSearchFilterModule,
        SharedModule,
        MyDatePickerModule,
        DateTimePickerModule,
        ModalModule.forRoot(),
        TimepickerModule.forRoot()
    ],
    declarations: [
        RulesListComponent,
        ConfigureRuleComponent,
        ConfiguredRulesListComponent,
        OrderRuleParamViewComponent,
        ViewRuleComponent,
        AttributeViewComponent,
        OperatorViewComponent
    ],
    providers: [RulesService]
})
export class AutomationRulesModule { }
