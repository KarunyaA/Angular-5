import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { JBHGlobals } from '../../../app.service';
import { RulesService } from '../rules.service';
import { FormBuilder, Validators } from '@angular/forms';
import { Headers, RequestOptions } from '@angular/http';

@Component({
    selector: 'app-configured-rules-list',
    templateUrl: './configured-rules-list.component.html',
    styleUrls: ['./configured-rules-list.component.scss']
})
export class ConfiguredRulesListComponent implements OnInit {
    rows: any[];
    selected = [];
    totalRecordsCount = 0;
    offset = 0;
    limit = 20;
    serviceOfferings: any = [];
    associationLevels: any = [];
    orderRuleCategories: any = [];
    activeFlags: any = [];
    globalOverrideFlags = [];
    businessUnit = [];
    orderRuleName = '';
    ruleMockData: any[] = [];
    debounceValue: any;
    typeaheadModule: any;
    ruleListUrl: string;
    ruleTypeAheadUrl: string;
    rulesGridMenu = [{
        'name': 'Export To Excel',
        'id': 'exporttoexcel'
    },
    {
        'name': 'Configure New Rule',
        'id': 'configurenewrule'
    }
    ];
    rulesFilterTitle = 'Filter By';
    flag = 0;
    isBusinessUnitLevelRules = true;
    isCustomerLevelRules = false;
    billTo: any = {
        'line1': 'Campbel l S oup (CAMP9)',
        'line2': '139 02 S treet Name',
        'line3': 'Goodheaven, IA, 84 203 USA'
    };
    onLoading: boolean;
    onNoResults: boolean;
    rulesFilterList: any[] = [{
        'index': 0,
        'key': 'serviceOfferingCode',
        'title': 'Service Offering',
        'checkSelectionKey': 'text',
        'componentType': 'lsitType',
        'rootVal': ['_embedded', 'buso'],
        'url': 'getBuSO',
        'params': {}
    }, {
        'index': 1,
        'key': 'Customer',
        'title': 'Association Level',
        'checkSelectionKey': 'orderRuleTypeDescription',
        'componentType': 'lsitType',
        'rootVal': ['_embedded', 'orderRuleTypes'],
        'url': 'getRulesTypes',
        'params': {}
    }, {
        'index': 2,
        'key': 'ruleCategory',
        'title': 'Rule Category',
        'checkSelectionKey': 'orderRuleCategoryDescription',
        'rootVal': ['_embedded', 'orderRuleCategories'],
        'componentType': 'lsitType',
        'url': 'getRulesCategory',
        'params': {}
    }, {
        'index': 3,
        'key': 'status',
        'title': 'Global override flag status',
        'checkSelectionKey': 'status',
        'rootVal': ['_embedded', 'globalOverrideStatus'],
        'componentType': 'lsitType',
        'url': 'getGlobalOverrideStatus'
    }, {
        'index': 4,
        'key': '_embedded',
        'title': 'Status',
        'checkSelectionKey': 'status',
        'rootVal': ['_embedded', 'ruleStatus'],
        'componentType': 'lsitType',
        'url': 'getStatusUrl',
        'params': {}
    }];
    @ViewChild('formSectionKey') formSectionKey: ElementRef;
    @ViewChild('gridSectionKey') gridSectionKey: ElementRef;
    @ViewChild('exportExcel') exportExcel: ElementRef;
    @ViewChild('callValue') callValue: ElementRef;
    ngOnInit(): void {
        this.setUpKeyboardShortcuts();
        this.page(this.offset, this.limit);
        this.typeaheadModule = this.fb.group({
            searchRuleName: ['', Validators.required]
        });
        this.debounceValue = this.jbhGlobals.settings.debounce;
        this.typeaheadModule['controls']['searchRuleName']['valueChanges']
            .debounceTime(this.debounceValue)
            .distinctUntilChanged()
            .subscribe((value) => {
                if (!this.jbhGlobals.utils.isEmpty(value) && value !== undefined) {
                    this.orderRuleName = '';
                    this.getRuleName(value);
                } else if (value.length === 0) {
                    this.ruleMockData = [];
                    this.orderRuleName = '';
                    this.onNoResults = false;
                    this.loadGridData();
                }
            }, (err: Error) => { });
    }
    constructor(private router: Router,
                private jbhGlobals: JBHGlobals,
                private rulesService: RulesService, private fb: FormBuilder) { }
    getSelectedIx() {
        // return this.selected[0]['$$index'];
        return null;
    }
    menuClickEvent(selectedVal) {
        if (selectedVal === 'configurenewrule') {
            this.rulesService.ruleDetails = {
                'orderRuleCriteriaSetID': null,
                'orderRuleDetailID': null,
                'orderRuleSupersedeTypeCode': null,
                'orderRuleName': '',
                'startDate': null,
                'orderRuleDescription': '',
                'associationLevel': '',
                'businessUnit': '',
                'businessUnitServiceOffering': '',
                'isBusinessUnitLevelRules': this.isBusinessUnitLevelRules,
                'isCustomerLevelRules': this.isCustomerLevelRules,
                'billTo': {
                    'line1': '',
                    'line2': '',
                    'line3': ''
                },
                'effectiveTimestamp': '',
                'expirationTimestamp': '',
                'mode': 'new',
                'resultantActions': [],
                'validationSet': [],
                'orderRuleCategoryDescription': ''

            };
            this.rulesService.selectedCriteriaDetails = null;
            this.router.navigateByUrl('/automationrules/rules');
        } else if (selectedVal === 'exporttoexcel') {
            const filename = 'ExportedExcel.csv';
            this.exportExcel.nativeElement.href = this.jbhGlobals.endpoints.automationrules.exportRule;
            this.exportExcel.nativeElement.download = filename;
        }

    }
    onRulesListMenuClick(event, pop, row, mode?: any) {
        const currEle = event.srcElement.id;
        pop.hide();
        this.rulesService.ruleDetails = {
            'orderRuleCriteriaSetID': row.orderRuleCriteriaSets[0].orderRuleCriteriaSetID,
            'orderRuleDetailID': row.orderRuleDetailId,
            'orderRuleSupersedeTypeCode': row.orderRuleCriteriaSets[0].orderRuleSupersedeTypeCode,
            'orderRuleName': row.ruleName,
            'startDate': row.startDate,
            'orderRuleDescription': row.ruleDescription,
            'associationLevel': row.associationLevel,
            'businessUnit': row.orderRuleCriteriaSets[0].businessUnit,
            'businessUnitServiceOffering': row.orderRuleCriteriaSets[0].businessUnitServiceOffering,
            'isBusinessUnitLevelRules': this.isBusinessUnitLevelRules,
            'isCustomerLevelRules': this.isCustomerLevelRules,
            'billTo': this.billTo,
            'effectiveTimestamp': row.orderRuleCriteriaSets[0].startDate,
            'expirationTimestamp': row.orderRuleCriteriaSets[0].endDate,
            'mode': mode,
            'resultantActions': [],
            'validationSet': row.validationSet,
            'orderRuleCategoryDescription': ''
        };
        switch (currEle) {
            case 'copyrule':
                {
                    this.onViewEditRule('edit');
                    break;
                }
            case 'inactivaterule':
                {
                    const inactURL = this.jbhGlobals.endpoints.automationrules.inactivateRule;
                    const orderRulecriteriaID = row.orderRuleCriteriaSets[0].orderRuleCriteriaSetID;
                    const inactURLAppendId = inactURL + '/' + orderRulecriteriaID;
                    this.jbhGlobals.apiService.patchData(inactURLAppendId, false).subscribe(data => {
                        const isSuccess = data['status'] === 'success';
                        if (isSuccess) {
                            this.jbhGlobals.notifications.success('Success', 'Rule Inactivated Successfully');
                            this.page(this.offset, this.limit);
                        } else {
                            this.jbhGlobals.notifications.alert('Failure', 'Rule Inactivation Failed');
                        }
                    }, (err: Error) => {
                        this.jbhGlobals.notifications.alert('Failure', 'Rule Inactivation Failed');
                        return false;
                    });
                    break;
                }
            case 'viewrule':
                {
                    this.onViewEditRule('view');
                    break;
                }
            case 'vieweditrule':
                {
                    this.onViewEditRule('edit');
                    break;
                }
            case 'activaterule':
                {
                    const actURL = this.jbhGlobals.endpoints.automationrules.activateRule;
                    const actURLId = actURL + '?orderRuleDetailIDs=' + row.orderRuleDetailId;
                    this.jbhGlobals.apiService.patchData(actURLId, {}).subscribe(data => {
                        const isSuccess = data['status'] === 'success';
                        if (isSuccess) {
                            this.jbhGlobals.notifications.success('Success', 'Rule Inactivated Successfully');
                        } else {
                            this.jbhGlobals.notifications.alert('Failure', 'Rule Inactivation Failed');
                        }
                    }, (err: Error) => {
                        return false;
                    });
                    break;
                }
            default:
                {
                    break;
                }
        }
    }
    onViewEditRule(mode) {
        const url = this.jbhGlobals.endpoints.automationrules.configurenewrule;
        const rs = this.rulesService;
        const criteriaSetUrl = url + '/' + rs.ruleDetails.orderRuleCriteriaSetID;
        this.jbhGlobals.apiService.getData(criteriaSetUrl).subscribe(data => {
            if (data !== null && data !== undefined) {
                rs.selectedCriteriaDetails = data;
                const routeURL = (mode === 'edit') ? '/automationrules/configurenewrule' : '/automationrules/viewrule';
                this.router.navigateByUrl(routeURL);
            } else if (data === null || data === undefined) {
                this.jbhGlobals.notifications.alert('Failure', 'No details found');
            }
        }, (err: Error) => {
            return false;
        });
    }
    onPage(event) {
        this.offset = event.offset;
        this.limit = event.limit;
        this.page(this.offset, this.limit);
    }
    page(offset, limit) {
        this.loadGridData({
            'page': offset,
            'limit': limit
        });
    }
    onActivate(event) {
        this.selected.splice(0, this.selected.length);
        this.selected.push(event.row);
    }
    additionalSearch() {
        if (this.flag === 0) {
            this.flag = 1;
        } else {
            this.flag = 0;
        }
    }
    showPopOver(row) {
        return (row.orderRuleCriteriaSets[0].status === 'Active') ? true : false;
    }
    formatDate(dt) {
        return (dt !== null && dt !== '' && dt !== undefined) ? new Date(dt) : '';
    }
    changeEvent(e) {
        this.offset = 0;
        const isChk = e.data.checked;
        const fVal = e.data.fullVal;
        if (isChk === true) {
            switch (e.num) {
                case 0:
                    const buso = fVal.id;
                    const busoFormat = buso.split('-');
                    if (busoFormat[1] === 'All') {
                        this.businessUnit.push(busoFormat[0]);
                    } else {
                        this.serviceOfferings.push(buso);
                    }
                    break;
                case 1:
                    this.associationLevels.push(fVal.orderRuleTypeCode);
                    break;
                case 2:
                    this.orderRuleCategories.push(fVal.orderRuleCategoryCode);
                    break;
                case 4:
                    this.activeFlags.push(fVal.code);
                    break;
                default:
                    break;
            }
        } else {
            switch (e.num) {
                case 0:
                    const buso = fVal.id;
                    const busoFormat = buso.split('-');
                    const businessElementIndex = this.businessUnit.indexOf(busoFormat[0]);
                    this.businessUnit.splice(businessElementIndex, 1);
                    const serviceElementIndex = this.serviceOfferings.indexOf(busoFormat[1]);
                    this.serviceOfferings.splice(serviceElementIndex, 1);
                    break;
                case 1:
                    const associationElementIndex = this.associationLevels.indexOf(fVal.orderRuleTypeCode);
                    this.associationLevels.splice(associationElementIndex, 1);
                    break;
                case 2:
                    const orderRuleElementIndex = this.orderRuleCategories.indexOf(fVal.orderRuleCategoryCode);
                    this.orderRuleCategories.splice(orderRuleElementIndex, 1);
                    break;
                case 4:
                    const orderStatusElementIndex = this.activeFlags.indexOf(fVal.code);
                    this.activeFlags.splice(orderStatusElementIndex, 1);
                    break;
                default:
                    break;
            }
        }
        this.loadGridData();
    }
    clickReset(index): void {
        switch (index) {
            case 0:
                this.serviceOfferings = [];
                this.businessUnit = [];
                break;
            case 1:
                this.associationLevels = [];
                break;
            case 2:
                this.orderRuleCategories = [];
                break;
            case 3:
                this.globalOverrideFlags = [];
                break;
            case 4:
                this.activeFlags = [];
                break;
            default:
                break;
        }
        this.loadGridData();
    }
    onRuleSelect(e) {
        this.orderRuleName = e.value;
        this.offset = 0;
        this.loadGridData();
    }
    onRuleLoading(e: boolean): void {
        this.onLoading = e;
        this.onNoResults = false;
    }
    onRuleNoResults(e: boolean): void {
        this.onNoResults = e;
    }
    getRuleName(e) {
        this.ruleTypeAheadUrl = this.jbhGlobals.endpoints.automationrules.ruleNameTypeahead;
        if (e.length >= 2) {
            // this.ruleSearchFlag = true;
            const ruleParam = {
                'orderRuleName': e
            };
            this.jbhGlobals.apiService.getData(this.ruleTypeAheadUrl, ruleParam, false).subscribe(data => {
                if (!this.jbhGlobals.utils.isEmpty(data)) {
                    this.ruleMockData = [];
                    this.ruleMockData = data['content'];
                }
            });
        }
    }
    loadGridData(pgParams?: Object) {
        const listUrl = this.jbhGlobals.endpoints.automationrules.configuredruleslist;
        const params = {
            'businessUnit': this.businessUnit,
            'businessUnitServiceOffering': this.serviceOfferings,
            'orderRuleType': this.associationLevels,
            'orderRuleCategory': this.orderRuleCategories,
            'activeFlag': this.activeFlags,
            'globalOverride': this.globalOverrideFlags,
            'orderRuleName': this.orderRuleName
        };
        const isPgPrmNotNull = (pgParams !== null && pgParams !== undefined);
        params['page'] = (isPgPrmNotNull) ? pgParams['page'] : 0;
        params['limit'] = (isPgPrmNotNull) ? pgParams['limit'] : this.limit;
        this.jbhGlobals.apiService.getData(listUrl, params).subscribe(data => {
            this.onNoResults = false;
            if (!this.jbhGlobals.utils.isEmpty(data)) {
                this.rows = data['content'];
                this.totalRecordsCount = data['totalElements'];
            } else {
                this.rows = [];
                this.totalRecordsCount = 0;
            }
        });
    }
    appendBUSO(val) {
        const validBUValues = val.businessUnit;
        const validBUSOValues = val.businessUnitServiceOffering;
        const bindBUValues = [];
        const bindBUSOValues = [];
        if (!this.jbhGlobals.utils.isEmpty(validBUValues) && this.jbhGlobals.utils.isArray(validBUValues)) {
            if (validBUValues.length > 0) {
                for (let i = 0; i < validBUValues.length; i++) {
                    if (!this.jbhGlobals.utils.isEmpty(validBUValues[i])) {
                        bindBUValues.push(validBUValues[i]);
                    }
                }
                if (!this.jbhGlobals.utils.isEmpty(validBUSOValues) && this.jbhGlobals.utils.isArray(validBUSOValues)) {
                    if (validBUSOValues.length > 0) {
                        for (let i = 0; i < validBUSOValues.length; i++) {
                            if (!this.jbhGlobals.utils.isEmpty(validBUSOValues[i])) {
                                bindBUValues.push(validBUSOValues[i]);
                            }
                        }
                    }
                    return bindBUValues.toString().replace(/,/g, ', ');
                } else {
                    return bindBUValues.toString().replace(/,/g, ', ');
                }
            }
        } else if (!this.jbhGlobals.utils.isEmpty(validBUSOValues) && this.jbhGlobals.utils.isArray(validBUSOValues)) {
            if (validBUSOValues.length > 0) {
                for (let i = 0; i < validBUSOValues.length; i++) {
                    if (!this.jbhGlobals.utils.isEmpty(validBUSOValues[i])) {
                        bindBUSOValues.push(validBUSOValues[i]);
                    }
                }
                return bindBUSOValues.toString().replace(/,/g, ', ');
            }
        }
    }
    private setUpKeyboardShortcuts() {
        this.jbhGlobals.shortkeys.getData().subscribe(data => {
            if (data.keyCode === 'alt+1') {
                this.formSectionKey.nativeElement.focus();
            }
        });
    }
}
