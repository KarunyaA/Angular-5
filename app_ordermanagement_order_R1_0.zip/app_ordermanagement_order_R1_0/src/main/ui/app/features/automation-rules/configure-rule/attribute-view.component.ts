import { Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { JBHGlobals } from '../../../app.service';

@Component({
    selector: 'app-attribute-view',
    templateUrl: './attribute-view.component.html',
    styleUrls: ['./attribute-view.component.scss']
})
export class AttributeViewComponent implements OnInit {
    @Input() attrcontrol: FormGroup;
    @Input() index: number;
    @Input() tabIdx: number;
    @Input() attributesList: any;
    @Input() orderRuleCriteriaList: any;
    @Input() orderRuleCriteriaSetID: number;
    @ViewChild('attrDD') attrDD: any;
    @Output() removeAttr: EventEmitter<any> = new EventEmitter<any>();
    debounceValue: any;
    isValueSelected = true;
    transTypeaheadList: any[] = [];
    optField: string;
    compType: string;
    datas: any[] = [];
    ruleCode = 'Attribute';
    ruleVale = 'Value';
    attributeValue: any[] = [];
    orderRuleOperatorsList: any[] = [];
    @ViewChild('ruleDetId')
    private elRuleDetId: ElementRef;

    @Input()
    set orderRuleOpts(isEmpty: boolean) {
        const codeVal = this.attrcontrol['controls']['orderRuleCriteriaCode'].value;
        if (!isEmpty && codeVal !== '' && this.orderRuleCriteriaList !== undefined && this.orderRuleCriteriaList.length > 0) {
            this.orderRuleOperatorsList = this.findOperators(this.orderRuleCriteriaList, codeVal);
        }
    }

    constructor(private jbhGlobals: JBHGlobals, private fb: FormBuilder) { }

    ngOnInit(): void {
        /* Load corresponding component type */
        const currCriCode = this.attrcontrol['controls']['orderRuleCriteriaCode'].value;
        const currCriOpt = this.attrcontrol['controls']['orderRuleLogicalOperatorDTO']['controls']['orderRuleLogicalOperatorCode'].value;
        if (currCriCode !== null && currCriCode !== '') {
            this.setCriValTypeAhead(currCriCode, this.index, currCriOpt);
        } else {
            this.compType = 'textfield';
        }
    }
    inputValidation() {
        this.attrcontrol.controls['orderRuleCriteriaValue'].setValidators(this.jbhGlobals.customValidator.alphaNumeric);
    }
    removeAttribute(id) {
        this.removeAttr.emit({
            event: event,
            values: {
                'id': id,
                'criSetId': this.orderRuleCriteriaSetID,
                'detailId': this.elRuleDetId.nativeElement.value
            }
        });
    }
    onCriteriaChange(eve) {
        const target = eve.currentTarget;
        const selTargetIndex = target.options[target.selectedIndex].getAttribute('data-index');
        this.orderRuleOperatorsList = target.options[target.selectedIndex].getAttribute('data-opts').split(',');
        const criOpt = this.attrcontrol.controls;
        const criVal = target.value;
        criOpt['orderRuleCriteriaValue'].setValue('');
        criOpt['orderRuleLogicalOperatorDTO']['controls']['orderRuleLogicalOperatorCode'].setValue('');
        this.setCriValTypeAhead(criVal, selTargetIndex, null);
    }
    setCriValTypeAhead(criVal, selTargetIndex, criOpt) {
        const attrListVal = this.attributesList[criVal];
        if (attrListVal !== undefined && attrListVal['type'] === 'multiselect') {
            const endPtUrl = attrListVal['url'];
            const pname = attrListVal['paramname'];
            const isTypeAhead = (pname !== null && pname !== '');
            this.optField = attrListVal['responseattr'];
            this.compType = attrListVal['type'];
            const url = (pname !== '') ? endPtUrl + '?' + pname + '=' : endPtUrl;
            this.createCriValTypeAhead(selTargetIndex, url, isTypeAhead);
        } else if ((criOpt !== null && (criOpt === 'EqlGrtThn' || criOpt === 'EqlLesThn' || criOpt === 'GrtLessThn' || criOpt === 'Between'))) {
            this.compType = 'range';
        } else if (attrListVal !== undefined && attrListVal['type'] === 'boolean') {
            this.compType = 'boolean';
            this.datas = attrListVal['data'];
        } else if (attrListVal !== undefined && attrListVal['type'] === 'textfield') {
            this.compType = 'textfield';
        } else if (attrListVal !== undefined && attrListVal['type'] === 'range') {
            this.compType = 'range';
        } else if (attrListVal !== undefined && attrListVal['type'] === 'numberfield') {
            this.compType = 'numberfield';
        }
    }
    createCriValTypeAhead(idx, urlVal, isTypeAhead) {
        const detCtrl = this.attrcontrol;
        if (idx !== null && detCtrl !== undefined) {
            detCtrl['controls']['orderRuleCriteriaValue']['valueChanges']
                .debounceTime(this.debounceValue)
                .distinctUntilChanged()
                .subscribe((searchStr) => {
                    if (searchStr !== null && searchStr !== undefined && searchStr.length > 1) {
                        this.isValueSelected = false;
                        const urlStr = (isTypeAhead) ? urlVal + searchStr : urlVal;
                        this.jbhGlobals.apiService.getData(urlStr, null, false).subscribe(data => {
                            this.transTypeaheadList = data;
                        });
                    }
                    /*if (this.ruleForm['dirty']) {
                        this.ruleFormId.nativeElement.focus();
                    }*/
                }, (err: Error) => { });
        }
    }

    onSelect(event) {
        this.isValueSelected = true;
    }

    onBlur(event) {
        if (!this.isValueSelected) {
            this.attrcontrol['controls']['orderRuleCriteriaValue'].setValue('');
        }
    }
    attrValidation(attrForm) {
        if (this.jbhGlobals.utils.isEmpty(attrForm['controls']['orderRuleCriteriaValue'].value)) {
            this.jbhGlobals.utils.forIn(this.attrcontrol['controls']['orderRuleCriteriaValue'],
                function (value, name, object) {
                    attrForm['controls']['orderRuleCriteriaValue'].markAsTouched();
                    attrForm['controls']['orderRuleCriteriaValue'].setErrors({
                        'mandatory': true
                    });
                });
        }
        if (this.jbhGlobals.utils.isEmpty(attrForm['controls']['orderRuleCriteriaCode'].value)) {
            this.jbhGlobals.utils.forIn(this.attrcontrol['controls']['orderRuleCriteriaCode'],
                function (value, name, object) {
                    attrForm['controls']['orderRuleCriteriaCode'].markAsTouched();
                    attrForm['controls']['orderRuleCriteriaCode'].setErrors({
                        'mandatorySelect': true
                    });
                });
        }
        const oprCode = this.attrcontrol.controls['orderRuleLogicalOperatorDTO']['controls']['orderRuleLogicalOperatorCode'];
        if (this.jbhGlobals.utils.isEmpty(oprCode.value)) {
            this.jbhGlobals.utils.forIn(oprCode,
                function (value, name, object) {
                    oprCode.markAsTouched();
                    oprCode.setErrors({
                        'mandatorySelect': true
                    });
                });
        }
    }
    /* changeLocationLoading(e:  boolean):  void {
        this.locationLoading = e;
    }
    changeLocationNoResults(e:  boolean):  void {
        this.locationNoResults = e;
    } */

    onOptChange(eve) {
        const selOpt = eve.values.selectedVal;
        if (selOpt === 'EqlGrtThn' || selOpt === 'EqlLesThn' || selOpt === 'GrtLessThn' || selOpt === 'Between') {
            this.compType = 'range';
        } else if (selOpt === 'GrtThn' || selOpt === 'LessThan') {
            this.compType = 'numberfield';
        } else if (selOpt === 'StartWith' || selOpt === 'Equal') {
            this.compType = 'textfield';
        } else {
            const target = this.attrDD;
            this.attrcontrol['controls']['orderRuleCriteriaValue'].setValue('');
            this.setCriValTypeAhead(target.nativeElement.value, target.nativeElement.getAttribute('data-index'), null);
        }
    }

    findOperators(criArr, searchStr) {
        let retVal = [];
        criArr.forEach(key => {
            if (this.orderRuleOperatorsList.length === 0 && key['orderRuleCriteriaCode'] === searchStr) {
                retVal = key['orderRuleLogicalOperator'];
            }
        });
        return retVal;
    }

    isAddedAttributes(code) {
        return (code === 'OrdChannel' || code === 'BusUnit' || code === 'BUServOffr' || code === 'Supersede');
    }
}
