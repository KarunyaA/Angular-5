import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { JBHGlobals } from '../../../app.service';
import { RulesService } from '../rules.service';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
    selector: 'app-rules-list',
    templateUrl: './rules-list.component.html',
    styleUrls: ['./rules-list.component.scss']
})
export class RulesListComponent implements OnInit {
    rows: any[];
    selected = [];
    totalRecordsCount = 0;
    offset = 0;
    limit = 20;
    flag = 0;
    rulesFilterTitle = 'Filter By';
    serviceOfferings: any = [];
    orderRuleCategories: any = [];
    ruleMockData: any[] = [];
    ruleSearchFlag = false;
    orderRuleName: string;
    debounceValue: any;
    typeaheadModule: any;
    rulesFilterList: any[] = [{
        'index': 0,
        'key': 'serviceOfferingCode',
        'title': 'Service Offering',
        'checkSelectionKey': 'text',
        'componentType': 'lsitType',
        'rootVal': ['_embedded', 'buso'],
        'url': 'getBuSO',
        'params': {}
    }, {
        'index': 1,
        'key': 'ruleCategory',
        'title': 'Rule Category',
        'checkSelectionKey': 'orderRuleCategoryDescription',
        'rootVal': ['_embedded', 'orderRuleCategories'],
        'componentType': 'lsitType',
        'url': 'getRulesCategory',
        'params': {}
    }];
    onLoading: boolean;
    onNoResults: boolean;
    businessUnits: any[] = [];
    ngOnInit(): void {
        this.page(this.offset, this.limit);
        this.typeaheadModule = this.fb.group({
            searchRuleName: ['', Validators.required]
        });
        this.debounceValue = this.jbhGlobals.settings.debounce;
        this.typeaheadModule['controls']['searchRuleName']['valueChanges']
            .debounceTime(this.debounceValue)
            .distinctUntilChanged()
            .subscribe((value) => {
                if (!this.jbhGlobals.utils.isEmpty(value) && value !== undefined) {
                    this.orderRuleName = '';
                    this.getRuleName(value);
                } else if (value.length === 0) {
                    this.onNoResults = false;
                    this.orderRuleName = '';
                    this.ruleMockData = [];
                    this.loadGridData();
                }
            }, (err: Error) => { });
    }
    constructor(private router: Router, private jbhGlobals: JBHGlobals, private rulesService: RulesService, private fb: FormBuilder) { }
    onPage(event) {
        this.offset = event.offset;
        this.limit = event.limit;
        this.page(this.offset, this.limit);
    }
    page(offset, limit) {
        this.loadGridData({
            'page': offset,
            'limit': limit
        });
    }
    updateRowPosition() {
        const ix = this.getSelectedIx();
        const arr = [...this.rows];
        arr[ix - 1] = this.rows[ix];
        arr[ix] = this.rows[ix - 1];
        this.rows = arr;
    }

    getSelectedIx() {
        return this.selected[0]['$$index'];
    }
    onSelect(event) {
        const selRule = event.selected[0];
        this.rulesService.ruleDetails = {
            'orderRuleCriteriaSetID': selRule.orderRuleCriteriaSetID,
            'orderRuleDetailID': selRule.orderRuleDetailID,
            'orderRuleSupersedeTypeCode': selRule.orderRuleSupersedeTypeCode,
            'orderRuleName': selRule.orderRuleName,
            'orderRuleDescription': selRule.orderRuleDescription,
            'startDate': this.rulesService.ruleDetails.startDate,
            'associationLevel': selRule.associationLevel,
            'businessUnit': selRule.businessUnit,
            'businessUnitServiceOffering': selRule.businessUnitServiceOffering,
            'isBusinessUnitLevelRules': this.rulesService.ruleDetails.isBusinessUnitLevelRules,
            'isCustomerLevelRules': this.rulesService.ruleDetails.isCustomerLevelRules,
            'billTo': null,
            'effectiveTimestamp': '',
            'expirationTimestamp': '',
            'mode': this.rulesService.ruleDetails.mode,
            'resultantActions': selRule.resultantAction,
            'validationSet': selRule.validationSet,
            'orderRuleCategoryDescription': selRule.orderRuleCategoryDescription
        };
        this.router.navigateByUrl('/automationrules/configurenewrule');
    }
    additionalSearch() {
        if (this.flag === 0) {
            this.flag = 1;
        } else {
            this.flag = 0;
        }
    }
    changeEvent(e) {
        this.offset = 0;
        const isChk = e.data.checked;
        const fVal = e.data.fullVal;
        if (isChk === true) {
            switch (e.num) {
                case 0:
                    const buso = fVal.id;
                    const busoFormat = buso.split('-');
                    if (busoFormat[1] === 'All') {
                        this.businessUnits.push(busoFormat[0]);
                    } else {
                        this.businessUnits.push(busoFormat[0]);
                        this.serviceOfferings.push(busoFormat[1]);
                    }
                    break;
                case 1:
                    this.orderRuleCategories.push(fVal.orderRuleCategoryDescription);
                    break;
                default:
                    break;
            }
        } else {
            switch (e.num) {
                case 0:
                    const buso = fVal.id;
                    const busoFormat = buso.split('-');
                    const businessElementIndex = this.businessUnits.indexOf(busoFormat[0]);
                    this.businessUnits.splice(businessElementIndex, 1);
                    const serviceElementIndex = this.serviceOfferings.indexOf(busoFormat[1]);
                    this.serviceOfferings.splice(serviceElementIndex, 1);
                    break;
                case 1:
                    const orderRuleElementIndex = this.orderRuleCategories.indexOf(fVal.orderRuleCategoryDescription);
                    this.orderRuleCategories.splice(orderRuleElementIndex, 1);
                    break;
                default:
                    break;
            }
        }
        this.loadGridData();
    }
    clickReset(index): void {
        switch (index) {
            case 0:
                this.serviceOfferings = [];
                this.businessUnits = [];
                break;
            case 1:
                this.orderRuleCategories = [];
                break;
            default:
                break;
        }
        this.loadGridData();
    }
    onPreRuleSelect(e) {
        this.orderRuleName = e.value;
        this.offset = 0;
        this.loadGridData();
    }
    onPreRuleLoading(e: boolean): void {
        this.onLoading = e;
        this.onNoResults = false;
    }
    onPreRuleNoResults(e: boolean): void {
        this.onNoResults = e;
    }
    getRuleName(e) {
        if (e.length > 2) {
            // this.ruleSearchFlag = true;
            const ruleParam = {
                'orderRuleName': e
            };
            const url = this.jbhGlobals.endpoints.automationrules.ruleNameTypeahead;
            this.jbhGlobals.apiService.getData(url, ruleParam, false).subscribe(data => {
                if (!this.jbhGlobals.utils.isEmpty(data)) {
                    this.ruleMockData = [];
                    this.ruleMockData = data['content'];
                }
            });
        }
        /* else if (e.length <= 1 && this.ruleSearchFlag) {
                   this.ruleMockData = [];
                   this.ruleSearchFlag = false;
                   const ruleParam = {};
                   this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.automationrules.ruleslist,
                     ruleParam, false).subscribe(data => {
                       this.rows = data['content'];
                   });
               } */
    }
    loadGridData(pgParams?: Object) {
        const listUrl = this.jbhGlobals.endpoints.automationrules.ruleslist;
        const params = {
            'serviceOffering': this.serviceOfferings,
            'businessUnit': this.businessUnits,
            'orderRuleCategory': this.orderRuleCategories,
            'orderRuleName': this.orderRuleName
        };
        const isPgPrmNotNull = (pgParams !== null && pgParams !== undefined);
        params['page'] = (isPgPrmNotNull) ? pgParams['page'] : 0;
        params['limit'] = (isPgPrmNotNull) ? pgParams['limit'] : this.limit;
        this.jbhGlobals.apiService.getData(listUrl, params).subscribe(data => {
            this.onNoResults = false;
            if (!this.jbhGlobals.utils.isEmpty(data)) {
                this.rows = data['content'];
                this.totalRecordsCount = data['totalElements'];
            } else {
                this.rows = [];
                this.totalRecordsCount = 0;
            }
        });
    }
    appendBUSO(val) {
        const retValidValues = [];
        for (let i = 0; i < val.length; i++) {
            if (val[i].businessUnit !== null && val[i].serviceOffering !== null) {
                retValidValues.push(val[i].businessUnit + '-' + val[i].serviceOffering);
            } else if (val[i].businessUnit !== null && val[i].serviceOffering === null) {
                retValidValues.push(val[i].businessUnit);
            } else if (val[i].businessUnit === null && val[i].serviceOffering !== null) {
                retValidValues.push(val[i].serviceOffering);
            }
        }
        return retValidValues.toString().replace(/,/g, ', ');
    }
}
