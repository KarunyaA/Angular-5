import { Component, OnInit } from '@angular/core';
import { JBHGlobals } from '../../../../app.service';
import { RulesService } from '../../rules.service';
import { Router } from '@angular/router';

@Component({
    selector: 'app-view-rule',
    templateUrl: './view-rule.component.html',
    styleUrls: ['./view-rule.component.scss']
})
export class ViewRuleComponent implements OnInit {

    selectedRule: any;
    orderRuleDetailID: number;
    orderRuleCriteriaSetID: number;
    orderRuleName: string;
    orderRuleDescription: string;
    startDate: string;
    associationLevel: string;
    businessUnit: string;
    businessUnitServiceOffering: string;
    isBusinessUnitLevelRules: boolean;
    isCustomerLevelRules: boolean;
    billTo: Object;
    orderCreationChannel: string;
    orderRuleCriteriaDetail: any;
    orderRuleParameter: any;
    orderRulePrmVal: any;

    constructor(private jbhGlobals: JBHGlobals, private ruleService: RulesService,
                private router: Router) { }

    ngOnInit(): void {
        this.viewRule();
    }

    viewRule() {
        const ruleDet = this.ruleService.ruleDetails;
        this.orderRuleDetailID = ruleDet.orderRuleDetailID;
        this.orderRuleCriteriaSetID = ruleDet.orderRuleCriteriaSetID;
        this.orderRuleName = ruleDet.orderRuleName;
        this.orderRuleDescription = ruleDet.orderRuleDescription;
        this.associationLevel = ruleDet.associationLevel;
        this.businessUnit = ruleDet.businessUnit;
        this.businessUnitServiceOffering = ruleDet.businessUnitServiceOffering;
        this.isBusinessUnitLevelRules = ruleDet.isBusinessUnitLevelRules;
        this.isCustomerLevelRules = ruleDet.isCustomerLevelRules;
        this.billTo = ruleDet.billTo;
        this.startDate = ruleDet.effectiveTimestamp;

        this.selectedRule = this.ruleService.selectedCriteriaDetails;
        if (this.selectedRule !== null) {
            this.businessUnit = this.selectedRule.businessUnit;
            this.businessUnitServiceOffering = this.selectedRule.businessUnitServiceOffering;
            // this.globalOverride = this.selectedRule.globalOverride;
            // this.orderCreationChannel = this.orderCreationChannel;
            this.orderRuleCriteriaDetail = this.selectedRule.orderRuleCriteriaDetailDTO;
            this.orderRuleParameter = this.selectedRule.orderRuleParameterDTO;
        }
    }
    bindValue(prm) {
        let val = '';
        const type = prm.orderRuleParameterTypeDTO;
        const code = type.orderRuleParameterValueTypeCode;
        const num = prm.orderParameterNumberValue;
        const char = prm.orderParameterCharValue;
        const dt = prm.orderParameterDateValue;
        val = (code === 'Number') ? num : (code === 'Char' ? char : dt);
        return val + ' ' + type.orderRuleParameterTypeDescription;
    }
    onBack() {
        this.router.navigateByUrl('/automationrules');
    }

}
