import { OrderRuleLogicalOperator } from './orderrulelogicaloperator.model';
import { OrderRuleParameterType } from './orderruleparametertype.model';

export class OrderRuleParameter {
    orderRuleParameterID: number;
    orderParameterName: string;
    orderParameterNumberValue: number;
    orderParameterCharValue: string;
    orderParameterDateValue: Date;
    orderRuleLogicalOperator: OrderRuleLogicalOperator;
    orderRuleParameterType: OrderRuleParameterType;
}
