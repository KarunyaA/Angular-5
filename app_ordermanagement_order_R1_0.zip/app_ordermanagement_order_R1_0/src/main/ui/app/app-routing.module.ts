import { NgModule } from '@angular/core';
import { Router, RouterModule, Routes } from '@angular/router';

import { MonitoringRoutes } from './features/monitoring/monitoring-routing.config';
import { Error401Component, Error404Component, Error500Component } from './shared/errors/index';
import { RouteGuard } from './shared/jbh-esa/index';

const routes: Routes = [
  {
    path: 'dashboard',
    loadChildren: 'app/features/dashboard/dashboard.module#DashboardModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Dashboard',
      pathIcon: `icon-jbh_home pull-right`,
      order: 1
    },
    canActivate: [RouteGuard]
  },
  {
    path: 'createorders',
    loadChildren: 'app/features/create-orders/create-orders.module#CreateOrdersModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Create Order',
      pathIcon: `icon-jbh_add pull-right`,
      order: 1
    },
    canActivate: [RouteGuard]
  },
  {
    path: 'shippingoptions',
    loadChildren: 'app/features/shipping-options/shipping-options.module#ShippingOptionsModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Shipping Options',
      pathIcon: `icon-jbh_list pull-right`,
      order: 1
    },
    canActivate: [RouteGuard]
  },  
  {
    path: 'tasks',
    loadChildren: 'app/features/monitoring/exception-management/exception-management.module#ExceptionManagementModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Tasks',
      pathIcon: `icon-jbh_clipboard pull-right`,
      order: 1
    },
    canActivate: [RouteGuard]
  },
  {
    path: 'exceptionmaintenance',
    loadChildren: 'app/features/monitoring/exception-maintenance/exception-maintenance.module#ExceptionMaintenanceModule',
    canActivate: [RouteGuard]
  },
  {
    path: 'automationrules',
    loadChildren: 'app/features/automation-rules/automation-rules.module#AutomationRulesModule',
    canActivate: [RouteGuard]
  },
  {
    path: 'vieworder',
    loadChildren: 'app/features/view-order/view-order.module#ViewOrderModule',
    canActivate: [RouteGuard]
  },
  {
    path: 'opportunities',
    loadChildren: 'app/features/opportunity-orders/opportunity-orders.module#OpportunityOrdersModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Opportunities',
      pathIcon: `icon-jbh_thumbs_up pull-right`,
      order: 1
    },
    canActivate: [RouteGuard]
  },
  {
    path: 'ordersearch',
    loadChildren: 'app/features/order-search/order-search.module#OrderSearchModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Advanced Search',
      pathIcon: `icon-jbh_search pull-right`,
      order: 1
    },
    canActivate: [RouteGuard]
  },  
  {
    path: 'manageratesheet',
    loadChildren: 'app/features/manage-rate-sheet/manage-rate-sheet.module#ManageRateSheetModule',
    canActivate: [RouteGuard]
  },
  {
    path: 'loadinformation',
    loadChildren: 'app/features/load-information/load-information.module#LoadInformationModule',
    canActivate: [RouteGuard]
  },
  {
    path: 'viewucr',
    loadChildren: 'app/features/view-ucr/view-ucr.module#ViewUcrModule',
    canActivate: [RouteGuard]
  }, {
    path: 'error401',
    component: Error401Component
  }, {
    path: 'error404',
    component: Error404Component
  }, {
    path: 'error500',
    component: Error500Component
  },
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
  { path: '**', redirectTo: 'error401' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  providers: [RouteGuard]
})

export class AppRoutingModule { }
