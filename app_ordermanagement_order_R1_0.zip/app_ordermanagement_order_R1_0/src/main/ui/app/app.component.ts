import { AfterViewInit, Component, HostListener, OnInit } from '@angular/core';
import {
    Event as RouterEvent, NavigationCancel, NavigationEnd,
    NavigationError, NavigationStart, Router
} from '@angular/router';

import { JBHGlobals } from './app.service';
import { SpinnerService } from './shared/spinner/index';
import { BusinessUnitService } from './shared/jbh-esa/index';

window.focus();

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.scss']
})

export class AppComponent implements OnInit, AfterViewInit {

    sidebarLock = false;
    isSidebarOpen = false;
    loading = true;
    commonData: any = {};
    options: any;

    constructor(
        private router: Router,
        private jbhGlobals: JBHGlobals,
        private spinnerService: SpinnerService,
        public businessUnitService: BusinessUnitService) {
        jbhGlobals.logger.info('Approot  initialized');
    }

    ngOnInit() {

        console.log('user details', this.jbhGlobals.userDetails);
        this.setUserPage(this.jbhGlobals.user.getAuthenticationStatus());
        this.businessUnitService.loadBusinessUnit(this.jbhGlobals.endpoints.order.getbusinessunit);

        this.router.events.subscribe((event: RouterEvent) => {
            this.navigationInterceptor(event);
        });
        this.options = this.jbhGlobals.settings.notificationsOptions;
        this.jbhGlobals.commonDataService.getData().subscribe(data => this.commonData = data);
        const status = this.businessUnitService.hasOMAccess();
        status ?  this.setUserPage(200) :  this.setUserPage(401);
    }

    @HostListener('window:keyup', ['$event'])
    keyboardInput(event: any) {
        console.log(this.jbhGlobals.shortkeys.getKeyCode(event));
        this.jbhGlobals.shortkeys.saveData({
            keyCode: this.jbhGlobals.shortkeys.getKeyCode(event),
            eventElement: event.target
        });
    }

    @HostListener('window:click', ['$event'])
    trackAppClick(event: any) {
        this.jbhGlobals.mouseevents.saveData({
            target: this.jbhGlobals.mouseevents.getTarget(event)
        });
    }

    ngAfterViewInit() {
        this.commonData.headerOverlay = true;
    };

    toggleMobleSidebar(e) {
        this.isSidebarOpen = e;
        this.sidebarLock = e;
    }

    manageOverlayToggle(e) {
        this.commonData.headerOverlay = e;
        this.jbhGlobals.commonDataService.saveData(this.commonData);
    }
    setUserPage(status) {
        switch (status) {
            case 200: break;
            case 401: this.router.navigateByUrl('error401'); break;
            case 404: this.router.navigateByUrl('error404'); break;
            case 500: this.router.navigateByUrl('error500'); break;
            default: this.router.navigateByUrl('error401'); break;
        }
    }

    onLockSideBar(e) {
        this.sidebarLock = e;
    }

    navigationInterceptor(event: RouterEvent): void {
        if (event instanceof NavigationStart) {
            this.jbhGlobals.logger.log('Naviagation start');
            this.jbhGlobals.apiService.requestCount = 0;
            this.spinnerService.spinnerText = 'Loading Page Components ...';
            if (!this.spinnerService.showStatus) {
                this.spinnerService.show();
            }
            this.jbhGlobals.notifications.remove();
        } else if (event instanceof NavigationEnd) {
            this.jbhGlobals.logger.log('Naviagation end');
            if (this.jbhGlobals.apiService.requestCount === 0) {
                this.spinnerService.hide();
            }
        } else if (event instanceof NavigationCancel) {
            this.jbhGlobals.logger.log('Naviagation NavigationCancel');
            this.spinnerService.hide();
            this.jbhGlobals.apiService.requestCount = 0;
        } else if (event instanceof NavigationError) {
            this.jbhGlobals.logger.log('Naviagation NavigationError');
            this.spinnerService.hide();
            this.jbhGlobals.apiService.requestCount = 0;
        }
    }
}
