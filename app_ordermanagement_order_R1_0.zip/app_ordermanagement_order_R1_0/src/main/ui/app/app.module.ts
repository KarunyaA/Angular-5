import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { CommonModule } from '@angular/common';
import { NgIdleKeepaliveModule } from '@ng-idle/keepalive';

import { SimpleNotificationsModule } from 'angular2-notifications';
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';

import { ShortcutkeyService } from './shared/jbh-app-services/shortcutkey.service';
import { CoreModule } from './core/core.module';
import { SpinnerComponent, SpinnerService } from './shared/spinner/index';
import { ApiClientService } from './shared/jbh-app-services/api-client.service';
import { LoggerService } from './shared/jbh-app-services/logger.service';
import { AppSharedDataService } from './shared/jbh-app-services/app-shared-data.service';
import { LocalStorageService } from './shared/jbh-app-services/local-storage.service';
import { SharedModule } from './shared/shared.module';
import { BusinessUnitService, JbhEsaModule, UserService } from './shared/jbh-esa/index';
import { MouseEventService } from './shared/jbh-app-services/mouseevent.service';
import { ErrorHandlerModule } from './shared/error-handler/error-handler.module';
import { TemplateJsonTransformerService } from './features/create-orders/templates/template-json-transformer.service';
import { JbhJsonTransformerService } from './features/create-orders/orders/services/jbh-json-transformer.service';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { JBHGlobals } from './app.service';
import { Error401Component, Error404Component, Error500Component, ErrorsModule } from './shared/errors/index';
import { TimeoutNotifierService } from './shared/jbh-app-services/timeout-notifier.service';

const PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  suppressScrollX: false,
  minScrollbarLength: 10,
  maxScrollbarLength: 50
};

// UserService.URL = 'api/order/esaorder.json';

@NgModule({
  declarations: [
    AppComponent,
    SpinnerComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    CommonModule,
    CoreModule,
    SharedModule,
    AppRoutingModule,
    SimpleNotificationsModule.forRoot(),
    PerfectScrollbarModule.forRoot(PERFECT_SCROLLBAR_CONFIG),
    ErrorHandlerModule,
    JbhEsaModule.forRoot(),
    ErrorsModule,
    NgIdleKeepaliveModule.forRoot()
  ],
  providers: [
    JBHGlobals,
    ApiClientService,
    LoggerService,
    SpinnerService,
    JbhJsonTransformerService,
    TemplateJsonTransformerService,
    AppSharedDataService,
    LocalStorageService,
    ShortcutkeyService,
    MouseEventService,
    UserService,
    BusinessUnitService,
    TimeoutNotifierService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
