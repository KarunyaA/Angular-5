import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";

import {CCI_AccCreateObjects} from '../ObjectRepository/AccountCreateObjects'
let ObjCCI_AC = new CCI_AccCreateObjects();

import {ExcelReader} from "../CommonFiles/ReadFromXL"
var ReadFromXL= new ExcelReader()
import {DataDictionary} from "../DataFiles/DictionaryData"
import { Browser } from "selenium-webdriver";
var DataDictLib= new DataDictionary()
import {ReusableFunctions} from "../PageFiles/ReusableFunctions"
var reuse= new ReusableFunctions()

export class CreateAccount{
/*********************************************************************************
	* MethodName:  invokeApplication
	* Description: To Invoke Url 
	* Parameter (if any):  
	* Return type:  Void
************************************************************************/
invokeApplication() { 
    browser.refresh();
    browser.get(ObjCCI_AC.str_url);     
    }   
/*********************************************************************************
	* MethodName:  ApplicationLogin
	* Description: Login to the application 
	* Parameter (if any):  TCName
	* Return type:  Void
************************************************************************/
ApplicationLogin(TCName){
    browser.waitForAngular();
    var CCiRow=ReadFromXL.FindRowNum(TCName,"CCI_Details");
    DataDictLib.pushToDictionaryWithSheet(CCiRow,"CCI_Details");

    var str_UserName:string =DataDictLib.getFromDictionary("UserName");
    reuse.EnterValue(ObjCCI_AC.txt_UsrName,str_UserName,"User Name"); 

    var str_Pswd:string =DataDictLib.getFromDictionary("Password");
    reuse.EnterValue(ObjCCI_AC.txt_Pswd,str_Pswd,"Password");

    reuse.ClickElement(ObjCCI_AC.btn_SignIn,"SignIn");
}  
/**==============================================================================
* 
* MethodName:  Navigation_Process
* Description: To Navigation To Location Search Page 
* Parameter (if any):  
* Return type:  Void
===============================================================================*/
Navigation_Process(){    
    browser.waitForAngular();    
    reuse.ClickElement(ObjCCI_AC.btn_toggle,"Toggle Button");
    reuse.ClickElement(ObjCCI_AC.tab_Account,"Account Tab");
    reuse.ClickElement(ObjCCI_AC.subTab_AccountSearch,"Account Search Tab")
}
/**==============================================================================
* 
* MethodName:  CreateAccount
* Description: Create account with details from excel
* Parameter (if any):  TCName
* Return type:  Void
===============================================================================*/
CreateAccount(TCName){
    browser.waitForAngular();
    reuse.ClickElement(ObjCCI_AC.icon_OverflowMenu,"Overflow Menu");
    reuse.ClickElement(ObjCCI_AC.btn_createAcc,"Create Account");   
    
    browser.sleep(2000);
    var CCiRow=ReadFromXL.FindRowNum(TCName,"CCI_Details");
    DataDictLib.pushToDictionaryWithSheet(CCiRow,"CCI_Details");
    //Enter Country
    var str_Country:string =DataDictLib.getFromDictionary("Country");    
    reuse.ClickElement(ObjCCI_AC.btncmb_Country,"Country Dropdown");
    reuse.EnterValue(ObjCCI_AC.txt_Country,str_Country,"Country");
    ObjCCI_AC.txt_Country.sendKeys(protractor.Key.ENTER); 

    //Enter Address value
    var str_address:string= DataDictLib.getFromDictionary("Address");
    reuse.EnterValue(ObjCCI_AC.txt_Address, str_address, "Address");

    //Enter City value
    var str_City:string= DataDictLib.getFromDictionary("City");
    reuse.EnterValue(ObjCCI_AC.txt_City, str_City, "City");

    //Select State
    var str_State:string =DataDictLib.getFromDictionary("State");    
    reuse.ClickElement(ObjCCI_AC.btncmb_State,"State Dropdown");
    reuse.EnterValue(ObjCCI_AC.txt_State,str_State,"State");
    ObjCCI_AC.txt_State.sendKeys(protractor.Key.ENTER);    
     
    //Enter Postal Code
    var str_PostCode:string= DataDictLib.getFromDictionary("PostalCode");
    reuse.EnterValue(ObjCCI_AC.txt_postCode, str_PostCode, "PostalCode");    
    
    //Enter Account Name
    var str_Accname:string = DataDictLib.getFromDictionary("Account Name");
    reuse.EnterValue(ObjCCI_AC.txt_AccName,str_Accname,"Account Name");

    //Enter Phone Number
    var str_PhNum:string = DataDictLib.getFromDictionary("PhoneNumber");
    reuse.EnterValue(ObjCCI_AC.txt_PhNum,str_PhNum,"Phone Number");

    //Create Button Click
    reuse.ClickElement(ObjCCI_AC.btn_create,"Create Button");
    browser.sleep(10000);
}
/**==============================================================================
* 
* MethodName:  VerifyAccountSuggestionDetails
* Description: To Verify suggestions are displayed based on account name
* Parameter (if any):  TCName
* Return type:  Void
===============================================================================*/
VerifyAccountSuggestionDetails(){
    browser.waitForAngular();

    //Verify update button is Present
    ObjCCI_AC.btn_update.isPresent().then(function(result){
        if(result==true){
            console.log("Update button is displayed");
        }else{
            console.log("Update button is not displayed");
        }
    });

    //Verify Suggested Account is displayed
    ObjCCI_AC.str_suggestionAcc.isPresent().then(function(result){
        if(result==true){
            console.log("Account details are as per Melissa address check");
            ObjCCI_AC.valRow_SuggestAcc.isPresent().then((bool)=>{
                if(bool==true){                    
                    console.log("Suggested New Account section is displayed");
                }
            })
        }else{            
            ObjCCI_AC.str_errPopup.isPresent().then((res)=>{
                if(res==true){
                    ObjCCI_AC.str_errPopup.getText().then((text)=>{
                        console.log(text);
                    reuse.ClickElement( ObjCCI_AC.btn_errOK,"OK");
                    })
                }
            })
        }
    });
}
/**==============================================================================
* 
* MethodName:  CreateAccWithRoletype
* Description: To select a roletype for suggested acc name.
* Parameter (if any):  TCName
* Return type:  Void
===============================================================================*/
CreateAccWithRoletype(TCName){

    var TcRow = ReadFromXL.FindRowNum(TCName,"data");
    DataDictLib.pushToDictionaryWithSheet(TcRow,"data");
    var str_role:string = DataDictLib.getFromDictionary("Role");

    browser.waitForAngularEnabled();
    ObjCCI_AC.valRow_SuggestAcc.isPresent().then((bool)=>{
        if(bool==true){

            reuse.ClickElement(ObjCCI_AC.cmb_role,"Role Dropdown");

            ObjCCI_AC.str_businessId.getText().then((text)=>{
                var int_Bid = text;
                console.log(int_Bid);
                var css_txtRole = "[id='"+int_Bid+"']";
                console.log(css_txtRole);
                var txt_Role = element(by.css(css_txtRole));
                reuse.EnterValue(txt_Role,str_role,"Role");            
                txt_Role.sendKeys(protractor.Key.ENTER);
                browser.sleep(3000);
                
                //Click '>' icon to create Account 
                reuse.ClickElement(ObjCCI_AC.btn_createArrow," '>' icon");
                browser.sleep(10000);
            });            
            
            }
        else{
            console.log("Could not find any accounts that matched your search ");
        }
        })
        
}
/**==============================================================================
* 
* MethodName:  SearchAccount
* Description: To search an account from search Account search page
* Parameter (if any):  TCName
* Return type:  Void
===============================================================================*/
SearchAccount(TCName){
        browser.waitForAngular();
        var TcRow = ReadFromXL.FindRowNum(TCName,"data");
        DataDictLib.pushToDictionaryWithSheet(TcRow,"data");
        var str_Account:string = DataDictLib.getFromDictionary("Search Account Details");

        ObjCCI_AC.txt_AccountSearch.isPresent().then((res)=>{
            if(res==true){
                reuse.EnterValue(ObjCCI_AC.txt_AccountSearch,str_Account,"Account Details");
                ObjCCI_AC.txt_AccountSearch.sendKeys(protractor.Key.TAB);
                reuse.ClickElement(ObjCCI_AC.btn_search,"Search icon");
                browser.sleep(5000);
            }
        })
}
/**==============================================================================
* 
* MethodName:  VerifySearchDetails
* Description: To verify search details are found
* Parameter (if any):  
* Return type:  Void
===============================================================================*/
VerifySearchDetails(){
    browser.waitForAngular();

    ObjCCI_AC.val_resultrow.isPresent().then(function(res){
        if(res==true){
            console.log("Account Details Exist");
        }
        else{
            ObjCCI_AC.str_invalidTxt.getText().then((text)=>{
                console.log(text);
            })
        }
    })
}
/**==============================================================================
* 
* MethodName:  verifyAccountCreatedwithRoletype
* Description: To verify roletype is selected and account created successfully
* Parameter (if any):  
* Return type:  Void
===============================================================================*/
verifyAccountCreatedwithRoletype(){
    browser.waitForAngularEnabled();
    ObjCCI_AC.str_Name.isPresent().then((res)=>{
        if(res==true){
            console.log("Account created successfully");
            var str_Acc = reuse.getTextValueFromElement(ObjCCI_AC.str_Name)

            //Navigate to Account Search Page
            reuse.ClickElement(ObjCCI_AC.tab_Account,"Account Tab");
            reuse.ClickElement(ObjCCI_AC.subTab_AccountSearch,"Account Search Tab")

            //Enter search value 
            reuse.EnterValue(ObjCCI_AC.txt_AccountSearch,str_Acc,"Account Details");   
            ObjCCI_AC.txt_AccountSearch.sendKeys(protractor.Key.TAB);         
            reuse.ClickElement(ObjCCI_AC.btn_search,"Search icon");            
            browser.sleep(5000); 

            var AccName = reuse.getTextValueFromElement(ObjCCI_AC.str_AccName);
            expect(AccName).toContain(str_Acc);

        }else{
            console.log("Failed to create an Account from Suggested Accounts.Please select a different Account name");
        }
    })
    
    
}

}