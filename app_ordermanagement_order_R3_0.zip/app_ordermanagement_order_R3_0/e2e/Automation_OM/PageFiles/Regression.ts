import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";
import {Update_Objects} from "../ObjectRepository/Objects_Order"
import { Key, WebElement } from "selenium-webdriver";

import {ExcelReader} from "../CommonFiles/ReadFromXL"

import {DataDictionary} from "../DataFiles/DictionaryData"
import {ReusableFunctions} from "../PageFiles/ReusableFunctions" 
var DictBU_OM = new DataDictionary();
var DictBU_EOM = new DataDictionary(); 
var OrderID;
let OBJCreate = new Update_Objects();
var ReadFromXL = new ExcelReader();
var DataDictLib = new DataDictionary();
var DataDictLib1 = new DataDictionary();
let reuse= new ReusableFunctions();
var ExcelDataSourceForConf = require('../CommonFiles/ReadFromXL');
var PushAndPullDataDictLib = require('../DataFiles/DictionaryData');
export class  commonFunctions{

Get_url(Testcasename:string):void { 
  console.log(Testcasename);
  var TcRow=ReadFromXL.FindRowNum(Testcasename,"CreateOrder");
  
  DataDictLib.pushToDictionaryWithSheet(TcRow,"CreateOrder");
  var urlName =DataDictLib.getFromDictionary('UrlName');
  console.log(urlName);
  browser.get(urlName); //overrides baseURL  
 }

EnterTextBox(IdValue:string,Value:string):void { 
    var tagname=element(by.css("[formcontrolname=\""+IdValue+"\"]"));
    tagname.clear();
    tagname.sendKeys(Value);
 }
 LoadingComponent(IdValue:string,Value:string):void { 
  OBJCreate.icon_loading.isPresent().then(function(result){
    if(result==true){
        console.log("Update button is displayed");
    }else{
        console.log("Update button is not displayed");
    }
});
}

SignIn(Testcasename:string):void { 
  console.log(Testcasename);
  var TcRow=ReadFromXL.FindRowNum(Testcasename,"CreateOrder");
  
  DataDictLib.pushToDictionaryWithSheet(TcRow,"CreateOrder");
  var username =DataDictLib.getFromDictionary('Username');
  var Password =DataDictLib.getFromDictionary('Password');
  
  OBJCreate.SignIn.isDisplayed().then((elem)=>{ 
    if (elem===true)
    OBJCreate.SignInUser.sendKeys(username);
    OBJCreate.SignInPwd.sendKeys(Password);
    //reuse.ClickElement((OBJCreate.SignInSubmit),"SignInbutton");
    OBJCreate.SignInSubmit.click();
    //browser.logger.info('SignInbutton is clicked');
    browser.sleep(2000);
  });
  
 }
SelectDRopdownValue(IdValue:string):void { 
    var tagname=element(by.css("[placeholder=\""+IdValue+"\"]"));
    tagname.click();
    browser.sleep(2000);
    tagname.sendKeys(protractor.Key.ENTER);
    //OBJCreate.ContactValue.click();
 }
 
NavigatefromDashboard(Pagename:string):void { 
 
    OBJCreate.togglefield.click();
   // browser.sleep(2000);
    var dbOption=element(by.cssContainingText(".routeDisplayText",""+Pagename+"")); 
    dbOption.click();
    browser.sleep(2000);
 }
 NavigateWhenToggleActive(Pagename:string):void { 
  
    
     var dbOption=element(by.cssContainingText(".routeDisplayText",""+Pagename+"")); 
     dbOption.click();
     browser.sleep(3000);
  }
NavigationFunction(Flowvalue:string,Testcasename:string) { 
  var TcRow=ReadFromXL.FindRowNum(Testcasename,"CreateOrder");
  
  DataDictLib.pushToDictionaryWithSheet(TcRow,"CreateOrder");
      var NavIdValue =DataDictLib.getFromDictionary('NavIdValue');
    // var NavIdValue =DataDictLib.getFromDictionary('NavIdValue');
      
    this.NavigatefromDashboard(NavIdValue);
    browser.executeScript("window.scrollBy(-2000, 0)");
    //browser.sleep(4000);
    var Neworder=element(by.xpath("//span[@class=\"btn-group open\"]//ul[@class=\"dropdown-menu dropdown-menu-right\"]//li//a[text()=\""+Flowvalue+"\"]"))  ;
    OBJCreate.Flowmenu.click();
    Neworder.click();
    browser.sleep(2000);
 
 }


  
  Equipment(){

  //this.dropdown(OBJCreate.equipcategory,"Flatbed");
  //this.dropdown(OBJCreate.equiptypecode,"Hot Shot");
  //this.dropdown(OBJCreate.equiplength,"40 Feet In Length");

  OBJCreate.equipcategory.click();
  OBJCreate.equipcategory.sendkeys("Flatbed");
  OBJCreate.equiptypecode.click();
  OBJCreate.equiptypecode.sendkeys("Hot Shot");
  OBJCreate.equiplength.click();
  OBJCreate.equiplength.sendkeys("40 Feet In Length");



    // OBJCreate.equipmentOptions.click();
                // OBJCreate.equipmentOptionstext.sendkeys("Duct Floor");
                // OBJCreate.freightSecurement.click();
                // OBJCreate.freightSecurementtext.sendkeys("Freeze Protect");
                // OBJCreate.protectionMaterialHandling.click();
                // OBJCreate.protectionMaterialHandlingtext.sendkeys("Flares");
  
  
  }

  dropdown(Objelement:any,strval:string){
  
  
 //var value = BU
  
  Objelement.count().then(function(total) {
  Objelement.each(function (item) {
  var index=0
  if(total > index) {
  var Disp=item.getText().then((elem)=>{ 
  if (elem.trim()===strval)
  {
  item.click();
  browser.sleep(3000);
  // ObjRul.Save_Btn.click();
  // browser.sleep(10000);
  
  }
  else 
  {
  console.log("View drop down is not available with the values");
  }
  });
  }
  })
  });
  }  


async Enteringdata(Testcasename:string) { 
  var TcRow=ReadFromXL.FindRowNum(Testcasename,"CreateOrder");
  
  DataDictLib.pushToDictionaryWithSheet(TcRow,"CreateOrder");
  var BUValue =DataDictLib.getFromDictionary('BU');
  var SOValue =DataDictLib.getFromDictionary('SO');
  var BillToValue =DataDictLib.getFromDictionary('BillTO');
  var OpOwner =DataDictLib.getFromDictionary('OpOwner');
  var TitleCreate =DataDictLib.getFromDictionary('CreateTitle');
  var Trailernumber =DataDictLib.getFromDictionary('Trailernumber');
  var TrailerPrefix =DataDictLib.getFromDictionary('TrailerPrefix');
  //var Scac =DataDictLib.getFromDictionary('scac');
 var Scac:string="HJBTVAN";
  OBJCreate.BillTo.sendKeys(BillToValue);
  browser.sleep(2000); 
  OBJCreate.BillTo.sendKeys(protractor.Key.ENTER);

  OBJCreate.icon_loading.isPresent().then((elem)=>{
    if(elem==true){
                      console.log("Loading icon is present")
    }
    browser.sleep(2000);
  })
  browser.sleep(5000);  
  //OBJCreate.BTContact.click();
 //browser.sleep(2000)
 //OBJCreate.BTContact.sendKeys(protractor.Key.ENTER); 
 browser.executeScript("window.scrollTo(0,100)");
 OBJCreate.BU.click();
 OBJCreate.BUclick.sendKeys(BUValue);
 browser.sleep(2000)
 OBJCreate.BUclick.sendKeys(protractor.Key.ENTER);
  browser.sleep(2000);
  OBJCreate.SO.click();
  OBJCreate.SOclick.sendKeys(SOValue);
 // browser.sleep(2000)
  OBJCreate.SOclick.sendKeys(protractor.Key.ENTER);
  browser.sleep(3000);
  if(Scac!="Null"){
OBJCreate.scac.isPresent().then((elem)=>{ 

          
        if (elem===true){
          OBJCreate.Tradingpartner.click();
          browser.sleep(1000);
          for (let i:number = 0; i < Scac.length; i++) {
            OBJCreate.scac.click();
           // (OBJCreate.scac).clear();
           (OBJCreate.scac).sendKeys(Scac.charAt(i));
          // OBJCreate.scac.se(Scac);
            browser.sleep(3000);
           // element.sendKeys(string.charAt(i));
          }
        }
         

        })
      }
  if(TrailerPrefix!="NULL"){
 this.Trailer("0000000105",TrailerPrefix)
  } 
 if (TitleCreate === "Create New Order") {
  OBJCreate.OPOwner.sendKeys(OpOwner);
  browser.sleep(2000)
  OBJCreate.OPOwner.sendKeys(protractor.Key.ENTER);
 
 } else {
  console.log("Create new template do not contain this field"); 
 }
 if (TitleCreate === "Create New Order") {
 await reuse.getTextValueFromElement(OBJCreate.ordernumber).then((text)=>{ 
  OrderID = text 
  }) ;
  console.log("base order "+OrderID);
  return OrderID 
}
 } 
 Trailer(Trailerno:string,Trailerprefix:string):void { 
      OBJCreate.trailernobutton.click();
      OBJCreate.Trailernumber.sendKeys(Trailerno); 
      browser.sleep(2000);
      OBJCreate.Trailernumber.sendKeys(protractor.Key.TAB);
      browser.sleep(3000);
      OBJCreate.Trailerprefix.click();
      OBJCreate.TrailerPrefixText.sendKeys(Trailerprefix);
      OBJCreate.TrailerPrefixText.sendKeys(protractor.Key.ENTER); 
      browser.sleep(2000)
      }
 
 Freightcharges(charge:string):void { 
      OBJCreate.freightcharges.click();
      OBJCreate.freightchargestext.sendKeys(charge); 
    OBJCreate.freightchargestext.sendKeys(protractor.Key.ENTER);
    } 
    Shipmentdetails(charge:string,ordervalue:string,fleetcode:string):void { 
    OBJCreate.ShipmentIdentificationNo.sendKeys(charge);
    OBJCreate.shipsecndarytype.click(); 
      OBJCreate.shipsecndarytypetext.sendKeys("Will");
      OBJCreate.shipsecndarytypetext.sendKeys(protractor.Key.ENTER);
      OBJCreate.ordervalue.sendKeys(ordervalue);   
      }


      AddstopsOrigin(Testcasename:string,Scheduled:string,Requested:string,pickupdate:string):void
      { 
        OBJCreate.NextButton.click();
        //this.ClickButtonwithText("Next");
        browser.sleep(3000);
        var TcRow=ReadFromXL.FindRowNum(Testcasename,"StopDetails");
        
        DataDictLib.pushToDictionaryWithSheet(TcRow,"StopDetails");
        var Pickup =DataDictLib.getFromDictionary('Pickup');
        var Delivery =DataDictLib.getFromDictionary('Delivery');
        var ItemQty =DataDictLib.getFromDictionary('ItemQty');
        var ItemWt =DataDictLib.getFromDictionary('ItemWt');
        var ItemChar =DataDictLib.getFromDictionary('ItemChar');
        var TitleCreate =DataDictLib.getFromDictionary('CreateTitle');
       
        var NoOfAppoint =DataDictLib.getFromDictionary('NoOfAppoint');
        var NoOfItem =DataDictLib.getFromDictionary('NoOfitems');
        var NoOfStop =DataDictLib.getFromDictionary('Noofstops');
        this.EnterTextBox("locationID",Pickup);
        browser.sleep(2000);
         OBJCreate.BillToValue.click();
         //browser.sleep(4000);
         this.SelectDRopdownValue("Contact");
         browser.sleep(2000);
         if(Requested=="Requested"){
          if(NoOfAppoint==1){
         this.Selectcalendericon(pickupdate,0);
         browser.sleep(2000);
         this.SelectTime("08:00",0);
         browser.sleep(2000);
         this.Selectcalendericon(pickupdate,1);
         browser.sleep(2000);
         this.SelectTime("09:00",1);
         //this.SelectTime("09:00",1);
        browser.sleep(2000);
          }
          if(NoOfAppoint>1){
for(var i=2;i<NoOfAppoint;i++){
console.log(NoOfAppoint+2)
this.Selectcalendericon(pickupdate,i);
browser.sleep(2000);
this.SelectTime("08:00",i);
// browser.sleep(2000);
this.Selectcalendericon(pickupdate,i+1);
browser.sleep(2000);
this.SelectTime("09:00",i+1);
//this.SelectTime("09:00",1);
browser.sleep(2000);
}

          } 
              
         }
         if(Scheduled=="Scheduled"){
          if(NoOfAppoint==1){
        OBJCreate.AddappointmentIcon.get(1).click();
        if (TitleCreate === "Create New Order") {
          OBJCreate.AddappointmentIcon.get(1).click();
          this.Selectcalendericon(pickupdate,2);
          browser.sleep(2000);
          this.SelectTime("08:30",2);
          browser.sleep(2000);
          this.Selectcalendericon(pickupdate,3);
         browser.sleep(2000);
          this.SelectTime("09:30",3);
         browser.sleep(2000);}
         if (TitleCreate === "Create New Template") {
          OBJCreate.AddappointmentIcon.get(0).click();
          this.Selectcalendericon(pickupdate,0);
          browser.sleep(2000);
          this.SelectTime("08:30",0);
          browser.sleep(2000);
          this.Selectcalendericon(pickupdate,1);
         browser.sleep(2000);
          this.SelectTime("09:30",1);
         browser.sleep(2000);}
        }
         if(NoOfAppoint>1){
          for(var i=4;i<=4;i++){
            console.log(NoOfAppoint+2)
            OBJCreate.AddappointmentIcon.get(1).click();
            this.Selectcalendericon(pickupdate,2);
            browser.sleep(2000);
            this.SelectTime("08:00",2);
           // browser.sleep(2000);
            this.Selectcalendericon(pickupdate,3);
           browser.sleep(2000);
            this.SelectTime("09:00",3);
            browser.sleep(4000);
            browser.executeScript("window.scrollTo(0,-100)"); 
            OBJCreate.AddappointmentIcon.get(0).click();
            browser.sleep(4000);
            OBJCreate.AddappointmentIconschedule.click();
            this.Selectcalendericon(pickupdate,i);
            browser.sleep(2000);
            this.SelectTime("09:00",i);
           // browser.sleep(2000);
            this.Selectcalendericon(pickupdate,i+1);
           browser.sleep(2000);
            this.SelectTime("10:00",i+1);
           browser.sleep(2000);
          }
         }
        }
         browser.sleep(6000)
         this.HandlingUnit(Testcasename);
         browser.sleep(3000)
        this.Itemdetails(Testcasename);
         
        var tagname=element(by.css("[formcontrolname=\"itemDescription\"]"));
        tagname.sendKeys(protractor.Key.ENTER);
    
        browser.sleep(5000);
      }

      AppointmentOrigin(Testcasename:string,Scheduled:string,pickupdate:string,Ordername:string){
        var TcRow=ReadFromXL.FindRowNum(Testcasename,"StopDetails");        
        DataDictLib.pushToDictionaryWithSheet(TcRow,"StopDetails");
      var NoOfAppoint =DataDictLib.getFromDictionary('NoOfAppoint');
        var NoOfItem =DataDictLib.getFromDictionary('NoOfitems');
        var NoOfStop =DataDictLib.getFromDictionary('Noofstops');
         if(Scheduled=="Scheduled"){
          if(NoOfAppoint==1){
        OBJCreate.AddappointmentIcon.get(1).click();
        if (Ordername === "Create New Order") {
          OBJCreate.AddappointmentIcon.get(1).click();
          this.Selectcalendericon(pickupdate,2);
          browser.sleep(2000);
          this.SelectTime("08:30",2);
          browser.sleep(2000);
          this.Selectcalendericon(pickupdate,3);
         browser.sleep(2000);
          this.SelectTime("09:30",3);
         browser.sleep(2000);}
         if (Ordername === "Create New Template") {
          OBJCreate.AddappointmentIcon.get(0).click();
          this.Selectcalendericon(pickupdate,0);
          browser.sleep(2000);
          this.SelectTime("08:30",0);
          browser.sleep(2000);
          this.Selectcalendericon(pickupdate,1);
         browser.sleep(2000);
          this.SelectTime("09:30",1);
         browser.sleep(2000);}
        }        
        }      }

AppiontmentDestination(Testcasename:string,Scheduled:string,DeliveryDate:string,Ordername:string,Index:number){
  var TcRow=ReadFromXL.FindRowNum(Testcasename,"StopDetails");        
  DataDictLib.pushToDictionaryWithSheet(TcRow,"StopDetails");
var NoOfAppoint =DataDictLib.getFromDictionary('NoOfAppoint');
  var NoOfItem =DataDictLib.getFromDictionary('NoOfitems');
  var NoOfStop =DataDictLib.getFromDictionary('Noofstops');

  
  if(Scheduled=="Scheduled"){
    
      if (Ordername === "Create New Order") {
        OBJCreate.AddappointmentIcon.get(1).click();
     this.Selectcalendericon(DeliveryDate,Index);
     browser.sleep(2000);
     this.SelectTime("08:30",Index);
    // browser.sleep(2000);
     this.Selectcalendericon(DeliveryDate,(Index+1));
    browser.sleep(2000);
     this.SelectTime("09:30",(Index+1));
    browser.sleep(2000);
    }
    if (Ordername === "Create New Template") {
      OBJCreate.AddappointmentIcon.get(0).click();
      this.Selectcalendericon(DeliveryDate,0);
      browser.sleep(2000);
      this.SelectTime("08:30",0);
      browser.sleep(2000);
      this.Selectcalendericon(DeliveryDate,1);
     browser.sleep(2000);
      this.SelectTime("09:30",1);
     browser.sleep(2000);
    }


  }
}


      HandlingUnit(Testcasename){
        var TcRow=ReadFromXL.FindRowNum(Testcasename,"StopDetails");
        
        DataDictLib.pushToDictionaryWithSheet(TcRow,"StopDetails");
var ItemQty =DataDictLib.getFromDictionary('ItemQty');
var ItemWt =DataDictLib.getFromDictionary('ItemWt');
//OBJCreate.dropdownopt.click();
this.EnterTextBox("itemHandlingTypeQuantity",ItemQty)
browser.sleep(2000);
this.EnterTextBox("itemHandlingUnitWeight",ItemWt);
browser.sleep(2000);       

var Handlingunit=element(by.css("[formcontrolname=\"itemHandlingUnitHeight\"]"));
Handlingunit.sendKeys(protractor.Key.TAB);            
browser.sleep(5000);

}
Itemdetails(Testcasename:string){
  var TcRow=ReadFromXL.FindRowNum(Testcasename,"StopDetails");
  
  DataDictLib.pushToDictionaryWithSheet(TcRow,"StopDetails");
var ItemQty =DataDictLib.getFromDictionary('ItemQty');
var ItemWt =DataDictLib.getFromDictionary('ItemWt');
var ItemChar =DataDictLib.getFromDictionary('ItemChar');
var NoOfItem =DataDictLib.getFromDictionary('NoOfitems');
if(NoOfItem==0){
this.EnterTextBox("packagingUnitTypeQuantity",ItemQty);
this.EnterTextBox("itemWeight",ItemWt);

browser.sleep(5000);
var itemunit=element(by.css("[formcontrolname=\"itemHeight\"]"));
itemunit.sendKeys(protractor.Key.TAB);
browser.sleep(12000);
this.EnterTextBox("itemDescription",ItemChar)
browser.sleep(5000);
var tagname=element(by.css("[formcontrolname=\"itemDescription\"]"));
}
if(NoOfItem>=1){
this.EnterTextBox("packagingUnitTypeQuantity",ItemQty);
this.EnterTextBox("itemWeight",ItemWt);

browser.sleep(5000);
var itemunit=element(by.css("[formcontrolname=\"itemHeight\"]"));
itemunit.sendKeys(protractor.Key.TAB);
browser.sleep(12000);

this.EnterTextBox("itemDescription",ItemChar)
browser.sleep(6000);
var tagname=element(by.css("[formcontrolname=\"itemDescription\"]"));
tagname.sendKeys(protractor.Key.ENTER);
browser.sleep(5000);
(OBJCreate.AddappointmentIcon.get(5)).click();
browser.sleep(5000);
for(var i=1;i<=NoOfItem;i++)
{
  var j =5;

  var AddItem=((j+=2));
console.log((j+=2));
console.log("Console value for j is ",j);
var ItemQtyvalue=(OBJCreate.tagname.get(i));
var ItemWeightValue=(OBJCreate.tagname1.get(i));
var itemunit=(OBJCreate.itemunit.get(i));
var ItemWeightValue=(OBJCreate.tagname1.get(i));
var ItemCharName=(OBJCreate.tagname2.get(i));

var ItemCharFreezeName=(OBJCreate.itemchar.get(i));
var NMFCNumber=(OBJCreate.NMFCNumber.get(i));
ItemQtyvalue.clear();
ItemQtyvalue.sendKeys(ItemQty);

ItemWeightValue.clear();
ItemWeightValue.sendKeys(ItemWt);
browser.sleep(5000);  
itemunit.sendKeys(protractor.Key.TAB);
browser.sleep(5000);
ItemCharName.click();
ItemCharName.sendKeys(protractor.Key.TAB);
NMFCNumber.sendKeys(protractor.Key.TAB);
//ItemCharFreezeName.click();
browser.sleep(3000);
ItemCharName.clear();
ItemCharName.sendKeys(ItemChar);
browser.sleep(5000);
ItemCharName.sendKeys(protractor.Key.ENTER);
browser.sleep(5000);
//var tagname=element(by.css("[formcontrolname=\"itemDescription\"]"));
//ItemCharName.sendKeys(protractor.Key.ENTER);
//browser.sleep(5000);
(OBJCreate.AddappointmentIcon.get(AddItem)).click();
browser.sleep(5000);
}  
}
}
AddstopsDestination(Testcasename:string,Scheduled:string,Requested:string,DeliveryDate):void {
        var TitleCreate =DataDictLib.getFromDictionary('CreateTitle');
        var Delivery =DataDictLib.getFromDictionary('Delivery');
        var pickupdate =DataDictLib.getFromDictionary('Pickup');
        var deliverdate =DataDictLib.getFromDictionary('Delivery');
        var StartTime =DataDictLib.getFromDictionary('PickupDate');
        var endTime =DataDictLib.getFromDictionary('Deliverydate');
                     if (TitleCreate === "Create New Order") {
          OBJCreate.DestinationTab.click();
          browser.sleep(4000);
                        
                     } else {
                           OBJCreate.TemplateDestinationTab.click();
          browser.sleep(7000);
                     }
     
       
        this.EnterTextBox("locationID",Delivery);
        browser.sleep(2000);
        OBJCreate.BillToValue.click();
        browser.sleep(2000);
        this.SelectDRopdownValue("Contact");
        browser.sleep(2000);
        if(Requested=="Requested"){
          this.Selectcalendericon(DeliveryDate,0);
          browser.sleep(2000);
          this.SelectTime("08:00",0);
         // browser.sleep(2000);
          this.Selectcalendericon(DeliveryDate,1);
          browser.sleep(2000);
          this.SelectTime("09:00",1);
          //this.SelectTime("09:00",1);
         browser.sleep(2000);
          }
          if(Scheduled=="Scheduled"){
          
            if (TitleCreate === "Create New Order") {
              OBJCreate.AddappointmentIcon.get(1).click();
           this.Selectcalendericon(DeliveryDate,2);
           browser.sleep(2000);
           this.SelectTime("08:30",2);
          // browser.sleep(2000);
           this.Selectcalendericon(DeliveryDate,3);
          browser.sleep(2000);
           this.SelectTime("09:30",3);
          browser.sleep(2000);
          }
          if (TitleCreate === "Create New Template") {
            OBJCreate.AddappointmentIcon.get(0).click();
            this.Selectcalendericon(pickupdate,0);
            browser.sleep(2000);
            this.SelectTime("08:30",0);
            browser.sleep(2000);
            this.Selectcalendericon(pickupdate,1);
           browser.sleep(2000);
            this.SelectTime("09:30",1);
           browser.sleep(2000);
          }
        
        }
          browser.sleep(3000); 
         // this.DateValidationCreateOrderOverview("01/04/2018","01/05/2018");

                     if (TitleCreate === "Create New Order") {
          OBJCreate.PalletChckBX.isPresent().then((elem)=>{
                              OBJCreate.PalletChckBX.click();
          browser.sleep(2000);})
          //OBJCreate.NextButton.click();
                     } else {
                     OBJCreate.PalletChckBX.isPresent().then((elem)=>{
                          OBJCreate.TemplatePalletChckBX.click();
                          browser.sleep(3000);})
                     }
            
        browser.sleep(4000);
       console.log("End of destination function");
          }

        MultiplePalletCheckbox(Testcasename,Title){
          var DataDictLib1 = new DataDictionary();
          var DataDictLib2 = new DataDictionary();
          var TcRow1=ReadFromXL.FindRowNum(Testcasename,"CreateOrder")
          DataDictLib2.pushToDictionaryWithSheet(TcRow1,"CreateOrder")
          var TcRow=ReadFromXL.FindRowNum(Testcasename,"StopDetails");
          
         DataDictLib1.pushToDictionaryWithSheet(TcRow,"StopDetails");
         var Stopnumber =DataDictLib1.getFromDictionary('StopNumber'); 
          var TitleCreate =DataDictLib2.getFromDictionary('CreateTitle');
          console.log(TitleCreate)
         // var TitleCreate="Create New Order";
          if (TitleCreate === "Create New Order") {
            OBJCreate.AddStopDestinationTab.get(Stopnumber).click();
            browser.sleep(3000);            
            browser.executeScript("window.scrollTo(0,500)");           
            if(Stopnumber>=1)
            {            
              browser.sleep(3000);
              for(var i=1;i<=Stopnumber;i++)
              {             
    browser.executeScript("window.scrollTo(0,500)");
            (OBJCreate.MultiplePalletChckBX.get(i)).click();
                browser.sleep(6000);
               }}             
               }  
        //        else (TitleCreate === "Create New Template") 
        //        {
        //                    OBJCreate.TemplateAddStopDestinationTab.get((Stopnumber)).click();
        //         browser.sleep(3000); 
        //         browser.executeScript("window.scrollTo(0,500)");               
        //         if(Stopnumber>=1)
        //         {
        //           browser.sleep(3000);
        //           for(var i=1;i<=Stopnumber;i++)
        //           {
        // browser.executeScript("window.scrollTo(0,500)");
        //         (OBJCreate.MultiplePalletChckBX.get(i)).click();
        //             browser.sleep(6000);
        //            }}                      
        // }
      }

          AddIntermediateStopDetails(Testcasename:string,Requested:string,Pickupdate:string,StopNumber:number):void
          { 
           // OBJCreate.NextButton.click();
            //this.ClickButtonwithText("Next")            ;
            browser.sleep(5000);
            
            var DataDictLibStop = new DataDictionary();
            var TcRow=ReadFromXL.FindRowNum(Testcasename,"InterStops")
            DataDictLib.pushToDictionaryWithSheet(TcRow,"InterStops")
            var Location =DataDictLib.getFromDictionary('Stop'+StopNumber);
            //var Delivery =DataDictLib.getFromDictionary('Delivery');
            console.log("ItemQty"+StopNumber)
            var ItemQty =DataDictLib.getFromDictionary('ItemQty'+StopNumber);
            var ItemWt =DataDictLib.getFromDictionary('ItemWt'+StopNumber);
            var ItemChar =DataDictLib.getFromDictionary('ItemChar'+StopNumber);
            var TitleCreate =DataDictLib.getFromDictionary('CreateTitle');
            console.log("Console values are as below "+Location,+ItemQty,+ItemWt);
          
            var NoOfAppoint =DataDictLib.getFromDictionary('NoOfAppoint');
            var NoOfItem =DataDictLib.getFromDictionary('NoOfitems');
            var NoOfStop =DataDictLib.getFromDictionary('Noofstops');
            this.EnterTextBox("locationID",Location);
            browser.sleep(3000);
             OBJCreate.BillToValue.click();
             browser.sleep(4000);
             OBJCreate.StopReason.click();
             OBJCreate.StopReasonText.click();
             browser.sleep(3000);
             this.SelectDRopdownValue("Contact");
             browser.sleep(4000);
             if(Requested=="Requested"){
              if(NoOfAppoint==1){
             this.Selectcalendericon(Pickupdate,0);
             browser.sleep(2000);
             this.SelectTime("08:00",0);
            // browser.sleep(2000);
             this.Selectcalendericon(Pickupdate,1);
             browser.sleep(2000);
             this.SelectTime("09:00",1);
             //this.SelectTime("09:00",1);
            browser.sleep(2000);
              }
              if(NoOfAppoint>1){
          for(var i=2;i<NoOfAppoint;i++){
          console.log(NoOfAppoint+2)
          this.Selectcalendericon(Pickupdate,i);
          browser.sleep(2000);
          this.SelectTime("08:00",i);
          // browser.sleep(2000);
          this.Selectcalendericon(Pickupdate,i+1);
          browser.sleep(2000);
          this.SelectTime("09:00",i+1);
          //this.SelectTime("09:00",1);
          browser.sleep(2000);
          }
          
              } 
                  
             }
             if(Requested=="Scheduled"){
              if(NoOfAppoint==1){
            OBJCreate.AddappointmentIcon.get(1).click();
              this.Selectcalendericon(Pickupdate,2);
              browser.sleep(2000);
              this.SelectTime("08:00",2);
             // browser.sleep(2000);
              this.Selectcalendericon(Pickupdate,3);
             browser.sleep(2000);
              this.SelectTime("09:00",3);
             browser.sleep(2000);}
             if(NoOfAppoint>1){
              for(var i=4;i<=4;i++){
                console.log(NoOfAppoint+2)
                OBJCreate.AddappointmentIcon.get(1).click();
                this.Selectcalendericon(Pickupdate,2);
                browser.sleep(2000);
                this.SelectTime("08:00",2);
               // browser.sleep(2000);
                this.Selectcalendericon(Pickupdate,3);
               browser.sleep(2000);
                this.SelectTime("09:00",3);
                browser.sleep(4000);
                browser.executeScript("window.scrollTo(0,-100)"); 
                OBJCreate.AddappointmentIcon.get(0).click();
                browser.sleep(4000);
                OBJCreate.AddappointmentIconschedule.click();
                this.Selectcalendericon(Pickupdate,i);
                browser.sleep(2000);
                this.SelectTime("09:00",i);
               // browser.sleep(2000);
                this.Selectcalendericon(Pickupdate,i+1);
               browser.sleep(2000);
                this.SelectTime("10:00",i+1);
               browser.sleep(2000);
              }
             }
            }
             browser.sleep(3000)
             this.HandlingUnit(Testcasename);
             browser.sleep(3000)
            this.Itemdetails(Testcasename);
             
            var tagname=element(by.css("[formcontrolname=\"itemDescription\"]"));
            tagname.sendKeys(protractor.Key.ENTER);
          
            browser.sleep(15000);
          }
  
  
Selectcalendericon(ApntmntDate:string,calendarvalue:number):void { 
  var datevalue=ApntmntDate.split('/')
 
    var date = datevalue[0];
      var month = datevalue[1];
     var year = datevalue[2];
    // console.log(year);
     var val=(OBJCreate.Calendaricon.get(calendarvalue)).isPresent().then((elem)=>{ 
       if (elem===true){
  browser.sleep(3000)
  var icon=OBJCreate.Calendaricon.get(calendarvalue);
  browser.sleep(4000); 
  icon.click();
   browser.sleep(4000);
  var value=null;
     let dateval: String = value;
  
   let MonthInput:string[] = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"] ;
 
  //console.log(MonthInput.length);
 var j;
  
      for (var i = 0; i < MonthInput.length; i++) {
 //console.log(MonthInput[i]);
       if(month === (MonthInput[i]))
  {
   j=i+1;
   }
      }
      // console.log(j);
    var monthvalue:any=element(by.css("[class=\"headerlabelbtn monthlabel\"]"));
     var yearvalue=element(by.css("[class=\"headerlabelbtn yearlabel\"]"));
       var viewContainer = element(by.css("[class=\"headerlabelbtn monthlabel\"]")).getText();   
      // viewContainer.then(console.log);
       if((monthvalue.getText().then(function(text) {console.log(text); return text === month;}))&&(yearvalue.getText().then(function(text) { console.log(text);return text === year;})))
      {
       browser.sleep(3000);
       var allOptions = element.all(by.xpath("//table[@class='caltable']//tbody//tr//td//div[contains(@class,'datevalue currmonth')]//span"));
 allOptions.filter(function (elem) {
  return elem.getText().then(function (text) {
   return text === date;
     });
      }).first().click(); 
    browser.sleep(4000);
   }    
 
 console.log("Clicking on the calendar icon");
 }
 else{
  console.log("Calendar icon is not available");
    }
       }); 
   
  
 }


      SelectTime(ApntmntTime:string,calendarvalue:number):void { 
 var datevalue=ApntmntTime.split(':')
 
 var hour = datevalue[0];
 var min = datevalue[1];
 OBJCreate.apnmntHR.get(calendarvalue).sendKeys(hour);
 OBJCreate.apnmntMIN.get(calendarvalue).sendKeys(min);   
   
 }
 InternationalShipment():void {                                                                         
  OBJCreate.shipmentreq.click();
  OBJCreate.shipmentreqText.sendKeys("Inter");
  OBJCreate.shipmentreqText.sendKeys(protractor.Key.ENTER);  
  OBJCreate.interservice.click();
  OBJCreate.interservicetext.sendKeys("door");
  OBJCreate.interservicetext.sendKeys(protractor.Key.ENTER);
  //OBJCreate.inbondToggle.click();
  //  OBJCreate.bondholder.click();
 //  OBJCreate.bondholdertext.sendKeys("Door");
 //  OBJCreate.bondholdertext.sendKeys(protractor.Key.ENTER);
 //  OBJCreate.bondholderparty.click();
 //  OBJCreate.bondholderpartytext.sendKeys("Door");
 //  OBJCreate.bondholderpartytext.sendKeys(protractor.Key.ENTER);
 // OBJCreate.bondholderpartytype.click();
 // OBJCreate.bondholderpartytypetext.sendKeys("Immediate Export");
  //OBJCreate.bondholderpartytypetext.sendKeys(protractor.Key.ENTER);
} 

OrderHistory(){
 
  var EC = protractor.ExpectedConditions; 
  browser.wait(EC.visibilityOf(OBJCreate.hstrybtn), 30000).then(function() {
    browser.executeScript("window.scrollTo(0,2000)"); 
    OBJCreate.hstrybtn.click();
    browser.sleep(5000);
  });


 var val=(OBJCreate.hstrytable).isPresent().then((elem)=>{ 
 if (elem===true){
 console.log("Order History is  available");
 OBJCreate.cnt;
 OBJCreate.cnt.count().then((intcnt)=>{ 
 if(intcnt>0){
 console.log("Records count is available" + intcnt);
 }
 else{
 console.log("Records count are not found")
 }
 
 OBJCreate.AcceptanceRulepass.isPresent().then((elem)=>{ 
 if (elem===true)
 {console.log("Acceptance rule is passed");}
 else
 console.log("Acceptance rule is not passed");
 });
 OBJCreate.Orderstatus.isPresent().then((elem)=>{ 
 if (elem===true)
 {console.log("order status is changed from pending to accepted");}
 else
 console.log("order status is not changed from pending to accepted");
 });
 }) }
 
 else{
 console.log("Order History is not available")  
 } 
 })

 
 }
 AdvancedSearchwithdate(Pickupdate:string,DeliveryDate:string,CreatedDate:string):void {  
  // this.NavigatefromDashboard("Advanced Search");     
 // browser.sleep(3000);
  this.ElementWait(true,OBJCreate.allOptions);
   // var allOptions =element.all(by.xpath("//*[@class='inline']//ng-select[@placeholder='Type'][1]"))
    OBJCreate.acceptclose.click();     
 this.Selectcalendericon(Pickupdate,0);
 browser.sleep(2000);
 this.Selectcalendericon(Pickupdate,1);
 browser.sleep(2000);
 this.Selectcalendericon(DeliveryDate,2);
 browser.sleep(2000);
 this.Selectcalendericon(DeliveryDate,3);
 browser.sleep(2000);
 this.Selectcalendericon(CreatedDate,4);
 browser.sleep(2000);
 this.Selectcalendericon(CreatedDate,5);
 browser.sleep(2000);
                       
}
ValidateRateOption(){
  browser.sleep(10000);
  browser.executeScript("window.scrollTo(0,-500)");
  var EC = protractor.ExpectedConditions;  
  browser.wait(EC.visibilityOf(OBJCreate.optiondots.get(0)), 20000).then(function() {
    OBJCreate.optiondots.get(0).click();
   browser.sleep(3000);
  });
  browser.executeScript("window.scrollTo(0,500)");
  OBJCreate.AllInRate.isPresent().then((elem)=>{
    var value=0;
    {
      var Disp= OBJCreate.AllInRate.getText().then((text )=>{        
    if(text.trim()!="0"){
        console.log("All In Rate is available in the rate overview popup");
       }
          })
          }
        });
        OBJCreate.FuelSurcharge.isPresent().then((elem)=>{
          var value=0;
          {
            var Disp= OBJCreate.FuelSurcharge.getText().then((text )=>{
              
          if(text.trim()!="0"){
              console.log("Fuel Surcharge is available in the rate overview popup");
             }
                })
                }
               
              });
              OBJCreate.optiondots.get(0).click();
}

AppointmentValidation(){
  this.ElementValidation(OBJCreate.apnmt_ordovrview);
  this.ElementValidation(OBJCreate.apnmt_stop);
}
ElementValidation(Objelement){
  
        Objelement.isPresent().then((elem)=>{
          if(elem==true)
          {
            Objelement.getText().then((text )=>{
              console.log(text);
              console.log("Appointment details is present in order overview"+ text);
            })
          }
       })};


       ElementValidationAdvancedsearch(AppointmnetDatepickup,appointmentdateDelivery){
        
        OBJCreate.ApntdatepickupAdvanced.isPresent().then((elem)=>{
                if(elem==true)
                {
                  OBJCreate.ApntdatepickupAdvanced.getText().then((text )=>{
                    var date=text.split(" ");
                    var PickupDate=date[0];
                    var pickupTime=date[1];
                   if(PickupDate==AppointmnetDatepickup){
                    console.log("Pickup Appointment details in advanced search is same as the appointment date while creating the order "+ text);
                   }
                                                })
                }
             });
             OBJCreate.ApntdatedeliveryAdvanced.isPresent().then((elem)=>{
              if(elem==true)
              {
                OBJCreate.ApntdatedeliveryAdvanced.getText().then((text )=>{
                  var date=text.split(" ");
                  var PickupDate=date[0];
                  var pickupTime=date[1];
                 if(PickupDate==appointmentdateDelivery){
                  console.log("Delivery Appointment details in advanced search is same as the appointment date while creating the order "+ text);
                 }
                                              })
              }
           });
            }
            DateValidationCreateOrderOverview(AppointmnetDatepickup,appointmentdateDelivery){
              
              OBJCreate.PickDateorderOverview.isPresent().then((elem)=>{
                      if(elem==true)
                      {
                        OBJCreate.PickDateorderOverview.getText().then((text )=>{
                        var date=text.split(" ");
                        var PickupDate=date[0];
                        var pickupTime=date[1];
                         if(PickupDate==AppointmnetDatepickup){
                          console.log("Pickup Appointment details and Time zone in Order overview  is same as the appointment date while creating the order "+ text);
                         }
                                                      })
                      }
                    });
                   OBJCreate.DelidateorderOverview.isPresent().then((elem)=>{
                    if(elem==true)
                    {
                      OBJCreate.DelidateorderOverview.getText().then((text )=>{
                        var date=text.split(" ");
                        var Deliverydate=date[0];
                        var DeliveryTime=date[1];
                       if(Deliverydate==appointmentdateDelivery){
                        console.log("Delivery Appointment details and Time Zone in Order overview is same as the appointment date while creating the order "+ text);
                       }
                                                    })
                    }
                 });
                  }
      



async TemplateSearch(Testcasename:string){
  
     var scac =DataDictLib.getFromDictionary('scac');
     var sO =DataDictLib.getFromDictionary('SO');
       OBJCreate.template_filter.click();
       OBJCreate.scacsearch.click();
       OBJCreate.scactext.click();
       browser.sleep(2000);
       OBJCreate.scactext.sendKeys(scac);
            browser.sleep(5000);
       OBJCreate.scacenter.click();
      //  OBJCreate.scactext.sendKeys(protractor.Key.ENTER)
       browser.executeScript("window.scrollBy(0,-500)")
       if(sO==="OTR"){
       OBJCreate.three_dotOtr.get(0).click();
       }
       if(sO==="Intermodal")
       {
        OBJCreate.three_dotInter.get(0).click();
       }
       if(sO==="LTL")
       {
        OBJCreate.three_dotLTL.get(0).click();
       }
       OBJCreate.ViewTemplate.click();
       //this.dropdown(OBJCreate.copy_view,"View Template");
       browser.sleep(6000);
       OBJCreate.threedot_temp.click();
       OBJCreate.tempdrop.click();
       // this.dropdown(OBJCreate.tempdrop,"Create Order");
        browser.sleep(25000);
       this.ElementWait(true,OBJCreate.ordernumber);
   
     await reuse.getTextValueFromElement(OBJCreate.ordernumber).then((text)=>{ 
      OrderID = text 
      }) ;
      console.log("base order "+OrderID);
      return OrderID 

 }
 async ElementWait(elemValCheck:boolean, OBJelem) 
 {
   
   
    
   var cntr:number = 0
   var displayvalue:boolean=false;
   var textvalue:any="";
   var value:boolean = false ;
   while(value === false)
   {
     browser.sleep(3000);
 
     await OBJelem.isPresent().then((elem)=>{
       console.log(cntr+"th time");
       displayvalue = elem;
       console.log("1st scope" + displayvalue);
     });
     browser.sleep(3000);
     if (elemValCheck==true && displayvalue.valueOf()=== true){
       console.log(" entering into text validation")
     await OBJelem.getText().then((elem1)=>{
 console.log(cntr+"th time");
 
 textvalue = elem1 ;
 console.log("2nd scope" + textvalue);
 });}
 
 if(cntr>12){
  break;
  }
  if (elemValCheck==true)
  {
    if(textvalue !== "")
      value = displayvalue
    else
      value = false
  }
 
  else
    value = displayvalue;
 
  console.log(value);
  cntr++;
 
       }
     }

     HazmatDetails(){
       var Item =DataDictLib.getFromDictionary('HAZMAT')
       var UNNA=DataDictLib.getFromDictionary('UNNA');
       var UNNAval=DataDictLib.getFromDictionary('UNNAval');
       var shippingname =DataDictLib.getFromDictionary('Hazmatshippingname');
      console.log("Entered Hazmat")
      // this.ElementWait(true,OBJCreate.stopbox);
      //this.hazmatdropdowns("Item Characteristics","Haazmat")
      browser.sleep(6000);
      OBJCreate.itemcharname.click();
      
      browser.sleep(3000);
      OBJCreate.itemchar_type.sendKeys(Item);
      OBJCreate.itemchar_type.sendKeys(protractor.Key.SPACE);
      OBJCreate.itemchar_type.sendKeys(protractor.Key.ENTER);
      browser.sleep(3000);
      
      OBJCreate.unnacode.click();
      OBJCreate.unnacode.sendKeys(UNNAval);
      OBJCreate.unnacode.sendKeys(protractor.Key.ENTER);
      //this.hazmatdropdowns("Proper Shipping Name","-Butyl chloroformate")
      OBJCreate.shippingname.click();
      OBJCreate.shippingname.sendKeys(shippingname);
      OBJCreate.shippingname.sendKeys(protractor.Key.ENTER);
      OBJCreate.primary.click();
      OBJCreate.primary.sendKeys(protractor.Key.TAB);
      OBJCreate.primary.sendKeys(protractor.Key.ENTER);
    
    
      //this.hazmatdropdowns("Secondary Hazard Class","");
      OBJCreate.secondary.click();
      OBJCreate.secondary.sendKeys(protractor.Key.TAB);
      OBJCreate.secondary.sendKeys(protractor.Key.ENTER);
    
     }


     


     ClickRateoption(Testcasename:string,Rownumber:number):void { 
      
     
       browser.sleep(5000);
       browser.executeScript("window.scrollTo(0,500)");
       var EC = protractor.ExpectedConditions;  
      // browser.wait(EC.visibilityOf(OBJCreate.optiondots.get(Rownumber)), 20000).then(function() {
        browser.executeScript("window.scrollTo(0,-500)");
        browser.sleep(2000);
         // browser.actions().mouseMove( OBJCreate.Overideall)
          //OBJCreate.Overideall.click();
       //browser.executeScript("window.scrollTo(0,-500)");
      ( OBJCreate.optiondots).get(Rownumber).click();
       browser.sleep(3000);
       //});
       browser.executeScript("window.scrollTo(0,500)");
      //  OBJCreate.AllInRate.isPresent().then((elem)=>{
      //   var value=0;
      //   {
      //     var Disp= OBJCreate.AllInRate.getText().then((text )=>{        
      //   if(text.trim()!="0"){
      //       console.log("All In Rate is available in the rate overview popup");
      //      }
      //         })
      //         }
      //       });
      //       OBJCreate.FuelSurcharge.isPresent().then((elem)=>{
      //         var value=0;
      //         {
      //           var Disp= OBJCreate.FuelSurcharge.getText().then((text )=>{
                  
      //         if(text.trim()!="0"){
      //             console.log("Fuel Surcharge is available in the rate overview popup");
      //            }
      //               })
      //               }                   
      //             });
       
       var val=(OBJCreate.CreateButtonOverview).isDisplayed().then((elem)=>{ 
         if (elem===true){
           browser.sleep(2000)
        
          OBJCreate.CreateButtonOverview.click();
        
          console.log("Create button is clicked for the available rate");
          }
          else{
           console.log("Create button is not clicked for the available rate");
                    }
         }); 
         
         var val=(OBJCreate.Overideall).isDisplayed().then((elem)=>{ 
           if (elem===true){
            // element(by.id("billtoaccount")).sendKeys("CACAB9")
            browser.sleep(3000);
         browser.executeScript("window.scrollTo(0,-500)");
         browser.sleep(2000);
           browser.actions().mouseMove( OBJCreate.Overideall)
            OBJCreate.Overideall.click();
            browser.sleep(2000);
            console.log("Warnings are overidden successfully");
            }
            else{
             console.log("Create opportunity is not displayed in the shipping options Flow menu");
                      }
           }); 
  
     var index = 0;
     OBJCreate.errorparent.count().then(function(total) {
       OBJCreate.errorparent.each(function (item) {
        index++;
        if(total >= index) {
         
         (OBJCreate.errorparent).get(0).isDisplayed().then((element)=>{ 
           if (element===true){
    
             var EC = protractor.ExpectedConditions;    
             browser.wait(EC.visibilityOf(OBJCreate.errorlink), 3000).then(function() {
               OBJCreate.errorlink.click();
               (OBJCreate.errorDropdownClick).isPresent().then(function(bool){
                 if(bool===true)
                 {
                  OBJCreate.errorDropdownClick.click();
                   OBJCreate.errordropDown.click();
                   OBJCreate.OverideErrorButton.click();
                   browser.sleep(2000);
                 // OBJCreate.errorlinkname.sendKeys(protractor.Key.ENTER);
                 }});
              (OBJCreate.errorlinkname).isPresent().then(function(bool){
           if(bool===true)
           {
             OBJCreate.errorlinkname.sendKeys("Keerthana Selvaraj");
             browser.sleep(2000);
            OBJCreate.errorlinkname.sendKeys(protractor.Key.ENTER);
           }});
           (OBJCreate.errorlinkCmnt).isPresent().then(function(bool){
             if(bool===true)
             {
               OBJCreate.errorlinkCmnt.sendKeys("Test");
               OBJCreate.OverideErrorButton.click();
               browser.sleep(2000);
               console.log("The errors and warnings are overriden successfully");
             }}) ; 
               });
             }
           });
        }else 
          console.log("No errors are available")
        });
      });
    
                     browser.executeScript("window.scrollTo(0,500)"); 
                     browser.sleep(3000);
                    // OBJCreate.CreateButton.click();
                    // browser.sleep(12000);
                         
    
 
   }


   AdvancedSearchforOrder(OrderNo:number,PickupDate,Deliverydate,OrderStatus:string) {  
    // this.NavigatefromDashboard("Advanced Search");     
   // browser.sleep(3000);
    this.ElementWait(true,OBJCreate.allOptions);
     // var allOptions =element.all(by.xpath("//*[@class='inline']//ng-select[@placeholder='Type'][1]"))
      OBJCreate.acceptclose.click();     
    OBJCreate.Showmore.click();  
    browser.executeScript("window.scrollTo(0,-200)");        
    browser.sleep(2000);
    //OBJCreate.Statuschange.sendKeys(OrderStatus);
    //OBJCreate.Statuschange.sendKeys(protractor.Key.ENTER);
          browser.executeScript("window.scrollTo(0,200)");           
          OBJCreate.Destin.click();
   // OBJCreate.ordertype.click();
   // browser.executeScript("window.scrollTo(0,200)"); 
   OBJCreate.allOptions.get(2).click();   
        var ind=0
        OBJCreate.allOptions.count().then(function(total) {      
        OBJCreate.allOptions.each(function (item) {    
        ind++
       if(ind==2) { 
         console.log("index no is"+ind)         
           item.sendKeys("order number");
           browser.sleep(2000); 
           item.sendKeys(protractor.Key.TAB);
           item.sendKeys(protractor.Key.TAB);
           item.sendKeys(protractor.Key.TAB);
           item.sendKeys(protractor.Key.ENTER);        
           
       }else 
         console.log("View drop down is not available with the values");
       });
      
     });
  
    var ind1=0
    browser.sleep(2000);

    OBJCreate.orderno.count().then(function(total) {            
      OBJCreate.orderno.each(function (item) {  
        console.log(ind1) 
        ind1++      
       if(ind1==3) {          
           item.sendKeys(OrderNo);
           browser.sleep(2000);            
       }else 
         console.log("View drop down is not available with the values");
       });
     });
    OBJCreate.SearchButton.click();    
    browser.executeScript("window.scrollTo(0,-200)");
    this.ElementValidationAdvancedsearch(PickupDate,Deliverydate);
    OBJCreate.SelectFirstorder.get(0).click(); 
var viewpage=element(by.xpath("//span[text()='Order']"));
this.ElementWait(true,viewpage);
  }

  utilities(utilityoption,option):void{ 
    browser.executeScript("window.scrollTo(0,-500)"); 
      OBJCreate.Utilitiesicon.click();
      browser.sleep(2000);
     
switch(utilityoption) { 
case "Comment": { 
//OBJCreate.Utilitiesicon.click();
//OBJCreate.Utilitiesicon.click();
OBJCreate.toollist.get(0).click();
OBJCreate.addComment.click();
OBJCreate.addCommenttext.sendKeys(protractor.Key.ENTER);  
browser.sleep(2000);
OBJCreate.addCommenttext.sendKeys("Ap");
OBJCreate.addCommenttext.sendKeys(protractor.Key.ENTER);  
browser.sleep(2000);
OBJCreate.templateType.click()
//OBJCreate.templatetypetext.sendKeys("Apppoin");
OBJCreate.templatetypetext.sendKeys(protractor.Key.ENTER);
OBJCreate.Commenttext.clear();
OBJCreate.Commenttext.sendKeys("Test");
browser.sleep(1000);
OBJCreate.Commenttext.sendKeys(protractor.Key.TAB);
//browser.executeScript("window.scrollTo(0,-500)"); 
(OBJCreate.Savebuttonreject.get(0)).sendKeys(protractor.Key.ENTER);
browser.sleep(2000);
OBJCreate.addedutilityref.click();
var EC = protractor.ExpectedConditions; 
browser.wait(EC.visibilityOf(OBJCreate.apntEditcmnt), 5000).then(function() {
console.log("Edit or Delete option is available ")
if(option=="Edit")
{
OBJCreate.utilityedit.click();
}
if(option=="Delete")
{
OBJCreate.utilityDelete.click(); 
}
});
OBJCreate.Utilitiesicon.click();
break; 
} 
case "Documents": { 
OBJCreate.toollist.get(1).click();
break; 
} 
case "Reference": { 
  //OBJCreate.Utilitiesicon.click();
  // OBJCreate.Utilitiesicon.click();
  OBJCreate.toollist.get(2).click();
  browser.sleep(3000);
  OBJCreate.ReferenceType.click();
  OBJCreate.Refercmnt.sendKeys("Test");
  browser.sleep(3000);  
  OBJCreate.Addbutton.get(1).click();  
  browser.sleep(5000);  
  OBJCreate.apntEditRef.click();
  //browser.executeScript("window.scrollBy(0,-3000)"); 
  //browser.executeScript("window.scrollTo(0,-500)"); 
  //OBJCreate.toollist.get(2).click();
  browser.executeScript("window.scrollBy(0,-5000)");
  var EC = protractor.ExpectedConditions; 
  browser.wait(EC.visibilityOf(OBJCreate.apntEditRef),5000).then(function() {
  console.log("Edit or Delete option is available ")
  if(option=="Edit")
  {
  OBJCreate.UtilrefEdit.click();
  OBJCreate.ReferenceType1.click();
  OBJCreate.Refercmnt.sendKeys("123456");
  
  browser.sleep(3000);
  OBJCreate.savebutton1.click();
    }
  if(option=="Delete")
  {
  OBJCreate.Utilrefdelete.click(); 
  }
  
  });
  OBJCreate.Utilitiesicon.click();
  break; 
} 
  
case "Instruction": { 
OBJCreate.toollist.get(3).click();
break; 
} 
case "Charge": { 
  OBJCreate.toollist.get(3).click();
  (OBJCreate.toollist.get(3)).sendKeys(protractor.Key.TAB);
OBJCreate.toollist.get(4).click();
OBJCreate.Chargelevel.click();
browser.sleep(2000);
OBJCreate.chargeamount.clear();
OBJCreate.chargeamount.sendKeys("10");
OBJCreate.chargequantity.clear();
OBJCreate.chargequantity.sendKeys("15");
OBJCreate.chargecode.sendKeys("DEAD");
//OBJCreate.chargecode.sendKeys(protractor.Key.SPACE);
OBJCreate.chargecode.sendKeys(protractor.Key.BACK_SPACE);
OBJCreate.chargecode.sendKeys(protractor.Key.BACK_SPACE);
browser.sleep(2000);
OBJCreate.chargecode.sendKeys("A");
browser.sleep(2000);
OBJCreate.BillToValue.click();
browser.sleep(2000);
OBJCreate.authno.sendKeys("12369");
OBJCreate.authby.sendKeys("keerthana");
//  browser.executeScript("window.scrollTo(0,50)");
OBJCreate.authby.sendKeys(protractor.Key.TAB);
OBJCreate.Addbuttoncharge.get(2).click();
browser.sleep(2000);
OBJCreate.UtilEditCharge.click();
var EC = protractor.ExpectedConditions; 
browser.wait(EC.visibilityOf(OBJCreate.UtilEditCharge),3000).then(function() {
console.log("Edit or Delete option is available ")
if(option=="Edit")
{
OBJCreate.UtilChargeEdit.click();
OBJCreate.ReferenceType1.click();
OBJCreate.Refercmnt.sendKeys("123456");
//browser.executeScript("window.scrollTo(0,300)");
browser.sleep(3000);

OBJCreate.savebutton1.click();
  }
if(option=="Delete")
{
  browser.sleep(1000);
OBJCreate.Utilchargedelete.click(); 
}
});
OBJCreate.Utilitiesicon.click();
break; 
} 

}   }
ClickButtonwithText(buttonText) 
{
  OBJCreate.Buttontext.count().then(function(total) {
    OBJCreate.Buttontext.each(function (item) {
        var index=0
        index++;
        if(total > index) {
            var Disp=item.getText().then((elem)=>{ 
            if (elem.trim()===buttonText)
            {
                item.click();
                browser.sleep(8000);                                            
            }
                  });
            }
        })
    });
      
    }

    EditStops(){
      OBJCreate.originstopedit.click();
      OBJCreate.editbtn.click();
      OBJCreate.requestedservices.click();
      OBJCreate.requestedservices.sendKeys("Pickup Trailer");
      OBJCreate.requestedservices.sendKeys(protractor.Key.ENTER);
    }

    TotalMilesCreateOrderOverview(OBJElement){
      OBJElement.isPresent().then((elem)=>{
      var value=0;
      {
      var Disp= OBJElement.getText().then((text )=>{
      if(text.trim()!="0"){
      console.log("Total miles is displayed for the order "+ text);
      }
      })
      }
      });
      } 
      addmultiplestops(Testcasename,stopreason):void {  
        var TcRow=ReadFromXL.FindRowNum(Testcasename,"StopDetails")
        DataDictLib.pushToDictionaryWithSheet(TcRow,"StopDetails")
        var TcRow=ReadFromXL.FindRowNum(Testcasename,"CreateOrder")
        DataDictLib1.pushToDictionaryWithSheet(TcRow,"CreateOrder")
        var Pickup =DataDictLib.getFromDictionary('Pickup');  
        var Stopnumber =DataDictLib.getFromDictionary('StopNumber'); 
        var TitleCreate =DataDictLib1.getFromDictionary('CreateTitle');
        browser.executeScript("window.scrollTo(0,-500)");
       //var TitleCreate="Create New order"
        if(Stopnumber>=1)
        {
         
          browser.sleep(3000);
         
browser.executeScript("window.scrollTo(0,-500)");
if(TitleCreate=="Create New Order"){
  for(var i=1;i<=Stopnumber;i++)
  {
        OBJCreate.expandicon.get(0).click();
            browser.sleep(7000);
            OBJCreate.stopdots.click();
            OBJCreate.addstop.click();
            browser.sleep(5000);
            this.AddIntermediateStopDetails(Testcasename,"NULL","29/Dec/2017",i);
            browser.sleep(7000);
  }
}
else(TitleCreate=="Create New Template")
{
  for(var i=1;i<=Stopnumber;i++)
  {
  OBJCreate.expandiconTemplate.get(0).click();
  browser.sleep(5000);
  OBJCreate.stopdotstemplate.click();
  OBJCreate.addstop.click();
  browser.sleep(5000);
  OBJCreate.expandiconTemplate.get(1).click();
  browser.sleep(5000);
this.AddIntermediateStopDetails(Testcasename,"NULL","29/Dec/2017",i);
browser.sleep(7000);
}
               
          }
  
    }
     } 
    
     OrderHistoryWarningsoverride(){
      
      OBJCreate.hstrybtn.click();
                      browser.sleep(5000);
                      var val=(OBJCreate.hstrytable).isPresent().then((elem)=>{ 
                      if (elem===true){
                             console.log("Order History is  available");
                             OBJCreate.cnt;
                             OBJCreate.cnt.count().then((intcnt)=>{ 
                              if(intcnt>0){
                                      console.log("Records count is available" + intcnt);
                              }
                              else{
                                      console.log("Records count are not found")
                              }
                             
                              OBJCreate.WarningsOveridden.isPresent().then((elem)=>{ 
                                  if (elem===true)
                                  {console.log("Credit Check Failure warning is displayed");}
                                  else
                                  console.log("Credit Check Failure warning is not displayed");
                              });
                            
                      }) }
      
                      else{
                              console.log("Order History is not available")              
                              }       
                        })

                  
      }
    
      SelectFirstorder(){
        
         
          OBJCreate.SelectFirstorder.get(0).click(); 
          browser.sleep(4000);
        var viewpage=element(by.xpath("//span[text()='Order']"));
       // this.ElementWait(true,viewpage);
        }

        RateSheet(){
          
              this.ElementWait(true,OBJCreate.Rulename);
              browser.executeScript("window.scrollTo(0,200)");
              browser.sleep(5000)
              OBJCreate.ratesheet.click();
              this.ElementWait(true,OBJCreate.rate_level);
              OBJCreate.rate_edit.isPresent().then((elem:any)=>{ 
                  if(elem === true)
                  {
                  console.log("edit button is present");
                  OBJCreate.rate_edit.click();
                  }
                  else{
                      console.log("edit button is not present");
          
                  }
                                                          });
                                                      }
CreateWithoutRate(){

OBJCreate.ShippingFlowMenu.click();
var val=(OBJCreate.CreateWithoutrTE).isDisplayed().then((elem)=>{ 
if (elem===true){
// element(by.id("billtoaccount")).sendKeys("CACAB9")
OBJCreate.CreateWithoutrTE.click();
console.log("Create without Rate is clicked from the dropdown");
}
else{
console.log("Create without Rate is not displayed in the shipping options Flow menu");
}
});     
OBJCreate.RateReason.click();
this.ClickButtonwithText("Create");
browser.sleep(12000);
}   

Overrideall(){
  
    OBJCreate.warningMsg.isPresent().then((elem)=>{
      var value=0;
      {
        var Disp= OBJCreate.warningMsg.getText().then((text )=>{
          
      if(text.trim()=="Customer credit status is CREDIT HLD."){
          console.log("Credit check failure is displayed as warning "+ text);
         }
                                            })
            }
          });
          OBJCreate.Overidewarning.isPresent().then((elem)=>{
            browser.sleep(2000);
          OBJCreate.Overidewarning.click();
          browser.sleep(10000);
          });
  
  }
   
  
  CCI_AccountSearch(CreditStatus:string){
  
    OBJCreate.CCi_Search.sendKeys("WABE10 ")
    OBJCreate.CCi_Search.sendKeys(protractor.Key.ENTER);
    OBJCreate.SelectFirstResult.click();
    OBJCreate.Credittab.click();
    OBJCreate.CreditStatusEditIcon.click();
    OBJCreate.CreditSelectClick.click();
    OBJCreate.CreditStatusEditIcon.click();
    OBJCreate.CreditSelectClick.click();
    if(CreditStatus=="Approved"){
    OBJCreate.CreditApproved.click();}
    if(CreditStatus=="Denied"){
      OBJCreate.CreditDenied.click();}
      OBJCreate.CreditScore.sendKeys("45")
      this.ClickButtonwithText("Save");  
  }
  RejectOrder(){
    OBJCreate.OrderFlowMenu.click();
    OBJCreate.RejectOrder.click();
    browser.sleep(2000);
    OBJCreate.RejectReason.click();
    OBJCreate.RejectReason.sendKeys("No Capacity");
    OBJCreate.RejectReason.sendKeys(protractor.Key.ENTER);
    OBJCreate.RejectComments.sendKeys("Test");
    browser.sleep(2000);
    //this.ClickButtonwithText("Save");
    OBJCreate.Savebuttonreject.get(3).click();
    browser.sleep(3000);
    }
    AlternateLogin(){
      
      OBJCreate.username.click()
      OBJCreate.username.sendKeys("rcon996");
      OBJCreate.password.click();
      OBJCreate.password.sendKeys("jb8462");
      OBJCreate.loginbutton.click();
      browser.sleep(5000);
      } 
      RoutePlan(ViewValue:string):void { 
        browser.sleep(5000)
        browser.executeScript("window.scrollTo(0,200)");
        browser.sleep(3000)
        var EC = protractor.ExpectedConditions;  
        //browser.wait(EC.visibilityOf(OBJCreate.optiondots.get(Rownumber)), 20000).then(function() {
     OBJCreate.Routeplan.click();
    browser.executeScript("window.scrollTo(0,-200)");
    try{
   browser.wait(EC.visibilityOf(OBJCreate.load), 5000).then(function() {
   
    OBJCreate.load.getText().then((elem:any)=>{ 
        if (elem!="")
        console.log("Load id is generated for the order"+ elem);
        });
      
  });
}
  catch{

    console.log("Load id is not generated for the order");

  }
    
                           } 

                           async FetchDatafromOM(){
                            
                                  var BUval;
                                  var billto;
                                  var totalmile;
                                  // var DictServicelvl_OM= new DataDictionary();
                                  // var DictTotalmile=new DataDictionary();
                                  
                                  
                                  
                                  await reuse.getTextValueFromElement(OBJCreate.BUval).then((text)=>{          
                                    BUval = text 
                                   BUval= BUval.replace(" -","");
                                  }) ;
                                 // console.log(BUval);
                            
                                  await reuse.getTextValueFromElement(OBJCreate.Billtoval).then((text)=>{          
                                    billto = text
                                            
                                  }) ;
                            
                                  billto.split('(')
                                  
                                  var billtocode = billto[1];
                            
                                  billtocode.split(')');
                                  var BillTo = billtocode[0];
                                  
                            
                                  //console.log(BillTo);
                                  await reuse.getTextValueFromElement(OBJCreate.totalmiles).then((text)=>{          
                                    totalmile = text 
                                  }) ;
                                 // console.log(totalmile);
                                  
                            
                            
                                  DictBU_OM["BusUnit"] = BUval;
                                  DictBU_OM["Billto"]= BillTo;
                                  DictBU_OM["totalmile"] = totalmile;
                                 
                            
                                  return DictBU_OM;
                            
                                 }
                            
                                 async FetchDatafromEOM(){
                            
                                  
                                  var BU;
                                   var BillTO;
                                  var mile;
                            
                                  await reuse.getTextValueFromElement(OBJCreate.BUdivision).then((text)=>{          
                                    BU = text 
                                  }) ;
                                  console.log("Inside function" + BU);
                            
                                  // await reuse.getTextValueFromElement(OBJCreate.Billtovaleom).then((text)=>{
                                  //   Billto = text 
                                  // }) ;
                                 
                                 await  OBJCreate.Billtovaleom.getAttribute("value").then((text)=>{          
                                    BillTO = text 
                                 }) ;
                                 
                                  console.log("Inside function" + BillTO);
                                  
                                  await reuse.getTextValueFromElement(OBJCreate.mileeom).then((text)=>{
                                    mile = text  
                                  }) ;
                                  console.log("Inside function" + mile);
                            
                                  DictBU_EOM["BusUnit"] = BU;
                                  DictBU_EOM["Billto"] = BillTO;
                                  DictBU_EOM["totalmile"] = mile;
                            
                                  return DictBU_EOM
                            
                                 }
                            
                                 NavigateEOM(){
                            
                                  OBJCreate.Loadid.click();
                                  OBJCreate.Loadid.sendKeys("KJ13693");
                                  OBJCreate.Loadid.sendKeys(protractor.Key.ENTER);
                                  browser.sleep(3000);
                                  OBJCreate.loadlink.click();
                                  browser.sleep(3000);
                            
                                  OBJCreate.loaddetail.click();
                                  browser.sleep(3000);
                                  OBJCreate.stopdetails.click();
                                  browser.sleep(3000);
                            
                                
                            
                                 }
                                 
                                 
                            CompareValues(Testcasename,DictBU_OM:DataDictionary,DictBU_EOM:DataDictionary)
                                 {
                            
                                  var OMvals =DataDictLib.getFromDictionary('OMvalues');
                                      var i=0;
                            
                                      console.log("excel values" + OMvals);
                                      var OMpagevalues:string[] = OMvals.split(',');
                            
                                    //   var highvalue= Math.max(OMvals);
                                    //   console.log(highvalue);
                            
                                    for(i=0;i<OMpagevalues.length;i++)
                                    {
                                      if (OMpagevalues[i] == "BusUnit" )
                                      {
                                      console.log("Entering into Businees Value Comparison")
                                        
                                        
                                          var BUnit = DictBU_OM [OMpagevalues[i]];
                                          console.log(BUnit);
                                          var TcRow=ReadFromXL.FindRowNum(Testcasename,"CreateOrder");
                                          
                                          var fleetcode = DataDictLib.getFromDictionary(BUnit + "_fleetcode");
                                          console.log(fleetcode);
                            
                                        if (fleetcode == DictBU_EOM[OMpagevalues[i]])
                                        {
                                          console.log("Business unit is same")
                                        }
                                        else
                                        {
                                          console.log("Business unit is not matching"+ DictBU_EOM[BUnit])
                                        }
                            
                                        
                                      }
                                    
                                        else if (DictBU_OM[OMpagevalues[i]] == DictBU_EOM[OMpagevalues[i]])
                                        {
                                             console.log('Values are same')
                            
                                             
                                            } 
                                            else 
                                            {
                            
                                              console.log("Comparison is failed" + DictBU_EOM[OMpagevalues[i]])
                                            }
                                          
                                        }
                                 }
                            
                                 SearchTemplate(Billto:string):void { 
                                  
                                 OBJCreate.Billtosearch.sendKeys(Billto);
                                 browser.sleep(3000);
                                 OBJCreate.Billtosearch.sendKeys(protractor.Key.ENTER);
                                  browser.sleep(3000);
                                  
                                  OBJCreate.SearchIcon.click();
                                  browser.sleep(4000);
                                  //this.ElementWait(true,OBJCreate.TempalteDots);                                                                                                                
                                   }
                                   TONU():void { 
                                    
                                    OBJCreate.WithoutapptmntRadio.click();
                
                                    OBJCreate.Comment.sendKeys("Test");
                                    OBJCreate.Processbutton.click();
                                    browser.sleep(6000); 
                                    OBJCreate.GotItbutton.click();
                                    browser.sleep(3000) 
                
                                                       }

}
      
      
      
      
      

 
      
























