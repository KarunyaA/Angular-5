import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";

import {commonFunctions} from "../PageFiles/Regression";
let ORDRegression  = new commonFunctions;
import {Update_Objects} from "../ObjectRepository/Objects_Order"
import { async } from "q";


let ORDRegobject=new Update_Objects();
import {ExcelReader} from "../CommonFiles/ReadFromXL"
var ReadFromXL = new ExcelReader();
import {DataDictionary} from "../DataFiles/DictionaryData";

var DataDictLib = new DataDictionary();
var path = require('path'); 
var filename = path.basename(__filename);
var Testcase=path.parse(filename).name
var TcRow=ReadFromXL.FindRowNum(Testcase,"CreateOrder");
DataDictLib.pushToDictionaryWithSheet(TcRow,"CreateOrder");
var NavIdValue =DataDictLib.getFromDictionary('NavIdValue');
var rownumber =DataDictLib.getFromDictionary('Rateoption');
var Navigationvalue =DataDictLib.getFromDictionary('CreateTitle');


describe("OM_R1ST_MOC_TC014", () => { // suite in Jasmine
  it("Navigate to Create order page",() => {
  
    ORDRegression.Get_url(Testcase);
    ORDRegression.SignIn(Testcase);
    browser.sleep(5000);
    ORDRegression.NavigationFunction("Create New Order",Testcase);
  })
 
  it("Adding origin stop details",() => {
    ORDRegression.Enteringdata(Testcase);
    browser.sleep(5000);
    ORDRegression.AddstopsOrigin(Testcase,"NULL","NULL","08/Feb/2018");
    ORDRegression.AddstopsDestination(Testcase,"NULL","Null","08/Feb/2018");
    ORDRegression.ClickButtonwithText("Next");
   browser.sleep(60000);
   //browser.executeScript("window.scrollTo(0,-500)");
    ORDRegression.ClickRateoption(Testcase,rownumber);
    ORDRegression.ClickButtonwithText("Create")
    browser.sleep(40000);
    browser.executeScript("window.scrollTo(0,2000)"); 
   // ORDRegression.OrderHistory();
   ORDRegression.RoutePlan(Testcase);
  })
 

    
})



