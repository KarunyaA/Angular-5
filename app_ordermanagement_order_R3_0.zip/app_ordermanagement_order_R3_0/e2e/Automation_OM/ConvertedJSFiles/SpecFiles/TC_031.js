"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const protractor_1 = require("protractor");
const Regression_1 = require("../PageFiles/Regression");
let ORDRegression = new Regression_1.commonFunctions;
const ReadFromXL_1 = require("../CommonFiles/ReadFromXL");
var ReadFromXL = new ReadFromXL_1.ExcelReader();
const DictionaryData_1 = require("../DataFiles/DictionaryData");
var DataDictLib = new DictionaryData_1.DataDictionary();
const Objects_Order_1 = require("../ObjectRepository/Objects_Order");
let ORDRegobject = new Objects_Order_1.Update_Objects;
var path = require('path');
var filename = path.basename(__filename);
var Testcase = path.parse(filename).name;
describe("TC_031", () => {
    it("Should Have a Title To be Verified", () => __awaiter(this, void 0, void 0, function* () {
        var TcRow = ReadFromXL.FindRowNum(Testcase, "CreateOrder");
        DataDictLib.pushToDictionaryWithSheet(TcRow, "CreateOrder");
        var NavIdValue = DataDictLib.getFromDictionary('NavIdValue');
        var rownumber = DataDictLib.getFromDictionary('NavIdValue');
        var urlName = DataDictLib.getFromDictionary('UrlName');
        var Navigationvalue = DataDictLib.getFromDictionary('CreateTitle');
        ORDRegression.Get_url(Testcase);
        protractor_1.browser.sleep(5000);
        ORDRegression.SignIn(Testcase);
        ORDRegression.NavigationFunction(Navigationvalue, Testcase);
        ORDRegression.utilities("Reference", "Add");
        //  browser.sleep(3000);
        // var OrderNumber = await ORDRegression.Enteringdata(Testcase);
        // browser.sleep(3000);
        // ORDRegression.Equipment();
        //     browser.sleep(3000);
        //     ORDRegobject.NextButton.click();
        //     ORDRegression.AddstopsOrigin(Testcase,"Scheduled","","18/Jan/2018"); 
        //     ORDRegression.AddstopsDestination(Testcase,"Scheduled","","19/Jan/2018");
        //     ORDRegression.TotalMilesCreateOrderOverview(ORDRegobject.TotalMiles);    /////Total Miles
        //    // ORDRegression.ClickButtonwithText("Back");
        ORDRegression.utilities("Reference", "Edit");
        //         browser.executeScript("window.scrollTo(0,-500)");
        //         ORDRegobject.NextButton.click();
        //         browser.sleep(60000);
        //         browser.sleep(60000);
        //         ORDRegression.Overrideall();
        //     browser.sleep(60000);
        //    // ORDRegression.ElementWait(true,ORDRegobject.Shippingpage); 
        //     ORDRegression.ValidateRateOption();
        //     ORDRegression.ClickRateoption(Testcase,rownumber);
        //     //ORDRegression.ClickButtonwithText("Create")
        //     browser.sleep(15000); 
        //     ORDRegression.CreateWithoutRate();
        //         ORDRegression.NavigationFunction(Navigationvalue,Testcase);
        //         ORDRegression.AdvancedSearchforOrder(OrderNumber,"01/18/2018","01/18/2018","Acccepted");  
        //ViewOrder
    }));
});
//# sourceMappingURL=TC_031.js.map