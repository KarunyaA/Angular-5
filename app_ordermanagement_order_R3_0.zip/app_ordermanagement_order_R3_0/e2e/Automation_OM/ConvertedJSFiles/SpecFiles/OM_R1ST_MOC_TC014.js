"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const protractor_1 = require("protractor");
const Regression_1 = require("../PageFiles/Regression");
let ORDRegression = new Regression_1.commonFunctions;
const Objects_Order_1 = require("../ObjectRepository/Objects_Order");
let ORDRegobject = new Objects_Order_1.Update_Objects();
const ReadFromXL_1 = require("../CommonFiles/ReadFromXL");
var ReadFromXL = new ReadFromXL_1.ExcelReader();
const DictionaryData_1 = require("../DataFiles/DictionaryData");
var DataDictLib = new DictionaryData_1.DataDictionary();
var path = require('path');
var filename = path.basename(__filename);
var Testcase = path.parse(filename).name;
var TcRow = ReadFromXL.FindRowNum(Testcase, "CreateOrder");
DataDictLib.pushToDictionaryWithSheet(TcRow, "CreateOrder");
var NavIdValue = DataDictLib.getFromDictionary('NavIdValue');
var rownumber = DataDictLib.getFromDictionary('Rateoption');
var Navigationvalue = DataDictLib.getFromDictionary('CreateTitle');
describe("OM_R1ST_MOC_TC014", () => {
    it("Navigate to Create order page", () => {
        ORDRegression.Get_url(Testcase);
        ORDRegression.SignIn(Testcase);
        protractor_1.browser.sleep(5000);
        ORDRegression.NavigationFunction("Create New Order", Testcase);
    });
    it("Adding origin stop details", () => {
        ORDRegression.Enteringdata(Testcase);
        protractor_1.browser.sleep(5000);
        ORDRegression.AddstopsOrigin(Testcase, "NULL", "NULL", "08/Feb/2018");
        ORDRegression.AddstopsDestination(Testcase, "NULL", "Null", "08/Feb/2018");
        ORDRegression.ClickButtonwithText("Next");
        protractor_1.browser.sleep(60000);
        //browser.executeScript("window.scrollTo(0,-500)");
        ORDRegression.ClickRateoption(Testcase, rownumber);
        ORDRegression.ClickButtonwithText("Create");
        protractor_1.browser.sleep(40000);
        protractor_1.browser.executeScript("window.scrollTo(0,2000)");
        // ORDRegression.OrderHistory();
        ORDRegression.RoutePlan(Testcase);
    });
});
//# sourceMappingURL=OM_R1ST_MOC_TC014.js.map