"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const protractor_1 = require("protractor");
const Regression_1 = require("../PageFiles/Regression");
let ORDRegression = new Regression_1.commonFunctions;
const Objects_Order_1 = require("../ObjectRepository/Objects_Order");
//let path="C:\\Users\\rcon996\\AppData\\Roaming\\npm";
let ORDRegobject = new Objects_Order_1.Update_Objects();
const ReadFromXL_1 = require("../CommonFiles/ReadFromXL");
var ReadFromXL = new ReadFromXL_1.ExcelReader();
const DictionaryData_1 = require("../DataFiles/DictionaryData");
var DataDictLib = new DictionaryData_1.DataDictionary();
var path = require('path');
var filename = path.basename(__filename);
var Testcase = path.parse(filename).name;
const CCI_CreateAccount_1 = require("../PageFiles/CCI_CreateAccount");
let CA_Run = new CCI_CreateAccount_1.CreateAccount();
var DataDictLibforCCI = new DictionaryData_1.DataDictionary();
var OrderNumber;
var TcRow = ReadFromXL.FindRowNum(Testcase, "CreateOrder");
DataDictLib.pushToDictionaryWithSheet(TcRow, "CreateOrder");
var NavIdValue = DataDictLib.getFromDictionary('NavIdValue');
var rownumber = DataDictLib.getFromDictionary('Rateoption');
var urlName = DataDictLib.getFromDictionary('UrlName');
var Navigationvalue = DataDictLib.getFromDictionary('CreateTitle');
describe("OM_R1ST_Other BU-SO_MOC-QLF-CONF_DCS_Dedicated_TC048", () => {
    // it("Create an Account in CCI Application",() => {
    //   var CCiRow=ReadFromXL.FindRowNum(Testcase,"CCI_Details");
    //   DataDictLibforCCI.pushToDictionaryWithSheet(CCiRow,"CCI_Details");
    //   CA_Run.invokeApplication();                
    //  // CA_Run.ApplicationLogin(Testcase); 
    //   browser.sleep(3000);           
    //  CA_Run.Navigation_Process(); 
    //   CA_Run.CreateAccount(Testcase);  
    // });
    it("Navigate to Create order page", () => __awaiter(this, void 0, void 0, function* () {
        ORDRegression.Get_url(Testcase);
        ORDRegression.SignIn(Testcase);
        protractor_1.browser.sleep(4000);
        //   ORDRegression.NavigationFunction(Navigationvalue,Testcase);
        //   browser.sleep(4000);
    })),
        // it("Adding create page details",async() => {
        //   OrderNumber=await ORDRegression.Enteringdata(Testcase);    
        //   //ORDRegression.Freightcharges("3rd");y
        //   ORDRegression.Shipmentdetails("94345","12589","FL741");
        //   ORDRegression.InternationalShipment();
        //   ORDRegression.Equipment();
        //   browser.sleep(4000);
        // }),
        //   it("Adding origin stops details",() => {
        //    ORDRegression.AddstopsOrigin(Testcase,"","NULL","");
        //   }),
        //   it("Adding destination stops details",() => {
        //    ORDRegression.AddstopsDestination(Testcase,"","NUll","");
        //    ORDRegression.ClickButtonwithText("Next")
        //    browser.sleep(7000);         
        //    browser.executeScript("window.scrollTo(0,-1000)");
        //    ORDRegression.Overrideall();     
        //    browser.sleep(80000);
        //   }),
        //   it("Searching the Order in Advanced search",() => {
        //   // ORDRegression.ElementWait(true,ORDRegobject.Shippingpage); 
        //    ORDRegression.NavigateWhenToggleActive("Advanced Search");
        //    ORDRegression.AdvancedSearchforOrder(OrderNumber,"","","Accepted");
        //    browser.sleep(6000);
        //    //ORDRegression.OrderHistoryWarningsoverride();
        //   }),
        it("Changing the Credit status in CCI Application", () => {
            //  ORDRegression.Get_url("https://account-tst.jbhunt.com/account/accounts/manageaccounts");
            //  CA_Run.SearchAccount(Testcase);
            //  ORDRegression.CCI_AccountSearch("Denied");
        }),
        it("Searching the Order in Advanced search", () => {
            //  ORDRegression.Get_url(Testcase);
            ORDRegression.NavigatefromDashboard("Advanced Search");
            ORDRegression.AdvancedSearchforOrder(3020567, "", "", "pending");
            //  ORDRegression.OrderHistoryWarningsoverride();
        }),
        it("Reject the order with rejected credit status", () => {
            ORDRegression.RejectOrder();
        });
});
//# sourceMappingURL=OM_R1ST_Other BU-SO_MOC-QLF-CONF_DCS_Dedicated_TC048.js.map