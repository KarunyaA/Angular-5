"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ExcelDataSourceForConf = require('../CommonFiles/ReadFromXL');
var ReadFromXL = new ExcelDataSourceForConf();
var PushAndPullDataDictLib = require('../DataFiles/DictionaryData');
var DataDictLib = new PushAndPullDataDictLib();
class Ord_Objects {
}
exports.Ord_Objects = Ord_Objects;
//# sourceMappingURL=OrdObjects.js.map