"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const protractor_1 = require("protractor");
const ptor_1 = require("protractor/built/ptor");
const Objects_Order_1 = require("../ObjectRepository/Objects_Order");
const ReadFromXL_1 = require("../CommonFiles/ReadFromXL");
const DictionaryData_1 = require("../DataFiles/DictionaryData");
//let ObjAP = new LaunchUrl(); 
let OBJCreate = new Objects_Order_1.Update_Objects();
var ReadFromXL = new ReadFromXL_1.ExcelReader();
var DataDictLib = new DictionaryData_1.DataDictionary();
var ExcelDataSourceForConf = require('../CommonFiles/ReadFromXL');
//var ReadFromXL = new ExcelDataSourceForConf();
var PushAndPullDataDictLib = require('../DataFiles/DictionaryData');
//var DataDictLib = new PushAndPullDataDictLib();
// 'use strict';  
// var createobj =require('/PageFiles/createorderOBJ.ts'); 
//module.exports = {   
class commonFunctions {
    CreateOrderFunction(Testcasename, Access) {
        var TcRow = ReadFromXL.FindRowNum(Testcasename);
        DataDictLib.pushToDictionary(TcRow);
        var Navigationvalue = DataDictLib.getFromDictionary('CreateTitle');
        this.Get_url(Testcasename);
        // this.SignIn(Testcasename);
        protractor_1.browser.sleep(4000);
        var Flowvalue = this.NavigationFunction(Navigationvalue, Testcasename, "YES");
        var Neworder = protractor_1.element(protractor_1.by.xpath("//span[@class=\"btn-group open\"]//ul[@class=\"dropdown-menu dropdown-menu-right\"]//li//a[text()=\"" + Flowvalue + "\"]"));
        var val = (Neworder).isPresent().then((elem) => {
            if (elem === true) {
                Neworder.click();
                //browser.waitForAngularEnabled();
                protractor_1.browser.sleep(6000);
                this.Enteringdata(Testcasename);
                //browser.waitForAngularEnabled();
                protractor_1.browser.sleep(8000);
                this.AddstopsOrigin(Testcasename);
                //browser.waitForAngularEnabled();
                protractor_1.browser.sleep(6000);
                console.log("Create order option is available and the Create order access is available for the user");
            }
            else {
                console.log("Fail-Create order is not available for the user ");
            }
        });
        protractor_1.browser.sleep(40000);
        protractor_1.browser.waitForAngular();
        protractor_1.browser.executeScript("window.scrollTo(0,-200)");
        this.ClickRateoption("TC005", 1);
        protractor_1.browser.sleep(8000);
        protractor_1.browser.waitForAngular();
        this.RoutePlan("Route Plan");
        protractor_1.browser.sleep(4000);
    }
    CreatetemplateFunction(Testcasename, Access) {
        var TcRow = ReadFromXL.FindRowNum(Testcasename);
        DataDictLib.pushToDictionary(TcRow);
        var Navigationvalue = DataDictLib.getFromDictionary('CreateTitle');
        this.Get_url(Testcasename);
        protractor_1.browser.sleep(4000);
        var Flowvalue = this.NavigationFunction(Navigationvalue, Testcasename, "YES");
        var Neworder = protractor_1.element(protractor_1.by.xpath("//span[@class=\"btn-group open\"]//ul[@class=\"dropdown-menu dropdown-menu-right\"]//li//a[text()=\"" + Flowvalue + "\"]"));
        if (Access === "YES") {
            var val = (Neworder).isPresent().then((elem) => {
                if (elem === true) {
                    Neworder.click();
                    protractor_1.browser.sleep(4000);
                    this.Enteringdata(Testcasename);
                    protractor_1.browser.sleep(5000);
                    this.AddstopsOrigin(Testcasename);
                    protractor_1.browser.sleep(6000);
                    console.log("Create template option is available and the Create order access is available for the user");
                }
                else {
                    console.log("Fail-Create template is not available for the user ");
                }
            });
        }
        else {
            var val = (Neworder).isPresent().then((elem) => {
                if (elem === true) {
                    console.log("Fail-Create template is available for the user for whom the access is denied");
                }
                else {
                    console.log("Pass-Create template access is not available for the user");
                }
            });
        }
    }
    ElementEnabledFunction(Access, Testcasename, element) {
        var bool1;
        // var TcRow=ReadFromXL.FindRowNum(Testcasename)
        // DataDictLib.pushToDictionary(TcRow)
        // var urlName =DataDictLib.getFromDictionary('UrlName');
        if (Access === "YES") {
            var val = (element).isDisplayed().then((elem) => {
                if (elem === true) {
                    element.click();
                    console.log("Create order option is available and the Create order access is available for the user");
                    return bool1 = true;
                }
                else {
                    console.log("Fail-Create order is not available for the user ");
                    return bool1 = false;
                }
            });
        }
        else {
            var val = (element).isDisplayed().then((elem) => {
                if (elem === true) {
                    console.log("Fail-Create order is available for the user for whom the access is denied");
                    return bool1 = false;
                }
                else {
                    console.log("Pass-Create order access is not available for the user");
                    return bool1 = true;
                }
            });
        }
        // console.log(bool1);
        //return bool1;
    }
    SignIn(Testcasename) {
        console.log(Testcasename);
        var TcRow = ReadFromXL.FindRowNum(Testcasename);
        DataDictLib.pushToDictionary(TcRow);
        var username = DataDictLib.getFromDictionary('Username');
        var Password = DataDictLib.getFromDictionary('Password');
        OBJCreate.SignIn.isDisplayed().then((elem) => {
            if (elem === true)
                OBJCreate.SignInUser.sendKeys(username);
            OBJCreate.SignInPwd.sendKeys(Password);
            OBJCreate.SignInSubmit.click();
            protractor_1.browser.sleep(2000);
        });
    }
    Get_url(Testcasename) {
        console.log(Testcasename);
        var TcRow = ReadFromXL.FindRowNum(Testcasename);
        DataDictLib.pushToDictionary(TcRow);
        var urlName = DataDictLib.getFromDictionary('UrlName');
        console.log(urlName);
        protractor_1.browser.get(urlName); //overrides baseURL      
    }
    EnterTextBox(IdValue, Value) {
        var tagname = protractor_1.element(protractor_1.by.css("[formcontrolname=\"" + IdValue + "\"]"));
        tagname.clear();
        tagname.sendKeys(Value);
    }
    SelectDRopdownValue(IdValue) {
        var tagname = protractor_1.element(protractor_1.by.css("[placeholder=\"" + IdValue + "\"]"));
        tagname.click();
        protractor_1.browser.sleep(2000);
        tagname.sendKeys(ptor_1.protractor.Key.ENTER);
        //OBJCreate.ContactValue.click();
    }
    NavigatefromDashboard(Pagename) {
        OBJCreate.togglefield.click();
        var dbOption = protractor_1.element(protractor_1.by.cssContainingText(".routeDisplayText", "" + Pagename + ""));
        dbOption.click();
        protractor_1.browser.sleep(3000);
    }
    NavigationFunction(Flowvalue, Testcasename, Access) {
        var TcRow = ReadFromXL.FindRowNum(Testcasename);
        DataDictLib.pushToDictionary(TcRow);
        var NavIdValue = DataDictLib.getFromDictionary('NavIdValue');
        // var NavIdValue =DataDictLib.getFromDictionary('NavIdValue');
        this.NavigatefromDashboard(NavIdValue);
        protractor_1.browser.executeScript("window.scrollBy(-2000, 0)");
        var Neworder = protractor_1.element(protractor_1.by.xpath("//span[@class=\"btn-group open\"]//ul[@class=\"dropdown-menu dropdown-menu-right\"]//li//a[text()=\"" + Flowvalue + "\"]"));
        OBJCreate.Flowmenu.click();
        return Flowvalue;
        //var bool=this.ElementEnabledFunction("YES","",Neworder).valueOf();            
    }
    SelectDropDown(IdValue, BU, Testcasename) {
        var TcRow = ReadFromXL.FindRowNum(Testcasename);
        DataDictLib.pushToDictionary(TcRow);
        var BUValue = DataDictLib.getFromDictionary('BU');
        var allOptions = protractor_1.element.all(protractor_1.by.xpath("//*[@id='financeBusinessUnitCode']//ul//a/div"));
        console.log(allOptions.count());
        allOptions.filter(function (elem) {
            return elem.getText().then(function (text) {
                console.log(text);
                return text === BUValue;
            });
        }).click();
    }
    Selectcalendericon(ApntmntDate) {
        var datevalue = ApntmntDate.split('/');
        var date = datevalue[0];
        var month = datevalue[1];
        var year = datevalue[2];
        console.log(year);
        var icon = OBJCreate.Calendaricon.get(0);
        //console.log(icon.count());
        protractor_1.browser.sleep(4000);
        icon.click();
        protractor_1.browser.sleep(4000);
        var value = null;
        let dateval = value;
        let MonthInput = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
        console.log(MonthInput.length);
        var j;
        console.log(month);
        for (var i = 0; i < MonthInput.length; i++) {
            //console.log(MonthInput[i]);
            if (month === (MonthInput[i])) {
                j = i + 1;
            }
        }
        console.log(j);
        var monthvalue = protractor_1.element(protractor_1.by.css("[class=\"headerlabelbtn monthlabel\"]"));
        var MONTH = monthvalue.getAttribute('value');
        //console.log(MONTH);
        var yearvalue = protractor_1.element(protractor_1.by.css("[class=\"headerlabelbtn yearlabel\"]"));
        var viewContainer = protractor_1.element(protractor_1.by.css("[class=\"headerlabelbtn monthlabel\"]")).getText();
        viewContainer.then(console.log);
        var valuemon = monthvalue.getText().then(function (text) {
            console.log(text);
            return text.toString();
        });
        console.log("helll   ...........");
        //console.log(valuemon);
        var k = 0;
        console.log("lval " + k);
        var test = expect(monthvalue.getText()).toEqual("NOV");
        console.log("arun");
        console.log(test);
        for (var i = 0; i < MonthInput.length; i++) {
            var varialbe = (MonthInput[i]);
            console.log(i);
        }
        console.log("K value is " + k);
        console.log("Month value" + monthvalue.getText());
        console.log("year value" + yearvalue.getText());
        console.log("the value " + j);
        console.log("list val " + k);
        if ((monthvalue.getText().then(function (text) { console.log(text); return text === month; })) && (yearvalue.getText().then(function (text) { console.log(text); return text === year; }))) {
            var allOptions = protractor_1.element.all(protractor_1.by.xpath("//table[@class='caltable']//tbody//tr//td//div[contains(@class,'datevalue currmonth')]"));
            allOptions.filter(function (elem) {
                //console.log(elem.getText())
                return elem.getText().then(function (text) {
                    //console.log(elem.getText())
                    return text === date;
                });
            }).first().click();
            protractor_1.browser.sleep(4000);
        }
        else if ((yearvalue.getText().then(function (text) { return parseInt(text) > parseInt(year); }))) {
            var yeardiff;
            //yeardiff=yearvalue.getText().then(function(text) { return (parseInt(text)-parseInt(year));})
            //yeardiff=parseInt(text)
            var Prevyrbutton = protractor_1.element(protractor_1.by.xpath("//button[@aria-label='Previous Year']"));
            for (var i = 0; i < yeardiff; i++) {
                //console.log(MonthInput[i]);
                Prevyrbutton.click();
                protractor_1.browser.sleep(1000);
            }
            if (j = k) {
                var allOptions = protractor_1.element.all(protractor_1.by.xpath("//table[@class='caltable']//tbody//tr//td//div[contains(@class,'datevalue currmonth')]"));
                allOptions.filter(function (elem) {
                    return elem.getText().then(function (text) {
                        return text === date;
                    });
                }).first().click();
                protractor_1.browser.sleep(4000);
            }
            else if (j < k) {
                var monthdiff = 12 - (k - j);
                var nextMNbutton = protractor_1.element(protractor_1.by.xpath("//button[@aria-label='Next Month']"));
                for (var i = 0; i < monthdiff; i++) {
                    //console.log(MonthInput[i]);
                    nextMNbutton.click();
                    protractor_1.browser.sleep(1000);
                }
                var allOptions = protractor_1.element.all(protractor_1.by.xpath("//table[@class='caltable']//tbody//tr//td//div[contains(@class,'datevalue currmonth')]"));
                allOptions.filter(function (elem) {
                    return elem.getText().then(function (text) {
                        return text === date;
                    });
                }).first().click();
                protractor_1.browser.sleep(4000);
            }
            else if (j < k) {
                var monthdiff = (j - k);
                var nextMNbutton = protractor_1.element(protractor_1.by.xpath("//button[@aria-label='Next Month']"));
                for (var i = 0; i < monthdiff; i++) {
                    //if(nextMNbutton.getText() ==="Nov")
                    //console.log(MonthInput[i]);
                    nextMNbutton.click();
                    protractor_1.browser.sleep(1000);
                }
                var allOptions = protractor_1.element.all(protractor_1.by.xpath("//table[@class='caltable']//tbody//tr//td//div[contains(@class,'datevalue currmonth')]"));
                allOptions.filter(function (elem) {
                    return elem.getText().then(function (text) {
                        return text === date;
                    });
                }).first().click();
                protractor_1.browser.sleep(4000);
            }
        }
        else if ((yearvalue.getText().then(function (text) { return parseInt(text) < parseInt(year); }))) {
            var nextyrbutton = protractor_1.element(protractor_1.by.xpath("//button[@aria-label='Next Year']"));
            nextyrbutton.click();
            protractor_1.browser.sleep(4000);
            var allOptions = protractor_1.element.all(protractor_1.by.xpath("//table[@class='caltable']//tbody//tr//td//div[contains(@class,'datevalue currmonth')]"));
            allOptions.filter(function (elem) {
                //console.log(elem.getText())
                return elem.getText().then(function (text) {
                    //console.log(elem.getText())
                    return text === date;
                });
            }).first().click();
            protractor_1.browser.sleep(4000);
        }
    }
    Enteringdata(Testcasename) {
        var TcRow = ReadFromXL.FindRowNum(Testcasename);
        DataDictLib.pushToDictionary(TcRow);
        var BUValue = DataDictLib.getFromDictionary('BU');
        var SOValue = DataDictLib.getFromDictionary('SO');
        var BillToValue = DataDictLib.getFromDictionary('BillTO');
        var OpOwner = DataDictLib.getFromDictionary('OpOwner');
        var TitleCreate = DataDictLib.getFromDictionary('CreateTitle');
        OBJCreate.BillTo.sendKeys(BillToValue);
        //OBJCreate.BillTo.sendKeys(Billto);
        protractor_1.browser.sleep(5000);
        OBJCreate.BillTo.sendKeys(ptor_1.protractor.Key.ENTER);
        protractor_1.browser.sleep(5000);
        //browser.wait((browser.until.OBJCreate.BTContact), 5000);
        OBJCreate.BTContact.click();
        protractor_1.browser.sleep(2000);
        OBJCreate.BTContact.sendKeys(ptor_1.protractor.Key.ENTER);
        OBJCreate.BU.click();
        OBJCreate.BUclick.sendKeys(BUValue);
        protractor_1.browser.sleep(2000);
        OBJCreate.BUclick.sendKeys(ptor_1.protractor.Key.ENTER);
        protractor_1.browser.sleep(3000);
        OBJCreate.SO.click();
        OBJCreate.SOclick.sendKeys(SOValue);
        protractor_1.browser.sleep(2000);
        OBJCreate.SOclick.sendKeys(ptor_1.protractor.Key.ENTER);
        protractor_1.browser.sleep(3000);
        if (TitleCreate === "Create New Order") {
            OBJCreate.OPOwner.sendKeys(OpOwner);
            protractor_1.browser.sleep(2000);
            OBJCreate.OPOwner.sendKeys(ptor_1.protractor.Key.ENTER);
        }
        else {
            console.log("Create new template do not contain this field");
        }
        OBJCreate.NextButton.click();
        protractor_1.browser.sleep(3000);
    }
    //Addstops(pickup:string,itemqnty:string,itemweight:string,itemdesc:string,destination:string,title:string):void 
    AddstopsOrigin(Testcasename) {
        var TcRow = ReadFromXL.FindRowNum(Testcasename);
        DataDictLib.pushToDictionary(TcRow);
        var Pickup = DataDictLib.getFromDictionary('Pickup');
        var Delivery = DataDictLib.getFromDictionary('Delivery');
        var ItemQty = DataDictLib.getFromDictionary('ItemQty');
        var ItemWt = DataDictLib.getFromDictionary('ItemWt');
        var ItemChar = DataDictLib.getFromDictionary('ItemChar');
        var TitleCreate = DataDictLib.getFromDictionary('CreateTitle');
        this.EnterTextBox("locationID", Pickup);
        OBJCreate.BillToValue.click();
        protractor_1.browser.sleep(4000);
        this.SelectDRopdownValue("Contact");
        protractor_1.browser.sleep(2000);
        OBJCreate.dropdownopt.click();
        this.EnterTextBox("itemHandlingTypeQuantity", ItemQty);
        protractor_1.browser.sleep(2000);
        this.EnterTextBox("itemHandlingUnitWeight", ItemWt);
        protractor_1.browser.sleep(2000);
        var Handlingunit = protractor_1.element(protractor_1.by.css("[formcontrolname=\"itemHandlingUnitHeight\"]"));
        Handlingunit.sendKeys(ptor_1.protractor.Key.TAB);
        protractor_1.browser.sleep(5000);
        //tagname.sendKeys("Silico");
        this.EnterTextBox("packagingUnitTypeQuantity", ItemQty);
        this.EnterTextBox("itemWeight", ItemWt);
        protractor_1.browser.sleep(5000);
        var itemunit = protractor_1.element(protractor_1.by.css("[formcontrolname=\"itemHeight\"]"));
        itemunit.sendKeys(ptor_1.protractor.Key.TAB);
        protractor_1.browser.sleep(12000);
        this.EnterTextBox("itemDescription", ItemChar);
        protractor_1.browser.sleep(5000);
        var tagname = protractor_1.element(protractor_1.by.css("[formcontrolname=\"itemDescription\"]"));
        //tagname.sendKeys("Silico");
        tagname.sendKeys(ptor_1.protractor.Key.ENTER);
        protractor_1.browser.sleep(15000);
    }
    AddstopsDestination(Testcasename) {
        var TitleCreate = DataDictLib.getFromDictionary('CreateTitle');
        var Delivery = DataDictLib.getFromDictionary('Delivery');
        if (TitleCreate === "Create New Order") {
            OBJCreate.DestinationTab.click();
            protractor_1.browser.sleep(7000);
        }
        else {
            OBJCreate.TemplateDestinationTab.click();
            protractor_1.browser.sleep(7000);
        }
        this.EnterTextBox("locationID", Delivery);
        OBJCreate.BillToValue.click();
        protractor_1.browser.sleep(2000);
        this.SelectDRopdownValue("Contact");
        protractor_1.browser.sleep(5000);
        if (TitleCreate === "Create New Order") {
            OBJCreate.PalletChckBX.click();
            protractor_1.browser.sleep(6000);
            OBJCreate.NextButton.click();
        }
        else {
            OBJCreate.TemplatePalletChckBX.click();
            protractor_1.browser.sleep(6000);
            OBJCreate.SaveButton.click();
        }
        protractor_1.browser.sleep(8000);
        //sendKeys(protractor.Key.ENTER); 
    }
    AdvancedSearchforOrder() {
        // this.NavigatefromDashboard("Advanced Search");     
        // browser.sleep(3000);
        this.ElementWait(true, OBJCreate.allOptions);
        // var allOptions =element.all(by.xpath("//*[@class='inline']//ng-select[@placeholder='Type'][1]"))
        OBJCreate.acceptclose.click();
        OBJCreate.Showmore.click();
        protractor_1.browser.executeScript("window.scrollTo(0,-200)");
        protractor_1.browser.sleep(2000);
        OBJCreate.Statuschange.sendKeys("Peending");
        OBJCreate.Statuschange.sendKeys(ptor_1.protractor.Key.ENTER);
        protractor_1.browser.executeScript("window.scrollTo(0,200)");
        OBJCreate.Destin.click();
        // OBJCreate.ordertype.click();
        // browser.executeScript("window.scrollTo(0,200)"); 
        OBJCreate.allOptions.get(2).click();
        var ind = 0;
        OBJCreate.allOptions.count().then(function (total) {
            OBJCreate.allOptions.each(function (item) {
                ind++;
                if (ind == 2) {
                    console.log("index no is" + ind);
                    item.sendKeys("order number");
                    protractor_1.browser.sleep(2000);
                    item.sendKeys(ptor_1.protractor.Key.TAB);
                    item.sendKeys(ptor_1.protractor.Key.TAB);
                    item.sendKeys(ptor_1.protractor.Key.TAB);
                    item.sendKeys(ptor_1.protractor.Key.ENTER);
                }
                else
                    console.log("View drop down is not available with the values");
            });
        });
        var ind1 = 0;
        protractor_1.browser.sleep(2000);
        OBJCreate.orderno.count().then(function (total) {
            OBJCreate.orderno.each(function (item) {
                console.log(ind1);
                ind1++;
                if (ind1 == 3) {
                    item.sendKeys("3000339");
                    protractor_1.browser.sleep(2000);
                }
                else
                    console.log("View drop down is not available with the values");
            });
        });
        OBJCreate.SearchButton.click();
        protractor_1.browser.executeScript("window.scrollTo(0,-200)");
        OBJCreate.SelectFirstorder.get(0).click();
        var viewpage = protractor_1.element(protractor_1.by.xpath("//span[text()='Order']"));
    }
    AlternateShippingoptions(Testcasename) {
        OBJCreate.ShippingFlowMenu.click();
        OBJCreate.FlowMenuAlternate.click();
        protractor_1.browser.sleep(8000);
        protractor_1.browser.waitForAngularEnabled();
        console.log(OBJCreate.BUSOParent.count());
        var index = 0;
        OBJCreate.BUSOParent.count().then(function (total) {
            OBJCreate.BUSOParent.each(function (item) {
                index++;
                console.log(OBJCreate.BUSOParent.count());
                if (total > 0) {
                    var Disp = item.getText().then((elem) => {
                        if (elem.trim() === "JBT - OTR") {
                            console.log("The alternate shipping option is JBT OTR");
                        }
                        if (elem.trim() === "JBI - Backhaul") {
                            console.log("The alternate shipping option is JBi backhaul");
                        }
                        if (elem.trim() === "DCS - Backhaul") {
                            console.log("The alternate shipping option is Dcs Backhaul");
                        }
                        if (elem.trim() === "ICS - Brokerage") {
                            console.log("The alternate shipping option is ICS Brokerage");
                        }
                        if (elem.trim() === "ICS - LTL") {
                            console.log("The alternate shipping option is ICS LTL");
                        }
                        if (elem.trim() === "ICS - Reefer") {
                            console.log("The alternate shipping option is ICS Reefer");
                        }
                        if (index == 10) {
                            OBJCreate.rightArrow.click();
                            protractor_1.browser.sleep(5000);
                        }
                    });
                }
                else
                    console.log("View drop down is not available with the values");
            });
        });
    }
    CreateOpportunity(Testcasename) {
        var TcRow = ReadFromXL.FindRowNum(Testcasename);
        DataDictLib.pushToDictionary(TcRow);
        var HourMIn = DataDictLib.getFromDictionary('HourMIn');
        var Timevalue = HourMIn.split(',');
        var hour = Timevalue[0];
        var min = Timevalue[1];
        OBJCreate.ShippingFlowMenu.click();
        var val = (OBJCreate.FlowMenuOppurtunity).isDisplayed().then((elem) => {
            if (elem === true) {
                // element(by.id("billtoaccount")).sendKeys("CACAB9")
                OBJCreate.FlowMenuOppurtunity.click();
                console.log("Opportunity is clicked from the dropdown");
            }
            else {
                console.log("Create opportunity is not displayed in the shipping options Flow menu");
            }
        });
        var OppHour = protractor_1.element(protractor_1.by.css('[formcontrolname="expirationTimeHrs"]')).element(protractor_1.by.cssContainingText('option', hour)).click();
        var OppMin = protractor_1.element(protractor_1.by.css('[formcontrolname="expirationTimeMins"]')).element(protractor_1.by.cssContainingText('option', min)).click();
        this.EnterTextBox("comments", "Test");
        OBJCreate.CreateButton.click();
    }
    ClickRateoption(Testcasename, Rownumber) {
        protractor_1.browser.sleep(5000);
        protractor_1.browser.executeScript("window.scrollTo(0,-500)");
        var EC = ptor_1.protractor.ExpectedConditions;
        protractor_1.browser.wait(EC.visibilityOf(OBJCreate.optiondots.get(Rownumber)), 10000).then(function () {
            console.log("Click on the rate dot");
            OBJCreate.optiondots.get(Rownumber).click();
        });
        protractor_1.browser.executeScript("window.scrollTo(0,500)");
        var val = (OBJCreate.CreateButtonOverview).isDisplayed().then((elem) => {
            if (elem === true) {
                protractor_1.browser.sleep(3000);
                OBJCreate.CreateButtonOverview.click();
                console.log("Opportunity is clicked from the dropdown");
            }
            else {
                console.log("Create opportunity is not displayed in the shipping options Flow menu");
            }
        });
        var val = (OBJCreate.Overideall).isDisplayed().then((elem) => {
            if (elem === true) {
                // element(by.id("billtoaccount")).sendKeys("CACAB9")
                protractor_1.browser.sleep(4000);
                protractor_1.browser.executeScript("window.scrollTo(0,-500)");
                protractor_1.browser.sleep(3000);
                protractor_1.browser.actions().mouseMove(OBJCreate.Overideall);
                OBJCreate.Overideall.click();
                protractor_1.browser.sleep(4000);
                console.log("Warnings are overidden successfully");
            }
            else {
                console.log("Create opportunity is not displayed in the shipping options Flow menu");
            }
        });
        var index = 0;
        OBJCreate.errorparent.count().then(function (total) {
            OBJCreate.errorparent.each(function (item) {
                index++;
                if (total >= index) {
                    (OBJCreate.errorparent).get(0).isDisplayed().then((element) => {
                        if (element === true) {
                            var EC = ptor_1.protractor.ExpectedConditions;
                            protractor_1.browser.wait(EC.visibilityOf(OBJCreate.errorlink), 5000).then(function () {
                                OBJCreate.errorlink.click();
                                (OBJCreate.errordropDown).isPresent().then(function (bool) {
                                    if (bool === true) {
                                        OBJCreate.errordropDown.click();
                                        OBJCreate.OverideErrorButton.click();
                                        protractor_1.browser.sleep(2000);
                                        // OBJCreate.errorlinkname.sendKeys(protractor.Key.ENTER);
                                    }
                                });
                                (OBJCreate.errorlinkname).isPresent().then(function (bool) {
                                    if (bool === true) {
                                        OBJCreate.errorlinkname.sendKeys("Keerthana Selvaraj");
                                        protractor_1.browser.sleep(2000);
                                        OBJCreate.errorlinkname.sendKeys(ptor_1.protractor.Key.ENTER);
                                    }
                                });
                                (OBJCreate.errorlinkCmnt).isPresent().then(function (bool) {
                                    if (bool === true) {
                                        OBJCreate.errorlinkCmnt.sendKeys("Test");
                                        OBJCreate.OverideErrorButton.click();
                                        protractor_1.browser.sleep(2000);
                                        console.log("The errors and warnings are overriden successfully");
                                    }
                                });
                            });
                        }
                    });
                }
                else
                    console.log("No errors are available");
            });
        });
        protractor_1.browser.executeScript("window.scrollTo(0,500)");
        protractor_1.browser.sleep(3000);
        OBJCreate.CreateButton.click();
        protractor_1.browser.sleep(12000);
    }
    NavigatioInVieworder() {
        OBJCreate.FlowmenuDots.click();
        OBJCreate.SelectOption.click();
        protractor_1.browser.sleep(3000);
    }
    TONU() {
        OBJCreate.WithoutapptmntRadio.click();
        OBJCreate.Comment.sendKeys("Test");
        OBJCreate.Processbutton.click();
        protractor_1.browser.sleep(6000);
        OBJCreate.GotItbutton.click();
        protractor_1.browser.sleep(3000);
    }
    RoutePlan(ViewValue) {
        protractor_1.browser.executeScript("window.scrollTo(0,200)");
        protractor_1.browser.sleep(5000);
        protractor_1.element(protractor_1.by.xpath("//h4[text()='Route Plan']")).click();
        protractor_1.browser.executeScript("window.scrollTo(0,-200)");
        var load = protractor_1.element(protractor_1.by.xpath("//span[text()='Active Load']//following::a[1]"));
        load.getText().then((elem) => {
            if (elem != "")
                console.log("Load id is generated for the order" + elem);
        });
    }
    ElementWait(elemValCheck, OBJelem) {
        return __awaiter(this, void 0, void 0, function* () {
            var cntr = 0;
            var displayvalue = false;
            var textvalue = "";
            var value = false;
            while (value === false) {
                protractor_1.browser.sleep(3000);
                yield OBJelem.isPresent().then((elem) => {
                    console.log(cntr + "th time");
                    displayvalue = elem;
                    console.log("1st scope" + displayvalue);
                });
                protractor_1.browser.sleep(3000);
                if (elemValCheck == true && displayvalue.valueOf() === true) {
                    console.log(" entering into text validation");
                    yield OBJelem.getText().then((elem1) => {
                        console.log(cntr + "th time");
                        textvalue = elem1;
                        console.log("2nd scope" + textvalue);
                    });
                }
                if (cntr > 12) {
                    break;
                }
                if (elemValCheck == true) {
                    if (textvalue !== "")
                        value = displayvalue;
                    else
                        value = false;
                }
                else
                    value = displayvalue;
                console.log(value);
                cntr++;
            }
        });
    }
}
exports.commonFunctions = commonFunctions;
//# sourceMappingURL=Createpage.js.map