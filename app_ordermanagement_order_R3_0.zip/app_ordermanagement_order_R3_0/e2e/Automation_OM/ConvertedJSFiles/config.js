"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var AllureReporter = require('jasmine-allure-reporter');
const now = new Date();
var report_name = 'Report-' + now.getFullYear() + "-" + (now.getMonth() + 1) + "-" + now.getDate() + "-" + now.getHours() + "-" + now.getMinutes() + "-" + now.getSeconds();
console.log(report_name);
var logfile_name = 'results-' + now.getFullYear() + "-" + (now.getMonth() + 1) + "-" + now.getDate() + "-" + now.getHours() + "-" + now.getMinutes() + "-" + now.getSeconds();
exports.config = {
    seleniumAddress: "http://localhost:4444/wd/hub",
    capabilities: {
        "browserName": "chrome",
    },
    framework: "jasmine",
    specs: ["./SpecFiles**/OM_R1ST_MOC_TC014.js"],
    //specs: ["./SpecFiles**/OM_R1ST_MOCQLF_TC008.js","./SpecFiles**/TC_002.js","./SpecFiles**/OM_R1ST_MOC_TC014.js"],
    jasmineNodeOpts: {
        defaultTimeoutInterval: 15000000
    },
    onPrepare: () => {
        // tslint:disable-next-line:typedef
        let globals = require("protractor");
        // tslint:disable-next-line:typedef
        let browser = globals.browser;
        browser.ignoreSynchronization = true;
        browser.manage().window().maximize();
        browser.manage().timeouts().implicitlyWait(5000);
        // tslint:disable-next-line:typedef
        // var AllureReporter = require("jasmine-allure-reporter");
        jasmine.getEnv().addReporter(new AllureReporter({
            resultsDir: 'C:\\Users\\rcon996\\Desktop\\BatchRun\\Target\\' + report_name + '\\' + logfile_name
        }));
        //   jasmine.getEnv().addReporter(new AllureReporter({
        //     resultsDir: '..\\Target\\' + report_name + '\\' + logfile_name
        // }));
        jasmine.getEnv().afterEach(() => (done) => {
            browser.takeScreenshot().then(function (png) {
                AllureReporter.createAttachment('Screenshot', function () {
                    return new Buffer(png, 'base64');
                }, 'image/png')();
                done();
            });
        });
    },
    onComplete: () => {
        // tslint:disable-next-line:typedef
        var process = require('process');
        const exec = require('child_process').execSync;
        process.chdir('C:\\Users\\rcon996\\Desktop\\BatchRun\\Target\\' + report_name);
        exec('allure generate ' + logfile_name, (error, stdout, stderr) => {
            console.log('standard output', stdout);
        });
        exec('taskkill /F /IM IEDriverServer3.9.0.exe', (error, stdout, stderr) => {
            console.log('standard output', stdout);
        });
        //exec("allure serve"+' C:\\Users\\rcon875\\Documents\\MyProtractor_WS\\ProtractorTS\\Target\\'+report_name, (error, stdout, stderr) => {
        exec('allure report open', (error, stdout, stderr) => {
            console.log("standard output", stdout);
            console.log("log file", logfile_name);
            console.log("report file", report_name);
        });
    }
};
//# sourceMappingURL=config.js.map