import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";
var ExcelDataSourceForConf = require('../CommonFiles/ReadFromXL');

export class Update_Objects{
    ////////////////////////////////////////// Launch URL Page ///////////////////////////////////////////////////////////////////////////////

    togglefield=element(by.css("[class=\"fa fa-circle-o\"]")); 
    dbOption=element(by.cssContainingText('.routeDisplayText','Create Order')); 
    Flowmenu=element(by.css("[id=\"btn-append-to-body\"]"));
    Neworder=element(by.xpath("//span[@class=\"btn-group open\"]//ul[@class=\"dropdown-menu dropdown-menu-right\"]//li//a[text()=\"Create New Order\"]"))  ;
    Newtemplate=element(by.xpath("//span[@class=\"btn-group open\"]//ul[@class=\"dropdown-menu dropdown-menu-right\"]//li//a[text()=\"Create New Template\"]"))  ;
icon_loading=element(by.xpath("//*[@class='spinner' and @role='progressbar']"));
////////////////////////////////////////// Create Order Page ///////////////////////////////////////////////////////////////////////////////

BillTo=element(by.css("[id=\"billtoaccount\"]"));
BillToValue=element(by.xpath("//ul[@class=\"dropdown-menu\"]//li[@class=\"active\"]//a"));
//BTContact=element.all(by.cssContainingText(".ui-select-placeholder text-muted","Bill to Account Contact"));
BTContact=element(by.css("[placeholder=\"Bill To Account Contact\"]"));
//BTContact=element(by.css('[formcontrolname="contactTypeCode"]'));
//span[text()="Bill To Account Contact"]
//BTContact=element(by.xpath("//ng-select[@placeholder=\"Bill to Account Contact\"]//div[@class=\"ui-select-container dropdown open\"]"));
ContactValue=element(by.xpath("//ul[@class=\"ui-select-choices dropdown-menu\"]//li//div[@class=\"ui-select-choices-row active\"]//a"));
//BU=element(by.css("[formcontrolname=\"financeBusinessUnitCode\"]"));
BU=element(by.xpath("//*[@formcontrolname='financeBusinessUnitCode']//i[2]"));
BUclick=element(by.xpath("//input[@placeholder='Business Unit']"));
BUValue=element(by.xpath("//*[@id='financeBusinessUnitCode']//ul//a/div"));

//BUValue=element(by.xpath("//ul[@class=\"ui-select-choices dropdown-menu\"]//li//a//div[contains(text(),'JBT')]/ancestor::a"));
SO=element(by.xpath("//ng-select[@formcontrolname='serviceOfferingCode']//i[2]"));
SOclick=element(by.xpath("//input[@placeholder='Service Offering']"));
SOValue=element(by.xpath("//ul[@class=\"ui-select-choices dropdown-menu\"]//li//a[contains(text(),'OTR')]/ancestor::a"));
OPOwner=element(by.css("[id=\"operationalOwner\"]"));
OPValue=element(by.xpath("//ul[@class=\"dropdown-menu\"]//li[@class=\"active\"]//a"));
NextButton=element(by.buttonText("Next"));
Tradingpartner=element(by.css("[formcontrolname='tradingPartnerCode']"));
//element(by.css('[formcontrolname="contactTypeCode"]')).element(by.cssContainingText('option','BUCKETS')).click(); 
//    var allOptions = element.all(by.xpath("///table[@class='caltable']//tbody//tr//td//div[contains(@class,'datevalue currmonth')]"))
//    allOptions.filter(function (elem) {
//    return elem.getText().then(function (text) {
//    return text === '20';
//    });
//    }).first().click(); 

//ADD Stop objects:
Location=element(by.css("[formcontrolname='locationID']"));
LocationContact=element(by.css("[placeholder='Contact']"));

DestinationTab=element(by.xpath("//i[@class='glyphicon accordianIcon icon-jbh_expand']"));
TemplateDestinationTab=element(by.xpath("//i[@class='glyphicon accordianIconCustomize textBold icon-jbh_expand']"));
AddStopDestinationTab=element.all(by.xpath("//i[@class='glyphicon accordianIcon icon-jbh_expand']"));
TemplateAddStopDestinationTab=element.all(by.xpath("//i[@class='glyphicon accordianIconCustomize textBold icon-jbh_expand']"));

PalletChckBX=element(by.xpath("//a[@class='list-group-item']//following::input[@type='checkbox']"));;
MultiplePalletChckBX=element.all(by.xpath("//a[@class='list-group-item']//following::input[@type='checkbox']"));;

TemplatePalletChckBX=element(by.xpath("//a[@class='list-group-item']//following::input[@type='checkbox']"));;
SaveButton=element(by.buttonText("Save"));
Savebuttonreject=element.all(by.xpath("//button[@id='btn-save' and text()='Save']"));
ItmdescDD=element(by.xpath("//ul[@class='dropdown-menu']//li[@class='active']//a//h5"));
//dropdownopt=element(by.css('[formcontrolname="itemHandlingTypeCode"]')).element(by.cssContainingText('div','Bag'));

dropdownopt=element(by.xpath("//div[text()='Bag']"));
//Advanced search page

TypeDD=element.all(by.xpath("//ng-select[@placeholder='Type']"));
//*[@placeholder='Name'][1]
accountname=element(by.xpath("//*[@placeholder='Name'][1]"));
SearchButton=element(by.buttonText("Search"));
Status=element(by.xpath("//ng-select[@id='tagIpOrderSearchStatus']//span//a"));

Showmore=element(by.css("[id='orderSearchShowMore']"));
//OrdersearchBU=element(by.css("[formcontrolname=\"orderSearchBusinessUnit\"]"));
OrdersearchBU=element(by.xpath("//*[@id='ngSelOrderSearchBusinessUnit']//span[text()='Business Unit']"));

//OrderSearchSO=element(by.css("[formcontrolname=\"orderSearchServiceOffering\"]"));
OrderSearchSO=element(by.xpath("//*[@id='ngSelOrderSearchServiceOffering']//span[text()='Service Offering']"));

busearch=element(by.css("[formcontrolname=\"orderSearchBusinessUnit\"]")).element(by.xpath("//input[@placeholder='Business Unit']"));
Sosearch=element(by.css("[formcontrolname=\"orderSearchServiceOffering\"]")).element(by.xpath("//input[@placeholder='Service Offering']"));

//Calendar icon:
//Calendaricon=element.all(by.xpath("//my-date-picker[@formcontrolname='appointmentStartDate']//span[@class='mydpicon icon-mydpcalendar']"));
Calendaricon=element.all(by.xpath("//button[@class='btnpicker btnpickerenabled']"));
calListdiv=element(by.css("[class=\"selector selectorarrow selectorarrowleft\"]"));
calListtable=element.all(by.xpath("//table[@class='caltable']//tbody//tr"));
AddappointmentIcon=element.all(by.xpath("//a[@class='link-icon-secondary']//i")); 
AddappointmentIconschedule=element(by.xpath("//p[text()='Primary Appointment']//following::h3[text()='Scheduled Appointments']//following::i[1]"));
//Shipping option page:
shippingRowparent=element(by.css("[class='datatable-scroll']"));
shippingRowdivs=element.all(by.xpath("//datatable-row-wrapper[@class='datatable-row-wrapper']"));
ShippingFlowMenu=element(by.css("[id='btn-append-to-body']"));
FlowMenuAlternate=element(by.css("[id='a-viewAllShippingOptions']"));
BUSOParent=element.all(by.xpath("//div[@class='datatable-row-center datatable-row-group']//datatable-body-cell[@class='datatable-body-cell sort-active'][1]"));
rightArrow=element(by.css("[class='icon icon-jbh_right_arrow']"));


//ShippingFlowMenu=element(by.id("btn-append-to-body"));a-createOpport
FlowMenuOppurtunity=element(by.css("[id='a-createOpport']"));
CreateButton=element(by.buttonText("Create"));
optiondots=element.all(by.id("btn-showPopOver"));
AllInRate=element(by.xpath("//div[text()='All In Rate ']//following::div[2]"));
FuelSurcharge=element(by.xpath("//div[text()='Fuel Surcharge']//following::div[2]"));
Overideall=element(by.xpath("//div[@class='caption']//a[@id='a-overRideAll']"));
Overidewarning=element(by.xpath("//h3[text()='Warnings']//following::p[1]"));
warningMsg=element(by.xpath("//p[text()='Override All']//following::li[1]"));
tagname=element.all(by.css("[formcontrolname='packagingUnitTypeQuantity']"));
tagname1=element.all(by.css("[formcontrolname='itemWeight']"));
tagname2=element.all(by.css("[formcontrolname='itemDescription']"));
itemunit=element.all(by.css("[formcontrolname=\"itemHeight\"]"));
itemchar=element.all(by.css("[formcontrolname='itemCharacteristics']"));
itemcharname=element.all(by.css("[formcontrolname='itemCharacteristics']"));
NMFCNumber=element.all(by.css("[formcontrolname='freightClassCode']"));
//Overideall=element(by.xpath("//div[div[text()='Warning']]/parent::div/parent::div//a[@id='a-overRideAll' and @class='nodecor']"));
//div[div[text()='Warning']]/parent::div/parent::div//a[@id='a-overRideAll' and @class='nodecor']
//Overideall=element(by.linkText("Override All"))
errorparent=element.all(by.xpath("//div[@class='caption']//ul[@class='list-group mar-bot0']//li"));
errorlink=element(by.xpath("//div[@class='caption']//a[@id='a-ruleExcep-desc']"));
errorlinkname=element(by.css("[id='preferedName']"));
errorlinkCmnt=element(by.css("[id='overRideCmtTxt']"));
//errordropDown=element(by.xpath("//p[text()='Reason']//following::select")).element(by.cssContainingText('option','EDI Tender Will Time-Out')); 
errorDropdownClick=element(by.xpath("//div[@class='ui-select-container dropdown open']"))
errordropDown=element(by.xpath("//a[@class='dropdown-item']//following::div[text()='EDI Tender Will Time-Out']"))
OverideErrorButton=element(by.buttonText("Override"));
CreateButtonOverview=element(by.xpath("//button[@id='btn-create' and  @type='button']"));

//View order page
//FlowmenuDots=element(by.css("[class='pull-right icon-jbh_three-dots mar-top20 mar-left10 font24 cursor-pointer']"));
threedot =element(by.xpath("//h1[@class='alignHeading']//following::*[@placement='bottom'][1]")) 
FlowmenuDots=element(by.xpath("//div[contains(@class,'pull-right icon-jbh_three-dots')]"));
SelectOption=element(by.id("a-processTruck"));
sETapptmntRadio=element(by.id("ipRadioSetNewAppointment"));
WithoutapptmntRadio=element(by.id("ipRadioContinueNewAppointment"));
StndRateRadio=element(by.id("ipRadioStdContractRate"));
NegoRateRadio=element(by.id("ipRadioNegotiatedFee"));
WaivefeeRadio=element(by.id("ipRadioWaiveFee"));
Comment=element(by.id("txtAreaComment"));
Processbutton=element(by.id("btn-tonuProcess"));
//GotItbutton=element(by.id("btn-gotIt"));
//button[@id='btn-gotIt' and @class='btn btn-primary btn-custom']
GotItbutton=element(by.buttonText("Got It"));

//View order sub option
BelowOptions=element.all(by.xpath("//h4[@class='panel-title pull-left']"));
//LoadIds=element(by.xpath("//div[@class='overview ']//div[@class='loads pull-right']//a[contains(text(),'Load')]"));

//LoadIds=element(by.xpath("///div[@class='associateloads details pull-left']//following::div[1]"));

//LoadIds=element(by.xpath("//div[@class='overview ']/div[3]/div/div[2]/p/a"));
//LoadIds=element(by.xpath("//div[@class='associateloads details pull-left']//following::div[1]"));

LoadIds=element(by.xpath("//div[text()='AssociateLoads']//following::div[@class='loads pull-right']"));
//LoadIds=element(by.xpath("//div[@class='router-container']//div[@class='overview ']/div[3]/div/div[2]"));


loadcomment=element(by.id("prePlanCmt"));


//Monitoring page:::
UserNameExpandicon=element(by.id("btn-expand"));
//Searchname=element(by.css("[formcontrolname=\"myUserName\"]"))
Searchname=element(by.xpath("//div[text()='Sri Ragavi Rajasekar']"))
//MonitoringDropdown=element.all(by.xpath("//div[@class='jbh-data-table']//select//option"))
//MonitoringDropdown=element(by.xpath("//div[@class='jbh-data-table']//select")).element(by.css("[value='pending']"));
MonitoringDropdown=element(by.xpath("//select[@class='dropdown mar-bot10']")).element(by.css("[value='pending']"));
//MonitoringDropdown=element(by.xpath("//select[contains(@class,'dropdown')")).element(by.cssContainingText('option','Pending'));
Excepdata=element(by.css("[class='empty-row']"));
ExpandIcon=element.all(by.xpath("//*[@class='pull-right expanded-arrow']"));
VieworderIcon=element(by.id("btn-pageKeyStrk"));
ViewExpandIcon=element(by.id("btn-expand2"));
ParentDivManageView=element.all(by.xpath("//div[@class='manageColumnstask modal-dialog modal-lg']//ul//li"));

//FlowMenuoption=element.all(by.xpath("//span[@title='dropdown menu']//ul//li"));


FlowMenuoption=element(by.xpath("//span[@title='dropdown menu']//following::button[text()='Configure Rule Attribute']"));
//RuleList=element.all(by.xpath("//*[@class='datatable-row-center datatable-row-group']//div//span"));

//RuleList=element(by.xpath("//datatable-scroller[@class='datatable-scroll']/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell/div/span[@title='Appointment Expired']"));
RuleList=element(by.xpath("//div[@class='datatable-row-center datatable-row-group'][1]//following::span[@title='Appointment Expired']"));
//RuleList=element(by.xpath("//datatable-body-cell[@class='datatable-body-cell sort-active']//span[@title='Appointment Expired']"));
//RuleList=element(by.xpath("//span[@title='Appointment Expired']"));

BuDropdown=element(by.xpath("//div[@class='business-group-tag']//following::input[1]"));
BuText=element(by.xpath("//input[@class='form-control ui-select-search']"));

Threedots=element.all(by.css("[id='btn-append-to-body']"));
EditRuleparent=element.all(by.xpath("//ul[@class='dropdown-menu dropdown-menu-right']//li[@class='manageEdit']//a"));
viewName=element(by.css("[placeholder=\"Enter View Name\"]"));
//BilltoSelect=element.all(by.xpath("//*[@class='form-control isNotSelect ng-pristine ng-valid ng-touched']"));
BilltoSelect=element(by.xpath("//*[@class='modal-body']/div/div[2]/div[2]/div/select")).element(by.cssContainingText('option','Is')) 
Selectvalue=element.all(by.css("[placeholder='select']"));
Select=element(by.xpath("//*[@class='modal-body']/div/div[2]/div[2]/div[2]/ng-select/div/input[@role='combobox']"))
savebuttoninRule=element(by.xpath("//*[@class='modal-footer']//following::button[text()='Save']"));


// SignIn=element(by.id("heading1"));
// SignInUser=element(by.css("[placeholder='Email or Username']"));
// SignInPwd=element(by.css("[placeholder='Password']"));
// SignInSubmit=element(by.css("[name='submit']"));





 ////:::SignIn:::////

 SignIn=element(by.id("heading1"));
 SignInUser=element(by.css("[placeholder='Email or Username']"));
 SignInPwd=element(by.css("[placeholder='Password']"));
 SignInSubmit=element(by.css("[name='submit']"));

 allOptions =element.all(by.xpath("//*[@class='inline']//ng-select[@placeholder='Type'][1]")) 
 Statuschange=element(by.xpath("//*[@formcontrolname='orderSearchStatus']//following::input"));
 acceptclose=element(by.xpath("//*[@formcontrolname='orderSearchStatus']//following::a")); 
 orderno=element.all(by.xpath("//*[@placeholder='Name']")); 

 loadComponent=element(by.xpath(""))





//////////////////////////////////////////Update Order Page ///////////////////////////////////////////////////////////////////////////////
        
        
            orderid                =element(by.xpath("//*[text()='Order Overview']//following::span[strong][1]"));
            updateBUSO_btn          =element(by.xpath("//*[text()='Service Offering']//following::div[@class='icon-jbh_edit icon-edit pull-right']"));
            BU_update               = element(by.css("[formcontrolname=\"financeBusinessUnitCode\"]"));
            BU_updateclck           =element(by.xpath("//*[text()='Edit Service Offering']//following::input[@class='form-control ui-select-search'][1]")); 
            SO_update               =element(by.css("[formcontrolname=\"serviceOfferingCode\"]"));
            SO_updateclck            =element(by.xpath("//*[text()='Edit Service Offering']//following::input[@class='form-control ui-select-search'][1]"));
            validateBU                  =element(by.xpath("//*[text()='Business Unit']//following::p[1]"));
            validateSO               = element(by.xpath("//*[text()='Business Unit']//following::p[text()='Service Offering']//following::p[1]"));
        
        
           ///:::Equipment Field Objects::://// 
            
            edit_equipment      =element(by.xpath("//h3[text()='Equipments']//following::div[@class='icon-jbh_edit icon-edit']"));
            equip_category      =element(by.id("equipmentCategory"));   
            equipinput           =element(by.xpath("//input[@placeholder='Equipment Category']"));
            equipsave_Btn        =element(by.xpath("//*[@class='btn btn-primary col-md-3 btns']//button[text()='Save']"));
            save_BUSO            =element(by.xpath("//*[text()='Edit Service Offering']//following::button[text()='Save'][1]"));
            //threedot             =element(by.xpath("//h1[@class='alignHeading']//following::*[@placement='bottom'][1]"));
            //reconsign          =element(by.xpath("//*[text()='Reconsignment']"));
            reconsign            =element(by.id("a-reconsgmt"));
            reason_btn           =element(by.xpath("//*[@formcontrolname='reasonCode']"));
            
            reasoncomnts         =  element(by.css("[formcontrolname=\"reconComments\"]"));
            //submit = element(by.csscontainigtext("[@id='btn-submit']","Submit"));
            createrate_btn        = element(by.xpath("//*[text()='Rate Overview']//following::button[@id='btn-create'][1]"));
            overall_hdr         =element(by.xpath("//*[text()='OVERALL']"));
            chckbox              =element(by.id("checkx"));
            level                = element(by.css("[formcontrolname=\"chargeLevelTypeCode\"]"));
            amntfield            =element(by.id("amountField"));


           
            
            ////:::Order History:::////
            hstrybtn    =   element(by.xpath("//*[text()='Order History']"));
            hstrytable  =   element(by.xpath("//*[@class='datatable-body']"));
            cnt = element.all(by.xpath("//*[@class='datatable-row-center datatable-row-group']"))
            WarningsOveridden=element(by.xpath("//span[text()='Warnings Override:']//following::a[1]"));
            AcceptanceRulepass=element(by.xpath("//span[text()='Acceptance Rules:']//following::span[text()='Pass']"));
            Orderstatus=element(by.xpath("//span[text()='Order Status Change']//following::span[text()='Accepted']"));
 ////////////////////////////////////////////////////////// Automation Rules Page ///////////////////////////////////////////////////////////////////////////////


            
            // togglefield         =element(by.css("[class=\"fa fa-circle-o\"]")); 
            // dbOption            =element(by.cssContainingText('.routeDisplayText','System Automation Rules'));
            // searchoption        =element (by.cssContainingText('.routeDisplayText','Advanced Search'));
            // Flowmenu            =element(by.css("[id=\"btn-append-to-body\"]"));
            Rulename            = element(by.xpath("//*[text()='Rule Name']"));
         filter_clk             =element(by.css('[id="span-jbhFilt"]'));
         template_filter        =element(by.css('[id="span-filter"]'));

         association_clk        =element(by.xpath("//div[@class='panel-heading']//h5[span[text()='Association Level ']]"));
         //association_clk        =element(by.xpath("//h5[text()='Association Level']"));
         
         status_clk             =element(by.xpath("//div[@class='panel-heading']//h5[span[text()='Status ']]"));
         //status_clk             =element(by.xpath("//h5[text()='Status']"));
         
         active_cb             =element(by.xpath("//*[text()='Active']/preceding-sibling::input[@id='fltChkActive0']"));
         BU_cb                 =element(by.xpath("//*[text()='Business Unit']/preceding-sibling::input[@name='filterChkBx']"));
         threedot_btn          =element.all(by.xpath("//span[text()='DCS']//following::span[@id='span-3dots'][1]"));
         threedot_btn1         =element.all(by.xpath("//span[text()='DCS, JBI']//following::span[@id='span-3dots'][1]"));
            view_btn           =element(by.id("vieweditrule"));
            BU_btn             =element(by.xpath("//*[@formcontrolname='businessUnit']"));
            BU_list            =element.all(by.xpath("//ul[@class='ui-select-choices dropdown-menu']//li//a "));
           // Save_Btn         =element(by.id("btnSave"));
           Save_Btn            =element(by.xpath("//button[@id='btnSave']"));
            Inactivate_btn     =element(by.id("inactivaterule"));
            copyrule           =element(by.id("copyrule"));
            routeplan          =element(by.xpath("//h4[text()='Route Plan']"));
            load               =element(by.xpath("//span[text()='Active Load']//following::a[1]"));
            ratesheet          =element(by.xpath("//h4[text()='Rate Sheet']"));
            rate_level         =element(by.xpath("//*[text()='Rate Information']//following::span[span][2]"));
            rate_edit          =element(by.xpath("//*[text()='Rate Information']//following::span[span][2]")); 
            Routeplan=element(by.xpath("//h4[text()='Route Plan']"))
            Shippingpage=element(by.xpath("//div[@class='capacityHed']"));
            SelectFirstorder            =element.all(by.xpath("//div[@class='datatable-row-center datatable-row-group']//following::div[@class='GridRowSpanStyle']//h6"));
            Destin                      =element(by.css("[placeholder='Destination Marketing Area']"));


            //itemchar            =element(by.xpath("//input[@placeholder='Item Characteristics']"));
            itemchar_type            =element(by.xpath("//*[@placeholder='Item Characteristics']"));
            unnacode            =element(by.xpath("//*[@id='unnaCode']"));
            shippingname        =element(by.xpath("//span[text()='Proper Shipping Name']"));
            stopbox             =element(by.css('[formcontrolname="locationID"]'));
            primary             =element(by.xpath("//span[text()='Primary Hazard Class']"));
            secondary       =element(by.xpath("//span[text()='Secondary Hazard Class']"));
            ApntdatepickupAdvanced=element(by.xpath("//datatable-body-cell[@class='datatable-body-cell sort-active'][4]/div/h6/p[1]"));
            ApntdatedeliveryAdvanced=element(by.xpath("//datatable-body-cell[@class='datatable-body-cell sort-active'][5]/div/h6/p[1]"));
            PickDateorderOverview=element(by.xpath("//div[text()='Scheduled Appointment']//following::span[1]"));
            DelidateorderOverview=element(by.xpath("//div[text()='Scheduled Appointment']//following::span[2]"));
            Buttontext=element.all(by.tagName("button"))
            calendarvalue=element.all(by.xpath("//span[@class='mydpicon icon-mydpremove']"));
            Timevalue=element.all(by.xpath("//input[@placeholder='HH']"));
            TimeMinvalue=element.all(by.xpath("//input[@placeholder='MM']"));
            dayTab=element(by.buttonText("1-6 Days"));
            //equipment
            equipcategory   =element.all(by.xpath("//*[@formcontrolname='equipmentCategoryCode']"));
            equipcategorytext=element(by.xpath("//input[@placeholder='Equipment Category']"));
            equiptypecode   =element.all(by.xpath("//*[@id='equipmentTypeCode']"));
            equiplength     =element.all(by.xpath("//*[@formcontrolname='equipmentLengthCode']"));
            ordernumber = element(by.className("ordernumber"));
            // BU=element(by.css("[formcontrolname=\"financeBusinessUnitCode\"]"));
            // BUclick=element(by.xpath("//input[@placeholder='Business Unit']"));
            // BUValue=element(by.xpath("//*[@id='financeBusinessUnitCode']//ul//a/div"));





 //AcceptanceRulepass=element(by.xpath("//span[text()='Acceptance Rules:']//following::span[text()='Pass']")); 

            freightcharges=element(by.id("freightChargeTermTypeCode"));
            freightchargestext=element(by.xpath("//input[@placeholder='Freight Charge Terms']"));
            trailernobutton=element(by.buttonText("Trailer Number"));
            Trailernumber=element(by.xpath("//input[@placeholder='Trailer Number']"));
            Trailerprefix=element(by.xpath("//span[text()='Trailer Prefix']"));
            TrailerPrefixText=element(by.xpath("//input[@placeholder='Trailer Prefix']"));
            ShipmentIdentificationNo=element(by.xpath("//input[@placeholder='Shipment Identification']"));
            shipsecndarytype=element(by.id("orderSubTypeCode"));
            shipsecndarytypetext=element(by.xpath("//input[@placeholder='Secondary Order Type']"));
            ordervalue=element(by.id("order-value"));
            fleetcode=element(by.id("fleetCode"));
            
            apnmntHR=element.all(by.id("hours"));
            apnmntMIN=  element.all(by.id("minutes"));
            //AcceptanceRulepass= element(by.xpath("//span[text()='Acceptance Rules:']//following::span[1]"));
            
            //Orderstatus=    element(by.xpath("//span[text()='Order Status Change']//following::span[text()='Accepted']"));
            scac       =    element(by.xpath("//*[@placeholder='SCAC']"));
            scacsearch =    element(by.xpath("//span[text()='SCAC ']"));
            //scactext    =   element(by.xpath("//span[text()='SCAC ']//following::div[input[@placeholder='Search']][1]"));
            scactext    =   element(by.xpath("//div[@class='panel-heading']//span[text()='SCAC ']//following::input[1]"))
            scacenter   =   element(by.xpath("//div[@class='panel-heading']//span[text()='SCAC ']//following::span[1]"))
            three_dotOtr    =   element.all(by.xpath("//span[text()='OTR']//following::button[@id='btn-popOver']"));
            three_dotInter    =   element.all(by.xpath("//span[text()='Intermodal']//following::button[@id='btn-popOver']"));
            three_dotLTL   =   element.all(by.xpath("//span[text()='LTL']//following::button[@id='btn-popOver']"));
            ViewTemplate = element(by.xpath("//a[text()='View Template']"));
            copy_view   =   element.all(by.xpath("//span[text()='OTR']//following::button[@id='btn-popOver']//following::div/ul/li/a']"));
            threedot_temp   =element(by.xpath("//button[@id='btn-popOver']"));
            tempdrop        =element.all(by.xpath("//button[@id='btn-popOver']//following::div/ul/li/a[text()='Create Order']"));
            apnmt_ordovrview    =element(by.xpath("//div[text()='Scheduled Appointment ']//following::span[1]/span[1]"));
            apnmt_stop          =element(by.xpath("//span[text()='Origin']//following::span[@class='pad0 font-styles'][1]"));
            Utilitiesicon=element(by.id("a-SaveDirections"));
            toollist=element.all(by.xpath("//tabset//ul[@class='nav nav-tabs']//li//i"));
            addComment=element(by.css("[formcontrolname='commentLevel']"));
            addCommenttext=element(by.xpath("//*[@id='commentLevel']//div//input"));
            templateType=element(by.xpath("//*[@id='span-optional']//following::div[1]//div[1]//span[1]//span"));
            templatetypetext=element(by.xpath("//*[@id='span-optional']//following::div[1]//div[1]//input[1]"));
            Commenttext=element(by.css("[formcontrolname='commentTxtarea']"));
            Savebutton=element.all(by.buttonText("Save"));
            SavebuttonCommnt=element(by.xpath("//textarea[@formcontrolname='commentTxtarea']//following::button[text()='Save'][1]"));
            //appointmentconf=element(by.xpath("//p[text()='Appointment Confirmed']"));
            addedutilityref=element(by.xpath("//div[@class='ps-content']//div//span[@class='instItmLvldesc']//p"));
            apntEditcmnt=element(by.xpath("//*[@class='editDisable editEnable']"));
            apntEditRef=element(by.xpath("//h4[text()='Order']//following::div[1]/div"));
            
            UtilEditCharge=element(by.xpath("//strong[text()='ORDER']"));
            //apntEditRef=element(by.xpath("//h4[text()='Order']//following::div[@class='utility-font']")); 
            utilityDelete=element(by.css("[id='a-delete']"));
            utilityedit=element(by.css("[id='a-edit']"));
            Utilrefdelete=element(by.xpath("//h4[text()='Order']//following::div[1]/div//a[@id='a-delete']"));
            UtilrefEdit=element(by.xpath("//h4[text()='Order']//following::div[1]/div//a[@id='a-edit']"));
            Utilchargedelete=element(by.xpath("//strong[text()='ORDER']//following::a[@id='a-delete']"));
            UtilChargeEdit=element(by.xpath("//strong[text()='ORDER']//following::a[@id='a-edit']"));
            
            
            //reference
           // ReferenceType=element(by.css('[id="RefType"]')).element(by.cssContainingText('option','Appointment Number'));
            Refercmnt=element(by.xpath("//input[@placeholder='Reference value']"));
            ReferenceType=element(by.css('[id="RefType"]')).element(by.cssContainingText('option','Appointment Number'));
            ReferenceType1=element(by.css('[id="RefType"]')).element(by.cssContainingText('option','Bill of Lading'))
           // Refercmnt=element(by.xpath("//input[@placeholder='Reference value']"));
            //Addbutton=element(by.buttonText("Add"));
            //Addbutton=element.all(by.xpath("//button[@class='btn-dark-primary']"));
         savebutton1=element.all(by.xpath("//label[text()='Reference Value']//following::button[@class='btn-dark-primary'][1]"));
           // Addbuttoncharge=element.all(by.xpath("//button[@id='btn-add' ]"));

            //Addbutton=element(by.buttonText("Add"));
            Addbutton=element.all(by.xpath("//button[text()='Add']"));
            Addbuttoncharge=element.all(by.xpath("//button[@id='btn-add' ]"));
            //charge
            Chargelevel=element(by.css('[formcontrolname="chargeLevelTypeCode"]')).element(by.cssContainingText('option','ORDER'));
            chargecode=element(by.id("chargeDescriptionTxt"));
            chargeamount=element(by.id("chargeUnitRateAmountTxt"));
            chargequantity=element(by.id("chargeQuantityTxt"));
            authno=element(by.id("customerAuthorizationNumberTxt"));
            authby=element(by.id("customerAuthorizationFirstNameTxt"));
            originstopedit=element(by.xpath("//span[text()='Origin']//following::span[@id='span-ritArr'][1]"));
            pickupstopedit=element(by.xpath("//span[text()='Origin']//following::span[@id='span-ritArr'][2]"));
            editbtn = element(by.id("span-jbhedit"));
            requestedservices=element(by.xpath("//h3[text()='Requested Service(s)']//following::input[@role='combobox'][1]"));
            miles = element(by.xpath("//button[@id='btn-info']//following::div[@class='col-md-1']/span"));
            TotalMiles=element(by.xpath("//span[text()='Total Miles']//following::span[1]"));
            
            //Multiple stops
            stopdots=element(by.css("[class='dots-span']"));
            
            stopdotstemplate=element(by.css("[id='span-locDetails']"));
            addstop=element(by.xpath("//a[text()='Add Stop']"));;
            stopstitle=element.all(by.xpath("//div[@class='accordion-toggle']"));
            expandicon=element.all(by.xpath("//i[@class='glyphicon accordianIcon icon-jbh_expand']"));
            expandiconTemplate=element.all(by.xpath("//i[@class='glyphicon accordianIconCustomize textBold icon-jbh_expand']"));
            StopReason=element(by.id("stopReason"));
            StopReasonText=element(by.xpath("//li/div/a/div[text()='Pickup']"));

            interservice=element(by.id("serviceType"));
            interservicetext=element(by.xpath("//*[@id='serviceType']//span[@class='ui-select-match']//following::input[1]"));
            inbondToggle=element(by.xpath("//*[@for='inbond-freight' and @class='jbh-toggle-label']"));
            shipmentreq=element(by.id("shipment-requirement"));
            shipmentreqText=element(by.xpath("//*[@id='shipment-requirement']//span[@class='ui-select-match']//following::input[1]"));
            //Shipping option page:
            CreateWithoutrTE=element(by.css("[id='a-createWithoutRate']"));
            RateReason=element(by.xpath("//p[text()='No Rates Available.']//following::select")).element(by.cssContainingText('option','Pending Manual Quote From Pricing Manager')); 
///CCCi Page::::
  
CCi_Search =element(by.xpath("//input[@placeholder='Search by Address, Account Name, Phone Number or Business Identifier']"));
SelectFirstResult=element(by.xpath("//div[@class='datatable-row-center datatable-row-group'][1]/datatable-body-cell[1]"));
Credittab=element(by.xpath("//span[text()='Credit']"));
CreditStatusEditIcon=element(by.xpath("//i[@class='icon-jbh_edit']"));
 CreditSelectClick=element(by.xpath("//ng-select[@formcontrolname='selectedStatus']")); 
 CreditApproved=element(by.xpath("//ng-select[@formcontrolname='selectedStatus']/div[1]/ul/li[1]//a")); 
 CreditDenied=element(by.xpath("//ng-select[@formcontrolname='selectedStatus']/div[1]/ul/li[2]//a")); 
 CreditScore =element(by.xpath("//input[@formcontrolname='overAllCreditScore']"));
 OrderFlowMenu=element(by.xpath("//h1[@class='alignHeading']//following::div[1]"));
 //a[text()='Reject Order']
 RejectOrder=element(by.xpath("//a[text()='Reject Order']"));
 RejectReason=element(by.xpath("//ng-select[@formcontrolname='rejectOption']"));
 RejectComments=element(by.xpath("//textarea[@formcontrolname='rejectComments']"));
 username= element(by.id("j_username"));
 password= element(by.id("j_password")); 
 loginbutton=element(by.xpath("//input[@value='login']"));

////////////////////////////////////////////////////backfill//////////////////////////////////////////

            //BUval = element(by.xpath("//*[text()='Business Unit']//following::p[1]"));
            BUval  = element(by.xpath("//span[text()='Service Offering']//following::strong[1]"));
            Servicelvl=element(by.xpath("//span[text()='Service Level']//following::span"));
            TrailerNum = element(by.xpath("//p[text()='Trailer']//following::p[1]"));
            Billtoval = element(by.xpath("//strong[text()='Bill to Account']//following::div[1]/div[1]"));
            ShipperVal=element(by.xpath("//h4[text()='Origin ']//following::div[1]/div[1]"));
            RecieverVal=element(by.xpath("//h4[text()='Destination ']//following::div[1]/div[1]"));
            totalmiles = element(by.xpath("//*[text()='Total Miles']//following::span[1]"));

            /////EOM
            Loadid =    element(by.id("eomSearchMain:baseSearchVal"));
            loadlink= element(by.id("frmOrderListing:lOrderListing:0:optxtOrderNumberActionFocusLink"));
            loaddetail=element(by.id("eomOrderDetail:orderDetailminimizer"));
            stopdetails=element(by.id("eomOrderDetail:nonStopsminimizer"));
            BUdivision=element(by.xpath("//*[@id='eomOrderDetail:divisionlist']/option[@selected='selected']"));
            Billtovaleom = element(by.id("eomOrderDetail:billto"));
            mileeom = element(by.id("eomOrderDetail:ttlMiles"));

            //Template search
            Billtosearch=element(by.id("billToVal"));
            OriginSearch=element(by.id("originVal"));
            DestinationSearch=element(by.id("destinationVal"));
            SearchIcon=element(by.id("span-search"));
            TempalteDots=element(by.id("btn-popOver"));

            


            

        //     statuschange        =element(by.xpath("//*[@formcontrolname='orderSearchStatus']//following::input"));
        //     //OrdersearchBU     =element(by.css("[formcontrolname=\"orderSearchBusinessUnit\"]"));
        // OrdersearchBU           =element(by.xpath("//*[@id='ngSelOrderSearchBusinessUnit']//span[text()='Business Unit']"));
            
        //     //OrderSearchSO     =element(by.css("[formcontrolname=\"orderSearchServiceOffering\"]"));
        //     OrderSearchSO       =element(by.xpath("//*[@id='ngSelOrderSearchServiceOffering']//span[text()='Service Offering']"));
            
        //     busearch             =element(by.css("[formcontrolname=\"orderSearchBusinessUnit\"]")).element(by.xpath("//input[@placeholder='Business Unit']"));
        //     Sosearch             =element(by.css("[formcontrolname=\"orderSearchServiceOffering\"]")).element(by.xpath("//input[@placeholder='Service Offering']"));
        // SelectFirstorder        =element.all(by.xpath("//div[@class='datatable-row-center datatable-row-group']//following::div[@class='GridRowSpanStyle']//h6")); 
        // SearchButton            =element(by.buttonText("Search")); 



        // accountname                 =element(by.xpath("//*[@placeholder='Name'][1]"));
        
        // accountnameselect           =element(by.xpath("///ul[@class='dropdown-menu']//li[@class='active']//a"));
        // SearchButton                =element(by.buttonText("Search"));
        // Status                      =element(by.xpath("//ng-select[@id='tagIpOrderSearchStatus']//span//a"));
        
        // Showmore                        =element(by.css("[id='orderSearchShowMore']"));
        
        // Statuschange                    =element(by.xpath("//*[@formcontrolname='orderSearchStatus']//following::input"));
        // //OrdersearchBU             =element(by.css("[formcontrolname=\"orderSearchBusinessUnit\"]"));
        // OrdersearchBU               =element(by.xpath("//*[@id='ngSelOrderSearchBusinessUnit']//span[text()='Business Unit']"));
        
        // //OrderSearchSO             =element(by.css("[formcontrolname=\"orderSearchServiceOffering\"]"));
        // OrderSearchSO               =element(by.xpath("//*[@id='ngSelOrderSearchServiceOffering']//span[text()='Service Offering']"));
        
        // busearch                    =element(by.css("[formcontrolname=\"orderSearchBusinessUnit\"]")).element(by.xpath("//input[@placeholder='Business Unit']"));
        // Sosearch                    =element(by.css("[formcontrolname=\"orderSearchServiceOffering\"]")).element(by.xpath("//input[@placeholder='Service Offering']"));
         
        // BUclick                     =element(by.xpath("//input[@placeholder='Business Unit']")); 
        // SOclick                     =element(by.xpath("//input[@placeholder='Service Offering']")); 
        // adv_title                   =element(by.xpath("//*[text()='Account']"));
        // Viewpage                    =element(by.xpath("//h4[text()='Order Overview']"));

        
}   