/* tslint:disable */
import { ElementFinder, browser, by, element } from "protractor";
describe("Account Creation and Search ", () => { // suite in Jasmine
  it("Should Have a Title To be Verified", () => {
     
     // console.log((<any>data).SearchAccountDetails);
    
     // browser.get(page.Call_url());
      
    browser.get("http://account-tst.jbhunt.com/account/");
 });
it("Should Navigate To Account Page", () => {
    //console.log(page.btn_navtoggle);
   
     //element(by.css(page.obj_NavigationToggle())).click();
    // element(by.css(page.obj_NavigationToggle())).click();
   element(by.css("[class=\"fa fa-circle-o\"]")).click();
   element(by.className(""));
browser.executeScript("window.scrollBy(-2000, 0)");
    //page.lst_NavigationList.click();
    
  //element.all(by.cssContainingText(".routeDisplayText","Account")).click();
});
});