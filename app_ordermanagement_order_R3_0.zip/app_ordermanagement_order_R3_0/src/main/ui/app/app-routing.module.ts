import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { ErrorPageComponent, ErrorsModule } from 'jbh-components/errors';
import { RouteGuard } from 'jbh-components/jbh-esa';

const routes: Routes = [
  {
    path: 'dashboard',
    loadChildren: 'app/features/dashboard/dashboard.module#DashboardModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Dashboard',
      pathIcon: 'icon-jbh_home pull-right',
      order: 1
    },
    canActivate: [RouteGuard]
  },
  {
    path: 'createorders',
    loadChildren: 'app/features/create-orders/create-orders.module#CreateOrdersModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Create Order',
      pathIcon: 'icon-jbh_add pull-right',
      order: 1
    },
    canActivate: [RouteGuard]
  },
  {
    path: 'shippingoptions',
    loadChildren: 'app/features/shipping-options/shipping-options.module#ShippingOptionsModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Shipping Options',
      pathIcon: 'icon-jbh_list pull-right',
      order: 1
    },
    canActivate: [RouteGuard]
  },
  {
    path: 'tasks',
    loadChildren: 'app/features/monitoring/exception-management/exception-management.module#ExceptionManagementModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Tasks',
      pathIcon: 'icon-jbh_clipboard pull-right',
      order: 1
    },
    canActivate: [RouteGuard]
  },
  {
    path: 'viewhistory',
    loadChildren: 'app/features/monitoring/view-screens/view-screen.module#ViewScreenModule',
    canActivate: [RouteGuard]
  },
  {
    path: 'automationrules',
    loadChildren: 'app/features/automation-rules/automation-rules.module#AutomationRulesModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'System Automation Rules',
      pathIcon: 'icon-jbh_multi_item pull-right',
      order: 1
    },
    canActivate: [RouteGuard]
  },
  {
    path: 'exceptionmaintenance',
    loadChildren: 'app/features/monitoring/exception-maintenance/exception-maintenance.module#ExceptionMaintenanceModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Exception Maintenance',
      pathIcon: 'icon-jbh_tool pull-right',
      order: 1
    },
    canActivate: [RouteGuard]
  },
  {
    path: 'customerrules',
    loadChildren: 'app/features/automation-rules/automation-rules.module#AutomationRulesModule',
    canActivate: [RouteGuard]
  },
  {
    path: 'vieworder',
    loadChildren: 'app/features/view-order/view-order.module#ViewOrderModule',
    canActivate: [RouteGuard]
  },
  {
    path: 'opportunities',
    loadChildren: 'app/features/opportunity-orders/opportunity-orders.module#OpportunityOrdersModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Opportunities',
      pathIcon: 'icon-jbh_thumbs_up pull-right',
      order: 1
    },
    canActivate: [RouteGuard]
  },
  {
    path: 'ordersearch',
    loadChildren: 'app/features/order-search/order-search.module#OrderSearchModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Advanced Search',
      pathIcon: 'icon-jbh_search pull-right',
      order: 1
    },
    canActivate: [RouteGuard]
  },
  {
    path: 'changerequest',
    loadChildren: 'app/features/change-request/change-request.module#ChangeRequestModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Change Requests',
      pathIcon: 'icon-jbh_add pull-right',
      url: '/changerequest',
      order: 1
    },
    canActivate: [RouteGuard]
  }, {
    path: 'managereference',
    loadChildren: 'app/features/manage-reference-data/manage-reference-data.module#ManageReferenceDataModule'
  },
  {
    path: 'managereference',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Manage Reference Data',
      pathIcon: 'icon-jbh_list pull-right',
      order: 1,
      url: '/managereference'
    },

    children: [{
      path: 'services',
      loadChildren: 'app/features/manage-reference-data/manage-reference-data.module#ManageReferenceDataModule',
      data: {
        createSidebarEntry: true,
        pathDisplayText: 'Services',
        order: 1,
        url: '/services'
      }
    },
    {
      path: 'internationalinformation',
      loadChildren: 'app/features/manage-reference-data/manage-reference-data.module#ManageReferenceDataModule',
      data: {
        createSidebarEntry: true,
        pathDisplayText: 'Internation Information',
        order: 1,
        url: '/internationalinformation'
      }
    }, {
      path: 'handlingtypeinformation',
      loadChildren: 'app/features/manage-reference-data/manage-reference-data.module#ManageReferenceDataModule',
      data: {
        createSidebarEntry: true,
        pathDisplayText: 'Handling Type Information',
        order: 1,
        url: '/handlingtypeinformation'
      }
    }, {
      path: 'referencenumber',
      loadChildren: 'app/features/manage-reference-data/manage-reference-data.module#ManageReferenceDataModule',
      data: {
        createSidebarEntry: true,
        pathDisplayText: 'Reference Number Types',
        order: 1,
        url: '/referencenumber'
      }
    }, {
      path: 'trailingequipment',
      loadChildren: 'app/features/manage-reference-data/manage-reference-data.module#ManageReferenceDataModule',
      data: {
        createSidebarEntry: true,
        pathDisplayText: 'Trailing Equipment Profile',
        order: 1,
        url: '/trailingequipment'
      }
    }],
    canActivate: [RouteGuard]
  },
  {
    path: 'serviceguide',
    loadChildren: 'app/features/service-guide-maintenance/service-guide-maintenance.module#ServiceGuideMaintenanceModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Service Guide',
      pathIcon: 'icon-jbh_add pull-right',
      order: 1,
      url: '/serviceguide'
    },
    canActivate: [RouteGuard]
  },
  {
    path: 'manageratesheet',
    loadChildren: 'app/features/manage-rate-sheet/manage-rate-sheet.module#ManageRateSheetModule',
    canActivate: [RouteGuard]
  },
  {
    path: 'loadinformation',
    loadChildren: 'app/features/load-information/load-information.module#LoadInformationModule',
    canActivate: [RouteGuard]
  },
  {
    path: 'orderplan',
    loadChildren: 'app/features/order-plan/order-plan.module#OrderPlanModule',
    canActivate: [RouteGuard]
  },
  {
    path: 'viewucr',
    loadChildren: 'app/features/view-ucr/view-ucr.module#ViewUcrModule',
    canActivate: [RouteGuard]
  },
  {
    path: 'customerappointmentscheduling',
    loadChildren: 'app/features/customer-appointment-scheduling/customer-appointment-scheduling.module#CustomerAppointmentSchedulingModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Customer Appointment Scheduling',
      pathIcon: 'icon-jbh_add pull-right',
      order: 1,
      url: '/customerappointmentscheduling'
    },
    canActivate: [RouteGuard]
  },
  {
    path: 'consumerappointmentscheduling',
    loadChildren: 'app/features/consumer-appointment-scheduling/consumer-appointment-scheduling.module#ConsumerAppointmentSchedulingModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Consumer Appointment Scheduling',
      pathIcon: 'icon-jbh_add pull-right',
      order: 1,
      url: '/consumerappointmentscheduling'
    },
    canActivate: [RouteGuard]
  },
  {
    path: 'summary',
    loadChildren: 'app/features/monitoring-summary/monitoring-summary.module#MonitoringSummaryModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Monitoring Summary',
      pathIcon: 'icon-jbh_report_perfomance pull-right',
      order: 1,
      url: 'tasks/customerappointmentscheduling'
    },
    canActivate: [RouteGuard]
  },
  {
    path: 'error/:status',
    component: ErrorPageComponent
  },
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
  { path: '**', redirectTo: 'error401' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes),
  ErrorsModule.forRoot()],
  exports: [RouterModule],
  providers: [RouteGuard]
})

export class AppRoutingModule { }
