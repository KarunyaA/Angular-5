import { Component, EventEmitter, HostListener, NgZone, OnInit, Output } from '@angular/core';
import {
    Event as RouterEvent, NavigationCancel, NavigationEnd,
    NavigationError, NavigationStart, Router
} from '@angular/router';
import { Location } from '@angular/common';
import { SpinnerService } from 'jbh-components/spinner';
import { BusinessUnitService, ProfileService, UserService } from 'jbh-components/jbh-esa';

import { JBHGlobals } from './app.service';

declare var JBH360Platform: any;
window.focus();

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.scss']
})

export class AppComponent implements OnInit {
    // @Output() overlayShowEvent: EventEmitter<boolean> = new EventEmitter<boolean>();
    @Output() notificationEvent: EventEmitter<boolean> = new EventEmitter<boolean>();

    sidebarLock: boolean;
    navIconClicked: false;
    isSidebarOpen: boolean;
    loading: any = true;
    commonData: any;
    options: object;
    sidebarLockRight: boolean;
    showWindow: any = false;
    isAppHeaderHidden: any = true;
    isShowToolsHidden: any = true;
    logoutClk: any;
    isShowHeader: boolean;
    showOverLayIcon: boolean;

    constructor(
        private router: Router,
        location: Location,
        private jbhGlobals: JBHGlobals,
        private spinnerService: SpinnerService,
        private ngZone: NgZone,
        private profileService: ProfileService,
        private userService: UserService,
        public businessUnitService: BusinessUnitService) {
        jbhGlobals.logger.info('Approot  initialized');
        this.loadWebSocketTopicName();
    }

    ngOnInit(): void {
        this.isShowHeader = true;
        this.setUserPage(this.jbhGlobals.user.getAuthenticationStatus());
        this.businessUnitService.loadBusinessUnit(this.jbhGlobals.endpoints.order.getbusinessunit);
        this.router.events.subscribe((event: any) => {
            this.navigationInterceptor(event);
            if (!this.jbhGlobals.utils.isEmpty(this.router.url.split('?')) &&
                ((this.router.url.split('?')[0] === '/createorders/order/create') ||
                    (this.router.url.split('?')[0] === '/createorders/order/addstops') ||
                    (this.router.url.split('?')[0] === '/createorders/template/create') ||
                    (this.router.url.split('?')[0] === '/createorders/template/addstops') ||
                    (this.router.url.split('?')[0] === '/createorders/template/viewedit') ||
                    (this.router.url.split('?')[0] === '/createorders/template/vieweditstops') ||
                    (this.router.url.split('?')[0] === '/createorders/template/copy') ||
                    (this.router.url.split('?')[0] === '/createorders/template/copystops') ||
                    (this.router.url.split('?')[0] === '/vieworder'))) {
                this.showOverLayIcon = true;
            } else {
                this.showOverLayIcon = false;
            }
        });
        this.options = this.jbhGlobals.settings.notificationsOptions;
        this.jbhGlobals.commonDataService.getData().subscribe((data: any) => this.commonData = data);
        this.loadUserRolesAndTasks();
        this.isShowHeader = false;
        this.initHeader();
        this.manageOverlayToggle();
    }

    @HostListener('window:keyup', ['$event'])
    keyboardInput(event: any): void {
        console.log(this.jbhGlobals.shortkeys.getKeyCode(event));
        this.jbhGlobals.shortkeys.saveData({
            keyCode: this.jbhGlobals.shortkeys.getKeyCode(event),
            eventElement: event.target
        });
    }

    @HostListener('window:click', ['$event'])
    trackAppClick(event: Event): void {
        this.jbhGlobals.mouseevents.saveData({
            target: this.jbhGlobals.mouseevents.getTarget(event)
        });
    }

    loadWebSocketTopicName(): void {
        let topicSubscription: any;
        topicSubscription = this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.shippingoptions.getTopicName)
            .subscribe((data: any) => {
                if (data) {
                    this.jbhGlobals.localStore.setItem('webSocket', 'topicName', data['topic'], false);
                }
                topicSubscription.unsubscribe();
            }, (err: Error) => {
                topicSubscription.unsubscribe();
            });
    }
    manageOverlayToggle(): void {
        this.showWindow = !this.showWindow;
        const overlayFlag: object = { 'headerOverlay': this.showWindow };
        // this.overlayShowEvent.emit(this.showWindow);
        this.jbhGlobals.commonDataService.saveData(overlayFlag);
    }

    toggleMobleSidebar(e: any): void {
        this.isSidebarOpen = e;
        this.sidebarLock = e;
    }

    onLockSideBarRight(event: any): void {
        this.sidebarLockRight = event;
    }

    showRightNavigation(event: any): void {
        this.navIconClicked = event;
        if (event === false) {
            this.sidebarLockRight = false;
        }
    }
    onLockSideBar(e: any): void {
        this.sidebarLock = e;
    }

    setUserPage(status: number): void {
        switch (status) {
            case 200: break;
            case 401:
            case 404:
            case 500: this.router.navigateByUrl(`error/${status}`); break;
            default: this.router.navigateByUrl('error/401'); break;
        }
    }

    navigationInterceptor(event: RouterEvent): void {
        if (event instanceof NavigationStart) {
            this.jbhGlobals.logger.log('Naviagation start');
            this.jbhGlobals.apiService.requestCount = 0;
            this.spinnerService.spinnerText = 'Loading Page Components ...';
            if (!this.spinnerService.showStatus) {
                this.spinnerService.show();
            }
            this.jbhGlobals.notifications.remove();
        } else if (event instanceof NavigationEnd) {
            this.jbhGlobals.logger.log('Naviagation end');
            if (this.jbhGlobals.apiService.requestCount === 0) {
                this.spinnerService.hide();
            }
        } else if (event instanceof NavigationCancel) {
            this.jbhGlobals.logger.log('Naviagation NavigationCancel');
            this.spinnerService.hide();
            this.jbhGlobals.apiService.requestCount = 0;
        } else if (event instanceof NavigationError) {
            this.jbhGlobals.logger.log('Naviagation NavigationError');
            this.spinnerService.hide();
            this.jbhGlobals.apiService.requestCount = 0;
        }
    }

    loadUserRolesAndTasks(): void {
        this.profileService.loadUserRolesAndTasks(this.jbhGlobals, this.userService);
    }
    private initHeader(): void {
        const config: object = {
            hamburgerClickFunction: (): void => {
                this.ngZone.run(() => {
                    this.isSidebarOpen = !this.isSidebarOpen;
                    this.toggleMobleSidebar(this.isSidebarOpen);
                });
            }
        };
        try {
            JBH360Platform.init(config);
        } catch (error) {
            this.isAppHeaderHidden = false;
            this.isShowHeader = true;
        }
    }
}
