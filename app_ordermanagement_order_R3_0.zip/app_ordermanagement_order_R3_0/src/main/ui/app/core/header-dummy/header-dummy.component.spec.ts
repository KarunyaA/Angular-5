import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HeaderDummyComponent } from './header-dummy.component';

describe('HeaderDummyComponent', () => {
  let component: HeaderDummyComponent;
  let fixture: ComponentFixture<HeaderDummyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HeaderDummyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HeaderDummyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
