import { Component, EventEmitter, Input, OnChanges, OnInit, Output } from '@angular/core';
import { NotificationListComponent } from '../notifications/notification-list/notification-list.component'

@Component({
  selector: 'jbh-sidebar-right',
  templateUrl: './sidebar-right.component.html',
  styleUrls: ['./sidebar-right.component.scss']
})
export class SidebarRightComponent implements OnInit, OnChanges {
  @Input() navIconProb: boolean;
  @Output() sidebarLockRightEvent: EventEmitter<boolean> = new EventEmitter<boolean>();
  sidebarOpenRight = false;
  navIconProbstring: string;
  sidebarLocked = false;
  constructor() { }
  onLockSidebar(): void {
    this.sidebarLocked = !this.sidebarLocked;
    this.sidebarLockRightEvent.emit(this.sidebarLocked);
    if (this.sidebarLocked) {
      this.sidebarOpenRight = true;
    } else {
      this.navIconProb = !this.navIconProb;
    }
  }
  getSidebarLockIcon(): any {
    return this.sidebarLocked ? 'fa fa-stop-circle-o' : 'fa fa-circle-o';
  }
  ngOnInit() { }
  ngOnChanges() {
    // this.navIconProbstring = this.navIconProb.toString().trim();
    this.sidebarLocked = !this.navIconProb;
  }
  // notificationClose(e) {
  //   console.log(e);
  // }

}
