import { Component, OnInit } from '@angular/core';
import { JBHGlobals } from '../../../app.service';
import { TaskListService } from './services/task-list.service';

@Component({
  selector: 'app-task-list',
  templateUrl: './task-list.component.html',
  styleUrls: ['./task-list.component.scss'],
  providers: [TaskListService]
})
export class TaskListComponent implements OnInit {
  result: any;
  constructor(private jbhGlobals: JBHGlobals, private taskListService: TaskListService) { }
  ngOnInit() {
    this.getTaskList();
  }
  getTaskList() {
    // this.taskListService.getTaskList().subscribe(resFetchData => this.result = resFetchData);
    this.result = [];
  }
}
