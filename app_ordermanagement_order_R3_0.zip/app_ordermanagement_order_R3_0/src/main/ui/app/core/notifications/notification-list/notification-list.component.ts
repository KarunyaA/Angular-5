import { Component, OnDestroy, OnInit } from '@angular/core';
// import { MomentModule } from 'angular2-moment';
import { JBHGlobals } from '../../../app.service';
import { SearchFilterPipe } from '../search-filter.pipe';
import { NotificationListService } from './services/notification-list.service';

@Component({
  selector: 'app-notification-list',
  templateUrl: './notification-list.component.html',
  styleUrls: ['./notification-list.component.scss'],
  providers: [NotificationListService]
})
export class NotificationListComponent implements OnInit, OnDestroy {
  result: any;
  term: any;
  reducecount: any;
  notificationCriteria: any[] = [];
  userDetails: any;
  loadingFlag = true;
  noData = false;
  private userId: any;
  constructor(private jbhGlobals: JBHGlobals, private notificationListService: NotificationListService) { }
  ngOnInit() {
    const data = this.jbhGlobals.user.userDetails;
    if (!this.jbhGlobals.utils.isEmpty(data)
      && !this.jbhGlobals.utils.isEmpty(data['userId'])) {
      this.userId = data['userId'];
      this.getNotificationList(data['userId']);
    }
  }
  ngOnDestroy() { }
  getNotificationList(loggedInUserId) {
    this.notificationCriteria = [];
    this.notificationListService.getNotificationServiceList(loggedInUserId).subscribe(result => {
      this.loadingFlag = false;
      const notificationLogs = result['_embedded']['notificationLogs'];
      for (let i = 0; i < notificationLogs.length; i++) {
        const getnotificationLogContent = JSON.parse(notificationLogs[i].notificationLogContent);
        const getnotificationContent = JSON.parse(getnotificationLogContent.notificationContent);
        this.notificationCriteria.push({
          'id': notificationLogs[i].notificationLogID,
          'timeStamp': notificationLogs[i].lastUpdateTimestampString,
          'readReceiptTimestamp': notificationLogs[i].readReceiptTimestamp,
          'notificationType': notificationLogs[i].readReceiptTimestamp,
          'applicationDomainCode': getnotificationLogContent.applicationDomainCode,
          'notificationTitle': getnotificationLogContent.applicationDomainCode,
          'notificationDiscription': getnotificationContent.notificationContent
        });
      }
      if (this.notificationCriteria.length === 0) {
        this.noData = true;
      }
    }, (err: Error) => {
      this.noData = true;
      this.loadingFlag = false;
    });
  }
  getCSSClass(domainName) {
    const responseData = {
      iconClsName: 'icon-jbh_crate iconFontSizeColorCls'
    };
    if (!this.jbhGlobals.utils.isEmpty(domainName)) {
      switch (domainName.toLowerCase()) {
        case '':
        default:
          responseData['iconClsName'] = 'icon-jbh_crate iconFontSizeColorCls';
          break;
        case 'order management':
          responseData['iconClsName'] = 'icon-jbh_crate iconFontSizeColorCls';
          break;
        case 'location':
          responseData['iconClsName'] = 'icon-jbh_pin_marker iconFontSizeColorCls';
          break;
        case 'account':
          responseData['iconClsName'] = 'icon-jbh_pin_marker iconFontSizeColorCls';
          break;
        case 'opportunity':
          responseData['iconClsName'] = 'icon-jbh_pin_marker iconFontSizeColorCls';
          break;
      }
    }
    return responseData;
  }
  selectedNotificationClick(notificationId, readReceiptTimestamp) {
    // temp code:
    this.loadingFlag = true;
    if (readReceiptTimestamp === null) {
      this.notificationListService.updateNotificationDetails(notificationId).subscribe(data => {
        // update notication count on every click from notification..
        this.updateNotificationCountValue(data);
      }, (err: Error) => {
        this.loadingFlag = false;
      });
    } else {
      this.loadingFlag = false;
    }
  }
  private updateNotificationCountValue(data) {
    let resData = data;
    if (resData !== undefined && resData['notificationLogID'] !== undefined) {
      this.jbhGlobals.commonDataService.getNotificationCountData().subscribe(notificationdata => {
        if (notificationdata !== undefined) {
          this.reducecount = notificationdata;
          if (resData !== null && this.reducecount !== undefined && this.reducecount !== null && this.reducecount > 0) {
            resData = null; // To prevent circular call
            this.jbhGlobals.commonDataService.saveNotificationCountData(this.reducecount - 1);
            this.getNotificationList(this.userId);
          }
        }
      });
    }
  }
}
