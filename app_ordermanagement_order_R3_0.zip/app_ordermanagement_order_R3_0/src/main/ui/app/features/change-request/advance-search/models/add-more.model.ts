export class AddMoreModel {
    isAddMoreDisabled: boolean;
    isValidTypeFieldOnBlur: boolean;
    isValidTypeAhead: boolean;
    dataListHadBeenSet: boolean;
    isEnterableNameField: boolean;
    isDefaultListGetPopulate: boolean;
}
