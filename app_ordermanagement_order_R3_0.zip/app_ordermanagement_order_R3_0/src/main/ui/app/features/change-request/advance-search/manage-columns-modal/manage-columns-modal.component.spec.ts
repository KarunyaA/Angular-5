import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageColumnsModalComponent } from './manage-columns-modal.component';

describe('ManageColumnsComponent', () => {
  let component:  ManageColumnsModalComponent;
  let fixture: ComponentFixture< ManageColumnsModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [  ManageColumnsModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageColumnsModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
