import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { FormGroup } from '@angular/forms';

import { ChangeRequestFormBuilderService } from '../../../services/change-request-form-builder.service';
import { AdvanceSearchModel } from '../../models/advance-search.model';
import { AdvanceSearchService } from '../../services/advance-search.service';
@Component({
  selector: 'app-add-ldc',
  templateUrl: './add-ldc.component.html',
  styleUrls: ['./add-ldc.component.scss']
})
export class AddLdcComponent implements OnInit, OnDestroy {

  advanceSearchModel: AdvanceSearchModel;
  accountDetails: FormGroup;
  ldcDetails: FormGroup;
  @Input() dataIndex: number;
  @Input() changeRequestFilter: any;
  @Input() ldctDetailsForm: FormGroup;
  @Output() currentLDC: EventEmitter<any> = new EventEmitter<any>();
  constructor(private advanceSearchService: AdvanceSearchService,
              public crFormBuilderService: ChangeRequestFormBuilderService) {
    this.advanceSearchModel = new AdvanceSearchModel();
  }

  ngOnInit(): void {
    this.advanceSearchModel.subscribeFlag = true;
    this.accountDetails = this.changeRequestFilter['controls']['accountDetails']['controls'][this.dataIndex];
    this.ldcDetails = this.changeRequestFilter['controls']['LDCDetails']['controls'][this.dataIndex];
  }

  ngOnDestroy(): void {
    this.advanceSearchModel.subscribeFlag = false;
  }

  onSelectCurrentLDC(event: any): void {
    this.currentLDC.emit(event.item.partyID);
    this.changeRequestFilter['controls']['LDCDetails']['controls'][this.dataIndex]['controls']['LDC']['_value'] = event.item.partyID;
  }

  onCurrentLDCKeyup(event: any): void {
    const value: any = event.target.value;
    if (value.length > 2) {
      this.advanceSearchService.onCurrentLDCKeyup(value, this.advanceSearchModel.subscribeFlag, this.advanceSearchModel);
    } else {
      this.advanceSearchModel.currentLDCList = [];
    }
  }
}
