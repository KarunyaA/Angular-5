import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChangeRequestResultGridComponent } from './change-request-result-grid.component';

describe('ChangeRequestResultGridComponent', () => {
  let component: ChangeRequestResultGridComponent;
  let fixture: ComponentFixture<ChangeRequestResultGridComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChangeRequestResultGridComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChangeRequestResultGridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
