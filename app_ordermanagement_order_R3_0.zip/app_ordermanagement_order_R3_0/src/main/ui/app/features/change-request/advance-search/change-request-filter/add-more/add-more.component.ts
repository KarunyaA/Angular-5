import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { FormGroup } from '@angular/forms';

import { ChangeRequestFormBuilderService } from '../../../services/change-request-form-builder.service';
import { AdvanceSearchModel } from '../../models/advance-search.model';
import { AdvanceSearchService } from '../../services/advance-search.service';
import { AddMoreModel } from './models/add-more.model';

@Component({
  selector: 'app-add-more',
  templateUrl: './add-more.component.html',
  styleUrls: ['./add-more.component.scss']
})

export class AddMoreComponent implements OnInit, OnDestroy {

  advanceSearchModel: AdvanceSearchModel;
  addMoreModel: AddMoreModel;
  accountDetails: FormGroup;
  ldcDetails: FormGroup;
  showAccountFieldFlag: any;
  showLDCFieldFlag: any;
  @Input()
  set showAccount(flag: boolean) {
    this.showAccountFieldFlag = flag;
  }
  @Input()
  set showLDC (flag: boolean) {
    this.showLDCFieldFlag = flag;
  }
  @Input() dataIndex: number;
  @Input() acctDetailsForm: FormGroup;
  @Input() changeRequestFilter: any;
  @Output() customerID: EventEmitter<any> = new EventEmitter<any>();

  constructor(private advanceSearchService: AdvanceSearchService,
              public crFormBuilderService: ChangeRequestFormBuilderService) {
                this.advanceSearchModel = new AdvanceSearchModel();
                this.addMoreModel = new AddMoreModel();
              }

  ngOnInit(): void {
    this.advanceSearchModel.subscribeFlag = true;
    this.accountDetails = this.changeRequestFilter['controls']['accountDetails']['controls'][this.dataIndex];
    this.ldcDetails = this.changeRequestFilter['controls']['LDCDetails']['controls'][this.dataIndex];
  }

  ngOnDestroy(): void {
    this.advanceSearchModel.subscribeFlag = false;
}
  onCurrentKeyup(event: any): void {
    const value: any = event.target.value;
    if (value.length > 2) {
        this.advanceSearchService.onCurrentTypeaheadKeyup(value, this.advanceSearchModel.subscribeFlag, this.advanceSearchModel);
    } else {
        this.advanceSearchModel.currentCustomerList = [];
    }
}

    onSelectCustomer(event: any): void {
      this.customerID.emit(event.item.partyID);
      this.changeRequestFilter['controls']['accountDetails']['controls'][this.dataIndex]
      ['controls']['Account']['_value'] = event.item.partyID;
    }
}
