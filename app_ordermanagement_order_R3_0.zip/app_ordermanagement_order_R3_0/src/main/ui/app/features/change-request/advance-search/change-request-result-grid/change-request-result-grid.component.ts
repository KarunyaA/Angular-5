import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, Subscription } from 'rxjs/Rx';
import { ResultGridModel } from './models/change-request-result-grid.model';
import { ViewChangeRequestService } from '../../services/view-change-request.service';
import { JBHGlobals } from '../../../../app.service';

@Component({
  selector: 'app-change-request-result-grid',
  templateUrl: './change-request-result-grid.component.html',
  styleUrls: ['./change-request-result-grid.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ChangeRequestResultGridComponent {

  @Input()
  set gridResults(gridDataJSON: any) {
    this.populateSearchResultGrid(gridDataJSON);
  }

  @ViewChild('autoShownModal') autoShownModal: any;
  @ViewChild('popoverDiv') popoverDiv: any;
  @Output() gridResize: any = new EventEmitter<string>();
  @Output() gridColumnManaged: any = new EventEmitter<any>();
  @Output() gridAdditionalFilterClicked: any = new EventEmitter<any>();
  @Output() exportExcelClicked: any = new EventEmitter<any>();
  @Output() paginationData: any = new EventEmitter<any>();
  @Output() createCR: any = new EventEmitter();
  @Input() searchQuery: any;

  resultGridModel: ResultGridModel;
  userInfoJson: object = {
    'personid': this.jbhGlobals.user.userDetails.userId
  };

  @Input()
  set gridColumns(result: any) {
    this.resultGridModel.columns = [];
    if (result && result.gridColumns) {
      this.setGridColumns(result.gridColumns);
      this.resultGridModel.editColumnGridHeaders = result.gridColumns;
    }
  }

  constructor(private router: Router, private viewChangeRequestService: ViewChangeRequestService, private jbhGlobals: JBHGlobals) {
    this.resultGridModel = new ResultGridModel();
   }

  onManageCloumns(): void {
    this.autoShownModal.show();
  }

  onCreateNewChangeRequest(): void {
    this.createCR.emit(true);
  }

  onPopOverBlur(event: any, popover: any, popup: any): void {
    event.stopPropagation();
    const scope: any = this;
    this.resultGridModel.popOverFlag = true;
    const source: any = Observable.timer(500);
    const subscribe: any = source.subscribe(() => {
      const popOVerList: any = this.popoverDiv['nativeElement'];
      popOVerList.setAttribute('tabindex', '1');
      popOVerList.focus();
      popOVerList.addEventListener('blur', function (eventProperty: any): any {
        if (scope.resultGridModel.popOverFlag) {
          popup.hide();
          scope.resultGridModel.popOverFlag = false;
        }
      });
    });
  }

  populateSearchResultGrid(gridDataJSON: any): void {
    if (gridDataJSON !== undefined) {
      this.resultGridModel.count = gridDataJSON['count'];
      this.resultGridModel.rows = gridDataJSON['gridDataArray'];
    }
  }

  onPage(event: any): void {
     const obj: any = {
       'from':  event.limit * event.offset,
       'size': event.limit
     };
     this.paginationData.emit(obj);
  }

  onHideEditColumnModel(): void {
    this.autoShownModal.hide();
  }

  onUpdateColumModel(inputColumnParams: any): void {
    let columnsInfoJson: any = {};
    this.onHideEditColumnModel();
    this.setGridColumns(inputColumnParams);
    columnsInfoJson[this.userInfoJson['personid']] = {};
    columnsInfoJson[this.userInfoJson['personid']]['OrderSearchGridColumns'] = inputColumnParams;
    this.jbhGlobals.localStore.setItem('OrderSearch', 'userColumnPref',
      JSON.stringify(columnsInfoJson), true);
    this.gridResize.emit();
    this.gridColumnManaged.emit(inputColumnParams);
    columnsInfoJson = null;

  }

  exportToExcel(event: any): void {
        const val: any = [];
        for (let i: any = 0; i < this.resultGridModel.columns.length; i++) {
            val.push(this.resultGridModel.columns[i]['prop']);
        }
        const url: any = `${this.jbhGlobals.endpoints.changerequest.exportToExcel}${'?displayfields='}${val}`;
        const query: any = this.searchQuery;
        this.viewChangeRequestService.exportToExcel(url, query).takeWhile(() => this.resultGridModel.subscribeFlag)
            .subscribe((data: any) => {
                if (data) {
                    this.downloadFile(data);
                }
            });
   }

  downloadFile(data: any): void {
      const blob: any = new Blob([data['_body']], {
          type: 'application/vnd.ms-excel'
      });
      if (window.navigator && window.navigator.msSaveOrOpenBlob) {
          window.navigator.msSaveBlob(blob, 'changeRequest.xlsx');
      } else {
          const a: any = document.createElement('a');
          a.href = URL.createObjectURL(blob);
          a.download = 'changeRequest.xlsx';
          document.body.appendChild(a);
          a.click();
      }
  }

  setGridColumns(columnsArray: any): void {
    const columns: any = [];
    for (let columnIdx: any = 0; columnIdx < columnsArray.length; columnIdx++) {
      const columnJSON: any = columnsArray[columnIdx];
      if (columnJSON['isVisible']) {
        columns.push(columnJSON);
      }
    }
    this.resultGridModel.columns = columns;
  }

  onActivate(event: any): void {
    const param: object = {
      'id': event.row.orderChangeRequestID,
      'requestTypeCode': event.row['orderChangeRequestTypeCode'],
      'requestTypeName': event.row['changeRequestTypeDescription']
    };
    this.viewChangeRequestService.setSelectedData(param);
    this.router.navigateByUrl('/changerequest/viewrequest');
  }
}
