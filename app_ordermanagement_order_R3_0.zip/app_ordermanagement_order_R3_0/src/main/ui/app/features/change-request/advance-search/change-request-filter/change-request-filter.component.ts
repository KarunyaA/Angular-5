import {
    ChangeDetectionStrategy, Component, EventEmitter, Input, OnDestroy, OnInit,
    Output, ViewChild
} from '@angular/core';
import { DatePipe } from '@angular/common';
import { FormControl, FormGroup } from '@angular/forms';
import { ModalDirective } from 'ngx-bootstrap/modal';

import { IMyOptions } from 'mydatepicker';
import * as moment from 'moment';

import { JBHGlobals } from '../../../../app.service';
import { ChangeRequestFormBuilderService } from '../../services/change-request-form-builder.service';
import { AdvanceSearchModel } from '../models/advance-search.model';
import { AdvanceSearchService } from '../services/advance-search.service';
import { Subscription } from 'rxjs/Subscription';
import { SavedSearchComponent } from './saved-search/saved-search.component';
import { LocalStorageService } from 'jbh-components/jbh-core-services';

@Component({
    selector: 'app-change-request-filter',
    templateUrl: './change-request-filter.component.html',
    styleUrls: ['./change-request-filter.component.scss'],
    providers: [DatePipe],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class ChangeRequestFilterComponent implements OnInit, OnDestroy {

    @Input() accountDetails: any;
    @Input() ldcDetails: any;
    @Output() orderSearchSaveForm: EventEmitter<any> = new EventEmitter<any>();
    @ViewChild('addFavoriteModal') addFavoriteModal: ModalDirective;
    @ViewChild('savedsearchmodal') manageFavoriteModal: ModalDirective;
    @ViewChild(SavedSearchComponent) savedSearchComponent: SavedSearchComponent;
    myDatePickerOptions: IMyOptions;
    advanceSearchModel: AdvanceSearchModel;
    momentRef: any;
    userInfoJson: object = {
        'personId': this.jbhGlobals.user.userDetails.userId
    };
    subscriptions: Array<Subscription> = [];

    changeRequestFilter: FormGroup;
    constructor(
        private datePipe: DatePipe,
        private jbhGlobals: JBHGlobals,
        private localStorageService: LocalStorageService,
        private advanceSearchService: AdvanceSearchService,
        public crFormBuilderService: ChangeRequestFormBuilderService) {
        this.advanceSearchModel = new AdvanceSearchModel();
        this.advanceSearchModel.subscribeFlag = true;
        this.dateFormator();
    }

    ngOnInit(): void {
        this.changeRequestFilter = this.crFormBuilderService.changeRequestForm['controls']['requestFilter'];
        this.accountDetails = this.crFormBuilderService.changeRequestForm['controls']['requestFilter']['controls']['accountDetails'];
        this.ldcDetails = this.crFormBuilderService.changeRequestForm['controls']['requestFilter']['controls']['LDCDetails'];
        this.loadChangeRequest();
        this.setDatePickerOption();
        this.loadChangeRequestStatus();
        this.loadTeamID();
        this.loadTaskAssignment();
        this.advanceSearchService.initializeModel(this.advanceSearchModel);
        this.populateSearchFields();
        this.savedSearchModalHidden();
        this.retainFormDetails();
    }

    dateFormator(): void {
        const date: any = new Date();
        this.advanceSearchModel.dateValuePast = {
            'year': date.getFullYear(),
            'month': date.getMonth(),
            'day': date.getDate()
        };
        this.advanceSearchModel.dateValueFuture = {
            'year': date.getFullYear(),
            'month': date.getMonth() + 4,
            'day': date.getDate()
        };
    }
    getCustomerID(event: any): void {
        this.advanceSearchModel.customerID = event;
    }
    getCurrentLDC(event: any): void {
        this.advanceSearchModel.LDCValue = event;
    }
    retainFormDetails(): void {
        this.advanceSearchModel.formDetails = this.localStorageService.getItem('ChangeRequest', 'searchFormData', false);
        if (this.advanceSearchModel.formDetails) {
            if (this.advanceSearchModel.formDetails['goBackFlag'] === true) {
                this.changeRequestFilter.controls.RAN.setValue(this.advanceSearchModel.formDetails['RAN']);
                this.changeRequestFilter.controls.PRN.setValue(this.advanceSearchModel.formDetails['PRN']);
                this.changeRequestFilter.controls.TeamID.setValue(this.advanceSearchModel.formDetails['TeamID']);
                this.changeRequestFilter.controls.TaskAssignment.setValue(this.advanceSearchModel.formDetails['TaskAssignment']);
                this.changeRequestFilter.controls.ChangeRequestStatus.setValue(this.advanceSearchModel.formDetails['ChangeRequestStatus']);
                this.changeRequestFilter.controls.fromDate.setValue(this.advanceSearchModel.formDetails['fromDate']);
                this.changeRequestFilter.controls.toDate.setValue(this.advanceSearchModel.formDetails['toDate']);
                this.changeRequestFilter.controls['accountDetails']['controls'] =
                    this.advanceSearchModel.formDetails['accountDetails']['controls'];
                this.changeRequestFilter.controls['LDCDetails']['controls'] = this.advanceSearchModel.formDetails['LDCDetails']['controls'];
                this.changeRequestFilter.controls['LDCDetails']['controls'][0]['_value'] =
                  this.changeRequestFilter.controls['LDCDetails']['controls'][0]['_value']['LDC'];
                this.changeRequestFilter.controls['LDCDetails']['controls'][0].controls['LDC']['_value'] =
                  this.changeRequestFilter.controls['LDCDetails']['controls'][0]['_value'];
                this.changeRequestFilter.controls['accountDetails']['controls'][0]['_value'] =
                    this.changeRequestFilter.controls['accountDetails']['controls'][0]['_value']['Account'];
                this.changeRequestFilter.controls['accountDetails']['controls'][0].controls['Account']['_value'] =
                    this.changeRequestFilter.controls['accountDetails']['controls'][0]['_value'];
                setTimeout(() => { this.orderSearchClicked(); }, 500);
            }
        }
    }

    setDatePickerOption(): void {
        this.myDatePickerOptions = {
            todayBtnTxt: 'Today',
            dateFormat: 'mm-dd-yyyy',
            height: '34px',
            width: '160px',
            inline: false,
            firstDayOfWeek: 'mo',
            showClearDateBtn: false,
            sunHighlight: true,
            selectionTxtFontSize: '14px',
            disableUntil: this.advanceSearchModel.dateValuePast,
            disableSince: this.advanceSearchModel.dateValueFuture
        };
        this.momentRef = moment;
    }

    orderSearchClicked(): void {
        const searchFormDetail: any = this.localStorageService.getItem('ChangeRequest', 'searchFormData', false);
        if (this.advanceSearchModel.LDCValue || searchFormDetail || this.advanceSearchModel.LDCValue) {
            this.advanceSearchModel.formData = {
                'goBackFlag': false,
                'customerIDValue': this.advanceSearchModel.customerID ? this.advanceSearchModel.customerID :
                    searchFormDetail['customerIDValue'],
                'LDCIdValue': this.advanceSearchModel.LDCValue ? this.advanceSearchModel.LDCValue :
                    searchFormDetail['LDCIdValue'],
                'accountDetails': this.changeRequestFilter.controls.accountDetails,
                'LDCDetails': this.changeRequestFilter.controls.LDCDetails,
                'PRN': this.changeRequestFilter.controls.PRN.value,
                'RAN': this.changeRequestFilter.controls.RAN.value,
                'TeamID': this.changeRequestFilter.controls.TeamID.value,
                'TaskAssignment': this.changeRequestFilter.controls.TaskAssignment.value,
                'ChangeRequestStatus': this.changeRequestFilter.controls.ChangeRequestStatus.value,
                'fromDate': this.changeRequestFilter.controls.fromDate.value,
                'toDate': this.changeRequestFilter.controls.toDate.value
        };
    }
        this.localStorageService.setItem('ChangeRequest', 'searchFormData', this.advanceSearchModel.formData, false);
        this.advanceSearchModel.queryParamDTO['query']['constant_score']['filter']['bool']['must'] = [];
        const queryLength: number = this.advanceSearchModel.queryParamDTO.query.constant_score.filter.bool.must.length;
        if (queryLength < 8) {
            this.advanceSearchModel.queryParamDTO.query.constant_score.filter.bool.must = this.filterQueryLoop(9);
        }
        this.getFormControlQueryJSON(this, (resultJSON: any) => {
            this.matchQueryValues(resultJSON);
            if (this.changeRequestFilter['controls']['accountDetails']['controls'][0]['controls']['Account']['_value'] &&
                this.changeRequestFilter['controls']['LDCDetails']['controls'][0]['controls']['LDC']['_value']) {
                if (this.advanceSearchModel.queryParamDTO.query.constant_score.filter.bool.must[1].bool.should[0].match.billingPartyID) {
                    this.localStorageService.setItem('ChangeRequestQuery', 'queryValue', this.advanceSearchModel.queryParamDTO, false);
                } else {
                    const requestQuery: any = this.localStorageService.getItem('ChangeRequestQuery', 'queryValue', false);
                    this.advanceSearchModel.queryParamDTO.query.constant_score.filter.bool.must[1].bool.should[0].match =
                        requestQuery['query']['constant_score']['filter']['bool']['must'][1]['bool']['should'][0]['match'];
                    this.localStorageService.setItem('ChangeRequestQuery', 'queryValue', this.advanceSearchModel.queryParamDTO, false);
                }
                this.orderSearchSaveForm.emit(this.advanceSearchModel.queryParamDTO);
            } else {
                this.jbhGlobals.notifications.alert('Warning', 'Please fill Account & Local Distribution Centre details');
            }
        });
    }

    onRemoveAccount(position: number): void {
        const itemArray: any = this.changeRequestFilter['controls']['accountDetails']['controls'];
        itemArray.splice(position, 1);
    }

    onValueSelected(event: any, formControlName: string): void {
        this.changeRequestFilter['controls'][formControlName].setValue(event.id);
    }

    onClickAddAdditionalAccount(event: any): void {
        if (this.changeRequestFilter['controls']['accountDetails']['controls']) {
            const length: number = this.changeRequestFilter['controls']['accountDetails']['controls'].length;
            if (this.changeRequestFilter['controls']['accountDetails']['controls'][length - 1]['controls']['Account'].value) {
                const itemDetails: any = this.crFormBuilderService.addAccount();
                this.changeRequestFilter['controls']['accountDetails']['controls'].push(itemDetails);
            }
        }
    }

    onClickAddAdditionalLDC(event: any): void {
        if (this.changeRequestFilter['controls']['LDCDetails']['controls']) {
            const length: number = this.changeRequestFilter['controls']['LDCDetails']['controls'].length;
            if (this.changeRequestFilter['controls']['LDCDetails']['controls'][length - 1]['controls']['LDC'].value) {
                const itemDetails: any = this.crFormBuilderService.addLDC();
                this.changeRequestFilter['controls']['LDCDetails']['controls'].push(itemDetails);
            }
        }
    }

    onRemoveLDC(position: number): void {
        const itemArray: any = this.changeRequestFilter['controls']['LDCDetails']['controls'];
        itemArray.splice(position, 1);
    }

    onDateSelected(fieldName: string, event: any): void {
        const value: string = event.formatted;
        this.changeRequestFilter['controls'][fieldName].setValue(value);
        const dateValidatorObject: any = this.validateDate();
        if (dateValidatorObject.endDateError) {
            this.jbhGlobals.notifications.alert('Warning', 'Please enter valid date range. Begin date should be earlier than the end date');
        } else if (dateValidatorObject.beyondRangeError) {
            this.jbhGlobals.notifications.alert('Warning',
                'Entered date exceeds the maximum range. Please enter the dates within 3 months');
        }
    }

    getFormControlQueryJSON(parentScope: any, callBackFn: any): any {
        const formObj: any = parentScope.changeRequestFilter.controls;
        const formObjLen: number = Object.keys(formObj).length;
        const formKeys: any = parentScope.jbhGlobals.utils.keys(formObj);
        const payLoad: object = {};
        const opJSON: object = {};
        for (let formObjIndex: any = 0; formObjIndex < formObjLen; formObjIndex++) {
            if (formKeys[formObjIndex].match('_') === null && formObj[formKeys[formObjIndex]] &&
                formObj[formKeys[formObjIndex]]['_value'] && formObj[formKeys[formObjIndex]]['_value'].length !== 0
                && formKeys[formObjIndex] !== 'LDCDetails' && formKeys[formObjIndex] !== 'accountDetails') {
                payLoad[formKeys[formObjIndex]] = (formObj[formKeys[formObjIndex]]) ? formObj[formKeys[formObjIndex]]['_value'] : '';
            } else if (formKeys[formObjIndex].match('_') === null && formObj[formKeys[formObjIndex]] &&
                formObj[formKeys[formObjIndex]]['_value'] && formObj[formKeys[formObjIndex]]['_value'].length !== 0
                && (formKeys[formObjIndex] === 'LDCDetails' || formKeys[formObjIndex] === 'accountDetails')) {
                payLoad[formKeys[formObjIndex]] = (formObj[formKeys[formObjIndex]]) ? formObj[formKeys[formObjIndex]]['controls'] : '';
            }
        }
        opJSON['formObj'] = payLoad;
        opJSON['addMoreComponentProps'] = [];
        opJSON['isAnyAddMoreInValid'] = false;
        callBackFn(opJSON);
    }

    onReferenceKeyup(event: any): void {
        const value: any = event.target.value;
        if (value && value.length > 2) {
            const params: object = {
                'typeAhead': value
            };
            this.advanceSearchService.getReferenceNumbers(this.jbhGlobals.endpoints.changerequest.primaryReferenceNumber, params)
                .takeWhile(() => this.advanceSearchModel.subscribeFlag)
                .subscribe((data: any) => {
                    if (data) {
                        this.advanceSearchModel.referenceList = [];
                        for (const list of data) {
                            const obj: object = {};
                            obj['referenceNumber'] = list['primaryReferenceNumber'];
                            this.advanceSearchModel.referenceList.push(obj);
                        }
                    }
                });
        }
    }

    onAuthorizarionKeyup(event: any): void {
        const value: any = event.target.value;
        if (value && value.length > 2) {
            const params: object = {
                'typeAhead': value
            };
            this.advanceSearchService.getReferenceNumbers(this.jbhGlobals.endpoints.changerequest.returnAuthorizationNumber, params)
                .takeWhile(() => this.advanceSearchModel.subscribeFlag)
                .subscribe((data: any) => {
                    if (data) {
                        this.advanceSearchModel.returnAuthorizationList = [];
                        for (const list of data) {
                            const obj: object = {};
                            obj['authorizationNumber'] = list['returnAuthorizationNumber'];
                            this.advanceSearchModel.returnAuthorizationList.push(obj);
                        }
                    }
                });
        }
    }

    favoriteSearchSelected(typeAheadEvent: any): void {
        const typeAheadValue: any = typeAheadEvent['value'];
        if (typeAheadEvent !== undefined && typeAheadValue !== undefined) {
            this.advanceSearchModel.selectedFavorite = typeAheadValue;
            this.advanceSearchModel.favoriteSelectFromPopup = true;
            switch (this.advanceSearchModel.selectedFavorite) {
                case 'Add to Favorites':
                    this.addFavoriteModal.show();
                    this.advanceSearchModel.selectedFavorite = '';
                    break;
                case 'Manage Favorites':
                    this.manageFavoriteModal.show();
                    this.advanceSearchModel.selectedFavorite = '';
                    break;
                default:
                    this.rePopulatedList(typeAheadEvent.item);
                    break;
            }
        }
    }

    savedSearchModalHidden(): void {
        if (!this.advanceSearchModel.favoriteSelectFromPopup) {
            const inputParams: any = Object.assign({}, this.userInfoJson);
            this.populateSavedSearchList(inputParams);
            this.savedSearchComponent.ResetFields();
        }
    }

    populateSavedSearchList(inputParams: any): void {
        const self: any = this;
        this.advanceSearchModel.newSearch = this.advanceSearchModel.hardCodedFavoriteList;
        inputParams['searchFunCode'] = 'chngeRqst';
        this.getSearchList({
            'inputParams': inputParams,
            'callBack': (results: any): void => {
                let resultList: Array<any> = [];
                const resultListLength: number = results.length;
                for (let idx: any = 0; idx < resultListLength; idx++) {
                    resultList.push(results[idx]);
                }
                self.advanceSearchModel.newSearch = resultList.concat(self.advanceSearchModel.hardCodedFavoriteList);
                resultList = null;
            }
        });
    }

    getSearchList(serviceArguments: any): void {
        const callBackFn: any = serviceArguments['callBack'];
        const inputParams: object = serviceArguments['inputParams'];
        const getSavedSearches: any = this.advanceSearchService.getSavedSearches(this.jbhGlobals.endpoints.changerequest.findSavedSearch,
            inputParams, true).subscribe((results: any) => {
                if (results !== undefined) {
                    if (callBackFn !== undefined) {
                        callBackFn(results);
                    }
                }
            });
        this.subscriptions.push(getSavedSearches);
    }

    populateSearchFields(): void {
        this.advanceSearchModel.hardCodedFavoriteList = this.advanceSearchService.getHardCodedModel('hardCodedCustomFavorites');
    }

    addFavModalShown(): void {
        this.advanceSearchModel.addFavErrorMsg = this.advanceSearchModel.newFavoriteName = '';
    }

    onAddFavoriteBtnClicked(): void {
        const inputParam: object = {};
        inputParam['personID'] = this.userInfoJson['personId'];
        inputParam['userSearchName'] = this.advanceSearchModel.newFavoriteName;
        inputParam['userSearchDefaultIndicator'] = 'Y';
        inputParam['applicationSearchFunctionCode'] = 'chngeRqst';
        inputParam['errorCallback'] = true;
        const notification: any = document.getElementsByClassName('simple-notification-wrapper')[0];
        this.getFavoriteFormControlQuery((resultJSON: any) => {
            this.advanceSearchModel.addFavErrorMsg = '';
            inputParam['userSearchCriteriaContent'] = btoa(JSON.stringify(resultJSON));  // Encrypted JSON to Post
            notification.classList.add('notification-hide');
            const postSavedSearch: any = this.advanceSearchService.postSavedSearch(
                this.jbhGlobals.endpoints.changerequest.getSavedSearches, inputParam).subscribe((stopData: any) => {
                    if (stopData !== undefined && stopData['userSearchName'] === this.advanceSearchModel.newFavoriteName) {
                        this.addFavoriteModal.hide();
                        this.populateSavedSearchList(this.userInfoJson);
                    }
                    this.advanceSearchModel.newFavoriteName = '';
                }, (err: Error) => {
                    notification.classList.add('notification-hide');
                    if (err && err['errorMessage']) {
                        this.advanceSearchModel.addFavErrorMsg = err['errorMessage'];
                    }
                });
            this.subscriptions.push(postSavedSearch);
        });
        this.addFavoriteModal.hide();
    }

    getFavoriteFormControlQuery(callBackFn: any): any {
        const formObj: any = this.changeRequestFilter.controls;
        const formObjLen: number = Object.keys(formObj).length;
        const formKeys: any = this.jbhGlobals.utils.keys(formObj);
        const payLoad: object = {};
        let opJSON: object = {};
        for (let formObjIndex: any = 0; formObjIndex < formObjLen; formObjIndex++) {
            if (formKeys[formObjIndex].match('_') === null && formObj[formKeys[formObjIndex]] &&
                formObj[formKeys[formObjIndex]]['_value'] && formObj[formKeys[formObjIndex]]['_value'].length !== 0) {
                payLoad[formKeys[formObjIndex]] = (formObj[formKeys[formObjIndex]]) ? formObj[formKeys[formObjIndex]]['_value'] : '';
            }
        }
        opJSON['formObj'] = payLoad;
        opJSON['addMoreComponentProps'] = [];
        opJSON['isAnyAddMoreInValid'] = false;
        callBackFn(opJSON);
        opJSON = null;
    }

    savedSearchModalShown(): void {
        const self: any = this;
        this.advanceSearchModel.favoriteSelectFromPopup = false;
        const inputParams: object = Object.assign({}, this.userInfoJson);
        this.getSearchList({
            'inputParams': inputParams,
            'callBack': (results: any): void => {
                self.savedSearchComponent.modalShown(results);
            }
        });
    }

    rePopulatedList(data: any): void {
        this.resetAllFields();
        const decryptedData: any = JSON.parse(atob(data['userSearchCriteriaContent']));
        const formControlObject: any = decryptedData['formObj'];
        const formObjLen: number = Object.keys(formControlObject).length;
        const addMoreData: any = decryptedData['addMoreComponentProps'];
        const addMoreDataLength: any = addMoreData.length;
        const advanceSearchModel: any = this.advanceSearchModel;

        if (formObjLen !== 0) {
            for (const formControl in formControlObject) {
                if (formControl) {
                    this.changeRequestFilter['controls'][formControl].setValue(formControlObject[formControl]);
                }
            }
        }
        if (addMoreDataLength !== 0) {
            for (let idx: any = 0; idx < addMoreDataLength; idx++) {
                const addMoreComponentProp: any = addMoreData[idx];
                this.executeAddMoreWithPropJSON({}, addMoreComponentProp['AddMoreType'], addMoreComponentProp);
            }
        }
        for (const addMoreType in advanceSearchModel.addMoreProps) {
            if (advanceSearchModel[advanceSearchModel.addMoreProps[addMoreType]['counter']] === 0) {
                this.executeAddMoreWithPropJSON({}, addMoreType, advanceSearchModel[advanceSearchModel.addMoreProps[addMoreType]['prop']]);
            }
        }
    }

    executeAddMoreWithPropJSON(event: any, type: string, propJSON: any): void {
        let counter: any = 0;
        let addMorePropJSON: object = {};
        const isDefaultPropJSON: any = (Object.keys(propJSON).length === 0 ? true : false);
        switch (type) {
            case 'Account':
                counter = this.advanceSearchModel.addMoreAccountCounter = this.advanceSearchModel.addMoreAccountCounter + 1;
                addMorePropJSON = {
                    'counter': counter,
                    'propJSON': (isDefaultPropJSON ? this.advanceSearchModel.addMorePropJSON : propJSON),
                    'itemArray': this.advanceSearchModel.listOfAccountTypes
                };
                break;
            case 'Location':
                counter = this.advanceSearchModel.addMoreLocCounter = this.advanceSearchModel.addMoreLocCounter + 1;
                addMorePropJSON = {
                    'counter': counter,
                    'propJSON': (isDefaultPropJSON ? this.advanceSearchModel.addMoreLocPropJSON : propJSON),
                    'itemArray': this.advanceSearchModel.listOfLocationTypes
                };
                break;
            case 'Reference':
                counter = this.advanceSearchModel.addMoreReferenceCounter = this.advanceSearchModel.addMoreReferenceCounter + 1;
                addMorePropJSON = {
                    'counter': counter,
                    'propJSON': (isDefaultPropJSON ? this.advanceSearchModel.addMoreRefPropJSON : propJSON),
                    'itemArray': this.advanceSearchModel.listOfReferrenceTypes
                };
                break;
            default:
                break;
        }
        this.commonAddMoreClickFuntion(event, addMorePropJSON);
        counter = null;
        addMorePropJSON = null;
    }

    resetAllFields(): void {
        this.advanceSearchModel.listOfAccountTypes = [];
        this.advanceSearchModel.addMoreAccountCounter = 0;
        this.advanceSearchModel.listOfLocationTypes = [];
        this.advanceSearchModel.addMoreLocCounter = 0;
        this.advanceSearchModel.listOfReferrenceTypes = [];
        this.advanceSearchModel.addMoreReferenceCounter = 0;
        this.advanceSearchModel.maxAddMoreComponent = 50;
        this.advanceSearchModel.formControlObjectArray = [];
        this.resetFormFields(false);
    }

    resetFormFields(isShowMoreFieldsArg: boolean): void {
        const formArrayLength: number = this.advanceSearchModel.formControlObjectArray.length;
        for (let idx: any = 0; idx < formArrayLength; idx++) {
            const formControlField: any = this.advanceSearchModel.formControlObjectArray[idx];
            const isShowMoreField: boolean = isShowMoreFieldsArg ? formControlField['isMoreField'] : true;
            if (isShowMoreField) {
                if (formControlField['type'] === 'dateTime') {
                    this.changeRequestFilter['controls'][formControlField['name']].setValue('');
                } else {
                    this.changeRequestFilter['controls'][formControlField['name']].setValue([]);
                }
                this.advanceSearchModel.validationErrorMessageFlag[formControlField['errField']] = false;
            }
        }
    }

    commonAddMoreClickFuntion(event: any, addMorePropJSON: any): void {
        const counter: any = addMorePropJSON['counter'];
        const propJSON: any = addMorePropJSON['propJSON'];
        const itemArray: any = addMorePropJSON['itemArray'];
        const arrLength: number = itemArray.length;
        if (arrLength < this.advanceSearchModel.maxAddMoreComponent) {
            this.changeRequestFilter.addControl(`${propJSON['bindNameTxt']}${'_'}${counter}`, new FormControl('', []));
            this.changeRequestFilter.addControl(`${propJSON['bindTypeTxt']}${'_'}${counter}`, new FormControl('', []));
            for (let idx: any = 0; idx < arrLength; idx++) {
                itemArray[idx] = Object.assign(itemArray[idx], {
                    'accountTypeVisible': false
                });
            }
            itemArray.push(Object.assign({}, propJSON, {
                'accountTypeVisible': true,
                'bindType': `${propJSON['bindNameTxt']}${'_'}${counter}`,
                'bindName': `${propJSON['bindTypeTxt']}${'_'}${counter}`
            }));
        }
    }

    ngOnDestroy(): void {
        for (const subs of this.subscriptions) {
            subs.unsubscribe();
        }
    }

    private validateDate(): any {
        const obj: object = {
            'beyondRangeError': false,
            'endDateError': false
        };
        if (this.changeRequestFilter['controls']['fromDate'] && this.changeRequestFilter['controls']['fromDate']['value']['formatted']
            && this.changeRequestFilter['controls']['toDate'] && this.changeRequestFilter['controls']['toDate']['value']) {
            const startDate: string = this.changeRequestFilter['controls']['fromDate']['value']['formatted'];
            const endDate: string = this.changeRequestFilter['controls']['toDate']['value'];
            const date: any = Date.now();
            const dateFormat: any = this.datePipe.transform(date, 'shortDate');
            const dateDifference: any = (moment(dateFormat).diff(moment(startDate), 'days'));
            if (dateDifference > 91) {
                obj['beyondRangeError'] = true;
            }
            if (!(moment(endDate).isAfter(startDate))) {
                obj['endDateError'] = true;
            }
        }
        return obj;
    }

    private loadChangeRequest(): void {
        this.advanceSearchService.getChangeRequestService(this.jbhGlobals.endpoints.changerequest.getNewRequest)
            .subscribe((data: any) => {
                if (data !== null) {
                    this.advanceSearchModel.requestType = [];
                    const changeType: any = data;
                    for (let i: any = 0; i < changeType.length; i++) {
                        this.advanceSearchModel.requestType.push({
                            id: changeType[i]['changeRequestTypeCode'],
                            text: changeType[i]['changeRequestTypeDescription']
                        });
                    }
                }
            });
    }

    private loadChangeRequestStatus(): void {
        this.advanceSearchService.getChangeRequestStatusService(this.jbhGlobals.endpoints.changerequest.getChangeRequestStatuses)
            .subscribe((data: any) => {
                if (data !== null && data['_embedded']['changeRequestStatuses'] !== null) {
                    this.advanceSearchModel.requestStatus = [];
                    const changeType: any = data['_embedded']['changeRequestStatuses'];
                    for (let i: any = 0; i < changeType.length; i++) {
                        this.advanceSearchModel.requestStatus.push({
                            id: changeType[i]['changeRequestStatusCode'],
                            text: changeType[i]['changeRequestStatusDescription']
                        });
                    }
                }
            });
    }

    private loadTeamID(): void {
        this.advanceSearchService.getTeamID(this.jbhGlobals.endpoints.changerequest.getTeamId)
            .subscribe((data: any) => {
                if (data !== null && data['_embedded']['teams'] !== null) {
                    this.advanceSearchModel.teamID = [];
                    const changeType: any = data['_embedded']['teams'];
                    for (let i: any = 0; i < changeType.length; i++) {
                        this.advanceSearchModel.teamID.push({
                            id: changeType[i]['teamID'],
                            text: changeType[i]['teamName']
                        });
                    }
                }
            });
    }

    private loadTaskAssignment(): void {
        this.advanceSearchService.getTeamID(this.jbhGlobals.endpoints.changerequest.getTaskAssignment)
            .subscribe((data: any) => {
                if (data !== null && data['_embedded']['taskAssignments'] !== null) {
                    this.advanceSearchModel.taskAssignment = [];
                    const changeType: any = data['_embedded']['taskAssignments'];
                    for (let i: any = 0; i < changeType.length; i++) {
                        this.advanceSearchModel.taskAssignment.push({
                            id: changeType[i]['taskAssignmentID'],
                            text: changeType[i]['taskAssignmentName']
                        });
                    }
                }
            });
    }

    private filterQueryLoop(length: number): Array<object> {
        const array: Array<any> = [];
        for (let i: any = 0; i < length; i++) {
            const filterObj: object = {
                'bool': {
                    'should': []
                }
            };
            array.push(filterObj);
        }
        return array;
    }

    private matchQueryValues(resultJSON: object): void {
        for (const item of this.advanceSearchModel.filterList) {
            switch (item['title']) {
                case 'Account':
                    this.pushTypeAheadValuesToQuery('Account', 'accountDetails', resultJSON, item.checkSelectionKey, item.index);
                    break;
                case 'LDC':
                    this.pushTypeAheadValuesToQuery('LDC', 'LDCDetails', resultJSON, item.checkSelectionKey, item.index);
                    break;
                case 'PRN':
                    this.pushTypeAheadValues('PRN', 'PRN', resultJSON, item.checkSelectionKey, item.index);
                    break;
                case 'RAN':
                    this.pushTypeAheadValues('RAN', 'RAN', resultJSON, item.checkSelectionKey, item.index);
                    break;
                case 'ChangeRequestStatus':
                    this.pushMatchValueInQuery('ChangeRequestStatus', resultJSON, item.checkSelectionKey, item.index);
                    break;
                case 'TaskAssignment':
                    this.pushMatchValueInQuery('TaskAssignment', resultJSON, item.checkSelectionKey, item.index);
                    break;
                case 'TeamID':
                    this.pushMatchValueInQuery('TeamID', resultJSON, item.checkSelectionKey, item.index);
                    break;
                case 'Date':
                    this.frameDateRangeQuery(resultJSON, item.checkSelectionKey, item.index);
                default:
                    break;
            }
        }
    }

    private frameDateRangeQuery(data: object, matchField: string, index: number): void {
        const obj: object = {};
        let dateObj: object = [];
        if (data['formObj']['fromDate'] && data['formObj']['fromDate']['formatted']
            && data['formObj']['toDate'] && data['formObj']['toDate']['formatted']) {
            const startDate: any = `${this.datePipe.transform(data['formObj']['fromDate']['formatted'], 'yyyy-MM-dd')}${'T00:00:00.000Z'}`;
            const endDate: any = `${this.datePipe.transform(data['formObj']['toDate']['formatted'], 'yyyy-MM-dd')}${'T00:00:00.000Z'}`;
            obj['range'] = {};
            dateObj['match'] = {};
            obj['range'][matchField] = {
                'gte': startDate,
                'lte': endDate
            };
            dateObj = [{ 'match': { 'changeRequestStatusCode': 'Cancelled' } }, { 'match': { 'changeRequestStatusCode': 'Completed' } }];
        }
        this.advanceSearchModel.queryParamDTO['query']['constant_score']['filter']['bool']['must'][index]['bool']['should'].push(obj);
        if (this.advanceSearchModel.queryParamDTO['query']['constant_score']['filter']['bool']['must']
        [index]['bool']['should'][0]['range']) {
            this.advanceSearchModel.queryParamDTO['query']['constant_score']['filter']['bool']
            ['must'][index - 1]['bool']['should'] = dateObj;
        }
    }

    private pushMatchValueInQuery(key: string, value: object, matchField: string, index: number): void {
        let selectedValue: any;
        if (value['formObj'][key]) {
            selectedValue = value['formObj'][key][0]['id'];
            if (selectedValue) {
                const obj: object = {
                    'match': {}
                };
                obj['match'][matchField] = selectedValue;
                this.advanceSearchModel.queryParamDTO['query']['constant_score']['filter']['bool']['must'][index]
                ['bool']['should'].push(obj);
            }
        }
    }

    private pushTypeAheadValuesToQuery(key: string, path: string, resultJSON: object, matchField: string, index: number): void {
        let selectedValues: any;
        if (resultJSON['formObj'][path]) {
            selectedValues = resultJSON['formObj'][path];
            for (const value of selectedValues) {
                if (value['controls'][key]['_value']) {
                    const obj: any = {
                        'match': {}
                    };
                    if ((key === 'Account') && (this.advanceSearchModel.formDetails) &&
                        (this.advanceSearchModel.formDetails['goBackFlag'] === true)) {
                        obj.match[matchField] = this.advanceSearchModel.formDetails['customerIDValue'];

                     } else if ((key === 'LDC') && (this.advanceSearchModel.formDetails) &&
                        (this.advanceSearchModel.formDetails['goBackFlag'] === true)) {
                        obj.match[matchField] = this.advanceSearchModel.formDetails['LDCIdValue'];
                    } else {
                            obj.match[matchField] = value['controls'][key]['_value'];
                        }
                    this.advanceSearchModel.queryParamDTO['query']['constant_score']['filter']['bool']['must'][index]
                        ['bool']['should'].push(obj);
                    }
            }
        }
    }

    private pushTypeAheadValues(key: string, path: string, resultJSON: object, matchField: string, index: number): void {
        let selectedValues: any;
        if (resultJSON['formObj'][path]) {
            selectedValues = resultJSON['formObj'][path];
            if (selectedValues) {
                const obj: any = {
                    'match': {}
                };
                obj.match[matchField] = selectedValues;
                this.advanceSearchModel.queryParamDTO['query']['constant_score']['filter']['bool']['must'][index]['bool']
                ['should'].push(obj);
            }
        }
    }
}
