export class ResultGridModel {
    rows: Array<object>;
    selected: any;
    popOverFlag: boolean;
    columns: Array<object>;
    splitScreenInputData: any;
    offset: number;
    limit: number;
    count: number;
    subscribeFlag: boolean;
    editColumnGridHeaders: any;

    constructor() {
        this.rows = [];
        this.limit = 10;
        this.count = 10;
        this.offset = 0;
        this.subscribeFlag = true;
        this.columns = [];
        this.editColumnGridHeaders = [];
    }
}
