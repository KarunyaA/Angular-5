export class AddMoreModel {
    showAccountFieldFlag: boolean;
    showLDCFieldFlag: boolean;
    index: number;
}
