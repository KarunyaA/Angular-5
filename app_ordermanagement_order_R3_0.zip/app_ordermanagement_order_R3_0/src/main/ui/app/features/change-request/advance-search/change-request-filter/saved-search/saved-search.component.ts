import { Component, EventEmitter, Input, OnDestroy, OnInit, Output, ViewChild, ElementRef } from '@angular/core';
import { JBHGlobals } from '../../../../../app.service';

import { SavedSearchModel } from './../../models/saved-search.model';
import { SavedSearchService } from './../../services/saved-search.service';

import { Subscription } from 'rxjs/Subscription';

@Component({
    selector: 'app-saved-search',
    providers: [SavedSearchService],
    templateUrl: './saved-search.component.html',
    styleUrls: ['./saved-search.component.scss']
})

export class SavedSearchComponent implements OnDestroy {

    @Input()
    set parentUserInfoJson(parentUserInfoJson: any) {
        const scope: any = this;
        scope.userInfoJson = Object.assign({}, parentUserInfoJson);
    }
    @Output() getSearchList: any = new EventEmitter<any>();
    @Output() repopulatedList: any = new EventEmitter<any>();
    @Output() hideSavedSearchModal: any = new EventEmitter<any>();
    @Output() favoriteSearchSelected: any = new EventEmitter<any>();
    @ViewChild('manageSavedSearch') manageSavedSearch: ElementRef;

    savedSearchModel: SavedSearchModel;
    subscriptions: Array<Subscription> = [];
    userInfoJson: object = {};
    selectedFavorite: string;

    constructor(
        private jbhGlobals: JBHGlobals,
        private savedSearchService: SavedSearchService
    ) {
        this.savedSearchModel = new SavedSearchModel();
     }

    modalShown(savedSearchListData: any): void {
        this.savedSearchModel.savedSearchList = [];
        this.savedSearchModel.removeSavedSearchData = {};
        if (savedSearchListData.length !== 0) {
            this.savedSearchModel.savedSearchList = savedSearchListData;
        }
        this.savedSearchModel.isNoResultsDisplay = savedSearchListData.length === 0;
        this.savedSearchModel.copyOfSavedSearch = Object.assign([], this.savedSearchModel.savedSearchList);
        this.manageSavedSearch.nativeElement.click();
    }

    removeSavedSearch(): void {
        const url: any =
         `${this.jbhGlobals.endpoints.ordersearch.revomeSavedSearch}/${this.savedSearchModel.removeSavedSearchData['userSavedSearchID']}`;
        const revomeSavedSearch: any = this.savedSearchService.revomeSavedSearch(url, {}).subscribe((data: any) => {
            this.populateSavedSearchList(this.userInfoJson);
        });
        this.subscriptions.push(revomeSavedSearch);
        this.onCloseModal();
    }

    onSetRemovableData(event: any, removeSavedSearchDataArg: any): void {
        this.savedSearchModel.removeSavedSearchData = removeSavedSearchDataArg;
        event.stopPropagation();
    }

    onWarningPopupHidden(): void {
        this.savedSearchModel.removeSavedSearchData = {};
    }

    populateSavedSearchList(inputParams: any): void {
        const scope: any = this;
        this.getSearchList.emit({
            'inputParams': inputParams,
            'callBack': (results) => {
                scope.savedSearchList = results;
                scope.copyOfSavedSearch = Object.assign([], scope.savedSearchList);
                scope.isNoResultsDisplay = scope.copyOfSavedSearch.length === 0;
            }
        });
    }

    onCloseModal(): void {
        this.hideSavedSearchModal.emit();
    }

    onRepopulateSavedSearchList(data: any): void {
        this.repopulatedList.emit(data);
        this.onCloseModal();
    }

    onSearchFieldKeyUpPressed(event: any): void {
        this.savedSearchModel.savedSearchList = [];
        const txtBoxValue: any = event.target.value;
        const iteratedResults: any = this.savedSearchModel.copyOfSavedSearch.filter(function (item: any): any {
            const itemValue: any = (item && item['userSearchName']) ? item['userSearchName'] : '';
            return typeof itemValue === 'string' && itemValue.toLowerCase().indexOf(txtBoxValue.toLowerCase()) > -1;
        });
        this.savedSearchModel.savedSearchList = this.savedSearchModel.copyOfSavedSearch;
        if (iteratedResults.length !== 0) {
            this.savedSearchModel.savedSearchList = iteratedResults;
        }
    }

    ResetFields(): void {
        this.selectedFavorite = '';
        this.savedSearchModel.savedSearchList = this.savedSearchModel.copyOfSavedSearch;
    }

    ngOnDestroy(): void {
        for (const subs of this.subscriptions) {
            subs.unsubscribe();
        }
    }

}
