import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit, ViewChild, ViewChildren } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

import { JBHGlobals } from '../../../app.service';
import { CreateChangeRequestService } from '../create-change-request/services/create-change-request.service';
import { AdvanceSearchModel } from './models/advance-search.model';
import { ChangeRequestFormBuilderService } from '../services/change-request-form-builder.service';
import { CreateChangeRequestComponent } from '../create-change-request/create-change-request.component';
import { AdvanceSearchService } from './services/advance-search.service';
import { LocalStorageService } from 'jbh-components/jbh-core-services';

@Component({
  selector: 'app-advance-search',
  templateUrl: './advance-search.component.html',
  styleUrls: ['./advance-search.component.scss'],
  providers: [CreateChangeRequestService],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AdvanceSearchComponent implements OnInit {

  userInfoJson: object = {
    'personid': this.jbhGlobals.user.userDetails.userId
  };

  @ViewChild(CreateChangeRequestComponent) createChangeRequestComponent: CreateChangeRequestComponent;
  advanceSearchModel: AdvanceSearchModel;
  createChangeRequest: FormGroup;
  constructor(
    public jbhGlobals: JBHGlobals,
    private router: Router,
    private changeDetector: ChangeDetectorRef,
    private formBuilder: FormBuilder,
    public crFormBuilderService: ChangeRequestFormBuilderService,
    public createChangeRequestService: CreateChangeRequestService,
    private localStorageService: LocalStorageService,
    private advanceSerachService: AdvanceSearchService
  ) {
    this.advanceSearchModel = new AdvanceSearchModel();
    this.createChangeRequest = this.crFormBuilderService.changeRequestForm['controls']['createChangeRequestType'];
  }

  ngOnInit(): void {
    this.advanceSearchModel.rows = [];
    this.setSerarchResultGridColumns();
    this.populateAdvanceSearchTable();
  }

  setSerarchResultGridColumns(): void {
    const columnCacheData: any = this.jbhGlobals.localStore.getItem('OrderSearch', 'userColumnPref', true);
    this.advanceSearchModel.searchGridColumns = this.advanceSerachService.getStaticGridColumnsJSON();
    if (columnCacheData) {
      const columnParsedData: any = JSON.parse(columnCacheData);
      if (columnParsedData[this.userInfoJson['personid']]
        && columnParsedData[this.userInfoJson['personid']]['OrderSearchGridColumns']) {
        this.advanceSearchModel.searchGridColumns = {
          'gridColumns': columnParsedData[this.userInfoJson['personid']]['OrderSearchGridColumns']
        };
      }
    }
  }

  onCreateCRModalOpen(event: object): void {
    console.log(this.createChangeRequestComponent);
    this.createChangeRequestComponent.createNewChangeRequestModal.show();
  }

  loadGridData(results: any): any {
    this.advanceSearchModel.searchGridResult = Object.assign({}, { gridDataArray: [], count: 0 });
    this.advanceSearchModel.searchGridResult['count'] = results['hits']['total'];
    const data: Array<object> = results['hits']['hits'];
    if (data && data.length > 0) {
      this.advanceSearchModel.rows = [];
      const dataLength: number = data.length;
      for (let i: any = 0; i < dataLength; i++) {
        const obj: any = {};
        const customer: any = data[i]['_source']['customerDTO'];
        const ldcData: any = data[i]['_source']['ldcAddressDTO'];
        if (customer) {
          data[i]['_source']['customerDTO'] = `${customer['addressDTO']['addressLine1']}${', '}${', '}
            ${customer['addressDTO']['city']}${', '}${customer['addressDTO']['state']}${', '}
            ${customer['addressDTO']['country']}${', '}${customer['addressDTO']['zipcode']}`;
        }
        if (ldcData) {
            data[i]['_source']['ldcAddressDTO'] = `${ldcData['addressLine1']}${', '}
                ${ldcData['city']}${', '}${ldcData['state']}${', '}
                ${ldcData['country']}${', '}${ldcData['zipcode']}`;
        }
        this.advanceSearchModel.rows.push(data[i]['_source']);
      }
      this.advanceSearchModel.searchGridResult['gridDataArray'] = this.advanceSearchModel.rows;
    } else {
      this.advanceSearchModel.noRecordFound = true;
      this.advanceSearchModel.firstLoadFlag = false;
    }
    this.changeDetector.detectChanges();
  }
  onSearchOrder(eve: any): void {
    this.advanceSearchModel.param = eve;
    this.advanceSearchModel.firstLoadFlag = true;
    this.populateAdvanceSearchTable();
  }
  onGridColumnManaged(columns: any): void {
    this.populateAdvanceSearchTable();
  }
  paginationLimit(event: any): void {
      this.advanceSearchModel.pageLimit = event.from,
      this.advanceSearchModel.pageSize = event.size;
      this.populateAdvanceSearchTable();
  }
  populateAdvanceSearchTable(): void {
    const advanceSearchTableUrl: string = this.jbhGlobals.endpoints.changerequest.transitGuideTable;
    const requestQuery: any = this.localStorageService.getItem('ChangeRequestQuery', 'queryValue', false);
    if (requestQuery) {
        this.advanceSearchModel.param = requestQuery;
    }
    if (this.advanceSearchModel.param) {
        this.advanceSearchModel.param['from'] = this.advanceSearchModel.pageLimit ? this.advanceSearchModel.pageLimit : 0;
        this.advanceSearchModel.param['size'] = this.advanceSearchModel.pageSize ? this.advanceSearchModel.pageSize : 100; 
    }
    this.advanceSerachService.getTransitGridRecords(advanceSearchTableUrl, this.advanceSearchModel.param)
      .subscribe((data: any) => {
        if (data) {
          this.loadGridData(data);
        }
      });
  }
}
