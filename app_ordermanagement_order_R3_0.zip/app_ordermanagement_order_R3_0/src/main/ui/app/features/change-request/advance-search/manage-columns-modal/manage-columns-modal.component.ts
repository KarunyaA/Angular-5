import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ManageColumnsModel } from './../models/manage-columns.model';

@Component({
    selector: 'app-manage-columns-modal',
    templateUrl: './manage-columns-modal.component.html',
    styleUrls: ['./manage-columns-modal.component.scss']
})
export class ManageColumnsModalComponent implements OnInit {

    @Input()
    set gridColumns(gridColumnsArr: any) {
        this.columns = gridColumnsArr;
        this.copyOfColumns = Object.assign([], this.columns);
    }
    @Input()
    set editColumnUpdateStatus(editColumnStatusMsgJson: any) {
        if (editColumnStatusMsgJson) {
            this.errorStatus = editColumnStatusMsgJson['statusCode'];
            this.errorMessage = editColumnStatusMsgJson['message'];
        }
    }
    @Output() hideEditColumnModel: any = new EventEmitter<any>();
    @Output() updateColumModel: any = new EventEmitter<any>();

    columns: any = [];
    copyOfColumns: any = [];
    errorStatus: string;
    errorMessage: string;
    manageColumnsModel: any;

    ngOnInit(): void {
        this.manageColumnsModel = new ManageColumnsModel();
        this.initModelProperties();
    }

    initModelProperties(): void {
        this.manageColumnsModel.minimumNoOfColumns = 3;
        this.manageColumnsModel.visibleProperty = 'isVisible';
    }

    onCloseModal(): void {
        this.columns = this.copyOfColumns;
        this.hideEditColumnModel.emit();
        this.ResetFields();
        this.resetContainer();
    }

    onSaveBtnClicked(): void {
        this.resetColumnFields();
        this.copyOfColumns = this.columns;
        this.updateColumModel.emit(this.columns);
    }

    onManageColumnVisibility(columnJsonArg: object): void {
        const columnDataProp: any = this.checkAndReturnValidColumn(columnJsonArg['prop']);
        if (columnDataProp['isMinimumColumsExists']) {
            columnDataProp['column']['isVisible'] = !columnDataProp['column']['isVisible'];
        } else {
            columnDataProp['column']['isVisible'] = true;
        }
    }

    checkAndReturnValidColumn(columnProperty: string): object {
        let counter: any = 0;
        const columnJsonProp: any = {
            isMinimumColumsExists: false,
            columnJsonProp: {}
        };
        for (let columnIdx: any = 0; columnIdx < this.columns.length; columnIdx++) {
            const columnJson: any = this.columns[columnIdx];
            if (columnJson[this.manageColumnsModel.visibleProperty]) {
                counter = counter + 1;
            }
            if (columnProperty === columnJson['prop']) {
                columnJsonProp['column'] = columnJson;
            }
        }
        columnJsonProp['isMinimumColumsExists'] = (counter > this.manageColumnsModel.minimumNoOfColumns);
        return columnJsonProp;
    }

    onSearchFieldKeyUpPressed(event: any): void {
        const txtBoxValue: any = event.target.value;
        const iteratedResults: any = this.copyOfColumns.filter(function (item: any): any {
        const itemValue: any = (item && item['name']) ? item['name'] : '';
        return typeof itemValue === 'string' && itemValue.toLowerCase().indexOf(txtBoxValue.toLowerCase()) > -1;
        });
        this.columns = this.copyOfColumns;
        if (iteratedResults.length !== 0) {
            this.columns = iteratedResults;
        }
        this.resetContainer();
    }

    ResetFields(): void {
        this.manageColumnsModel.selectedColumn = '';
        this.columns = this.copyOfColumns;
    }

    resetColumnFields(): void {
        this.manageColumnsModel.selectedColumn = '';
        if (this.copyOfColumns.length !== this.columns.length) {
            const columnsArray: any = [];
            const copyColumnsLength: number = this.copyOfColumns.length;
            for (let idx: any = 0; idx < copyColumnsLength; idx++) {
                const filteredContent: any = this.columns.find((x: any) => x['property'] === this.copyOfColumns[idx]['property']);
                if (filteredContent) {
                    columnsArray.push(filteredContent);
                } else {
                    columnsArray.push(this.copyOfColumns[idx]);
                }
            }
            this.columns = columnsArray;
        }
    }

    resetContainer(): void {
        const container: any = document.getElementsByClassName('psScrollContainer')[0];
        container.scrollTop = 0;
    }

}
