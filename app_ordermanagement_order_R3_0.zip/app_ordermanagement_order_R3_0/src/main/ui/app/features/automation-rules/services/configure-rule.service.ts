import { Injectable } from '@angular/core';
import { Validators } from '@angular/forms';

import * as moment from 'moment';

@Injectable()
export class ConfigureRuleService {

    constructor() { }
    loadAllAttributes(configurerulecomponent): void {
        const loadRulePramURL = configurerulecomponent.jbhGlobals.endpoints.automationrules.getAllOrderRuleParamTypes;
        configurerulecomponent.automationRulesService.fetchData(loadRulePramURL, null, false).takeWhile(() =>
        configurerulecomponent.configureRuleModel.subscribeFlag).subscribe(data => {
                configurerulecomponent.configureRuleModel.orderRuleParamsList = data;
            });
        // Get all Attributes
        const loadAttrURL = configurerulecomponent.jbhGlobals.endpoints.automationrules.getAllAttributeTypes;
        configurerulecomponent.automationRulesService.fetchData(loadAttrURL, null, false).takeWhile(() =>
            configurerulecomponent.configureRuleModel.subscribeFlag).subscribe(data => {
                configurerulecomponent.configureRuleModel.attributesList = data['attributes'];
                configurerulecomponent.getRule();
            });
    }

    loadOrderRuleCriterias(configurerulecomponent): void {
        // Get all Order Rule Criterias
        const filterList = [];
        const thisVal = configurerulecomponent;
        if (configurerulecomponent.configureRuleModel.associationLevel === 'BusUnit') {
            configurerulecomponent.configureRuleModel.attributeParams = {
                'orderRuleType': 'BusUnit'

            };
        } else {
            configurerulecomponent.configureRuleModel.attributeParams = {
                'orderRuleType': 'Customer'
            };
            }

        const url = configurerulecomponent.jbhGlobals.endpoints.automationrules.getOrderRuleCriterias;
        configurerulecomponent.automationRulesService.fetchData(url,
            configurerulecomponent.configureRuleModel.attributeParams, null).takeWhile(() =>
                configurerulecomponent.configureRuleModel.subscribeFlag).subscribe(data => {
                    configurerulecomponent.configureRuleHelperService.loadAttr(data, configurerulecomponent.configureRuleModel);
                    this.loadOrderCreationChannel(configurerulecomponent);
                    this.loadAllAttributes(configurerulecomponent);
                });
    }
    removeAttribute(configurerulecomponent, event): void {
        if (event.values.detailId === null || event.values.detailId === undefined || event.values.detailId === '') {
            configurerulecomponent.configureRuleModel.ruleForm.controls.orderRuleCriteriaDetail.removeAt(event.values.id);
        } else {
            const detUrl = `${configurerulecomponent.jbhGlobals.endpoints.automationrules.
                deleteAttr}/${event.values.criSetId}/${event.values.detailId}`;
            configurerulecomponent.automationRulesService.deleteData(detUrl).takeWhile(() =>
                configurerulecomponent.configureRuleModel.subscribeFlag).subscribe(data => {
                    configurerulecomponent.configureRuleModel.ruleForm.controls.orderRuleCriteriaDetail.removeAt(event.values.id);
                });
        }
    }
    loadOrderCreationChannel(configurerulecomponent): void {
        // Get all Order Creation Channel
        const url = configurerulecomponent.jbhGlobals.endpoints.automationrules.getOrderCreationChannel;
        configurerulecomponent.automationRulesService.fetchData(url, null, true).takeWhile(() =>
        configurerulecomponent.configureRuleModel.subscribeFlag).subscribe(data => {
                configurerulecomponent.configureRuleModel.channelList = [];
                if (!configurerulecomponent.jbhGlobals.utils.isEmpty(data)) {
                    for (const item of data) {
                        configurerulecomponent.configureRuleModel.channelList.push({
                            'id': item.value, 'text': item.value
                        });
                    }
                }
            });
    }

    ordChnRemoved(configurerulecomponent, event): void {
        if (event['id'] !== null) {

            const detUrl = `${configurerulecomponent.jbhGlobals.endpoints.automationrules.
                deleteAttr}/${configurerulecomponent.configureRuleModel.orderRuleCriteriaSetID}/${event['id']}`;
            configurerulecomponent.automationRulesService.deleteData(detUrl).takeWhile(() =>
                configurerulecomponent.configureRuleModel.subscribeFlag).subscribe(data => { });
        }
    }

    saveRule(configurerulecomponent, mode): void {
        configurerulecomponent.configureRuleHelperService.setFormValidation(configurerulecomponent.bu,
            configurerulecomponent.so, configurerulecomponent.configureRuleModel);
        if (configurerulecomponent.configureRuleModel.isCustomerLevelRules) {
            if (configurerulecomponent.configureRuleHelperService.checkAttrArray(configurerulecomponent.configureRuleModel)) {
                configurerulecomponent.configureRuleModel.saveFlag = true;
            } else {
                configurerulecomponent.jbhGlobals.notifications.alert('Failure', `Please add ${configurerulecomponent.
                    configureRuleModel.mandatoryAttr} Attribute`);
                configurerulecomponent.configureRuleModel.saveFlag = false;
            }
        } else {
            configurerulecomponent.configureRuleModel.saveFlag = true;
        }
        for (let i = 0; i < configurerulecomponent.configureRuleModel.ruleForm.controls.orderRuleCriteriaDetail.controls.length; i++) {
            const attrVal = configurerulecomponent.configureRuleModel.ruleForm.controls.orderRuleCriteriaDetail
                .controls[i].controls['orderRuleCriteriaCode'].value;
            if (!configurerulecomponent.jbhGlobals.utils.isEmpty(attrVal)) {
                const attrType = configurerulecomponent.configureRuleModel.attributesList[attrVal].type;
                const attrOpt = configurerulecomponent.configureRuleModel.ruleForm.controls.orderRuleCriteriaDetail.controls[i].controls
                ['orderRuleLogicalOperatorDTO']['controls']['orderRuleLogicalOperatorCode'].value;
                if (attrOpt === 'GrtLessThn') {
                    configurerulecomponent.checkEmptyTime(i, 'orderRuleCriteriaValueEnd', attrType);
                }
                configurerulecomponent.checkEmptyTime(i, 'orderRuleCriteriaValue', attrType);
            }
        }
        if (configurerulecomponent.configureRuleModel.ruleForm.valid && configurerulecomponent.validateDates()
            && configurerulecomponent.configureRuleModel.saveFlag) {
            const saveUrl = configurerulecomponent.jbhGlobals.endpoints.automationrules.saverule;
            const val = configurerulecomponent.configureRuleModel.ruleForm.value;
            const orderCrChn = val.orderCreationChannel;
            const tempSo = val.serviceOffering;
            const tempBu = val.businessUnit;
            const cDet = val.orderRuleCriteriaDetail;
            const effTimeStamp = configurerulecomponent.configureRuleHelperService.setDateTimeFormat(val.effectiveDate.jsdate,
                val.effectiveTime);
            const expTimeStamp = configurerulecomponent.configureRuleHelperService.setDateTimeFormat(val.expirationDate.jsdate,
                val.expirationTime);
            const obj = this.saveFormObject(configurerulecomponent, mode, val, effTimeStamp, expTimeStamp,
                orderCrChn, configurerulecomponent.so, tempSo, configurerulecomponent.bu, tempBu, cDet);
            configurerulecomponent.jbhGlobals.apiService.addData(saveUrl, obj).takeWhile(() =>
                configurerulecomponent.configureRuleModel.subscribeFlag).subscribe(data => {
                    const isSuccess = data['status'] === 'success';
                    if (isSuccess) {
                        configurerulecomponent.jbhGlobals.notifications.success('Success', 'Rule Configured Successfully');
                        configurerulecomponent.loadCriteriaList();
                    } else {
                        configurerulecomponent.jbhGlobals.notifications.alert('Failure', 'Rule Configuration Failed');
                    }
                });
        } else if (!configurerulecomponent.configureRuleModel.ruleForm.valid || !configurerulecomponent.validateDates()) {
            const me = configurerulecomponent;
            if (configurerulecomponent.effectiveDatePicker.selectionDayTxt === '') {
                configurerulecomponent.configureRuleModel.effectiveDateFlag = true;
            } else {
                configurerulecomponent.configureRuleModel.effectiveDateFlag = false;
            }
            if (configurerulecomponent.expirationDatePicker.selectionDayTxt === '') {
                configurerulecomponent.configureRuleModel.expirationDateFlag = true;
            } else {
                configurerulecomponent.configureRuleModel.expirationDateFlag = false;
            }
            if (configurerulecomponent.configureRuleModel.ruleForm.get('orderCreationChannel').value === null ||
                configurerulecomponent.configureRuleModel.ruleForm.controls.orderCreationChannel.value.length === 0) {
                configurerulecomponent.jbhGlobals.utils.forIn(
                    configurerulecomponent.configureRuleModel.ruleForm.controls.orderCreationChannel,

                    function(value, name, object): void {
                        me.configureRuleModel.ruleForm.controls.orderCreationChannel.markAsTouched();
                    });
                configurerulecomponent.configureRuleModel.ruleForm.get('orderCreationChannel').setErrors({
                    'mandatorySelect': true
                });
            }
            const attrlen = me.configureRuleModel.ruleForm.controls.orderRuleCriteriaDetail.controls.length;
            for (let i = 0; i < attrlen; i++) {
                configurerulecomponent.attributeViewComponent.attrValidation(configurerulecomponent.configureRuleModel.ruleForm.controls
                ['orderRuleCriteriaDetail'].controls[i], i);
            }
            configurerulecomponent.jbhGlobals.notifications.alert('Failure', 'Please enter Valid details');
        }
    }
    saveFormObject(configurerulecomponent, mode, val, effTimeStamp, expTimeStamp, orderCrChn, so, tempSo, bu, tempBu, cDet): any {
        const obj = {
            'orderRuleCriteriaSetID': (mode === 'copy') ? null : val.orderRuleCriteriaSetID,
            'orderRuleDetailID': val.orderRuleDetailID,
            'orderRuleSupersedeTypeCode': (val.orderRuleSupersedeTypeCode === true) ? 'Suprsed' : 'NotSuprsed',
            'effectiveTimestamp': effTimeStamp,
            'expirationTimestamp': expTimeStamp,
            'orderRuleCriteriaDetailDTO': [],
            'orderRuleParameterDTO': val.orderRuleParameterDetail
        };
        if (orderCrChn !== null && orderCrChn !== '' && orderCrChn.length > 0) {
            for (let cnt = 0; cnt < orderCrChn.length; cnt++) {
                obj.orderRuleCriteriaDetailDTO.push({
                    'orderRuleCriteriaValue': orderCrChn[cnt].text,
                    'orderRuleCriteriaDetailID': null,
                    'orderRuleCriteriaDescription': '',
                    'orderRuleCriteriaCode': 'OrdChannel'
                });
            }
        }
        if (so.nativeElement.checked === true) {
            if (tempSo !== null && tempSo !== '' && tempSo.length > 0) {
                for (let cnt1 = 0; cnt1 < tempSo.length; cnt1++) {
                    obj.orderRuleCriteriaDetailDTO.push({
                        'orderRuleCriteriaValue': tempSo[cnt1]['text'],
                        'orderRuleCriteriaDetailID': null,
                        'orderRuleCriteriaDescription': '',
                        'orderRuleCriteriaCode': 'BUServOffr'
                    });
                }
            }
        }
        if (bu.nativeElement.checked === true) {
            if (tempBu !== null && tempBu !== '' && tempBu.length > 0) {
                for (let cnt1 = 0; cnt1 < tempBu.length; cnt1++) {
                    obj.orderRuleCriteriaDetailDTO.push({
                        'orderRuleCriteriaValue': tempBu[cnt1]['text'],
                        'orderRuleCriteriaDetailID': null,
                        'orderRuleCriteriaDescription': '',
                        'orderRuleCriteriaCode': 'BusUnit'
                    });
                }
            }
        }
        return this.loopObjct(configurerulecomponent, mode, cDet, obj, effTimeStamp, expTimeStamp);
    }
    loopObjct(configurerulecomponent, mode, cDet, obj, effTimeStamp, expTimeStamp): any {
        for (let attrCnt = 0; attrCnt < cDet.length; attrCnt++) {
            cDet[attrCnt].orderRuleCriteriaDetailID = null;
            const selOpt = cDet[attrCnt].orderRuleLogicalOperatorDTO.orderRuleLogicalOperatorCode;
            if ((selOpt === 'GrtLessThn' || selOpt === 'Between') &&
                (cDet[attrCnt].orderRuleCriteriaValue !== null && cDet[attrCnt].orderRuleCriteriaValueEnd !== null)) {
                cDet[attrCnt].orderRuleLogicalOperatorDTO['effectiveTimestamp'] = effTimeStamp;
                cDet[attrCnt].orderRuleLogicalOperatorDTO['expirationTimestamp'] = expTimeStamp;
                cDet[attrCnt].orderRuleCriteriaValue = this.assignCriteriaValue(cDet[attrCnt]);
                cDet[attrCnt].orderRuleLogicalOperatorDTO['orderRuleLogicalOperatorCode'] = 'GrtThn';
                obj.orderRuleCriteriaDetailDTO.push(cDet[attrCnt]);
                const endVal = Object.assign({}, cDet[attrCnt], {
                    orderRuleCriteriaDetailID: null,
                    orderRuleCriteriaValue: this.assignCriteriaValue(cDet[attrCnt], true),
                    orderRuleLogicalOperatorDTO: {
                        orderRuleLogicalOperatorCode: 'LessThan',
                        effectiveTimestamp: effTimeStamp,
                        expirationTimestamp: expTimeStamp
                    }
                });
                obj.orderRuleCriteriaDetailDTO.push(endVal);
            } else {
                /* cDet[attrCnt].orderRuleLogicalOperatorDTO['effectiveTimestamp'] = effTimeStamp;
                cDet[attrCnt].orderRuleLogicalOperatorDTO['expirationTimestamp'] = expTimeStamp;
                cDet[attrCnt].orderRuleCriteriaValue = this.assignCriteriaValue(cDet[attrCnt]);
                obj.orderRuleCriteriaDetailDTO.push(cDet[attrCnt]); */
                const cuurentAttrValue = cDet[attrCnt]['orderRuleCriteriaValue'];
                const selectedAttr = configurerulecomponent.configureRuleModel.attributesList
                [cDet[attrCnt].orderRuleCriteriaCode]['selectionAttr'];
                if (typeof (cuurentAttrValue) !== 'string' && cuurentAttrValue.length > 0) {
                    for (let cntt = 0; cntt < cuurentAttrValue.length; cntt++) {
                        const temp = JSON.parse(JSON.stringify(cDet[attrCnt]));
                        // cDet[attrCnt].id = id
                        temp.orderRuleLogicalOperatorDTO['effectiveTimestamp'] = effTimeStamp;
                        temp.orderRuleLogicalOperatorDTO['expirationTimestamp'] = expTimeStamp;
                        temp.orderRuleCriteriaValue = cuurentAttrValue[cntt].id;
                        obj.orderRuleCriteriaDetailDTO.push(temp);
                    }
                } else {
                    cDet[attrCnt].orderRuleLogicalOperatorDTO['effectiveTimestamp'] = effTimeStamp;
                    cDet[attrCnt].orderRuleLogicalOperatorDTO['expirationTimestamp'] = expTimeStamp;
                    cDet[attrCnt].orderRuleCriteriaValue = this.assignCriteriaValue(cDet[attrCnt]);
                    obj.orderRuleCriteriaDetailDTO.push(cDet[attrCnt]);
                }
            }
        }
        for (let cnt = 0; cnt < obj.orderRuleCriteriaDetailDTO.length; cnt++) {
            obj.orderRuleCriteriaDetailDTO[cnt].effectiveTimestamp = effTimeStamp;
            obj.orderRuleCriteriaDetailDTO[cnt].expirationTimestamp = expTimeStamp;
        }
        for (let cnt1 = 0;
            (obj.orderRuleParameterDTO !== null && cnt1 < obj.orderRuleParameterDTO.length); cnt1++) {
            const pId = obj.orderRuleParameterDTO[cnt1].orderRuleParameterID;
            obj.orderRuleParameterDTO[cnt1].orderRuleParameterID = (mode === 'copy') ? null : pId;
            obj.orderRuleParameterDTO[cnt1].effectiveTimestamp = effTimeStamp;
            obj.orderRuleParameterDTO[cnt1].expirationTimestamp = expTimeStamp;
            obj.orderRuleParameterDTO[cnt1].orderParameterDateValue = this.assignResultantActionValues(
                obj.orderRuleParameterDTO[cnt1], obj.orderRuleParameterDTO[cnt1].orderParameterDateValue, true);
            obj.orderRuleParameterDTO[cnt1].orderParameterCharValue = this.assignResultantActionValues(
                obj.orderRuleParameterDTO[cnt1], obj.orderRuleParameterDTO[cnt1].orderParameterCharValue, false);
        }
        return obj;
    }
    assignCriteriaValue(criObj, isEndValue ?: boolean): any {
        const value = (isEndValue) ? criObj.orderRuleCriteriaValueEnd : criObj.orderRuleCriteriaValue;
        const code = criObj.orderRuleCriteriaCode;
        if (typeof (value) === 'object' && (code === 'Earlydelap' || code === 'Latedelap' || code === 'Ordtime')) {
            return moment(new Date(value)).format('HH:mm');
        } else if (typeof (value) === 'object' && code === 'Earlypikap' || code === 'Latepikap' || code === 'Orddate') {
            return moment(new Date(value.formatted)).format('YYYY-MM-DD');
        } else if (code === 'TradePart' || code === 'Fleetcode' ||
            code === 'PickMarket' || code === 'DelMarket' ||
            code === 'Delstate' || code === 'Pickstate' ||
            code === 'Delcity' || code === 'Pickcity' || code === 'Pickcntry' || code === 'Itemdsc' ||
            code === 'Customer' || code === 'BillParty' || code === 'LOB' || code === 'Solicitor') {
            return criObj.selectedCriteriaValue;
        }
        return value;
    }
    assignResultantActionValues(paramDetails, value, isDate): any {
        const code = paramDetails.orderParameterName;
        if (!isDate && value !== null && typeof (value) === 'object' && (code === 'FxdTimeHr' || code === 'FxdEndTime' ||
            code === 'BegEndTime' || code === 'CustAppoTm' || code === 'FxdBegTime')) {
            return moment(new Date(value)).format('HH:mm');
        } else if (isDate && value !== null && typeof (value) === 'object' && code === 'CustAppoDt') {
            if (value.formatted === '00-00-0') {
                return null;
            } else {
                return moment(new Date(value.formatted)).format('YYYY-MM-DD');
            }
        }
        return value;
    }

    createForm(configurerulecomponent, validators): void {
        const ruleDet = configurerulecomponent.ruleService.ruleDetails;
        configurerulecomponent.configureRuleModel.ruleForm = configurerulecomponent.fb.group({
            orderRuleCriteriaSetID: ruleDet.orderRuleCriteriaSetID,
            orderRuleDetailID: ruleDet.orderRuleDetailID,
            serviceOffering: [
                [], ruleDet.isBusinessUnitLevelRules ?
                configurerulecomponent.jbhGlobals.customValidator.mandatorySelect : []
            ],
            businessUnit: [
                [], ruleDet.isBusinessUnitLevelRules ?
                configurerulecomponent.jbhGlobals.customValidator.mandatorySelect : []
            ],
            orderCreationChannel: [
                [], validators.compose([configurerulecomponent.jbhGlobals.customValidator.mandatorySelect])
            ],
            orderRuleSupersedeTypeCode: (ruleDet.orderRuleSupersedeTypeCode === 'Suprsed') ? true : false,
            effectiveDate: ['', validators.required],
            expirationDate: ['', validators.required],
            effectiveTime: ['', configurerulecomponent.jbhGlobals.customValidator.mandatory],
            expirationTime: ['', configurerulecomponent.jbhGlobals.customValidator.mandatory],
            effectiveTimestamp: '',
            expirationTimestamp: '',
            orderRuleCriteriaDetail: configurerulecomponent.fb.array([
                this.initCriteriaDetails(null, configurerulecomponent)
            ]),
            orderRuleParameterDetail: configurerulecomponent.ruleService.ruleDetails.mode === 'new' ?
                null : configurerulecomponent.fb.array([
                    this.initOrderRuleParameterDetails(null, configurerulecomponent)
                ])
        });
    }
    initCriteriaDetails(currSet, configurerulecomponent): any {
        const orderRuleCriteriaDescriptionVal = (currSet !== null) ? currSet.orderRuleCriteriaDescription : '';
        const orderRuleLogicalOperatorCodeVal = (currSet !== null) ? currSet.orderRuleLogicalOperatorDTO.orderRuleLogicalOperatorCode : '';
        return configurerulecomponent.fb.group({
            orderRuleLogicalOperatorDTO: configurerulecomponent.fb.group({
                orderRuleLogicalOperatorCode: [orderRuleLogicalOperatorCodeVal,
                    configurerulecomponent.jbhGlobals.customValidator.mandatorySelect]
            }),
            selectedCriteriaValue: (currSet !== null) ? currSet.orderRuleCriteriaValue : '',
            // orderRuleCriteriaValue: [(currSet !== null) ?
            //     this.loadMultipleCriteriaValue(currSet.orderRuleCriteriaValues, configurerulecomponent, currSet) : '',
            //     configurerulecomponent.jbhGlobals.customValidator.mandatorySelect],
            orderRuleCriteriaValue: (currSet !== null) ?
            this.loadMultipleCriteriaValue(currSet.orderRuleCriteriaValues, configurerulecomponent, currSet) : [ '',
                    configurerulecomponent.jbhGlobals.customValidator.mandatory],
            orderRuleCriteriaValueEnd: (currSet !== null) ? currSet.orderRuleCriteriaValueEnd : '',
            orderRuleCriteriaDetailEndLimitID: (currSet !== null) ? currSet.orderRuleCriteriaDetailEndLimitID : null,
            orderRuleCriteriaDetailID: null,
            orderRuleCriteriaDescription: [orderRuleCriteriaDescriptionVal],
            orderRuleCriteriaCode: [(currSet !== null) ? currSet.orderRuleCriteriaCode : '',
            configurerulecomponent.jbhGlobals.customValidator.mandatory]
        });
    }
    loadMultipleCriteriaValue(orderCriteriaValues, configurerulecomponent, currSet): any {
        const tempArray = [];
        const multiselectType = configurerulecomponent.configureRuleModel.attributesList
        [currSet.orderRuleCriteriaCode].type;
        const multiselectFlag = (multiselectType === 'multiselect' || multiselectType === 'multiselectDropdown') ? true : false;
        if (multiselectFlag) {
            for (const criDetVal of orderCriteriaValues) {
                const obj = {
                    'id': criDetVal.orderRuleCriteriaValue,
                    'text': criDetVal.orderRuleCriteriaValueDescription
                };
                // obj['id'][multiselectType === 'multiselect' ? configurerulecomponent.configureRuleModel.attributesList
                // [currSet.orderRuleCriteriaCode]['selectionAttr'] : 'id'] = criDetVal.orderRuleCriteriaValue;
                tempArray.push(obj);
            }
        }
        return multiselectFlag === true ? [tempArray, multiselectType === 'multiselectDropdown' ?
            configurerulecomponent.jbhGlobals.customValidator.mandatorySelect :
            []]
            : [multiselectType === 'typeahead' ? currSet.orderRuleCriteriaValues[0].orderRuleCriteriaValueDescription :
            currSet.orderRuleCriteriaValue, configurerulecomponent.jbhGlobals.customValidator.mandatory];
    }

    initOrderRuleParameterDetails(currSet, configurerulecomponent): any {
        const isValid = (currSet !== null);
        const isTypeValid = (currSet !== null && currSet.orderRuleParameterTypeDTO !== null);
        return configurerulecomponent.fb.group({
            orderRuleParameterID: isValid ? currSet.orderRuleParameterID : '',
            orderParameterName: isValid ? currSet.orderParameterName : '',
            orderParameterDescription: isValid ? currSet.orderParameterDescription : '',
            orderParameterNumberValue: isValid ? currSet.orderParameterNumberValue : '',
            orderParameterCharValue: isValid ? currSet.orderParameterCharValue : '',
            orderParameterDateValue: isValid ? currSet.orderParameterDateValue : '',
            orderRuleParameterTypeDTO: (currSet !== null) ? configurerulecomponent.fb.group({
                orderRuleParameterTypeCode: isTypeValid ? currSet.orderRuleParameterTypeDTO.orderRuleParameterTypeCode : '',
                orderRuleParameterTypeDescription: isTypeValid ? currSet.orderRuleParameterTypeDTO.orderRuleParameterTypeDescription : '',
                orderRuleParameterValueTypeCode: isTypeValid ? currSet.orderRuleParameterTypeDTO.orderRuleParameterValueTypeCode : ''
            }) : null
        });
    }
}
