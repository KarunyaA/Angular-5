import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PopoverModule } from 'ngx-bootstrap/popover';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AutomationRulesRoutingModule } from './automation-rules-routing.module';
import { RulesListComponent } from './rules-list/rules-list.component';
import { DateTimePickerModule } from 'ng-pick-datetime';
import { BsDropdownModule, ModalModule, TimepickerModule } from 'ngx-bootstrap';

import { SelectModule } from 'jbh-components/select';
import { JBHDataTableModule } from 'jbh-components/jbh-data-table/jbh-data-table.module';
import { RulesService } from './rules.service';
import { JbhSearchFilterModule } from 'jbh-components/jbh-search-filter/jbh-search-filter.module';
import { ConfiguredRulesListComponent } from './rules-list/configured-rules-list.component';
import { JbhValidationModule, TypeaheadModule } from 'jbh-components';
import { ConfigureRuleComponent } from './configure-rule/configure-rule.component';
import { MyDatePickerModule } from 'mydatepicker';
import { OrderRuleParamViewComponent } from './configure-rule/order-rule-param-view.component';
import { ViewRuleComponent } from './configure-rule/view-rule/view-rule.component';
import { AttributeViewComponent } from './configure-rule/attribute-view.component';
import { OperatorViewComponent } from './configure-rule/operator-view.component';
import { ConfirmationPopupModule } from 'jbh-components/confirmation-popup/confirmation-popup.module';

@NgModule({
    imports: [
        CommonModule,
        AutomationRulesRoutingModule,
        JBHDataTableModule,
        PopoverModule.forRoot(),
        TypeaheadModule.forRoot(),
        SelectModule,
        BsDropdownModule.forRoot(),
        FormsModule,
        ReactiveFormsModule,
        JbhSearchFilterModule,
        MyDatePickerModule,
        DateTimePickerModule,
        ModalModule.forRoot(),
        TimepickerModule.forRoot(),
        ConfirmationPopupModule,
        JbhValidationModule.forRoot()
    ],
    declarations: [
        RulesListComponent,
        ConfigureRuleComponent,
        ConfiguredRulesListComponent,
        OrderRuleParamViewComponent,
        ViewRuleComponent,
        AttributeViewComponent,
        OperatorViewComponent
    ],
    providers: [RulesService]
})
export class AutomationRulesModule { }
