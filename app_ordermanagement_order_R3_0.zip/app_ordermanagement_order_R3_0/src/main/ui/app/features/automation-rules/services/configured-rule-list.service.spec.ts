import { inject, TestBed } from '@angular/core/testing';

import { ConfiguredRuleListService } from './configured-rule-list.service';

describe('ConfiguredRuleListService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ConfiguredRuleListService]
    });
  });

  it('should be created', inject([ConfiguredRuleListService], (service: ConfiguredRuleListService) => {
    expect(service).toBeTruthy();
  }));
});
