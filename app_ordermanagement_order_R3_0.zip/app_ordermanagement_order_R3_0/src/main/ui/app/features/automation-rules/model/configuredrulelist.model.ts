
export class ConfiguredRuleListModel {
    totalRecordsCount: number;
    offset: number;
    limit: number;
    rows: string[];
    accountId: number;
    selected: string[];
    orderRuleName: string;
    serviceOfferings: Array<string>;
    associationLevels: Array<string>;
    orderRuleCategories: Array<string>;
    activeFlags: Array<string>;
    globalOverrideFlags: Array<string>;
    businessUnit: Array<string>;
    ruleMockData: Array<string>;
    debounceValue: number;
    ruleListUrl: string;
    ruleTypeAheadUrl: string;
    rulesGridMenu: any;
    rulesFilterTitle: string;
    flag: number;
    isBusinessUnitLevelRules: boolean;
    isCustomerLevelRules: boolean;
    effectiveStartDate: string;
    effectiveEndDate: string;
    expirationStartDate: string;
    expirationEndDate: string;
    billTo: any;
    onLoading: boolean;
    onNoResults: boolean;
    rulesFilterList: string[];
    filterList: any;
    subscribeFlag: boolean;
    billingPartyId: Array<number>;

    constructor() {
        this.selected = [];
        this.totalRecordsCount = 0;
        this.offset = 0;
        this.limit = 25;
        this.rulesFilterTitle = 'FILTER BY';
        this.flag = 0;
        this.isBusinessUnitLevelRules = true;
        this.isCustomerLevelRules = false;
        this.orderRuleName = '';
        this.rulesGridMenu = [{
            'name': 'Export To Excel',
            'id': 'exporttoexcel'
        },
        {
            'name': 'Configure New Rule',
            'id': 'configurenewrule'
        }
        ];
        this.effectiveStartDate = '';
        this.effectiveEndDate = '';
        this.expirationStartDate = '';
        this.expirationEndDate = '';
        this.serviceOfferings = [];
        this.associationLevels = [];
        this.orderRuleCategories = [];
        this.activeFlags = [];
        this.globalOverrideFlags = [];
        this.businessUnit = [];
        this.ruleMockData = [];
        this.rulesFilterList = [];
        this.subscribeFlag = true;
        this.billingPartyId = [];
        this.accountId = null;
    }
}
