import { Injectable } from '@angular/core';

@Injectable()
export class ConfiguredRuleListService {

    constructor() { }

    initializeVariables(configuredrulecomponent): void {
        configuredrulecomponent.configuredRuleListModel.filterList = [
            {
                'key': 'serviceOfferingCode',
                'index': 0,
                'title': 'Service Offering',
                'componentType': 'lsitType',
                'rootVal': ['_embedded', 'financeBusinessUnitServiceOfferingAssociations'],
                'params': {},
                'deepNestFlag': false,
                'framerMethod': 'soFramer',
                'url': configuredrulecomponent.jbhGlobals.endpoints.automationrules.getBuSO,
                'count': 0,
                'ruleCategory': 'common'
            }, {
                'key': 'Bill to Account',
                'index': 1,
                'title': 'Bill To Account',
                'checkSelectionKey': '_source.OrganizationName',
                'componentType': 'lsitType',
                'rootVal': ['hits', 'hits'],
                'valueField': ['_source', 'OrganizationName'],
                'methodType': 'addData',
                'serviceFilter': true,
                'deepNestFlag': true,
                'framerMethod': 'objectFramer',
                'url': configuredrulecomponent.jbhGlobals.endpoints.automationrules.gerBillToData,
                'params': {
                    'size': 5, '_source': ['OrganizationName', 'PartyID', 'CustomerCode',
                        'Address.AddressLine1', 'Address.AddressLine2', 'Address.CityName', 'Address.StateName',
                        'Address.CountryName', 'Address.PostalCode', 'ExpirationTimestamp', 'OrganizationStatusTypeCode'],
                    'query': {
                        'bool': {
                            'should': [{
                                'query_string': {
                                    'fields': ['OrganizationName^6', 'CustomerCode^3',
                                        'Address.AddressLine1^18', 'Address.AddressLine2^18', 'Address.CityName^15', 'Address.StateName^12',
                                        'Address.PostalCode^9', 'Address.CountryName', 'OrganizationName'], 'query': '*', 'default_operator': 'and'
                                }
                            }],
                            'minimum_should_match': 1, 'must': [{
                                'query_string': {
                                    'default_field': 'OrganizationStatusTypeCode.keyword', 'query':
                                        'Approved'
                                }
                            }, {
                                'nested': {
                                    'path': 'partyroles', 'query': {
                                        'match': {
                                            'partyroles.PartyRoleTypeDescription.keyword':
                                                'Bill To'
                                        }
                                    }, 'inner_hits': { 'size': 1, '_source': { 'includes': ['partyroles.PartyRoleTypeDescription'] } }
                                }
                            }]
                        }
                    }
                },
                'count': 0,
                'ruleCategory': 'customerLevel'
            }, {
                'key': 'Customer',
                'index': 2,
                'title': 'Association Level',
                'checkSelectionKey': 'orderRuleTypeDescription',
                'componentType': 'lsitType',
                'rootVal': ['_embedded', 'orderRuleTypes'],
                'url': configuredrulecomponent.jbhGlobals.endpoints.automationrules.getRulesTypes,
                'params': {},
                'count': 0,
                'ruleCategory': 'buLevel'
            }, {
                'key': 'ruleCategory',
                'index': 3,
                'title': 'Rule Category',
                'checkSelectionKey': 'orderRuleCategoryDescription',
                'rootVal': ['_embedded', 'orderRuleCategories'],
                'componentType': 'lsitType',
                'url': configuredrulecomponent.jbhGlobals.endpoints.automationrules.getRulesCategory,
                'params': {},
                'count': 0,
                'ruleCategory': 'common'
            }, {
                'key': 'status',
                'index': 4,
                'title': 'Global override flag status',
                'checkSelectionKey': 'status',
                'rootVal': ['_embedded', 'globalOverrideStatus'],
                'componentType': 'lsitType',
                'url': configuredrulecomponent.jbhGlobals.endpoints.automationrules.getGlobalOverrideStatus,
                'count': 0,
                'ruleCategory': 'buLevel'
            }, {
                'key': '_embedded',
                'index': 5,
                'title': 'Effective Start Date',
                'rootVal': '',
                'componentType': 'Date',
                'count': 0,
                'ruleCategory': 'common'
            }, {
                'index': 6,
                'key': '_embedded',
                'title': 'Expiration Date',
                'rootVal': '',
                'componentType': 'Date',
                'count': 0,
                'ruleCategory': 'common'
            }, {
                'index': 7,
                'key': '_embedded',
                'title': 'Status',
                'checkSelectionKey': 'status',
                'rootVal': ['_embedded', 'ruleStatus'],
                'componentType': 'lsitType',
                'url': configuredrulecomponent.jbhGlobals.endpoints.automationrules.getStatus,
                'params': {},
                'count': 0,
                'ruleCategory': 'common'
            }];
    }
    onViewEditRule(configuredrulecomponent, mode): any {
        const url = configuredrulecomponent.jbhGlobals.endpoints.automationrules.configurenewrule;
        const rs = configuredrulecomponent.rulesService;
        const criteriaSetUrl = `${url}/${rs.ruleDetails.orderRuleCriteriaSetID}`;
        let routeURL = '';
        configuredrulecomponent.automationRulesService.fetchData(criteriaSetUrl, null, true).takeWhile(() =>
            configuredrulecomponent.configuredRuleListModel.subscribeFlag).subscribe(data => {
                if (data !== null && data !== undefined) {
                    rs.selectedCriteriaDetails = data;
                    if (configuredrulecomponent.configuredRuleListModel.isBusinessUnitLevelRules === true) {
                        routeURL = (mode === 'edit') ? '/automationrules/configurenewrule' : '/automationrules/viewrule';
                    } else {
                        routeURL = (mode === 'edit') ? '/customerrules/configurenewrule' : '/customerrules/viewrule';
                    }
                    configuredrulecomponent.router.navigateByUrl(routeURL);
                } else if (data === null || data === undefined) {
                    configuredrulecomponent.jbhGlobals.notifications.alert('Failure', 'No details found');
                }
            }, (err: Error) => {
                return false;
            });
    }

    loadBillTo(configuredrulecomponent, partyId): void {
        const url = `${configuredrulecomponent.jbhGlobals.endpoints.automationrules.getBillTo + partyId}/accountinformations`;
        configuredrulecomponent.automationRulesService.fetchData(url, null, false).takeWhile(() =>
            configuredrulecomponent.configuredRuleListModel.subscribeFlag).subscribe(data => {
                if (data) {
                    if (!configuredrulecomponent.jbhGlobals.utils.isEmpty(data['accountInformationDTOs'])) {
                        if (configuredrulecomponent.jbhGlobals.utils.isArray(data['accountInformationDTOs']) &&
                            data['accountInformationDTOs'].length > 0) {
                            configuredrulecomponent.configuredRuleListModel.billTo = data['accountInformationDTOs'][0];
                        }
                    }
                }
            });
    }
    searchTypeAheadData(configuredrulecomponent, url, param, eve, el): void {
        const method = (el['methodType']) ? el['methodType'] : 'getData';
        const key = el['checkSelectionKey'];
        const root = el['rootVal'];
        configuredrulecomponent.jbhGlobals.apiService[method](url, param, false).takeWhile(() =>
            configuredrulecomponent.configuredRuleListModel.subscribeFlag).subscribe(data => {
                if (data) {
                    const dataList = data[root[0]][root[1]];
                    const dataListLength = dataList.length;
                    const arr = [];
                    const setData = eve.setDatda;
                    for (let i = 0; i < dataListLength; i++) {
                        arr.push(configuredrulecomponent.objectFramer(dataList[i]));
                    }
                    setData(arr);
                }
            });
    }
    getRuleName(configuredrulecomponent, event): void {
        configuredrulecomponent.configuredRuleListModel.ruleTypeAheadUrl =
            configuredrulecomponent.jbhGlobals.endpoints.automationrules.rulesTypeahead;
        if (event.length >= 2) {
            const ruleParam = {
                'orderRuleName': event
            };
            configuredrulecomponent.automationRulesService.fetchData(configuredrulecomponent.configuredRuleListModel.ruleTypeAheadUrl,
                ruleParam, false).takeWhile(() => configuredrulecomponent.configuredRuleListModel.subscribeFlag).subscribe(data => {
                    if (!configuredrulecomponent.jbhGlobals.utils.isEmpty(data)) {
                        configuredrulecomponent.configuredRuleListModel.ruleMockData = [];
                        configuredrulecomponent.configuredRuleListModel.ruleMockData = data;
                    }
                });
        }
    }
    loadGridData(configuredrulecomponent, pgParams?: Object): void {
        const listUrl = configuredrulecomponent.jbhGlobals.endpoints.automationrules.configuredruleslist;
        const params = {
            'businessUnit': configuredrulecomponent.configuredRuleListModel.businessUnit,
            'businessUnitServiceOffering': configuredrulecomponent.configuredRuleListModel.serviceOfferings,
            // 'orderRuleType': configuredrulecomponent.configuredRuleListModel.associationLevels,
            'orderRuleType': configuredrulecomponent.configuredRuleListModel.isBusinessUnitLevelRules ?
                ['Company', 'BusUnit'] : 'Customer',
            'orderRuleCategory': configuredrulecomponent.configuredRuleListModel.orderRuleCategories,
            'activeFlag': configuredrulecomponent.configuredRuleListModel.activeFlags,
            'orderRuleSupersede': configuredrulecomponent.configuredRuleListModel.globalOverrideFlags,
            'orderRuleName': configuredrulecomponent.configuredRuleListModel.orderRuleName,
            'effectiveStartDate': configuredrulecomponent.configuredRuleListModel.effectiveStartDate,
            'effectiveEndDate': configuredrulecomponent.configuredRuleListModel.effectiveEndDate,
            'expirationStartDate': configuredrulecomponent.configuredRuleListModel.expirationStartDate,
            'expirationEndDate': configuredrulecomponent.configuredRuleListModel.expirationEndDate,
            'customerId': configuredrulecomponent.configuredRuleListModel.accountId
        };
        const isPgPrmNotNull = (pgParams !== null && pgParams !== undefined);
        params['page'] = (isPgPrmNotNull) ? pgParams['page'] : 0;
        params['size'] = (isPgPrmNotNull) ? pgParams['size'] : configuredrulecomponent.configuredRuleListModel.limit;
        configuredrulecomponent.automationRulesService.fetchData(listUrl, params, true).takeWhile(() =>
            configuredrulecomponent.configuredRuleListModel.subscribeFlag).subscribe(data => {
                configuredrulecomponent.configuredRuleListModel.onNoResults = false;
                if (!configuredrulecomponent.jbhGlobals.utils.isEmpty(data)) {
                    configuredrulecomponent.configuredRuleListModel.rows = data['content'];
                    configuredrulecomponent.configuredRuleListModel.totalRecordsCount = data['totalElements'];
                } else {
                    configuredrulecomponent.configuredRuleListModel.rows = [];
                    configuredrulecomponent.configuredRuleListModel.totalRecordsCount = 0;
                }
            });
    }
    setUpKeyboardShortcuts(configuredrulecomponent): void {
        configuredrulecomponent.automationRulesService.getShortcut().takeWhile(() =>
            configuredrulecomponent.configuredRuleListModel.subscribeFlag).subscribe(data => {
                if (data.keyCode === 'alt+1') {
                    configuredrulecomponent.formSectionKey.nativeElement.focus();
                }
            });
    }
    getBUSOData(configuredrulecomponent, val): any {
        const validBUValues = val.businessUnit;
        const validBUSOValues = val.businessUnitServiceOffering;
        const bindBUValues = [];
        const bindBUSOValues = [];
        if (!configuredrulecomponent.jbhGlobals.utils.isEmpty(validBUValues) &&
            configuredrulecomponent.jbhGlobals.utils.isArray(validBUValues)) {
            if (validBUValues.length > 0) {
                for (let i = 0; i < validBUValues.length; i++) {
                    if (!configuredrulecomponent.jbhGlobals.utils.isEmpty(validBUValues[i])) {
                        bindBUValues.push(validBUValues[i]);
                    }
                }
                if (!configuredrulecomponent.jbhGlobals.utils.isEmpty(validBUSOValues) &&
                    configuredrulecomponent.jbhGlobals.utils.isArray(validBUSOValues)) {
                    if (validBUSOValues.length > 0) {
                        for (let i = 0; i < validBUSOValues.length; i++) {
                            if (!configuredrulecomponent.jbhGlobals.utils.isEmpty(validBUSOValues[i])) {
                                bindBUValues.push(validBUSOValues[i]);
                            }
                        }
                    }
                    return bindBUValues.toString().replace(/,/g, ', ');
                } else {
                    return bindBUValues.toString().replace(/,/g, ', ');
                }
            }
        } else if (!configuredrulecomponent.jbhGlobals.utils.isEmpty(validBUSOValues) &&
            configuredrulecomponent.jbhGlobals.utils.isArray(validBUSOValues)) {
            if (validBUSOValues.length > 0) {
                for (let i = 0; i < validBUSOValues.length; i++) {
                    if (!configuredrulecomponent.jbhGlobals.utils.isEmpty(validBUSOValues[i])) {
                        bindBUSOValues.push(validBUSOValues[i]);
                    }
                }
                return bindBUSOValues.toString().replace(/,/g, ', ');
            }
        }
    }
    onRukeInactivate(configuredrulecomponent, row): any {
        const inactURL = configuredrulecomponent.jbhGlobals.endpoints.automationrules.inactivateRule;
        const orderRulecriteriaID = row.orderRuleCriteriaSets[0].orderRuleCriteriaSetID;
        const inactURLAppendId = `${inactURL}/${orderRulecriteriaID}`;
        configuredrulecomponent.automationRulesService.pushData(inactURLAppendId, false).takeWhile(() =>
            configuredrulecomponent.configuredRuleListModel.subscribeFlag).subscribe(data => {
                const isSuccess = data['status'] === 'success';
                if (isSuccess) {
                    configuredrulecomponent.jbhGlobals.notifications.success('Success', 'Rule Inactivated Successfully');
                    configuredrulecomponent.page(configuredrulecomponent.configuredRuleListModel.offset,
                        configuredrulecomponent.configuredRuleListModel.limit);
                } else {
                    configuredrulecomponent.jbhGlobals.notifications.alert('Failure', 'Rule Inactivation Failed');
                }
            }, (err: Error) => {
                configuredrulecomponent.jbhGlobals.notifications.alert('Failure', 'Rule Inactivation Failed');
                return false;
            });
    }
    paramFramer(eve, text, rulesFilterList): void {
        const me = this;
        const params = rulesFilterList[eve.num].params;
        if (text) {
            params['query']['bool']['should'][0]['query_string']['query'] = `${text}*`;
            params['query']['bool']['should'][1]['nested']['query']['query_string']['query'] = `${text}*`;
            return params;
        } else {
            params['query']['bool']['should'][0]['query_string']['query'] = '*';
            // params['query']['bool']['should'][1]['nested']['query']['query_string']['query'] = '*';
            return params;
        }
    }
}
