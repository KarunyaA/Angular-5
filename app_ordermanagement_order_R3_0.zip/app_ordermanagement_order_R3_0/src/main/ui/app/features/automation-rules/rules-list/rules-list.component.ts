import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

import { JBHGlobals } from '../../../app.service';

import { RulesService } from '../rules.service';
import { AutomationRulesService } from './../services/automation-rules.service';
import { RulesListService } from '../services/rules-list.service';
import { RulesListModel } from '../model/ruleslist.model';

@Component({
    selector: 'app-rules-list',
    templateUrl: './rules-list.component.html',
    styleUrls: ['./rules-list.component.scss'],
    providers: [RulesListService, AutomationRulesService]
})
export class RulesListComponent implements OnInit, OnDestroy {
    rulesListModel: RulesListModel;
    typeaheadModule: FormGroup;
    ngOnInit(): void {
        this.rulesListModel = new RulesListModel();
        this.rulesListService.InitializeFilter(this);
        this.rulesListModel.rulesFilterList[0]['myParentScope'] = this;
        this.loadCustomerRules();
        this.page(this.rulesListModel.offset, this.rulesListModel.limit);
        this.typeaheadModule = this.fb.group({
            searchRuleName: ['', Validators.required]
        });
        this.typeaheadSearch();
    }
    ngOnDestroy(): void {
        this.rulesListModel.subscribeFlag = false;
    }
    constructor(
        private router: Router, private jbhGlobals: JBHGlobals, private automationRulesService: AutomationRulesService,
        private rulesService: RulesService, private fb: FormBuilder, private rulesListService: RulesListService) { }
    onPage(event): void {
        this.rulesListModel.offset = event.offset;
        this.rulesListModel.limit = event.limit;
        this.page(this.rulesListModel.offset, this.rulesListModel.limit);
    }
    onSelect(event): void {
        const selRule = event.selected[0];
        this.rulesService.ruleDetails = {
            'orderRuleCriteriaSetID': selRule.orderRuleCriteriaSetID,
            'orderRuleDetailID': selRule.orderRuleDetailID,
            'orderRuleSupersedeTypeCode': selRule.orderRuleSupersedeTypeCode,
            'orderRuleName': selRule.orderRuleName,
            'orderRuleDescription': selRule.orderRuleDescription,
            'startDate': this.rulesService.ruleDetails.startDate,
            'associationLevel': selRule.associationLevel,
            'businessUnit': selRule.businessUnit,
            'ruleProcessCode': selRule.orderRuleProcessTypeCode,
            'businessUnitServiceOffering': selRule.businessUnitServiceOffering,
            'isBusinessUnitLevelRules': this.rulesService.ruleDetails.isBusinessUnitLevelRules,
            'isCustomerLevelRules': this.rulesService.ruleDetails.isCustomerLevelRules,
            'billTo': this.rulesService.ruleDetails.billTo,
            'effectiveTimestamp': '',
            'expirationTimestamp': '',
            'mode': this.rulesService.ruleDetails.mode,
            'resultantActions': selRule.resultantAction,
            'validationSet': selRule.validationSet,
            'orderRuleCategoryDescription': selRule.orderRuleCategoryDescription,
            'orderRuleCategoryCode': selRule.orderRuleCategoryCode,
            'billingPartyID': this.rulesService.ruleDetails.billingPartyID
        };
        if (this.rulesService.ruleDetails.isBusinessUnitLevelRules === true) {
            this.router.navigateByUrl('/automationrules/configurenewrule');
        } else {
            this.router.navigateByUrl('/customerrules/configurenewrule');
        }
    }
    onAdditionalSearch(): void {
        if (this.rulesListModel.flag === 0) {
            this.rulesListModel.flag = 1;
        } else {
            this.rulesListModel.flag = 0;
        }
    }
    onChangeEvent(event): void {
        this.rulesListModel.orderRuleName = this.typeaheadModule.controls.searchRuleName.value;
        this.rulesListModel.offset = 0;
        const isChk = event.data.checked;
        const fVal = event.data.fullVal;
        if (isChk === true) {
            switch (event.num) {
                case 0:
                    const buso = fVal.id;
                    const busoFormat = buso.split('-');
                    if (busoFormat[1] === 'All') {
                        this.rulesListModel.businessUnits.push(busoFormat[0]);
                    } else {
                        this.rulesListModel.businessUnits.push(busoFormat[0]);
                        this.rulesListModel.serviceOfferings.push(buso);
                    }
                    this.rulesListModel.rulesFilterList[event.num]['count'] = event.count;
                    break;
                case 1:
                    this.rulesListModel.orderRuleCategories.push(fVal.orderRuleCategoryDescription);
                    this.rulesListModel.rulesFilterList[event.num]['count'] = event.count;
                    break;
                default:
                    break;
            }
        } else {
            switch (event.num) {
                case 0:
                    const buso = fVal.id;
                    const busoFormat = buso.split('-');
                    const businessElementIndex = this.rulesListModel.businessUnits.indexOf(busoFormat[0]);
                    this.rulesListModel.businessUnits.splice(businessElementIndex, 1);
                    const serviceElementIndex = this.rulesListModel.serviceOfferings.indexOf(busoFormat[1]);
                    this.rulesListModel.serviceOfferings.splice(serviceElementIndex, 1);
                    this.rulesListModel.rulesFilterList[event.num]['count'] = event.count;
                    break;
                case 1:
                    const orderRuleElementIndex = this.rulesListModel.orderRuleCategories.indexOf(fVal.orderRuleCategoryDescription);
                    this.rulesListModel.orderRuleCategories.splice(orderRuleElementIndex, 1);
                    this.rulesListModel.rulesFilterList[event.num]['count'] = event.count;
                    break;
                default:
                    break;
            }
        }
        this.loadGridData();
    }
    onClickReset(index): void {
        switch (index) {
            case 0:
                this.rulesListModel.serviceOfferings = [];
                this.rulesListModel.businessUnits = [];
                this.rulesListModel.rulesFilterList[index]['count'] = 0;
                break;
            case 1:
                this.rulesListModel.orderRuleCategories = [];
                this.rulesListModel.rulesFilterList[index]['count'] = 0;
                break;
            default:
                break;
        }
        this.loadGridData();
    }
    onPreRuleSelect(event): void {
        this.rulesListModel.orderRuleName = event.value;
        this.rulesListModel.offset = 0;
        this.loadGridData();
    }
    onPreRuleLoading(event: boolean): void {
        this.rulesListModel.onLoading = event;
        this.rulesListModel.onNoResults = false;
    }
    onPreRuleNoResults(event: boolean): void {
        this.rulesListModel.onNoResults = event;
    }
    appendBUSO(value): any {
        const retValidValues = [];
        for (let i = 0; i < value.length; i++) {
            if (value[i].businessUnit !== null && value[i].serviceOffering !== null) {
                retValidValues.push(value[i].businessUnit);
                retValidValues.push(value[i].serviceOffering);
            } else if (value[i].businessUnit !== null && value[i].serviceOffering === null) {
                retValidValues.push(value[i].businessUnit);
            } else if (value[i].businessUnit === null && value[i].serviceOffering !== null) {
                retValidValues.push(value[i].serviceOffering);
            }
        }
        return retValidValues.toString().replace(/,/g, ', ');
    }
    loadCriteriaList(): void {
        if (this.rulesService.ruleDetails.isBusinessUnitLevelRules !== true) {
            this.router.navigate(['/customerrules'],
                { queryParams: { partyId: this.rulesService.ruleDetails.billingPartyID } });
        } else {
            this.router.navigateByUrl('/automationrules');
        }
    }
    soFramer(data: Object): Object {
        const obj = {};
        if (data) {
            obj['val'] = `${data['financeBusinessUnitCode']}-${data['serviceOfferingCode']}`;
            obj['fullVal'] = data;
            return obj;
        }
    }
    private typeaheadSearch(): void {
        this.rulesListModel.debounceValue = this.jbhGlobals.settings.debounce;
        this.typeaheadModule['controls']['searchRuleName']['valueChanges']
            .debounceTime(this.rulesListModel.debounceValue)
            .distinctUntilChanged()
            .subscribe((value) => {
                if (!this.jbhGlobals.utils.isEmpty(value) && value !== undefined) {
                    this.rulesListModel.orderRuleName = '';
                    this.getRuleName(value);
                } else if (value.length === 0) {
                    this.rulesListModel.onNoResults = false;
                    this.rulesListModel.orderRuleName = '';
                    this.rulesListModel.ruleMockData = [];
                    this.loadGridData();
                }
            }, (err: Error) => { });
    }
    private page(offset, limit): void {
        this.loadGridData({
            'page': offset,
            'size': limit
        });
    }
    private updateRowPosition(): void {
        const ix = this.getSelectedIx();
        const arr = [...this.rulesListModel.rows];
        arr[ix - 1] = this.rulesListModel.rows[ix];
        arr[ix] = this.rulesListModel.rows[ix - 1];
        this.rulesListModel.rows = arr;
    }
    private getSelectedIx(): any {
        return this.rulesListModel.selected[0]['$$index'];
    }
    private getRuleName(event): void {
        if (event.length > 2) {
            const ruleParam = {
                'orderRuleName': event
            };
            const url = this.jbhGlobals.endpoints.automationrules.rulesTypeahead;
            this.automationRulesService.fetchData(url, ruleParam, false).takeWhile(() =>
                this.rulesListModel.subscribeFlag).subscribe(data => {
                    if (!this.jbhGlobals.utils.isEmpty(data)) {
                        this.rulesListModel.ruleMockData = [];
                        this.rulesListModel.ruleMockData = data;
                    }
                });
        }
    }
    private loadCustomerRules(): void {
        if (this.rulesService.ruleDetails.isCustomerLevelRules === true) {
            this.rulesListModel.associationLevel = 'Customer';
        }
    }
    private loadGridData(pgParams?: Object): void {
        const listUrl = this.jbhGlobals.endpoints.automationrules.ruleslist;
        const params = {
            'serviceOffering': this.rulesListModel.serviceOfferings,
            'businessUnit': this.rulesListModel.businessUnits,
            'orderRuleCategory': this.rulesListModel.orderRuleCategories,
            'orderRuleName': this.rulesListModel.orderRuleName,
            'orderRuleType': this.rulesService.ruleDetails.isCustomerLevelRules ? 'Customer' : ['Business Unit', 'Company']
        };
        const isPgPrmNotNull = (pgParams !== null && pgParams !== undefined);
        params['page'] = (isPgPrmNotNull) ? pgParams['page'] : 0;
        params['size'] = (isPgPrmNotNull) ? pgParams['size'] : this.rulesListModel.limit;
        this.automationRulesService.fetchData(listUrl, params, true).takeWhile(() =>
            this.rulesListModel.subscribeFlag).subscribe(data => {
                this.rulesListModel.onNoResults = false;
                if (!this.jbhGlobals.utils.isEmpty(data)) {
                    this.rulesListModel.rows = data['content'];
                    this.rulesListModel.totalRecordsCount = data['totalElements'];
                } else {
                    this.rulesListModel.rows = [];
                    this.rulesListModel.totalRecordsCount = 0;
                }
            });
    }
}
