import { Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormArray, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/finally';

import * as moment from 'moment';
import { IMyDate, IMyDateModel, IMyOptions } from 'mydatepicker';
import { JBHGlobals } from '../../../app.service';

import { RulesService } from '../rules.service';
import { ConfigureRuleService } from '../services/configure-rule.service';
import { ConfigureRuleHelperService } from '../services/configure-rule-helper.service';
import { AutomationRulesService } from './../services/automation-rules.service';
import { OrderRuleCriteriaDetail } from '../model/orderrulecriteriadetail.model';
import { OrderRuleCriteriaSet } from '../model/orderrulecriteriaset.model';
import { OrderRuleParameter } from '../model/orderruleparameter.model';
import { ConfigureRuleModel } from '../model/configure-rule.model';

@Component({
    selector: 'app-configure-rule',
    templateUrl: './configure-rule.component.html',
    styleUrls: ['./configure-rule.component.scss'],
    providers: [DatePipe, ConfigureRuleService, AutomationRulesService, ConfigureRuleHelperService]
})

export class ConfigureRuleComponent implements OnInit, OnDestroy {
    configureRuleModel = new ConfigureRuleModel();
    rule: Observable<OrderRuleCriteriaSet>;
    @ViewChild('ruleFormId') ruleFormId: any;
    @ViewChild('formHeaderSectionKey') formHeaderSectionKey;
    @ViewChild('formMiddleSectionKey') formMiddleSectionKey;
    @ViewChild('formBottomSectionKey') formBottomSectionKey;
    @ViewChild('serviceOfferingKey') serviceOfferingKey: ElementRef;
    @ViewChild('ruleOverviewKey') ruleOverviewKey: ElementRef;
    @ViewChild('AttributeViewComponent') attributeViewComponent;
    @ViewChild('effectiveDatePicker') effectiveDatePicker;
    @ViewChild('expirationDatePicker') expirationDatePicker;
    @ViewChild('popInstance') popInstance: any;
    @ViewChild('bu') bu;
    @ViewChild('so') so;

    constructor(
        private router: Router, private fb: FormBuilder, private datePipeObj: DatePipe,
        private ruleService: RulesService, private jbhGlobals: JBHGlobals, private configureRuleService: ConfigureRuleService,
        private automationRulesService: AutomationRulesService, private configureRuleHelperService: ConfigureRuleHelperService) {
        this.configureRuleService.createForm(this, Validators);
        this.setRuleOverviewDetails();
    }
    ngOnInit(): void {
        this.configureRuleService.loadOrderRuleCriterias(this);
        this.setUpKeyboardShortcuts();
        this.configureRuleModel.myStartTime = this.configureRuleHelperService.setInitialTime();
        this.configureRuleModel.myEndTime = this.configureRuleHelperService.setInitialTime();
        this.ruleService.selectedAtrributeList = [];
        if (this.configureRuleModel.isBusinessUnitLevelRules) {
            this.configureRuleModel.pathVariable = '/automationrules';
        } else {
            this.configureRuleModel.pathVariable = '/customerrules';
        }
    }
    ngOnDestroy(): void {
        this.configureRuleModel.subscribeFlag = false;
    }
    onSupersedeCheck(e): void {
        if (e.target.checked) {
            this.popInstance.deleteButtonModal.show();
        }
    }
    onDelete(event: any, e): void {
        if (event.flag) {
            event.model.hide();
        } else {
            event.model.hide();
            e.checked = false;
        }
    }
    getRule(): void {
        this.configureRuleModel.selectedRule = this.ruleService.selectedCriteriaDetails;
        if (this.configureRuleModel.selectedRule !== null) {
            this.configureRuleModel.ruleForm.reset({
                orderRuleCriteriaSetID: this.ruleService.ruleDetails.orderRuleCriteriaSetID,
                orderRuleDetailID: this.ruleService.ruleDetails.orderRuleDetailID,
                orderRuleSupersedeTypeCode: (this.configureRuleModel.selectedRule.orderRuleSupersedeTypeCode === 'Suprsed') ? true : false
            });
            this.configureRuleHelperService.setDateTime(this.ruleService.ruleDetails.effectiveTimestamp,
                this.ruleService.ruleDetails.expirationTimestamp, this.configureRuleModel);
            this.configureRuleHelperService.setOrderRuleCriterias(this, this.configureRuleModel.selectedRule.orderRuleCriteriaDetailDTO);
            this.setOrderRuleParameters(this.configureRuleModel.selectedRule.orderRuleParameterDTO);
        } else if (this.configureRuleModel.selectedRule === null &&
            this.configureRuleModel.resultantActions !== null &&
            this.configureRuleModel.resultantActions['resultantParameterDTO'] !== undefined &&
            this.configureRuleModel.resultantActions['resultantParameterDTO'].length > 0) {
            this.setOrderRuleParametersOnRuleCreation(this.configureRuleModel.resultantActions['resultantParameterDTO']);
        }
    }
    setOrderRuleParameters(orderRuleParameter: OrderRuleParameter[]): void {
        const orderRulePDFG: any = [];
        if (orderRuleParameter !== null) {
            for (let cnt = 0; cnt < orderRuleParameter.length; cnt++) {
                const currIns = this.configureRuleService.initOrderRuleParameterDetails(orderRuleParameter[cnt], this);
                orderRulePDFG.push(currIns);
            }
        }
        const ruleFormArray = this.fb.array(orderRulePDFG);
        this.configureRuleModel.ruleForm.setControl('orderRuleParameterDetail', ruleFormArray);
    }
    setOrderRuleParametersOnRuleCreation(resultantActions): void {
        this.configureRuleHelperService.setOrderRuleParametersOnRuleCreation(resultantActions, this.configureRuleModel, this.fb);
    }
    get orderRuleCriteriaDetail(): FormArray {
        return this.configureRuleModel.ruleForm.get('orderRuleCriteriaDetail') as FormArray;
    }
    get orderRuleParameterDetail(): FormArray {
        return this.configureRuleModel.ruleForm.get('orderRuleParameterDetail') as FormArray;
    }
    onAddNewAttribute(): void {
        const control = <FormArray> this.configureRuleModel.ruleForm.controls['orderRuleCriteriaDetail'];
        const addrCtrl = this.configureRuleService.initCriteriaDetails(null, this);
        control.push(addrCtrl);
    }
    removeAttribute(event): void {
        this.configureRuleService.removeAttribute(this, event);
    }
    onCancel(msg): void {
        if (this.configureRuleModel.ruleForm.touched) {
            msg.show();
        } else {
            this.loadCriteriaList();
        }
    }
    onProceed(): void {
        this.loadCriteriaList();
    }
    onFormCancel(alertMsg): void {
        alertMsg.hide();
    }
    loadCriteriaList(): void {
        if (this.configureRuleModel.isCustomerLevelRules) {
            this.router.navigate(['/customerrules'],
                { queryParams: { partyId: this.ruleService.ruleDetails.billingPartyID } });
        } else {
            this.router.navigateByUrl('/automationrules');
        }
    }
    onOrdChnRemoved(event): void {
        // Remove Order Channel
        this.configureRuleService.ordChnRemoved(this, event);
    }
    onSelected(eve): void {
        if (typeof (eve['id']) === 'string') {
            eve['id'] = null;
        }
    }
    onSetDates(eve, type): void {
        switch (type) {
            case 'effDt':
                this.configureRuleModel.selEffDate = this.configureRuleHelperService.getDateFormat(eve.jsdate);
                this.configureRuleModel.effectiveDateFlag = false;
                this.validateDates();
                break;
            case 'expDt':
                this.configureRuleModel.selExpDate = this.configureRuleHelperService.getDateFormat(eve.jsdate);
                this.configureRuleModel.expirationDateFlag = false;
                this.validateDates();
                break;
            default:
                break;
        }
    }
    validateDates(): boolean {
        let validateDateFlag = false;
        if (!this.configureRuleHelperService.isDateEmpty(this.configureRuleModel.selEffDate) &&
            !this.configureRuleHelperService.isDateEmpty(this.configureRuleModel.selExpDate)) {
            const effDtTime = this.configureRuleHelperService.setDateTimeFormatFromDt
                (this.configureRuleModel.selEffDate, this.configureRuleModel.myStartTime);
            const expDtTime = this.configureRuleHelperService.setDateTimeFormatFromDt
                (this.configureRuleModel.selExpDate, this.configureRuleModel.myEndTime);
            if (effDtTime > expDtTime) {
                this.configureRuleModel.dateCompareFlag = true;
            } else {
                this.configureRuleModel.dateCompareFlag = false;
            }
        }
        if (!this.configureRuleHelperService.isDateEmpty(this.configureRuleModel.selEffDate) &&
            !this.configureRuleHelperService.isDateEmpty(this.configureRuleModel.selExpDate)) {
            validateDateFlag = true;
        }
        const dateError = this.configureRuleModel.dateCompareFlag ? { 'incorrect': true } : null;
        this.configureRuleModel.ruleForm.controls.effectiveDate.setErrors(dateError);
        this.configureRuleModel.ruleForm.controls.expirationDate.setErrors(dateError);
        return validateDateFlag;
    }
    onpickUpDateChanged(event: IMyDateModel): void {
        let jsDt;
        this.configureRuleModel.effectiveDateFlag = false;
        this.configureRuleModel.effectiveDate = event.epoc;
        jsDt = this.datePipeObj.transform(event.jsdate, 'yyyy-MM-ddTHH:mm:ss');
        event.jsdate = jsDt;
        this.configureRuleModel.ruleForm.controls.effectiveDate.setValue(event);
        this.validateDates();
    }
    ondeliveryDateChanged(event: IMyDateModel): void {
        let jsDt;
        this.configureRuleModel.expirationDateFlag = false;
        this.configureRuleModel.expirationDate = event.epoc;
        jsDt = this.datePipeObj.transform(event.jsdate, 'yyyy-MM-ddTHH:mm:ss');
        event.jsdate = jsDt;
        this.configureRuleModel.ruleForm.controls.expirationDate.setValue(event);
        this.validateDates();
    }
    onParamTypeChange(eve): void {
        const paramDet = this.configureRuleModel.ruleForm.controls.orderRuleParameterDetail.controls[0].controls;
        this.configureRuleModel.selectedParamType = eve;
        paramDet.orderParameterCharValue.setValue(null);
        paramDet.orderParameterDateValue.setValue(null);
        paramDet.orderParameterNumberValue.setValue(null);
    }
    focusReady(event): void {
        if (event.key === 'Enter' && this.configureRuleModel.focusFlag === 0 && (event.target.childNodes[4].focus())) {
            event.target.childNodes[4].focus();
            this.configureRuleModel.focusFlag++;
        }
    }
    setFocusFlag(): void {
        this.configureRuleModel.focusFlag = 0;
    }
    onSelectvalidation(event, selectComponent): void {
        const compName = selectComponent.element.nativeElement.id;
        if (event.innerText === '' && selectComponent.multiple !== true) {
            this.configureRuleModel.ruleForm.get(compName).markAsTouched();
            this.configureRuleModel.ruleForm.get(compName).setErrors(
                compName === 'orderCreationChannel' /* || compName === 'serviceOffering' || compName === 'businessUnit' */ ? {
                    'mandatory': true
                } : null);
            if (selectComponent.multiple !== true && selectComponent.active.length > 0) {
                selectComponent.active = [];
            }
        } else if (selectComponent.multiple === true && selectComponent._active.length === 0) {
            this.configureRuleModel.ruleForm.get(compName).markAsTouched();
            this.configureRuleModel.ruleForm.get(compName).setErrors(
                compName === 'orderCreationChannel' /* || compName === 'serviceOffering' || compName === 'businessUnit'*/ ? {
                    'mandatory': true
                } : null);
        }
    }
    checkEmptyTime(index, formcontrol, attrType): void {
        const attrVal = this.configureRuleModel.ruleForm.controls.orderRuleCriteriaDetail
            .controls[index].controls[formcontrol].value;
        let isAttrEmpty = false;
        switch (attrType) {
            case 'timefield':
                isAttrEmpty = (attrVal.getHours() === 0 && attrVal.getMinutes() === 0);
                break;
            case 'datefield':
                isAttrEmpty = (attrVal.formatted === '00-00-0');
                break;
            default:
                break;
        }
        if (isAttrEmpty) {
            this.configureRuleModel.ruleForm.controls.orderRuleCriteriaDetail
                .controls[index].controls[formcontrol].setErrors({ 'mandatory': true });
        }
    }
    onSave(mode): void {
        this.configureRuleService.saveRule(this, mode);
    }
    onStartTimeChanged(): void {
        this.configureRuleModel.startTimeMeridian = true;
        this.timeValidator(this.configureRuleModel.myStartTime, 'Start');
    }
    onEndTimeChanged(): void {
        this.configureRuleModel.endTimeMeridian = true;
        this.timeValidator(this.configureRuleModel.myEndTime, 'End');
    }
    timeValidator(time, key): void {
        const hour = Number(moment(time).format('HH'));
        const minute = Number(moment(time).format('mm'));
        if ((hour === 0 && minute === 0)) {
            switch (key) {
                case 'Start':
                    this.configureRuleModel.myStartTime = this.configureRuleHelperService.setInitialTime();
                    break;
                case 'End':
                    this.configureRuleModel.myEndTime = this.configureRuleHelperService.setInitialTime();
                    break;
                default:
            }
        }
        if (hour !== 0 && minute === 0) {
            this.conditonalValidator(time, key);
        }
        if (hour === 0 && minute !== 0) {
            this.conditonalValidator(time, key);
        }
        if (hour !== 0 && minute !== 0) {
            this.conditonalValidator(time, key);
        }
        this.validateDates();
    }
    conditonalValidator(myTime, key): void {
        switch (key) {
            case 'Start':
                this.configureRuleModel.myStartTime = this.configureRuleHelperService.hoursMinsSetter(myTime, key);
                break;
            case 'End':
                this.configureRuleModel.myEndTime = this.configureRuleHelperService.hoursMinsSetter(myTime, key);
                break;
            default:
        }
    }
    private setRuleOverviewDetails(): void {
        this.configureRuleHelperService.setRuleOverviewDetails(this.ruleService, this.configureRuleModel);
        this.configureRuleHelperService.binValidBUSO(this.configureRuleModel);
        this.configureRuleHelperService.busoRadioCheck(this.configureRuleModel);
    }
    private setUpKeyboardShortcuts(): void {
        this.jbhGlobals.shortkeys.getData().subscribe(data => {
            if (data.keyCode === 'alt+1') { } else if (data.keyCode === 'alt+3') {
                this.ruleOverviewKey.nativeElement.focus();
            }
        });
    }
}
