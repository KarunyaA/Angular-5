import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RulesListComponent } from './rules-list/rules-list.component';
import { ConfiguredRulesListComponent } from './rules-list/configured-rules-list.component';
import { ConfigureRuleComponent } from './configure-rule/configure-rule.component';
import { ViewRuleComponent } from './configure-rule/view-rule/view-rule.component';
import { JbhValidationModule } from 'jbh-components';
import { RouteGuard } from 'jbh-components/jbh-esa';

const routes: Routes = [{
  path: 'rules',
  component: RulesListComponent, // Rules List Component
  canActivate: [RouteGuard]
}, {
  path: 'configurenewrule',
  component: ConfigureRuleComponent,
  canActivate: [RouteGuard]
}, {
  path: 'viewrule',
  component: ViewRuleComponent
}, {
  path: '',
  component: ConfiguredRulesListComponent // Configured Rules List Component
}];

@NgModule({
  imports: [RouterModule.forChild(routes),
  JbhValidationModule.forRoot()],
  exports: [RouterModule]
})
export class AutomationRulesRoutingModule { }
