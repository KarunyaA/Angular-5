import { Injectable } from '@angular/core';

import { JBHGlobals } from './../../../app.service';
import * as moment from 'moment';

@Injectable()
export class ConfigureRuleHelperService {
    constructor(private jbhGlobals: JBHGlobals) { }
    setDateTime(effDate, expDate, configureRuleModel): void {
        if (!this.jbhGlobals.utils.isEmpty(effDate)) {
            configureRuleModel.selEffDate = this.getDateFormat(effDate);
            configureRuleModel.myStartTime = effDate;
            configureRuleModel.startTimeMeridian = true;
        }
        if (!this.jbhGlobals.utils.isEmpty(expDate)) {
            configureRuleModel.selExpDate = this.getDateFormat(expDate);
            configureRuleModel.myStartTime = effDate;
            configureRuleModel.myEndTime = expDate;
            configureRuleModel.endTimeMeridian = true;
        }
    }
    setDateTimeFormat(date, time): any {
        const dateTime = new Date(date);
        dateTime.setHours(time.getHours());
        dateTime.setMinutes(time.getMinutes());
        const hoursFormat = (`0${dateTime.getHours()}`).slice(-2);
        const minsFormat = (`0${dateTime.getMinutes()}`).slice(-2);
        return moment(dateTime).format('YYYY-MM-DDTHH:mm:ss');
    }
    setDateTimeFormatFromDt(date, time): any {
        const dateTime = new Date();
        dateTime.setFullYear(date.year);
        dateTime.setMonth(date.month - 1);
        dateTime.setDate(date.day);
        dateTime.setHours(new Date(time).getHours());
        dateTime.setMinutes(new Date(time).getMinutes());
        dateTime.setSeconds(0);
        return moment(dateTime).format('YYYY-MM-DDTHH:mm:ss');
    }
    findNextAvailDetail(orderRuleCriteriaDetail, cnt1, code, selOpt): any {
        for (let cnt = cnt1 + 1; cnt < orderRuleCriteriaDetail.length; cnt++) {
            const currObj = orderRuleCriteriaDetail[cnt];
            if ((currObj['orderRuleLogicalOperatorDTO']['orderRuleLogicalOperatorCode'] === 'LessThan' ||
                currObj['orderRuleLogicalOperatorDTO']['orderRuleLogicalOperatorCode'] === 'GrtThn') &&
                currObj['orderRuleCriteriaCode'] === code) {
                return cnt;
            }
        }
        return null;
    }

    setOrderRuleCriterias(configurerulecomponent, orderRuleCriteriaDetail): void {
        const orderRuleCDFG: any = [];
        const bu = '';
        const so = '';
        const buId = null;
        const soId = null;
        const ordChhArr = [];
        const buValues = [];
        const busoValues = [];
        for (let cnt = 0; cnt < orderRuleCriteriaDetail.length; cnt++) {
            const criDet = orderRuleCriteriaDetail[cnt];
            const code = criDet['orderRuleCriteriaCode'];
            if (code !== undefined && this.filterAttributes(code, configurerulecomponent.configureRuleModel)) {
                if (this.findNewAttribute(code, configurerulecomponent.ruleService)[0] === undefined) {
                    configurerulecomponent.ruleService.selectedAtrributeList.push(code);
                }
                const selOpt = criDet['orderRuleLogicalOperatorDTO']['orderRuleLogicalOperatorCode'];
                if ((selOpt === 'GrtThn' || selOpt === 'LessThan') &&
                    (orderRuleCriteriaDetail[cnt]['isDisabled'] !== true)) {
                    const findNextSelDetail = this.findNextAvailDetail(orderRuleCriteriaDetail, cnt, code, selOpt);
                    if (findNextSelDetail !== null) {
                        orderRuleCriteriaDetail[cnt]['orderRuleCriteriaValueEnd'] =
                            orderRuleCriteriaDetail[findNextSelDetail]['orderRuleCriteriaValue'];
                        orderRuleCriteriaDetail[cnt]['orderRuleCriteriaDetailEndLimitID'] =
                            orderRuleCriteriaDetail[findNextSelDetail]['orderRuleCriteriaDetailID'];
                        orderRuleCriteriaDetail[findNextSelDetail]['isDisabled'] = true;
                        orderRuleCriteriaDetail[cnt]['orderRuleLogicalOperatorDTO']['orderRuleLogicalOperatorCode'] = 'GrtLessThn';
                        // to handle if Lessthan greaterthan order sequence changes (grtThn should followed by Lessthn)
                        if (orderRuleCriteriaDetail[findNextSelDetail]
                        ['orderRuleLogicalOperatorDTO']['orderRuleLogicalOperatorCode'] === 'GrtThn') {
                            const tempVar = orderRuleCriteriaDetail[cnt]['orderRuleCriteriaValue'];
                            orderRuleCriteriaDetail[cnt]['orderRuleCriteriaValue'] =
                                orderRuleCriteriaDetail[cnt]['orderRuleCriteriaValueEnd'];
                            orderRuleCriteriaDetail[cnt]['orderRuleCriteriaValueEnd'] = tempVar;
                        }
                    }

                    const currIns = configurerulecomponent.configureRuleService.initCriteriaDetails(orderRuleCriteriaDetail[cnt],
                        configurerulecomponent);
                    orderRuleCDFG.push(currIns);
                } else if (orderRuleCriteriaDetail[cnt]['isDisabled'] !== true) {
                    const currIns = configurerulecomponent.configureRuleService.initCriteriaDetails(orderRuleCriteriaDetail[cnt],
                        configurerulecomponent);
                    orderRuleCDFG.push(currIns);
                }
            } else if (typeof (criDet) === 'object') {
                switch (code) {
                    case 'OrdChannel':
                        this.loadCriteriaDetailValues(criDet, 'orderCreationChannel', configurerulecomponent);
                        break;
                    case 'BusUnit':
                        this.loadCriteriaDetailValues(criDet, 'businessUnit', configurerulecomponent);
                        break;
                    case 'BUServOffr':
                        this.loadCriteriaDetailValues(criDet, 'serviceOffering', configurerulecomponent);
                        break;
                    default:
                        break;
                }
            }
        }
        // configurerulecomponent.configureRuleModel.ruleForm['controls']['orderCreationChannel']['setValue'](ordChhArr);
        // configurerulecomponent.configureRuleModel.ruleForm['controls']['businessUnit']['setValue'](buValues);
        // configurerulecomponent.configureRuleModel.ruleForm['controls']['serviceOffering']['setValue'](busoValues);
        const ruleFormArray = configurerulecomponent.fb.array(orderRuleCDFG);
        configurerulecomponent.configureRuleModel.ruleForm.setControl('orderRuleCriteriaDetail', ruleFormArray);
    }
    loadCriteriaDetailValues(criDet, code, configurerulecomponent): void {
        const tempArray = [];
        for (const criDetVal of criDet['orderRuleCriteriaValues']) {
            tempArray.push({
                'id': criDetVal.orderRuleCriteriaDetailID,
                'text': criDetVal.orderRuleCriteriaValue
            });
        }
        configurerulecomponent.configureRuleModel.ruleForm['controls'][code]['setValue'](tempArray);
    }

    setOrderRuleParametersOnRuleCreation(resultantActions, configureRuleModel, fb): void {
        const orderRulePDFG: any = [];
        for (let cnt = 0; cnt < resultantActions.length; cnt++) {
            const pName: string = resultantActions[cnt].parameterName;
            const pTypeCode: string = resultantActions[cnt].parameterType;
            const pValTypeCode: string = resultantActions[cnt].parameterValueType;
            const pValTypeDesc: string = resultantActions[cnt].parameterDescription;
            const currIns = this.initOrderRuleParameterDetailsOnRuleCreation(pName, pTypeCode,
                pValTypeCode, pValTypeDesc, fb);
            orderRulePDFG.push(currIns);
        }
        const ruleFormArray = fb.array(orderRulePDFG);
        configureRuleModel.ruleForm.setControl('orderRuleParameterDetail', ruleFormArray);
    }

    loadAttr(data, configureRuleModel): void {
        if (data !== null) {
            if (configureRuleModel.isBusinessUnitLevelRules) {
                for (const attr of data) {
                    if (attr['orderRuleCriteriaCode'] !== 'OrdChannel' && attr['orderRuleCriteriaCode'] !== 'BusUnit' &&
                        attr['orderRuleCriteriaCode'] !== 'ServOffer' && attr['orderRuleCriteriaCode'] !== 'Supersede') {
                        configureRuleModel.orderRuleCriteriaList.push(attr);
                    }
                }
            } else {
                for (const attr of data) {
                    if (attr['orderRuleCriteriaCode'] !== 'OrdChannel' && attr['orderRuleCriteriaCode'] !== 'Supersede') {
                        configureRuleModel.orderRuleCriteriaList.push(attr);
                    }
                }
            }
        }
    }
    filterAttributes(code, configureRuleModel): boolean {
        const isBuss = configureRuleModel.isBusinessUnitLevelRules;
        const isCus = configureRuleModel.isCustomerLevelRules;
        const bussFilter = (isBuss && code !== 'OrdChannel' && code !== 'BusUnit' &&
            code !== 'BUServOffr' && code !== 'ServOffer' && code !== 'Supersede');
        const cusFilter = (isCus && code !== 'OrdChannel' && code !== 'Supersede');
        return (bussFilter || cusFilter);
    }
    getDateFormat(date): any {
        const dt: Date = new Date(date);
        return {
            year: dt.getFullYear(),
            month: dt.getMonth() + 1,
            day: dt.getDate()
        };
    }
    isDateEmpty(dtObj): boolean {
        return (dtObj.year === 0 && dtObj.month === 0 && dtObj.day === 0);
    }

    setInitialTime(): any {
        const initialTime = new Date();
        initialTime.setHours(0);
        initialTime.setMinutes(0);
        return initialTime;
    }
    hoursMinsSetter(time, key): any {
        let hour = Number(moment(time).format('HH'));
        let minute = Number(moment(time).format('mm'));
        hour = hour !== 0 ? hour : 0;
        minute = minute !== 0 ? minute : 0;
        const setTime = new Date();
        setTime.setHours(hour);
        setTime.setMinutes(minute);
        return setTime;
    }

    binValidBUSO(configureRuleModel): void {
        if (!this.jbhGlobals.utils.isEmpty(configureRuleModel.validBUSOValues) &&
            this.jbhGlobals.utils.isArray(configureRuleModel.validBUSOValues)) {
            for (let i = 0; i < configureRuleModel.validBUSOValues.length; i++) {
                if (configureRuleModel.validBUSOValues[i].businessUnit !== null) {
                    configureRuleModel.bindValidBUValues.push(configureRuleModel.validBUSOValues[i].businessUnit);
                }
                if (configureRuleModel.validBUSOValues[i].serviceOffering !== null &&
                    configureRuleModel.validBUSOValues[i].serviceOffering.length > 0) {
                    for (let cnt = 0; cnt < configureRuleModel.validBUSOValues[i].serviceOffering.length; cnt++) {
                        configureRuleModel.bindValidSOValues.push(configureRuleModel.validBUSOValues[i].serviceOffering[cnt]);
                    }
                }
            }
        }
    }

    busoRadioCheck(configureRuleModel): void {
        if (configureRuleModel.mode === 'new') {
            configureRuleModel.buRadioCheck = true;
        } else {
            if (!this.jbhGlobals.utils.isEmpty(configureRuleModel.businessUnit) &&
                this.jbhGlobals.utils.isArray(configureRuleModel.businessUnit)) {
                if (configureRuleModel.businessUnit.length > 0) {
                    configureRuleModel.buRadioCheck = true;
                }
            } else {
                configureRuleModel.soRadioCheck = true;
            }
        }
    }

    setRuleOverviewDetails(ruleService, configureRuleModel): void {
        const ruleDet = ruleService.ruleDetails;
        configureRuleModel.orderRuleDetailID = ruleDet.orderRuleDetailID;
        configureRuleModel.orderRuleCriteriaSetID = ruleDet.orderRuleCriteriaSetID;
        configureRuleModel.orderRuleName = ruleDet.orderRuleName;
        configureRuleModel.orderRuleDescription = ruleDet.orderRuleDescription;
        configureRuleModel.associationLevel = ruleDet.associationLevel;
        configureRuleModel.businessUnit = ruleDet.businessUnit;
        configureRuleModel.ruleProcessCode = ruleDet.ruleProcessCode;
        configureRuleModel.businessUnitServiceOffering = ruleDet.businessUnitServiceOffering;
        configureRuleModel.isBusinessUnitLevelRules = ruleDet.isBusinessUnitLevelRules;
        configureRuleModel.isCustomerLevelRules = ruleDet.isCustomerLevelRules;
        configureRuleModel.billTo = ruleDet.billTo;
        configureRuleModel.mode = ruleDet.mode;
        configureRuleModel.resultantActions = ruleDet.resultantActions;
        configureRuleModel.orderRuleCategoryDescription = ruleDet.orderRuleCategoryDescription;
        configureRuleModel.orderRuleCategoryCode = ruleDet.orderRuleCategoryCode;
        configureRuleModel.title = (configureRuleModel.mode === 'edit') ? 'View and Edit Rule' :
            (configureRuleModel.mode === 'copy' ? 'Copy Rule' : 'Configure New Rule');
        configureRuleModel.validBUSOValues = ruleDet.validationSet;
    }

    setFormValidation(bu, so, configureRuleModel): void {
        if (configureRuleModel.ruleForm.get('orderCreationChannel').value === null ||
            configureRuleModel.ruleForm.get('orderCreationChannel').value.length === 0) {
            configureRuleModel.ruleForm.get('orderCreationChannel').markAsTouched();
            configureRuleModel.ruleForm.get('orderCreationChannel').setErrors({
                'mandatorySelect': true
            });
        }
        if (configureRuleModel.isBusinessUnitLevelRules) {
            if (so.nativeElement.checked === true) {
                if (configureRuleModel.ruleForm.get('serviceOffering').value === null ||
                    configureRuleModel.ruleForm.get('serviceOffering').value.length === 0) {
                    configureRuleModel.ruleForm.get('serviceOffering').markAsTouched();
                    configureRuleModel.ruleForm.get('serviceOffering').setErrors({
                        'mandatorySelect': true
                    });
                }
                configureRuleModel.ruleForm.get('businessUnit').setValidators([]);
                configureRuleModel.ruleForm.get('businessUnit').updateValueAndValidity();
            }
            if (bu.nativeElement.checked === true) {
                if (configureRuleModel.ruleForm.get('businessUnit').value === null ||
                    configureRuleModel.ruleForm.get('businessUnit').value.length === 0) {
                    configureRuleModel.ruleForm.get('businessUnit').markAsTouched();
                    configureRuleModel.ruleForm.get('businessUnit').setErrors({
                        'mandatorySelect': true
                    });
                }
                configureRuleModel.ruleForm.get('serviceOffering').setValidators([]);
                configureRuleModel.ruleForm.get('serviceOffering').updateValueAndValidity();
            }
        }
        // check empty values for multiselect fields
        const attrForm: any = configureRuleModel.ruleForm.controls.orderRuleCriteriaDetail;
        for (let i = 0; i < attrForm.controls.length; i++) {
            const getAttr: any = attrForm.controls[i].controls.orderRuleCriteriaCode.value;
            if (!this.jbhGlobals.utils.isEmpty(configureRuleModel.attributesList) &&
                !this.jbhGlobals.utils.isEmpty(configureRuleModel.attributesList[getAttr])) {
                if (configureRuleModel.attributesList[getAttr].type === 'multiselect' &&
                    attrForm.controls[i].controls.orderRuleCriteriaValue.value.length === 0) {
                    attrForm.controls[i].controls.orderRuleCriteriaValue.markAsTouched();
                    attrForm.controls[i].controls.orderRuleCriteriaValue.setValidators([this.jbhGlobals.customValidator.mandatorySelect]);
                } else if (configureRuleModel.attributesList[getAttr].type === 'multiselect' &&
                    attrForm.controls[i].controls.orderRuleCriteriaValue.value.length !== 0) {
                    attrForm.controls[i].controls.orderRuleCriteriaValue.setValidators([]);
                }
            }
            attrForm.controls[i].controls.orderRuleCriteriaValue.updateValueAndValidity();
        }
    }
    initOrderRuleParameterDetailsOnRuleCreation(pName, pTypeCode, pValTypeCode, pValTypeDesc, fb): any {
        return fb.group({
            orderRuleParameterID: null,
            orderParameterName: pName,
            orderParameterDescription: pValTypeDesc,
            orderParameterType: pTypeCode,
            orderParameterNumberValue: null,
            orderParameterCharValue: null,
            orderParameterDateValue: null,
            orderRuleParameterTypeDTO: fb.group({
                orderRuleParameterTypeCode: pTypeCode,
                orderRuleParameterTypeDescription: pTypeCode,
                orderRuleParameterValueTypeCode: pValTypeCode
            })
        });
    }
    checkAttrArray(configureRuleModel): any {
        let flag = false;
        let buFlag = false;
        const defaultAttributes = ['BillParty', 'LOB', 'Customer', 'TradePart'];
        const attrArray = [];
        const attrForm = configureRuleModel.ruleForm.controls.orderRuleCriteriaDetail;
        const isAutoUpdateRule = configureRuleModel.orderRuleCategoryCode === 'AutoUpdate';
        const isUCRRule = (configureRuleModel.ruleProcessCode === 'Capture' ||
            configureRuleModel.ruleProcessCode === 'UCR');
        for (let i = 0; i < attrForm.controls.length; i++) {
            const getAttr = attrForm.controls[i].controls.orderRuleCriteriaCode.value;
            attrArray.push(getAttr);
        }
        for (let i = 0; (attrArray !== undefined && i < attrArray.length); i++) {
            for (let j = 0; j < (isAutoUpdateRule ? 1 :
                isUCRRule ? defaultAttributes.length : defaultAttributes.length - 1); j++) {
                if (attrArray[i] === defaultAttributes[j]) {
                    flag = true;
                    break;
                } else if (isAutoUpdateRule && attrArray[i] === 'BusUnit') {
                    buFlag = true;
                    break;
                }
            }
        }
        configureRuleModel.mandatoryAttr = isAutoUpdateRule ?
            (!flag && !buFlag) ? 'Billing Party and Business Unit'
                : flag ? 'Bussiness Unit' : 'Billing Partty'
            : (isUCRRule && !flag) ? 'Billing Party (or) Line Of Business (or) Customer (or) UCR Trading Partner' :
                'Billing Party (or) Line Of Business (or) Customer';
        return isAutoUpdateRule ? (flag && buFlag) : flag;
    }
    autoUpdateRuleCheck(configureRuleModel): any {
        return configureRuleModel.autoUpdateCustomerRules.indexOf(configureRuleModel.orderRuleName) !== -1;
    }
    findNewAttribute(selectedAttribute, rulesService): any {
        return rulesService.selectedAtrributeList.filter(item => item.toLowerCase().indexOf(selectedAttribute.toLowerCase()) !== -1);
    }
}
