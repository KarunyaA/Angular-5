import { IMyDate, IMyDateModel, IMyOptions } from 'mydatepicker';

export class AttributeModel {
  attribute: string;
  operator: string;
  value: string;
  debounceValue: number;
  isValueSelected: boolean;
  transTypeaheadList: any[];
  attributeValue: string[];
  oprList: string[];
  compType: string;
  datas: any[];
  ruleCode: string;
  ruleVale: string;
  selectionAttr: string;
  preVal: string;
  datePickerOptions: IMyOptions;
  selEffDate: IMyDate;
  selExpDate: IMyDate;
  effectiveDateFlag: boolean;
  expirationDateFlag: boolean;
  dateCompareFlag: boolean;
  timeCompareFlag: boolean;
  startTimeMeridian: boolean;
  endTimeMeridian: boolean;
  rangeFlag: boolean;
  subscription: any[];
  subscribeFlag: boolean;

  constructor() {
    this.isValueSelected = true;
    this.effectiveDateFlag = false;
    this.expirationDateFlag = false;
    this.dateCompareFlag = false;
    this.timeCompareFlag = false;
    this.startTimeMeridian = false;
    this.endTimeMeridian = false;
    this.rangeFlag = false;
    this.subscribeFlag = true;
    this.ruleCode = 'Attribute';
    this.ruleVale = 'Value';
    this.attribute = '';
    this.operator = '';
    this.value = '';
    this.preVal = '';
    this.transTypeaheadList = ['aeewrew rw rerwerewr  ttwrtretre ytyryry', 'basdad sadsad sads adsadsada sdsadsa sdasdsad sdasd'];
    this.attributeValue = [];
    this.oprList = [];
    this.subscription = [];
    this.datas = [];
    this.datePickerOptions = {
      todayBtnTxt: 'Today',
      dateFormat: 'mm-dd-yyyy',
      firstDayOfWeek: 'mo',
      showClearDateBtn: false,
      editableDateField: false,
      sunHighlight: true,
      height: '34px',
      inline: false,
      selectionTxtFontSize: '14px'
    };
    this.selEffDate = {
      year: 0,
      month: 0,
      day: 0
    };
    this.selExpDate = {
      year: 0,
      month: 0,
      day: 0
    };
  }
}
