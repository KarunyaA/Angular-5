export class OrderRuleParameterType {
    orderRuleParameterTypeCode: string;
    orderRuleParameterTypeDescription: string;
    orderRuleParameterValueTypeCode: string;
}
