import { inject, TestBed } from '@angular/core/testing';

import { RulesListService } from './rules-list.service';

describe('RulesListService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [RulesListService]
    });
  });

  it('should be created', inject([RulesListService], (service: RulesListService) => {
    expect(service).toBeTruthy();
  }));
});
