import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { JBHGlobals } from '../../../app.service';

@Component({
    selector: 'app-operator-view',
    templateUrl: './operator-view.component.html',
    styleUrls: ['./operator-view.component.scss']
})
export class OperatorViewComponent implements OnInit {
    @Input() optControl: FormGroup;
    @Input() orderRuleOperatorsList;
    @Input() orderRuleOperatorsValue: any;
    @Input() tabindex;
    @Input() index;
    @Output() optChange: EventEmitter<any> = new EventEmitter<any>();
    operatorMsg = 'Operator';
    constructor(private jbhGlobals: JBHGlobals, private fb: FormBuilder) { }

    ngOnInit(): void {
        this.oprValidatiion();
    }
    oprValidatiion(): void {
        if (this.optControl !== undefined) {
        this.optControl.controls['orderRuleLogicalOperatorCode'].setValidators(this.jbhGlobals.customValidator.mandatorySelect);
        }
    }
    onOperatorChange(event): void {
        this.optChange.emit({
            event: event,
            values: {
                'selectedVal': event.target.value
            }
        });
    }
}
