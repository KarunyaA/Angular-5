import { Injectable } from '@angular/core';

@Injectable()
export class AttributeViewService {

    constructor() { }
  attrValidation(attrForm, attributeViewComponent): void {
        if (attributeViewComponent.attributesList[attrForm.controls.orderRuleCriteriaCode.value] !== undefined) {
            const attrType = attributeViewComponent.attributesList[attrForm.controls.orderRuleCriteriaCode.value].type;
            if (attrType === 'timefield' || attrType === 'datefield') {
                if (attrForm['controls']['orderRuleCriteriaValue'].hasError('mandatory')) {
                    attrForm['controls']['orderRuleCriteriaValue'].markAsTouched();
                    attrForm['controls']['orderRuleCriteriaValue'].setErrors({
                        'mandatory': true
                    });
                }
                if (attrForm.controls.orderRuleLogicalOperatorDTO.controls.orderRuleLogicalOperatorCode.value === 'GrtLessThn' &&
                    attrForm['controls']['orderRuleCriteriaValueEnd'].hasError('mandatory')) {
                    attrForm['controls']['orderRuleCriteriaValueEnd'].markAsTouched();
                    attrForm['controls']['orderRuleCriteriaValueEnd'].setErrors({
                        'mandatory': true
                    });
                }
            } else {
                if (attributeViewComponent.jbhGlobals.utils.isEmpty(attrForm['controls']['orderRuleCriteriaValue'].value.toString())) {
                    attrForm['controls']['orderRuleCriteriaValue'].markAsTouched();
                    attrForm['controls']['orderRuleCriteriaValue'].setErrors({
                        'mandatory': true
                    });
                }
                if (attrForm.controls.orderRuleLogicalOperatorDTO.controls.orderRuleLogicalOperatorCode.value === 'GrtLessThn' &&
                    ((attrForm['controls']['orderRuleCriteriaValueEnd'].value !== null) ?
                        attributeViewComponent.jbhGlobals.utils.isEmpty(attrForm['controls']
                        ['orderRuleCriteriaValueEnd'].value.toString()) : true)) {
                    attrForm['controls']['orderRuleCriteriaValueEnd'].markAsTouched();
                    attrForm['controls']['orderRuleCriteriaValueEnd'].setErrors({
                        'mandatory': true
                    });
                }
            }
        }
        if (attributeViewComponent.jbhGlobals.utils.isEmpty(attrForm['controls']['orderRuleCriteriaCode'].value)) {
            attributeViewComponent.jbhGlobals.utils.forIn(attributeViewComponent.attrcontrol['controls']['orderRuleCriteriaCode'],
            function (value, name, object): void {
                    attrForm['controls']['orderRuleCriteriaCode'].markAsTouched();
                    attrForm['controls']['orderRuleCriteriaCode'].setErrors({
                        'mandatorySelect': true
                    });
                });
        }
        const oprCode = attributeViewComponent.attrcontrol.controls
        ['orderRuleLogicalOperatorDTO']['controls']['orderRuleLogicalOperatorCode'];
        if (attributeViewComponent.jbhGlobals.utils.isEmpty(oprCode.value)) {
            attributeViewComponent.jbhGlobals.utils.forIn(oprCode,
            function (value, name, object): void {
                    oprCode.markAsTouched();
                    oprCode.setErrors({
                        'mandatorySelect': true
                    });
                });
        }
    }
  onOptChange(eve, orderRuleLogicalOperatorsList, attributeViewComponent): void {
        const selOpt = eve.values.selectedVal;
        const isRangeApplicable = (attributeViewComponent.attributeModel.compType === 'datefield' ||
            attributeViewComponent.attributeModel.compType === 'numberfield' ||
            attributeViewComponent.attributeModel.compType === 'timefield' ||
            attributeViewComponent.attributeModel.compType === 'daterange' ||
            attributeViewComponent.attributeModel.compType === 'numberrange' ||
            attributeViewComponent.attributeModel.compType === 'timerange');
        if (isRangeApplicable) {
            switch (attributeViewComponent.attributeModel.compType) {
                case 'datefield':
                case 'daterange':
                    attributeViewComponent.attributeModel.compType = attributeViewComponent.isRange(selOpt) ? 'daterange' : 'datefield';
                    attributeViewComponent.attrcontrol.controls['orderRuleCriteriaValueEnd'].setValidators(
                        (attributeViewComponent.attributeModel.compType === 'daterange') ?
                            [attributeViewComponent.jbhGlobals.customValidator.mandatory] : []);
                    attributeViewComponent.attrcontrol.controls['orderRuleCriteriaValueEnd'].updateValueAndValidity();
                    break;
                case 'numberfield':
                case 'numberrange':
                    attributeViewComponent.attributeModel.compType = attributeViewComponent.isRange(selOpt) ? 'numberrange' : 'numberfield';
                    attributeViewComponent.attrcontrol.controls['orderRuleCriteriaValueEnd'].setValidators(
                        (attributeViewComponent.attributeModel.compType === 'numberrange') ?
                            [attributeViewComponent.jbhGlobals.customValidator.mandatory] : []);
                    attributeViewComponent.attrcontrol.controls['orderRuleCriteriaValueEnd'].updateValueAndValidity();
                    break;
                case 'timefield':
                case 'timerange':
                    attributeViewComponent.attributeModel.compType = attributeViewComponent.isRange(selOpt) ? 'timerange' : 'timefield';
                    attributeViewComponent.attrcontrol.controls['orderRuleCriteriaValueEnd'].setValidators(
                        (attributeViewComponent.attributeModel.compType === 'timerange') ?
                            [attributeViewComponent.jbhGlobals.customValidator.mandatory] : []);
                    attributeViewComponent.attrcontrol.controls['orderRuleCriteriaValueEnd'].updateValueAndValidity();
                    break;
                default:
                    break;
            }
        }
    }
  createGetCriValTypeAhead(currentParam, endPtUrl, searchStr, attributeViewComponent): void {
        const pname = currentParam['paramname'];
        const isTypeAhead = (pname !== null && pname !== '' && pname !== undefined);
        const url = (isTypeAhead) ? `${endPtUrl}${pname}=${searchStr}` : endPtUrl + searchStr;
        attributeViewComponent.attributeModel.subscription.push(attributeViewComponent.automationRulesService.fetchData(url, '', false)
            .takeWhile(() => attributeViewComponent.attributeModel.subscribeFlag).subscribe(data => {
                attributeViewComponent.attributeModel.transTypeaheadList = [];
                const resAttr = currentParam['responsenodePath'];
                let typeaheadData = [];
                switch (resAttr !== '') {
                    case true:
                        typeaheadData = attributeViewComponent.jbhGlobals.utils.get(data, currentParam['responsenodePath']);
                        break;
                    default:
                        typeaheadData = data;
                        break;
                }
                attributeViewComponent.loadTypeaheadListValue(currentParam, typeaheadData);
            }));
    }
  loadDropdownData(attrListVal, attributeViewComponent): void {
        attributeViewComponent.attributeModel.subscription.push(attributeViewComponent.automationRulesService
            .fetchData(attrListVal['url'], '', false).subscribe(data => {
                attributeViewComponent.attributeModel.transTypeaheadList = [];
                switch (attrListVal['responsecodeattr'].length) {
                    case 1:
                        for (const item of data[attrListVal['responsenode'][0]][attrListVal['responsenode'][1]]) {
                            attributeViewComponent.attributeModel.transTypeaheadList.push({
                                'id': item[attrListVal['responsecodeattr'][0]],
                                'text': item[attrListVal['responsedescattr'][0]]
                            });
                        }
                        console.log(attributeViewComponent.attributeModel.transTypeaheadList);
                        break;
                    case 2:
                        for (const item of data[attrListVal['responsenode'][0]][attrListVal['responsenode'][1]]) {
                            attributeViewComponent.attributeModel.transTypeaheadList.push({
                                'id': item[attrListVal['responsecodeattr'][0]][attrListVal['responsecodeattr'][1]],
                                'text': item[attrListVal['responsedescattr'][0]][attrListVal['responsedescattr'][1]]
                            });
                            console.log(attributeViewComponent.attributeModel.transTypeaheadList);
                        }
                        break;
                    default:
                        break;
                }
            }));
    }
  createPostCriValTypeAhead(currentParam, endPtUrl, searchStr, attributeViewComponent): void {
        const params = currentParam['params'];
        if (currentParam['path'] !== undefined && currentParam['path'] !== '') {
      attributeViewComponent.jbhGlobals.utils.set(params, currentParam['path'], `${searchStr}*`);
        }
        if (currentParam['path1'] !== undefined && currentParam['path1'] !== '') {
        attributeViewComponent.jbhGlobals.utils.set(params, currentParam['path1'], `${searchStr}*`);
        }
        attributeViewComponent.attributeModel.subscription.push(attributeViewComponent.automationRulesService.postData(endPtUrl, params)
            .takeWhile(() => attributeViewComponent.attributeModel.subscribeFlag).subscribe(data => {
                attributeViewComponent.attributeModel.transTypeaheadList = [];
                let typeaheadData = [];
                typeaheadData = attributeViewComponent.jbhGlobals.utils.get(data, currentParam['responsenodePath']);
                attributeViewComponent.loadTypeaheadListValue(currentParam, typeaheadData);
            }));
    }
}
