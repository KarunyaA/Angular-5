import { Component, ElementRef, EventEmitter, Input, OnDestroy, OnInit, Output, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';

import { JBHGlobals } from '../../../app.service';

import { IMyDate, IMyDateModel, IMyOptions } from 'mydatepicker';
import * as moment from 'moment';

import { RulesService } from '../rules.service';
import { AttributeModel } from '../model/attribute.model';
import { AutomationRulesService } from '../services/automation-rules.service';
import { AttributeViewService } from '../services/attribute-view.service';

@Component({
    selector: 'app-attribute-view',
    templateUrl: './attribute-view.component.html',
    styleUrls: ['./attribute-view.component.scss'],
    providers: [AutomationRulesService, AttributeViewService]
})
export class AttributeViewComponent implements OnInit, OnDestroy {
    attributeModel: AttributeModel;
    orderRuleOperatorsList: any[] = [];
    @ViewChild('ruleDetId') elRuleDetId: ElementRef;
    @ViewChild('attrDD') attrDD: any;
    @Output() removeAttr: EventEmitter<any> = new EventEmitter<any>();
    @Input() attrcontrol: FormGroup;
    @Input() index: number;
    @Input() tabIdx: number;
    @Input() attributesList: any;
    @Input() orderRuleCriteriaList: any;
    @Input() orderRuleCriteriaSetID: number;
    @Input()
    set orderRuleOpts(isEmpty: boolean) {
        const codeVal = this.attrcontrol['controls']['orderRuleCriteriaCode'].value;
        if (!isEmpty && codeVal !== '' && this.orderRuleCriteriaList !== undefined && this.orderRuleCriteriaList.length > 0) {
            this.orderRuleOperatorsList = this.findOperators(this.orderRuleCriteriaList, codeVal);
        }
    }
    constructor(
        private jbhGlobals: JBHGlobals, private fb: FormBuilder,
        private datePipeObj: DatePipe, private rulesService: RulesService,
        private automationRulesService: AutomationRulesService,
        private attributeViewService: AttributeViewService) { }
    ngOnInit(): void {
        this.attributeModel = new AttributeModel();
        /* Load corresponding component type */
        if (this.attrcontrol !== undefined) {
            const currCriCode = this.attrcontrol['controls']['orderRuleCriteriaCode'].value;
            this.attributeModel.preVal = currCriCode;
            const currCriOpt = this.attrcontrol['controls']['orderRuleLogicalOperatorDTO']
            ['controls']['orderRuleLogicalOperatorCode'].value;
            const val = this.attrcontrol['controls']['orderRuleCriteriaValue'].value;
            const endVal = this.attrcontrol['controls']['orderRuleCriteriaValueEnd'].value;
            if (currCriCode !== null && currCriCode !== '') {
                this.setCriValTypeAhead(currCriCode, this.index, currCriOpt);
            } else {
                this.attributeModel.compType = 'textfield';
            }
            /* Setting Date and Time On Load*/
            if ((currCriCode === 'Earlydelap' || currCriCode === 'Latedelap' || currCriCode === 'Ordtime')) {
                this.attrcontrol['controls']['orderRuleCriteriaValue'].setValue(this.setTimeAttribute(null));
                this.attrcontrol['controls']['orderRuleCriteriaValueEnd'].setValue(this.setTimeAttribute(null));
                if (val !== '' && val !== null) {
                    this.attrcontrol['controls']['orderRuleCriteriaValue'].setValue(this.setTimeAttribute(val));
                }
                if (endVal !== '' && endVal !== null) {
                    this.attrcontrol['controls']['orderRuleCriteriaValueEnd'].setValue(this.setTimeAttribute(endVal));
                }
            }
            if ((currCriCode === 'Earlypikap' || currCriCode === 'Latepikap' || currCriCode === 'Orddate') && val !== '' && val !== null) {
                this.attributeModel.selEffDate = this.getDateFormat(val);
            }
            if ((currCriCode === 'Earlypikap' || currCriCode === 'Latepikap' || currCriCode === 'Orddate')
                && endVal !== '' && endVal !== null) {
                this.attributeModel.selExpDate = this.getDateFormat(endVal);
            }
        }
    }
    ngOnDestroy(): void {
        this.attributeModel.transTypeaheadList = [];
        for (const subs of this.attributeModel.subscription) {
            subs.unsubscribe();
        }
    }
    onInputValidation(): void {
        this.attrcontrol.controls['orderRuleCriteriaValue'].setValidators([this.jbhGlobals.customValidator.alphaNumeric,
        this.jbhGlobals.customValidator.mandatory]);
        if (this.attributeModel.compType === 'numberrange') {
            const lowerRange = this.attrcontrol.controls['orderRuleCriteriaValue'].value;
            const upperRange = this.attrcontrol.controls['orderRuleCriteriaValueEnd'].value;
            if ((lowerRange !== '' && lowerRange !== null) && (upperRange !== '' && upperRange !== null)) {
                this.attributeModel.rangeFlag = (lowerRange > upperRange);
            } else {
                this.attributeModel.rangeFlag = false;
            }
        }
    }
    onRemoveAttributeClick(id): void {
        this.removeAttr.emit({
            event: event,
            values: {
                'id': id,
                'criSetId': this.orderRuleCriteriaSetID,
                'detailId': this.elRuleDetId.nativeElement.value
            }
        });
        this.removePrevSelectedAttribute();
    }
    onCriteriaChange(eve, value): void {
        if (this.rulesService.selectedAtrributeList.length !== 0 &&
            this.findNewAttribute(eve.target.value)[0] !== undefined) {
            this.jbhGlobals.notifications.alert('Warning', 'Same Attribute cannot be Added ');
            eve.target.value = this.attributeModel.preVal ? this.attributeModel.preVal : '';
        } else {
            this.attributeModel.oprList = [];
            const target = eve.currentTarget;
            const selTargetIndex = target.options[target.selectedIndex].getAttribute('data-index');
            const getOpr = value[selTargetIndex].orderRuleLogicalOperator;
            for (let i = 0; i < getOpr.length; i++) {
                this.attributeModel.oprList.push(getOpr[i]);
            }
            this.orderRuleOperatorsList = this.attributeModel.oprList;
            const criOpt = this.attrcontrol.controls;
            const criVal = target.value;
            criOpt['orderRuleCriteriaValue'].setValue('');
            criOpt['orderRuleLogicalOperatorDTO']['controls']['orderRuleLogicalOperatorCode'].setValue('');
            this.setCriValTypeAhead(criVal, selTargetIndex, null);
            if (this.attributeModel.preVal) {
                this.removePrevSelectedAttribute(this.attributeModel.preVal);
            }
            this.rulesService.selectedAtrributeList.push(eve.target.value);
            this.attributeModel.preVal = eve.target.value;
        }
    }
    loadTypeaheadListValue(currentParam, typeaheadData): void {
        if (!this.jbhGlobals.utils.isEmpty(typeaheadData)) {
        this.attributeModel.transTypeaheadList = [];
        for (const item of typeaheadData) {
            const tempObj = {
                'name' : this.getAttributeValue(item, currentParam['responsedescPath']),
                'code' : this.getAttributeValue(item, currentParam['responsecodePath']),
                'id' : this.getAttributeValue(item, currentParam['responseIdPath']) ?
                    this.getAttributeValue(item, currentParam['responseIdPath']).toString() : ''
            };
            // const name = this.getAttributeValue(item, currentParam['responsedescPath']);
            // const code = this.getAttributeValue(item, currentParam['responsecodePath']);
            // const id = this.getAttributeValue(item, currentParam['responseIdPath']) ?
            // this.getAttributeValue(item, currentParam['responseIdPath']).toString() : '';
            const obj = {
                'text': (tempObj['name'] && tempObj['code']) ? `${tempObj['name']} ${tempObj['code']}` :
                    `${tempObj['name']}${tempObj['code']}`,
                'id': tempObj[currentParam['selectionAttr']]
            };
            this.attributeModel.transTypeaheadList.push(obj);
        }
    }
    }
    onSelect(event): void {
        this.attributeModel.isValueSelected = true;
        this.attributeModel.subscribeFlag = false;
        this.attrcontrol['controls']['selectedCriteriaValue'].setValue(event['item']['id']);
    }
    onBlur(event): void {
        if (!this.attributeModel.isValueSelected) {
            this.attrcontrol['controls']['orderRuleCriteriaValue'].setValue('');
        }
    }
    attrValidation(attrForm): void {
        this.attributeViewService.attrValidation(attrForm, this);
    }
    onOptChange(eve, orderRuleOperatorsList): void {
        this.attributeViewService.onOptChange(eve, orderRuleOperatorsList, this);
    }
    isRange(selOpt: string): boolean {
        if (selOpt === 'GrtLessThn' || selOpt === 'Between') {
            return true;
        } else if (selOpt === 'EqlGrtThn' || selOpt === 'EqlLesThn' || selOpt === 'GrtThn' || selOpt === 'LessThan' || selOpt === 'Equal') {
            return false;
        }
    }
    setDateTime(eve, type): void {
        let attrType;
        switch (type) {
            case 'effDt':
            case 'expDt':
                this.attributeModel[(type === 'effDt') ? 'selEffDate' : 'selExpDate']
                    = this.getDateFormat(eve.jsdate);
                this.attributeModel[(type === 'effDt') ? 'effectiveDateFlag' : 'expirationDateFlag'] = false;
                attrType = 'date';
                break;
            case 'startTime':
            case 'endTime':
                this.attributeModel[(type === 'startTime') ? 'startTimeMeridian' : 'endTimeMeridian'] = true;
                // this.attributeModel.expirationDateFlag = false;
                attrType = 'time';
                break;
            default:
                break;
        }
        this.validateDates(attrType);
    }
    onpickUpDateChanged(event: IMyDateModel): void {
        let jsDt;
        this.attributeModel.effectiveDateFlag = false;
        jsDt = this.datePipeObj.transform(event.jsdate, 'yyyy-MM-ddTHH:mm:ss');
        event.jsdate = jsDt;
        this.validateDates('date');
    }
    ondeliveryDateChanged(event: IMyDateModel): void {
        let jsDt;
        this.attributeModel.expirationDateFlag = false;
        jsDt = this.datePipeObj.transform(event.jsdate, 'yyyy-MM-ddTHH:mm:ss');
        event.jsdate = jsDt;
        this.validateDates('date');
    }
    onStartTimeChanged(): void {
        this.attributeModel.startTimeMeridian = true;
    }
    onEndTimeChanged(): void {
        this.attributeModel.endTimeMeridian = true;
    }
    onAttributeValueLoad(searchStr): void {
        console.log(searchStr.length, searchStr)
        if (searchStr !== null && searchStr !== undefined && searchStr.length < 2) {
            this.attributeModel.subscribeFlag = true;
        }
        if (searchStr !== null && searchStr !== undefined && searchStr.length <= 2 && this.attributeModel.compType === 'multiselect') {
            this.attributeModel.transTypeaheadList = [];
            console.log(this.attributeModel.transTypeaheadList);
        }
        if (searchStr !== null && searchStr !== undefined && searchStr.length > 2) {
            // this.attributeModel.transTypeaheadList = [];
            const attrListVal = this.attributesList[this.attrcontrol['controls']['orderRuleCriteriaCode'].value];
            this.attributeModel.isValueSelected = false;
            const endPtUrl = attrListVal['url'];
            if (attrListVal['requestMethod'] === 'post') {
                this.attributeViewService.createPostCriValTypeAhead(attrListVal, endPtUrl, searchStr, this);
            } else if (attrListVal['requestMethod'] === 'get') {
                this.attributeViewService.createGetCriValTypeAhead(attrListVal, endPtUrl, searchStr, this);
            }
        }
    }
    onAttrSelect(event, isSelectFlag: boolean): void {
        console.log(event);
        if (isSelectFlag) {
            const attrType = this.attributesList[this.attrcontrol['controls']
            ['orderRuleCriteriaCode'].value]['type'];
            if (attrType === 'multiselect') {
                this.attributeModel.transTypeaheadList = [];
                this.attributeModel.isValueSelected = true;
                this.attributeModel.subscribeFlag = false;
            }
            this.attrcontrol['controls']['orderRuleCriteriaValue'].setValidators([]);
        } else if (!isSelectFlag && this.jbhGlobals.utils.isEmpty(this.attrcontrol['controls']['orderRuleCriteriaValue'].value)) {
            this.attrcontrol['controls']['orderRuleCriteriaValue'].setValidators([this.jbhGlobals.customValidator.mandatorySelect]);
        }
        this.attrcontrol['controls']['orderRuleCriteriaValue'].updateValueAndValidity();
        // else if (attrType === 'multiselectDropdown') {

        // }
    }
    // onDataLoad(event) {
    //     if (event.length > 0) {
    //         const selectionAttr = this.attributesList[this.attrcontrol['controls']['orderRuleCriteriaCode'].value]
    //         this.attrcontrol['controls']['selectedCriteriaValue']['setValue'](event[0][selectionAttr]);
    //         console.log(event, this.attributeModel.selectionAttr);
    //     }
    // }
    setTimeAttribute(timeStr: string): object {
        const retVal = new Date();
        retVal.setHours((timeStr !== null) ? Number(timeStr.split(':')[0]) : 0);
        retVal.setMinutes((timeStr !== null) ? Number(timeStr.split(':')[1]) : 0);
        return retVal;
    }
    isDateEmpty(dtObj, isDateAttr): boolean {
        return (isDateAttr ? (dtObj.year === 0 && dtObj.month === 0 && dtObj.day === 0) :
            (dtObj.getHours() === 0));
    }
    setDateTimeFormatFromDt(date): string {
        const dateTime = new Date();
        dateTime.setFullYear(date.year);
        dateTime.setMonth(date.month - 1);
        dateTime.setDate(date.day);
        return moment(dateTime).format('YYYY-MM-DDTHH:mm:ss');
    }
    getDateFormat(date): any {
        const dt: Date = typeof (date) === 'string' ? new Date(date.replace(/-/g, '\/')) : new Date(date);
        return {
            year: dt.getFullYear(),
            month: dt.getMonth() + 1,
            day: dt.getDate()
        };
    }
    private validateDates(attrType): void {
        const curOpt = this.attrcontrol['controls']['orderRuleLogicalOperatorDTO']['controls']['orderRuleLogicalOperatorCode'].value;
        const isDateAttr = (attrType === 'date');
        const startAttrVal = isDateAttr ? this.attributeModel.selEffDate :
            this.attrcontrol.controls.orderRuleCriteriaValue.value;
        const endAttrVal = isDateAttr ? this.attributeModel.selExpDate :
            this.attrcontrol.controls.orderRuleCriteriaValueEnd.value;
        const emptyCheck = !this.isDateEmpty(startAttrVal, isDateAttr) &&
            !this.isDateEmpty(endAttrVal, isDateAttr);
        if (curOpt === 'GrtLessThn' && emptyCheck) {
            const effDtTime = isDateAttr ? this.setDateTimeFormatFromDt(startAttrVal) :
                startAttrVal.getHours() * 60 + startAttrVal.getMinutes();
            const expDtTime = isDateAttr ? this.setDateTimeFormatFromDt(endAttrVal) :
                endAttrVal.getHours() * 60 + endAttrVal.getMinutes();
            if (effDtTime > expDtTime) {
                this.attrcontrol['controls']['orderRuleCriteriaValueEnd'].setErrors({ 'incorrect': true });
                this.attrcontrol['controls']['orderRuleCriteriaValue'].setErrors({ 'incorrect': true });
                this.attributeModel[isDateAttr ? 'dateCompareFlag' : 'timeCompareFlag'] = true;
            } else {
                this.attrcontrol['controls']['orderRuleCriteriaValueEnd'].setErrors(null);
                this.attrcontrol['controls']['orderRuleCriteriaValue'].setErrors(null);
                this.attributeModel[isDateAttr ? 'dateCompareFlag' : 'timeCompareFlag'] = false;
            }
        }
    }
    private findOperators(criArr, searchStr): any {
        let retVal = [];
        criArr.forEach(key => {
            if (this.orderRuleOperatorsList.length === 0 && key['orderRuleCriteriaCode'] === searchStr) {
                retVal = key['orderRuleLogicalOperator'];
            }
        });
        return retVal;
    }
    private setCriValTypeAhead(criVal, selTargetIndex, criOpt): void {
        const attrListVal = this.attributesList[criVal];
        this.ngOnDestroy();
        if (attrListVal !== undefined) {
            this.attributeModel.compType = attrListVal['type'];
            switch (this.attributeModel.compType) {
                case 'multiselect':
                    // this.setTypeaheadType(attrListVal, selTargetIndex);
                    this.attrcontrol.controls['orderRuleCriteriaValue'].setValidators([]);
                    this.attrcontrol.controls['orderRuleCriteriaValue'].updateValueAndValidity();
                    this.attributeModel.transTypeaheadList = [];
                    break;
                case 'typeahead':
                    this.setTypeaheadType(attrListVal, selTargetIndex);
                    break;
                case 'datefield':
                    this.setRangeType(criOpt, 'daterange');
                    break;
                case 'timefield':
                    if (criOpt === null) {
                        this.attrcontrol['controls']['orderRuleCriteriaValueEnd'].setValue(this.setTimeAttribute(null));
                        this.attrcontrol['controls']['orderRuleCriteriaValue'].setValue(this.setTimeAttribute(null));
                    }
                    this.setRangeType(criOpt, 'timerange');
                    break;
                case 'numberfield':
                    this.setRangeType(criOpt, 'numberrange');
                    break;
                case 'boolean':
                    this.attributeModel.datas = attrListVal['data'];
                    break;
                case 'multiselectDropdown':
                    this.attributeViewService.loadDropdownData(attrListVal, this);
                    break;
                default:
                    break;
            }
        }
    }
    private setRangeType(criOpt, rangetype): void {
        if (criOpt === 'GrtLessThn') {
            this.attributeModel.compType = rangetype;
            this.attrcontrol['controls']['orderRuleCriteriaValueEnd'].setValidators([
                this.jbhGlobals.customValidator.mandatory]);
            this.attrcontrol['controls']['orderRuleCriteriaValueEnd'].updateValueAndValidity();
        }
    }
    private setTypeaheadType(attrListVal, selTargetIndex): void {
        const detCtrl = this.attrcontrol;
        this.attributeModel.selectionAttr = attrListVal['selectionAttr'];
        if (selTargetIndex !== null && detCtrl !== undefined) {
            this.attributeModel.subscription.push(detCtrl['controls']['orderRuleCriteriaValue']['valueChanges']
                .debounceTime(this.attributeModel.debounceValue)
                .distinctUntilChanged()
                .subscribe((searchStr) => {
                    if (searchStr !== null && searchStr !== undefined && searchStr.length < 2) {
                        this.attributeModel.subscribeFlag = true;
                    }
                    if (searchStr !== null && searchStr !== undefined && searchStr.length > 2) {
                        this.attributeModel.isValueSelected = false;
                        const endPtUrl = attrListVal['url'];
                        if (attrListVal['requestMethod'] === 'post') {
                            this.attributeViewService.createPostCriValTypeAhead(attrListVal, endPtUrl, searchStr, this);
                        } else if (attrListVal['requestMethod'] === 'get') {
                            this.attributeViewService.createGetCriValTypeAhead(attrListVal, endPtUrl, searchStr, this);
                        }
                    }
                }));
        }
    }
    private removePrevSelectedAttribute(preVal?): void {
        this.rulesService.selectedAtrributeList.splice(
            this.rulesService.selectedAtrributeList.indexOf(
                preVal !== undefined ? preVal : this.attrcontrol.controls.orderRuleCriteriaCode.value), 1);
    }
    private findNewAttribute(selectedAttribute): any {
        return this.rulesService.selectedAtrributeList.filter(item => item.toLowerCase().indexOf(selectedAttribute.toLowerCase()) !== -1);
    }
    private getAttributeValue(item, value): any {
        const attributeValue = this.jbhGlobals.utils.get(item, value);
        if (attributeValue !== undefined && attributeValue !== null) {
            return attributeValue;
        } else {
            return '';
        }
    }
}
