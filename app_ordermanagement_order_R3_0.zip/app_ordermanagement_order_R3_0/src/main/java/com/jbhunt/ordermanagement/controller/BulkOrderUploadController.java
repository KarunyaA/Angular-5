package com.jbhunt.ordermanagement.controller;



import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Optional;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.jbhunt.ordermanagement.order.dto.BulkUploadResponseDTO;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.jbhunt.ordermanagement.properties.OrderProperties;
import com.jbhunt.ordermanagement.order.dto.DocumentDTO;
import com.jbhunt.ordermanagement.order.dto.DocumentResponseDTO;
import com.jbhunt.ordermanagement.order.dto.OrderDTO;
import com.jbhunt.ordermanagement.order.dto.OrderResponseDTO;
import com.jbhunt.ordermanagement.order.dto.UserSavedSearchCriteriaDTO;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping(value = "/ordermanagementservices")
@Slf4j
public class BulkOrderUploadController {

    private RestTemplate restTemplate;
    private OrderProperties orderProperties;
    
    @Autowired
    private ObjectMapper objectMapper;
    @Autowired
    public BulkOrderUploadController(RestTemplate restTemplate, OrderProperties orderProperties) {
        this.restTemplate = restTemplate;
        this.orderProperties = orderProperties;
    }

    @RequestMapping(value = "/uploadFile", method = RequestMethod.POST, consumes = "multipart/form-data")
    @ResponseBody
    public ResponseEntity<?> bulkOrderUpload(@RequestParam("uploadedFileName") MultipartFile multipartfile)
            throws RestClientException, IOException {
        log.info("___In Client Controller");
        String encoded = Base64.getEncoder().encodeToString(multipartfile.getBytes());
        ResponseEntity<BulkUploadResponseDTO> responseEntity = this.restTemplate.exchange(orderProperties.getOrderBaseUrl() + "/bulkorderupload",
                org.springframework.http.HttpMethod.POST, new HttpEntity(encoded), BulkUploadResponseDTO.class);
        return ResponseEntity.ok(responseEntity.getBody());
    }
    
    @RequestMapping(value = "/uploadDocument", method = RequestMethod.POST, consumes = "multipart/form-data")
    @ResponseBody
    public ResponseEntity<DocumentResponseDTO> create(@RequestParam("uploadFileContent") MultipartFile fileContent,
    		@RequestParam("uploadDocumentContent") String  documentContent,@RequestParam("ignoreDuplicateValue") String ignoreDuplicateValue) throws JsonParseException,JsonMappingException, IOException {
    	
    	DocumentDTO documentValues = new ObjectMapper().readValue(documentContent, DocumentDTO.class);
    	
       

    	documentValues.setFileContent(fileContent.getBytes());
     
        log.info("___In Client Controller_documentContent"+documentValues.getFileName());
        log.info("___In Client Controller_documentContent"+documentValues.getFileFormat());
        log.info("___In Client Controller_documentContent"+documentValues.getDocumentType());
        log.info("___In Client Controller_documentContent"+documentValues.getDocumentClass());
        log.info("___In Client Controller_documentContent"+documentValues.getOrderID());
        log.info("___documentContent_documentValues"+documentValues);

        
        Boolean ignoreduplicate = Boolean.valueOf(ignoreDuplicateValue);
        log.info("___In Client Controller_ignoreduplicate"+ignoreduplicate);
        


		Object  responseEntity= this.restTemplate.postForObject(orderProperties.getOrderBaseUrl() + "/documents?ignoreduplicate="+ignoreduplicate,
    		   documentValues,Object.class);
       log.info("___documentContent_responseEntity"+ responseEntity);
       
       String jsonStr = new ObjectMapper().writeValueAsString(responseEntity);
       log.info("___documentContent_jsonStr"+ jsonStr);

       DocumentResponseDTO documentResponseDTO = new ObjectMapper().readValue(jsonStr, DocumentResponseDTO.class);
       log.info("___documentContent_DocumentResponseDTO"+ documentResponseDTO);
	return ResponseEntity.ok(documentResponseDTO);
       
    }   
        
    }

