package com.jbhunt.ordermanagement.configuration;


import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.servlet.Filter;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.CacheControl;
import org.springframework.web.filter.CharacterEncodingFilter;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;

import com.github.ziplet.filter.compression.CompressingFilter;
import com.jbhunt.biz.security.sso.filters.AuthenticationFilter;
import com.jbhunt.biz.security.sso.filters.LogoutFilter;
import com.jbhunt.biz.security.ui.filter.AuthorizationEnforcementFilter;

@Configuration
public class AppConfiguration {

  @Bean(name = "compressionFilter")
  public Filter compressionFilter() {
      return new CompressingFilter();
  }

  @Bean
  public FilterRegistrationBean filterRegistration() {
      FilterRegistrationBean registration = new FilterRegistrationBean();
      registration.setFilter(compressionFilter());
      registration.setName("compressionFilter");
      registration.setOrder(Integer.MAX_VALUE - 4);        
      return registration;
  }
  
  @Bean(name = "jbhSSOFilter")
  public Filter jbhSSOFilter() {
      return new AuthenticationFilter();
  }
  
  @Bean
  public FilterRegistrationBean registerJbhSSOFilter() {
      FilterRegistrationBean registration = new FilterRegistrationBean();
      registration.setFilter(jbhSSOFilter());
      registration.setName("jbhSSOFilter");
      registration.setOrder(Integer.MAX_VALUE - 2);        
      Map <String, String> initParams = new HashMap<>();
      initParams.put("app.filter.wrap.request", "true");
      registration.setInitParameters(initParams);
      registration.setUrlPatterns(Arrays.asList("/*", "*.html"));
      registration.addServletNames("app");        
      return registration;
  }
  
  @Bean(name = "encodingFilter")
  public Filter encodingFilter() {
      return new CharacterEncodingFilter();
  }
  
  @Bean
  public FilterRegistrationBean registerEncodingFilter() {
      FilterRegistrationBean registration = new FilterRegistrationBean();
      registration.setFilter(encodingFilter());
      registration.setName("encodingFilter");        
      Map <String, String> initParams = new HashMap<>();
      initParams.put("encoding", "UTF-8");
      initParams.put("forceEncoding", "true");
      registration.setInitParameters(initParams);
      registration.setUrlPatterns(Arrays.asList("/*"));
      registration.setOrder(Integer.MAX_VALUE - 3);        
      return registration;
  }
  
  @Bean(name = "AuthFilter")
  public Filter authFilter() {
      return new AuthorizationEnforcementFilter();
  }
  
  @Bean
  public FilterRegistrationBean registerAuthFilter() {
      FilterRegistrationBean registration = new FilterRegistrationBean();
      registration.setFilter(authFilter());
      registration.setName("AuthFilter");        
      Map <String, String> initParams = new HashMap<>();
      initParams.put("loginUrl", "/signin.html");
      initParams.put("stopFilterProcess", "true");
      initParams.put("notAuthorizedUrl", "/securepages/notauthorized");
      initParams.put("secureUrls", "/order/* /order/user /user");
      initParams.put("useridResolverType", "Container");
      registration.setInitParameters(initParams);        
      registration.setUrlPatterns(Arrays.asList("/home/user", "/user"));
      registration.setOrder(Integer.MAX_VALUE - 1);        
      return registration;
  }
  
  @Bean(name = "LogoutFilter")
  public Filter logoutFilter() {
      return new LogoutFilter();
  }
  
  @Bean
  public FilterRegistrationBean registerLogoutFilter() {
      FilterRegistrationBean registration = new FilterRegistrationBean();
      registration.setFilter(logoutFilter());
      registration.setName("LogoutFilter");        
      registration.setUrlPatterns(Arrays.asList( "/logout/"));
      registration.setOrder(Integer.MAX_VALUE);        
      return registration;
  }
  
  
  @Bean
	public WebMvcConfigurerAdapter webConfigurer() {
		return new WebMvcConfigurerAdapter() {
			@Override
			public void addResourceHandlers(ResourceHandlerRegistry registry) {
				registry.addResourceHandler("/**").addResourceLocations("classpath:/public/")
						.setCacheControl(CacheControl.maxAge(365, TimeUnit.DAYS));
				registry.setOrder(2).addResourceHandler("/index.html").addResourceLocations("classpath:/public/")
				.setCacheControl(CacheControl.noCache());

			}
			@Override
			public void addViewControllers(ViewControllerRegistry registry) {
				registry.setOrder(1);
				registry.addViewController("/").setViewName("forward:/index.html");
			}
		};
	}
  
}