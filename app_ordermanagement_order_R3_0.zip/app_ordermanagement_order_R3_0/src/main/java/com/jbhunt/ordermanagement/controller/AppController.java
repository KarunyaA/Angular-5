package com.jbhunt.ordermanagement.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class AppController {

    @RequestMapping({ "/dashboard", "/tasks/**", "/advancedsearch", "/createorders/**", "/vieworder/**", "/viewucr/**",
            "/ordersearch/**", "/manageorders/**", "/monitoring/**", "/manageorders/active", "/manageorders/planned",
            "/manageorders/requested", "/manageorders/unscheduled", "/opportunities", "/automationrules/**",
            "/shippingoptions/**", "/appointments/**", "/loadinformation/**", "/settings", "/error401", "/error404",
            "/error500", "/manageratesheet/**", "/exceptionmaintenance/**", "/customerrules/**", "/changerequest/**",
            "/managereference/**","/orderplan/**", "/summary/**" })
    public String home() {
        return "forward:/index.html";
    }

}
