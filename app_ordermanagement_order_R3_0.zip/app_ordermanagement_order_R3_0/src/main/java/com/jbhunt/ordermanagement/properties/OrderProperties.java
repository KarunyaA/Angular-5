package com.jbhunt.ordermanagement.properties;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@RefreshScope
@Component
@ConfigurationProperties(prefix = "contactstatuscodes")
public class OrderProperties {

	private List<Map<String, Map<String, String>>> contactStatusCodesTypes;

	@Value("${orderBaseUrl}")
	private String orderBaseUrl;

	@Value("${ehcache.url}")
	private String ehcacheUrl;
	
	@Value("${amq.messaging.relayHost}")
	private String host;

	@Value("${amq.messaging.relayPort}")
	private Integer port;
	
	@Value("${amq.messaging.topic}")
	private String topicName;

}
