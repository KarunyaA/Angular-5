package com.jbhunt.ordermanagement.constants;

public final class OrderConstants {
	
	public static final String CALLRESULTS = "callresults";

	public static final String CALLDIRECTION = "calldirection";

	public static final String CALLINTENT = "callintent";

	public static final String RECORD_STATUS = "A";
	
	public static final String TYPE = "type";
	
	public static final String ID = "id";
	
	private OrderConstants() {
	}
}
