package com.jbhunt.ordermanagement.util;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.jbhunt.contact.entities.PhoneCallVO;
import com.jbhunt.contact.entities.StandardCodeVO;

@Service
public class ContactWebserviceUtil {

	private ContactWebserviceClient contactWebserviceClient;


	@Autowired
	public ContactWebserviceUtil(ContactWebserviceClient contactWebserviceClient) {
		this.contactWebserviceClient = contactWebserviceClient;
	}

	public List<PhoneCallVO> getPhoneCall(List<String> trackingNumbers) {
		return contactWebserviceClient.getPhoneCallRequest(trackingNumbers);
	}

	@Cacheable(value = "callIntentCache", cacheManager = "supplyChainManagementCacheManager")
	public List<StandardCodeVO> getStatusCodesByCallIntent() {
		return contactWebserviceClient.getStatusCodesForCallIntent();
	}

	@Cacheable(value = "callResultCache", cacheManager = "supplyChainManagementCacheManager")
	public List<StandardCodeVO> getStatusCodesByCallResult() {
		return contactWebserviceClient.getStatusCodesForCallResult();
	}

	@Cacheable(value = "callDirectionCache", cacheManager = "supplyChainManagementCacheManager")
	public List<StandardCodeVO> getStatusCodesByCallDirection() {
		return contactWebserviceClient.getStatusCodesForCallDirection();
	}
	
	public List<PhoneCallVO> savePhoneCalls(List<PhoneCallVO> phoneCalls ) {
		return contactWebserviceClient.savePhoneCalls(phoneCalls);
	}

}
