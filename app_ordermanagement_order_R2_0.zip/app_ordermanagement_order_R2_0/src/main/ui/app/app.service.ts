import { Injectable } from '@angular/core';

import { AppointmentsEndpointsConfig } from './../config/appointments.endpoints.config';
import { AutomationRulesEndpointsConfig } from './../config/automationrules.endpoints.config';
import { CreateOfferEndpointsConfig } from './../config/createoffer.endpoints.config';
import { LoadinformationEndpointsConfig } from './../config/loadinformation.endpoints.config';
import { ManageRateSheetEndpointsConfig } from './../config/manageratesheet.endpoints.config';
import { MonitoringEndpointsConfig } from './../config/monitoring.endpoints.config';
import { MonitoringMessagesConfig } from './../config/i18n/monitoring.messages.config';
import { MonitoringTableEndpointsConfig } from './../config/monitoringtable.endpoints.config';
import { OpportunitiesEndpointsConfig } from './../config/opportunities.endpoints.config';
import { OrderEndpointsConfig } from './../config/order.endpoints.config';
import { OrderSearchEndpointsConfig } from './../config/ordersearch.endpoints.config';
import { QuickRatesEndpointsConfig } from './../config/quickrates.endpoints.config';
import { ShippingOptionsEndpointsConfig } from './../config/shippingoptions.endpoints.config';
import { TemplateEndpointsConfig } from './../config/template.endpoints.config';
import { TemplateMessagesConfig } from './../config/i18n/template.messages.config';
import { ViewOrderEndpointsConfig } from './../config/vieworder.endpoints.config';
import { ViewUCREndpointsConfig } from './../config/viewucr.endpoints.config';
import { ChangeRequestEndpointsConfig } from './../config/changerequest.endpoints.config';
import { DashboardEndpointsConfig } from './../config/dashboard.endpoints.config';

import { NotificationsService } from 'angular2-notifications';
import * as _ from 'lodash';
import {
  ApiClientService, AppSharedDataService,
  LocalStorageService, LoggerService,
  MouseEventService, ShortcutkeyService,
  TimeoutNotifierService, UtilityFunctionsService
} from 'jbh-components/jbh-core-services';
import { ValidationService } from 'jbh-components/jbh-validation';
import { UserService } from 'jbh-components/jbh-esa';
import { AppConfig } from '../config/app.config';

import { environment } from '../environments/environment';

@Injectable()
export class JBHGlobals {

  endpoints: any;
  apiService: ApiClientService;
  logger: LoggerService;
  notifications: NotificationsService;
  shortkeys: any;
  settings: any;
  commonDataService: any;
  utils: any;
  customValidator: any;
  userDetails: any;
  mouseevents: any;
  environment: any;
  localStore: any;
  user: any;
  routeUrls: any;
  endpointsApi: any;
  timeoutNotification: TimeoutNotifierService;

  constructor(
    public apiClientService: ApiClientService,
    public log4js: LoggerService,
    public ns: NotificationsService,
    public shortcutkeyService: ShortcutkeyService,
    public appSharedDataService: AppSharedDataService,
    public localStorageService: LocalStorageService,
    public mouseevent: MouseEventService,
    public userService: UserService,
    public timeoutNotifierService: TimeoutNotifierService,
    public utilityFunctionsService: UtilityFunctionsService
  ) {
    const appConfig = AppConfig.getConfig();
    let logLevel = appConfig.system.logLevel;
    this.endpointsApi = appConfig.api;
    this.endpoints = {};
    this.endpoints['appointments'] = AppointmentsEndpointsConfig.getConfig();
    this.endpoints['automationrules'] = AutomationRulesEndpointsConfig.getConfig();
    this.endpoints['createoffer'] = CreateOfferEndpointsConfig.getConfig();
    this.endpoints['viewLoad'] = LoadinformationEndpointsConfig.getConfig();
    this.endpoints['manageratesheets'] = ManageRateSheetEndpointsConfig.getConfig();
    this.endpoints['monitoring'] = MonitoringEndpointsConfig.getConfig();
    this.endpoints['monitoringMessages'] = MonitoringMessagesConfig.getConfig();
    this.endpoints['monitoringTable'] = MonitoringTableEndpointsConfig.getConfig();
    this.endpoints['opportunities'] = OpportunitiesEndpointsConfig.getConfig();
    this.endpoints['order'] = OrderEndpointsConfig.getConfig();
    this.endpoints['ordersearch'] = OrderSearchEndpointsConfig.getConfig();
    this.endpoints['quickrates'] = QuickRatesEndpointsConfig.getConfig();
    this.endpoints['shippingoptions'] = ShippingOptionsEndpointsConfig.getConfig();
    this.endpoints['template'] = TemplateEndpointsConfig.getConfig();
    this.endpoints['templateMessages'] = TemplateMessagesConfig.getConfig();
    this.endpoints['viewOrder'] = ViewOrderEndpointsConfig.getConfig();
    this.endpoints['viewUcr'] = ViewUCREndpointsConfig.getConfig();
    this.endpoints['changerequest'] = ChangeRequestEndpointsConfig.getConfig();
    this.endpoints['dashboard'] = DashboardEndpointsConfig.getConfig();
    this.apiService = apiClientService;
    this.logger = log4js;
    this.notifications = ns;
    this.settings = appConfig.settings;
    this.routeUrls = appConfig.routeurls;
    this.utils = _;
    Object.assign(this.utils, this.utilityFunctionsService.getUtilities());
    this.shortkeys = shortcutkeyService;
    this.commonDataService = appSharedDataService;
    this.customValidator = ValidationService;
    this.localStore = localStorageService;
    this.mouseevents = mouseevent;
    this.environment = environment;
    this.user = this.userService;
    this.timeoutNotification = timeoutNotifierService;
    if (this.environment.production) {
      logLevel = 5;
    }
    this.logger.init(Number(logLevel));
  }
}
