import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Response } from '@angular/http';
import { JBHGlobals } from '../../../../app.service';
@Injectable()
export class SettingsService {

    constructor(private jbhGlobals: JBHGlobals) { }
    getSettingList() {
        return this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.notificationsettinglist, '', false);
    }
}
