import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { JBHGlobals } from '../../app.service'

@Component({
  selector: 'app-jbh-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  @Output() sidebarOpenEvent: EventEmitter<boolean> = new EventEmitter<
    boolean>();
  @Output() overlayShowEvent: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Output() notificationEvent: EventEmitter<boolean> = new EventEmitter<boolean>();
  showWindow = false;
  displayLayer: string;
  applicationName = 'ORDER';
  isSidebarOpen = false;
  notificationCount: any = '';
  private isFullScreen = false;
  constructor(public jbhGlobals: JBHGlobals) { }

  ngOnInit() {
    const data = this.jbhGlobals.user.userDetails
    if (!this.jbhGlobals.utils.isEmpty(data) && !this.jbhGlobals.utils.isEmpty(data['userId'])) {
      this.getNotificationCount(data['userId']);
    }

  }
  getFullScreenIcon(): any {
    return this.isFullScreen ? 'icon-size-actual' :
      'icon-size-fullscreen';
  }

  toggleFullScreen() {
    const doc: any = window.document;
    const docEl: any = doc.documentElement;

    const requestFullScreen: any = docEl.requestFullscreen || docEl.mozRequestFullScreen ||
      docEl.webkitRequestFullScreen || docEl.msRequestFullscreen;
    const cancelFullScreen: any = doc.exitFullscreen || doc.mozCancelFullScreen ||
      doc.webkitExitFullscreen || doc.msExitFullscreen;

    if (!doc.fullscreenElement && !doc.mozFullScreenElement && !doc.webkitFullscreenElement &&
      !doc.msFullscreenElement) {
      requestFullScreen.call(docEl);
      this.isFullScreen = true;
    } else {
      cancelFullScreen.call(doc);
      this.isFullScreen = false;
    }
  }

  toggleMobleSidebar(): any {
    this.isSidebarOpen = !this.isSidebarOpen;
    this.sidebarOpenEvent.emit(this.isSidebarOpen);
  }

  manageOverlayToggle() {
    this.showWindow = !this.showWindow;
    this.overlayShowEvent.emit(this.showWindow);
  }
  manageRightNavigationBar(event) {
    this.showWindow = !this.showWindow;
    this.notificationEvent.emit(this.showWindow);
  }
  private getNotificationCount(loggedInUserId) {
    if (loggedInUserId !== null) {
      const serUrl = this.jbhGlobals.endpoints.order.getnotificationcount + '?userId=' + loggedInUserId;
      this.jbhGlobals.apiService.getData(serUrl).subscribe(data => {
        if (data !== undefined && data !== null) {
          this.jbhGlobals.commonDataService.saveNotificationCountData(data);
          this.jbhGlobals.commonDataService.getNotificationCountData().subscribe(dataCount => {
            this.notificationCount = dataCount;
            if (this.notificationCount > 0) {
              this.notificationCount = this.notificationCount.toString();
            }
          });
        }
      });
    }
  }
}
