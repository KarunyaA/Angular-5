import { inject, TestBed } from '@angular/core/testing';

import { ConfigureRuleService } from './configure-rule.service';

describe('ConfigureRuleService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ConfigureRuleService]
    });
  });

  it('should be created', inject([ConfigureRuleService], (service: ConfigureRuleService) => {
    expect(service).toBeTruthy();
  }));
});
