import { AttributeModel } from './attribute.model';

export class RuleModel {
    businessUnit: string;
    serviceOffering: string;
    globalOverride: boolean;
    orderRuleCriteria: string;
    orderRuleParameterType: string;
    orderRuleLogicalOperator: string;
    addedAttributes: AttributeModel[];
}

export const values = ['V 1', 'V 2', 'V 3', 'V 4'];
