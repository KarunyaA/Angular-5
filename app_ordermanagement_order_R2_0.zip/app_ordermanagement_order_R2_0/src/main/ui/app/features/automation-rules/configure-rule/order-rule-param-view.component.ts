import { AfterContentInit, Component, Input, OnDestroy, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';

import { JBHGlobals } from '../../../app.service';
import * as moment from 'moment';

import { OrderRuleParamViewModel } from '../model/order-rule-param-view.model';
import { AutomationRulesService } from '../services/automation-rules.service';

@Component({
    selector: 'app-order-rule-param-view',
    templateUrl: './order-rule-param-view.component.html',
    styleUrls: ['./order-rule-param-view.component.scss'],
    providers: [AutomationRulesService]
})
export class OrderRuleParamViewComponent implements OnInit, AfterContentInit, OnDestroy {
    orderRuleParamViewModel: OrderRuleParamViewModel;
    @Input() paramcontrol: FormGroup;
    @Input() orderRuleParamsList: any;

    constructor(private jbhGlobals: JBHGlobals, private automationRulesService: AutomationRulesService) { }

    ngOnInit(): void {
        this.orderRuleParamViewModel = new OrderRuleParamViewModel();
    }
    ngAfterContentInit(): void {
        this.loadParameterTypes();
    }
    onSetDates(event): void {
        this.orderRuleParamViewModel.selEffDate = this.getDateFormat(event.jsdate);
    }
    onSelect(event): void {
        this.orderRuleParamViewModel.isValueSelected = true;
        this.orderRuleParamViewModel.subscribeFlag = false;
        this.paramcontrol['controls'][this.orderRuleParamViewModel.typeaheadType].setValue
        (event['item'][this.orderRuleParamViewModel.selectedresultaneAttr].toString());
        this.orderRuleParamViewModel.selectedValue = event['item']['text'];
    }
    onBlur(event): void {
        if (!this.orderRuleParamViewModel.isValueSelected) {
            this.paramcontrol['controls'][this.orderRuleParamViewModel.typeaheadType].setValue('');
        }
    }
    onTimeChanged(): void {
        this.orderRuleParamViewModel.timeMeridian = true;
    }
    ngOnDestroy(): void {
        this.orderRuleParamViewModel.subscribeFlag = false;
    }
    getDateFormat(date): any {
        const dt: Date = typeof (date) === 'string' ? new Date(date.replace(/-/g, '\/')) : new Date(date);
        return {
            year: dt.getFullYear(),
            month: dt.getMonth() + 1,
            day: dt.getDate()
        };
    }
    setTimeAttribute(timeStr: string): any {
        const retVal = new Date();
        retVal.setHours(Number(timeStr.split(':')[0]));
        retVal.setMinutes(Number(timeStr.split(':')[1]));
        return retVal;
    }
    private loadParameterTypes(): void {
        /* Bind Parameters */
        if (this.paramcontrol !== undefined) {
        const prmType = this.paramcontrol['controls']['orderRuleParameterTypeDTO'];
        if (prmType.value === null) {
            return;
        }
        this.orderRuleParamViewModel.compDesc = this.paramcontrol['controls']['orderParameterDescription'].value;
        this.orderRuleParamViewModel.comDTOType = this.paramcontrol.controls.orderRuleParameterTypeDTO['controls']
                        .orderRuleParameterValueTypeCode.value;
        const compName = this.paramcontrol['controls']['orderParameterName'].value;
        const currentParam = this.orderRuleParamsList[compName];
        if (currentParam !== null && currentParam !== undefined) {
            this.setRuleParamType(currentParam);
            this.setRuleParamValues(this.paramcontrol['controls'], currentParam.code);
        }
        }
    }
    private setRuleParamType(currentParam): void {
        this.orderRuleParamViewModel.compType = currentParam.type;
        this.orderRuleParamViewModel.datas = currentParam.data;
        if (this.orderRuleParamViewModel.compType === 'boolean') {
            this.orderRuleParamViewModel.selectedValue = this.paramcontrol['controls']['orderParameterCharValue'].value;
        }
        if (this.orderRuleParamViewModel.compType === 'dropdown') {
            this.orderRuleParamViewModel.selectedValue = this.paramcontrol['controls']['orderParameterCharValue'].value;
            this.automationRulesService.fetchData(currentParam['url'], null, false).
            takeWhile(() => this.orderRuleParamViewModel.subscribeFlag).subscribe(data => {
                this.orderRuleParamViewModel.datas = [];
                switch (currentParam['responsecodeattr'].length) {
                    case 1:
                        for (const item of data[currentParam['responsenode'][0]][currentParam['responsenode'][1]]) {
                            this.orderRuleParamViewModel.datas.push({
                                'code': item[currentParam['responsecodeattr'][0]],
                                'description': item[currentParam['responsedescattr'][0]]
                            });
                        }
                        break;
                    case 2:
                        for (const item of data[currentParam['responsenode'][0]][currentParam['responsenode'][1]]) {
                            this.orderRuleParamViewModel.datas.push({
                                'code': item[currentParam['responsecodeattr'][0]][currentParam['responsecodeattr'][1]],
                                'description': item[currentParam['responsedescattr'][0]][currentParam['responsedescattr'][1]]
                            });
                        }
                        break;
                    default:
                        break;
                }
            });
        }
        if (this.orderRuleParamViewModel.compType === 'typeahead') {
            this.setTypeaheadType(currentParam);
        }
    }
    private setRuleParamValues(currentParamDto, code): void {
        if (code === 'FxdTimeHr' || code === 'FxdEndTime'
            || code === 'BegEndTime' || code === 'CustAppoTm' || code === 'FxdBegTime') {
            const value = currentParamDto.orderParameterCharValue.value;
            if (value !== null && value !== '') {
                currentParamDto.orderParameterCharValue.setValue(this.setTimeAttribute(value));
            }
        }
        if (code === 'CustAppoDt') {
            const value = currentParamDto.orderParameterDateValue.value;
            if (value !== null && value !== '') {
                this.orderRuleParamViewModel.selEffDate = this.getDateFormat(value);
            }
        }
    }
    private setTypeaheadType(currentParam): void {
        if (this.orderRuleParamViewModel.comDTOType.toLowerCase() === 'number') {
            this.orderRuleParamViewModel.typeaheadType = 'orderParameterNumberValue';
        } else if (this.orderRuleParamViewModel.comDTOType.toLowerCase() === 'char') {
            this.orderRuleParamViewModel.typeaheadType = 'orderParameterCharValue';
        }
        this.orderRuleParamViewModel.selectedValue = this.paramcontrol['controls'][this.orderRuleParamViewModel.typeaheadType].value;
        this.orderRuleParamViewModel.selectedresultaneAttr = currentParam['selectionAttr'];
        this.paramcontrol['controls'][this.orderRuleParamViewModel.typeaheadType]['valueChanges']
        .debounceTime(this.orderRuleParamViewModel.debounceValue)
        .distinctUntilChanged()
        .subscribe((searchStr) => {
            if (searchStr !== null && searchStr !== undefined && searchStr.length === 0) {
                this.orderRuleParamViewModel.subscribeFlag = true;
            }
            if (searchStr !== null && searchStr !== undefined && searchStr.length > 2) {
                this.orderRuleParamViewModel.isValueSelected = false;
                const endPtUrl = currentParam['url'];
                if (currentParam['requestMethod'] === 'post') {
                        this.setPostTypeaheadValue(currentParam, endPtUrl, searchStr);
                    } else if (currentParam['requestMethod'] === 'get') {
                        this.setGetTypeaheadValue(currentParam, endPtUrl, searchStr);
                    }
                }
        });
    }
    private setPostTypeaheadValue(currentParam, endPtUrl, searchStr): void {
        const params = currentParam['params'];
        if (currentParam['path'] !== undefined && currentParam['path'] !== '') {
            this.jbhGlobals.utils.set(params, currentParam['path'], `${searchStr}*`);
        }
        if (currentParam['path1'] !== undefined && currentParam['path1'] !== '') {
            this.jbhGlobals.utils.set(params, currentParam['path1'], `${searchStr}*`);
        }
        this.automationRulesService.postData(endPtUrl, params)
        .takeWhile(() => this.orderRuleParamViewModel.subscribeFlag).subscribe(data => {
            this.orderRuleParamViewModel.transTypeaheadList = [];
            let typeaheadData = [];
            typeaheadData = this.jbhGlobals.utils.get(data, currentParam['responsenodePath']);
            this.loadTypeaheadListValue(currentParam, typeaheadData);
        });
    }
    private setGetTypeaheadValue(currentParam, endPtUrl, searchStr): void {
        const pname = currentParam['paramname'];
        const isTypeAhead = (pname !== null && pname !== '' && pname !== undefined);
        const url = (isTypeAhead) ? `${endPtUrl}${pname}=${searchStr}` : endPtUrl + searchStr;
        this.automationRulesService.fetchData(url, null, false)
        .takeWhile(() => this.orderRuleParamViewModel.subscribeFlag).subscribe(data => {
            this.orderRuleParamViewModel.transTypeaheadList = [];
            const resAttr = currentParam['responsenodePath'];
            let typeaheadData = [];
            switch (resAttr !== '') {
                case true:
                    typeaheadData = this.jbhGlobals.utils.get(data, currentParam['responsenodePath']);
                    break;
                default:
                    typeaheadData = data;
                    break;
            }
            this.loadTypeaheadListValue(currentParam, typeaheadData);
        });
    }
    private loadTypeaheadListValue(currentParam, typeaheadData): void {
        if (!this.jbhGlobals.utils.isEmpty(typeaheadData)) {
            for (const item of typeaheadData) {
                const name = this.getResultantAttributeValue (item, currentParam['responsedescPath']);
                const code = this.getResultantAttributeValue (item, currentParam['responsecodePath']);
                const id = this.getResultantAttributeValue (item, currentParam['responseIdPath']);
                const obj = {
                    'text': `${name} ${code}`,
                    'name': name,
                    'code': code,
                    'id': id
                };
                this.orderRuleParamViewModel.transTypeaheadList.push(obj);
            }
        }
    }
    private getResultantAttributeValue(item, value): any {
        const attributeValue = this.jbhGlobals.utils.get(item, value);
        if (attributeValue !== undefined && attributeValue !== null) {
            return attributeValue;
        } else {
            return '';
        }
    }
}
