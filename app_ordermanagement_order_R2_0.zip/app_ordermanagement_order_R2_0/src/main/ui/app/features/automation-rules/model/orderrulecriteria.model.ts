export class OrderRuleCriteria {
    orderRuleCriteriaCode: string;
    orderRuleCriteriaDescription: string;
}
