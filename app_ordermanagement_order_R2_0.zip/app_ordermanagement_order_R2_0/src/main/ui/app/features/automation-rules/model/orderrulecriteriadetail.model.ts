// import { OrderRuleCriteria } from './orderrulecriteria.model';

export class OrderRuleCriteriaDetail {
    orderRuleCriteriaDetailID: number = null;
    orderRuleCriteriaOperatorID: number = null;
    selectedCriteriaValue = '';
    orderRuleCriteriaOperator = '';
    orderRuleCriteriaValue = '';
    orderRuleCriteriaCode = '';
    orderRuleCriteriaDescription = '';
    expirationTimestamp = '';
    effectiveTimestamp = '';
    // orderRuleCriteria: OrderRuleCriteria = null;
}
