export class ViewRuleModel {
    selectedRule: any;
    orderRuleName: string;
    orderRuleDescription: string;
    startDate: string;
    associationLevel: string;
    isBusinessUnitLevelRules: boolean;
    isCustomerLevelRules: boolean;
    orderCreationChannel: string;
    orderRuleCriteriaDetail: any;
    orderRuleParameter: any;
    orderRuleDetailID: number;
    orderRuleCriteriaSetID: number;
    businessUnit: string;
    businessUnitServiceOffering: string;
    billTo: Object;

}
