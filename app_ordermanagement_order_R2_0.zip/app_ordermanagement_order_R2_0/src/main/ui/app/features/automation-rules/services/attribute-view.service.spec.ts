import { inject, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { APP_BASE_HREF } from '@angular/common';
import { AppModule } from 'app/app.module';
import { JBHGlobals } from '../../../app.service';
import { AutomationRulesModule } from '../automation-rules.module';

import { AttributeViewService } from './attribute-view.service';

describe('AttributeViewService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        AppModule,
        AutomationRulesModule
      ],
      providers: [{ provide: APP_BASE_HREF, useValue: '/' }, AttributeViewService, JBHGlobals]
    });
  });

  it('should be created', inject([AttributeViewService], (service: AttributeViewService) => {
    expect(service).toBeTruthy();
  }));
});
