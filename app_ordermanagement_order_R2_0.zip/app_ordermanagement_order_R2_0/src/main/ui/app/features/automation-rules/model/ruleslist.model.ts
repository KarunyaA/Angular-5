export class RulesListModel {
    rows: string[];
    selected: string[];
    totalRecordsCount: number;
    offset: number;
    limit: number;
    flag: number;
    rulesFilterTitle: string;
    serviceOfferings: string[];
    orderRuleCategories: string[];
    ruleMockData: any[];
    businessUnits: string[];
    orderRuleName: string;
    debounceValue: number;
    onLoading: boolean;
    onNoResults: boolean;
    rulesFilterList: any;
    subscribeFlag: boolean;
    associationLevel: string;

    constructor() {
        this.totalRecordsCount = 0;
        this.offset = 0;
        this.limit = 25;
        this.flag = 0;
        this.rulesFilterTitle = 'FILTER BY';
        this.subscribeFlag = true;
        this.selected = [];
        this.serviceOfferings = [];
        this.orderRuleCategories = [];
        this.ruleMockData = [];
        this.businessUnits = [];
        this.associationLevel = '';
    }
}
