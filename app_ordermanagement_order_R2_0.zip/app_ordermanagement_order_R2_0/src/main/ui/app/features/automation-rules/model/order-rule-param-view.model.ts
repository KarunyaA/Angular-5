import { IMyDate, IMyDateModel, IMyOptions } from 'mydatepicker';

export class OrderRuleParamViewModel {
    compType: string;
    comDTOType: string;
    typeaheadType: string;
    datas: any;
    compDesc: string;
    debounceValue: number;
    isValueSelected: boolean;
    selectedValue: string;
    subscribeFlag: boolean;
    selectedresultaneAttr: any;
    transTypeaheadList: any[];
    timeMeridian: boolean;
    datePickerOptions: IMyOptions;
    selEffDate: IMyDate;

    constructor() {
        this.isValueSelected = true;
        this.subscribeFlag =  true;
        this.timeMeridian = false;
        this.transTypeaheadList = [];
        this.datePickerOptions  = {
            todayBtnTxt: 'Today',
            dateFormat: 'mm-dd-yyyy',
            firstDayOfWeek: 'mo',
            showClearDateBtn: false,
            editableDateField: false,
            sunHighlight: true,
            height: '34px',
            inline: false,
            selectionTxtFontSize: '14px'
        };
        this.selEffDate = {
            year: 0,
            month: 0,
            day: 0
        };
    }
}
