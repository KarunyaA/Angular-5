import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Response } from '@angular/http';

import { JBHGlobals } from '../../../app.service';

@Injectable()
export class AutomationRulesService {

  constructor(private jbhGlobals: JBHGlobals) { }

  fetchData(url, params, flag): Observable < Response[] > {
    if (params === null) {
        return this.jbhGlobals.apiService.getData(url, flag);
    } else {
        return this.jbhGlobals.apiService.getData(url, params, flag);
    }
  }
  pushData(url, params): Observable < Response[] > {
      return this.jbhGlobals.apiService.patchData(url, params);
  }
  getShortcut(): Observable < Response[] > {
    return this.jbhGlobals.shortkeys.getData();
  }
  postData(commentsUrl, params): Observable < Response[] > {
    return this.jbhGlobals.apiService.addData(commentsUrl, params);
  }
  deleteData(url): Observable < Response[] > {
    return this.jbhGlobals.apiService.removeData(url);
  }
}
