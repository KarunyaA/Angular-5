import { Injectable } from '@angular/core';
import 'rxjs/add/operator/delay';

@Injectable()
export class RulesService {
    ruleDetails = {
        'orderRuleCriteriaSetID': null,
        'orderRuleDetailID': null,
        'orderRuleSupersedeTypeCode': null,
        'orderRuleName': '',
        'startDate': null,
        'orderRuleDescription': '',
        'associationLevel': '',
        'businessUnit': '',
        'businessUnitServiceOffering': '',
        'isBusinessUnitLevelRules': false,
        'isCustomerLevelRules': false,
        'ruleProcessCode': '',
        'billTo': {
            'line1': '',
            'line2': '',
            'line3': ''
        },
        'effectiveTimestamp': '',
        'expirationTimestamp': '',
        'mode': '',
        'resultantActions': [],
        'validationSet': [],
        'orderRuleCategoryDescription': '',
        'orderRuleCategoryCode': '',
        'billingPartyID': null
    };
    selectedCriteriaDetails = null;
    selectedAtrributeList: any = [];
}
