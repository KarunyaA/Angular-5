import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { ViewRuleModel } from '../../model/view-rule.model';
import { RulesService } from '../../rules.service';

@Component({
    selector: 'app-view-rule',
    templateUrl: './view-rule.component.html',
    styleUrls: ['./view-rule.component.scss']
})
export class ViewRuleComponent implements OnInit {
    viewRuleModel: ViewRuleModel;

    constructor(private ruleService: RulesService,
                private router: Router) { }

    ngOnInit(): void {
        this.viewRuleModel = new ViewRuleModel();
        this.viewRule();
    }
    onBack(): void {
        if (this.viewRuleModel.associationLevel === 'Customer') {
            this.router.navigate(['/customerrules'],
                { queryParams: { partyId: this.ruleService.ruleDetails.billingPartyID } });
        } else {
            this.router.navigateByUrl('/automationrules');
        }
    }
    bindValue(prm): string {
        let val = '';
        const type = prm.orderRuleParameterTypeDTO;
        const code = type.orderRuleParameterValueTypeCode;
        const num = prm.orderParameterNumberValue;
        const char = prm.orderParameterCharValue;
        const dt = prm.orderParameterDateValue;
        val = (code === 'Number') ? num : (code === 'Char' ? char : dt);
        return `${val} ${type.orderRuleParameterTypeDescription}`;
    }
    private viewRule(): void {
        const ruleDet = this.ruleService.ruleDetails;
        this.viewRuleModel.orderRuleDetailID = ruleDet.orderRuleDetailID;
        this.viewRuleModel.orderRuleCriteriaSetID = ruleDet.orderRuleCriteriaSetID;
        this.viewRuleModel.orderRuleName = ruleDet.orderRuleName;
        this.viewRuleModel.orderRuleDescription = ruleDet.orderRuleDescription;
        this.viewRuleModel.associationLevel = ruleDet.associationLevel;
        this.viewRuleModel.businessUnit = ruleDet.businessUnit;
        this.viewRuleModel.businessUnitServiceOffering = ruleDet.businessUnitServiceOffering;
        this.viewRuleModel.isBusinessUnitLevelRules = ruleDet.isBusinessUnitLevelRules;
        this.viewRuleModel.isCustomerLevelRules = ruleDet.isCustomerLevelRules;
        this.viewRuleModel.billTo = ruleDet.billTo;
        this.viewRuleModel.startDate = ruleDet.effectiveTimestamp;
        this.viewRuleModel.selectedRule = this.ruleService.selectedCriteriaDetails;
        if (this.viewRuleModel.selectedRule !== null) {
            this.viewRuleModel.businessUnit =  this.viewRuleModel.selectedRule.businessUnit;
            this.viewRuleModel.businessUnitServiceOffering =  this.viewRuleModel.selectedRule.businessUnitServiceOffering;
            // this.viewRuleModel.globalOverride =  this.viewRuleModel.selectedRule.globalOverride;
            this.viewRuleModel.orderCreationChannel = this.viewRuleModel.orderCreationChannel;
            this.viewRuleModel.orderRuleCriteriaDetail =  this.viewRuleModel.selectedRule.orderRuleCriteriaDetailDTO;
            this.viewRuleModel.orderRuleParameter =  this.viewRuleModel.selectedRule.orderRuleParameterDTO;
        }
    }
}
