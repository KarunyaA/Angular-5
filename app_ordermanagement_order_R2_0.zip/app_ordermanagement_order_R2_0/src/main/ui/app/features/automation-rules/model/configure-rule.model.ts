import { IMyDate, IMyDateModel, IMyOptions } from 'mydatepicker';
export class ConfigureRuleModel {
    isLoading: boolean;
    selectedRule: any;
    ruleForm: any;
    orderRuleDetailID: number;
    orderRuleCriteriaSetID: number;
    orderRuleName: string;
    orderRuleDescription: string;
    associationLevel: string;
    businessUnit: string;
    businessUnitServiceOffering: string;
    isBusinessUnitLevelRules: boolean;
    isCustomerLevelRules: boolean;
    billTo: Object;
    mode: string;
    title: string;
    attributesList: any;
    resultantActions: string[];
    orderRuleCriteriaList: any;
    channelList: string[];
    orderRuleParameterTypeList: any;
    validBUSOValues: string[];
    bindValidSOValues: string[];
    bindValidBUValues: string[];
    selectedParamType: string;
    orderRuleOperatorsList: any;
    isMulAllowed: boolean;
    attributeParams: any;
    orderRuleParamsList: any;
    pathVariable: string;
    focusFlag: number;
    effectiveDateFlag: boolean;
    expirationDateFlag: boolean;
    dateCompareFlag: boolean;
    timeCompareFlag: boolean;
    effTimeError: string;
    expTimeError: string;
    orderChannel: string;
    roleType: string;
    effectiveDate: number;
    expirationDate: number;
    effectiveTime: any;
    expirationTime: any;
    orderRuleCategoryDescription: string;
    soRadioCheck: boolean;
    buRadioCheck: boolean;
    startTimeMeridian: boolean;
    endTimeMeridian: boolean;
    datePickerOptions: IMyOptions;
    selEffDate: IMyDate;
    selExpDate: IMyDate;
    myEndTime: Date;
    myStartTime: Date;
    subscribeFlag: boolean;
    saveFlag: boolean;
    mandatoryAttr: string;
    autoUpdateCustomerRules: string[];
    ruleProcessCode: string;
    orderRuleCategoryCode: string;

    constructor() {
        this.datePickerOptions = {
            todayBtnTxt: 'Today',
            dateFormat: 'mm-dd-yyyy',
            firstDayOfWeek: 'mo',
            showClearDateBtn: false,
            editableDateField: false,
            sunHighlight: true,
            height: '34px',
            inline: false,
            selectionTxtFontSize: '14px'
        };
        this.selEffDate = {
            year: 0,
            month: 0,
            day: 0
        };
        this.selExpDate = {
            year: 0,
            month: 0,
            day: 0
        };
        this.myEndTime = new Date();
        this.myStartTime = new Date();
        this.isLoading = false;
        this.isMulAllowed = false;
        this.selectedParamType = '';
        this.focusFlag = 0;
        this.effectiveDateFlag = false;
        this.expirationDateFlag = false;
        this.dateCompareFlag = false;
        this.timeCompareFlag = false;
        this.effTimeError = 'Effective time';
        this.expTimeError = 'Expiration time';
        this.orderChannel = 'Order creation channel';
        this.startTimeMeridian = false;
        this.endTimeMeridian = false;
        this.resultantActions = [];
        this.orderRuleCriteriaList = [];
        this.channelList = [];
        this.validBUSOValues = [];
        this.bindValidSOValues = [];
        this.bindValidBUValues = [];
        this.subscribeFlag = true;
        this.autoUpdateCustomerRules = ['Accept UCR, Do not Update Order, if Order is already updated manually',
            'Process Electronic Updates', 'Process Appointment Change for Scheduled Pickup Appointment Date and Time',
            'Process Appointment Change for Scheduled Delivery Appointment Date and Time', 'Process Trailer Number with Appointment Change',
            'Process Weight and Pieces with Appointment Change', 'Bypass Transit Time Check'
        ];
    }
}
