import { Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Headers, RequestOptions } from '@angular/http';

import * as moment from 'moment';
import { JBHGlobals } from '../../../app.service';
import { UserService } from 'jbh-components/jbh-esa';

import { RulesService } from '../rules.service';
import { AutomationRulesService } from './../services/automation-rules.service';
import { ConfiguredRuleListService } from '../services/configured-rule-list.service';
import { ConfiguredRuleListModel } from '../model/configuredrulelist.model';

@Component({
    selector: 'app-configured-rules-list',
    templateUrl: './configured-rules-list.component.html',
    styleUrls: ['./configured-rules-list.component.scss'],
    providers: [ConfiguredRuleListService, AutomationRulesService]
})
export class ConfiguredRulesListComponent implements OnInit, OnDestroy {
    typeaheadModule: FormGroup;
    configuredRuleListModel: ConfiguredRuleListModel;
    @ViewChild('formSectionKey') formSectionKey: ElementRef;
    @ViewChild('gridSectionKey') gridSectionKey: ElementRef;
    @ViewChild('exportExcel') exportExcel: ElementRef;
    @ViewChild('callValue') callValue: ElementRef;

    constructor(
        private router: Router, private route: ActivatedRoute,
        private jbhGlobals: JBHGlobals, private rulesService: RulesService,
        private automationRulesService: AutomationRulesService,
        private fb: FormBuilder, private configuredRuleListService: ConfiguredRuleListService,
        private userService: UserService) { }

    ngOnInit(): void {
        this.configuredRuleListModel = new ConfiguredRuleListModel();
        this.configuredRuleListService.initializeVariables(this);
        this.configuredRuleListService.setUpKeyboardShortcuts(this);
        this.configuredRuleListModel.accountId = this.route.queryParams['value']['partyId'];
        this.loadCustomerRule();
        this.page(this.configuredRuleListModel.offset, this.configuredRuleListModel.limit);
        this.configuredRuleListModel.filterList[0]['myParentScope'] = this;
        this.configuredRuleListModel.filterList[1]['myParentScope'] = this;
        this.typeaheadModule = this.fb.group({
            searchRuleName: ['', Validators.required]
        });
        this.searchTypeaheadLoad();
        this.loadFilter();
    }
    ngOnDestroy(): void {
        this.configuredRuleListModel.subscribeFlag = false;
    }
    onTypeAheadSearchFilterCall(eve): void {
        if (this.configuredRuleListModel.rulesFilterList[eve.num]['serviceFilter']) {
            const typedText = eve.val;
            const el = this.configuredRuleListModel.rulesFilterList[eve.num];
            const url = this.configuredRuleListModel.rulesFilterList[eve.num]['url'];
            const param = this.configuredRuleListService.paramFramer(eve, typedText, this.configuredRuleListModel.rulesFilterList);
            if (typedText.length > 2 && this.configuredRuleListModel.rulesFilterList[eve.num]['url']) {
                this.configuredRuleListService.searchTypeAheadData(this, url, param, eve, el);
            } else if (typedText === '') {
                this.configuredRuleListService.searchTypeAheadData(this, url, param, eve, el);
            }
        }
    }
    onMenuClickEvent(selectedVal): void {
        if (selectedVal === 'configurenewrule') {
            this.rulesService.ruleDetails = {
                'orderRuleCriteriaSetID': null,
                'orderRuleDetailID': null,
                'orderRuleSupersedeTypeCode': null,
                'orderRuleName': '',
                'startDate': null,
                'orderRuleDescription': '',
                'associationLevel': '',
                'businessUnit': '',
                'businessUnitServiceOffering': '',
                'ruleProcessCode': '',
                'isBusinessUnitLevelRules': this.configuredRuleListModel.isBusinessUnitLevelRules,
                'isCustomerLevelRules': this.configuredRuleListModel.isCustomerLevelRules,
                'billTo': this.configuredRuleListModel.billTo,
                'effectiveTimestamp': '',
                'expirationTimestamp': '',
                'mode': 'new',
                'resultantActions': [],
                'validationSet': [],
                'orderRuleCategoryDescription': '',
                'orderRuleCategoryCode': '',
                'billingPartyID': this.configuredRuleListModel.accountId
            };
            this.rulesService.selectedCriteriaDetails = null;
            if (this.configuredRuleListModel.isBusinessUnitLevelRules) {
                this.router.navigateByUrl('/automationrules/rules');
            } else {
                this.router.navigateByUrl('/customerrules/rules');
            }
        } else if (selectedVal === 'exporttoexcel') {
            const filename = 'ExportedExcel.csv';
            this.exportExcel.nativeElement.href = this.jbhGlobals.endpoints.automationrules.exportRule;
            this.exportExcel.nativeElement.download = filename;
        }
    }
    onRulesListMenuClick(event, pop, row, mode?: any): void {
        const currEle = event.srcElement.id;
        pop.hide();
        this.rulesService.ruleDetails = {
            'orderRuleCriteriaSetID': row.orderRuleCriteriaSets[0].orderRuleCriteriaSetID,
            'orderRuleDetailID': row.orderRuleDetailId,
            'orderRuleSupersedeTypeCode': row.orderRuleCriteriaSets[0].orderRuleSupersedeTypeCode,
            'orderRuleName': row.ruleName,
            'startDate': row.startDate,
            'orderRuleDescription': row.ruleDescription,
            'associationLevel': row.associationLevel,
            'businessUnit': row.orderRuleCriteriaSets[0].businessUnit,
            'businessUnitServiceOffering': row.orderRuleCriteriaSets[0].businessUnitServiceOffering,
            'ruleProcessCode': row.orderRuleProcessCode,
            'isBusinessUnitLevelRules': this.configuredRuleListModel.isBusinessUnitLevelRules,
            'isCustomerLevelRules': this.configuredRuleListModel.isCustomerLevelRules,
            'billTo': this.configuredRuleListModel.billTo,
            'effectiveTimestamp': row.orderRuleCriteriaSets[0].startDate,
            'expirationTimestamp': row.orderRuleCriteriaSets[0].endDate,
            'mode': mode,
            'resultantActions': [],
            'validationSet': row.validationSet,
            'orderRuleCategoryDescription': row.ruleCategoryDescription,
            'orderRuleCategoryCode': row.ruleCategory,
            'billingPartyID': this.configuredRuleListModel.accountId
        };
        switch (currEle) {
            case 'copyrule':
                this.configuredRuleListService.onViewEditRule(this, 'edit');
                break;
            case 'inactivaterule':
                this.configuredRuleListService.onRukeInactivate(this, row);
                break;
            case 'viewrule':
                this.configuredRuleListService.onViewEditRule(this, 'view');
                break;
            case 'vieweditrule':
                this.configuredRuleListService.onViewEditRule(this, 'edit');
                break;
            default:
                break;
        }
    }
    onPage(event): void {
        this.configuredRuleListModel.offset = event.offset;
        this.configuredRuleListModel.limit = event.limit;
        this.page(this.configuredRuleListModel.offset, this.configuredRuleListModel.limit);
    }
    onActivate(event): void {
        this.configuredRuleListModel.selected.splice(0, this.configuredRuleListModel.selected.length);
        this.configuredRuleListModel.selected.push(event.row);
    }
    onAdditionalSearch(): void {
        this.configuredRuleListModel.flag = (this.configuredRuleListModel.flag === 0) ? 1 : 0;
    }
    onShowPopOver(row): boolean {
        return (row.orderRuleCriteriaSets[0].status === 'Active') ? true : false;
    }
    onChangeEvent(e): void {
        this.configuredRuleListModel.orderRuleName = this.typeaheadModule.controls.searchRuleName.value;
        this.configuredRuleListModel.offset = 0;
        const isChk = e.data.checked;
        const fVal = e.data.fullVal;
        const filterIndex = this.jbhGlobals.utils.indexOf(this.configuredRuleListModel.rulesFilterList,
            this.jbhGlobals.utils.find(this.configuredRuleListModel.rulesFilterList, { 'index': e.num }));
        if (isChk === true) {
            switch (e.num) {
                case 0:
                    const bu = fVal.financeBusinessUnitCode;
                    const so = fVal.serviceOfferingCode;
                    if (so !== 'All') {
                        this.configuredRuleListModel.serviceOfferings.push(`${bu}-${so}`);
                    }
                    this.configuredRuleListModel.businessUnit.push(bu);
                    this.configuredRuleListModel.rulesFilterList[filterIndex]['count'] = e.count;
                    break;
                case 1:
                    this.configuredRuleListModel.billingPartyId.push(fVal.PartyID);
                    this.configuredRuleListModel.rulesFilterList[filterIndex]['count'] = e.count;
                    break;
                case 2:
                    this.configuredRuleListModel.associationLevels.push(fVal.orderRuleTypeCode);
                    this.configuredRuleListModel.rulesFilterList[filterIndex]['count'] = e.count;
                    break;
                case 3:
                    this.configuredRuleListModel.orderRuleCategories.push(fVal.orderRuleCategoryCode);
                    this.configuredRuleListModel.rulesFilterList[filterIndex]['count'] = e.count;
                    break;
                case 4:
                    this.configuredRuleListModel.globalOverrideFlags.push((fVal.code === 'true') ? 'Suprsed' : 'NotSuprsed');
                    if (this.configuredRuleListModel.globalOverrideFlags.length > 1) {
                        this.configuredRuleListModel.globalOverrideFlags = [];
                    }
                    this.configuredRuleListModel.rulesFilterList[filterIndex]['count'] = e.count;
                    break;
                case 7:
                    this.configuredRuleListModel.activeFlags.push(fVal.code);
                    this.configuredRuleListModel.rulesFilterList[filterIndex]['count'] = e.count;
                    break;
                default:
                    break;
            }
        } else {
            switch (e.num) {
                case 0:
                    const bu = fVal.financeBusinessUnitCode;
                    const so = fVal.serviceOfferingCode;
                    const businessElementIndex = this.configuredRuleListModel.businessUnit.indexOf(bu);
                    this.configuredRuleListModel.businessUnit.splice(businessElementIndex, 1);
                    const serviceElementIndex = this.configuredRuleListModel.serviceOfferings.indexOf(`${bu}-${so}`);
                    this.configuredRuleListModel.serviceOfferings.splice(serviceElementIndex, 1);
                    this.configuredRuleListModel.rulesFilterList[filterIndex]['count'] = e.count;
                    break;
                case 1:
                    const billingPartyIDElementIndex = this.configuredRuleListModel.billingPartyId.indexOf(fVal.PartyID);
                    this.configuredRuleListModel.billingPartyId.splice(billingPartyIDElementIndex, 1);
                    this.configuredRuleListModel.rulesFilterList[filterIndex]['count'] = e.count;
                    break;
                case 2:
                    const associationElementIndex = this.configuredRuleListModel.associationLevels.indexOf(fVal.orderRuleTypeCode);
                    this.configuredRuleListModel.associationLevels.splice(associationElementIndex, 1);
                    this.configuredRuleListModel.rulesFilterList[filterIndex]['count'] = e.count;
                    break;
                case 3:
                    const orderRuleElementIndex = this.configuredRuleListModel.orderRuleCategories.indexOf(fVal.orderRuleCategoryCode);
                    this.configuredRuleListModel.orderRuleCategories.splice(orderRuleElementIndex, 1);
                    this.configuredRuleListModel.rulesFilterList[filterIndex]['count'] = e.count;
                    break;
                case 4:
                    let globalOverrideIndex = -1;
                    if (fVal.code === 'true') {
                        globalOverrideIndex = this.configuredRuleListModel.globalOverrideFlags.indexOf('Suprsed');
                    } else {
                        globalOverrideIndex = this.configuredRuleListModel.globalOverrideFlags.indexOf('NotSuprsed');
                    }
                    this.configuredRuleListModel.globalOverrideFlags.splice(globalOverrideIndex, 1);
                    this.configuredRuleListModel.rulesFilterList[filterIndex]['count'] = e.count;
                    break;
                case 7:
                    const orderStatusElementIndex = this.configuredRuleListModel.activeFlags.indexOf(fVal.code);
                    this.configuredRuleListModel.activeFlags.splice(orderStatusElementIndex, 1);
                    this.configuredRuleListModel.rulesFilterList[filterIndex]['count'] = e.count;
                    break;
                default:
                    break;
            }
        }
        this.configuredRuleListService.loadGridData(this);
    }
    onDateChange(event): void {
        switch (event.num) {
            case 5:
                this.setDateFilterValue(event, 'effectiveStartDate', 'effectiveEndDate');
                break;
            case 6:
                this.setDateFilterValue(event, 'expirationStartDate', 'expirationEndDate');
                break;
            default:
                break;
        }
    }
    onClickReset(index): void {
        const filterIndex = this.jbhGlobals.utils.indexOf(this.configuredRuleListModel.rulesFilterList,
            this.jbhGlobals.utils.find(this.configuredRuleListModel.rulesFilterList, { 'index': index }));
        switch (index) {
            case 0:
                this.configuredRuleListModel.serviceOfferings = [];
                this.configuredRuleListModel.businessUnit = [];
                this.configuredRuleListModel.rulesFilterList[filterIndex]['count'] = 0;
                break;
            case 1:
                this.configuredRuleListModel.billingPartyId = [];
                this.configuredRuleListModel.rulesFilterList[filterIndex]['count'] = 0;
                break;
            case 2:
                this.configuredRuleListModel.associationLevels = [];
                this.configuredRuleListModel.rulesFilterList[filterIndex]['count'] = 0;
                break;
            case 3:
                this.configuredRuleListModel.orderRuleCategories = [];
                this.configuredRuleListModel.rulesFilterList[filterIndex]['count'] = 0;
                break;
            case 4:
                this.configuredRuleListModel.globalOverrideFlags = [];
                this.configuredRuleListModel.rulesFilterList[filterIndex]['count'] = 0;
                break;
            case 5:
                this.configuredRuleListModel.effectiveStartDate = '';
                this.configuredRuleListModel.effectiveEndDate = '';
                break;
            case 6:
                this.configuredRuleListModel.expirationStartDate = '';
                this.configuredRuleListModel.expirationEndDate = '';
                break;
            case 7:
                this.configuredRuleListModel.activeFlags = [];
                this.configuredRuleListModel.rulesFilterList[filterIndex]['count'] = 0;
                break;
            default:
                break;
        }
        this.configuredRuleListService.loadGridData(this);
    }
    onRuleSelect(e): void {
        this.configuredRuleListModel.orderRuleName = e.value;
        this.configuredRuleListModel.offset = 0;
        this.configuredRuleListService.loadGridData(this);
    }
    onRuleLoading(e: boolean): void {
        this.configuredRuleListModel.onLoading = e;
        this.configuredRuleListModel.onNoResults = false;
    }
    onRuleNoResults(e: boolean): void {
        this.configuredRuleListModel.onNoResults = e;
    }
    objectFramer(data): any {
        const obj = {};
        obj['val'] = `${data['_source']['OrganizationName']}(${data['_source']['PartyID']})`;
        obj['fullVal'] = data['_source'];
        return obj;
    }
    appendBUSO(val): any {
        return this.configuredRuleListService.getBUSOData(this, val);
    }
    hasAccess(operation: string): boolean {
        const url = (this.router.url.indexOf('/automationrules') !== -1) ?
            this.jbhGlobals.routeUrls.automationrules : this.jbhGlobals.routeUrls.customerrules;
        let status = false;
        status = this.userService.hasAccess(url, operation);
        return status;
    }
    headerIconClick(e): void {
        location.href = '/order/rules/account/dashboard';
    }
    formatDate(dt): any {
        return (dt !== null && dt !== '' && dt !== undefined) ? new Date(dt) : '';
    }
    soFramer(data: Object): Object {
        const obj = {};
        if (data) {
            obj['val'] = `${data['financeBusinessUnitCode']}-${data['serviceOfferingCode']}`;
            obj['fullVal'] = data;
            return obj;
        }
    }
    private searchTypeaheadLoad(): void {
        this.configuredRuleListModel.debounceValue = this.jbhGlobals.settings.debounce;
        this.typeaheadModule['controls']['searchRuleName']['valueChanges']
            .debounceTime(this.configuredRuleListModel.debounceValue)
            .distinctUntilChanged()
            .subscribe((value) => {
                if (!this.jbhGlobals.utils.isEmpty(value) && value !== undefined) {
                    this.configuredRuleListModel.orderRuleName = value;
                    this.configuredRuleListService.getRuleName(this, value);
                } else if (value.length === 0) {
                    this.configuredRuleListModel.ruleMockData = [];
                    this.configuredRuleListModel.orderRuleName = '';
                    this.configuredRuleListModel.onNoResults = false;
                    this.configuredRuleListService.loadGridData(this);
                }
            }, (err: Error) => { });
    }
    private loadCustomerRule(): void {
        if (this.router.url.indexOf('/automationrules') !== -1) {
            this.configuredRuleListModel.isBusinessUnitLevelRules = true;
            this.configuredRuleListModel.isCustomerLevelRules = false;
        } else {
            this.configuredRuleListModel.isBusinessUnitLevelRules = false;
            this.configuredRuleListModel.isCustomerLevelRules = true;
            this.configuredRuleListService.loadBillTo(this, this.configuredRuleListModel.accountId);
            this.configuredRuleListModel.billingPartyId.push(this.configuredRuleListModel.accountId);
        }
    }
    private loadFilter(): void {
        for (let i = 0; i < this.configuredRuleListModel.filterList.length; i++) {
            if (this.configuredRuleListModel.filterList[i].ruleCategory === 'common' ||
                this.configuredRuleListModel.filterList[i].ruleCategory ===
                ((this.configuredRuleListModel.isBusinessUnitLevelRules) ? 'buLevel' : 'customerLevel')) {
                this.configuredRuleListModel.rulesFilterList.push(this.configuredRuleListModel.filterList[i])
            }
        }
    }
    private page(offset, limit): void {
        this.configuredRuleListService.loadGridData(this, {
            'page': offset, 'size': limit
        });
    }
    private setDateFilterValue(e, startDate, endDate): void {
        const filterDate = moment(new Date(e.jsdate)).format('YYYY-MM-DD');
        (e.types === 'from') ? this.configuredRuleListModel[startDate] = filterDate :
            this.configuredRuleListModel[endDate] = filterDate;
        if (this.configuredRuleListModel[startDate] && this.configuredRuleListModel[endDate]) {
            this.configuredRuleListService.loadGridData(this);
        }
    }
}
