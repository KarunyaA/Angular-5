import { Injectable } from '@angular/core';

@Injectable()
export class RulesListService {

  constructor() { }
  InitializeFilter(rulesListComponent): void {
    rulesListComponent.rulesListModel.rulesFilterList = [
      {
        'key': 'serviceOfferingCode',
        'index': 0,
        'title': 'Service Offering',
        'componentType': 'lsitType',
        'rootVal': ['_embedded', 'financeBusinessUnitServiceOfferingAssociations'],
        'params': {},
        'deepNestFlag': false,
        'framerMethod': 'soFramer',
        'url': rulesListComponent.jbhGlobals.endpoints.automationrules.getBuSO,
        'count': 0,
        'ruleCategory': 'common'
      }, {
        'index': 1,
        'key': 'ruleCategory',
        'title': 'Rule Category',
        'checkSelectionKey': 'orderRuleCategoryDescription',
        'rootVal': ['_embedded', 'orderRuleCategories'],
        'componentType': 'lsitType',
        'url': rulesListComponent.jbhGlobals.endpoints.automationrules.getRulesCategory,
        'params': {},
        'count': 0
      }];
  }
}
