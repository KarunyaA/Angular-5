import { inject, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { APP_BASE_HREF } from '@angular/common';
import { AppModule } from 'app/app.module';
import { JBHGlobals } from '../../../app.service';
import { AutomationRulesModule } from '../automation-rules.module';

import { ConfigureRuleHelperService } from './configure-rule-helper.service';

describe('ConfigureRuleHelperService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        AppModule,
        AutomationRulesModule
      ],
      providers: [{ provide: APP_BASE_HREF, useValue: '/' }, ConfigureRuleHelperService, JBHGlobals]
    });
  });

  it('should be created', inject([ConfigureRuleHelperService], (service: ConfigureRuleHelperService) => {
    expect(service).toBeTruthy();
  }));
});
