export class OrderRuleLogicalOperator {
    orderRuleLogicalOperatorCode: string;
    orderRuleLogicalOperatorDescription: string;
}
