import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { SelectModule } from 'jbh-components/select';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { IMyOptions, MyDatePickerModule } from 'mydatepicker';
import { ModalModule, PopoverModule } from 'ngx-bootstrap';

import { TypeaheadModule } from 'jbh-components/jbh-typeahead';
import { JbhValidationModule } from 'jbh-components';
import { ConfirmationPopupModule } from 'jbh-components/confirmation-popup/confirmation-popup.module';
import { FileUploadModule } from 'ng2-file-upload';
import { UploadFileComponent } from '../create-change-request/upload-file/upload-file.component';
import { ChangeRequestFormBuilderService } from '../services/change-request-form-builder.service';

import { CreateChangeRequestRoutingModule } from './create-change-request-routing.module';
import { ContactChangeRequestComponent } from './contact-change-request/contact-change-request.component';
import { AddressChangeRequestComponent } from './address-change-request/address-change-request.component';
import { ServiceChangeRequestComponent } from './service-change-request/service-change-request.component';
import { OverageReportingRequestComponent } from './overage-reporting-request/overage-reporting-request.component';
import { ShortageReportingRequestComponent } from './shortage-reporting-request/shortage-reporting-request.component';
import { DamageRequestComponent } from './damage-request/damage-request.component';
import { PickupRequestComponent } from './pickup-request/pickup-request.component';
import { CreateTypeaheadQueryService } from './services/create-typeahead-query.service';
import { OverageItemDetailsComponent } from './overage-reporting-request/overage-item-details/overage-item-details.component';
import { ShortageItemDetailsComponent } from './shortage-reporting-request/shortage-item-details/shortage-item-details.component';
import { DamageItemDetailsComponent } from './damage-request/damage-item-details/damage-item-details.component';
import { CreateChangeRequestService } from './services/create-change-request.service';
import { PickupItemDetailsComponent } from './pickup-request/pickup-item-details/pickup-item-details.component';
import { CreateChangeRequestComponent } from '../create-change-request/create-change-request.component';

@NgModule({
  imports: [
    CommonModule,
    CreateChangeRequestRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    BsDropdownModule,
    ModalModule,
    SelectModule,
    MyDatePickerModule,
    PopoverModule,
    FileUploadModule,
    TypeaheadModule.forRoot(),
    ConfirmationPopupModule,
    JbhValidationModule
  ],
  declarations: [ContactChangeRequestComponent,
    AddressChangeRequestComponent,
    ServiceChangeRequestComponent,
    OverageReportingRequestComponent,
    ShortageReportingRequestComponent,
    DamageRequestComponent,
    UploadFileComponent,
    PickupRequestComponent,
    OverageItemDetailsComponent,
    CreateChangeRequestComponent,
    ShortageItemDetailsComponent,
    DamageItemDetailsComponent,
    PickupItemDetailsComponent],
  providers: [ChangeRequestFormBuilderService, CreateTypeaheadQueryService, CreateChangeRequestService],
  exports: [ContactChangeRequestComponent,
    AddressChangeRequestComponent,
    ServiceChangeRequestComponent,
    OverageReportingRequestComponent,
    ShortageReportingRequestComponent,
    CreateChangeRequestComponent,
    DamageRequestComponent,
    UploadFileComponent,
    PickupRequestComponent]
})
export class CreateChangeRequestModule { }
