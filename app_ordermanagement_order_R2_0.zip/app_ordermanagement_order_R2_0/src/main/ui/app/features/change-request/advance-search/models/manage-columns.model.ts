export class ManageColumnsModel {
    minimumNoOfColumns: number;
    visibleProperty: string;
    selectedColumn: string;
}