import { TestBed, inject } from '@angular/core/testing';

import { ContactChangeService } from './contact-change.service';

describe('ContactChangeService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ContactChangeService]
    });
  });

  it('should be created', inject([ContactChangeService], (service: ContactChangeService) => {
    expect(service).toBeTruthy();
  }));
});
