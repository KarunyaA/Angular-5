import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Response } from '@angular/http';

import { JBHGlobals } from '../../../../app.service';

@Injectable()
export class AdvanceSearchService {

  constructor(private jbhGlobals: JBHGlobals) { }

  getTransitGridRecords(url, param): Observable<Response[]> {
    return this.jbhGlobals.apiService.addData(url, param);
  }

  getCRdata(id): Observable<Response[]> {
    const url = this.jbhGlobals.endpoints.changerequest.getViewCRData + '/' + id;
//    const url = this.jbhGlobals.endpoints.changerequest.getViewCRData + '/' + '143';
    return this.jbhGlobals.apiService.getData(url);
  }

  getChangeRequestService(endpoint: string): Observable<Response[]> {
    return this.jbhGlobals.apiService.getData(endpoint);
  }

  getChangeRequestStatusService(endpoint: string): Observable<Response[]> {
    return this.jbhGlobals.apiService.getData(endpoint);
  }

  getReferenceNumbers(url, param): Observable<Response[]> {
    return this.jbhGlobals.apiService.getData(url, param);
  }

  onCurrentTypeaheadKeyup(value: string, subscribeFlag: boolean, model): void {
    const currentCustomerData = [];
    const params = this.getCurrentCustomer(value);
    this.currentCustomerService(params).takeWhile(() => subscribeFlag)
      .subscribe(data => {
        if (data && data['hits'] && data['hits']['hits'] && data['hits']['hits'].length > 0) {
          this.jbhGlobals.utils.map(data['hits']['hits'], (items) => {
            const obj = {};
            const source = items['_source']['Address'];
            obj['searchkey'] = source['AddressLine1'] + ' ' + source['AddressLine2'] + ', ' +
              source['CityName'] + ', ' + source['StateName'] + ', ' + source['PostalCode'] + ', ' +
              source['CountryName'] + ', ' + items['_source']['OrganizationName'] +
              ' (' + ((items['_source']['CustomerCode']) ? items['_source']['CustomerCode'] : '') + ')';
            obj['partyID'] = items['_source']['PartyID'];
            obj['orgName'] = items['_source']['OrganizationName'];
            obj['addressDTO'] = items['_source']['Address'];
            currentCustomerData.push(obj);
          });
          model.currentCustomerList = currentCustomerData;
        } else {
          model.currentCustomerList = [];
          model.currentCustomerList.push({});
        }
      });
  }

  currentCustomerService(params: Object): Observable<Response[]> {
    const url = this.jbhGlobals.endpoints.changerequest.currentCustomer;
    return this.jbhGlobals.apiService.addData(url, params);
  }

  onCurrentLDCKeyup(value: string, subscribeFlag: boolean, model): void {
    const currentLDCData = []
    const params = this.getCurrentLDC(value);
    this.getCurrentLDCData(params).takeWhile(() => subscribeFlag)
      .subscribe(data => {
        if (data && data['hits'] && data['hits']['hits'] && data['hits']['hits'].length > 0) {
          this.jbhGlobals.utils.map(data['hits']['hits'], (items) => {
            const obj = {};
            const address = items['_source']['Address'];
            obj['searchkey'] = address['AddressLine1']  + ', ' + address['CityName'] + ', ' +
              address['StateName']  + ', ' + address['CountryName'] + ' ' + address['PostalCode'] +
               '- ' + items['_source']['LocationName'];
            obj['partyID'] = items['_source']['LocationID'];
            obj['orgName'] = items['_source']['LocationName'];
            currentLDCData.push(obj);
          });
          model.currentLDCList = currentLDCData;
        } else {
          model.currentLDCList = [];
          model.currentLDCList.push({});
        }
      });
  }

  getCurrentLDCData(params: Object): Observable<Response[]> {
    const url = this.jbhGlobals.endpoints.changerequest.currentLDC;
    return this.jbhGlobals.apiService.addData(url, params);
  }

  getTeamID(endpoint: string): Observable<Response[]> {
    return this.jbhGlobals.apiService.getData(endpoint);
  }

  getCurrentCustomer(value): Object {
    const params = {
      'size': 5,
      '_source': [
        'OrganizationName',
        'PartyID',
        'CustomerCode',
        'Address.AddressLine1',
        'Address.AddressLine2',
        'Address.CityName',
        'Address.StateName',
        'Address.CountryName',
        'Address.PostalCode',
        'ExpirationTimestamp',
        'OrganizationStatusTypeCode'
      ],
      'query': {
        'bool': {
          'should': [
            {
              'query_string': {
                'fields': [
                  'OrganizationName^6',
                  'CustomerCode^3',
                  'Address.AddressLine1^18',
                  'Address.AddressLine2^18',
                  'Address.CityName^15',
                  'Address.StateName^12',
                  'Address.PostalCode^9',
                  'Address.CountryName',
                  'OrganizationName'
                ],
                'query': value + '*',
                'default_operator': 'and'
              }
            }
          ],
          'minimum_should_match': 1,
          'must': [
            {
              'query_string': {
                'default_field': 'OrganizationStatusTypeCode.keyword',
                'query': 'Approved'
              }
            },
            {
              'nested': {
                'path': 'partyroles',
                'query': {
                  'match': {
                    'partyroles.PartyRoleTypeDescription.keyword': 'Bill To'
                  }
                },
                'inner_hits': {
                  'size': 1,
                  '_source': {
                    'includes': [
                      'partyroles.PartyRoleTypeDescription'
                    ]
                  }
                }
              }
            }
          ]
        }
      }
    }
    return params;
  }

  getCurrentLDC(value): Object {
    const params = {
      '_source': [
        'LocationName',
        'LocationCode',
        'LocationID',
        'Address.AddressLine1',
        'Address.AddressLine2',
        'Address.CityName',
        'Address.StateName',
        'Address.CountryName',
        'Address.PostalCode'
      ],
        'size': 6,
          'from': 0,
            'query': {
        'bool': {
          'must': [
            {
              'query_string': {
                'fields': [
                  'LocationName',
                  'LocationCode',
                  'LocationID',
                  'Address.AddressLine1',
                  'Address.AddressLine2',
                  'Address.CityName',
                  'Address.StateName',
                  'Address.CountryName',
                  'Address.PostalCode'
                ],
                'query': value + '*',
                'default_operator': 'AND',
                'analyze_wildcard': true
              }
            },
            {
              'nested': {
                'path': 'locationtypes',
                'query': {
                  'query_string': {
                    'default_field': 'locationtypes.LocationSubTypeDescription.keyword',
                    'query': 'Local Distribution Center',
                    'split_on_whitespace':false
                  }
                }
              }
            }
          ]
        }
      }
    }
    return params;
  }
  getSavedSearches(endpoint: string, queryParamDTO: any, isLoaderRequired: boolean): Observable<Response[]> {
    return this.jbhGlobals.apiService.getData(endpoint, queryParamDTO, isLoaderRequired);
  }
  postSavedSearch(endpoint: string, queryParamDTO: any): Observable<Response[]> {
    return this.jbhGlobals.apiService.addData(endpoint, queryParamDTO);
  }

  initializeModel(advanceSearchModel) {
    advanceSearchModel.returnAuthorizationList = [];
    advanceSearchModel.referenceList = [];
    advanceSearchModel.queryParamDTO = {
      'query': {
        'constant_score': {
          'filter': {
            'bool': {
              'must': []
            }
          }
        }
      },
    'sort': {
    'lastUpdateTimestamp': 'desc'
  },
      'size': advanceSearchModel.pageLimit,
      'from': advanceSearchModel.pageSize
    };
    advanceSearchModel.filterList = [{
      'index': 0,
      'title': 'newSearch',
      'key': '',
      'componentType': 'typeahead',
      'checkSelectionKey': '',
      'serviceFilter': true,
      'params': {}
    }, {
      'index': 1,
      'title': 'Account',
      'key': '',
      'componentType': 'typeahead',
      'checkSelectionKey': 'billingPartyID',
      'serviceFilter': true,
      'params': {}
    }, {
      'index': 2,
      'title': 'LDC',
      'key': '',
      'componentType': 'typeahead',
      'checkSelectionKey': 'distributionFacilityProfileID',
      'serviceFilter': true,
      'params': {}
    }, {
      'index': 3,
      'title': 'PRN',
      'key': '',
      'componentType': 'typeahead',
      'checkSelectionKey': 'shipmentIdentificationNumber',
      'serviceFilter': true,
      'params': {}
    }, {
      'index': 4,
      'title': 'RAN',
      'key': '',
      'componentType': 'typeahead',
      'checkSelectionKey': 'returnAuthorizationNumber',
      'serviceFilter': true,
      'params': {}
    }, {
      'index': 5,
      'title': 'TeamID',
      'key': '',
      'componentType': 'select',
      'checkSelectionKey': 'teamId',
      'serviceFilter': true,
      'params': {}
    }, {
      'index': 6,
      'title': 'TaskAssignment',
      'key': '',
      'componentType': 'select',
      'checkSelectionKey': 'taskId',
      'serviceFilter': true,
      'params': {}
    }, {
      'index': 7,
      'title': 'ChangeRequestStatus',
      'key': '',
      'componentType': 'select',
      'checkSelectionKey': 'changeRequestStatusCode',
      'serviceFilter': true,
      'params': {}
    }, {
      'index': 8,
      'title': 'Date',
      'key': '',
      'componentType': 'range',
      'checkSelectionKey': 'createTimestamp',
      'serviceFilter': true,
      'params': {}
    }]
  }
  getHardCodedModel(jsonProp: string): any {
    let output = [];
    const hardCodedModelJSON = {
      'hardCodedCustomFavorites': [{ 'userSearchName': 'Add to Favorites' },
      { 'userSearchName': 'Manage Favorites' }]
    };
    output = hardCodedModelJSON[jsonProp] || [];
    return output;
  }
  getStaticGridColumnsJSON(): any {
    return {
      'gridColumns': [{
        name: 'Customer',
        prop: 'customerDTO',
        flexGrow: 2,
        isVisible: true
      },
      {
        name: 'Local Distribution Center',
        prop: 'ldcAddressDTO',
        flexGrow: 2,
        isVisible: true
      },
      {
        name: 'Request Type',
        prop: 'changeRequestTypeDescription',
        flexGrow: 2,
        isVisible: true
      },
      {
        name: 'Primary Reference Number',
        prop: 'shipmentIdentificationNumber',
        flexGrow: 2,
        isVisible: true
      },
      {
        name: 'Change Request Status',
        prop: 'changeRequestStatusDescription',
        flexGrow: 2,
        isVisible: true
      }
//      {
//        name: 'Bill Party ID',
//        prop: 'billingPartyID',
//        flexGrow: 2,
//        isVisible: true
//      }
      ]

    };
  }
}
