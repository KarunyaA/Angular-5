import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Response } from '@angular/http';

import { JBHGlobals } from '../../../../app.service';

@Injectable()
export class SavedSearchService {
  constructor(private jbhGlobals: JBHGlobals) { }

  revomeSavedSearch(endpoint, queryParam): Observable<Response[]> {
    return this.jbhGlobals.apiService.removeData(endpoint, queryParam);
  }

}
