export class AddressChangeModel {
    addressStateList: Array<Object>;
    addressCountryList: Array<Object>;
    getCityCodeList: Array<Object>;
    getPostalCodeList: Array<Object>;
    getAddressCodeList: Array<Object>;
    customerList: Array<Object>;
    customerLDCList: Array<Object>;
    consumerList: Array<Object>;
    addressDetails: boolean;
    subscribeFlag: boolean;
    addressFlag: boolean;
    addAddressFlag: boolean;
    addressType: boolean;
    distributionFlag: boolean;
    distributionList: Array<Object>;
    addressRecongFlag: boolean;
    addressForm: boolean;
    typeDistributionFlag: boolean;
    getLdcAddressList: Array<Object>;
    newAddressDTO: any;
    mandatoryFlag: boolean;
    validFormFlag: boolean;
    noReconsignmentFlag: boolean;
    lineOfBusinessCode: number;
    orderId: number;
    networkName: string;
}