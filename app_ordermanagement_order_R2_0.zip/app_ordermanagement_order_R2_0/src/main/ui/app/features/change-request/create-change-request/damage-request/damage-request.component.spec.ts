import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DamageRequestComponent } from './damage-request.component';

describe('DamageRequestComponent', () => {
  let component: DamageRequestComponent;
  let fixture: ComponentFixture<DamageRequestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DamageRequestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DamageRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
