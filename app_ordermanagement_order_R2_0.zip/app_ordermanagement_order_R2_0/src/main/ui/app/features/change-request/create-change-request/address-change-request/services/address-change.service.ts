import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Response } from '@angular/http';
import { JBHGlobals } from './../../../../../app.service';

@Injectable()
export class AddressChangeService {

  constructor(private jbhGlobals: JBHGlobals) { }

  addressChange(endpoint: string): Observable<Response[]> {
    return this.jbhGlobals.apiService.getData(endpoint);
  }

  getStateChange(endpoint: string): Observable<Response[]> {
    return this.jbhGlobals.apiService.getData(endpoint);
  }

  getCountryChange(endpoint: string): Observable<Response[]> {
    return this.jbhGlobals.apiService.getData(endpoint);
  }

  getCityChange(endpoint: string): Observable<Response[]> {
    return this.jbhGlobals.apiService.getData(endpoint);
  }

  getPostalChange(params): Observable<Response[]> {
    const url = this.jbhGlobals.endpoints.changerequest.getPostalCode;
    return this.jbhGlobals.apiService.getData(url, params);
  }

  loadCustomerAddress(params): Observable<Response[]> {
    const url = this.jbhGlobals.endpoints.changerequest.currentCustomer;
    return this.jbhGlobals.apiService.addData(url, params);
  }

  getNetworkName(params): Observable<Response[]> {
    const url = this.jbhGlobals.endpoints.changerequest.getNetworkData
    return this.jbhGlobals.apiService.getData(url, params);
  }
}
