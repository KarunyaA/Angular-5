import { Component, EventEmitter, Input, OnDestroy, OnInit, Output, ViewChild } from '@angular/core';
import { FormArray, FormGroup } from '@angular/forms';

import { JBHGlobals } from '../../../../../app.service';
import { ChangeRequestFormBuilderService } from '../../../services/change-request-form-builder.service';
import { OverageReportingRequestService } from '../services/overage-reporting-request.service';
import { OverageItemDetailModel } from './models/overage-item-details';
// import { UploadFileComponent } from '../../upload-file/upload-file.component';
import { CreateChangeRequestService } from '../../services/create-change-request.service';
import { ModalDirective } from 'ngx-bootstrap';

@Component({
  selector: 'app-overage-item-details',
  templateUrl: './overage-item-details.component.html',
  styleUrls: ['./overage-item-details.component.scss']
})
export class OverageItemDetailsComponent implements OnInit, OnDestroy {
  @ViewChild('createNewOverageRequestModal') createNewOverageRequestModal: any;
  @ViewChild('upload') uploadFileComponent: any;

  @Input() itemDetailsArray: FormArray;
  @Input() dataIndex: any;
  @Input() editForm: boolean;
  @Output() saveItemDetail: any = new EventEmitter();
  @Output() removeItemDetail: any = new EventEmitter();

  createOverageRequest: FormGroup;
  itemDetailForm: any;
  overageItemDetailModel: OverageItemDetailModel;

  constructor(
    private jbhGlobals: JBHGlobals,
    public crFormBuilderService: ChangeRequestFormBuilderService,
    private overageReportingRequestService: OverageReportingRequestService,
    private createChangeRequestService: CreateChangeRequestService) { }

  ngOnInit(): void {
    this.overageItemDetailModel = new OverageItemDetailModel();
    this.initiateValues();
    this.createOverageRequest = this.crFormBuilderService.changeRequestForm['controls']['overageCR'];
    this.itemDetailForm = this.itemDetailsArray.controls[this.dataIndex];

    this.itemDetailForm.reset();
    this.loadOverageType();
  }

  ngOnDestroy(): void {
    this.overageItemDetailModel.subscribeFlag = false;
  }

  onLadingNumber(event: any): void {
    if (!this.jbhGlobals.utils.isValueEmpty(event)) {
      this.overageItemDetailModel.ladingNumber = event.target.value;
      this.itemDetailsArray.controls[this.dataIndex]['controls']['billOfLadingNo'].setValue(event.target.value);
    }
  }
  onModelNumber(event: any): void {
    if (!this.jbhGlobals.utils.isValueEmpty(event)) {
      this.overageItemDetailModel.modelNumber = event.target.value;
      this.itemDetailsArray.controls[this.dataIndex]['controls']['modelNo'].setValue(event.target.value);
    }
  }
  onSerialNumber(event: any): void {
    if (!this.jbhGlobals.utils.isValueEmpty(event)) {
      this.overageItemDetailModel.serialNumber = event.target.value;
      this.itemDetailsArray.controls[this.dataIndex]['controls']['cartonOrLotNo'].setValue(event.target.value);
    }
  }

  onOverageTypeSelection(value: object): void {
    if (!this.jbhGlobals.utils.isValueEmpty(value)) {
      this.overageItemDetailModel.overageTypeSelect = value['text'];
      this.itemDetailsArray.controls[this.dataIndex]['controls']['overageType'].setValue({ id: value['id'], text: value['text'] });
    }
  }

  onSaveItem(): void {
    const uploaderQueue: any = this.uploadFileComponent.uploader.queue;
    for (const queue of uploaderQueue) {
      this.overageItemDetailModel.uploadFile.push(queue.file.name);
    }
    this.saveItemDetail.emit(this);
    this.editForm = false;
    // this.overageItemDetailModel.attachFile = true;
    // this.overageItemDetailModel.fileLabelFlag = true;
  }
  onSaveFile(fileSave: any): void {
    this.overageItemDetailModel.requestUploadFile = fileSave;
    if (!this.jbhGlobals.utils.isValueEmpty(fileSave)) {
      this.overageItemDetailModel.fileAttachArray.push(fileSave);
      // this.createChangeRequestService.onSaveFile(fileSave, this.overageItemDetailModel.subscribeFlag);
    }
  }
  onClickCloseFile(index: number): void {
    this.overageItemDetailModel.uploadFile.splice(index, 1);
    this.createChangeRequestService.onFileDelete(index, this.overageItemDetailModel.subscribeFlag);
    if (this.overageItemDetailModel.uploadFile.length === 0) {
      this.overageItemDetailModel.fileLabelFlag = false;
    }
  }
  onEditItem(): void {
    this.editForm = true;
    this.overageItemDetailModel.attachFile = true;
    this.overageItemDetailModel.fileLabelFlag = true;
    this.overageItemDetailModel.fileAttachArray = [];
  }
  onRemoveItem(): void {
    this.editForm = true;
    this.removeItemDetail.emit(this);
  }
  private initiateValues(): void {
    this.overageItemDetailModel.subscribeFlag = true;
    this.overageItemDetailModel.attachFile = false;
    this.overageItemDetailModel.uploadFile = [];
    this.overageItemDetailModel.fileLabelFlag = false;
    this.overageItemDetailModel.fileAttachArray = [];

  }

  private loadOverageType(): void {
    this.overageReportingRequestService.getOverageReportTypeService(this.jbhGlobals.endpoints.changerequest.overageTypeDropdown)
      .takeWhile(() => this.overageItemDetailModel.subscribeFlag).subscribe(data => {
        this.overageItemDetailModel.overageType = [];
        if (data !== null && data['_embedded'] !== null) {
          const overageType: any = data['_embedded']['itemOverageTypes'];

          for (const type of overageType) {
            this.overageItemDetailModel.overageType.push(
              {
                id: type['itemOverageTypeCode'],
                text: type['overageTypeDescription']
              }
            );
          }
        }
      });
  }
}
