import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OverageReportingRequestComponent } from './overage-reporting-request.component';

describe('OverageReportingRequestComponent', () => {
  let component: OverageReportingRequestComponent;
  let fixture: ComponentFixture<OverageReportingRequestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OverageReportingRequestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OverageReportingRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
