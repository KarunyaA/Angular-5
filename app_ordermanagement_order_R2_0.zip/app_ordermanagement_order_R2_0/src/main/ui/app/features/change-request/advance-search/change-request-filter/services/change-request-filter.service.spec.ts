import { TestBed, inject } from '@angular/core/testing';

import { ChangeRequestFilterService } from './change-request-filter.service';

describe('ChangeRequestFilterService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ChangeRequestFilterService]
    });
  });

  it('should be created', inject([ChangeRequestFilterService], (service: ChangeRequestFilterService) => {
    expect(service).toBeTruthy();
  }));
});
