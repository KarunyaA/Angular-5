import { Component, EventEmitter, Input, OnDestroy, OnInit, Output, ViewChild } from '@angular/core';
import { FormArray, FormGroup } from '@angular/forms';

import { JBHGlobals } from '../../../../../app.service';
import { ChangeRequestFormBuilderService } from '../../../services/change-request-form-builder.service';
import { DamageItemDetailModel } from './models/damage-item-details';
// import { UploadFileComponent } from '../../upload-file/upload-file.component';
import { DamageRequestService } from '../services/damage-request.service';
import { CreateChangeRequestService } from '../../services/create-change-request.service';

@Component({
  selector: 'app-damage-item-details',
  templateUrl: './damage-item-details.component.html',
  styleUrls: ['./damage-item-details.component.scss']
})
export class DamageItemDetailsComponent implements OnInit, OnDestroy {

  @ViewChild('createDamageRequestModal') createDamageRequestModal;
  @ViewChild('upload') uploadFileComponent;

  @Input() itemDetailsArray: FormArray;
  @Input() dataIndex: any;
  @Input() editForm: boolean;
  @Output() onSaveItemDetail = new EventEmitter();
  @Output() onRemoveItemDetail = new EventEmitter();

  createDamageRequest: FormGroup;
  itemDetailForm: any;
  damageItemDetailModel: DamageItemDetailModel;

  constructor(
    private jbhGlobals: JBHGlobals,
    private damageRequestService: DamageRequestService,
    public crFormBuilderService: ChangeRequestFormBuilderService,
    private createChangeRequestService: CreateChangeRequestService) { }

  ngOnInit() {
    this.damageItemDetailModel = new DamageItemDetailModel();
    this.initializeVariables();
    this.createDamageRequest = this.crFormBuilderService.changeRequestForm['controls']['damageCR'];
    this.itemDetailForm = this.itemDetailsArray.controls[this.dataIndex];

    this.itemDetailForm.reset();
    this.loadDamageType();
  }

  ngOnDestroy(): void {
    this.damageItemDetailModel.subscribeFlag = false;
  }

  onLadingNumber(event): void {
    if (!this.jbhGlobals.utils.isValueEmpty(event)) {
      this.damageItemDetailModel.ladingNumber = event.target.value;
      this.itemDetailsArray.controls[this.dataIndex]['controls']['billOfLadingNo'].setValue(event.target.value);
    }
  }
  onModelNumber(event): void {
    if (!this.jbhGlobals.utils.isValueEmpty(event)) {
      this.damageItemDetailModel.modelNumber = event.target.value;
      this.itemDetailsArray.controls[this.dataIndex]['controls']['modelNo'].setValue(event.target.value);
    }
  }
  onSerialNumber(event): void {
    if (!this.jbhGlobals.utils.isValueEmpty(event)) {
      this.damageItemDetailModel.serialNumber = event.target.value;
      this.itemDetailsArray.controls[this.dataIndex]['controls']['cartonOrLotNo'].setValue(event.target.value);
    }
  }
  onDamageTypeSelection(value): void {
    if (!this.jbhGlobals.utils.isValueEmpty(value)) {
      this.damageItemDetailModel.damageType = value.text;
      this.itemDetailsArray.controls[this.dataIndex]['controls']['damageType'].setValue({ id: value.id, text: value.text });
    }
  }

  onSaveItem(): void {
    const uploaderQueue = this.uploadFileComponent.uploader.queue;
    for (const queue of uploaderQueue) {
      this.damageItemDetailModel.uploadFile.push(queue.file.name);
    }
    this.onSaveItemDetail.emit(this);
    this.editForm = false;
    // this.damageItemDetailModel.attachFile = true;
    // this.damageItemDetailModel.fileLabelFlag = true;
  }
  onSaveFile(fileSave): void {
    this.damageItemDetailModel.requestUploadFile = fileSave;
    if (fileSave) {
      this.damageItemDetailModel.fileAttachArray.push(fileSave);
      // this.createChangeRequestService.onSaveFile(fileSave, this.damageItemDetailModel.subscribeFlag);
    }
  }
  onClickCloseFile(index: number): void {
    this.damageItemDetailModel.uploadFile.splice(index, 1);
    this.createChangeRequestService.onFileDelete(index, this.damageItemDetailModel.subscribeFlag);
    if (this.damageItemDetailModel.uploadFile.length === 0) {
      this.damageItemDetailModel.fileLabelFlag = false;
    }
  }
  onEditItem(): void {
    this.editForm = true;
    this.damageItemDetailModel.attachFile = true;
    this.damageItemDetailModel.fileLabelFlag = true;
    this.damageItemDetailModel.fileAttachArray = [];
  }
  onRemoveItem(): void {
    this.editForm = true;
    this.onRemoveItemDetail.emit(this);
  }
  private initializeVariables(): void {
    this.damageItemDetailModel.subscribeFlag = true;
    this.damageItemDetailModel.attachFile = false;
    this.damageItemDetailModel.uploadFile = [];
    this.damageItemDetailModel.fileLabelFlag = false;
    this.damageItemDetailModel.fileAttachArray = [];
  }

  private loadDamageType(): void {
    this.damageRequestService.loadDamageType(this.jbhGlobals.endpoints.changerequest.damageType)
      .takeWhile(() => this.damageItemDetailModel.subscribeFlag).subscribe(data => {
        this.damageItemDetailModel.damageTypeList = [];
        if (!this.jbhGlobals.utils.isValueEmpty(data) && !this.jbhGlobals.utils.isValueEmpty(data['_embedded']['itemDamageTypes'])) {
          const values = data['_embedded']['itemDamageTypes'];
          for (const list of values) {
            this.damageItemDetailModel.damageTypeList.push({
              'id': list['itemDamageTypeCode'],
              'text': list['itemDamageTypeDescription']
            });
          }
        }

      });
  }
}
