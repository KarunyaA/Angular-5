export class AddMoreModel {
    typeaheadDataList = [];
    isAddMoreDisabled = false;
    isValidTypeFieldOnBlur = false;
    isValidTypeAhead = false;
    dataListHadBeenSet = false;
    isEnterableNameField = false;
    isDefaultListGetPopulate = false;
}
