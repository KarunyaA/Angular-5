import { TestBed, inject } from '@angular/core/testing';

import { AddressChangeService } from './address-change.service';

describe('AddressChangeService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AddressChangeService]
    });
  });

  it('should be created', inject([AddressChangeService], (service: AddressChangeService) => {
    expect(service).toBeTruthy();
  }));
});
