import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnDestroy, OnInit, Output, ViewChild } from '@angular/core';
import { FormGroup } from '@angular/forms';

import { IMyOptions } from 'mydatepicker';
import * as moment from 'moment';

import { JBHGlobals } from '../../../../app.service';
import { ChangeRequestFormBuilderService } from '../../services/change-request-form-builder.service';
import { DamageRequestModel } from './models/damage-request.model';
import { DamageRequestService } from './services/damage-request.service';
import { CreateChangeRequestService } from './../services/create-change-request.service';
// import { DamageItemDetailsComponent } from './damage-item-details/damage-item-details.component';

@Component({
  selector: 'app-damage-request',
  templateUrl: './damage-request.component.html',
  styleUrls: ['./damage-request.component.scss'],
  providers: [DamageRequestService],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DamageRequestComponent implements OnInit, OnDestroy {

  @ViewChild('createDamageRequestModal') createDamageRequestModal;
  @ViewChild('itemForm') damageItemDetailsComponent;
  @Input() itemDetailForm: any;
  @Output() onClose = new EventEmitter();
  @ViewChild('popInstance') popInstance: any;
  @ViewChild('fileDuplicate') fileDuplicate: any;

  createDamageRequest: FormGroup;
  myDatePickerOptions: IMyOptions;
  damageRequestModel: DamageRequestModel;

  constructor(
    private jbhGlobals: JBHGlobals,
    private damageRequestService: DamageRequestService,
    private createChangeRequestService: CreateChangeRequestService,
    public crFormBuilderService: ChangeRequestFormBuilderService) { }

  ngOnInit(): void {
    this.damageRequestModel = new DamageRequestModel();
    this.createDamageRequest = this.crFormBuilderService.changeRequestForm['controls']['damageCR'];
    this.itemDetailForm = this.createDamageRequest['controls']['itemDetailsForm'];
    this.initializeModel();
    this.setDatePickerOption();
    this.loadRequestStatus();
    this.loadCarrier();
  }

  ngOnDestroy(): void {
    this.damageRequestModel.subscribeFlag = false;
  }

  onConfirmationOpen(): void {
    this.popInstance.deleteButtonModal.show();
  }
  onSelectTypeahead(event): void {
    if (!this.jbhGlobals.utils.isValueEmpty(event)) {
      this.damageRequestModel.typeaheadCarrier = false;
    }
  }
  onSelectCustomer(event): void {
    if (!this.jbhGlobals.utils.isValueEmpty(event)) {
      this.damageRequestModel.billPartyId = event.item.partyID;
    }
  }
  onSelectCurrentLDC(event): void {
    if (!this.jbhGlobals.utils.isValueEmpty(event)) {
      this.damageRequestModel.facilityProfileId = event.item.partyID;
    }
  }

  onCurrentKeyup(event): void {
    this.createDamageRequest['controls']['currentCustomer']['valueChanges'].debounceTime(this.damageRequestModel.debounceValue)
      .distinctUntilChanged().subscribe((value) => {
        if (!this.jbhGlobals.utils.isValueEmpty(value) && value.length > 2) {
          this.createChangeRequestService.onCurrentTypeaheadKeyup(value, this.damageRequestModel.subscribeFlag, this.damageRequestModel);
        } else {
          this.damageRequestModel.currentCustomerList = [];
        }
      });
  }

  onCurrentLDCKeyup(event): void {
    this.createDamageRequest['controls']['currentLDC']['valueChanges'].debounceTime(this.damageRequestModel.debounceValue)
      .distinctUntilChanged().subscribe((value) => {
        if (!this.jbhGlobals.utils.isValueEmpty(value) && value.length > 2) {
          this.createChangeRequestService.onCurrentLDCKeyup(value, this.damageRequestModel.subscribeFlag, this.damageRequestModel);
        } else {
          this.damageRequestModel.currentLDCList = [];
        }
      });
  }

  onStatus(value: any): void {
    if (!this.jbhGlobals.utils.isValueEmpty(value)) {
      this.createDamageRequest['controls']['status'].setValue({ id: value.id, text: value.text });
    }
  }

  onClickAddAdditionalItem(event): void {
    const itemDetails = this.crFormBuilderService.addItemDamage();
    this.damageRequestModel.addItemFlag = true;
    this.damageRequestModel.addAdditionalFlag = false;
    this.damageRequestModel.itemSaveFlag = false;
    this.damageRequestModel.itemSave = true;
    this.itemDetailForm.push(itemDetails);
  }
  onSaveItemDetail(event): void {
    if (!this.jbhGlobals.utils.isValueEmpty(event)) {
      this.damageRequestModel.item = event;
      this.damageRequestModel.addAdditionalFlag = true;
      this.damageRequestModel.orderChangeRequest = this.createChangeRequestService.getRequestOSD();
      if (this.jbhGlobals.utils.isValueEmpty(this.damageRequestModel.orderChangeRequest)) {
        this.onSubmit();
      } else {
        this.itemSave();
      }
    }
  }

  itemSave(): void {
    this.damageRequestModel.orderChangeRequest = this.createChangeRequestService.getRequestOSD();
    if (!this.damageRequestModel.addAdditionalFlag) {
      this.jbhGlobals.notifications.alert('Warning', 'Item not saved');
    } else {
      if (this.damageRequestModel.orderChangeRequest['shipmentDiscrepancyNotificationRequests'] &&
        this.damageRequestModel.orderChangeRequest['shipmentDiscrepancyNotificationRequests'][0] &&
        this.damageRequestModel.firstItemFlag) {
        this.frameItemsEntity(this.createDamageRequest, this.itemDetailForm);
        this.damageRequestModel.item.dataIndex = 0;
        this.headerUpdate(this.damageRequestModel.orderChangeRequest['shipmentDiscrepancyNotificationRequests'][0]);
        this.damageRequestModel.firstItemFlag = false;
      }
      if (this.damageRequestModel.orderChangeRequest && this.damageRequestModel.orderChangeRequest['orderChangeRequestID']) {
        this.damageRequestModel.addAdditionalFlag = true;
        const formJson = this.itemFormData();
        const shipmentNotification = this.damageRequestModel.orderChangeRequest['shipmentDiscrepancyNotificationRequests'];
        if (this.damageRequestModel.orderChangeRequest &&
          shipmentNotification && this.damageRequestModel.itemDetails[this.damageRequestModel.item.dataIndex]) {
          const shipmentId = this.damageRequestModel.itemDetails[this.damageRequestModel.item.dataIndex]['shipmentDiscrepancyNotificationRequestID'];
          const damageItemUpdate = this.frameItemsUpdateEntity(this.createDamageRequest, this.itemDetailForm, shipmentId);
          formJson.shipmentDiscrepancyNotificationRequests = damageItemUpdate;
          this.damageRequestModel.itemSaveFlag = true;
          this.createChangeRequestService.onItemUpdate(formJson, this, this.damageRequestModel,
            this.damageRequestModel.item.damageItemDetailModel['fileAttachArray'], this.damageRequestModel.item.dataIndex, 'damagechangerequest');
        } else {
          const damageItemDetails = this.frameItemsEntity(this.createDamageRequest, this.itemDetailForm);
          formJson.shipmentDiscrepancyNotificationRequests = damageItemDetails;
          this.damageRequestModel.itemSaveFlag = true;
          this.createChangeRequestService.onItemSave(formJson, this, this.damageRequestModel,
            this.damageRequestModel.item.damageItemDetailModel['fileAttachArray'], this.damageRequestModel.item.dataIndex, 'damagechangerequest');
        }
      }
    }
  }
  onRemoveItemDetail(event): void {
    if (!this.jbhGlobals.utils.isValueEmpty(event)) {
      const discrepencyId = this.damageRequestModel.itemDetails[event.dataIndex]['shipmentDiscrepancyNotificationRequestID'];
      this.damageRequestModel.itemDetails.splice(event.dataIndex, 1);
      this.itemDetailForm['controls'].splice(event.dataIndex, 1);
      this.damageRequestModel.headerUpdate.splice(event.dataIndex, 1);
      // this.damageRequestModel.orderChangeRequest
      // ['shipmentDiscrepancyNotificationRequests'].splice(event.dataIndex, 1);
      this.createChangeRequestService.onItemDelete(discrepencyId, this.damageRequestModel.subscribeFlag);
    }
  }

  onValidateDateRangeFields(event): void {
    if (!this.jbhGlobals.utils.isValueEmpty(event)) {
      moment(new Date(event.formatted)).format('MM/DD/YYYY');
    }
  }

  onSubmit(): void {
    const user = this.jbhGlobals.user.userDetails.userId;
    this.damageRequestModel.orderChangeRequest = this.createChangeRequestService.getRequestOSD();
    const damageHeaderDetails = this.frameHeaderEntity(this.createDamageRequest, this.itemDetailForm);
    const formJson = this.damageRequestService.createRequestForm(this.damageRequestModel);
    formJson['orderChangeRequestCommentLogs'] = [{
      'commentPersonID': user,
      'orderChangeRequestComment': this.createDamageRequest.controls.comments.value ?
        this.createDamageRequest.controls.comments.value : ''
    }];
    if (this.createDamageRequest.valid) {
      if (this.damageRequestModel.orderChangeRequest && this.damageRequestModel.orderChangeRequest['orderChangeRequestID']) {
        const formJson = this.itemFormData();
        formJson['shipmentDiscrepancyNotificationRequests'] = this.damageRequestModel.headerUpdate;
        this.createChangeRequestService.onUpdateOSD(this, formJson,
          this.damageRequestModel.subscribeFlag, this.createDamageRequest, this.createDamageRequestModal,
          this.damageRequestModel.orderChangeRequest['orderChangeRequestID'], this.damageRequestModel.itemSaveFlag, 'damagechangerequest');
      } else {
        formJson.shipmentDiscrepancyNotificationRequests = damageHeaderDetails;
        this.createChangeRequestService.onSaveOSD(this, this.damageRequestModel, formJson, this.damageRequestModel.subscribeFlag,
          this.createDamageRequest, this.createDamageRequestModal, this.damageRequestModel.itemSaveFlag, 'damagechangerequest');
      }
    } else {
      const me = this;
      this.jbhGlobals.utils.forIn(this.createDamageRequest.controls, function (value: any, name: string, object: Object): void {
        if (me.jbhGlobals.utils.isEmpty(me.createDamageRequest.controls[name].value)) {
          me.createDamageRequest.controls[name].markAsTouched();
          if (name === 'status') {
            me.createDamageRequest.controls[name].setErrors({
              'mandatorySelect': true
            });
          }
        }
      });
      this.jbhGlobals.notifications.alert('Warning', 'Please enter all the required fields');
    }
  }
  headerUpdate(shipmentId) {
    const item = this.frameItemsUpdateEntity(this.createDamageRequest, this.itemDetailForm, shipmentId['shipmentDiscrepancyNotificationRequestID']);
    const updateItem = this.jbhGlobals.utils.findIndex(this.damageRequestModel.headerUpdate, { 'shipmentDiscrepancyNotificationRequestID': shipmentId['shipmentDiscrepancyNotificationRequestID'] });
    if (updateItem === -1) {
      this.damageRequestModel.headerUpdate.push(item[0]);
    } else {
      this.damageRequestModel.headerUpdate.splice(updateItem, 1, item[0]);
    }
  }

  blurredOnSelect(event, selectComponent: any): void {
    const compName = selectComponent.element.nativeElement.id;
    if (selectComponent._active.length === 0) {
      this.createDamageRequest.get(compName).markAsTouched();
      this.createDamageRequest.get(compName).setErrors({
        mandatorySelect: true
      });
    }
  }

  onDelete(eve): void {
    if (eve.flag) {
      this.createDamageRequestModal.hide();
      this.createDamageRequest.reset();
      this.createDamageRequest['controls']['itemDetailsForm']['controls'] = [];
      this.itemDetailForm = [];
      this.popInstance.deleteButtonModal.hide();
      this.onClose.emit(eve);
    } else {
      this.popInstance.deleteButtonModal.hide();
    }
  }
  onFileDuplicate(eve): void {
    this.damageRequestModel.saveFile = true;
    if (eve.flag) {
      this.damageRequestModel.duplicateFile = true;
      this.createChangeRequestService.onSaveFile(this.damageRequestModel.fileJson, this, this.damageRequestModel)
      this.fileDuplicate.deleteButtonModal.hide();
    } else {
      this.damageRequestModel.duplicateFile = false;
      this.popInstance.deleteButtonModal.hide();
    }
  }

  private initializeModel(): void {
    this.damageRequestModel.subscribeFlag = true;
    this.damageRequestModel.typeaheadCarrier = true;
    this.damageRequestModel.isModalShown = true;
    this.damageRequestModel.debounceValue = this.jbhGlobals.settings.debounce;
    this.damageRequestModel.currentCustomerList = [];
    this.damageRequestModel.currentLDCList = [];
    this.damageRequestModel.addAdditionalFlag = true;
    this.damageRequestModel.shipmentDiscrepency = [];
    this.damageRequestModel.itemDetails = [];
    this.damageRequestModel.headerUpdate = [];
    this.damageRequestModel.firstItemFlag = true;
    this.damageRequestModel.itemSaveFlag = true;
    this.damageRequestModel.duplicateFile = false;
    this.damageRequestModel.saveFile = true;
    this.damageRequestModel.itemSave = true;
  }

  // private itemShipmentIdArray(index: number, shipId: number): void {
  //   this.damageRequestModel.itemDetails.push({
  //     'index': index,
  //     'discrepencyID': shipId
  //   });
  //   this.jbhGlobals.utils.uniqWith(this.damageRequestModel.itemDetails);
  // }

  private frameItemsEntity(damageDetails: any, itemDetails: any): any {
    if (!this.jbhGlobals.utils.isValueEmpty(damageDetails) && !this.jbhGlobals.utils.isValueEmpty(itemDetails)) {
      let obj = {};
      obj = this.itemRequestForm(damageDetails, itemDetails);
      this.damageRequestModel.shipmentDiscrepency.push(obj);
      return this.damageRequestModel.shipmentDiscrepency;
    }
  }

  private frameItemsUpdateEntity(damageDetails: any, itemDetails: any, shipmentId: number): any {
    const itemArray = [];
    let obj = {};
    obj = this.itemRequestForm(damageDetails, itemDetails);
    obj['shipmentDiscrepancyNotificationRequestID'] = shipmentId ? shipmentId : '';
    itemArray.push(obj);
    return itemArray;
  }

  private itemRequestForm(damageDetails: any, itemDetails: any): any {
    if (!this.jbhGlobals.utils.isValueEmpty(itemDetails)) {
      const itemDetailsPath = itemDetails.controls[this.damageRequestModel.item.dataIndex]['controls'];
      const damageType = itemDetailsPath['damageType']['value'] !== null ?
        itemDetailsPath['damageType']['value'][0]['id'] : '';
      let obj = {};
      obj = this.damageRequestService.createHeaderEntity(damageDetails, itemDetails);
      obj['itemBillOfLadingNumber'] = itemDetailsPath['billOfLadingNo'].value ? itemDetailsPath['billOfLadingNo'].value : '',
        obj['itemModelNumber'] = itemDetailsPath['modelNo'].value ? itemDetailsPath['modelNo'].value : '',
        obj['itemSerialNumber'] = itemDetailsPath['cartonOrLotNo'].value ? itemDetailsPath['cartonOrLotNo'].value : '',
        obj['itemDamageType'] = {},
        obj['itemDamageType']['itemDamageTypeCode'] = damageType
      return obj;
    }
  }

  private loadRequestStatus(): void {
    this.damageRequestService.loadDamageType(this.jbhGlobals.endpoints.changerequest.getChangeRequestStatus)
      .takeWhile(() => this.damageRequestModel.subscribeFlag).subscribe(data => {
        if (!this.jbhGlobals.utils.isValueEmpty(data)) {
          this.damageRequestModel.acceptRefused = [];
          for (const reqStatus of data) {
            this.damageRequestModel.acceptRefused.push(
              {
                id: reqStatus['status'],
                text: reqStatus['status']
              }
            );
          }
        }
      });
  }

  private loadCarrier(): void {
    this.damageRequestModel.carrierTypeheadList = [];
    this.createDamageRequest['controls']['carrier']['valueChanges'].debounceTime(this.damageRequestModel.debounceValue)
      .distinctUntilChanged().subscribe((value) => {
        if (!this.jbhGlobals.utils.isValueEmpty(value) && value.length > 2 && this.damageRequestModel.typeaheadCarrier) {
          const params = {
            query: value,
            limit: 10
          };
          this.damageRequestService.getCarrierService(this.jbhGlobals.endpoints.changerequest.carrier, params)
            .takeWhile(() => this.damageRequestModel.subscribeFlag).subscribe(data => {
              if (!this.jbhGlobals.utils.isValueEmpty(data)) {
                const carrierTypeAhead = data;
                this.damageRequestModel.carrierTypeheadList = [];
                for (const carrier of carrierTypeAhead) {
                  const obj = {};
                  obj['name'] = carrier['suggestText'];
                  obj['source'] = carrier;
                  this.damageRequestModel.carrierTypeheadList.push(obj);
                }
              }
            });
        } else {
          this.damageRequestModel.typeaheadCarrier = true;
        }
      });
  }

  private frameHeaderEntity(damageDetails: any, itemDetails: any): any {
    const headerDetailsArray = [];
    if (!this.jbhGlobals.utils.isValueEmpty(damageDetails)) {
      const obj = this.damageRequestService.createHeaderEntity(damageDetails, itemDetails);
      headerDetailsArray.push(obj);
    }
    return headerDetailsArray;
  }

  private itemFormData(): any {
    let obj = {};
    obj = this.damageRequestService.createRequestForm(this.damageRequestModel);
    obj['orderChangeRequestID'] = this.damageRequestModel.orderChangeRequest['orderChangeRequestID'];
    return obj;
  }

  private setDatePickerOption(): void {
    this.myDatePickerOptions = {
      todayBtnTxt: 'Today', dateFormat: 'mm-dd-yyyy', firstDayOfWeek: 'mo', showTodayBtn: false,
      showClearDateBtn: false, editableDateField: false, sunHighlight: true, height: '34px',
      width: '375px', inline: false, selectionTxtFontSize: '14px',
      enableDays: [{ year: 2017, month: 6, day: 12 }, { year: 2017, month: 6, day: 15 }],
      dayLabels: { su: 'S', mo: 'M', tu: 'T', we: 'W', th: 'T', fr: 'F', sa: 'S' }
    };
  }
}
