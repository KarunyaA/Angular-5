import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DamageItemDetailsComponent } from './damage-item-details.component';

describe('DamageItemDetailsComponent', () => {
  let component: DamageItemDetailsComponent;
  let fixture: ComponentFixture<DamageItemDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DamageItemDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DamageItemDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
