import { ChangeDetectorRef, ChangeDetectionStrategy, Component, Input, EventEmitter, OnInit, Output, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { AddressChangeModel } from './models/addresschange.model';
import { AddressChangeService } from './services/address-change.service';
import { JBHGlobals } from './../../../../app.service';
import { TypeaheadMatch } from 'ngx-bootstrap';
import { ChangeRequestFormBuilderService } from '../../services/change-request-form-builder.service';
import { AddresstypeahedService } from './../services/addresstypeahed.service';
import { CreateChangeRequestService } from './../services/create-change-request.service';

@Component({
    selector: 'app-address-change-request',
    templateUrl: './address-change-request.component.html',
    styleUrls: ['./address-change-request.component.scss'],
    providers: [AddressChangeService, AddresstypeahedService],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class AddressChangeRequestComponent implements OnInit {
    @ViewChild('createNewChangeRequestModal') createNewChangeRequestModal;
    @ViewChild('popInstance') popInstance: any;
    @Input('shipNumber') shipmentNumber: any;
    @Output() onClose = new EventEmitter();
    addressChangeModel: AddressChangeModel;
    createAddressChangeRequest: FormGroup;
    addressCRAddress: FormGroup;
    isModalShown: boolean;

    constructor(
        private formBuilder: FormBuilder,
        public crFormBuilderService: ChangeRequestFormBuilderService,
        private jbhGlobals: JBHGlobals,
        private changeDetector: ChangeDetectorRef,
        private addressChangeService: AddressChangeService,
        private typeAheadService: AddresstypeahedService,
        private createChangeRequestService: CreateChangeRequestService) { }

    ngOnInit() {
        this.addressChangeModel = new AddressChangeModel();
        this.initializeVariables(this.addressChangeModel);
        this.createAddressChangeRequest = this.crFormBuilderService.changeRequestForm['controls']['addressCR'];
        this.isModalShown = true;
        this.shipmentNumberPreload();
    }

    initializeVariables(addressChangeModel) {
        addressChangeModel.getCityCodeList = [];
        addressChangeModel.getPostalCodeList = [];
        addressChangeModel.getAddressCodeList = [];
        addressChangeModel.subscribeFlag = true;
        addressChangeModel.customerList = [];
        addressChangeModel.distributionList = [];
        addressChangeModel.customerLDCList = [];
        addressChangeModel.consumerList = [];
        addressChangeModel.addressFlag = false;
        addressChangeModel.addAddressFlag = false;
        addressChangeModel.addressType = true;
        addressChangeModel.addressForm = false;
        addressChangeModel.addressDetails = true;
        addressChangeModel.distributionFlag = false;
        addressChangeModel.addressRecongFlag = false;
        addressChangeModel.typeDistributionFlag = false;
        addressChangeModel.getLdcAddressList = [];
        addressChangeModel.newAddressDTO = [];
        addressChangeModel.noReconsignmentFlag = false;
    }
    onCloseModal(): void {
        this.createNewChangeRequestModal.hide();
        this.createAddressChangeRequest.reset();
    }
    onConfirmationOpen(): void {
        this.popInstance.deleteButtonModal.show();
    }
    onDelete(eve): void {
        if (eve.flag) {
            this.createAddressChangeRequest.reset();
            this.createNewChangeRequestModal.hide();
            this.popInstance.deleteButtonModal.hide();
            this.onClose.emit(eve);
        } else {
            this.popInstance.deleteButtonModal.hide();
        }
    }
    shipmentNumberPreload() {
        if (this.shipmentNumber) {
            this.createAddressChangeRequest['controls']['shipmentIdentificationNo'].setValue(this.shipmentNumber);
            this.createChangeRequestService.onShipmentNoBlur(this.shipmentNumber, this.addressChangeModel, this, 'address');
            this.addressChangeModel.addressFlag = true;
        }
    }
    onBlurShipmentNo(event): void {
        const shipNo = event.target.value;
        if (shipNo.length > 2) {
            this.createChangeRequestService.onShipmentNoBlur(shipNo, this.addressChangeModel, this, 'address');
            this.addressChangeModel.addressFlag = true;
        } else {
            this.addressChangeModel.addressFlag = false;
        }
        this.changeDetector.detectChanges();
    }

    getNetworkName() : void {
        const params = {
            'sourceOrderID': this.addressChangeModel.orderId
        }
        this.addressChangeService.getNetworkName(params).subscribe(data => {
            const datavalues = data['order'];
            this.addressChangeModel.networkName = datavalues['networkName'];
            });
    }
    getStateList() {
        this.addressChangeService.getStateChange(this.jbhGlobals.endpoints.changerequest.getChangeAddressState)
            .subscribe(data => {
                this.addressChangeModel.addressStateList = [];
                const stateValues = data['_embedded']['states'];
                for (let i = 0; i < stateValues.length; i++) {
                    this.addressChangeModel.addressStateList.push({
                        id: stateValues[i]['stateID'],
                        text: stateValues[i]['stateName']
                    });
                }
            });
    }
    createNewChangeForm() {
        this.addressChangeModel.addressForm = false;
        this.addressChangeModel.addressType = true;
        this.addressChangeModel.addAddressFlag = false;
        this.createAddressChangeRequest.reset();
    }
    onClickAddNewAddressDesc(event) {
        this.addressChangeModel.addressForm = true;
        this.addressChangeModel.addressType = false;
        this.getStateList();
        this.getCountryList();
    }

    getCountryList() {
        this.addressChangeService.getCountryChange(this.jbhGlobals.endpoints.changerequest.getChangeAddressCountry)
            .subscribe(data => {
                this.addressChangeModel.addressCountryList = [];
                const countryValues = data['_embedded']['countries'];
                for (let i = 0; i < countryValues.length; i++) {
                    this.addressChangeModel.addressCountryList.push({
                        id: countryValues[i]['countryCode'],
                        text: countryValues[i]['countryName']
                    })
                }
            });
    }

    onCityChangeKeyUp(event) {
        const value = event.target.value;
        if (value.length > 2) {
            this.getCityList();
        } else {
            this.addressChangeModel.getCityCodeList = [];
        }
    }

    getCityList() {
        this.addressChangeService.getCityChange(this.jbhGlobals.endpoints.changerequest.getChangeAddressCity)
            .subscribe(data => {
                this.addressChangeModel.getCityCodeList = [];
                const citylist = [];
                const cityValue = data['_embedded']['cities']
                for (const values of cityValue) {
                    citylist.push({
                        'code': values['cityName'],
                        'id': values['cityID']
                    })
                }
                this.addressChangeModel.getCityCodeList = citylist;
            });
    }
    onPostalCodeBlur(event) {
        const value = event.target.value;
        const params = {
            'networkName': this.addressChangeModel.networkName,
            'zipcode': value
        }
        this.addressChangeService.getPostalChange(params)
            .subscribe(data => {
                this.addressChangeModel.distributionList = [];
                const obj = {};
                obj['address1'] = data['AddressDTO']['addressLineOne'] + ',' + data['AddressDTO']['addressLineTwo'];
                obj['city'] = data['AddressDTO']['cityDTO']['cityAliasName'] + ',' + data['AddressDTO']['postalCodeDTO']['postalCode'];
                obj['phoneNo'] = data['AddressDTO']['TelephoneDTO']['telephoneNumber'];
                const postalCode = data['AddressDTO']['postalCodeDTO']['postalCode'];
                this.addressChangeModel.distributionList.push(obj);
                this.addressChangeModel.distributionFlag = true;
                const ldcPostCode = (this.addressChangeModel.customerLDCList) ?
                    this.addressChangeModel.customerLDCList['zipcode'] : '';
                if (ldcPostCode && ldcPostCode !== postalCode) {
                    this.addressChangeModel.noReconsignmentFlag = false;
                    this.addressChangeModel.addressRecongFlag = true;
                } else if(ldcPostCode && ldcPostCode === postalCode) {
                    this.addressChangeModel.addressRecongFlag = false;
                    this.addressChangeModel.noReconsignmentFlag = true;                       
                }
            });
    }

    loadAddressDetails(event) {
        this.addressChangeModel.addAddressFlag = false;
        this.getLDCPostalCode(event);
        this.addressChangeModel.newAddressDTO = event.item;
    }
    getLDCPostalCode(event) {
        this.addressChangeModel.getLdcAddressList = [];
        const value = event.item.postalCode;
        this.addressChangeService.getPostalChange(value).subscribe(data => {
            if (data === undefined) {
                this.addressChangeModel.typeDistributionFlag = false;
            } else {
                const obj = {};
                obj['address1'] = data['AddressDTO']['addressLineOne'] + ',' + data['AddressDTO']['addressLineTwo'];
                obj['city'] = data['AddressDTO']['cityDTO']['cityAliasName'] + ',' + data['AddressDTO']['postalCodeDTO']['postalCode'];
                obj['phoneNo'] = data['AddressDTO']['TelephoneDTO']['telephoneNumber']
                this.addressChangeModel.getLdcAddressList.push(obj);
                this.addressChangeModel.typeDistributionFlag = true;
            }
        });
    }

    onAddressChangeKeyUp(event) {
        const value = event.currentTarget.value;
        const changeAddressData = [];
        if (value.length > 2) {
            const params = this.typeAheadService.getCurrentCustomer(value);
            this.addressChangeModel.getAddressCodeList = [];
            this.addressChangeService.loadCustomerAddress(params).takeWhile(() => this.addressChangeModel.subscribeFlag)
                .subscribe(data => {
                    if (data && data['hits'] && data['hits']['hits'] && data['hits']['hits'].length > 0) {
                        this.jbhGlobals.utils.map(data['hits']['hits'], (items) => {
                            const obj = {};
                            const source = items['_source']['Address'];
                            obj['searchkey'] = source['AddressLine1'] + ' ' + source['AddressLine2'] + ', ' +
                                source['CityName'] + ', ' + source['StateName'] + ', ' + source['PostalCode'] + ', ' +
                                source['CountryName'] + ', ' + items['_source']['OrganizationName'] +
                                ' (' + ((items['_source']['CustomerCode']) ? items['_source']['CustomerCode'] : '') + ')';
                            obj['partyID'] = items['_source']['PartyID'];
                            obj['orgName'] = items['_source']['OrganizationName'];
                            obj['addressDTO'] = items['_source']['Address'];
                            obj['postalCode'] = items['_source']['Address']['PostalCode'];
                            changeAddressData.push(obj);
                        });
                        this.addressChangeModel.getAddressCodeList = changeAddressData;
                    } else {
                        this.addressChangeModel.getAddressCodeList = [];
                        this.addressChangeModel.getAddressCodeList.push({});
                        this.addressChangeModel.addAddressFlag = true;
                    }
                });
        }
    }

    onShipmentKeyup(event): void {
        const value = event.target.value;
        if (value) {
            this.addressChangeModel.mandatoryFlag = false;
        }
    }

    onSubmit(): void {
        this.addressChangeModel.validFormFlag = false;
        if (!this.createAddressChangeRequest.valid) {
            const me = this;
            this.jbhGlobals.utils.forIn(this.createAddressChangeRequest.controls, function (value: any, name: string, object: Object) {
                if (me.jbhGlobals.utils.isEmpty(me.createAddressChangeRequest.controls[name].value)) {
                    if (name === 'shipmentIdentificationNo' || (name === 'addressLine' && !me.addressChangeModel.addressForm) ||
                        name === 'requestorName') {
                        me.createAddressChangeRequest.controls[name].markAsTouched();
                        me.createAddressChangeRequest.controls[name].setErrors({
                            'required': true
                        });
                    }
                    if (name === 'addressLine1' || name === 'city' ||
                        name === 'state' || name === 'postalCode' ||
                    name === 'country') {
                        if (me.addressChangeModel.addressForm) {
                            me.createAddressChangeRequest.controls[name].markAsTouched();
                            me.createAddressChangeRequest.controls[name].setErrors({
                                'required': true
                            });
                        }
                    }
                }
            });
        }
        if (this.createAddressChangeRequest.controls['shipmentIdentificationNo'].value && this.createAddressChangeRequest.controls['requestorName'].value) {
            if (this.addressChangeModel.addressForm) {
                if (this.createAddressChangeRequest.controls['addressLine1'].value && this.createAddressChangeRequest.controls['city'].value && this.createAddressChangeRequest.controls['state'].value && this.createAddressChangeRequest.controls['postalCode'].value && this.createAddressChangeRequest.controls['country'].value) {
                    this.addressChangeModel.validFormFlag = true;
                }
            } else {
                if(this.createAddressChangeRequest.controls['addressLine'].value ) {
                    this.addressChangeModel.validFormFlag = true;
                }
            }
        }
        if (this.addressChangeModel.validFormFlag) {
            const formJson = this.loadFormData();
            this.createChangeRequestService.onSave(formJson, this.addressChangeModel.subscribeFlag,
                'addresschangerequest', this.createNewChangeRequestModal);
                this.onClose.emit('event');
                this.createAddressChangeRequest.reset();
        }
    }
    private loadFormData(): Object {
        const user = this.jbhGlobals.user.userDetails.userId;
        const json = {
            'changeRequestCreatorID': 1457,
            'orderID': null,
            'distributionFacilityProfileID': 1,
            'changeRequestType': {
                'changeRequestTypeCode': 'AddChngReq'
            },
            'changeRequestStatus': {
                'changeRequestStatusCode': 'Pending'
            },
            'billingPartyID': this.addressChangeModel.customerList['id'] ? this.addressChangeModel.customerList['id']: null,
            'lineOfBusinessCode': this.addressChangeModel.lineOfBusinessCode ? this.addressChangeModel.lineOfBusinessCode : null,
            'changeRequestRequesterID': 2466758,
            'shipmentIdentificationNumber': this.createAddressChangeRequest.controls.shipmentIdentificationNo.value,
            'customerRequesterFirstName': this.createAddressChangeRequest.controls.requestorName.value,
            'orderChangeRequestCommentLogs': [
                {
                    'commentPersonID': user,
                    'orderChangeRequestComment': this.createAddressChangeRequest.controls.consumerReason.value
                }
            ],
            'addressInformationChangeRequests': [
                {
                    'modifiedConsumerContactAddressLine2': (this.addressChangeModel.addressForm) ?
                        this.createAddressChangeRequest.controls.addressLine2.value : (this.addressChangeModel.newAddressDTO.addressDTO ? this.addressChangeModel.newAddressDTO.addressDTO.AddressLine2 : ''),
                    'modifiedConsumerContactAddressLine1': (this.addressChangeModel.addressForm) ?
                        this.createAddressChangeRequest.controls.addressLine1.value :(this.addressChangeModel.newAddressDTO.addressDTO.AddressLine1 ? this.addressChangeModel.newAddressDTO.addressDTO.AddressLine1 :''),
                    'modifiedConsumerContactAddressPostalCode': (this.addressChangeModel.addressForm) ?
                        this.createAddressChangeRequest.controls.postalCode.value :( this.addressChangeModel.newAddressDTO.addressDTO ?  this.addressChangeModel.newAddressDTO.addressDTO.PostalCode: ''),
                    'modifiedConsumerContactAddressCityName': (this.addressChangeModel.addressForm) ? 
                    ( this.createAddressChangeRequest.controls.city.value) : (  this.addressChangeModel.newAddressDTO.addressDTO ?   this.addressChangeModel.newAddressDTO.addressDTO.CityName : '')
                      ,
                    'modifiedConsumerContactPhoneNumber': (this.addressChangeModel.addressForm) ? (this.createAddressChangeRequest.controls.phone.value): 
                        (this.addressChangeModel.newAddressDTO.addressDTO ? this.addressChangeModel.newAddressDTO.addressDTO.TelephoneNumber : ''),
                    'modifiedConsumerContactAddressStateCode': '',
                    'modifiedConsumerContactAddressCountryCode': (this.addressChangeModel.addressForm) ? (this.createAddressChangeRequest.controls.country['_value'][0]['id']): 
                        (this.addressChangeModel.newAddressDTO.addressDTO ? this.addressChangeModel.newAddressDTO.addressDTO.CountryCode : '')
                }
            ]
        }
        return json;
    }
}
