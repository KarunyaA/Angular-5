export class OverageReportingModel {
  isModalShown: boolean;
  overageType: Array<Object>;
  overageTypeSelect: any;
  subscribeFlag: boolean;
  acceptRefused: Array<Object>;
  carrierTypeheadList: Array<Object>;
  debounceValue: number;
  typeaheadCarrier: boolean;
  billPartyId: number;
  facilityProfileId: number;
  currentCustomerList: Array<Object>;
  currentLDCList: Array<Object>;
  addAdditionalFlag: boolean;
  addItemFlag: boolean;
  orderChangeRequest: object;
  shipmentDiscrepency: Array<Object>;
  itemDetails: Array<Object>;
  item: any;
  firstItemFlag: boolean;
  itemSaveFlag: boolean;
  duplicateFile: boolean;
  fileJson: any;
  saveFile: boolean;
  headerUpdate: Array<Object>;
  itemSave: boolean;
}
