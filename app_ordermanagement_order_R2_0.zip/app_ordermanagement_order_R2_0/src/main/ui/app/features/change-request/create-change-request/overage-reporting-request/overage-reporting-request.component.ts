import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnDestroy, OnInit, Output, ViewChild } from '@angular/core';
import { FormGroup } from '@angular/forms';

import { IMyOptions } from 'mydatepicker';
import * as moment from 'moment';

import { JBHGlobals } from '../../../../app.service';
import { ChangeRequestFormBuilderService } from '../../services/change-request-form-builder.service';
import { OverageReportingRequestService } from './services/overage-reporting-request.service';
import { OverageReportingModel } from './models/overage-reporting-request';
import { OverageItemDetailsComponent } from './overage-item-details/overage-item-details.component';
import { CreateChangeRequestService } from './../services/create-change-request.service';

@Component({
  selector: 'app-overage-reporting-request',
  templateUrl: './overage-reporting-request.component.html',
  styleUrls: ['./overage-reporting-request.component.scss'],
  providers: [OverageReportingRequestService],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class OverageReportingRequestComponent implements OnInit, OnDestroy {

  @ViewChild('createNewOverageRequestModal') createNewOverageRequestModal: any;
  @ViewChild('itemForm') overageItemDetailsComponent: OverageItemDetailsComponent;
  @ViewChild('popInstance') popInstance: any;
  @ViewChild('fileDuplicate') fileDuplicate: any;
  @Input() itemDetailForm: any;
  @Output() onClose = new EventEmitter();

  createOverageRequest: FormGroup;
  myDatePickerOptions: IMyOptions;
  overageReportingModel: OverageReportingModel;

  constructor(
    private jbhGlobals: JBHGlobals,
    private createChangeRequestService: CreateChangeRequestService,
    private overageReportingRequestService: OverageReportingRequestService,
    public crFormBuilderService: ChangeRequestFormBuilderService) {
    this.overageReportingModel = new OverageReportingModel();
  }

  ngOnInit(): void {
    this.createOverageRequest = this.crFormBuilderService.changeRequestForm['controls']['overageCR'];
    this.itemDetailForm = this.createOverageRequest['controls']['itemDetailsForm'];
    this.initializeModel();
    this.setDatePickerOption();
    this.loadRequestStatus();
    this.loadCarrier();
    this.onCurrentKeyup();
  }

  ngOnDestroy(): void {
    this.overageReportingModel.subscribeFlag = false;
  }

  onConfirmationOpen(): void {
    this.popInstance.deleteButtonModal.show();
  }

  onSelectTypeahead(event: any): void {
    if (!this.jbhGlobals.utils.isValueEmpty(event)) {
      this.overageReportingModel.typeaheadCarrier = false;
    }
  }
  onSelectCustomer(event: any): void {
    if (!this.jbhGlobals.utils.isValueEmpty(event)) {
      this.overageReportingModel.billPartyId = event.item.partyID;
    }
  }
  onSelectCurrentLDC(event: any): void {
    if (!this.jbhGlobals.utils.isValueEmpty(event)) {
      this.overageReportingModel.facilityProfileId = event.item.partyID;
    }
  }

  onCurrentKeyup(): void {
    this.createOverageRequest['controls']['currentCustomer']['valueChanges'].debounceTime(this.overageReportingModel.debounceValue)
      .distinctUntilChanged().subscribe((value: any) => {
        if (!this.jbhGlobals.utils.isValueEmpty(value) && value.length >= 3) {
          this.createChangeRequestService.onCurrentTypeaheadKeyup(value,
            this.overageReportingModel.subscribeFlag, this.overageReportingModel);
        } else {
          this.overageReportingModel.currentCustomerList = [];
        }
      });
  }

  onCurrentLDCKeyup(event: any): void {
    this.createOverageRequest['controls']['currentLDC']['valueChanges'].debounceTime(this.overageReportingModel.debounceValue)
      .distinctUntilChanged().subscribe((value: any) => {
        if (!this.jbhGlobals.utils.isValueEmpty(value) && value.length > 2) {
          this.createChangeRequestService.onCurrentLDCKeyup(value, this.overageReportingModel.subscribeFlag, this.overageReportingModel);
        } else {
          this.overageReportingModel.currentLDCList = [];
        }
      });
  }

  onClickAddAdditionalItem(event: any): void {
    const itemDetails: any = this.crFormBuilderService.addItemOverage();
    this.overageReportingModel.addItemFlag = true;
    this.overageReportingModel.addAdditionalFlag = false;
    this.overageReportingModel.itemSaveFlag = false;
    this.overageReportingModel.itemSave = true;
    this.itemDetailForm.push(itemDetails);
  }
  onSaveItemDetail(event: any): void {
    if (!this.jbhGlobals.utils.isValueEmpty(event)) {
      this.overageReportingModel.item = event;
      this.overageReportingModel.addAdditionalFlag = true;
      this.overageReportingModel.orderChangeRequest = this.createChangeRequestService.getRequestOSD();
      if (this.jbhGlobals.utils.isValueEmpty(this.overageReportingModel.orderChangeRequest)) {
        this.onSubmit();
      } else {
        this.itemSave();
      }
    }
  }

  onRemoveItemDetail(event: any): void {
    if (!this.jbhGlobals.utils.isValueEmpty(event)) {
      const discrepencyId: number = this.overageReportingModel.itemDetails[event.dataIndex]['shipmentDiscrepancyNotificationRequestID'];
      this.overageReportingModel.itemDetails.splice(event.dataIndex, 1);
      this.itemDetailForm['controls'].splice(event.dataIndex, 1);
      this.overageReportingModel.headerUpdate.splice(event.dataIndex, 1);
      this.createChangeRequestService.onItemDelete(discrepencyId, this.overageReportingModel.subscribeFlag);
    }
  }
  onStatus(value: any): void {
    if (!this.jbhGlobals.utils.isValueEmpty(value)) {
      this.createOverageRequest['controls']['status'].setValue({ id: value.id, text: value.text });
    }
  }
  onValidateDateRangeFields(event: any): void {
    if (!this.jbhGlobals.utils.isValueEmpty(event)) {
      moment(new Date(event.formatted)).format('MM/DD/YYYY');
    }
  }

  onSubmit(): void {
    const user: string = this.jbhGlobals.user.userDetails.userId;
    this.overageReportingModel.orderChangeRequest = this.createChangeRequestService.getRequestOSD();
    const overageHeaderDetails: any = this.frameHeaderEntity(this.createOverageRequest, this.itemDetailForm);
    const formJson: any = this.overageReportingRequestService.createRequestForm(this.overageReportingModel);
    formJson['orderChangeRequestCommentLogs'] = [{
      'commentPersonID': user,
      'orderChangeRequestComment': this.createOverageRequest.controls.comments.value ?
        this.createOverageRequest.controls.comments.value : ''
    }];
    if (this.createOverageRequest.valid) {
      if (this.overageReportingModel.orderChangeRequest && this.overageReportingModel.orderChangeRequest['orderChangeRequestID']) {
        const jsonFormat: any = this.itemFormData();
        jsonFormat['shipmentDiscrepancyNotificationRequests'] = this.overageReportingModel.headerUpdate;
        this.createChangeRequestService.onUpdateOSD(this, jsonFormat,
          this.overageReportingModel.subscribeFlag, this.createOverageRequest, this.createNewOverageRequestModal,
          this.overageReportingModel.orderChangeRequest['orderChangeRequestID'],
          this.overageReportingModel.itemSaveFlag, 'overagechangerequest');
      } else {
        formJson['shipmentDiscrepancyNotificationRequests'] = overageHeaderDetails;
        this.createChangeRequestService.onSaveOSD(this, this.overageReportingModel, formJson, this.overageReportingModel.subscribeFlag,
          this.createOverageRequest, this.createNewOverageRequestModal, this.overageReportingModel.itemSaveFlag, 'overagechangerequest');
      }
    } else {
      const me: any = this;
      this.jbhGlobals.utils.forIn(this.createOverageRequest.controls, function (value: any, name: string, object: object): void {
        if (me.jbhGlobals.utils.isEmpty(me.createOverageRequest.controls[name].value)) {
          me.createOverageRequest.controls[name].markAsTouched();
          if (name === 'status') {
            me.createOverageRequest.controls[name].setErrors({
              'mandatorySelect': true
            });
          }
        }
      });
      this.jbhGlobals.notifications.alert('Warning', 'Please enter all the required fields');
    }
  }
  onBlurSelect(event: any, selectComponent: any): void {
    const compName: any = selectComponent.element.nativeElement.id;
    if (selectComponent._active.length === 0) {
      this.createOverageRequest.get(compName).markAsTouched();
      this.createOverageRequest.get(compName).setErrors({
        mandatorySelect: true
      });
    }
  }
  onDelete(eve: any): void {
    if (eve.flag) {
      this.createOverageRequest.reset();
      this.createOverageRequest['controls']['itemDetailsForm']['controls'] = [];
      this.itemDetailForm = [];
      this.createNewOverageRequestModal.hide();
      this.popInstance.deleteButtonModal.hide();
      this.onClose.emit(eve);
    } else {
      this.popInstance.deleteButtonModal.hide();
    }
  }

  onFileDuplicate(eve: any): void {
    this.overageReportingModel.saveFile = true;
    if (eve.flag) {
      this.overageReportingModel.duplicateFile = true;
      this.createChangeRequestService.onSaveFile(this.overageReportingModel.fileJson, this, this.overageReportingModel);
      this.fileDuplicate.deleteButtonModal.hide();
    } else {
      this.overageReportingModel.duplicateFile = false;
      this.fileDuplicate.deleteButtonModal.hide();
    }
  }
  itemSave(): void {
    this.overageReportingModel.orderChangeRequest = this.createChangeRequestService.getRequestOSD();
    if (!this.overageReportingModel.addAdditionalFlag) {
      this.jbhGlobals.notifications.alert('Warning', 'Item not saved');
    } else {
      if (this.overageReportingModel.orderChangeRequest['shipmentDiscrepancyNotificationRequests'] &&
        this.overageReportingModel.orderChangeRequest['shipmentDiscrepancyNotificationRequests'][0] &&
        this.overageReportingModel.firstItemFlag) {
        this.frameItemsEntity(this.createOverageRequest, this.itemDetailForm);
        this.overageReportingModel.item.dataIndex = 0;
        this.headerUpdate(this.overageReportingModel.orderChangeRequest['shipmentDiscrepancyNotificationRequests'][0]);
        this.overageReportingModel.firstItemFlag = false;
      }
      if (this.overageReportingModel.orderChangeRequest && this.overageReportingModel.orderChangeRequest['orderChangeRequestID']) {
        this.overageReportingModel.addAdditionalFlag = true;
        const formJson: any = this.itemFormData();
        const shipmentNotification: any = this.overageReportingModel.orderChangeRequest['shipmentDiscrepancyNotificationRequests'];
        if (this.overageReportingModel.orderChangeRequest &&
          shipmentNotification && this.overageReportingModel.itemDetails[this.overageReportingModel.item.dataIndex]) {
          const shipmentId: any = this.overageReportingModel.
            itemDetails[this.overageReportingModel.item.dataIndex]['shipmentDiscrepancyNotificationRequestID'];
          const overageItemUpdate: any = this.frameItemsUpdateEntity(this.createOverageRequest, this.itemDetailForm, shipmentId);
          formJson.shipmentDiscrepancyNotificationRequests = overageItemUpdate;
          this.overageReportingModel.itemSaveFlag = true;
          this.createChangeRequestService.onItemUpdate(formJson, this, this.overageReportingModel,
            this.overageReportingModel.item.overageItemDetailModel['fileAttachArray'],
            this.overageReportingModel.item, 'overagechangerequest');
        } else {
          const overageItemDetails: any = this.frameItemsEntity(this.createOverageRequest, this.itemDetailForm);
          formJson.shipmentDiscrepancyNotificationRequests = overageItemDetails;
          this.overageReportingModel.itemSaveFlag = true;
          this.createChangeRequestService.onItemSave(formJson, this, this.overageReportingModel,
            this.overageReportingModel.item.overageItemDetailModel['fileAttachArray'],
            this.overageReportingModel.item.dataIndex, 'overagechangerequest');
        }
      }
    }
  }
  headerUpdate(shipmentId: any): void {
    const item: any = this.frameItemsUpdateEntity(this.createOverageRequest,
      this.itemDetailForm, shipmentId['shipmentDiscrepancyNotificationRequestID']);
    const updateItem: any = this.jbhGlobals.utils.findIndex(this.overageReportingModel.headerUpdate,
      { 'shipmentDiscrepancyNotificationRequestID': shipmentId['shipmentDiscrepancyNotificationRequestID'] });
    if (updateItem === -1) {
      this.overageReportingModel.headerUpdate.push(item[0]);
    } else {
      this.overageReportingModel.headerUpdate.splice(updateItem, 1, item[0]);
    }

  }

  private initializeModel(): void {
    this.overageReportingModel.isModalShown = true;
    this.overageReportingModel.debounceValue = this.jbhGlobals.settings.debounce;
    this.overageReportingModel.typeaheadCarrier = true;
    this.overageReportingModel.subscribeFlag = true;
    this.overageReportingModel.addAdditionalFlag = true;
    this.overageReportingModel.currentCustomerList = [];
    this.overageReportingModel.currentLDCList = [];
    this.overageReportingModel.shipmentDiscrepency = [];
    this.overageReportingModel.itemDetails = [];
    this.overageReportingModel.headerUpdate = [];
    this.overageReportingModel.firstItemFlag = true;
    this.overageReportingModel.itemSaveFlag = true;
    this.overageReportingModel.duplicateFile = false;
    this.overageReportingModel.saveFile = true;
    this.overageReportingModel.itemSave = true;
  }

  private frameItemsEntity(overageDetails: any, itemDetails: any): any {
    if (!this.jbhGlobals.utils.isValueEmpty(itemDetails)) {
      let obj: object = {};
      obj = this.itemRequestForm(overageDetails, itemDetails);
      this.overageReportingModel.shipmentDiscrepency.push(obj);
      return this.overageReportingModel.shipmentDiscrepency;
    }
  }

  private frameItemsUpdateEntity(overageDetails: any, itemDetails: any, shipmentId: number): any {
    const itemArray: any = [];
    let obj: object = {};
    obj = this.itemRequestForm(overageDetails, itemDetails);
    obj['shipmentDiscrepancyNotificationRequestID'] = shipmentId ? shipmentId : '';
    itemArray.push(obj);
    return itemArray;
  }

  private itemRequestForm(overageDetails: any, itemDetails: any): any {
    if (!this.jbhGlobals.utils.isValueEmpty(itemDetails)) {
      const itemDetailsPath: any = itemDetails.controls[this.overageReportingModel.item.dataIndex]['controls'];
      const overageType: any = itemDetailsPath['overageType']['value'] !== null ?
        itemDetailsPath['overageType']['value'][0]['id'] : '';
      let obj: object = {};
      obj = this.overageReportingRequestService.createHeaderEntity(overageDetails, itemDetails);
      obj['itemBillOfLadingNumber'] = itemDetailsPath['billOfLadingNo'].value ? itemDetailsPath['billOfLadingNo'].value : '',
        obj['itemModelNumber'] = itemDetailsPath['modelNo'].value ? itemDetailsPath['modelNo'].value : '',
        obj['itemSerialNumber'] = itemDetailsPath['cartonOrLotNo'].value ? itemDetailsPath['cartonOrLotNo'].value : '',
        obj['itemOverageType'] = {},
        obj['itemOverageType']['itemOverageTypeCode'] = overageType;
      return obj;
    }
  }
  private loadRequestStatus(): void {
    this.overageReportingRequestService.getOverageReportTypeService(this.jbhGlobals.endpoints.changerequest.getChangeRequestStatus)
      .takeWhile(() => this.overageReportingModel.subscribeFlag).subscribe(data => {
        if (!this.jbhGlobals.utils.isValueEmpty(data)) {
          this.overageReportingModel.acceptRefused = [];
          for (const reqStatus of data) {
            this.overageReportingModel.acceptRefused.push(
              {
                id: reqStatus['status'],
                text: reqStatus['status']
              }
            );
          }
        }
      });
  }

  private loadCarrier(): void {
    this.overageReportingModel.carrierTypeheadList = [];
    this.createOverageRequest['controls']['carrier']['valueChanges'].debounceTime(this.overageReportingModel.debounceValue)
      .distinctUntilChanged().subscribe((value: any) => {
        if (!this.jbhGlobals.utils.isValueEmpty(value) && value.length > 2 && this.overageReportingModel.typeaheadCarrier) {
          const params: object = {
            query: value,
            limit: 10
          };
          this.overageReportingRequestService.getCarrierService(this.jbhGlobals.endpoints.changerequest.carrier, params)
            .takeWhile(() => this.overageReportingModel.subscribeFlag).subscribe(data => {
              if (!this.jbhGlobals.utils.isValueEmpty(data)) {
                const carrierTypeAhead: any = data;
                this.overageReportingModel.carrierTypeheadList = [];
                for (const carrier of carrierTypeAhead) {
                  const obj: object = {};
                  obj['name'] = carrier['suggestText'];
                  obj['source'] = carrier;
                  this.overageReportingModel.carrierTypeheadList.push(obj);
                }
              }
            });
        } else {
          this.overageReportingModel.typeaheadCarrier = true;
        }
      });
  }
  private frameHeaderEntity(overageDetails: any, itemDetails: any): any {
    const headerDetailsArray: any = [];
    if (!this.jbhGlobals.utils.isValueEmpty(overageDetails)) {
      const obj: any = this.overageReportingRequestService.createHeaderEntity(overageDetails, itemDetails);
      headerDetailsArray.push(obj);
    }
    return headerDetailsArray;
  }

  private itemFormData(): any {
    let obj: object = {};
    obj = this.overageReportingRequestService.createRequestForm(this.overageReportingModel);
    obj['orderChangeRequestID'] = this.overageReportingModel.orderChangeRequest['orderChangeRequestID'];
    return obj;
  }

  private setDatePickerOption(): void {
    this.myDatePickerOptions = {
      todayBtnTxt: 'Today', dateFormat: 'mm-dd-yyyy', firstDayOfWeek: 'mo', showTodayBtn: false,
      showClearDateBtn: false, editableDateField: false, sunHighlight: true, height: '34px',
      width: '375px', inline: false, selectionTxtFontSize: '14px',
      enableDays: [{ year: 2017, month: 6, day: 12 }, { year: 2017, month: 6, day: 15 }],
      dayLabels: { su: 'S', mo: 'M', tu: 'T', we: 'W', th: 'T', fr: 'F', sa: 'S' }
    };
  }
}
