import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, Subscription } from 'rxjs/Rx';
import { ResultGridModel } from './models/change-request-result-grid.model';
import { ViewChangeRequestService } from '../../services/view-change-request.service';
import { JBHGlobals } from '../../../../app.service';

@Component({
  selector: 'app-change-request-result-grid',
  templateUrl: './change-request-result-grid.component.html',
  styleUrls: ['./change-request-result-grid.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ChangeRequestResultGridComponent implements OnInit {

  @Input()
  set gridResults(gridDataJSON: any) {
    this.populateSearchResultGrid(gridDataJSON);
  }

  @ViewChild('autoShownModal') autoShownModal: any;
  @ViewChild('popoverDiv') popoverDiv: any;
  @Output() gridResize = new EventEmitter<string>();
  @Output() gridColumnManaged = new EventEmitter<any>();
  @Output() gridAdditionalFilterClicked = new EventEmitter<any>();
  @Output() exportExcelClicked = new EventEmitter<any>();
  @Output() paginationData = new EventEmitter<any>();

  resultGridModel: ResultGridModel;
  rows = [];
  limit: any = 10;
  count: any = 10;
  offset: number = 0;
  errorStatus: string;
  errorMessage: string;
  subscribeFlag: boolean = true;
  userInfoJson: object = {
    'personid': this.jbhGlobals.user.userDetails.userId
  };
  columns = [];
  editColumnGridHeaders = [];
  @Output() private createCR = new EventEmitter();
  @Input() searchQuery : any;

  @Input()
  set gridColumns(result: any) {
    this.columns = [];
    if (result && result.gridColumns) {
      this.setGridColumns(result.gridColumns);
      this.editColumnGridHeaders = result.gridColumns;
    }
  }

  constructor(private router: Router, private viewChangeRequestService: ViewChangeRequestService, private jbhGlobals: JBHGlobals) { }

  ngOnInit() {
    this.resultGridModel = new ResultGridModel();
  }

  onManageCloumns(): void {
    this.autoShownModal.show();
  }

  onCreateNewChangeRequest(): void {
    this.createCR.emit(true);
  }

  onPopOverBlur(event: any, popover: any, popup: any): void {
    event.stopPropagation();
    const scope = this;
    this.resultGridModel.popOverFlag = true;
    const source = Observable.timer(500);
    const subscribe = source.subscribe(() => {
      const popOVerList = this.popoverDiv['nativeElement'];
      popOVerList.setAttribute('tabindex', '1');
      popOVerList.focus();
      popOVerList.addEventListener('blur', function (eventProperty) {
        if (scope.resultGridModel.popOverFlag) {
          popup.hide();
          scope.resultGridModel.popOverFlag = false;
        }
      });
    });
  }

  populateSearchResultGrid(gridDataJSON: any): void {
    if (gridDataJSON !== undefined) {
      this.count = gridDataJSON['count'];
      this.rows = gridDataJSON['gridDataArray'];
    }
  }

  onPage(event:any): void {
     const obj = {
       'from':  event.limit * event.offset,
       'size': event.limit
     };
     this.paginationData.emit(obj);      
  }

  onHideEditColumnModel(): void {
    this.autoShownModal.hide();
  }

  onUpdateColumModel(inputColumnParams: any): void {
    let columnsInfoJson = {};
    this.onHideEditColumnModel();
    this.setGridColumns(inputColumnParams);
    columnsInfoJson[this.userInfoJson['personid']] = {};
    columnsInfoJson[this.userInfoJson['personid']]['OrderSearchGridColumns'] = inputColumnParams;
    this.jbhGlobals.localStore.setItem('OrderSearch', 'userColumnPref',
      JSON.stringify(columnsInfoJson), true);
    this.gridResize.emit();
    this.gridColumnManaged.emit(inputColumnParams);
    columnsInfoJson = null;

  }

  exportToExcel(event): void {
        const val = [];
        for (let i = 0; i < this.columns.length; i++) {            
            val.push(this.columns[i]['prop'])
            
            
        }
        // val.push(this.viewByOrderModel.columns[3]['prop'])
        // const param = {
        //     'displayfields': 'val'
        // }
        const url = this.jbhGlobals.endpoints.changerequest.exportToExcel + '?displayfields=' + val;
        const query = this.searchQuery;
        this.viewChangeRequestService.exportToExcel(url, query).takeWhile(() => this.subscribeFlag)
            .subscribe(data => {
                if (data) {
                    this.downloadFile(data);
                }
            });
   }

    private downloadFile(data): void {
        const blob = new Blob([data['_body']], {
            type: 'application/vnd.ms-excel'
        });
        if (window.navigator && window.navigator.msSaveOrOpenBlob) {
            window.navigator.msSaveBlob(blob, 'changeRequest.xlsx');
        } else {
            const a = document.createElement('a');
            a.href = URL.createObjectURL(blob);
            a.download = 'changeRequest.xlsx';
            document.body.appendChild(a);
            a.click();
        }
    }

  setGridColumns(columnsArray: any): void {
    const columns = [];
    for (let columnIdx = 0; columnIdx < columnsArray.length; columnIdx++) {
      const columnJSON = columnsArray[columnIdx];
      if (columnJSON['isVisible']) {
        columns.push(columnJSON);
      }
    }
    this.columns = columns;
  }

  onActivate(event): void {
    const param = {
      'id': event.row.orderChangeRequestID,
      'requestTypeCode': event.row['orderChangeRequestTypeCode'],
      'requestTypeName': event.row['changeRequestTypeDescription']
    };
    this.viewChangeRequestService.setSelectedData(param);
    this.router.navigateByUrl('/changerequest/viewrequest');
  }
}
