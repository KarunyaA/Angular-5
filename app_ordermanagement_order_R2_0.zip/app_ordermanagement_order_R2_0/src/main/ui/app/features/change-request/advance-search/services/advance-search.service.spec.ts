import { TestBed, inject } from '@angular/core/testing';

import { AdvanceSearchService } from './advance-search.service';

describe('AdvanceSerachService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AdvanceSearchService]
    });
  });

  it('should be created', inject([AdvanceSearchService], (service: AdvanceSearchService) => {
    expect(service).toBeTruthy();
  }));
});
