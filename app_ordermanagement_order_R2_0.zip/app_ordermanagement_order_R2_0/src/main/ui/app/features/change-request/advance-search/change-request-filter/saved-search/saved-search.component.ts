import { Component, EventEmitter, Injectable, Input, OnDestroy, OnInit, Output, ViewChild, ElementRef } from '@angular/core';
import { JBHGlobals } from '../../../../../app.service';

import { SavedSearchModel } from './../../models/saved-search.model';
import { SavedSearchService } from './../../services/saved-search.service';

import { Subscription } from 'rxjs/Subscription';

@Component({
    selector: 'app-saved-search',
    providers: [SavedSearchService],
    templateUrl: './saved-search.component.html',
    styleUrls: ['./saved-search.component.scss']
})

@Injectable()
export class SavedSearchComponent implements OnInit, OnDestroy {

    @Input()
    set parentUserInfoJson(parentUserInfoJson: any) {
        const me = this;
        me.userInfoJson = Object.assign({}, parentUserInfoJson);
    }
    @Output() getSearchList = new EventEmitter<any>();
    @Output() RepopulatedList = new EventEmitter<any>();
    @Output() HideSavedSearchModal = new EventEmitter<any>();
    @Output() FavoriteSearchSelected = new EventEmitter<any>();
    @ViewChild('manageSavedSearch') manageSavedSearch: ElementRef;

    savedSearchModel: any;
    subscriptions: Array<Subscription> = [];
    userInfoJson: Object = {};
    savedSearchList = [];
    copyOfSavedSearch = [];
    selectedFavorite: string;
    removeSavedSearchData: Object = {};
    isNoResultsDisplay = false;

    constructor(
        private jbhGlobals: JBHGlobals,
        private savedSearchService: SavedSearchService
    ) { }

    ngOnInit(): void {
        this.savedSearchModel = new SavedSearchModel();
    }

    modalShown(savedSearchListData: any): void {
        this.savedSearchList = [];
        this.removeSavedSearchData = {};
        if (savedSearchListData.length !== 0) {
            this.savedSearchList = savedSearchListData;
        }
        this.isNoResultsDisplay = savedSearchListData.length === 0;
        this.copyOfSavedSearch = Object.assign([], this.savedSearchList);
        this.manageSavedSearch.nativeElement.click();
    }

    removeSavedSearch(): void {
        const url = this.jbhGlobals.endpoints.ordersearch.revomeSavedSearch + '/' + this.removeSavedSearchData['userSavedSearchID'];
        const revomeSavedSearch = this.savedSearchService.revomeSavedSearch(url, {}).subscribe(data => {
            this.populateSavedSearchList(this.userInfoJson);
        });
        this.subscriptions.push(revomeSavedSearch);
        this.onCloseModal();
    }

    onSetRemovableData(event: any, removeSavedSearchDataArg: any): void {
        this.removeSavedSearchData = removeSavedSearchDataArg;
        event.stopPropagation();
    }

    onWarningPopupHidden(): void {
        this.removeSavedSearchData = {};
    }

    populateSavedSearchList(inputParams: any): void {
        const me = this;
        this.getSearchList.emit({
            'inputParams': inputParams,
            'callBack': (results) => {
                me.savedSearchList = results;
                me.copyOfSavedSearch = Object.assign([], me.savedSearchList);
                me.isNoResultsDisplay = me.copyOfSavedSearch.length === 0;
            }
        });
    }

    onCloseModal(): void {
        this.HideSavedSearchModal.emit();
    }

    onRepopulateSavedSearchList(data: any): void {
        this.RepopulatedList.emit(data);
        this.onCloseModal();
    }

    onSearchFieldKeyUpPressed(event: any): void {
        this.savedSearchList = [];
        const txtBoxValue = event.target.value;
        const iteratedResults = this.copyOfSavedSearch.filter(function (item) {
            const itemValue = (item && item['userSearchName']) ? item['userSearchName'] : '';
            return typeof itemValue === 'string' && itemValue.toLowerCase().indexOf(txtBoxValue.toLowerCase()) > -1;
        });
        this.savedSearchList = this.copyOfSavedSearch;
        if (iteratedResults.length !== 0) {
            this.savedSearchList = iteratedResults;
        }
    }

    ResetFields(): void {
        this.selectedFavorite = '';
        this.savedSearchList = this.copyOfSavedSearch;
    }

    ngOnDestroy(): void {
        for (const subs of this.subscriptions) {
            subs.unsubscribe();
        }
    }

}