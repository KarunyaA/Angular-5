import { ChangeDetectionStrategy, Component, Input, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

import { JBHGlobals } from '../../../app.service';
import { ChangeRequestFormBuilderService } from '../services/change-request-form-builder.service';
import { CreateChangeRequestService } from './services/create-change-request.service';
import { CreateChangeRequestModel } from './models/create-change-request.model';
import { UserService } from 'jbh-components/jbh-esa';

@Component({
  selector: 'app-create-change-request',
  templateUrl: './create-change-request.component.html',
  styleUrls: ['./create-change-request.component.scss'],
  providers: [ChangeRequestFormBuilderService, CreateChangeRequestService],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CreateChangeRequestComponent implements OnInit {

  @ViewChild('createNewChangeRequestModal') createNewChangeRequestModal: any;
  @Input('shipmentNumberData') shipmentNumber: any;
  createChangeRequestModel: CreateChangeRequestModel;
  createChangeRequest: FormGroup;
  constructor(
    public jbhGlobals: JBHGlobals,
    private router: Router,
    private formBuilder: FormBuilder,
    public crFormBuilderService: ChangeRequestFormBuilderService,
    public createChangeRequestService: CreateChangeRequestService,
    private userService: UserService
  ) { }

  ngOnInit() {
    this.createChangeRequestModel = new CreateChangeRequestModel();
    this.createChangeRequest = this.crFormBuilderService.changeRequestForm['controls']['createChangeRequestType'];
    this.loadChangeRequest();
  }

  closeModal(event) {
    this.createChangeRequestModel.showCRModalFlag = '';
  }

  onCreateCRModalOpen(event: Object): void {
    this.createNewChangeRequestModal.show();
  }

  onChangeRequestSelection(value): void {
    if (value !== null) {
      this.createChangeRequestModel.changeRequestType = value.id;
    }
  }

  onCreateChangeRequest(): void {
    if (this.createChangeRequestModel.changeRequestType !== null) {
      this.createNewChangeRequestModal.hide();
      this.createChangeRequest.reset();
      this.createChangeRequestModel.showCRModalFlag = this.createChangeRequestModel.changeRequestType;
    }
  }

  hasAccess(operation: String): Boolean {
    let status = false;
    status = this.userService.hasAccess(this.jbhGlobals.routeUrls.changerequest, operation);
    return status;
  }
  loadChangeRequest(): void {
    this.createChangeRequestService.getChangeRequestService(this.jbhGlobals.endpoints.changerequest.getNewRequest)
      .subscribe(data => {
        if (data !== null) {
          this.createChangeRequestModel.createNewRequest = [];
          const changeType = data['_embedded']['changeRequestTypes'];
          for (let i = 0; i < changeType.length; i++) {
            this.createChangeRequestModel.createNewRequest.push({
              id: changeType[i]['changeRequestTypeCode'],
              text: changeType[i]['changeRequestTypeDescription']
            });
          }
        }
      });
  }

}
