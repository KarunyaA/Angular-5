export class CreateChangeRequestModel {
  createNewRequest: Array<Object>;
  changeRequestType: string;
  showCRModalFlag: string;
  searchGridResult: Object;
  requestID: number;
}
