import { ChangeDetectorRef, ChangeDetectionStrategy, Component, EventEmitter, Input, OnInit, Output, ViewChild  } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { JBHGlobals } from 'app/app.service';

import { ContactChangeService } from './services/contact-change.service';
import { ContactChangeModel } from './models/contact-change.model';
import { CreateChangeRequestService } from './../services/create-change-request.service';
import { ChangeRequestFormBuilderService } from '../../services/change-request-form-builder.service';

@Component({
  selector: 'app-contact-change-request',
  templateUrl: './contact-change-request.component.html',
  styleUrls: ['./contact-change-request.component.scss'],
  providers: [ ContactChangeService],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ContactChangeRequestComponent implements OnInit {

    @ViewChild('createNewContactRequestModal') createNewContactRequestModal;
    @ViewChild('popInstance') popInstance: any;
    @Input('shipNumber') shipmentNumber: any;
    @Output() onClose = new EventEmitter();
    createContactAddressChangeRequest: FormGroup;
    contactChangeModel: ContactChangeModel

    constructor(private router: Router,
                private jbhGlobals: JBHGlobals,
                private formBuilder: FormBuilder,
                private changeDetector: ChangeDetectorRef,
                public crFormBuilderService: ChangeRequestFormBuilderService,
                private contactService: ContactChangeService,
                private createChangeRequestService: CreateChangeRequestService) {}

    ngOnInit() {

        this.contactChangeModel = new ContactChangeModel();
        this.initializeModel();
        this.createContactAddressChangeRequest = this.crFormBuilderService.changeRequestForm['controls']['contactCR'];
        this.contactChangeModel.isModalShown = true;
        this.shipmentNumberPreload();
    }

    onConfirmationOpen(): void {
        this.popInstance.deleteButtonModal.show();
    }

    shipmentNumberPreload() {
        if (this.shipmentNumber) {
            this.contactChangeModel.shipmentNumber = this.shipmentNumber;
            this.createContactAddressChangeRequest['controls']['shipmentIdentificationNo'].setValue(this.shipmentNumber);
            this.createChangeRequestService.onShipmentNoBlur(this.shipmentNumber, this.contactChangeModel, this, 'contact');
            this.contactChangeModel.addressFlag = true;
        }
    }
    onBlurShipmentNo(event: any): void {
        const shipNo = event.target.value;
        this.contactChangeModel.shipmentNumber = shipNo;
        if (shipNo.length > 2) {
            this.createChangeRequestService.onShipmentNoBlur(shipNo, this.contactChangeModel, this, 'contact');
            this.contactChangeModel.addressFlag = true;
        } else {
            this.contactChangeModel.addressFlag = false;
        }
        this.changeDetector.detectChanges();
    }

    onShipmentKeyup(event: any): void {
        const value = event.target.value;
        if (value) {
            this.contactChangeModel.mandatoryFlag = false;
        }
    }
    loadFormData(): Object {
        const user = this.jbhGlobals.user.userDetails.userId;
        const contactJson = {
          'changeRequestCreatorID': 1457,
          'orderID': null,
          'distributionFacilityProfileID': 1,
          'changeRequestType': {
            'changeRequestTypeCode': 'ContUpdReq'
          },
          'changeRequestStatus': {
            'changeRequestStatusCode': 'Pending'
          },
          'orderChangeRequestCommentLogs': [
            {
              'commentPersonID': this.createContactAddressChangeRequest.controls.comments.value ? user : '',
              'orderChangeRequestComment': this.createContactAddressChangeRequest.controls.comments.value
            }
          ],
          'billingPartyID': this.contactChangeModel.customerList ? this.contactChangeModel.customerList.id : null,
          'lineOfBusinessCode': this.contactChangeModel.lineOfBusinessCode ? this.contactChangeModel.lineOfBusinessCode : null,
          'changeRequestRequesterID': 2466758,
          'shipmentIdentificationNumber': this.contactChangeModel.shipmentNumber,
          "contactInformationChangeRequests": [
               {
                  "modifiedConsumerContactPhoneNumber": null
               }
            ]

        }
        return contactJson;
    }
    onSubmit(event): void {
        if (this.contactChangeModel.shipmentNumber) {
            const formJson = this.loadFormData();
            this.createChangeRequestService.onSave(formJson, this.contactChangeModel.subscribeFlag,
             'contactchangerequest', this.createNewContactRequestModal);
             this.onClose.emit(event);
             this.createContactAddressChangeRequest.reset();
            this.contactChangeModel.mandatoryFlag = false;
        }
        if (!this.contactChangeModel.shipmentNumber) {
            const me = this;
            this.jbhGlobals.utils.forIn(this.createContactAddressChangeRequest.controls, function(value: any, name: string, object: Object) {
        if (me.jbhGlobals.utils.isEmpty(me.createContactAddressChangeRequest.controls[name].value)) {
            me.createContactAddressChangeRequest.controls[name].markAsTouched();
            me.createContactAddressChangeRequest.controls[name].setErrors({
       'required': true
        });
        }
        });
    }
    }
    onDelete(eve: any): void {
        if (eve.flag) {
            this.createContactAddressChangeRequest.reset();
            this.createNewContactRequestModal.hide();
            this.popInstance.deleteButtonModal.hide();
            this.onClose.emit(eve);
        } else {
            this.popInstance.deleteButtonModal.hide();
        }
    }
    private initializeModel(): void {
        this.contactChangeModel.debounceValue = 500;
        this.contactChangeModel.selected = false;
        this.contactChangeModel.subscribeFlag = true;
        this.contactChangeModel.customerList = [];
        this.contactChangeModel.customerLDCList = [];
        this.contactChangeModel.addressFlag = false;
        this.contactChangeModel.shipmentList = [];
    }
}
