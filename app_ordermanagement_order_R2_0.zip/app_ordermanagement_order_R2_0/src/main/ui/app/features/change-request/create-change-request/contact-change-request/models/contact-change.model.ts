export class ContactChangeModel {
    isModalShown: boolean;
    shipmentList: Array<Object>;
    debounceValue: number;
    selected: boolean;
    subscribeFlag :boolean;
    customerList: any;
    customerLDCList: Array<Object>;
    addressFlag: boolean;
    shipmentNumber: string;
    mandatoryFlag: boolean;
    lineOfBusinessCode: number;
}