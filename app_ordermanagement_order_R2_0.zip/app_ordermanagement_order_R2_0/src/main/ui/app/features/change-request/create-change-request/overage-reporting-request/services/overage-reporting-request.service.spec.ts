import { inject, TestBed } from '@angular/core/testing';

import { OverageReportingRequestService } from './overage-reporting-request.service';

describe('OverageReportingRequestService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [OverageReportingRequestService]
    });
  });

  it('should be created', inject([OverageReportingRequestService], (service: OverageReportingRequestService) => {
    expect(service).toBeTruthy();
  }));
});
