import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Response } from '@angular/http';
import { JBHGlobals } from './../../../../../app.service';

@Injectable()
export class AddessChangeService {
constructor(private jbhGlobals: JBHGlobals) { }

addressChange (endpoint: string): Observable<Response[]> {
    return this.jbhGlobals.apiService.getData(endpoint);
  }

stateChange (endpoint: string): Observable<Response[]> {
    return this.jbhGlobals.apiService.getData(endpoint);
  }

  countryChange (endpoint: string): Observable<Response[]> {
    return this.jbhGlobals.apiService.getData(endpoint);
  }

  cityChange (endpoint: string): Observable<Response[]> {
    return this.jbhGlobals.apiService.getData(endpoint);
  }

  postalChange (code: string): Observable<Response[]> {
  const url = this.jbhGlobals.endpoints.changerequest.getPostalCode + '/' + code;
    return this.jbhGlobals.apiService.getData(url);
  }

 currentCustomerService(params): Observable<Response[]> {
        const url = this.jbhGlobals.endpoints.changerequest.currentCustomer;
        return this.jbhGlobals.apiService.addData(url, params);
    }
}
