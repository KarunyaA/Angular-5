export class ResultGridModel {
    rows: Array<Object>;
    selected;
    popOverFlag: boolean;
    columns: Array<Object>;
    splitScreenInputData;
    offset: number;
}
