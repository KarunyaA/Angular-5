import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ContactChangeRequestComponent } from './contact-change-request.component';

describe('ContactChangeRequestComponent', () => {
  let component: ContactChangeRequestComponent;
  let fixture: ComponentFixture<ContactChangeRequestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ContactChangeRequestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContactChangeRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
