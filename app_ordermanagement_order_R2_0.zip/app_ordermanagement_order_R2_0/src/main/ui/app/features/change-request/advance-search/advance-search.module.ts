import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SelectModule } from 'jbh-components/select';
import { IMyOptions, MyDatePickerModule } from 'mydatepicker';
import { ModalModule, PopoverModule, TypeaheadModule } from 'ngx-bootstrap';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { JBHDataTableModule } from 'jbh-components/jbh-data-table/jbh-data-table.module';
import { JbhValidationModule } from 'jbh-components';
import { AdvanceSearchRoutingModule } from './advance-search-routing.module';
import { AdvanceSearchComponent } from './advance-search.component';
import { ChangeRequestFilterComponent } from './change-request-filter/change-request-filter.component';
import { ChangeRequestResultGridComponent } from './change-request-result-grid/change-request-result-grid.component';
import { ChangeRequestFormBuilderService } from '../services/change-request-form-builder.service';
import { ManageColumnsModalComponent } from './manage-columns-modal/manage-columns-modal.component';

import { CreateChangeRequestModule } from '../create-change-request/create-change-request.module';

import { SortableModule } from 'ngx-bootstrap/sortable';
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { AddMoreComponent } from './change-request-filter/add-more/add-more.component';
import { AddLdcComponent } from './change-request-filter/add-ldc/add-ldc.component';
import { SavedSearchComponent } from './change-request-filter/saved-search/saved-search.component';
import { AdvanceSearchService } from './services/advance-search.service';

@NgModule({
  imports: [
    CommonModule,
    PopoverModule,
    ModalModule,
    MyDatePickerModule,
    SelectModule,
    BsDropdownModule,
    AdvanceSearchRoutingModule,
    JBHDataTableModule,
    FormsModule,
    ReactiveFormsModule,
    CreateChangeRequestModule,
    ModalModule.forRoot(),
    TypeaheadModule.forRoot(),
    JbhValidationModule.forRoot(),
    SortableModule.forRoot(),
    PerfectScrollbarModule
  ],
  declarations: [
    AdvanceSearchComponent,
    ChangeRequestFilterComponent,
    ChangeRequestResultGridComponent,
    ManageColumnsModalComponent,
    SavedSearchComponent,
    AddMoreComponent,
    AddLdcComponent
  ],
  providers: [ChangeRequestFormBuilderService, AdvanceSearchService],
  exports: [ChangeRequestFilterComponent,
    ChangeRequestResultGridComponent]
})
export class AdvanceSearchModule { }
