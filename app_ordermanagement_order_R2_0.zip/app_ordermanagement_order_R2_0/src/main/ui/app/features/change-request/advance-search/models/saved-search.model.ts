export class SavedSearchModel {
    removeSavedSearchMessage: string;
    removeSavedSearchStatus: string;
}
