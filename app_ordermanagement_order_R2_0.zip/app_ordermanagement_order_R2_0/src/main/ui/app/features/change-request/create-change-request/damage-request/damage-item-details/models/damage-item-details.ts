export class DamageItemDetailModel {
  damageTypeList: Array<Object>;
  damageType: any;
  ladingNumber: string;
  modelNumber: string;
  serialNumber: string;
  uploadFile: Array<Object>;
  fileAttachArray: Array<Object>;
  subscribeFlag: boolean;
  addItemFlag: boolean;
  editForm: boolean;
  itemForm: boolean;
  itemFormFlag: boolean;
  requestUploadFile: any;
  attachFile: boolean;
  fileLabelFlag: boolean;
}
