import { inject, TestBed } from '@angular/core/testing';

import { DamageRequestService } from './damage-request.service';

describe('DamageRequestService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DamageRequestService]
    });
  });

  it('should be created', inject([DamageRequestService], (service: DamageRequestService) => {
    expect(service).toBeTruthy();
  }));
});
