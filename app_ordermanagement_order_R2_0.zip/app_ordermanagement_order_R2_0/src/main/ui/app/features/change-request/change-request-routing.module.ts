import { NgModule } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';

import { ChangeRequestComponent } from './change-request.component';
import { CreateChangeRequestComponent } from './create-change-request/create-change-request.component';
import { AddressChangeRequestComponent } from './create-change-request/address-change-request/address-change-request.component';
import { ContactChangeRequestComponent } from './create-change-request/contact-change-request/contact-change-request.component';
import { ServiceChangeRequestComponent } from './create-change-request/service-change-request/service-change-request.component';
import { OverageReportingRequestComponent } from './create-change-request/overage-reporting-request/overage-reporting-request.component';
import { ShortageReportingRequestComponent } from './create-change-request/shortage-reporting-request/shortage-reporting-request.component';
import { DamageRequestComponent } from './create-change-request/damage-request/damage-request.component';
import { PickupRequestComponent } from './create-change-request/pickup-request/pickup-request.component';
import { AdvanceSearchComponent } from './advance-search/advance-search.component';
import { AdvanceSearchModule } from './advance-search/advance-search.module';
import { ViewChangeRequestModule } from './view-change-request/view-change-request.module';
import { ViewBySearchComponent } from './view-change-request/view-by-search/view-by-search.component';
import { ViewByOrderComponent } from './view-change-request/view-by-order/view-by-order.component';

const routes: Routes = [
  {
    path: '',
    loadChildren: './advance-search/advance-search.module#AdvanceSearchModule'
  },
  {
    path: 'viewrequest',
    component: ViewBySearchComponent
  },
  {
    path: 'viewchangerequest',
    component: ViewByOrderComponent
  }
];

@NgModule({
  imports: [ReactiveFormsModule,
    FormsModule,
    RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ChangeRequestRoutingModule { }
