import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Response } from '@angular/http';
import * as moment from 'moment';

import { JBHGlobals } from '../../../../../app.service';
@Injectable()
export class DamageRequestService {

    constructor(private jbhGlobals: JBHGlobals) { }

    loadDamageType(endpoint: string): Observable<Response[]> {
        return this.jbhGlobals.apiService.getData(endpoint);
    }
    getCarrierService(endpoint: string, params: object): Observable<Response[]> {
        return this.jbhGlobals.apiService.getData(endpoint, params);
    }
    createRequestForm(model: object): any {
        const json = {
            'changeRequestCreatorID': 1457,
            'orderID': null,
            // 'distributionFacilityProfileID': 1,
            'distributionFacilityProfileID': model['facilityProfileId'],
            'changeRequestType': {
                'changeRequestTypeCode': 'DamageRpt'
            },
            'changeRequestStatus': {
                'changeRequestStatusCode': 'Pending'
            },
            'billingPartyID': model['billPartyId'],
            'changeRequestRequesterID': 2466758,
            'shipmentDiscrepancyNotificationRequests': []
        }
        return json;
    }
    createHeaderEntity(damageDetails: object, itemDetails: object): object {
        if (!this.jbhGlobals.utils.isValueEmpty(damageDetails)) {
            const itemLength = itemDetails['controls'].length;
            const damageData = damageDetails['controls'];
            let status;
            if (damageData['status'].value) {
                status = damageData['status'].value[0]['id'];
            }
            const obj = {
                'carrierName': damageData['carrier'].value ? damageData['carrier'].value : '',
                'customerTrailerNumber': damageData['trailerNo'].value ? damageData['trailerNo'].value : '',
                'inboundCarrierBillOfLadingNumber': damageData['inboundCarrierBOLNo'].value ? damageData['inboundCarrierBOLNo'].value : '',
                'shipmentArrivalDate': this.setDateFormat(damageData),
                'itemDiscrepancyQuantity': itemLength ? itemLength : 0,
                'carrierNotedDiscrepancyIndicator': damageData['OSDRadio'].value === 'yes' ? 'Y' : 'N',
                "shipmentStatusType": {
                    "shipmentStatusTypeCode": status
                }
            };
            return obj;
        }
    }
    private setDateFormat(damageData: object): string {
        if (!this.jbhGlobals.utils.isValueEmpty(damageData)) {
            const value = damageData['arrivalDate'] ? damageData['arrivalDate'].value : null;
            if (!this.jbhGlobals.utils.isValueEmpty(value) && value.formatted) {
                return moment(new Date(value.formatted)).format('YYYY-MM-DD');
            }
        }
    }
}
