import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Response } from '@angular/http';

import * as moment from 'moment';

import { JBHGlobals } from '../../../../../app.service';

@Injectable()
export class OverageReportingRequestService {
  constructor(private jbhGlobals: JBHGlobals) { }
  getOverageReportTypeService(endpoint: string): Observable<Response[]> {
    return this.jbhGlobals.apiService.getData(endpoint);
  }
  getCarrierService(endpoint: string, params: object): Observable<Response[]> {
    return this.jbhGlobals.apiService.getData(endpoint, params);
  }
  createRequestForm(model: object): any {
    const json = {
      'changeRequestCreatorID': 1457,
      'orderID': null,
      'distributionFacilityProfileID': model['facilityProfileId'],
      // 'distributionFacilityProfileID': 1,
      'changeRequestType': {
        'changeRequestTypeCode': 'OvrageRpt'
      },
      'changeRequestStatus': {
        'changeRequestStatusCode': 'Pending'
      },
      'billingPartyID': model['billPartyId'],
      'changeRequestRequesterID': 2466758,
      'shipmentDiscrepancyNotificationRequests': []
    }
    return json;
  }
  createHeaderEntity(overageDetails: object, itemDetails: object): any {
    if (!this.jbhGlobals.utils.isValueEmpty(overageDetails)) {
      const itemLength = itemDetails['controls'].length;
      const overageData = overageDetails['controls'];
      let status;
      if (overageData['status'].value) {
        status = overageData['status'].value[0]['id'];
      }
      const obj = {
        'carrierName': overageData['carrier'].value ? overageData['carrier'].value : '',
        'customerTrailerNumber': overageData['trailerNo'].value ? overageData['trailerNo'].value : '',
        'inboundCarrierBillOfLadingNumber': overageData['inboundCarrierBOLNo'].value ? overageData['inboundCarrierBOLNo'].value : '',
        'shipmentArrivalDate': this.setDateFormat(overageData),
        'itemDiscrepancyQuantity': itemLength ? itemLength : 0,
        'carrierNotedDiscrepancyIndicator': overageData['OSDRadio'].value === 'yes' ? 'Y' : 'N',
        'shipmentStatusType': {
          'shipmentStatusTypeCode': status
        }
      };
      return obj;
    }
  }
  private setDateFormat(overageData: object): string {
    if (!this.jbhGlobals.utils.isValueEmpty(overageData)) {
      const value = overageData['arrivalDate'] ? overageData['arrivalDate'].value : null;
      if (!this.jbhGlobals.utils.isValueEmpty(value) && value.formatted) {
        return moment(new Date(value.formatted)).format('YYYY-MM-DD');
      }
    }
  }
}
