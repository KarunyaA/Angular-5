export class PickupRequestModel {
    returnReason: Array < Object >
    damageCategory: Array < Object >;
    damageLocation: Array < Object >;
    damageLocationCode: Array < Object >;
    subscribeFlag: boolean;
    currentCustomerList: Array < Object >;
    currentLDCList: Array < Object >;
    damageType: Array < Object >;
    damageSource: Array < Object >;
    damageCause: Array < Object >;
    damageNoticed: Array < Object >;
    damagePoint: Array < Object >;
    closeModalFlag: boolean;
    showDamageDropdownFlag: boolean;
    unitOfWeight: Array < Object >;
    unitOfMeasurement: Array < Object >;
    brandName: Array < Object >;
    customerError: boolean;
    currentLDCerror: boolean;
}
