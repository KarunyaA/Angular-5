import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddLdcComponent } from './add-ldc.component';

describe('AddLdcComponent', () => {
  let component: AddLdcComponent;
  let fixture: ComponentFixture<AddLdcComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddLdcComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddLdcComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
