import { TestBed, inject } from '@angular/core/testing';

import { AddessChangeService } from './addess-change.service';

describe('AddessChangeService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AddessChangeService]
    });
  });

  it('should be created', inject([AddessChangeService], (service: AddessChangeService) => {
    expect(service).toBeTruthy();
  }));
});
