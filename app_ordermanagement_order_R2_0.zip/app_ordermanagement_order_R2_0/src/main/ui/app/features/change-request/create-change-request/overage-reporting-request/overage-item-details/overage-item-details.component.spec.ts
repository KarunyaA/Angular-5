import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OverageItemDetailsComponent } from './overage-item-details.component';

describe('OverageItemDetailsComponent', () => {
  let component: OverageItemDetailsComponent;
  let fixture: ComponentFixture<OverageItemDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OverageItemDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OverageItemDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
