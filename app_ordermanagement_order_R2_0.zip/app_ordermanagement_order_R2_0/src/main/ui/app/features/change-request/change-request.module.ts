import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { ModalModule, PopoverModule } from 'ngx-bootstrap';
import { SelectModule } from 'jbh-components/select';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { IMyOptions, MyDatePickerModule } from 'mydatepicker';

import * as moment from 'moment';

import { ConfirmationPopupModule } from 'jbh-components/confirmation-popup/confirmation-popup.module';
import { ChangeRequestRoutingModule } from './change-request-routing.module';
import { ChangeRequestFormBuilderService } from './services/change-request-form-builder.service';
import { ChangeRequestComponent } from './change-request.component';
import { AdvanceSearchModule } from './advance-search/advance-search.module';
import { TypeaheadModule } from 'jbh-components/jbh-typeahead';
import { JBHDataTableModule } from 'jbh-components/jbh-data-table/jbh-data-table.module';
import { CreateChangeRequestModule } from './create-change-request/create-change-request.module';
import { ViewChangeRequestModule } from './view-change-request/view-change-request.module';
import { SharedComponentsModule } from './shared-components/shared-components.module';
import { ViewChangeRequestService } from './services/view-change-request.service';
import { CustomerAppointmentComponent } from './customer-appointment/customer-appointment.component';
import { AppoitmentsColumnsComponent } from './customer-appointment/appoitments-columns/appoitments-columns.component';
import { ReferenceDataComponent } from './customer-appointment/reference-data/reference-data.component';

@NgModule({
  imports: [
    CommonModule,
    ModalModule,
    PopoverModule,
    SelectModule,
    ReactiveFormsModule,
    FormsModule,
    ChangeRequestRoutingModule,
    CreateChangeRequestModule,
    ViewChangeRequestModule,
    SharedComponentsModule,
    JBHDataTableModule,
    MyDatePickerModule,
    AdvanceSearchModule,
    ConfirmationPopupModule,
    TypeaheadModule.forRoot(),
    BsDropdownModule.forRoot()
  ],
  declarations: [
    ChangeRequestComponent,
    CustomerAppointmentComponent,
    AppoitmentsColumnsComponent,
    ReferenceDataComponent],
  providers: [ChangeRequestFormBuilderService, ViewChangeRequestService],
  exports: [SharedComponentsModule]
})
export class ChangeRequestModule { }
