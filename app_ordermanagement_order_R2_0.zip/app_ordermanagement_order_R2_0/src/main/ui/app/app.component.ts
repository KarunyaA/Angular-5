import { Component, EventEmitter, HostListener, NgZone, OnInit, Output } from '@angular/core';
import {
    Event as RouterEvent, NavigationCancel, NavigationEnd,
    NavigationError, NavigationStart, Router
} from '@angular/router';
import { Location } from '@angular/common';
import { SpinnerService } from 'jbh-components/spinner';
import { BusinessUnitService, ProfileService, UserService } from 'jbh-components/jbh-esa';

import { JBHGlobals } from './app.service';

declare var JBH360Platform: any;
window.focus();

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.scss']
})

export class AppComponent implements OnInit {
    // @Output() overlayShowEvent: EventEmitter<boolean> = new EventEmitter<boolean>();
    @Output() notificationEvent: EventEmitter<boolean> = new EventEmitter<boolean>();

    sidebarLock: boolean;
    navIconClicked: false;
    isSidebarOpen: boolean;
    loading = true;
    commonData: any;
    options: Object;
    sidebarLockRight: boolean;
    showWindow = false;
    isAppHeaderHidden = true;
    isShowToolsHidden = true;
    logoutClk: any;
    isShowHeader: boolean;

    constructor(
        private router: Router,
        location: Location,
        private jbhGlobals: JBHGlobals,
        private spinnerService: SpinnerService,
        private ngZone: NgZone,
        private profileService: ProfileService,
        private userService: UserService,
        public businessUnitService: BusinessUnitService) {
        jbhGlobals.logger.info('Approot  initialized');
    }

    ngOnInit(): void {
        console.log('user details', this.jbhGlobals.user.userDetails);
        this.isShowHeader = true;
        this.setUserPage(this.jbhGlobals.user.getAuthenticationStatus());
        this.businessUnitService.loadBusinessUnit(this.jbhGlobals.endpoints.order.getbusinessunit);
        this.router.events.subscribe((event: RouterEvent) => {
            this.navigationInterceptor(event);
        });
        this.options = this.jbhGlobals.settings.notificationsOptions;
        this.jbhGlobals.commonDataService.getData().subscribe(data => this.commonData = data);
        this.loadUserRolesAndTasks();
        this.isShowHeader = false;
        this.initHeader();
        this.manageOverlayToggle();
    }

    @HostListener('window:keyup', ['$event'])
    keyboardInput(event: any): void {
        console.log(this.jbhGlobals.shortkeys.getKeyCode(event));
        this.jbhGlobals.shortkeys.saveData({
            keyCode: this.jbhGlobals.shortkeys.getKeyCode(event),
            eventElement: event.target
        });
    }

    @HostListener('window:click', ['$event'])
    trackAppClick(event: Event): void {
        this.jbhGlobals.mouseevents.saveData({
            target: this.jbhGlobals.mouseevents.getTarget(event)
        });
    }
    toggleMobleSidebar(e): void {
        this.isSidebarOpen = e;
        this.sidebarLock = e;
    }
    onLockSideBarRight(event): void {
        this.sidebarLockRight = event;
    }
    showRightNavigation(event): void {
        this.navIconClicked = event;
        if (event === false) {
            this.sidebarLockRight = false;
        }
    }
    manageOverlayToggle(): void {
        this.showWindow = !this.showWindow;
        const overlayFlag = {
            'headerOverlay': this.showWindow
        };
        this.jbhGlobals.commonDataService.saveData(overlayFlag);
    }
    onLockSideBar(e): void {
        this.sidebarLock = e;
    }

    setUserPage(status): void {
        switch (status) {
            case 200: break;
            case 401:
            case 404:
            case 500: this.router.navigateByUrl(`error/${status}`); break;
            default: this.router.navigateByUrl('error/401'); break;
        }
    }

    navigationInterceptor(event: RouterEvent): void {
        if (event instanceof NavigationStart) {
            this.jbhGlobals.logger.log('Naviagation start');
            this.jbhGlobals.apiService.requestCount = 0;
            this.spinnerService.spinnerText = 'Loading Page Components ...';
            if (!this.spinnerService.showStatus) {
                this.spinnerService.show();
            }
            this.jbhGlobals.notifications.remove();
        } else if (event instanceof NavigationEnd) {
            this.jbhGlobals.logger.log('Naviagation end');
            if (this.jbhGlobals.apiService.requestCount === 0) {
                this.spinnerService.hide();
            }
        } else if (event instanceof NavigationCancel) {
            this.jbhGlobals.logger.log('Naviagation NavigationCancel');
            this.spinnerService.hide();
            this.jbhGlobals.apiService.requestCount = 0;
        } else if (event instanceof NavigationError) {
            this.jbhGlobals.logger.log('Naviagation NavigationError');
            this.spinnerService.hide();
            this.jbhGlobals.apiService.requestCount = 0;
        }
    }

    loadUserRolesAndTasks(): void {
        this.profileService.loadUserRolesAndTasks(this.jbhGlobals, this.userService);
    }
    private initHeader(): void {
        const config = {
            hamburgerClickFunction: () => {
                this.ngZone.run(() => {
                    this.isSidebarOpen = !this.isSidebarOpen;
                    this.toggleMobleSidebar(this.isSidebarOpen);
                });
            }
        };
        try {
            JBH360Platform.init(config);
        } catch (error) {
            this.isAppHeaderHidden = false;
            this.isShowHeader = true;
        }
    }
}
