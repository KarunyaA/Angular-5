package com.jbhunt.ordermanagement.configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.MethodInvokingFactoryBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.jbhunt.biz.securepid.FusePIDReader;
import com.jbhunt.biz.securepid.PIDCredentials;
import com.jbhunt.contact.factory.GetPhoneCallRequestFactory;
import com.jbhunt.contact.factory.GetStandardCodeRequestFactory;
import com.jbhunt.contact.factory.SavePhoneCallRequestFactory;
import com.jbhunt.hrms.EOIAPIUtil.apiutil.EOIAPIUtil;
import com.jbhunt.hrms.EOIAPIUtil.util.AuditInformation;

import lombok.extern.slf4j.Slf4j;

import javax.servlet.Filter;

@Slf4j
@Configuration
public class OrderConfiguration {

	@Value("${spring.application.name}")
	private String applicationName;

	@Bean
	public EOIAPIUtil eoiapiUtil() {
		return new EOIAPIUtil(new AuditInformation(jbhLdapCredentials().getUsername(), applicationName));
	}

	@Bean
	public PIDCredentials jbhLdapCredentials() {
		 FusePIDReader fusePIDReader = new FusePIDReader("app_ordermanagement_supplychainmanagement");
	     return fusePIDReader.readPIDCredentials("ldapresource");
	}

	@Bean
	public GetPhoneCallRequestFactory getPhoneCallRequestFactory() {
		return new GetPhoneCallRequestFactory();
	}

	@Bean
	public GetStandardCodeRequestFactory getStandardCodeRequestFactory() {
		return new GetStandardCodeRequestFactory();
	}

	@Bean
	public SavePhoneCallRequestFactory savePhoneCallRequestFactory() {
		return new SavePhoneCallRequestFactory();
	}

	@Bean
	public MethodInvokingFactoryBean methodInvokingFactoryBean() {		
		try{			
			MethodInvokingFactoryBean methodInvokingFactoryBean = new MethodInvokingFactoryBean();
			methodInvokingFactoryBean.setStaticMethod("com.jbhunt.contact.ContactPortFactory.getPortStub");
			return methodInvokingFactoryBean;
		}catch (Exception exception){			
			log.info("Error in contacting services");
		}
		return null;
	}
}
