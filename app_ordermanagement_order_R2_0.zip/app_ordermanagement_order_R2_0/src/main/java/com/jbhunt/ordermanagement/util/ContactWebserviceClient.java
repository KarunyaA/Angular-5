package com.jbhunt.ordermanagement.util;

import static com.jbhunt.ordermanagement.constants.OrderConstants.RECORD_STATUS;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.datacontract.schemas._2004._07.com_jbhunt_apps_contact_model.StandardCodeTypesStandardCode;
import org.springframework.stereotype.Component;

import com.jbhunt.contact.IContactWebService;
import com.jbhunt.contact.entities.PhoneCallVO;
import com.jbhunt.contact.entities.StandardCodeVO;
import com.jbhunt.contact.factory.GetPhoneCallRequestFactory;
import com.jbhunt.contact.factory.GetStandardCodeRequestFactory;
import com.jbhunt.contact.factory.SavePhoneCallRequestFactory;
import com.jbhunt.contact.requestresponseobjects.GetPhoneCallsRequest;
import com.jbhunt.contact.requestresponseobjects.GetPhoneCallsResponse;
import com.jbhunt.contact.requestresponseobjects.GetStandardCodesRequest;
import com.jbhunt.contact.requestresponseobjects.GetStandardCodesResponse;
import com.jbhunt.contact.requestresponseobjects.SavePhoneCallResponse;
import com.jbhunt.contact.requestresponseobjects.SavePhoneCallsRequest;
import com.jbhunt.ordermanagement.properties.OrderProperties;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ContactWebserviceClient {

	private IContactWebService iContactWebService;
	private OrderProperties orderProperties;
	private GetPhoneCallRequestFactory getPhoneCallRequestFactory;
	private GetStandardCodeRequestFactory getStandardCodeRequestFactory;
	private SavePhoneCallRequestFactory savePhoneCallRequestFactory;

	public ContactWebserviceClient(OrderProperties orderProperties,
			GetPhoneCallRequestFactory getPhoneCallRequestFactory,
			GetStandardCodeRequestFactory getStandardCodeRequestFactory,
			SavePhoneCallRequestFactory savePhoneCallRequestFactory, IContactWebService iContactWebService) {
		this.orderProperties = orderProperties;
		this.getPhoneCallRequestFactory = getPhoneCallRequestFactory;
		this.getStandardCodeRequestFactory = getStandardCodeRequestFactory;
		this.savePhoneCallRequestFactory = savePhoneCallRequestFactory;
		this.iContactWebService = iContactWebService;
	}

	public List<PhoneCallVO> getPhoneCallRequest(List<String> trackingNumbers) {
		log.debug("Inside the method getPhoneCallRequest()");
		GetPhoneCallsRequest request = getPhoneCallRequestFactory.getPhoneCallByTrackingNumbers(trackingNumbers);
		GetPhoneCallsResponse response = iContactWebService.getPhoneCalls(request);
		return response.getPhoneCalls().getPhoneCallVO();

	}

	@HystrixCommand(fallbackMethod = "populateCallIntentStaticValues")
	public List<StandardCodeVO> getStatusCodesForCallIntent() {
		log.debug("Inside the method getStatusCodesForCallIntent()");
		GetStandardCodesRequest request = getStandardCodeRequestFactory
				.getStandardCodesRequest(StandardCodeTypesStandardCode.CALL_INTENT);
		GetStandardCodesResponse response = iContactWebService.getStandardCodes(request);
		List<StandardCodeVO> codeList = new ArrayList<>();
		Optional.ofNullable(response).map(GetStandardCodesResponse::getStandardCodes)
				.ifPresent(codes -> codeList.addAll(codes.getStandardCodeVO()));
		return codeList;
	}

	@HystrixCommand(fallbackMethod = "populateCallResultStaticValues")
	public List<StandardCodeVO> getStatusCodesForCallResult() {
		log.debug("Inside the method getStatusCodesForCallResult()");
		GetStandardCodesRequest request = getStandardCodeRequestFactory
				.getStandardCodesRequest(StandardCodeTypesStandardCode.CALL_RESULT);
		GetStandardCodesResponse response = iContactWebService.getStandardCodes(request);
		List<StandardCodeVO> codeList = new ArrayList<>();
		Optional.ofNullable(response).map(GetStandardCodesResponse::getStandardCodes)
				.ifPresent(codes -> codeList.addAll(codes.getStandardCodeVO()));
		return codeList;
	}

	@HystrixCommand(fallbackMethod = "populateCallDirectionStaticValues")
	public List<StandardCodeVO> getStatusCodesForCallDirection() {
		log.debug("Inside the method getStatusCodesForCallDirection()");
		GetStandardCodesRequest request = getStandardCodeRequestFactory
				.getStandardCodesRequest(StandardCodeTypesStandardCode.CALL_DIRECTION);
		GetStandardCodesResponse response = iContactWebService.getStandardCodes(request);
		List<StandardCodeVO> codeList = new ArrayList<>();
		Optional.ofNullable(response).map(GetStandardCodesResponse::getStandardCodes)
				.ifPresent(codes -> codeList.addAll(codes.getStandardCodeVO()));
		return codeList;
	}

	public List<PhoneCallVO> savePhoneCalls(List<PhoneCallVO> phoneCalls) {
		log.debug("Inside the method savePhoneCalls()");
		SavePhoneCallsRequest request = savePhoneCallRequestFactory.savePhoneCallsRequest(phoneCalls);
		request.setUpdateAssociations(true);
		SavePhoneCallResponse response = iContactWebService.savePhoneCalls(request);
		return response.getPhoneCalls().getPhoneCallVO();
	}

	public List<StandardCodeVO> populateCallIntentStaticValues() {
		return getStandardCodeVO(StandardCodeTypesStandardCode.CALL_INTENT);
	}

	public List<StandardCodeVO> populateCallResultStaticValues() {
		return getStandardCodeVO(StandardCodeTypesStandardCode.CALL_RESULT);
	}

	public List<StandardCodeVO> populateCallDirectionStaticValues() {
		return getStandardCodeVO(StandardCodeTypesStandardCode.CALL_DIRECTION);
	}

	private List<StandardCodeVO> getStandardCodeVO(StandardCodeTypesStandardCode code) {
		log.debug("loading static values for code" + code.value());
		List<StandardCodeVO> standardCodeVo = new ArrayList<>();
		Map<String, Map<String, String>> val = orderProperties.getContactStatusCodesTypes().stream()
				.flatMap(
						mapping -> mapping.entrySet().stream().filter(ma -> ma.getKey().equalsIgnoreCase(code.value())))
				.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
		if (Optional.of(val).isPresent()) {
			val.entrySet().forEach(items -> items.getValue().forEach((key, value) -> {
				StandardCodeVO standardCodeVO = new StandardCodeVO();
				standardCodeVO.setCode(key);
				standardCodeVO.setPresentationName(value);
				standardCodeVO.setRecordStatus(RECORD_STATUS);
				standardCodeVo.add(standardCodeVO);
			}));
		}
		return standardCodeVo;
	}

}
