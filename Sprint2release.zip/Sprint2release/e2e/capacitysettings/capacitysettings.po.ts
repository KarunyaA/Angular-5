import { browser, by, element } from 'protractor';

export class CapacitySettingsPage {
    navigateTo() {
        return browser.get('/loads/capacitysettings');
    }

    getHeaderText() {
        return element(by.tagName('h3')).getText();
    }

    getJBITabText() {
        return element(by.css('p-tabPanel[header="JBI Inbound Limits"]')).getAttribute('header');
    }

    getJBITabDropDownText() {
        const tab = element(by.css('p-tabPanel[header="JBI Inbound Limits"]'));
        const dropdown = tab.element(by.css('p-dropdown[id="inboundType"]'));
        return dropdown.getText();
    }
}
