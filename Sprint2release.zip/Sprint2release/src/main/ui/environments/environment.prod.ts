export const environment = {
  production: true,
  envName: 'prod'
};
