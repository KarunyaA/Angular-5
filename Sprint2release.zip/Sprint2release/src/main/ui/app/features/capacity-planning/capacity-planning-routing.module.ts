import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CapacityPlanningComponent } from './capacity-planning/capacity-planning.component';
import { EmptyplanCreateComponent } from './emptyplan/emptyplan-create/emptyplan-create.component';

const routes: Routes = [
  { path: '', component: CapacityPlanningComponent },
  { path: 'createemptylane', component: EmptyplanCreateComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class CapacityPlanningRoutingModule { }
