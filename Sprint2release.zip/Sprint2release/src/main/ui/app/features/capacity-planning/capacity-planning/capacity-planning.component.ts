import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-capacity-planning',
  templateUrl: './capacity-planning.component.html',
  styleUrls: ['./capacity-planning.component.scss']
})
export class CapacityPlanningComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
}
