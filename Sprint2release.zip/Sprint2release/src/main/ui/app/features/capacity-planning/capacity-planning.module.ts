import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { TabViewModule } from 'primeng/tabview';
import { DropdownModule } from 'primeng/dropdown';
import { BreadcrumbModule } from 'primeng/breadcrumb';
import { ButtonModule } from 'primeng/button';
import { MenuModule } from 'primeng/menu';
import { MenuItem } from 'primeng/api';
import { TableModule } from 'primeng/table';
import { AccordionModule } from 'primeng/accordion';
import { CheckboxModule } from 'primeng/checkbox';
import { RadioButtonModule } from 'primeng/radiobutton';
import { AutoCompleteModule } from 'primeng/autocomplete';
import {InputTextModule} from 'primeng/inputtext';

import { CapacityPlanningRoutingModule } from './capacity-planning-routing.module';
import { CapacityPlanningComponent } from './capacity-planning/capacity-planning.component';
import { EmptyplanListComponent } from './emptyplan/emptyplan-list/emptyplan-list.component';
import { EmptyplanEditComponent } from './emptyplan/emptyplan-edit/emptyplan-edit.component';
import { EmptyplanCreateComponent } from './emptyplan/emptyplan-create/emptyplan-create.component';
import { BreadcrumbComponent } from './breadcrumb/breadcrumb.component';
import { EmptyplanCreateService } from './../capacity-planning/emptyplan/emptyplan-create/services/emptyplan-create.service';

@NgModule({
  imports: [
    CommonModule,
    CapacityPlanningRoutingModule,
    TabViewModule,
    DropdownModule,
    BreadcrumbModule,
    ButtonModule,
    MenuModule,
    TableModule,
    AccordionModule,
    CheckboxModule,
    RadioButtonModule,
    AutoCompleteModule,
    FormsModule,
    ReactiveFormsModule,
    InputTextModule
  ],
  declarations: [
    CapacityPlanningComponent,
    EmptyplanListComponent,
    EmptyplanEditComponent,
    EmptyplanCreateComponent,
    BreadcrumbComponent],
  providers: [EmptyplanCreateService]
})

export class CapacityPlanningModule { }
