import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Params, Router } from '@angular/router';

import * as _ from 'lodash';

import { EmptyplanCreateService } from './services/emptyplan-create.service';
import { EmptyplanCreateModel } from './model/emptyplan-create.model';

@Component({
  selector: 'app-emptyplan-create',
  templateUrl: './emptyplan-create.component.html',
  styleUrls: ['./emptyplan-create.component.scss']
})

export class EmptyplanCreateComponent implements OnInit, OnDestroy {

  createModel: EmptyplanCreateModel;

  constructor(private fb: FormBuilder, private service: EmptyplanCreateService, private route: ActivatedRoute) {
    this.createModel = new EmptyplanCreateModel();
  }

  ngOnInit(): void {
    this.createModel.initailizedObject();
    this.createModel.getDateParams = this.route.queryParams.subscribe(params => {
      this.createModel.dateObj.fromDate = params['fromDate'];
      this.createModel.dateObj.toDate = params['toDate'];
    });
    this.searchGroup();
  }

  // NgOn Destroy
  ngOnDestroy(): void {
    this.createModel.getDateParams.unsubscribe();
  }

  // Initializing The FromGroup
  searchGroup(): void {
    this.createModel.searchForm = this.fb.group({
      originRampGroup: ['', Validators.required],
      destinationRampGroup: ['', Validators.required]
    });
  }

  // Get Function Of Ramp Group
  getRampGroup(event: any): void {
    if (this.createModel.searchForm.controls.originRampGroup.value) {
      this.createModel.validFormOrigin = false;
    }
    if (this.createModel.searchForm.controls.destinationRampGroup.value) {
      this.createModel.validFormDestination = false;
    }
    const typeaheadParams: object = {
      'input': `${event.query.replace(/[,!?^~=\/{}&&||<>()+*-]/g, ' ')}${'*'}`
    };
    this.createModel.elasticParam = this.createModel.getRampQuery(typeaheadParams);
    this.service.getOriginValue(this.createModel.elasticParam).subscribe(data => {
      if (data && data['hits'] && data['hits']['hits']) {
        const listData = data['hits']['hits'];
        const listValues = [];
        listData.forEach((element: any) => {
          listValues.push({
            id: element._source.RampGroup,
            text: element._source.RampGroup
          });
        });
        this.createModel.rampSuggession = listValues;
      }
    });
  }

  // Search Form
  onShowData(): void {
    if (this.createModel.searchForm.controls.originRampGroup.valid && this.createModel.searchForm.controls.destinationRampGroup.valid) {
      this.createModel.isSearchCompleted = 1;
      const searchTypeaheadParams: object = {
        'origin': this.createModel.searchForm.controls.originRampGroup.value,
        'destination': this.createModel.searchForm.controls.destinationRampGroup.value,
        'dateStart': this.createModel.dateObj.fromDate,
        'dateEnd': this.createModel.dateObj.toDate
      };
      this.createModel.searchParam = this.createModel.getSearchValue(searchTypeaheadParams);
      this.service.getOriginValue(this.createModel.searchParam).subscribe(data => {
      });
    } else {
      this.createModel.validFormOrigin = !this.createModel.searchForm.controls.originRampGroup.valid;
      this.createModel.validFormDestination = !this.createModel.searchForm.controls.destinationRampGroup.valid;
    }
  }

  // Show Data Value
  onShowDataValue(val) {
    this.createModel.availableEmptyLanesMaster = this.createModel.availableEmptyLanes;
    this.createModel.availableEmptyLanes = this.createModel.availableEmptyLanes.filter(
      (firstObj) => this.createModel.selectedEmptyLanes.filter(
        (secondObj) => secondObj['id'] === firstObj['id']).length === 0);
    this.createModel.addLanes = this.createModel.selectedEmptyLanes;
  }

  // Reset The Form
  onReset() {
    this.createModel.searchForm.reset();
    this.createModel.addLanes = [];
    this.createModel.availableEmptyLanes = this.createModel.availableEmptyLanesMaster;
  }

  // Close Function
  onCloseEvent(selectedOriginValue: any) {
    const elementPos = this.createModel.addLanes.map(function (thisObj) {
      return thisObj['id'];
    }).indexOf(selectedOriginValue.id);
    const objectFound = this.createModel.addLanes[elementPos];
    if (elementPos > -1) {
      this.createModel.addLanes.splice(elementPos, 1);
      this.createModel.availableEmptyLanes.push(selectedOriginValue);
    }
  }
}
