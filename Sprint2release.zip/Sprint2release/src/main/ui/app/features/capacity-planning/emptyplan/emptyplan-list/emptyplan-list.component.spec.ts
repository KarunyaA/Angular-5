import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { APP_BASE_HREF } from '@angular/common';

import { AppModule } from '../../../../app.module';
import { EmptyplanListComponent } from './emptyplan-list.component';
import { CapacityPlanningModule } from '../../capacity-planning.module';

describe('EmptyplanListComponent', () => {
  let component: EmptyplanListComponent;
  let fixture: ComponentFixture<EmptyplanListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule, CapacityPlanningModule],
      declarations: [],
      providers: [{ provide: APP_BASE_HREF, useValue: '/' }]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmptyplanListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

});
