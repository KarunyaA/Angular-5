import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Data } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/catch';

import { AppConfig } from 'config/app.config';
import { AppLocalConfig } from 'config/app.local.config';
import { environment } from 'environments/environment';
import { SpinnerService } from 'app/shared/spinner/index';


@Injectable()
export class EmptyplanCreateService {

  appConfig = (environment.envName === 'local') ? AppLocalConfig.getConfig() : AppConfig.getConfig();

  constructor(private spinnerService: SpinnerService, private http: HttpClient) { }

  // Elastic Search Call
  getOriginValue(query: object): Observable<any> {
    return this.addData(this.appConfig.api.capacityPlanning.getOrigin, query, true);
  }

  // Post Method
  addData(url, body: Object, headers?: any): Observable<any[]> {
    this.spinnerService.show();
    this.spinnerService.spinnerText = 'Processing Service Requests ...';
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Cache-Control': 'no-cache',
        'Pragma': 'no-cache'
      })
    };

    const bodyString = JSON.stringify(body);
    return this.http.post<any>(url, bodyString, httpOptions).map((res: any) => {
      this.spinnerService.hide();
      return res;
    }).catch((err: HttpErrorResponse) => {
      this.spinnerService.hide();
      return err.error;
    });
  }
}
