export class EmptyplanEditModel {

}
