import { TestBed, inject } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { APP_BASE_HREF } from '@angular/common';

import { AppModule } from '../../../../../app.module';
import { EmptyplanEditService } from './emptyplan-edit.service';

describe('EmptyplanEditService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule],
      declarations: [],
      providers: [EmptyplanEditService, { provide: APP_BASE_HREF, useValue: '/' }]
    });
  });

  it('should be created', inject([EmptyplanEditService], (service: EmptyplanEditService) => {
    expect(service).toBeTruthy();
  }));

});
