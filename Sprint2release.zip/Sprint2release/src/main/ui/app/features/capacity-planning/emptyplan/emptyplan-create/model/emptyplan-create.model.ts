import { FormGroup } from '@angular/forms';

export class EmptyplanCreateModel {
  addLanes: Array<object>;
  availableEmptyLanes: Array<object>;
  availableEmptyLanesMaster: Array<object>;
  viewValues: Array<object>;
  addValues: Array<object>;
  dateObj: any;
  elasticParam: object;
  getDateParams: any;
  isSearchCompleted: number;
  items: Array<object>;
  queryRamp: object;
  querySearch: object;
  rampSuggession: Array<object>;
  searchForm: FormGroup;
  searchParam: object;
  selectedAddLanes: Array<object>;
  selectedEmptyLanes: Array<object>;
  selectedLanes: Array<object>;
  validFormDestination: boolean;
  validFormOrigin: boolean;

  // Initialising Model
  initailizedObject(): void {
    this.validFormDestination = false;
    this.validFormOrigin = false;
    this.dateObj = { 'fromDate': null, 'toDate': null };
    this.isSearchCompleted = 0;
    this.items = [
      { label: 'Home', routerLink: ['/dashboard'] },
      { label: 'Capacity Planning', routerLink: ['/capacityplanning'] },
      { label: 'Add Empty Lanes', routerLink: ['/capacityplanning/createemptylane'] }];

    this.availableEmptyLanes = [
      { id: 1, cost: '$194.00', destination: 'Chicago North', multi: 'No', origin: 'Albany North', status: 'Available' },
      { id: 2, cost: '$294.00', destination: 'Chicago South', multi: 'Yes', origin: 'Albany South', status: 'Complete' },
      { id: 3, cost: '$394.00', destination: 'Chicago East', multi: 'Yes', origin: 'Albany East', status: 'Active' },
    ];
    this.addValues = [
      { field: 'origin', header: 'Origin Ramp' },
      { field: 'destination', header: 'Destination Ramp' },
      { field: 'cost', header: 'Cost' },
      { field: 'multi', header: 'Multi Segment Lane' },
      { field: 'total', header: 'Total' },
      { field: 'status', header: 'Status' }
    ];
    this.viewValues = [
      { field: 'origin', header: 'Origin Ramp' },
      { field: 'destination', header: 'Destination Ramp' },
      { field: 'cost', header: 'Cost' },
      { field: 'total', header: 'Total' },
      { field: 'multi', header: 'Multi Segment Lane' }
    ];
  }

  // Typing Origin
  getRampQuery(param: any): any {
    this.queryRamp = {
      query: {
        query_string: {
          fields: [
            'RampGroup'
          ],
          query: `${param.input}`
        }
      },
      _source: [
        'RampGroup'
      ]
    };
    return this.queryRamp;
  }

  // Search Origin Destination
  getSearchValue(param: any): any {
    this.querySearch = {
      query: {
        bool: {
          must: [
            {
              query_string: {
                fields: [
                  'OriginRampGroup'
                ],
                query: `${param.origin}`
              }
            },
            {
              query_string: {
                fields: [
                  'DestinationRampGroup'
                ],
                query: `${param.destination}`
              }
            },
            {
              range: {
                StartDate: {
                  gte: `${param.dateStart}`
                }
              }
            },
            {
              range: {
                EndDate: {
                  lte: `${param.dateEnd}`
                }
              }
            }
          ]
        }
      }
    };
    return this.querySearch;
  }
}
