import { TestBed, inject } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { APP_BASE_HREF } from '@angular/common';

import { AppModule } from '../../../../../app.module';
import { EmptyplanListService } from './emptyplan-list.service';

describe('EmptyplanListService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule],
      declarations: [],
      providers: [EmptyplanListService, { provide: APP_BASE_HREF, useValue: '/' }]
    });
  });

  it('should be created', inject([EmptyplanListService], (service: EmptyplanListService) => {
    expect(service).toBeTruthy();
  }));

});
