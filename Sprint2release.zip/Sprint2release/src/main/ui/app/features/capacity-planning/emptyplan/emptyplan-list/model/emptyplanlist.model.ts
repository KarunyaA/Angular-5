export class EmptyplanlistModel {
  filterFlag: number;
  formFlag: number;
  formEditFlag: number;
  formViewFlag: number;
  formAddFlag: number;
  items: object[];
  dropdownlables: object[];
  dropdownSelectedValue: number;
  selectedRow: any;
  emptylanesSource: object[];
  emptylanes_source_len: any;
  currentSelectedWeek: any;
  currentSelectedWeekValue: number;
  dateBasedParam: object;

  constructor() {
    this.filterFlag = 0;
    this.formFlag = 0;
    this.formEditFlag = 0;
    this.formViewFlag = 0;
    this.formAddFlag = 0;
  }
  searchGridValue: object = {
    'query': {
      'bool': {
        'must': [
          {
            'bool': {
              'should': [
                {
                  'multi_match': {
                    'query': '',
                    'fields': ['OriginRamp', 'OriginRampGroup',
                      'DestinationRamp', 'DestinationRampGroup', 'Rail', 'MoveType', 'CapacityOwner'],
                    'type': 'phrase_prefix'
                  }
                },
                {
                  'query_string': {
                    'fields': ['Priority', 'Cost', 'Goal', 'Total', 'Billed', 'Moved', 'InGated', 'Remaining'],
                    'query': ''
                  }
                },
                {
                  'nested': {
                    'path': 'LastUpdated',
                    'query': {
                      'multi_match': {
                        'query': '',
                        'fields': ['LastUpdated.UserName', 'LastUpdated.UserID', 'LastUpdated.Date'],
                        'type': 'phrase_prefix'
                      }
                    }
                  }
                }
              ]
            }
          }
        ]
      }
    }
  };

  // Date based suggestions
  getDateBasedSuggestion(param: any): any {
    this.dateBasedParam = {
      query: {
        bool: {
          must: [
            {
              range: {
                StartDate: {
                  gte: `${param.dateStart}`
                }
              }
            },
            {
              range: {
                EndDate: {
                  lte: `${param.dateEnd}`
                }
              }
            }
          ]
        }
      }
    };
    return this.dateBasedParam;
  }
}
