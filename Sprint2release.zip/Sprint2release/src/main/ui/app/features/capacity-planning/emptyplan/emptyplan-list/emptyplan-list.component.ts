import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { EmptyplanlistModel } from './model/emptyplanlist.model';
import { EmptyplanListService } from './services/emptyplan-list.service';


@Component({
  selector: 'app-emptyplan-list',
  templateUrl: './emptyplan-list.component.html',
  styleUrls: ['./emptyplan-list.component.scss'],
  providers: [EmptyplanListService]
})
export class EmptyplanListComponent implements OnInit {

  emptyplanlistModel: EmptyplanlistModel;

  constructor(private router: Router, private emptyplanListService: EmptyplanListService) {
    this.emptyplanlistModel = new EmptyplanlistModel();
  }

  ngOnInit() {
    this.emptyplanlistModel.dropdownlables = this.getWeekDropdown().reverse();
    this.emptyplanlistModel.currentSelectedWeek = this.emptyplanlistModel.dropdownlables.filter(
      (thisObj: any) => thisObj.isTodayInThisWeekRange === true)[0];
    this.emptyplanlistModel.currentSelectedWeekValue = this.emptyplanlistModel.currentSelectedWeek.value;
    this.emptyplanlistModel.items = [
      {
        label: 'Add Lanes', command: (onclick) => {
          this.router.navigate(['/capacityplanning/createemptylane'],
            { queryParams: { fromDate: '0', toDate: '0' } });
        },
      },
      { label: 'Publish Empty Plan' },
      { label: 'Add Multi Segment Lanes' },
      { label: 'Manage Columns' },
      { label: 'Export to Excel' },
    ];
    this.fetchAllEmptyLanesData();
    this.dateSelected();
  }
  removeForm(event: string): void {
    this.emptyplanlistModel.formFlag = 0;
    this.emptyplanlistModel.filterFlag = 0;
  }
  showFilter(event: string): void {
    this.emptyplanlistModel.filterFlag = (this.emptyplanlistModel.filterFlag === 0) ? 1 : 0;
    this.emptyplanlistModel.formFlag = 0;
  }
  closeSplit(event): void {
    this.emptyplanlistModel.formFlag = 0;
  }
  onSelectType(weekNumber: number) {
    this.emptyplanlistModel.formFlag = 0;
    this.emptyplanlistModel.currentSelectedWeek = this.emptyplanlistModel.dropdownlables.filter(
      (thisObj: any) => thisObj.value === weekNumber)[0];
    this.dateSelected();
  }
  dateSelected(): void {
    const startDateVal = new Date(this.emptyplanlistModel.currentSelectedWeek.startDate),
      startMonth = ('0' + (startDateVal.getMonth() + 1)).slice(-2),
      startDay = ('0' + startDateVal.getDate()).slice(-2);
    const startDate = [startMonth, startDay, startDateVal.getFullYear()].join('-');
    const endDateVal = new Date(this.emptyplanlistModel.currentSelectedWeek.endDate),
      endMonth = ('0' + (endDateVal.getMonth() + 1)).slice(-2),
      endDay = ('0' + endDateVal.getDate()).slice(-2);
    const endDate = [endMonth, endDay, endDateVal.getFullYear()].join('-');
    const dateObj = {
      dateStart: startDate,
      dateEnd: endDate
    };
    this.emptyplanlistModel.dateBasedParam = this.emptyplanlistModel.getDateBasedSuggestion(dateObj);
    this.emptyplanListService.dateBasedSearch(this.emptyplanlistModel.dateBasedParam).subscribe(data => {
      if (data && data['hits'] && data['hits']['hits']) {
        const DateList = data['hits']['hits'];
        const dataValue = [];
        DateList.forEach((element: any) => {
          element['updatedData'] = `${element._source.LastUpdated[0].UserName} (${element._source.LastUpdated[0].UserID})
        \n ${element._source.LastUpdated[0].Date}`;
        });
        this.emptyplanlistModel.emptylanesSource = data['hits']['hits'];
      }
    });
  }
  onRowSelect(event: object): void {
    this.emptyplanlistModel.formFlag = 1;
    this.emptyplanlistModel.filterFlag = 0;
    this.emptyplanlistModel.formEditFlag = 0;
    this.emptyplanlistModel.formViewFlag = 1;
    this.emptyplanlistModel.formAddFlag = 0;
  }
  redirectToCreateLanes(): void {
    const fromDate = new Date(this.emptyplanlistModel.currentSelectedWeek.startDate),
      startMonth = ('0' + (fromDate.getMonth() + 1)).slice(-2),
      startDay = ('0' + fromDate.getDate()).slice(-2);
    const fromDateFormat = [startMonth, startDay, fromDate.getFullYear()].join('-');

    const toDate = new Date(this.emptyplanlistModel.currentSelectedWeek.startDate),
      endMonth = ('0' + (toDate.getMonth() + 1)).slice(-2),
      endDay = ('0' + toDate.getDate()).slice(-2);
    const toDateFormat = [endMonth, endDay, toDate.getFullYear()].join('-');
    this.router.navigate(['/capacityplanning/createemptylane'],
      { queryParams: { fromDate: fromDateFormat, toDate: toDateFormat } });
  }
  getMonday(d) {
    d = new Date(d);
    const day = d.getDay(),
      diff = d.getDate() - day + (day === 0 ? -6 : 1);
    return new Date(d.setDate(diff));
  }

  private fetchAllEmptyLanesData(): void {
    this.emptyplanlistModel.emptylanesSource = [];
    this.emptyplanlistModel.emptylanes_source_len = 0;
  }

  private getWeekDropdown(): Array<any> {
    const todayDate = new Date();
    const oneJan: any = new Date(todayDate.getFullYear(), 0, 1);
    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const weekwiseDateArrayList = [];
    let weekStartDate: any = this.getMonday(new Date(new Date(todayDate).setDate(todayDate.getDate() + 7)));
    let weekEndDate: Date = new Date(new Date(weekStartDate).setDate(weekStartDate.getDate() + 6));

    for (let i = 1; i <= 12; i++) {
      const thisWeekNumber = Math.ceil((((weekStartDate - oneJan) / 86400000) + oneJan.getDay() + 1) / 7);
      const displayDateRange = monthNames[weekStartDate.getMonth()] + ' ' + weekStartDate.getDate() + ' - ' +
        monthNames[weekEndDate.getMonth()] + ' ' + weekEndDate.getDate() + ' (Week ' + thisWeekNumber + ')';
      weekwiseDateArrayList.unshift({
        'startDate': weekStartDate, 'endDate': weekEndDate, 'value': thisWeekNumber, 'label': displayDateRange,
        'isTodayInThisWeekRange': false
      });

      if (weekStartDate <= todayDate && weekEndDate >= todayDate) {
        weekwiseDateArrayList[0].isTodayInThisWeekRange = true;
      }

      weekStartDate = new Date(new Date(weekStartDate).setDate(weekStartDate.getDate() - 7));
      weekEndDate = new Date(new Date(weekEndDate).setDate(weekEndDate.getDate() - 7));
    }
    return weekwiseDateArrayList;
  }

  onSearchChange(event: Event): void {
    const searchValue = event.target['value'];
    const queryParam = this.emptyplanlistModel.searchGridValue;
    const pattern = /^[0-9]*$/;
    if (pattern.test(searchValue)) {
      queryParam['query']['bool']['must'][0]['bool']['should'][0]['multi_match']['query'] = '*';
      queryParam['query']['bool']['must'][0]['bool']['should'][1]['query_string']['query'] = searchValue;
      queryParam['query']['bool']['must'][0]['bool']['should'][2]['nested']['query']['multi_match']['query'] = '*';
    } else {
      queryParam['query']['bool']['must'][0]['bool']['should'][0]['multi_match']['query'] = searchValue;
      queryParam['query']['bool']['must'][0]['bool']['should'][1]['query_string']['query'] = '';
      queryParam['query']['bool']['must'][0]['bool']['should'][2]['nested']['query']['multi_match']['query'] = searchValue;
    }
    this.emptyplanListService.searchGridValue(queryParam).subscribe(data => {
      if (data && data['hits'] && data['hits']['hits']) {
        const DateList = data['hits']['hits'];
        const dataValue = [];
        DateList.forEach((element: any) => {
          element['updatedData'] = `${element._source.LastUpdated[0].UserName} (${element._source.LastUpdated[0].UserID})
          \n ${element._source.LastUpdated[0].Date}`;
        });
        this.emptyplanlistModel.emptylanesSource = data['hits']['hits'];
      }
    });
  }

}

