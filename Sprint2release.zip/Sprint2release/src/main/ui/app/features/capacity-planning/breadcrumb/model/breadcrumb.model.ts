export class BreadCrumb {
  items = [
    { label: 'Home', routerLink: ['/dashboard'] },
    { label: 'Capacity Planning', routerLink: ['/capacityplanning'] }  ];
}
