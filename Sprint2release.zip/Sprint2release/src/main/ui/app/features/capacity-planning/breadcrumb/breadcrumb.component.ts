import { Component, OnInit } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { BreadCrumb } from './model/breadcrumb.model';

@Component({
  selector: 'app-breadcrumb',
  templateUrl: './breadcrumb.component.html',
  styleUrls: ['./breadcrumb.component.scss']
})
export class BreadcrumbComponent implements OnInit {

  breadCrumbModel: BreadCrumb;

  constructor() {
    this.breadCrumbModel = new BreadCrumb();
  }

  ngOnInit() {
  }

}
