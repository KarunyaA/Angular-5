import { TestBed, inject } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { APP_BASE_HREF } from '@angular/common';

import { AppModule } from '../../../../../app.module';
import { EmptyplanCreateService } from './emptyplan-create.service';

describe('EmptyplanCreateService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, AppModule],
      declarations: [],
      providers: [EmptyplanCreateService, { provide: APP_BASE_HREF, useValue: '/' }]
    });
  });

  it('should be created', inject([EmptyplanCreateService], (service: EmptyplanCreateService) => {
    expect(service).toBeTruthy();
  }));

});
