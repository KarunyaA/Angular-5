import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emptyplan-edit',
  templateUrl: './emptyplan-edit.component.html',
  styleUrls: ['./emptyplan-edit.component.scss']
})
export class EmptyplanEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }


}
