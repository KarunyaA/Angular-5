import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/toPromise';

import { AppConfig } from 'config/app.config';
import { AppLocalConfig } from 'config/app.local.config';
import { environment } from 'environments/environment';
import { SpinnerService } from 'app/shared/spinner/index';

@Injectable()
export class EditInboundLocationService {

  appConfig = (environment.envName === 'local') ? AppLocalConfig.getConfig() : AppConfig.getConfig();
  constructor(private spinnerService: SpinnerService, private http: HttpClient) {}

  getInboundLimitLocationByLimitId(limitId: number): Observable<object> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    return this.http.get < object > (this.appConfig.api.inboundlimits.editinboundlimits + limitId, {
      headers
    });
  }
  saveInboundLimitLocationByLimitId(requestParam: object, limitId: number): Observable<object> {
    return this.patchData(this.appConfig.api.inboundlimits.editinboundlimits + limitId, requestParam);
  }
  private patchData(url, body: Object, headers ?: any): Observable < Object[] > {
    this.spinnerService.show();
    this.spinnerService.spinnerText = 'Processing Service Requests ...';
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Cache-Control': 'no-cache',
        'Pragma': 'no-cache'
      })
    };

    const bodyString = JSON.stringify(body);
    return this.http.patch < Object > (url, bodyString, httpOptions).map((res: any) => {
      this.spinnerService.hide();
      return res;
    }).catch((err: HttpErrorResponse) => {
      this.spinnerService.hide();
      return [err];
    });

  }

}
