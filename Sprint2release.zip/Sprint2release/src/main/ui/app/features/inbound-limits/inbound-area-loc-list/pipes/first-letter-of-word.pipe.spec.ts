import { FirstLetterOfWordPipe } from './first-letter-of-word.pipe';

describe('FirstLetterOfWordPipe', () => {
  it('create an instance', () => {
    const pipe = new FirstLetterOfWordPipe();
    expect(pipe).toBeTruthy();
  });
});
