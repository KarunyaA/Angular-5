import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ViewChild, ComponentFactoryResolver, ViewContainerRef } from '@angular/core';
import { Subscriber } from 'rxjs/Subscriber';
import { FormGroup, FormArray, FormBuilder, FormControl } from '@angular/forms';
import * as _ from 'lodash';

import { ConfirmationService } from 'primeng/api';
import { EditInboundLimitsModel } from './model/edit-inbound-location.model';
import { EditInboundLocationService } from './services/edit-inbound-location.service';
import { AddSpecificdateComponent } from '../add-specificdate/add-specificdate.component';
import { MessageService } from 'primeng/components/common/messageservice';
import { WeekDay } from '@angular/common';

@Component({
  selector: 'app-edit-inbound-location',
  templateUrl: './edit-inbound-location.component.html',
  styleUrls: ['./edit-inbound-location.component.scss']
})
export class EditInboundLocationComponent implements OnInit {
    @Input() businessUnitType: String;
    @Input() selectedRow: any ;
    @Input() set inboundCapacityLimitID(inboundCapacityLimitID: number) {
        if (inboundCapacityLimitID !== undefined) {
          this.inboundCapacityLimitIDSaveCall = inboundCapacityLimitID;
        this.serviceCall();
        }
    }
    @Output() splitClose = new EventEmitter();
    specificDatee = [];
    myForm: FormGroup;
    showError = false;
    duplicateArray = [];
    dateCount = 0;
    specificDateError = false;
    inboundCapacityLimitIDSaveCall: any;
    moreThanOneSpecificLimit = false;
    reqJson = {};
    editInboundLocationModel: EditInboundLimitsModel;
  constructor(
      private editInboundLocationService: EditInboundLocationService,
      private confirmationService: ConfirmationService,
      private formBulder: FormBuilder,
      private toastMessage: MessageService) {}
  ngOnInit() {
      this.editInboundLocationModel = new EditInboundLimitsModel();
      this.specificDateForm();
      this.editInboundLocationModel.weekDayService = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
      this.editInboundLocationModel.weekDays = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
      }
      serviceCall() {
        this.myForm = this.formBulder.group({
            date: this.formBulder.array([]),
        });
        this.editInboundLocationService.getInboundLimitLocationByLimitId(this.inboundCapacityLimitIDSaveCall).subscribe(data => {
            const listValues = data['inboundCapacityDayOfWeekLimits'];
            listValues.forEach(element => {
              for ( let i = 0; i < this.editInboundLocationModel.weekDays.length; i++) {
                  if ( this.editInboundLocationModel.weekDayService[i] === element['weekDayCode']) {
                      this.editInboundLocationModel[this.editInboundLocationModel.weekDays[i]] =
                       element['inboundLoadCapacityLimitCount'];
                  }
              }
            });
        this.editInboundLocationModel.customerLocationName = data['customerLocationName'];
        this.editInboundLocationModel.customerLocationAddress = data['customerLocationAddress'];
        this.editInboundLocationModel.financeBusinessUnitCode = data['financeBusinessUnitCode'];
        this.editInboundLocationModel.serviceOfferingCode = data['serviceOfferingCode'];
        this.editInboundLocationModel.fleetTypeCode = data['fleetTypeCode'];
        const listValuesspecificdate = data['inboundCapacityDateLimits'];
        const control = <FormArray>this.myForm.controls['date'];
        listValuesspecificdate.forEach(element => {
            const dataValues = element['inboundCapacityLimitDate'].split('-');
            control.push(this.formBulder.group({
                specificDate: [ dataValues[1] + '/' + dataValues[2]
                + '/' + dataValues[0]],
                 specificDateLimit: [element[ 'inboundLoadCapacityDateLimitCount']]
            }));
          });
      });
      }
  specificDateForm(): void {
      this.myForm = this.formBulder.group({
        date: this.formBulder.array([])
      });
    }
  getForm(myForm):   any   {
      return   myForm.controls.date.controls;
    }
    formControl(myForm,   i):   any   {
      return   myForm.controls.date.controls[i];
    }
  checkDuplicate(date, formArray): void {
      const newDate = date;
      const dateArray = formArray.controls;
      const duplicateVal = [];
      this.showError = false;
      if (formArray.controls.length) {
          formArray.controls.forEach(element => {
                  if (element.value.specificDate.indexOf(newDate.specificDate) !== -1) {
                      this.duplicateArray.push(newDate.specificDate);
                      if (this.duplicateArray.length > 1) {
                          this.showError = true;
                  }
              }
          });
          this.duplicateArray = [];
      } else {
          this.showError = false;
      }
  }

  initDate(): any {
      return this.formBulder.group({
          specificDate: [''],
          specificDateLimit: ['']
      });

  }

  addNewDate(): void {
      const control = <FormArray> (this.myForm.controls['date']);
      const addCtrl = this.initDate();
      addCtrl.valueChanges.subscribe(x => {
          this.checkDuplicate(x, control);
      });
      control.push(addCtrl);
  }

  removeDate(i: number): void {
      const control = <FormArray> this.myForm.controls['date'];
  control.removeAt(i);
  const newControl = <FormArray> this.myForm.controls['date'];
  if (newControl.controls.length > 1) {
    this.customGroupValidation(newControl);
  } else {
    this.showError = false;
  }
  this.showError = false;
  this.specificDateError = false;
  }

  customGroupValidation(formArray) {
      let isError = false;
      this.showError = false;
      const result = _.groupBy(formArray.controls, c => c.value);
      for (const prop in result) {
          if (result[prop].length > 1) {
              isError = true;
              _.forEach(result[prop], function(item) {
                  item._status = 'INVALID';
              });
          } else {
              result[prop][0]._status = 'VALID';
          }
      }
      if (isError) {
          return this.showError = true;
      }
  }

  dailyLimitFactValidation() {
      if (this.isValidData()) {
          this.editInboundLocationModel.dailyLimitFact = false;
      } else {
          this.editInboundLocationModel.dailyLimitFact = true;
      }
  }
  specificLimitValidation() {
    let specificDateLimitNotAssignedCount = 0;
    this.moreThanOneSpecificLimit = false;
    this.specificDateError = false;
    for (let n = 0; n < this.myForm.controls.date['controls']['length']; n++) {
        if (this.myForm.controls.date['controls'][n].value.specificDate &&
            this.myForm.controls.date['controls'][n].value.specificDateLimit === '' ||
            this.myForm.controls.date['controls'][n].value.specificDateLimit === null) {
                specificDateLimitNotAssignedCount++;
            }
        }
        if (specificDateLimitNotAssignedCount === 1) {
            this.specificDateError = true;
        } else if (specificDateLimitNotAssignedCount > 1) {
            this.moreThanOneSpecificLimit = true;
        } else {
            this.moreThanOneSpecificLimit = false;
            this.specificDateError = false;
        }
}
  save(): void {
      if (this.isValidData()) {
          this.specificLimitValidation();
          const dailyLimit = [];
          for (let j = 0; j < this.editInboundLocationModel.weekDays.length; j++) {
              if (this.editInboundLocationModel[this.editInboundLocationModel.weekDays[j]]) {
                  dailyLimit.push({
                      'weekDayCode': this.editInboundLocationModel.weekDayService[j],
                      'inboundLoadCapacityLimitCount': this.editInboundLocationModel[this.editInboundLocationModel.weekDays[j]]
                  });
              }
          }
          const dates = this.myForm.value['date'];
          const arrayList = [];
          dates.forEach(dateObj => {
              const dateSeperated = dateObj['specificDate'].split('/');
              const dateArray = [parseInt(dateSeperated[2], 10),
                  parseInt(dateSeperated[0], 10), parseInt(dateSeperated[1], 10)
              ];
              if (this.specificDateError === false) {
                  arrayList.push({
                      'inboundCapacityLimitDate': dateArray,
                      'inboundLoadCapacityDateLimitCount': dateObj['specificDateLimit'],
                  });
              }
          });
          this.editInboundLocationModel.specificDates = arrayList;
          this.reqJson['inboundCapacityLimitID'] = this.inboundCapacityLimitID,
          this.reqJson['customerLocationID'] =  this.editInboundLocationModel.customerLocationID,
          this.reqJson['customerLocationCode'] = this.editInboundLocationModel.customerLocationCode,
          this.reqJson['customerLocationName'] = this.editInboundLocationModel.customerLocationName,
          this.reqJson['customerLocationAddress'] = this.editInboundLocationModel.customerLocationAddress,
          this.reqJson['financeBusinessUnitCode'] = this.editInboundLocationModel.financeBusinessUnitCode,
          this.reqJson['serviceOfferingCode'] = this.editInboundLocationModel.serviceOfferingCode,
          this.reqJson['fleetTypeCode'] = this.editInboundLocationModel.fleetTypeCode,
          this.reqJson['specificDates'] = this.editInboundLocationModel.specificDates,
          this.reqJson['dailyLimit'] = dailyLimit;
          if (this.editInboundLocationModel.dailyLimitFact === false && this.showError === false
              && this.specificDateError === false) {
              this.editInboundLocationService.saveInboundLimitLocationByLimitId(this.reqJson,
                this.inboundCapacityLimitIDSaveCall).subscribe(data => {
                    this.toastMessage.add({
                        severity: 'success',
                        summary: 'Inbound Limit Saved',
                        detail: `Inbound Limit for
                         ${this.editInboundLocationModel.customerLocationName}
                        (${this.editInboundLocationModel.customerLocationID})has been successfully added`
                    });
                    this.splitClose.emit(false);
              });
          }
          this.editInboundLocationModel.dailyLimitFact = false;
      } else if (this.isValidData() === false && this.myForm.controls.date['controls']['length'] === 0) {
        this.editInboundLocationModel.dailyLimitFact = false;
        this.toastMessage.add({
                severity: 'warn',
             summary: 'Inbound Limit Not Set ',
                 detail: 'Inbound Limit fields are empty. You need to specify either Daily Limits or Specific Dates'
             });
    }  else {
          this.editInboundLocationModel.dailyLimitFact = true;
      }
  }
  isValidData(): boolean {
      let dailyLimitFlag = 0;
      for (let j = 0; j < this.editInboundLocationModel.weekDays.length; j++) {
          if (this.editInboundLocationModel[this.editInboundLocationModel.weekDays[j]] >= 0) {
            dailyLimitFlag = 1;
          }
      }
      if (dailyLimitFlag === 1) {
          return true;
      }
      return false;

  }

  removeInboundLimits() {
      this.confirmationService.confirm({
          message: `Are you sure you want to remove inbound limits for ‘
              ${this.editInboundLocationModel.customerLocationName} (${this.editInboundLocationModel.customerLocationID})’`,
          header: 'Remove Inbound Limit',
          accept: () => {
            this.toastMessage.add({
                severity: 'success',
                summary: 'Inbound Limit Removed',
                detail: `Inbound Limit for ${this.editInboundLocationModel.customerLocationName}
                ’ has been successfully removed`
            });
          },
          reject: () => {
            this.toastMessage.add({
                  severity: 'info',
                  summary: 'Rejected',
                  detail: 'You have rejected'
              });
          }
      });
  }
  dailyLimitSetToZero() {
    for (let j = 0; j < this.editInboundLocationModel.weekDays.length; j++) {
        this.editInboundLocationModel[this.editInboundLocationModel.weekDays[j]] = null;
    }
}
  cancel() {
      this.dailyLimitSetToZero();
    this.splitClose.emit(false);
  }
}
