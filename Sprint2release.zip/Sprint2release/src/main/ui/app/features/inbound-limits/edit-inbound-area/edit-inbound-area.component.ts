import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ViewChild, ComponentFactoryResolver, ViewContainerRef } from '@angular/core';
import { Subscriber } from 'rxjs/Subscriber';
import { FormGroup, FormArray, FormBuilder, FormControl } from '@angular/forms';
import * as _ from 'lodash';
import { TitleCasePipe } from '@angular/common';

import { ConfirmationService } from 'primeng/api';
import { EditInboundLimitsModel } from './model/edit-inbound-area.model';
import { EditInboundAreaService } from './services/edit-inbound-area.service';
import { MessageService } from 'primeng/components/common/messageservice';
import { AddSpecificdateComponent } from '../add-specificdate/add-specificdate.component';
import { WeekDay } from '@angular/common';


@Component({
    selector: 'app-edit-inbound-area',
    templateUrl: './edit-inbound-area.component.html',
    styleUrls: ['./edit-inbound-area.component.scss']
})

export class EditInboundAreaComponent implements OnInit {
  @Input() businessUnitType: String;
  @Input() selectedRow: any;
  @Input() set inboundCapacityLimitID(inboundCapacityLimitID: number) {
      if (inboundCapacityLimitID !== undefined) {
        this.inboundCapacityLimitIDSaveCall = inboundCapacityLimitID;
      this.serviceCall();
      }
  }
  @Input() set capacityAreaName(capacityAreaName: string) {
    if (capacityAreaName !== undefined) {
      this.capacityAreaNameSaveCall = capacityAreaName;
    this.serviceCall();
    }
}
  @Output() splitClose = new EventEmitter();
    myForm: FormGroup;
    showError = false;
    duplicateArray = [];
    dateCount = 0;
    specificDateError = false;
    moreThanOneSpecificLimit = false;
    editInboundAreaModel: EditInboundLimitsModel;
    inboundCapacityLimitIDSaveCall: number;
    capacityAreaNameSaveCall: String;
    reqJson = {};
    constructor(
        private editInboundAreaService: EditInboundAreaService,
        private confirmationService: ConfirmationService,
        private formBulder: FormBuilder,  private toastMessage: MessageService) {
        }
    ngOnInit() {
        this.editInboundAreaModel = new EditInboundLimitsModel();
        this.specificDateForm();
        this.editInboundAreaModel.weekDayService = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
        this.editInboundAreaModel.weekDays = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
    }
    serviceCall() {
        this.myForm = this.formBulder.group({
            date: this.formBulder.array([]),
        });
        this.editInboundAreaService.getInboundLimitAreaByLimitId(this.inboundCapacityLimitIDSaveCall).subscribe(data => {
            const listValues = data['inboundCapacityDayOfWeekLimits'];
            listValues.forEach(element => {
                for ( let i = 0; i < this.editInboundAreaModel.weekDays.length; i++) {
                    if ( this.editInboundAreaModel.weekDayService[i] === element['weekDayCode']) {
                        this.editInboundAreaModel[this.editInboundAreaModel.weekDays[i]] =
                         element['inboundLoadCapacityLimitCount'];
                    }
                }

            });
            this.editInboundAreaModel.capacityAreaID = data['capacityAreaID'];
            this.editInboundAreaModel.financeBusinessUnitCode = data['financeBusinessUnitCode'];
            this.editInboundAreaModel.serviceOfferingCode = data['serviceOfferingCode'];
            this.editInboundAreaModel.fleetTypeCode = data['fleetTypeCode'];
            const listValuesspecificdate = data['inboundCapacityDateLimits'];
            const control = < FormArray > this.myForm.controls['date'];
            listValuesspecificdate.forEach(element => {
                const dataValues = element['inboundCapacityLimitDate'].split('-');
                control.push(this.formBulder.group({
                    specificDate: [dataValues[1] + '/' + dataValues[2] + '/' + dataValues[0]],
                    specificDateLimit: [element['inboundLoadCapacityDateLimitCount']]
                }));
            });
        });
    }
    specificDateForm(): void {
        this.myForm = this.formBulder.group({
          date: this.formBulder.array([])
        });
      }
    getForm(myForm):   object   {
        return   myForm.controls.date.controls;
      }
      formControl(myForm,   i):   object   {
        return   myForm.controls.date.controls[i];
      }
    checkDuplicate(date, formArray): void {
        const newDate = date;
        const dateArray = formArray.controls;
        const duplicateVal = [];
        this.showError = false;
        if (formArray.controls.length) {
            formArray.controls.forEach(element => {
                    if (element.value.specificDate.indexOf(newDate.specificDate) !== -1) {
                        this.duplicateArray.push(newDate.specificDate);
                        if (this.duplicateArray.length > 1) {
                            this.showError = true;
                        }
                    }
            });
            this.duplicateArray = [];
        } else {
            this.showError = false;
        }
    }

    initDate(): any {
        return this.formBulder.group({
            specificDate: [''],
            specificDateLimit: ['']
        });

    }

    addNewDate(): void {
        const control = < FormArray > (this.myForm.controls['date']);
        const addCtrl = this.initDate();
        addCtrl.valueChanges.subscribe(x => {
            this.checkDuplicate(x, control);
        });
        control.push(addCtrl);
    }

    removeDate(i: number): void {
        const control = < FormArray > this.myForm.controls['date'];
    control.removeAt(i);
    const newControl = < FormArray > this.myForm.controls['date'];
    if (newControl.controls.length > 1) {
      this.customGroupValidation(newControl);
    } else {
      this.showError = false;
    }
    this.showError = false;
    this.specificDateError = false;
    this.moreThanOneSpecificLimit = false;
    }

    customGroupValidation(formArray) {
        let isError = false;
        this.showError = false;
        const result = _.groupBy(formArray.controls, c => c.value);
        for (const prop in result) {
            if (result[prop].length > 1) {
                isError = true;
                _.forEach(result[prop], function(item) {
                    item._status = 'INVALID';
                });
            } else {
                result[prop][0]._status = 'VALID';
            }
        }
        if (isError) {
            return this.showError = true;
        }
    }

    dailyLimitFactValidation() {
        if (this.isValidData()) {
            this.editInboundAreaModel.dailyLimitFact = false;
        } else {
            this.editInboundAreaModel.dailyLimitFact = true;
        }
    }
    specificLimitValidation() {
        let specificDateLimitNotAssignedCount = 0;
        this.moreThanOneSpecificLimit = false;
        this.specificDateError = false;
        for (let n = 0; n < this.myForm.controls.date['controls']['length']; n++) {
            if (this.myForm.controls.date['controls'][n].value.specificDate &&
                this.myForm.controls.date['controls'][n].value.specificDateLimit === '' ||
                this.myForm.controls.date['controls'][n].value.specificDateLimit === null) {
                    specificDateLimitNotAssignedCount++;
                }
            }
            if (specificDateLimitNotAssignedCount === 1) {
                this.specificDateError = true;
            } else if (specificDateLimitNotAssignedCount > 1) {
                this.moreThanOneSpecificLimit = true;
            } else {
                this.moreThanOneSpecificLimit = false;
                this.specificDateError = false;
            }
    }
    save(): void {
        if (this.isValidData()) {
            this.specificLimitValidation();
            const dailyLimit = [];
            for (let j = 0; j < this.editInboundAreaModel.weekDays.length; j++) {
                if (this.editInboundAreaModel[this.editInboundAreaModel.weekDays[j]]) {
                    dailyLimit.push({
                        'weekDayCode': this.editInboundAreaModel.weekDayService[j],
                        'inboundLoadCapacityLimitCount': this.editInboundAreaModel[this.editInboundAreaModel.weekDays[j]]
                    });
                }
            }
            const dates = this.myForm.value['date'];
            const arrayList = [];
            dates.forEach(dateObj => {
                const dateSeperated = dateObj['specificDate'].split('/');
                const dateArray = [parseInt(dateSeperated[2], 10),
                    parseInt(dateSeperated[0], 10), parseInt(dateSeperated[1], 10)];
                if (this.specificDateError === false) {
                    arrayList.push({
                        'inboundCapacityLimitDate': dateArray,
                        'inboundLoadCapacityDateLimitCount': dateObj['specificDateLimit'],
                    });
                }
            });
            this.editInboundAreaModel.specificDates = arrayList;
                this.reqJson['inboundCapacityLimitID'] = this.inboundCapacityLimitIDSaveCall,
                this.reqJson['capacityAreaID'] = this.editInboundAreaModel.capacityAreaID,
                this.reqJson['capacityAreaName'] = this.capacityAreaNameSaveCall,
                this.reqJson['financeBusinessUnitCode'] = this.editInboundAreaModel.financeBusinessUnitCode,
                this.reqJson['serviceOfferingCode'] = this.editInboundAreaModel.serviceOfferingCode,
                this.reqJson['fleetTypeCode'] = this.editInboundAreaModel.fleetTypeCode,
                this.reqJson['specificDates'] = this.editInboundAreaModel.specificDates,
                this.reqJson['dailyLimit'] = dailyLimit;
            if (this.editInboundAreaModel.dailyLimitFact === false && this.showError === false
                && this.specificDateError === false && this.moreThanOneSpecificLimit === false) {
                this.editInboundAreaService.saveInboundLimitAreaByLimitId(this.reqJson
                    , this.inboundCapacityLimitIDSaveCall).subscribe(data => {
                        this.toastMessage.add({
                            severity: 'success',
                            summary: 'Inbound Limit Updated',
                            detail: `Inbound Limit for ${this.editInboundAreaModel.capacityAreaName}
                            has been successfully Update`
                        });
                        this.splitClose.emit(false);
                });
            }
            this.editInboundAreaModel.dailyLimitFact = false;
        } else if (this.isValidData() === false && this.myForm.controls.date['controls']['length'] === 0) {
            this.editInboundAreaModel.dailyLimitFact = false;
            this.toastMessage.add({
                    severity: 'warn',
                 summary: 'Inbound Limit Not Set ',
                     detail: 'Inbound Limit fields are empty. You need to specify either Daily Limits or Specific Dates'
                 });
        } else {
            this.editInboundAreaModel.dailyLimitFact = true;
        }
    }
    isValidData(): boolean {
        let dailyLimitFlag = 0;
        for (let j = 0; j < this.editInboundAreaModel.weekDays.length; j++) {
            if (this.editInboundAreaModel[this.editInboundAreaModel.weekDays[j]] >= 0) {
                dailyLimitFlag = 1;
            }
        }
        if (dailyLimitFlag === 1) {
            return true;
        }
        return false;

    }
    removeInboundLimits() {
        this.confirmationService.confirm({
            message: `Are you sure you want to remove inbound limits for ‘
                ${this.editInboundAreaModel.capacityAreaName} (${this.editInboundAreaModel.capacityAreaID})’`,
            header: 'Remove Inbound Limit',
            accept: () => {
                this.toastMessage.add({
                    severity: 'success',
                    summary: 'Inbound Limit Removed',
                    detail: `Inbound Limit for ‘${this.editInboundAreaModel.capacityAreaName}’ has been successfully removed`
                });
            },
            reject: () => {
                this.toastMessage.add({
                    severity: 'info',
                    summary: 'Rejected',
                    detail: 'You have rejected'
                });
            }
        });
    }
    dailyLimitSetToZero() {
        for (let j = 0; j < this.editInboundAreaModel.weekDays.length; j++) {
            this.editInboundAreaModel[this.editInboundAreaModel.weekDays[j]] = 0;
        }
    }
    cancel() {
        this.dailyLimitSetToZero();
        this.specificDateForm();
      this.splitClose.emit(false);
    }
}
