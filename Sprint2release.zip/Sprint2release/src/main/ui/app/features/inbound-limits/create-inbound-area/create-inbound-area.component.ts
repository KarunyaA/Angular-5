import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators, FormArray } from '@angular/forms';

import { GrowlModule, Message } from 'primeng/primeng';
import { MessageService } from 'primeng/components/common/messageservice';
import { SelectItem } from 'primeng/api';
import * as _ from 'lodash';


import { InboundAreaModel } from './models/create-inbound-area.model';
import { CreateInboundAreaService } from './services/create-inbound-area.service';

@Component({
  selector: 'app-create-inbound-area',
  templateUrl: './create-inbound-area.component.html',
  styleUrls: ['./create-inbound-area.component.scss']
})
export class CreateInboundAreaComponent implements OnInit {
  @Input() businessUnitType: any;
  @Output() splitClose = new EventEmitter();
  inboundAreaModel: InboundAreaModel;
  notifications: MessageService;

  constructor(private createInboundAreaService: CreateInboundAreaService,
    private toastMessage: MessageService,
    private formBuilder: FormBuilder) {
    this.inboundAreaModel = new InboundAreaModel();
  }
  date = new Date();
  today = new Date();

  ngOnInit() {
    this.inboundAreaModel.labelFloat = false;
    this.inboundAreaModel.fleetFloat = false;
    this.inboundAreaModel.areaFlag = false;
    this.inboundAreaModel.serviceOfferingFlag = false;
    this.inboundAreaModel.fleetTypeFlag = false;
    this.inboundAreaModel.businessUnit = this.businessUnitType;
    this.specificDateForm();
    this.today.setDate = this.date.getDate;
    this.today.setMonth = this.date.getMonth;
    this.today.setFullYear = this.date.getFullYear;
    this.addForm();
    this.getServiceOffering();
  }

  getDate(value: any): void {
    if (value !== undefined) {
      this.inboundAreaModel.newDateArray.push(value);
    }
  }


  specificDateForm(): void {
    this.inboundAreaModel.myForm = this.formBuilder.group({
      date: this.formBuilder.array([])
    });
  }

  addForm(): void {
    this.inboundAreaModel.userform = this.formBuilder.group({
      'capacityArea': new FormControl('', Validators.required),
      'serviceOffering': new FormControl('', Validators.required),
      'fleetType': new FormControl('', Validators.required),
      'sunday': new FormControl(''),
      'monday': new FormControl(''),
      'tuesday': new FormControl(''),
      'wednesday': new FormControl(''),
      'thursday': new FormControl(''),
      'friday': new FormControl(''),
      'saturday': new FormControl(''),
    });
  }

  onSelectFleet(event: any): void {
    if (event && event.name !== '' && event.name !== null) {
      this.inboundAreaModel.fleetFloat = true;
    }
  }

  getServiceOffering(): void {
    this.createInboundAreaService.getServiceOffering(this.inboundAreaModel.businessUnit).subscribe(data => {
      if (data && data['_embedded'] && data['_embedded']['serviceOfferingBusinessUnitTransitModeAssociations']) {
        const listData = data['_embedded']['serviceOfferingBusinessUnitTransitModeAssociations'];
        const listValues = [];
        listData.forEach(element => {
          const obj = {
            name: element['serviceOfferingCode'],
            code: element['serviceOfferingCode']
          };
          listValues.push(obj);
        });
        this.inboundAreaModel.serviceOfferingList = listValues;
      }
    });
  }

  onSelectType(event: any): void {
    if (event && event.name !== '' && event.name !== null) {
      this.inboundAreaModel.labelFloat = true;
    }
    switch (this.businessUnitType) {
      case 'JBI':
        this.inboundAreaModel.fleetTypeList = this.inboundAreaModel.jbiFleetype;
        break;
      case 'JBT':
        this.inboundAreaModel.fleetTypeList = this.inboundAreaModel.jbtFleetype;
        break;
      case 'DCS':
        this.inboundAreaModel.fleetTypeList = this.inboundAreaModel.dcsFleetype;
        break;
      case 'ICS':
        this.inboundAreaModel.fleetTypeList = this.inboundAreaModel.icsFleetype;
    }
  }

  getFormControls(myForm): any {
    return myForm.controls.date.controls;
  }

  getFormControlByIndex(myForm, i): any {
    return myForm.controls.date.controls[i];
  }

  initDate(): any {
    return this.formBuilder.group({
      specificDate: [''],
      specificDateLimit: ['']
    });
  }

  addNewDate(): void {
    const control = <FormArray>(this.inboundAreaModel.myForm.controls['date']);
    const addCtrl = this.initDate();
    addCtrl.valueChanges.subscribe(dates => {
      this.checkDuplicate(dates, control);
    });
    control.push(addCtrl);
  }

  checkDuplicate(date: any, formArray: FormArray): void {
    const newDate = date;
    const dateArray = formArray.controls;
    const duplicateVal = [];
    this.inboundAreaModel.showError = false;
    if (formArray.controls.length > 1) {
      formArray.controls.forEach(element => {
        if (element.value.specificDate !== '' && element.value.specificDate !== null) {
          if (element.value.specificDate.indexOf(newDate.specificDate) !== -1) {
            this.inboundAreaModel.duplicateArray.push(newDate.specificDate);
            if (this.inboundAreaModel.duplicateArray.length > 1) {
              this.inboundAreaModel.showError = true;
            }
          }
        }
      });
      this.inboundAreaModel.duplicateArray = [];
    } else {
      this.inboundAreaModel.showError = false;
    }
  }

  removeDate(i: number): void {
    const control = <FormArray>this.inboundAreaModel.myForm.controls['date'];
    control.removeAt(i);
    const newControl = <FormArray>this.inboundAreaModel.myForm.controls['date'];
    if (newControl.controls.length > 1) {
      this.customGroupValidation(newControl);
      this.inboundAreaModel.showError = false;
    } else {
      this.inboundAreaModel.showError = false;
      this.inboundAreaModel.specificDateError = false;
    }
    if (newControl.controls.length === 1) {
      this.inboundAreaModel.specificDateError = false;
    }
  }

  removeForm(event) {
    this.onCancel();
  }

  customGroupValidation(formArray: FormArray): void {
    const uniqueNames = [];
    if (formArray.controls.length > 1) {
      this.inboundAreaModel.showError = false;
      for (let i = 0; i < formArray.controls.length; i++) {
        if (uniqueNames.indexOf(formArray.controls[i].value.specificDate) === -1) {
          this.inboundAreaModel.showError = false;
          uniqueNames.push(formArray.controls[i].value.specificDate);
        } else {
          this.inboundAreaModel.showError = true;
        }
      }
    }
  }

  getCapacityArea(event): void {
    const queryParam = event.query;
    this.createInboundAreaService.getCapacityArea(queryParam, this.inboundAreaModel.businessUnit).then(areas => {
      const arrayList = [];
      areas.forEach(areaObj => {
        arrayList.push({
          name: areaObj['capacityArea'],
          code: areaObj['id']
        });
      });
      this.inboundAreaModel.filteredArea = arrayList;
    });
  }

  specificDates(): void {
    const dates = this.inboundAreaModel.myForm.value['date'];
    const arrayList = [];
    dates.forEach(dateObj => {
      const dateSeperated = dateObj['specificDate'].split('/');
      const dateArray = [parseInt(dateSeperated[2], 10),
      parseInt(dateSeperated[0], 10), parseInt(dateSeperated[1], 10)
      ];
      if (dateObj.specificDate) {
        arrayList.push({
          inboundCapacityLimitDate: dateArray,
          inboundLoadCapacityDateLimitCount: dateObj['specificDateLimit'],
        });
      }
    });
    this.inboundAreaModel.specificDates = arrayList;
      for (let n = 0; n < this.inboundAreaModel.myForm.controls.date['controls']['length']; n++) {
      if (this.inboundAreaModel.myForm.controls.date['controls'][n].value.specificDate &&
        this.inboundAreaModel.myForm.controls.date['controls'][n].value.specificDateLimit === ''
        || this.inboundAreaModel.myForm.controls.date['controls'][n].value.specificDateLimit === null) {
        this.inboundAreaModel.specificDateError = true;
        break;
      } else {
        this.inboundAreaModel.specificDateError = false;
      }
    }
  }

  saveAction(): void {
    const dailyLimitEntered = [];
    this.inboundAreaModel.days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    for (let j = 0; j < this.inboundAreaModel.days.length; j++) {
      if (this.inboundAreaModel[this.inboundAreaModel.days[j]] >= 0 && this.inboundAreaModel[this.inboundAreaModel.days[j]] !== null) {
        dailyLimitEntered.push({
          'weekDayCode': this.inboundAreaModel.days[j],
          'inboundLoadCapacityLimitCount': this.inboundAreaModel[this.inboundAreaModel.days[j]]
        });
      }
    }

    this.specificDates();

    const reqJson = {
      'capacityAreaID': this.inboundAreaModel.userform.value['capacityArea'] ?
        this.inboundAreaModel.userform.value['capacityArea']['code'] : '',
      'capacityAreaName': this.inboundAreaModel.userform.value['capacityArea'] ?
        this.inboundAreaModel.userform.value['capacityArea']['name'] : '',
      'financeBusinessUnitCode': this.inboundAreaModel.businessUnit,
      'serviceOfferingCode': this.inboundAreaModel.userform.value['serviceOffering'] ?
        this.inboundAreaModel.userform.value['serviceOffering']['code'] : '',
      'fleetTypeCode': this.inboundAreaModel.userform.value['fleetType'] ? this.inboundAreaModel.userform.value['fleetType']['code'] : '',
      'specificDates': this.inboundAreaModel.specificDates,
      'dailyLimit': dailyLimitEntered,
    };
    this.inboundAreaModel.limt = dailyLimitEntered.length ? true : false;
    if (this.inboundAreaModel.userform.valid) {
      if (this.inboundAreaModel.limt) {
        if (this.inboundAreaModel.myForm.valid && this.inboundAreaModel.showError === false
          && this.inboundAreaModel.specificDateError === false && (this.inboundAreaModel.limt)) {
          this.saveInboundAreaLimit(reqJson);
        }
      } else {
        this.toastMessage.add({
          severity: 'Save',
          summary: 'Daily limit',
          detail: 'Add at least one daily limit'
        });
      }
    } else {
      this.inboundAreaModel.areaFlag = !this.inboundAreaModel.userform.controls.capacityArea.valid;
      this.inboundAreaModel.serviceOfferingFlag = !this.inboundAreaModel.userform.controls.serviceOffering.valid;
      this.inboundAreaModel.fleetTypeFlag = !this.inboundAreaModel.userform.controls.fleetType.valid;
    }
  }
  saveInboundAreaLimit(reqJson): void {
    this.createInboundAreaService.saveInboundArea(reqJson).subscribe(data => {
      if (data['error']) {
        if (data['error']['errorMessage'] === 'DUPLICATE_INBOUND_AREA_EXISTS') {
          this.toastMessage.add({
            severity: 'error',
            summary: 'Duplicate Inbound Limit',
            detail: `${'An active inbound limit already exists, '}
            ${'please create new inbound limit or edit existing inbound limits54321125 RowsJBI INBOUND LIMITSLoadsCapacity Settings'}`
          });
        }
        if (data['error']['errorMessage'] === 'INBOUND_CAPACITY_AREA_ID_OR_LOCATION_ID_NOT_FOUND') {
          this.toastMessage.add({
            severity: 'error',
            summary: 'Error',
            detail: 'Error'
          });
        }
      } else {
        this.splitClose.emit(false);
        this.toastMessage.add({
          severity: 'success',
          summary: 'Save Inbound Limit',
          detail: `${'Inbound Limit for '}${this.inboundAreaModel.userform.value['capacityArea']['name']}${' has been successfully added'}`

        });
      }
      this.inboundAreaModel.userform.reset();
      this.inboundAreaModel.myForm.reset();
      this.onCancel();
    });
  }

  onCancel(): void {
    this.specificDateForm();
    this.addForm();
    this.splitClose.emit(false);
    this.inboundAreaModel.areaFlag = false;
    this.inboundAreaModel.serviceOfferingFlag = false;
    this.inboundAreaModel.fleetTypeFlag = false;
    this.inboundAreaModel.specificDateError = false;
    this.inboundAreaModel.showError = false;
    this.inboundAreaModel.labelFloat = false;
    this.inboundAreaModel.fleetFloat = false;
  }
}
