export class EditInboundLimitsModel {
    weekDays = [];
    weekDayService = [];
    dailyLimitFact = false;
    sunday: number;
    monday: number;
    tuesday: number;
    wednesday: number;
    thursday: number;
    friday: number;
    saturday: number;
    specificDates = [];
    customerLocationID: number;
    customerLocationCode: String;
    customerLocationName: String;
    customerLocationAddress: String;
    financeBusinessUnitCode: String;
    serviceOfferingCode: String;
    fleetTypeCode: String;
    inboundCapacityLimitDate: String;
    inboundLoadCapacityDateLimitCount: String;
    inboundCapacityLimitID: number;
}
