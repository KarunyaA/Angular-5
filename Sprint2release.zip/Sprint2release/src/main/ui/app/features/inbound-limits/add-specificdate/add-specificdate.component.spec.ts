import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddSpecificdateComponent } from './add-specificdate.component';

describe('AddSpecificdateComponent', () => {
  let component: AddSpecificdateComponent;
  let fixture: ComponentFixture<AddSpecificdateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddSpecificdateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddSpecificdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
