import { TestBed, inject } from '@angular/core/testing';

import { CreateInboundLocationService } from './create-inbound-location.service';

describe('CreateInboundLocationService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CreateInboundLocationService]
    });
  });

  it('should be created', inject([CreateInboundLocationService], (service: CreateInboundLocationService) => {
    expect(service).toBeTruthy();
  }));
});
