export class InboundAreaLocListModel {
  areaParamsList = {
    'query': {
      'bool': {
        'must': [{
          'match': {
            'bu_type': ''
          }
        }]
      }
    },
    'sort': {
      'capacity_area': {
        'order': 'asc'
      }
    },
    'from': 0,
    'size': 25
  };
  locParamsList = {
    'query': {
      'bool': {
        'must': [{
          'match': {
            'bu_type': ''
          }
        }]
      }
    },
    'sort': {
      'cust_location_name': {
        'order': 'asc'
      }
    },
    'from': 0,
    'size': 25
  };
  areaSearchParams = {

    'query':
    {

        'bool':
        {

            'must': [

                {

                    'bool':
                    {

                        'should': [

                            {

                                'wildcard':
                                {

                                    'service_offering':
                                    {

                                        'value': 'John*'

                                    }

                                }

                            },

                            {

                                'wildcard':
                                {

                                    'fleet_type':
                                    {

                                        'value': 'John*'

                                    }

                                }

                            },

                            {

                                'wildcard':
                                {

                                    'capacity_area':
                                    {

                                        'value': 'John*'

                                    }

                                }

                            },

                            {

                                'wildcard':
                                {

                                    'capacity_owner':
                                    {

                                        'value': 'John*'

                                    }

                                }

                            },

                            {

                                'nested':
                                {

                                    'path': 'specific_dates',

                                    'query':
                                    {

                                        'prefix':
                                        {

                                            'specific_dates.date.merged':
                                            {

                                                'value': 'John'

                                            }

                                        }

                                    }

                                }

                            },

                            {

                                'nested':
                                {

                                    'path': 'specific_dates',

                                    'query':
                                    {

                                        'query_string':
                                        {

                                            'fields': [

                                                'specific_dates.Limit.Inlimit'

                                            ],

                                            'query': 'John'

                                        }

                                    }

                                }

                            },

                            {

                                'nested':
                                {

                                    'path': 'daily_limit',

                                    'query':
                                    {

                                        'wildcard':
                                        {

                                            'daily_limit.week_day_code':
                                            {

                                                'value': 'John*'

                                            }

                                        }

                                    }

                                }

                            },

                            {

                                'nested':
                                {

                                    'path': 'daily_limit',

                                    'query':
                                    {

                                        'query_string':
                                        {

                                            'fields': [

                                                'daily_limit.limit_count.Inlimit_count'

                                            ],

                                            'query': 'John'

                                        }

                                    }

                                }

                            }

                        ]

                    }

                },

                {

                    'match':
                    {

                        'bu_type': 'JBT'

                    }

                },

                {

                    'match':
                    {

                        'status': 'active'

                    }

                }

            ]

        }

    },

    'sort': [

        {

            'capacity_area':
            {

                'order': 'asc'

            }

        }

    ]

};
  locSearchParams = {

    'query':
    {

        'bool':
        {

            'must': [

                {

                    'bool':
                    {

                        'should': [

                            {

                                'wildcard':
                                {

                                    'fleet_type':
                                    {

                                        'value': 'John*'

                                    }

                                }

                            },

                            {

                                'wildcard':
                                {

                                    'service_offering':
                                    {

                                        'value': 'John*'

                                    }

                                }

                            },

                            {

                                'wildcard':
                                {

                                    'cust_location_name':
                                    {

                                        'value': 'John*'

                                    }

                                }

                            },

                            {

                                'wildcard':
                                {

                                    'cust_location_address':
                                    {

                                        'value': 'John*'

                                    }

                                }

                            },

                            {

                                'wildcard':
                                {

                                    'cust_location_code':
                                    {

                                        'value': '*John*'

                                    }

                                }

                            },

                            {

                                'wildcard':
                                {

                                    'capacity_owner':
                                    {

                                        'value': 'John*'

                                    }

                                }

                            },

                            {

                                'nested':
                                {

                                    'path': 'specific_dates',

                                    'query':
                                    {

                                        'prefix':
                                        {

                                            'specific_dates.date.merged':
                                            {

                                                'value': 'John'

                                            }

                                        }

                                    }

                                }

                            },

                            {

                                'nested':
                                {

                                    'path': 'specific_dates',

                                    'query':
                                    {

                                        'query_string':
                                        {

                                            'fields': ['specific_dates.Limit.Inlimit'],

                                            'query': 'John'

                                        }

                                    }

                                }

                            },

                            {

                                'nested':
                                {

                                    'path': 'daily_limit',

                                    'query':
                                    {

                                        'wildcard':
                                        {

                                            'daily_limit.week_day_code':
                                            {

                                                'value': 'John*'

                                            }

                                        }

                                    }

                                }

                            },

                            {

                                'nested':
                                {

                                    'path': 'daily_limit',

                                    'query':
                                    {

                                        'query_string':
                                        {

                                            'fields': ['daily_limit.limit_count.Inlimit_count'],

                                            'query': 'John'

                                        }

                                    }

                                }

                            }





                        ]

                    }

                },

                {

                    'match':
                    {

                        'bu_type': 'JBI'

                    }

                },

                {

                    'match':
                    {

                        'status': 'active'

                    }

                }

            ]

        }

    },

    'sort': [

        {

            'cust_location_name':
            {

                'order': 'asc'

            }

        }

    ]

};
  filterByParams = {

    'query': {

      'bool': {

        'must': [

          {

            'wildcard': {

              'capacity_area': {

                'value': '*'

              }

            }

          },

          {

            'query_string': {

              'fields': ['capacity_owner'],

              'query': 'John,Peter'

            }

          },

          {

            'query_string': {

              'fields': ['service_offering'],

              'query': '*'

            }

          },

          {

            'query_string': {

              'fields': ['fleet_type'],

              'query': '*'

            }

          },

          {

            'match': {

              'bu_type': 'JBT'

            }

          },

          {

            'match': {

              'status': 'active'

            }

          }

        ]

      }

    },

    'sort': [

      {

        'capacity_area': {

          'order': 'asc'

        }

      }

    ]

  };
  capacityAreaParams = {

    'query':
    {

        'prefix':
        {

            'capacity_area':
            {

                'value': ''

            }

        }

    }

    ,
    '_source': ['capacity_area']

};
}
