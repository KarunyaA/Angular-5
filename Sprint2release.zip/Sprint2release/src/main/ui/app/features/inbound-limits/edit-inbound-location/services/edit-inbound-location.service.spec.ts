import { TestBed, inject } from '@angular/core/testing';

import { EditInboundLocationService } from './edit-inbound-location.service';

describe('EditInboundLocationService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [EditInboundLocationService]
    });
  });

  it('should be created', inject([EditInboundLocationService], (service: EditInboundLocationService) => {
    expect(service).toBeTruthy();
  }));
});
