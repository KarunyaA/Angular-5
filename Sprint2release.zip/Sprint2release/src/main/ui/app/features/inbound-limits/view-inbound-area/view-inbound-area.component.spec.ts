import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewInboundAreaComponent } from './view-inbound-area.component';

describe('ViewInboundAreaComponent', () => {
  let component: ViewInboundAreaComponent;
  let fixture: ComponentFixture<ViewInboundAreaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewInboundAreaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewInboundAreaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
