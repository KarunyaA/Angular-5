import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/catch';
import { Data } from '@angular/router';

import { AppConfig } from '../../../../../config/app.config';
import { AppLocalConfig } from '../../../../../config/app.local.config';
import { environment } from '../../../../../environments/environment';
import { SpinnerService } from '../../../../shared/spinner/index';

@Injectable()
export class InboundAreaLocListService {
  appConfig = (environment.envName === 'local') ? AppLocalConfig.getConfig() : AppConfig.getConfig();
  constructor(private spinnerService: SpinnerService, private http: HttpClient) {}
  getLocationData(reqObject): Observable < any > {
    return this.addData(this.appConfig.api.inboundlimits.getinboundlocations, reqObject, true);
  }
  getAreaData(reqObject): Observable < any > {
    return this.addData(this.appConfig.api.inboundlimits.getinboundareas, reqObject, true);
  }
  getAreaSearchData(reqObject): Observable < any > {
    return this.addData(this.appConfig.api.inboundlimits.getinboundareas, reqObject, true);
  }
  getLocationSearchData(reqObject): Observable < any > {
    return this.addData(this.appConfig.api.inboundlimits.getinboundlocations, reqObject, true);
  }
  getAreaFilterData(reqObject): Observable < any > {
    return this.addData(this.appConfig.api.inboundlimits.getinboundareas, reqObject, true);
  }
  getLocFilterData(reqObject): Observable < any > {
    return this.addData(this.appConfig.api.inboundlimits.getinboundareas, reqObject, true);
  }
  addData(url, body: Object, headers ?: any): Observable < any[] > {
    this.spinnerService.show();
    this.spinnerService.spinnerText = 'Processing Service Requests ...';
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Cache-Control': 'no-cache',
        'Pragma': 'no-cache'
      })
    };

    const bodyString = JSON.stringify(body);
    return this.http.post < any > (url, bodyString, httpOptions).map((res: any) => {
      this.spinnerService.hide();
      return res;
    }).catch((err: HttpErrorResponse) => {
        // simple logging, but you can do a lot more, see below
        // console.error('An error occurred:', err.error);
        this.spinnerService.hide();
         return err.error;
      });
    }
  }
