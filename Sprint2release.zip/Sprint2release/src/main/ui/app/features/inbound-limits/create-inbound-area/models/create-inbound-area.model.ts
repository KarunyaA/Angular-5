import { FormBuilder, FormControl, FormGroup, Validators, FormArray } from '@angular/forms';

export class InboundAreaModel {
  myForm: FormGroup;
  userform: FormGroup;
  serviceOfferingList: object[];
  businessUnit: string;
  serviceOffering: string;
  fleetType: string;
  specificDates: Array<Object>;
  fleetTypeList: object[];
  filteredArea: object[];
  duplicateArray: string[] = [];
  days: string[];
  Sunday: number;
  Monday: number;
  Tuesday: number;
  Wednesday: number;
  Thursday: number;
  Friday: number;
  Saturday: number;
  areaFlag: boolean;
  limt: boolean;
  serviceOfferingFlag: boolean;
  fleetTypeFlag: boolean;
  icsFleetype: object[];
  jbiFleetype: object[];
  jbtFleetype: object[];
  dcsFleetype: object[];
  capacityArea: string;
  newDateArray: any[];
  showError: boolean;
  specificDateError: boolean;
  labelFloat: boolean;
  fleetFloat: boolean;
  constructor() {
    this.icsFleetype = [{ name: 'Alternative', code: 'Alternative' }];
    this.jbiFleetype = [{ name: 'Intermodal', code: 'Intermodal' }];
    this.jbtFleetype = [{ name: 'OTR', code: 'OTR' }, { name: 'Regional', code: 'Regional' },
     { name: 'Van Engineered', code: 'VanEngineered' }];
    this.dcsFleetype = [{ name: 'DCS Backhaul', code: 'DCSBackhaul' }];
    this.showError = false;
    this.specificDateError = false;
    this.days = [];
    this.duplicateArray = [];
  }
}
