import {Component, OnInit, Input, ViewChild} from '@angular/core';
import {InboundAreaLocListModel} from './models/inbound-area-loc-list.model';

import {InboundAreaLocListService} from '../inbound-area-loc-list/services/inbound-area-loc-list.service';

@Component({
  selector: 'app-inbound-area-loc-list',
  templateUrl: './inbound-area-loc-list.component.html',
  styleUrls: ['./inbound-area-loc-list.component.scss']
})
export class InboundAreaLocListComponent implements OnInit {
  @Input() businessUnitType: any;
  selectedRow: any;
  isDataTableDetailOpen;
  filterFlag = 0;
  searchValue: any;
  formFlag = 0;
  formEditFlag = 0;
  formViewFlag = 0;
  formAddFlag = 0;
  dropdownvalue = 'inboundarea';
  filteredCountriesMultiple: any[];
  columnOptions: object[];
  items: object[];
  isController = true;
  dropdownLables: object[];
  breadcrumItems: object[];
  areaSource: object[];
  locSource: object[];
  dailyLimitList: object[];
  areaSearch: any = '';
  ownerSearch: any = '';
  searchValueEscape: any;
  searchDate: any;
  @Input() state: any = '';
  areaSourceLength: number;
  locSourceLength: number;
  dialogDisplay = false;
  searchInput: string;
  totalAreaRecords: number;
  totalLocRecords: number;
  selectedOfferings: string[] = [];
  selectedFleet: string[] = [];
  params: any;
  inboundAreaLocListModel: InboundAreaLocListModel;
  inboundCapacityLimitID = 0;
  constructor(private service: InboundAreaLocListService) {
    this.dropdownLables = [{
      label: 'Inbound Area Limits',
      value: 'inboundarea'
    }, {
      label: 'Inbound Location Limits',
      value: 'inboundlocation'
    }];
    this.inboundAreaLocListModel = new InboundAreaLocListModel();
  }
  ngOnInit() {
    const bu = this.businessUnitType;
    this.inboundAreaLocListModel['areaParamsList']['query']['bool']['must'][0]['match']['bu_type'] = bu;
    this.inboundAreaLocListModel['locParamsList']['query']['bool']['must'][0]['match']['bu_type'] = bu;
    this.inboundAreaLocListModel['areaSearchParams']['query']['bool']['must'][1]['match']['bu_type'] = bu;
    this.inboundAreaLocListModel['locSearchParams']['query']['bool']['must'][1]['match']['bu_type'] = bu;
    this.inboundAreaLocListModel['filterByParams']['query']['bool']['must'][4]['match']['bu_type'] = bu;
    this.breadcrumItems = [{
      label: 'Home',
      url: '#'
    }, {
      label: 'Capacity Settings'
    }];
    this.columnOptions = [];
    this.items = this.items = [{
      label: 'Add Inbound Limit',
      command: (onclick) => {
        this.formFlag = 1;
        this.formViewFlag = 0;
        this.formEditFlag = 0;
        this.formAddFlag = 1;
        this.filterFlag = 0;
        this.isDataTableDetailOpen = true;
      }
    }, {
      label: 'Manage Columns',
      command: (onclick) => {
        this.showDialog();
      }
    }, {
      label: 'Export to Excel'
    }];
  }
  addinbound() {
    this.formFlag = 1;
    this.formViewFlag = 0;
    this.formEditFlag = 0;
    this.formAddFlag = 1;
    this.filterFlag = 0;
    this.isDataTableDetailOpen = true;
  }
  editinbound(id: number) {
    this.formFlag = 1;
    this.formEditFlag = 1;
    this.formViewFlag = 0;
    this.formAddFlag = 0;
    this.filterFlag = 0;
    this.isDataTableDetailOpen = true;
    this.inboundCapacityLimitID = id;

  }
  viewinbound() {
    this.formFlag = 1;
    this.formEditFlag = 0;
    this.formViewFlag = 1;
    this.formAddFlag = 0;
    this.filterFlag = 0;
    this.isDataTableDetailOpen = true;
  }
  onToggelController() {
    this.isController = !this.isController;
  }

  handleRowSelect(event, data) {
    this.isDataTableDetailOpen = true;
    this.selectedRow = data;
  }
  onCloseSplitView() {
    this.isDataTableDetailOpen = false;
  }

  showDialog() {
    this.dialogDisplay = true;
  }
  handleChange(e) {
    const isChecked = e.checked;
  }
  onRowSelect(event: object): void {
    this.formFlag = 1;
    this.filterFlag = 0;
    this.formEditFlag = 0;
    this.formViewFlag = 1;
    this.formAddFlag = 0;
    this.isDataTableDetailOpen = true;
    this.dailyLimitList = [];
    const dayList = [{
        week_day_code: 'Sunday',
        limit_count: '-'
      },
      {
        week_day_code: 'Monday',
        limit_count: '-'
      },
      {
        week_day_code: 'Tuesday',
        limit_count: '-'
      },
      {
        week_day_code: 'Wednesday',
        limit_count: '-'
      },
      {
        week_day_code: 'Thursday',
        limit_count: '-'
      },
      {
        week_day_code: 'Friday',
        limit_count: '-'
      },
      {
        week_day_code: 'Saturday',
        limit_count: '-'
      }
    ];
    if (this.selectedRow !== undefined && this.selectedRow['_source']['daily_limit'] !== undefined) {
      const dailyLimitList = this.selectedRow['_source']['daily_limit'];
      for (let i = 0; i < dayList.length; i++) {
        this.dailyLimitList.push(dayList[i]);
        for (let j = 0; j < dailyLimitList.length; j++) {
          if (dayList[i]['week_day_code'] === dailyLimitList[j]['week_day_code']) {
            this.dailyLimitList[i] = dailyLimitList[j];
          }
        }
      }
    }
  }
  removeForm(event: string): void {
    this.formFlag = 0;
    this.filterFlag = 0;
  }
  showFilter(event: string): void {
    this.filterFlag = (this.filterFlag === 0) ? 1 : 0;
    this.formFlag = 0;
  }
  onSelectType(event) {
    this.formFlag = 0;
    this.searchInput = '';
    if (event === 'inboundlocation') {
      this.dropdownvalue = 'inboundlocation';
      this.fetchAllLocationData();
    } else {
      this.dropdownvalue = 'inboundarea';
      this.fetchAllAreaData();
    }
  }

  onSearchChange(value: any) {
    const bu = this.businessUnitType;
    this.searchValueEscape = value.replace(/[[\]{}()*:"~&!?\\^$|]/g, '\\$&');
    const commaEscape = this.searchValueEscape.replace(/\,/g, '');
    this.searchDate = value.replace(/[[\]{}()*:"~&!?\\^$|]/g, '\\$&').replace(/\//g, '-');
    if ((value.length > 2) && (this.dropdownvalue === 'inboundarea')) {
      this.params = this.inboundAreaLocListModel.areaSearchParams['query']['bool']['must'][0];
      this.params['bool']['should'][0]['wildcard']['service_offering']['value'] = value + '*';
      this.params['bool']['should'][1]['wildcard']['fleet_type']['value'] = value + '*';
      this.params['bool']['should'][2]['wildcard']['capacity_area']['value'] = value + '*';
      this.params['bool']['should'][3]['wildcard']['capacity_owner']['value'] = value + '*';
      this.params['bool']['should'][4]['nested']['query']['prefix']['specific_dates.date.merged']['value'] = this.searchDate;
      this.params['bool']['should'][5]['nested']['query']['query_string']['query'] = commaEscape;
      this.params['bool']['should'][6]['nested']['query']['wildcard']['daily_limit.week_day_code']['value'] = commaEscape + '*';
      this.params['bool']['should'][7]['nested']['query']['query_string']['query'] = this.searchValueEscape;
      this.service.getAreaSearchData(this.inboundAreaLocListModel.areaSearchParams).subscribe(data => {
        this.areaSource = data['hits']['hits'];
      });
    } else if ((value.length > 2) && (this.dropdownvalue === 'inboundlocation')) {
      this.params = this.inboundAreaLocListModel.locSearchParams['query']['bool']['must'][0];
      this.params['bool']['should'][0]['wildcard']['fleet_type']['value'] = value + '*';
      this.params['bool']['should'][1]['wildcard']['service_offering']['value'] = value + '*';
      this.params['bool']['should'][2]['wildcard']['cust_location_name']['value'] = value + '*';
      this.params['bool']['should'][3]['wildcard']['cust_location_address']['value'] = value + '*';
      this.params['bool']['should'][4]['wildcard']['cust_location_code']['value'] = value + '*';
      this.params['bool']['should'][5]['wildcard']['capacity_owner']['value'] = value + '*';
      this.params['bool']['should'][6]['nested']['query']['prefix']['specific_dates.date.merged']['value'] = this.searchDate;
      this.params['bool']['should'][7]['nested']['query']['query_string']['query'] = commaEscape;
      this.params['bool']['should'][8]['nested']['query']['wildcard']['daily_limit.week_day_code']['value'] = commaEscape;
      this.params['bool']['should'][9]['nested']['query']['query_string']['query'] = this.searchValueEscape;
      this.service.getLocationSearchData(this.inboundAreaLocListModel.locSearchParams).subscribe(data => {
        this.locSource = data['hits']['hits'];
      });
    } else if ((value.length < 3) && (this.dropdownvalue === 'inboundarea')) {
      this.service.getAreaData(this.inboundAreaLocListModel.areaParamsList).subscribe(data => {
        this.areaSource = data['hits']['hits'];
      });
    } else if ((value.length < 3) && (this.dropdownvalue === 'inboundlocation')) {
      this.service.getLocationData(this.inboundAreaLocListModel.locParamsList).subscribe(data => {
        this.locSource = data['hits']['hits'];
      });
    }
  }
  closeSplit(event): void {
    this.formFlag = 0;
    const bu = this.businessUnitType;
    setTimeout(() => {
      if (this.dropdownvalue === 'inboundarea') {
        this.fetchAllAreaData();
      } else {
        this.fetchAllLocationData();
      }
    }, 1000);
  }
  private fetchAllAreaData(): void {
    this.service.getAreaData(this.inboundAreaLocListModel.areaParamsList).subscribe(data => {
      this.areaSource = data.hits.hits;
      this.areaSourceLength = this.areaSource.length;
      this.totalAreaRecords = data['hits']['total'];
    });
  }
  private fetchAllLocationData(): void {
    this.service.getLocationData(this.inboundAreaLocListModel.locParamsList).subscribe(data => {
      this.locSource = data.hits.hits;
      this.locSourceLength = this.locSource.length;
      this.totalLocRecords = data['hits']['total'];
      console.log(this.totalLocRecords);
    });
  }

  onPage(event) {
      if (this.dropdownvalue === 'inboundarea') {
        this.inboundAreaLocListModel.areaParamsList['from'] = event.first;
        this.inboundAreaLocListModel.areaParamsList['size'] = event.rows;
        this.fetchAllAreaData();
      } else if (this.dropdownvalue === 'inboundlocation') {
        this.inboundAreaLocListModel.locParamsList['from'] = event.first;
        this.inboundAreaLocListModel.locParamsList['size'] = event.rows;
        this.fetchAllLocationData();
      }
  }
  onAreaSearch(val) {
    this.areaSearch = val;
    this.params = this.inboundAreaLocListModel.capacityAreaParams;
    if (val) {
    this.params['query']['bool']['must'][0]['wildcard']['capacity_area']['value'] = this.areaSearch + '*';
    this.fetchAllFilterAreaData();
    }
  }
  onOwnerSearch(val) {
    this.ownerSearch = ' AND ' + val;
    this.params = this.inboundAreaLocListModel.filterByParams;
    if (val) {
    this.params['query']['bool']['must'][1]['query_string']['query'] = this.ownerSearch;
    this.fetchAllFilterAreaData();
    }
  }
  onStatus() {
    if (this.state) {
    this.params = this.inboundAreaLocListModel.filterByParams;
    this.params['query']['bool']['must'][0]['query_string']['query'] = this.areaSearch + this.ownerSearch + ' AND ' + this.state;
    this.fetchAllFilterAreaData();
    }
  }
  serviceCahnge() {
    this.params = this.inboundAreaLocListModel.filterByParams;
    this.params['query']['bool']['must'][2]['query_string']['query'] = this.selectedOfferings;
    this.fetchAllFilterAreaData();
  }
  fleetChange() {
    this.params = this.inboundAreaLocListModel.filterByParams;
    this.params['query']['bool']['must'][3]['query_string']['query'] = this.selectedFleet;
    this.fetchAllFilterAreaData();
  }
  private fetchAllFilterAreaData(): void {
    /* this.service.getAreaFilterData(this.inboundAreaLocListModel.filterByParams).subscribe(data => {
      this.areaSource = data['hits']['hits'];
      this.areaSourceLength = this['areaSource']['length'];
      this.totalAreaRecords = data['hits']['total'];
    }); */
  }
  private fetchAllFilterLocData(): void {
    /* this.service.getLocFilterData(this.inboundAreaLocListModel.filterByParams).subscribe(data => {
      this.locSource = data.hits.hits;
      this.locSourceLength = this.locSource.length;
      this.totalLocRecords = data['hits']['total'];
    }); */
  }
  clearFilters() {
    this.fetchAllAreaData();
  }
}
