import { Component, OnInit, Input} from '@angular/core';
import {FormBuilder,  FormGroup, Validators} from '@angular/forms';


@Component({
  selector: 'app-add-specificdate',
  templateUrl: './add-specificdate.component.html',
  styleUrls: ['./add-specificdate.component.scss']
})
export class AddSpecificdateComponent implements OnInit {
  @Input() group: any;
  @Input() myFormObj: any;
  dateForm: FormGroup;
  specificDateForm: FormGroup;
  newDateArray: any[];
  formValid1: boolean;
  constructor() { }
  date = new Date();
  today = new Date();
  ngOnInit() {
    this.today.setDate =  this.date.getDate;
    this.today.setMonth = this.date.getMonth;
    this.today.setFullYear = this.date.getFullYear;

  }
  getDate(value) {
    if (value !== undefined) {
        this.newDateArray.push(value);
    }
}
}
