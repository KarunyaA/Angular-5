
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/catch';
import { Data } from '@angular/router';

import { AppConfig } from 'config/app.config';
import { AppLocalConfig } from 'config/app.local.config';
import { environment } from 'environments/environment';
import { SpinnerService } from 'app/shared/spinner/index';
@Injectable()
export class CreateInboundLocationService {

  appConfig = (environment.envName === 'local') ? AppLocalConfig.getConfig() : AppConfig.getConfig();
  constructor(private spinnerService: SpinnerService, private http: HttpClient) {}

  getServiceOffering(bu: string) {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    let url = this.appConfig.api.inboundlimits.serviceofferring;
    url += '?financeBusinessUnitCode=' + bu + '&projection=viewserviceofferingbusinessunittransitmode';
    return this.http.get <Object> (url, {
      headers
    });
  }
  getFleetType(bu: string, so: string) {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    let url = this.appConfig.api.inboundlimits.fleettype;
    url += '?financeBusinessUnitCode=' + bu + '&serviceOffering=' + so + ';';
    return this.http.get <Object> (url, {
      headers
    });
  }
  getLocationDTO(queryParam) {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const url = this.appConfig.api.inboundlimits.inboundlocation;
    return this.http.post <Object> (url, queryParam)
      .toPromise()
      .then(data => data);
  }
  saveInboundArea(requestParam: object): Observable <any> {
    return this.addData(this.appConfig.api.inboundlimits.saveinboundlimits, requestParam, true);
  }
  private addData(url, body: Object, headers ?: any): Observable <any[]> {
    this.spinnerService.show();
    this.spinnerService.spinnerText = 'Processing Service Requests ...';
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Cache-Control': 'no-cache',
        'Pragma': 'no-cache'
      })
    };

    const bodyString = JSON.stringify(body);
    return this.http.post <Object> (url, bodyString, httpOptions).map((res: any) => {
      this.spinnerService.hide();
      return res;
    }).catch((err: HttpErrorResponse) => {
        this.spinnerService.hide();
         return [err];
      });

    }
}

