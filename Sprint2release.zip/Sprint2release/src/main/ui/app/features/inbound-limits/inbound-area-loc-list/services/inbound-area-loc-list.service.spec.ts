import { TestBed, inject } from '@angular/core/testing';

import { InboundAreaLocListService } from './inbound-area-loc-list.service';

describe('InboundAreaLocListService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [InboundAreaLocListService]
    });
  });

  it('should be created', inject([InboundAreaLocListService], (service: InboundAreaLocListService) => {
    expect(service).toBeTruthy();
  }));
});
