import { TestBed, inject } from '@angular/core/testing';

import { EditInboundAreaService } from './edit-inbound-area.service';

describe('EditInboundAreaService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [EditInboundAreaService]
    });
  });
  it('should be created', inject([EditInboundAreaService], (service: EditInboundAreaService) => {
    expect(service).toBeTruthy();
  }));
});
