import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { InboundLimitsRoutingModule } from './inbound-limits-routing.module';
import { InboundAreaListComponent } from './inbound-area-list/inbound-area-list.component';
import { InboundLocationListComponent } from './inbound-location-list/inbound-location-list.component';
import { CreateInboundLocationComponent } from './create-inbound-location/create-inbound-location.component';
import { CreateInboundAreaComponent } from './create-inbound-area/create-inbound-area.component';
import { ViewInboundAreaComponent } from './view-inbound-area/view-inbound-area.component';
import { EditInboundAreaComponent } from './edit-inbound-area/edit-inbound-area.component';
import { EditInboundLocationComponent } from './edit-inbound-location/edit-inbound-location.component';
import { ViewInboundLocationComponent } from './view-inbound-location/view-inbound-location.component';
import { InboundLimitComponent } from './inbound-limit/inbound-limit.component';
import { AddSpecificdateComponent } from './add-specificdate/add-specificdate.component';

import { DataTableModule } from 'primeng/datatable';
import { ContextMenuModule } from 'primeng/contextmenu';
import { InputTextModule } from 'primeng/inputtext';
import { MenuModule } from 'primeng/menu';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { TableModule } from 'primeng/table';
import { ScrollPanelModule } from 'primeng/scrollpanel';
import { PaginatorModule } from 'primeng/paginator';
import { ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';
import { OrderListModule } from 'primeng/orderlist';
import { ToggleButtonModule } from 'primeng/togglebutton';
import { MenuItem } from 'primeng/api';
import { AccordionModule } from 'primeng/accordion';
import { CheckboxModule } from 'primeng/checkbox';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RadioButtonModule } from 'primeng/radiobutton';
import { DropdownModule } from 'primeng/dropdown';
import { BreadcrumbModule } from 'primeng/breadcrumb';
import { TabViewModule } from 'primeng/tabview';
import { PanelModule } from 'primeng/panel';
import { SpinnerModule } from 'primeng/spinner';
import { CalendarModule } from 'primeng/calendar';
import { GrowlModule } from 'primeng/growl';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { KeyFilterModule } from 'primeng/keyfilter';

import { InboundAreaLocListComponent } from './inbound-area-loc-list/inbound-area-loc-list.component';
import { ThousandsSeparatorPipe } from './inbound-area-loc-list/pipes/thousands-separator.pipe';
import { FirstLetterOfWordPipe } from './inbound-area-loc-list/pipes/first-letter-of-word.pipe';
import { ConfirmationService } from 'primeng/api';

import { EditInboundAreaService } from './edit-inbound-area/services/edit-inbound-area.service';
import { EditInboundLocationService } from './edit-inbound-location/services/edit-inbound-location.service';
import { InboundAreaLocListService } from './inbound-area-loc-list/services/inbound-area-loc-list.service';
import { CreateInboundAreaService } from './create-inbound-area/services/create-inbound-area.service';
import { CreateInboundLocationService } from './create-inbound-location/services/create-inbound-location.service';
@NgModule({
    imports: [
        CommonModule,
        InboundLimitsRoutingModule,
        DataTableModule,
        ContextMenuModule,
        InputTextModule,
        MenuModule,
        AutoCompleteModule,
        TableModule,
        ScrollPanelModule,
        CalendarModule,
        SpinnerModule,
        PaginatorModule,
        ButtonModule,
        DialogModule,
        OrderListModule,
        ToggleButtonModule,
        AccordionModule,
        CheckboxModule,
        FormsModule,
        RadioButtonModule,
        GrowlModule,
        ReactiveFormsModule,
        DropdownModule,
        BreadcrumbModule,
        TabViewModule,
        PanelModule,
        ConfirmDialogModule,
        KeyFilterModule
    ],
    declarations: [InboundAreaListComponent, InboundLocationListComponent,
        CreateInboundLocationComponent, CreateInboundAreaComponent,
        ViewInboundAreaComponent, EditInboundAreaComponent, EditInboundLocationComponent,
        ViewInboundLocationComponent,
        InboundLimitComponent,
        InboundAreaLocListComponent,
        ThousandsSeparatorPipe,
        FirstLetterOfWordPipe,
        AddSpecificdateComponent,
        ThousandsSeparatorPipe
    ],
    providers: [ConfirmationService, EditInboundAreaService, EditInboundLocationService,
    InboundAreaLocListService, CreateInboundAreaService, CreateInboundLocationService]
})
export class InboundLimitsModule { }
