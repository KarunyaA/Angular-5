export class InboundLimitModel {
    breadCrumbItems: any;
    buJBT = 'JBT';
    buJBI = 'JBI';
    buDCS = 'DCS';
    buICS = 'ICS';
    constructor() {
        this.breadCrumbItems = [{
                label: 'Home',
                url: 'dashboard'
            },
            {
                label: 'Capacity Settings',
                url: 'capacitysettings'
            }
        ];
    }
}
