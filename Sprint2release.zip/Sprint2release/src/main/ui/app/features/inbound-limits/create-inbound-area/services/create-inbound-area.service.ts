import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/catch';
import { Data } from '@angular/router';

import { AppConfig } from 'config/app.config';
import { AppLocalConfig } from 'config/app.local.config';
import { environment } from 'environments/environment';
import { SpinnerService } from 'app/shared/spinner/index';
@Injectable()
export class CreateInboundAreaService {
  appConfig = (environment.envName === 'local') ? AppLocalConfig.getConfig() : AppConfig.getConfig();
  constructor(private spinnerService: SpinnerService, private http: HttpClient) {}


  getCapacityArea(query, businessUnit: string) {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    let url = this.appConfig.api.inboundlimits.capacityarea;
    url += '?areaName=' + query + '&businessUnit=' + businessUnit;

    return this.http.get <any> (url)
      .toPromise()
      .then(data => {
        return data;
      });
  }

  getServiceOffering(businessUnit: string) {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    let url = this.appConfig.api.inboundlimits.serviceofferring;
    url += '?financeBusinessUnitCode=' + businessUnit + '&projection=viewserviceofferingbusinessunittransitmode';

    return this.http.get <object> (url, {
      headers
    });
  }

  getFleetType(businessUnit: string, serviceOffering: string) {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    let url = this.appConfig.api.inboundlimits.fleettype;
    url += '?financeBusinessUnitCode=' + businessUnit + '&serviceOffering=' + serviceOffering;
    return this.http.get <object> (url, {
      headers
    });
  }
  saveInboundArea(requestParam: object): Observable<object> {
    return this.addData(this.appConfig.api.inboundlimits.saveinboundlimits, requestParam, true);
  }

  private addData(url, body: Object, headers ?: any): Observable <any[]> {
    this.spinnerService.show();
    this.spinnerService.spinnerText = 'Processing Service Requests ...';
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Cache-Control': 'no-cache',
        'Pragma': 'no-cache'
      })
    };

    const bodyString = JSON.stringify(body);
    return this.http.post <any> (url, bodyString, httpOptions).map((res: any) => {
      this.spinnerService.hide();
      return res;
    }).catch((err: HttpErrorResponse) => {
        this.spinnerService.hide();
         return [err];
      });

    }
}

