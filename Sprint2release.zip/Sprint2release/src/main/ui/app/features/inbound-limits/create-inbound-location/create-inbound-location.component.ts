import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators, FormArray } from '@angular/forms';

import { MessageService } from 'primeng/components/common/messageservice';


import { CreateInboundLocationService } from './services/create-inbound-location.service';
import { InboundLocation } from './models/create-inbound-location-model';

@Component({
  selector: 'app-create-inbound-location',
  templateUrl: './create-inbound-location.component.html',
  styleUrls: ['./create-inbound-location.component.scss']
})

export class CreateInboundLocationComponent implements OnInit {
  @Input() businessUnitType: any;
  @Output() splitClose = new EventEmitter();
  inboundLocation: InboundLocation;
  notifications: MessageService;
  constructor(
    private createInboundLocationService: CreateInboundLocationService,
    private formBuilder: FormBuilder, private toastMessage: MessageService) {
    this.inboundLocation = new InboundLocation();
  }
  date = new Date();
  today = new Date();

  ngOnInit() {
    this.inboundLocation.locationLabel = false;
    this.inboundLocation.fleetLabel = false;
    this.today.setDate = this.date.getDate;
    this.today.setMonth = this.date.getMonth;
    this.today.setFullYear = this.date.getFullYear;
    this.inboundLocation.locationFlag = false;
    this.inboundLocation.serviceOfferingFlag = false;
    this.inboundLocation.fleetTypeFlag = false;
    this.inboundLocation.businessUnitCode = this.businessUnitType;
    this.getServiceOffering();
    this.addFormLocation();
    this.inboundLocation.specificDateError = false;
    this.inboundLocation.showMessage = false;
  }
  addFormLocation(): void {
    this.inboundLocation.myForm = this.formBuilder.group({
      'capacityLocation': ['', Validators.required],
      'fleetType': ['', Validators.required],
      'serviceOffering': ['', Validators.required],
      'sunday': new FormControl(''),
      'monday': new FormControl(''),
      'tuesday': new FormControl(''),
      'wednesday': new FormControl(''),
      'thursday': new FormControl(''),
      'friday': new FormControl(''),
      'saturday': new FormControl(''),
      date: this.formBuilder.array([]),
    });
  }
  getDate(value) {
    if (value !== undefined) {
      this.inboundLocation.newDateArray.push(value);
    }
  }

  getForm(myForm): any {
    return myForm.controls.date.controls;
  }

  formControl(myForm, i): any {
    return myForm.controls.date.controls[i];
  }

  initDate(): any {
    return this.formBuilder.group({
      specificDate: [''],
      specificDateLimit: ['']
    });
  }

  addNewDate(): void {
    const control = <FormArray>(this.inboundLocation.myForm.controls['date']);
    const addCtrl = this.initDate();
    addCtrl.valueChanges.subscribe(checkDates => {
      this.checkDuplicate(checkDates, control);
    });
    control.push(addCtrl);
  }

  checkDuplicate(date: any, formArray: FormArray): void {
    const newDate = date;
    const dateArray = formArray.controls;
    const duplicateVal = [];
    this.inboundLocation.showMessage = false;
    if (formArray.controls.length > 1) {
      formArray.controls.forEach(element => {
        if (element.value.specificDate !== '' && element.value.specificDate !== null) {
          if (element.value.specificDate.indexOf(newDate.specificDate) !== -1) {
            this.inboundLocation.duplicateDateCheck.push(newDate.specificDate);
            if (this.inboundLocation.duplicateDateCheck.length > 1) {
              this.inboundLocation.showMessage = true;
            }
          }
        }
      });
      this.inboundLocation.duplicateDateCheck = [];
    } else {
      this.inboundLocation.showMessage = false;
    }
  }

  removeDate(i: number): void {
    const control = <FormArray>this.inboundLocation.myForm.controls['date'];
    control.removeAt(i);
    const newControl = <FormArray>this.inboundLocation.myForm.controls['date'];
    if (newControl.controls.length > 1) {
      this.customGroupValidation(newControl);
      this.inboundLocation.showMessage = false;
    } else {
      this.inboundLocation.specificDateError = false;
      this.inboundLocation.showMessage = false;
    }
    if (newControl.controls.length === 1) {
      this.inboundLocation.specificDateError = false;
    }
  }

  customGroupValidation(formArray: any): void {
    const uniqueNames = [];
    if (formArray.controls.length > 1) {
      this.inboundLocation.showMessage = false;
      for (let i = 0; i < formArray.controls.length; i++) {
        if (uniqueNames.indexOf(formArray.controls[i].value.specificDate) === -1) {
          this.inboundLocation.showMessage = false;
          uniqueNames.push(formArray.controls[i].value.specificDate);
        } else {
          this.inboundLocation.showMessage = true;
        }
      }
    }
  }

  getServiceOffering(): void {
    this.createInboundLocationService.getServiceOffering(this.inboundLocation.businessUnitCode).subscribe(data => {
      if (data && data['_embedded'] && data['_embedded']['serviceOfferingBusinessUnitTransitModeAssociations']) {
        const listData = data['_embedded']['serviceOfferingBusinessUnitTransitModeAssociations'];
        const listValues = [];
        listData.forEach(element => {
          const obj = {
            name: element['serviceOfferingCode'],
            code: element['serviceOfferingCode']
          };
          listValues.push(obj);
        });
        this.inboundLocation.serviceOfferingList = listValues;
      }
    });
  }

  onSelectType(event: any): void {
    if (event && event.name !== '' && event.name !== null) {
      this.inboundLocation.locationLabel = true;
    }
    switch (this.businessUnitType) {
      case 'JBI':
        this.inboundLocation.fleetTypeList = this.inboundLocation.jbiFleetype;
        break;
      case 'JBT':
        this.inboundLocation.fleetTypeList = this.inboundLocation.jbtFleetype;
        break;
      case 'DCS':
        this.inboundLocation.fleetTypeList = this.inboundLocation.dcsFleetype;
        break;
      case 'ICS':
        this.inboundLocation.fleetTypeList = this.inboundLocation.icsFleetype;
    }
  }

  getCapacityLocation(event: any): void {
    const queryParam = this.inboundLocation.getLocationDTO;
    queryParam['query']['bool']['must'][0]['query_string']['query'] = event.query + '*';
    this.createInboundLocationService.getLocationDTO(queryParam).then(areas => {
      if (areas && areas['hits'] && areas['hits']['hits']) {
        const locations = areas['hits']['hits'];
        const arrayList = [];
        locations.forEach(locationObj => {
          if (locationObj) {
            arrayList.push({
              id: locationObj['_id'],
              address: locationObj['_source']['Address']['AddressLine1'],
              name: locationObj['_source']['LocationName'],
              code: locationObj['_source']['LocationCode'],
            });
          }
        });
        this.inboundLocation.locationList = arrayList;
      }
    });
  }

  specificDates(): void {
    const dates = this.inboundLocation.myForm.value['date'];
    const arrayList = [];
    dates.forEach(dateObj => {
      const dateSeperated = dateObj['specificDate'].split('/');
      const dateArray = [parseInt(dateSeperated[2], 10),
      parseInt(dateSeperated[0], 10), parseInt(dateSeperated[1], 10)
      ];
      if (dateObj.specificDate) {
        arrayList.push({
          inboundCapacityLimitDate: dateArray,
          inboundLoadCapacityDateLimitCount: dateObj['specificDateLimit'],
        });
      }
    });
    this.inboundLocation.specificDates = arrayList;
    const dateInput = this.inboundLocation.myForm.controls.date['controls'];
    for (let n = 0; n < dateInput['length']; n++) {
      if (dateInput[n].value.specificDate &&
        dateInput[n].value.specificDateLimit === ''
        || dateInput[n].value.specificDateLimit === null) {
        this.inboundLocation.specificDateError = true;
        return;
      } else {
        this.inboundLocation.specificDateError = false;
      }
    }
  }

  onSaveLocationLimit(): void {
    const dailyLimitEntered = [];
    this.inboundLocation.dailyDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    for (let j = 0; j < this.inboundLocation.dailyDays.length; j++) {
      if (this.inboundLocation[this.inboundLocation.dailyDays[j]] >= 0 &&
        this.inboundLocation[this.inboundLocation.dailyDays[j]] !== null) {
        dailyLimitEntered.push({
          'weekDayCode': this.inboundLocation.dailyDays[j],
          'inboundLoadCapacityLimitCount': this.inboundLocation[this.inboundLocation.dailyDays[j]]
        });
      }
    }
    this.specificDates();
    const requestJson = {
      'customerLocationID': this.inboundLocation.myForm.value['capacityLocation'] ?
        this.inboundLocation.myForm.value['capacityLocation']['id'] : '',
      'customerLocationCode': this.inboundLocation.myForm.value['capacityLocation'] ?
        this.inboundLocation.myForm.value['capacityLocation']['code'] : '',
      'customerLocationName': this.inboundLocation.myForm.value['capacityLocation'] ?
        this.inboundLocation.myForm.value['capacityLocation']['name'] : '',
      'customerLocationAddress': this.inboundLocation.myForm.value['capacityLocation'] ?
        this.inboundLocation.myForm.value['capacityLocation']['address'] : '',
      'financeBusinessUnitCode': this.inboundLocation.businessUnitCode,
      'serviceOfferingCode': this.inboundLocation.myForm.value['serviceOffering'] ?
        this.inboundLocation.myForm.value['serviceOffering']['code'] : '',
      'fleetTypeCode': this.inboundLocation.myForm.value['fleetType'] ? this.inboundLocation.myForm.value['fleetType']['code'] : '',
      'specificDates': this.inboundLocation.specificDates,
      'dailyLimit': dailyLimitEntered,
    };
    this.inboundLocation.limit = dailyLimitEntered.length ? true : false;
    if (this.inboundLocation.myForm.valid) {
      if (this.inboundLocation.limit) {
        if (this.inboundLocation.showMessage === false &&
          this.inboundLocation.specificDateError === false && (this.inboundLocation.limit)) {
          this.saveValidation(requestJson);
        }
      } else {
        this.toastMessage.add({
          severity: 'Save',
          summary: 'Daily Limit',
          detail: 'Add atleast one daily limit'
        });
      }
    } else {
      this.inboundLocation.locationFlag = !this.inboundLocation.myForm.controls.capacityLocation.valid;
      this.inboundLocation.serviceOfferingFlag = !this.inboundLocation.myForm.controls.serviceOffering.valid;
      this.inboundLocation.fleetTypeFlag = !this.inboundLocation.myForm.controls.fleetType.valid;
    }
  }

  saveValidation(requestJson): void {
    this.createInboundLocationService.saveInboundArea(requestJson).subscribe(data => {
      if (data['error']) {
        if (data['error']['errorMessage'] === 'DUPLICATE_INBOUND_LOCAITON_EXISTS') {
          this.toastMessage.add({
            severity: 'error',
            summary: 'Duplicate Inbound Limit',
            detail: `${'An active inbound limit already exists, '}
              ${'please create new inbound limit or edit existing'}
              ${' inbound limits54321125 RowsJBI INBOUND LIMITSLoadsCapacity Settings'}`
          });
        }
        if (data['error']['errorMessage'] === 'INBOUND_CAPACITY_AREA_ID_OR_LOCATION_ID_NOT_FOUND') {
          this.toastMessage.add({
            severity: 'error',
            summary: 'Error',
            detail: 'Error'
          });
        }
      } else {
        this.splitClose.emit(false);
        this.toastMessage.add({
          severity: 'success',
          summary: 'Save Inbound Limit',
          detail: `${'Inbound Limit for '}${this.inboundLocation.myForm.value['capacityLocation']['name']}${' has been successfully added'}`
        });
      }
      this.inboundLocation.myForm.reset();
      this.onCancel();
    });
  }

  onSelectingFleetType(event: any): void {
    if (event && event.name !== '' && event.name !== null) {
      this.inboundLocation.fleetLabel = true;
    }
  }
  onCancel(): void {
    this.splitClose.emit(false);
    this.addFormLocation();
    this.inboundLocation.locationFlag = false;
    this.inboundLocation.serviceOfferingFlag = false;
    this.inboundLocation.fleetTypeFlag = false;
    this.inboundLocation.locationLabel = false;
    this.inboundLocation.specificDateError = false;
    this.inboundLocation.showMessage = false;
    this.inboundLocation.fleetLabel = false;
  }
  closeForm(): void {
    this.onCancel();
  }
}
