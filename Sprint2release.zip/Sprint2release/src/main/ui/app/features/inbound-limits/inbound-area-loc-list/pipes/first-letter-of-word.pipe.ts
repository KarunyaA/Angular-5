import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'firstLetterOfWord'
})
export class FirstLetterOfWordPipe implements PipeTransform {

  transform(value: any, args?: any): any {
    return value.replace(/\W*(\w)\w*/g, '$1').toUpperCase();
  }

}
