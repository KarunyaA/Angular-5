import { Component, EventEmitter, OnInit, Input, Output } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { FormGroup, FormArray, FormBuilder, Validators, FormControl } from '@angular/forms';

import { LdcSharedService } from './../service/ldc-shared.service';

import { UpdateLdcService } from './service/update-ldc.service';
import { LocalDistributionService } from '../view-ldc/service/local-distribution.service';
import { UpdateLdc } from './models/update-ldc';
import * as _ from 'lodash';
import { Message } from 'primeng/components/common/api';
import { GrowlModule } from 'primeng/growl';

@Component({
  selector: 'app-update-ldc',
  templateUrl: './update-ldc.component.html',
  styleUrls: ['./update-ldc.component.scss']
})
export class UpdateLdcComponent implements OnInit {

  updateLdcOverAll: UpdateLdc;
  viewOrderForm: FormGroup;
  msgs: Message[] = [];
  specificDateFormValue: any;
  updatedArray: any;
  utils: any;
  ldcData: any;
  updatedLDC = false;
  @Input() set ldcLocationData(ldcLocationData: any) {
    if (ldcLocationData !== undefined) {
      this.assignDailyRouteCapacity(ldcLocationData);
    }
  }
  @Input()
  set ldcUpdateData(ldcDailyRouteObject: any) {
    if (ldcDailyRouteObject !== undefined) {
      this.assignDailyRouteCapacity(ldcDailyRouteObject);
    }
  }
  @Output() spinnerFormGroup: EventEmitter<any> = new EventEmitter();
  @Output() specificDateAddOrRemove: EventEmitter<any> = new EventEmitter();
  get ldcUpdateData() {
    return this.updateLdcOverAll;
  }
  public myForm: FormGroup;
  showError: boolean;
  showEmptyDateError: boolean;
  showErrorFlag: boolean;
  localDistributionCenterDateCapacityID: FormControl;
  duplicateArray: any[] = [];
  locationID: any;
  dailyRouteCapacity: any;
  specificDates: any;
  constructor(private formBuilder: FormBuilder, private ldcSharedService: LdcSharedService,
    private updateLdcService: UpdateLdcService, private ldcService: LocalDistributionService) {

  }

  private sharedService = this.ldcSharedService.getUpdatedData().subscribe((data: any) => {
    if (typeof(data) !== 'object') {
       this.updateLDC(this.myForm.value);
   }
 });


  ngOnInit() {
    this.updatedArray = [];
    this.updateLdcOverAll = new UpdateLdc();
    this.initFormGroup();
    this.myForm['valueChanges'].
      subscribe(form => {
        this.spinnerFormGroup.emit(this.myForm);
      });
    this.showError = false;
    this.showEmptyDateError = false;
    this.showErrorFlag = false;
  }

  initFormGroup() {
    this.myForm = this.formBuilder.group({
      sundayLimit: [0, Validators.required],
      mondayLimit: [0, Validators.required],
      tuesdayLimit: [0, Validators.required],
      wednesdayLimit: [0, Validators.required],
      thursdayLimit: [0, Validators.required],
      fridayLimit: [0, Validators.required],
      saturdayLimit: [0, Validators.required],
      specificDates: this.formBuilder.array([]),
      dailyLimit: this.formBuilder.array([])
    });
  }
  assignDailyRouteCapacity(ldcDailyRouteObject: Object): void {
    this.updateLdcOverAll.ldcID = ldcDailyRouteObject['locationId'];
    if (ldcDailyRouteObject['loc'] !== undefined) {
      this.updateLdcOverAll.ldcName = ldcDailyRouteObject['loc'];
    }
    this.updateLdcOverAll.capacityId = ldcDailyRouteObject['capacityID'] ? ldcDailyRouteObject['capacityID'] : '';
    this.initFormGroup();
    if (!_.isEmpty(ldcDailyRouteObject['dailyRoute'])) {
      ldcDailyRouteObject['dailyRoute'].forEach(element => {
        switch (element['ldcday']) {
          case 'Sunday':
            this.myForm.controls['sundayLimit'].setValue(element['ldclimit']);
            this.updateLdcOverAll.sundayCapacityID = element['ldcrouteid'];
            break;
          case 'Monday':
            this.myForm.controls['mondayLimit'].setValue(element['ldclimit']);
            this.updateLdcOverAll.mondayCapacityID = element['ldcrouteid'];
            break;
          case 'Tuesday':
            this.myForm.controls['tuesdayLimit'].setValue(element['ldclimit']);
            this.updateLdcOverAll.tuesdayCapacityID = element['ldcrouteid'];
            break;
          case 'Wednesday':
            this.myForm.controls['wednesdayLimit'].setValue(element['ldclimit']);
            this.updateLdcOverAll.wednesdayCapacityID = element['ldcrouteid'];
            break;
          case 'Thursday':
            this.myForm.controls['thursdayLimit'].setValue(element['ldclimit']);
            this.updateLdcOverAll.thursdayCapacityID = element['ldcrouteid'];
            break;
          case 'Friday':
            this.myForm.controls['fridayLimit'].setValue(element['ldclimit']);
            this.updateLdcOverAll.fridayCapacityID = element['ldcrouteid'];
            break;
          case 'Saturday':
            this.myForm.controls['saturdayLimit'].setValue(element['ldclimit']);
            this.updateLdcOverAll.saturdayCapacityID = element['ldcrouteid'];
            break;
          default:
            break;
        }
      });
    }
    if (!_.isEmpty(ldcDailyRouteObject['specificDates'])) {
      const control = <FormArray>this.myForm.controls['specificDates'];
      control.controls = [];
      ldcDailyRouteObject['specificDates'].forEach(element => {
        control.push(this.formBuilder.group({
          localDistributionCenterCapacityDate: element.specificDate,
          localDistributionCenterRouteCapacityCount: element.specificCount,
          localDistributionCenterDateCapacityID: element.specificID
        }));
      });
    }
    this.spinnerFormGroup.emit(this.myForm);
  }

  checkDuplicate(date, formArray) {
    const newDate = date;
    this.showError = false;
    this.showEmptyDateError = false;
    if (formArray.controls.length > 1) {
      formArray.controls.forEach(element => {
        if (element.value.localDistributionCenterCapacityDate !== '') {
          if (!_.isEmpty(element.value.localDistributionCenterCapacityDate) &&
            element.value.localDistributionCenterCapacityDate.indexOf(newDate.localDistributionCenterCapacityDate) !== -1) {
            this.duplicateArray.push(newDate.localDistributionCenterCapacityDate);
            if (this.duplicateArray.length > 1) {
              this.showError = true;
            }
          }
        }
      });
      this.duplicateArray = [];
    } else {
      this.showError = false;
      this.showEmptyDateError = false;
    }
  }

  checkEmptyDates(formArray) {
    if (formArray.controls.length > 0) {
      if (formArray.controls[formArray.controls.length - 1].value.localDistributionCenterCapacityDate === '') {
        this.showEmptyDateError = true;
      } else {
        this.showEmptyDateError = false;
        this.showError = false;
        this.showErrorFlag = false;
      }
    }
  }
  initDate() {
    return this.formBuilder.group({
      localDistributionCenterCapacityDate: [''],
      localDistributionCenterRouteCapacityCount: ['']
    });

  }


  addNewDate() {
    const control = <FormArray>(this.myForm.controls['specificDates']);
    const addCtrl = this.initDate();
    this.checkEmptyDates(control);
    addCtrl.valueChanges.subscribe(x => {
      this.customGroupValidation(control);
    });
    if (this.showEmptyDateError === false) {
      control.push(addCtrl);
    }
    this.specificDateAddOrRemove.emit(true);
  }

  removeDate(i: number) {

    const control = <FormArray>this.myForm.controls['specificDates'];
    control.removeAt(i);
    this.checkEmptyDates(control);
    const newControl = <FormArray>this.myForm.controls['specificDates'];
    if (control.controls.length > 0) {
      this.customGroupValidation(control);
    } else if (control.controls.length === 0) {
      this.showError = false;
      this.showEmptyDateError = false;
      this.showErrorFlag = false;
    }
    this.specificDateAddOrRemove.emit(true);
  }


  customGroupValidation(formArray) {
    const uniqueNames = [];
    if (formArray.controls.length > 1) {
      // this.showError = false;
      for (let i = 0; i < formArray.controls.length; i++) {
        if (uniqueNames.indexOf(formArray.controls[i].value.localDistributionCenterCapacityDate) === -1) {
          this.showError = false;
          this.showEmptyDateError = false;
          uniqueNames.push(formArray.controls[i].value.localDistributionCenterCapacityDate);
        } else {
          this.showError = true;
        }
      }
    }
  }

  getLDCDailyRoutesCapacity(locationID: number): void {

    this.updateLdcOverAll.dailyRouteObservable = this.ldcService.getDailyRouteCapacity(locationID).subscribe((dailyRoutes: any) => {
      if (!_.isEmpty(dailyRoutes)) {
        if (dailyRoutes['localDistributionCenterCapacityID']) {
          this.updateLdcOverAll.capacityID = dailyRoutes['localDistributionCenterCapacityID'];
        }
        const dailyRouteArray = dailyRoutes['localDistributionCenterDayOfWeekCapacities'];
        const speicificArray = dailyRoutes['localDistributionCenterDateCapacities'];
        const dailyLimitData = [];
        const specificDatesData = [];
        let dailyObj = {};
        dailyRouteArray.forEach(element => {
          dailyObj = {
            ldcday: element['weekDayCode'],
            ldclimit: element['localDistributionCenterRouteCapacityCount'],
            ldcrouteid: element['localDistributionCenterDayOfWeekCapacityID']
          };
          dailyLimitData.push(dailyObj);
        });
        this.dailyRouteCapacity = dailyLimitData;
        let specificObj = {};
        speicificArray.forEach(element => {
          specificObj = {
            specificCount: element['localDistributionCenterRouteCapacityCount'],
            specificDate: element['localDistributionCenterCapacityDate'],
            specificID: element['localDistributionCenterDateCapacityID']
          };
          specificDatesData.push(specificObj);
        });

        this.specificDates = specificDatesData;
        if (this.updateLdcOverAll.capacityID) {
          this.ldcData = {
            'locationId': locationID,
            'capacityID': this.updateLdcOverAll.capacityID,
            'dailyRoute': this.dailyRouteCapacity,
            'specificDates': this.specificDates
          };
          this.assignDailyRouteCapacity(this.ldcData);
        } else {
          this.ldcData = {
            'locationId': locationID,
            'dailyRoute': this.dailyRouteCapacity,
            'specificDates': this.specificDates
          };
          this.assignDailyRouteCapacity(this.ldcData);
        }

      }
    }, (error: Error) => {
      this.ldcData = {
        'locationId': locationID,
        'capacityID': '',
        'dailyRoute': [],
        'specificDates': []
      };
      this.assignDailyRouteCapacity(this.ldcData);
    });

  }

  updateLDC(value) {
    this.msgs = [];
    this.updateLdcOverAll.dailyLimitArray = [];
    this.updateLdcOverAll.dailyLimitArray.push({
      'weekDayCode': 'Sunday',
      'localDistributionCenterRouteCapacityCount': value.sundayLimit ? value.sundayLimit : 0,
      'localDistributionCenterDayOfWeekCapacityID': this.updateLdcOverAll.sundayCapacityID
    },
      {
        'weekDayCode': 'Monday',
        'localDistributionCenterRouteCapacityCount': value.mondayLimit ? value.mondayLimit : 0,
        'localDistributionCenterDayOfWeekCapacityID': this.updateLdcOverAll.mondayCapacityID
      },
      {
        'weekDayCode': 'Tuesday',
        'localDistributionCenterRouteCapacityCount': value.tuesdayLimit ? value.tuesdayLimit : 0,
        'localDistributionCenterDayOfWeekCapacityID': this.updateLdcOverAll.tuesdayCapacityID
      },
      {
        'weekDayCode': 'Wednesday',
        'localDistributionCenterRouteCapacityCount': value.wednesdayLimit ? value.wednesdayLimit : 0,
        'localDistributionCenterDayOfWeekCapacityID': this.updateLdcOverAll.wednesdayCapacityID
      },
      {
        'weekDayCode': 'Thursday',
        'localDistributionCenterRouteCapacityCount': value.thursdayLimit ? value.thursdayLimit : 0,
        'localDistributionCenterDayOfWeekCapacityID': this.updateLdcOverAll.thursdayCapacityID
      },
      {
        'weekDayCode': 'Friday',
        'localDistributionCenterRouteCapacityCount': value.fridayLimit ? value.fridayLimit : 0,
        'localDistributionCenterDayOfWeekCapacityID': this.updateLdcOverAll.fridayCapacityID
      },
      {
        'weekDayCode': 'Saturday',
        'localDistributionCenterRouteCapacityCount': value.saturdayLimit ? value.saturdayLimit : 0,
        'localDistributionCenterDayOfWeekCapacityID': this.updateLdcOverAll.saturdayCapacityID
      });
    if (this.updateLdcOverAll.capacityId) {
      const updateData = {
        'localDistributionCenterCapacityID': this.updateLdcOverAll.capacityId,
        'dailyLimits': this.updateLdcOverAll.dailyLimitArray,
        'specificDates': value.specificDates
      };
      this.updateLdcService.updateLDC(updateData, this.updateLdcOverAll.capacityId).subscribe((ldcUpdate: any) => {
        this.updatedLDC = true;
        this.msgs.push(
          {
            severity: 'success',
            summary: 'Capacity Updated',
            detail: 'Capacity for ' + this.updateLdcOverAll.ldcName + ' has been successfully updated'
          });
        this.initFormGroup();
        this.getLDCDailyRoutesCapacity(this.updateLdcOverAll.ldcID);

      });
    } else {
      this.updateLdcOverAll.dailyLimitArray.forEach(element => {
        delete element['localDistributionCenterDayOfWeekCapacityID'];
      });
      const addData = {
        'localDistributionCenterLocationID': this.updateLdcOverAll.ldcID,
        'dailyLimits': this.updateLdcOverAll.dailyLimitArray,
        'specificDates': value.specificDates
      };
      this.updateLdcService.addLDC(addData).subscribe((overRide: any) => {
        this.updatedLDC = true;
        this.msgs.push(
          {
            severity: 'success',
            summary: 'Capacity Updated', detail: 'Capacity for ' + this.updateLdcOverAll.ldcName + ' has been successfully updated'
          });
        this.initFormGroup();
        this.getLDCDailyRoutesCapacity(this.updateLdcOverAll.ldcID);
      });
    }
  }

  onSubmitDate(formVal) {
    console.log(formVal);
  }

  showEmptyDateErrorCheck(showEmptyDateErrorFlag) {
    this.showErrorFlag = showEmptyDateErrorFlag;
  }
}
