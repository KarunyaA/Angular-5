import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
// Custom Modules
import { LdcRoutingModule } from './ldc-routing.module';
// Custom Components
import { ViewLdcComponent } from './view-ldc/view-ldc.component';
import { BreadcrumbComponent } from './breadcrumb/breadcrumb.component';
import { UpdateLdcComponent } from './update-ldc/update-ldc.component';

// PrimeNG modules
import { TabMenuModule } from 'primeng/tabmenu';
import { TabViewModule } from 'primeng/tabview';
import { BreadcrumbModule } from 'primeng/breadcrumb';
import { MenuModule } from 'primeng/menu';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { SpinnerModule } from 'primeng/spinner';
import { ButtonModule } from 'primeng/button';
import { TableModule } from 'primeng/table';
import { CalendarModule } from 'primeng/calendar';
import { GrowlModule } from 'primeng/growl';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ScrollPanelModule } from 'primeng/scrollpanel';

// Custom Services
import { LocalDistributionService } from './view-ldc/service/local-distribution.service';
import { SpecificDateComponent } from './update-ldc/specific-date/specific-date.component';
import { UpdateLdcService } from './update-ldc/service/update-ldc.service';
import { FinalMileCapacityComponent } from './final-mile-capacity/final-mile-capacity.component';
import { LdcSharedService } from './service/ldc-shared.service';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    LdcRoutingModule,
    TabMenuModule,
    TabViewModule,
    BreadcrumbModule,
    AutoCompleteModule,
    SpinnerModule,
    ButtonModule,
    TableModule,
    CalendarModule,
    GrowlModule,
    ConfirmDialogModule,
    ScrollPanelModule
  ],
  declarations: [ViewLdcComponent, BreadcrumbComponent,
     UpdateLdcComponent, SpecificDateComponent, FinalMileCapacityComponent],
  providers: [LocalDistributionService, UpdateLdcService, LdcSharedService],
  exports: [BreadcrumbComponent],
  entryComponents: [FinalMileCapacityComponent]
})
export class LdcModule { }
