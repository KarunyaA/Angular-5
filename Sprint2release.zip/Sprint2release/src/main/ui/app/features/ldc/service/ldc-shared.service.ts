import { Output, EventEmitter, Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Injectable()
export class LdcSharedService {

  private sharingData: BehaviorSubject<string[]>;
  constructor() {
    this.sharingData = <BehaviorSubject<string[]>>new BehaviorSubject([]);
   }

  saveUpdatedData(data): void {
    this.sharingData.next(data);
  }

  getUpdatedData() {
      return this.sharingData;
  }

}
