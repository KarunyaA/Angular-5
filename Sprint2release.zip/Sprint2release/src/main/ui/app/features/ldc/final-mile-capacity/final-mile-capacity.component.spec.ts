import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FinalMileCapacityComponent } from './final-mile-capacity.component';

describe('FinalMileCapacityComponent', () => {
  let component: FinalMileCapacityComponent;
  let fixture: ComponentFixture<FinalMileCapacityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FinalMileCapacityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FinalMileCapacityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
