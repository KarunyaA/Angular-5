import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewLdcComponent } from './view-ldc.component';

describe('ViewLdcComponent', () => {
  let component: ViewLdcComponent;
  let fixture: ComponentFixture<ViewLdcComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewLdcComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewLdcComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
