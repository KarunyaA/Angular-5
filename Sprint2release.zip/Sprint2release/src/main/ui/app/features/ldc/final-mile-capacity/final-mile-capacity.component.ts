import { Component, OnInit, OnDestroy, ViewChild, ElementRef, Output, EventEmitter } from '@angular/core';
import { AbstractControl, FormGroup, FormArray, FormBuilder, Validators, FormControl, Form } from '@angular/forms';
import { MenuItem } from 'primeng/api';

import { LdcSharedService } from './../service/ldc-shared.service';

import { FinalMileCapacityService } from './service/final-mile-capacity.service';
import { FinalMileCapacityModel } from './model/final-mile-capacity.model';
import { Index } from '../ldcenum/index.enum';
import { ConfirmationService } from 'primeng/api';
import { Message } from 'primeng/components/common/api';
import { GrowlModule } from 'primeng/growl';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import * as _ from 'lodash';

@Component({
  selector: 'app-final-mile-capacity',
  templateUrl: './final-mile-capacity.component.html',
  styleUrls: ['./final-mile-capacity.component.scss'],
  providers: [ConfirmationService, FinalMileCapacityService, LdcSharedService]
})

export class FinalMileCapacityComponent implements OnInit, OnDestroy {

  capacityID: number;
  eventName: string;
  // ldcDailyRouteObject: any;
  ldcData: Array<Object>;
  filteredLocationCenter: any;
  ldcIndex = Index;
  ldcLocationID: Object;
  ldcViewData: Object;
  locationName: any;
  msgs: Message[] = [];
  myForm: FormGroup;
  myValue = new FormControl([]);
  selectedIndex = 0;
  specificDates: Array<Object>;
  userId: any;
  utils: any;
  finalMileCapacityModel: FinalMileCapacityModel;
  shareUpdatedData = false;

  constructor(private formBuilder: FormBuilder, private finalMileCapacityService: FinalMileCapacityService,
    private ldcSharedService: LdcSharedService,
    private confirmationService: ConfirmationService) {

  }
  @Output() ldcTypeaheadFormGroup: EventEmitter<any> = new EventEmitter();
  @Output() spinnerFormGroupMethodFromFinal: EventEmitter<any> = new EventEmitter();
  @Output() specificDateAddOrRemoveFromFinal: EventEmitter<any> = new EventEmitter();
  @ViewChild('updateLdcRef') updateLdcRef: any;

  ngOnInit() {
    this.finalMileCapacityModel = new FinalMileCapacityModel();
    this.ldcForm();
    this.getALLocationInfo();
    this.finalMileCapacityModel.userRole = 'LDCManager';
    this.myForm['valueChanges'].
      subscribe(form => {
        this.ldcTypeaheadFormGroup.emit(this.myForm);
      });
    this.finalMileCapacityModel.specificDateAddOrRemove = false;
    this.specificDateAddOrRemoveFromFinal.emit(this.finalMileCapacityModel.specificDateAddOrRemove);
    if (this.updateLdcRef) {
      this.updateLdcRef.ngOnInit();
    }
  }

  ngOnDestroy() {
    if (this.finalMileCapacityModel.dailyRouteObservable) {
      this.finalMileCapacityModel.dailyRouteObservable.unsubscribe();
    }
  }

  ldcForm() {
    this.myForm = this.formBuilder.group({
      ldcName: [0, Validators.required],
      ldcDate: [0, Validators.required],
      ldcLimit: [0, Validators.required]
    });
  }

  getALLocationInfo(): void {
    this.ldcData = [];
    this.finalMileCapacityModel.dailyRouteObservable = this.finalMileCapacityService.getLocalCenters().subscribe((locations: any) => {
      if (!_.isEmpty(locations)) {
        const locationArray = locations['hits']['hits'];
        if (!_.isEmpty(locationArray)) {
          let locationObj;
          locationArray.forEach(element => {
            locationObj = {
              locationname: element['_source']['LocationName'],
              locationID: element['_source']['LocationID'],
              locationCode: element['_source']['LocationCode']
            };
            this.ldcData.push(locationObj);
          });
          this.filteredLocationCenter = this.ldcData.sort();
          const filterIndex = this.ldcIndex.indexZero;
          this.myForm.controls['ldcName'].patchValue({
            name: ` ${this.
              filteredLocationCenter[filterIndex]['locationname']} ${this.filteredLocationCenter[filterIndex]['locationCode']}`
          });
          this.getLDCDailyRoutesCapacity(this.filteredLocationCenter[filterIndex]['locationID']);
        }
        this.locationName = this.filteredLocationCenter[this.ldcIndex.indexZero]['locationname'];
      }
    });
    this.ldcTypeaheadFormGroup.emit(this.myForm);
    this.spinnerFormGroupMethodFromFinal.emit(this.finalMileCapacityModel.spinnerFormGroup);
  }

  getLDCDailyRoutesCapacity(locationID: number): void {
    this.finalMileCapacityModel.dailyRouteObservable =
      this.finalMileCapacityService.getDailyRouteCapacity(locationID).subscribe((dailyRoutes: any) => {
        this.ldcViewData = {};
        if (!_.isEmpty(dailyRoutes)) {
          if (dailyRoutes['localDistributionCenterCapacityID']) {
            this.capacityID = dailyRoutes['localDistributionCenterCapacityID'];
          }
          const dailyRouteArray = dailyRoutes['localDistributionCenterDayOfWeekCapacities'];
          const speicificArray = dailyRoutes['localDistributionCenterDateCapacities'];
          const dailyLimitData = [];
          const specificDatesData = [];
          let dailyObj = {};
          dailyRouteArray.forEach(element => {
            dailyObj = {
              ldcday: element['weekDayCode'],
              ldclimit: element['localDistributionCenterRouteCapacityCount'],
              ldcrouteid: element['localDistributionCenterDayOfWeekCapacityID']
            };
            dailyLimitData.push(dailyObj);
          });
          this.finalMileCapacityModel.dailyRouteCapacity = dailyLimitData;
          let specificObj = {};
          speicificArray.forEach(element => {
            specificObj = {
              specificCount: element['localDistributionCenterRouteCapacityCount'],
              specificDate: element['localDistributionCenterCapacityDate'],
              specificID: element['localDistributionCenterDateCapacityID']
            };
            specificDatesData.push(specificObj);
          });

          this.specificDates = specificDatesData;
          if (this.capacityID) {
            this.ldcViewData = {
              'locationId': locationID,
              'loc': this.locationName,
              'capacityID': this.capacityID,
              'dailyRoute': this.finalMileCapacityModel.dailyRouteCapacity,
              'specificDates': this.specificDates
            };
          } else {
            this.ldcViewData = {
              'locationId': locationID,
              'loc': this.locationName,
              'dailyRoute': this.finalMileCapacityModel.dailyRouteCapacity,
              'specificDates': this.specificDates
            };
          }
        }
      }, (error: Error) => {
        this.ldcViewData = {
          'locationId': locationID,
          'loc': this.locationName,
          'capacityID': '',
          'dailyRoute': [],
          'specificDates': []
        };
      });

  }

  getUserSearch() {
    this.finalMileCapacityService.getUserInfo().subscribe((userInfo: any) => {
      this.userId = userInfo.userId;
    });
    this.finalMileCapacityService.getUserSearch().subscribe((userSavedSearches: any) => {
      if (userSavedSearches) {
        this.finalMileCapacityModel.userSavedSearchID = userSavedSearches['userSavedSearchID'];
      }
      const userSearchCriteria = { 'locationDistributionCenter': this.eventName };
      if (this.finalMileCapacityModel.userSavedSearchID) {
        this.finalMileCapacityModel.userSavedData = {
          userSavedSearchID: this.finalMileCapacityModel.userSavedSearchID,
          personID: this.userId,
          applicationSearchFunctionCode: 'CAP001',
          userSearchName: 'LdcCapacitySearch',
          userSearchDefaultIndicator: 'N',
          userSearchCriteriaContent: JSON.stringify(userSearchCriteria)
        };
      } else {
        this.finalMileCapacityModel.userSavedData = {
          personID: this.userId,
          applicationSearchFunctionCode: 'CAP001',
          userSearchName: 'LdcCapacitySearch',
          userSearchDefaultIndicator: 'N',
          userSearchCriteriaContent: JSON.stringify(userSearchCriteria)
        };
      }

      this.finalMileCapacityService.saveUserSearch(this.finalMileCapacityModel.userSavedData).subscribe((saveUser: any) => {
        // TODO
      });
    });

  }
  onLDCSelect(localID: Object): void {
    const locID = localID['id'];
    this.eventName = localID['name'];
    this.locationName = localID['name'];
    this.ldcLocationID = {
      'locID': locID,
      'loc': this.eventName
    };
    if (!_.isEmpty(localID['code']) && localID['code'] !== '') {
      this.myForm.controls['ldcName'].patchValue({
        name: `${localID['name']} (${localID['code']})`
      });
    }
    this.getLDCDailyRoutesCapacity(locID);
  }
  filterLocationCenter(localCenter: any): void {
    const queryParam = this.finalMileCapacityModel.getLocationID;
    const arrayList = [];
    queryParam['query']['bool']['must'][0]['query_string']['query'] = localCenter.query + '*';
    this.finalMileCapacityService.getLocationDTO(queryParam).subscribe(areas => {
      if (areas && areas['hits'] && areas['hits']['hits']) {
        const locations = areas['hits']['hits'];
        locations.forEach(locationObj => {
          if (locationObj) {
            arrayList.push({
              id: locationObj['_id'],
              address: locationObj['_source']['Address']['AddressLine1'],
              name: locationObj['_source']['LocationName'],
              code: locationObj['_source']['LocationCode'],
            });
          }
        });

        this.filteredLocationCenter = arrayList;
      }

    });

    //  this.filteredLocationCenter = this.filterLocations(this.ldcData);
  }
  spinnerFormGroupMethod(spinnerFormGroup: FormGroup): void {
    this.finalMileCapacityModel.spinnerFormGroup = spinnerFormGroup;
    this.spinnerFormGroupMethodFromFinal.emit(this.finalMileCapacityModel.spinnerFormGroup);
  }
  specificDateAddOrRemove(specificDateAddOrRemove: boolean) {
    this.finalMileCapacityModel.specificDateAddOrRemove = specificDateAddOrRemove;
    this.specificDateAddOrRemoveFromFinal.emit(this.finalMileCapacityModel.specificDateAddOrRemove);
  }

  updateLDC(formValue) {
    this.shareUpdatedData = true;
    this.ldcSharedService.saveUpdatedData(this.shareUpdatedData);
  }

}
