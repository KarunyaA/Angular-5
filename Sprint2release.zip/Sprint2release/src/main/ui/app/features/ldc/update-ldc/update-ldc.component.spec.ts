import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateLdcComponent } from './update-ldc.component';

describe('UpdateLdcComponent', () => {
  let component: UpdateLdcComponent;
  let fixture: ComponentFixture<UpdateLdcComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateLdcComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateLdcComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
