export enum Index {
    indexZero = 0,
    indexOne = 1,
    indexTwo = 2,
    indexThree = 3,
    indexFive = 5
}
