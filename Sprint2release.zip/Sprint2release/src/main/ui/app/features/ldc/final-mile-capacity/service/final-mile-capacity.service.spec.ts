import { TestBed, inject } from '@angular/core/testing';

import { FinalMileCapacityService } from './final-mile-capacity.service';

describe('FinalMileCapacityService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [FinalMileCapacityService]
    });
  });

  it('should be created', inject([FinalMileCapacityService], (service: FinalMileCapacityService) => {
    expect(service).toBeTruthy();
  }));
});
