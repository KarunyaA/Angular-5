import { Injectable } from '@angular/core';

@Injectable()
export class LocalStorageService {
  private localStore = localStorage;
  private memoryStore = {};
  private store;
  constructor() { }

  getItem(parentName, key, persist?): void {
    this.setStorage(persist);
    return this.store[parentName + '_' + key];
  }

  setItem(parentName, key, value, persist?): void {
    this.setStorage(persist);
    this.store[parentName + '_' + key] = value;
  }

  clearItems(persist?): void {
    if (persist) {
      this.localStore.clear();
    } else {
      this.memoryStore = {};
    }
  }

  clearAllItems(): void {
    this.localStore.clear();
    this.memoryStore = {};
  }

  clearItem(parentName, key, persist?): void {
    this.setStorage(persist);
    delete this.store[parentName + '_' + key];
  }

  private setStorage(persist) {
    if (persist) {
      this.store = this.localStore;
    } else {
      this.store = this.memoryStore;
    }
  }

}
