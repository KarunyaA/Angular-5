import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { CoreModule } from './core/core.module';

import { SpinnerComponent, SpinnerService } from './shared/spinner/index';
import { AppSharedDataService } from './shared/jbh-app-services/app-shared-data.service';
import { LoggerService } from './shared/jbh-app-services/logger.service';
import { ShortcutkeyService } from './shared/jbh-app-services/shortcutkey.service';
import { MouseEventService } from './shared/jbh-app-services/mouseevent.service';
import { CanDeactivateGuardService } from './shared/jbh-app-services/can-deactivate-guard.service';
import { LocalStorageService } from './shared/jbh-app-services/local-storage.service';
import { MessageService } from 'primeng/components/common/messageservice';
import { GrowlModule } from 'primeng/growl';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

@NgModule({
  declarations: [
    AppComponent,
    SpinnerComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    CoreModule,
    AppRoutingModule,
    GrowlModule
  ],
  providers: [
    SpinnerService,
    AppSharedDataService,
    LocalStorageService,
    LoggerService,
    MessageService,
    ShortcutkeyService,
    MouseEventService
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
