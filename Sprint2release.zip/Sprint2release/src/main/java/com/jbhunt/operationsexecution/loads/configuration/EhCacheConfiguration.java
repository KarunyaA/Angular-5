
package com.jbhunt.operationsexecution.loads.configuration;

import javax.annotation.PreDestroy;

import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.ehcache.EhCacheCacheManager;
import org.springframework.cache.ehcache.EhCacheManagerUtils;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.ClassPathResource;

import lombok.extern.slf4j.Slf4j;

@Configuration
@Slf4j
@EnableCaching
public class EhCacheConfiguration {

	EhCacheCacheManager ehCacheCacheManager;    
   
    @Bean
    @Primary
    public CacheManager operationsExecutionCacheManager() {
        ClassPathResource ehCacheConfigFile = new ClassPathResource("ehcache.xml");
        ehCacheCacheManager = new EhCacheCacheManager(EhCacheManagerUtils.buildCacheManager(ehCacheConfigFile));
        return ehCacheCacheManager;
    }
    
    @PreDestroy
    public void destroy() {
        log.debug("Shutting down operationsExecutionCacheManager.");
        this.ehCacheCacheManager.getCacheManager().shutdown();

    }


}