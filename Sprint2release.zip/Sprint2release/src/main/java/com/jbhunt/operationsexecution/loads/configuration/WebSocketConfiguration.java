package com.jbhunt.operationsexecution.loads.configuration;

public class WebSocketConfiguration {

}
