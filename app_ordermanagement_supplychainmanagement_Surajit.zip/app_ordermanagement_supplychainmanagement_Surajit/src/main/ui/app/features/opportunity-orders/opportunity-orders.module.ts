import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OpportunityOrdersRoutingModule } from './opportunity-orders-routing.module';
import { OpportunityOrdersComponent } from './opportunity-orders.component';

@NgModule({
  imports: [
    CommonModule,
    OpportunityOrdersRoutingModule
  ],
  declarations: [OpportunityOrdersComponent]
})
export class OpportunityOrdersModule { }
