import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { OpportunityOrdersComponent } from './opportunity-orders.component';

const routes: Routes = [
  {
    path: '',
    component: OpportunityOrdersComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: []
})
export class OpportunityOrdersRoutingModule { }
