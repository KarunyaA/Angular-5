import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-opportunity-orders',
  templateUrl: './opportunity-orders.component.html',
  styleUrls: ['./opportunity-orders.component.scss']
})
export class OpportunityOrdersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
