import { Injectable, Component, EventEmitter, Input, Output, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { JBHGlobals } from '../../../app.service';

@Component({
  selector: 'app-search-result-grid',
  templateUrl: './search-result-grid.component.html',
  styleUrls: ['./search-result-grid.component.scss']
})

@Injectable()
export class SearchResultGridComponent {

  // Rows for Grid to populate results
  public rows = [];
  // Columns for Grid
  public columns = [];
  // Cache those results to display page wise record thru navigation
  public results = [];
  // Initial count to set rows for grid.
  public count = 0;
  // Page Offset
  public offset = 0;
  // Number Of Records in a Page for Grid - Minimum 25 records per page
  public limit = 25;
  // List of Column Headers to display in Edit Column Popup
  public editColumnGridHeaders = [];
  // User Info JSON from parent component
  public userInfoJson: Object = {};
  // Edit Column Update Status & Message
  public editColumnUpdateStatus: Object = {};

  // Grid - Drop Down Menu Contents
  public gridDropDownMenu = [{
    name: 'Manage Columns',
    id: 'manageColumns'
  },
  {
    name: 'Export to Excel',
    id: 'exportToExcel'
  }
  ];

  // To View First Icon of this component
  @ViewChild('SearchResultFirstNavigation') public searchResultFirstNavigation;

  // To View Edit Column modal Child
  @ViewChild('editColumnModel') public editColumnModel: ModalDirective;

  // To Parent Component, Emits when we select any Item in DropDown
  @Output() gridDropMenuSelected = new EventEmitter<string>();
  // To Parent Component, Emits when we click on Additional Filter
  @Output() gridAdditionalFilterClicked = new EventEmitter<any>();

  @Output() getSearchGridColumns = new EventEmitter<any>();

  constructor(
    public jbhGlobals: JBHGlobals,
    public router: Router
  ) { }

  /************    Setter Function: Data, Model, Property will set from parent Component - Starts    ************/

  /************    gridResults function: Data will be mapped from Parent Component    ************/

  @Input()
  set parentUserInfoJson(parentUserInfoJson: any) {
    this.userInfoJson = Object.assign({}, parentUserInfoJson);
  };

  @Input()
  set gridResults(result: any) {
    this.results = [];
    if (result && result.RestResponse) {
      this.populateSearchResultGrid(result);
    }
  };

  @Input()
  set gridColumns(result: any) {
    this.columns = [];
    if (result && result.gridColumns) {
      this.setGridColumns(result.gridColumns);
      this.editColumnGridHeaders = result.gridColumns;
    }
  };

  /************    Setter Function: Data, Model, Property will set from parent Component - Ends    ************/

  /************    populateSearchResultGrid function: Used to Populate Search Result Grid    ************/

  public populateSearchResultGrid(data): void {
    if (data.RestResponse.result !== undefined) {
      this.results = data.RestResponse.result;
      this.page(this.offset, this.limit);
    }
  };

  /************    page function: Defined to Perform Nagigation related operations    ************/

  public page(offset, limit): void {
    this.count = this.results.length;
    const start = offset * limit;
    const end = start + limit;
    const rows = [...this.rows];
    for (let i = start; i < end; i++) {
      const result = this.results[i];
      if (result !== undefined) {
        rows[i] = this.results[i];
      }
    }
    this.rows = rows;
  };

  /************    onPage function: Triggers when Naviation happened in Search Results Grid    ************/

  public onPage(event): void {
    this.page(event.offset, event.limit);
  };

  /************    Parent Component: Event Emitter Function Declaration - Starts    ************/

  /************    menuClickEvent function: Trigger when we select any Item in DropDown    ************/

  public menuClickEvent(selectedGridMenuId): void {
    switch (selectedGridMenuId) {
      case 'manageColumns':
        this.editColumnModel.show();
        break;
      case 'exportToExcel':
        // this.router.navigateByUrl('/order-search/exporttoexcel');
        break;
      default:
        this.gridDropMenuSelected.emit(selectedGridMenuId);
        break;
    }
  };

  /************    menuClickEvent function: Trigger when we click over Additional Filter Icon    ************/

  public addidtionalSearch(): void {
    this.gridAdditionalFilterClicked.emit();
  };

  /************    Parent Component: Event Emitter Function Declaration - Ends    ************/

  /************    Edit Column Child Component: Function Declaration Starts    ************/

  /************    setGridColumns function: Used to set Grid columns for JBH data Table    ************/

  public setGridColumns(columnsArray: any): void {
    const columns = [];
    for (let columnIdx = 0; columnIdx < columnsArray.length; columnIdx++) {
      const columnJSON = columnsArray[columnIdx];
      if (columnJSON['isVisible']) {
        columns.push(columnJSON);
      }
    }
    this.columns = columns;
  }

  /************    hideEditColumnModel function: Will Hide Edit Column modal    ************/

  public hideEditColumnModel(): void {
    this.editColumnModel.hide();
  }

  /************    updateColumModel function: Will update Edit Column modal
                          - Column Hide and show (&) Column ordering    ************/

  public updateColumModel(inputColumnParams: any): void {
    const columnInfoJson = Object.assign(Object.assign({}, this.userInfoJson), {
      'gridColumns': JSON.stringify(inputColumnParams)
    });
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.ordersearch.updateGridColumns, columnInfoJson, false)
      .subscribe(data => {
        if (data !== undefined) {
          this.editColumnUpdateStatus = data['RestResponse'];
          if (this.editColumnUpdateStatus['statusCode'].toUpperCase() === 'P') {
            this.getSearchGridColumns.emit(Object.assign({}, this.userInfoJson));
            this.hideEditColumnModel();
          }
        }
      });
  }

  /************    Edit Column Child Component: Function Declaration Ends    ************/
}
