import { Component, OnInit, Input } from '@angular/core';
import { FormGroup } from '@angular/forms';

@Component({
    selector: 'app-add-more-referrence',
    templateUrl: './add-more-referrence.component.html',
    styleUrls: ['./add-more-referrence.component.scss']
})

export class AddMoreReferrenceComponent implements OnInit {

    public addMoreRefIndex: number;

    @Input() addMoreRefForm: FormGroup;
    @Input() refNodataList;

    @Input()
    set addMoreIdx(indexArg) {
        this.addMoreRefIndex = indexArg;
    }

    constructor() {}

    ngOnInit() {}


    public typeaheadNoResultsCallBack(isNoResultExists: boolean, typeAheadField: string): void {

    }


    // <!-- Added for ng2-select method implementation Pras-918 -->

    public onSelectPrefix(value: string): void {

    }


    public onRemovePrefix(value: any): void {
        // console.log(value);
    }


    public onTypePrefix(event): void {
        // console.log(event);
    }

    /************    typeaheadOnSelect function: Will trigger once typeahead got selected   ************/

    public typeaheadOnSelect(event: any, typeAheadField: string): void {

    };

}
