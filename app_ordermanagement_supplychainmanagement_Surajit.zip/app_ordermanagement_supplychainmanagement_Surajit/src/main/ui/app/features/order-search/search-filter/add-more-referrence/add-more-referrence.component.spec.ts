import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddMoreReferrenceComponent } from './add-more-referrence.component';

describe('AddMoreReferrenceComponent', () => {
  let component: AddMoreReferrenceComponent;
  let fixture: ComponentFixture<AddMoreReferrenceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddMoreReferrenceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddMoreReferrenceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
