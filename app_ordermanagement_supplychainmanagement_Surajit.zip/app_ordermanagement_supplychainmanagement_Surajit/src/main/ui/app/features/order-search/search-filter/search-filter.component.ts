import { Component, OnInit, Input, Output, EventEmitter, ViewChild, Injectable } from '@angular/core';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { ModalDirective } from 'ngx-bootstrap/modal';
import * as _ from 'lodash';
import { IMyOptions } from 'mydatepicker';
import { JBHGlobals } from '../../../app.service';
import { SavedSearchComponent } from './saved-search/saved-search.component';

@Component({
    selector: 'app-search-filter',
    templateUrl: './search-filter.component.html',
    styleUrls: ['./search-filter.component.scss']
})

@Injectable()
export class SearchFilterComponent implements OnInit {

    // To View Saved Search Component modal Child
    @ViewChild(SavedSearchComponent) public savedSearchComponent: SavedSearchComponent;

    // To View First Icon of this component
    @ViewChild('SearchFilterFirstNavigation') public searchFilterFirstNavigation;

    // To View Add To Favorite modal Child
    @ViewChild('addFavoriteModal') public addFavoriteModal: ModalDirective;

    // To View Manage Favorite modal Child
    @ViewChild('savedsearchmodal') public manageFavoriteModal: ModalDirective;

    /************    parentUserInfoJson function: UserInfo JSON object    ************/

    @Input()
    set parentUserInfoJson(parentUserInfoJson: any) {
        this.userInfoJson = Object.assign({}, parentUserInfoJson);
    };

    /************    parentUserInfoJson function: UserInfo JSON object    ************/

    // To Parent Component, Order Search Form
    @Output()
    orderSearchSaveForm: EventEmitter < any > = new EventEmitter < any > ();

    /*    Component Property Declaration Starts    */

    public orderSearchMoreOrLess: boolean; //  Parent container initial width handling Flag
    public orderSearchForm: FormGroup;
    public newSearch = [];
    public userInfoJson: Object = {};
    public selectedFavorite: string;
    public addMoreaddbtn: boolean;
    public addMorermbtn: boolean;
    public addMoreRefaddbtn = true;
    public addMoreRefrmbtn = false;

    public locationAddMore: boolean;
    public orderSearchDrayServiceList = [];
    public appointmentInstructionList = [];
    public locationNameList = [];
    public orderSeachLocationNameList = [];
    public originMarKetAreaList = [];
    public destinationMarKetAreaList = [];

    public tagInputValidator: any = {};
    public validationErrorIcon = 'icon-jbh_circle-info';
    public validationErrorMessage: any = {};
    public validationErrorMessageFlag: any = {};
    public newFavoriteName: string;

    public businessUnitList = [];
    public orderStatusList = [];
    public serviceOfferingList = [];
    public orderSearchFleetCodeList = [];
    public orderTypeList = [];
    public referenceNumberList = [];
    public referenceNumberTypeList = [];
    public internationalServieceList = [];
    public OrderSeatchreasonOrderStatusList = [];
    public orderSearchCreationChannelList = [];
    public serviceLevelList = [];

    public orderSearchTypeList = [];
    public orderSearchLocationTypeList = [];
    public orderSearchAppoinmentList = [];
    public orderSearchReferrenceTypeList = [];
    public orderSearchOrderOwnerList = [];
    public orderSearchMeasureTimeList = [];

    public hardCodedShipmentReqList = [];
    public hardCodedRefNumberTypes = [];
    public hardCodedFavoriteList = [];

    public serviceStatusList = [];
    public trackingStatusList = [];
    public orderSearchCreatorList = [];

    public selectedBusinessUnit: string;
    public accountTypes = [];
    public referrenceTypes = [];

    public favoriteSelectFromPopup: boolean;

    /*    Component Property Declaration Starts    */

    /*    Date Picker Option Declaration Starts    */

    public myDatePickerOptions: IMyOptions = {
        todayBtnTxt: 'Today',
        dateFormat: 'dd-mm-yyyy',
        firstDayOfWeek: 'mo',
        showClearDateBtn: false,
        sunHighlight: true,
        height: '34px',
        width: '160px',
        inline: false,
        disableUntil: {
            year: (new Date().getFullYear()),
            month: (new Date().getMonth() + 1),
            day: (new Date().getDate() - 4)
        },
        disableSince: {
            year: (new Date().getFullYear()),
            month: (new Date().getMonth() + 1),
            day: (new Date().getDate() + 4)
        },
        selectionTxtFontSize: '14px'
    };

    /*    Date Picker Option Declaration Ends    */

    constructor(
        public formBuilder: FormBuilder,
        public jbhGlobals: JBHGlobals) {}

    ngOnInit() {
        this.accountTypes.length = 1;
        this.referrenceTypes.length = 1;
        this.locationAddMore = false;
        this.orderSearchMoreOrLess = true;
        this.addMoreaddbtn = true;
        this.addMorermbtn = false;
        this.addMoreRefaddbtn = true;
        this.addMoreRefrmbtn = false;
        this.favoriteSelectFromPopup = false;

        this.orderSearchTypeList = this.getHardCodedValues('hardCodedAccountTypes');
        this.hardCodedRefNumberTypes = this.getHardCodedValues('hardCodedRefNumberTypes');
        this.orderSearchAppoinmentList = this.getHardCodedValues('hardCodedAppoinmentList');
        this.hardCodedShipmentReqList = this.getHardCodedValues('hardCodedshipmentrequirement');
        this.orderSearchLocationTypeList = this.getHardCodedValues('hardCodedLocationList');
        this.hardCodedFavoriteList = this.getHardCodedValues('hardCodedCustomFavorites');


        this.orderSearchForm = this.formBuilder.group({
            searchOrderNewSearch: [''],
            orderSearchType: [''],
            orderSearchName: [''],
            orderSearchStatus: [''],
            orderSearchLocationType: [''],
            OrderSeachLocationName: [''],
            orderSearchAppoinment: [''],
            orderSearchPickUpDate: [''],
            orderSearchPickUpTime: [''],
            orderSearchDeliveryDate: [''],
            orderSearchDeliveryTime: [''],
            orderSearchCreateDate: [''],
            orderSearchCreateTime: [''],
            OriginMarkettingArea: [''],
            DestinationMarkettingArea: [''],
            orderSearchBusinessUnit: [''],
            orderSearchServiceOffering: [''],
            orderSearchReferrenceType: [''],
            orderSearchReferrenceValue: [''],
            orderSearchFleetCode: [''],
            orderSearchOrderOwner: [''],
            orderSearchOrderCreator: [''],
            orderSearchCreationChannel: [''],
            orderSearchOrderType: [''],
            orderSearchServiceLevel: [''],
            orderSearchServiceStatus: [''],
            orderSearchTrackingStatus: [''],
            orderSearchMeasureTime: [''],
            orderSearchMeasureServiceLevel: [''],
            OrderSeatchreasonOrderStatus: [''],
            orderSearchAppointmentInstruction: [''],
            appointmentInstruction: [''],
            orderSearchInternationalService: [''],
            orderSearchShipmentRequirement: [''],
            orderSearchDrayServices: ['']
        });

        this.validationErrorMessage = {
            'orderSearchStatus': 'Please choose a order search status',
            'OriginMarkettingArea': 'Please choose a origin marketting area',
            'DestinationMarkettingArea': 'Please choose a destination marketting area',
            'orderSearchServiceStatus': 'Please choose a service status',
            'orderSearchOrderType': 'Please choose a order type',
            'orderSearchServiceLevel': 'Please choose a service level',
            'orderSearchTrackingStatus': 'Please choose a tracking status',
            'orderSearchCreationChannel': 'Please choose a creation channel',
            'orderSearchOrderCreator': 'Please choose a order creator',
            'orderSearchDrayServices': 'Please choose a measurement of time',
            'ShipmentRequirement': 'Please choose a shipment requirements',
            'InternationalServices': 'Please choose a order type',
            'OrderSeatchreasonOrderStatus': 'Please choose a reason order status',
            'appointmentInstruction': 'Please choose a valid appointment status',
            'locationName': 'Please choose a valid account name',
            'OrderSeachLocationName': 'Please choose a valid location name',
            'orderSearchBusinessUnit': 'Please choose a valid business unit',
            'orderSearchReferrenceValue': 'Please choose a valid reference number',
            'orderSearchServiceOffering': 'Please choose a valid service offerring',
            'orderSearchFleetCode': 'Please choose a valid Fleet code',
            'orderSearchLocationType': 'Please choose a valid type',
            'orderOwner': 'Please choose a valid order owner',
            'orderSearchMeasureTime': 'Please choose a measurement of time'
        };

        this.validationErrorMessageFlag = {
            'orderSearchDrayServices': false,
            'appointmentInstruction': false,
            'locationName': false,
            'OrderSeachLocationName': false,
            'orderSearchBusinessUnit': false,
            'orderSearchServiceOffering': false,
            'orderSearchReferrenceValue': false,
            'orderSearchStatus': false,
            'OriginMarkettingArea': false,
            'DestinationMarkettingArea': false,
            'orderSearchServiceStatus': false,
            'orderSearchOrderType': false,
            'orderSearchServiceLevel': false,
            'orderSearchTrackingStatus': false,
            'orderSearchCreationChannel': false,
            'orderSearchOrderCreator': false,
            'orderSearchFleetCode': false,
            'orderSearchLocationType': false,
            'orderOwner': false,
            'orderSearchMeasureTime': false
        };

        this.tagInputValidator = {
            'orderSearchStatus': [(control: FormControl) => {
                const me = this;
                return me.checkTagInputValid(control, 'orderSearchStatus', me.validationErrorMessageFlag);
            }],
            'ShipmentRequirement': [(control: FormControl) => {
                const me = this;
                return me.checkTagInputValid(control, 'ShipmentRequirement', me.validationErrorMessageFlag);
            }],
            'InternationalServices': [(control: FormControl) => {
                const me = this;
                return me.checkTagInputValid(control, 'InternationalServices', me.validationErrorMessageFlag);
            }],
            'OriginMarkettingArea': [(control: FormControl) => {
                const me = this;
                return me.checkTagInputValid(control, 'OriginMarkettingArea', me.validationErrorMessageFlag);
            }],
            'DestinationMarkettingArea': [(control: FormControl) => {
                const me = this;
                return me.checkTagInputValid(control, 'DestinationMarkettingArea', me.validationErrorMessageFlag);
            }],
            'orderSearchOrderType': [(control: FormControl) => {
                const me = this;
                return me.checkTagInputValid(control, 'orderSearchOrderType', me.validationErrorMessageFlag);
            }],
            'orderSearchServiceStatus': [(control: FormControl) => {
                const me = this;
                return me.checkTagInputValid(control, 'orderSearchServiceStatus', me.validationErrorMessageFlag);
            }],
            'orderSearchServiceLevel': [(control: FormControl) => {
                const me = this;
                return me.checkTagInputValid(control, 'orderSearchServiceLevel', me.validationErrorMessageFlag);
            }],
            'orderSearchTrackingStatus': [(control: FormControl) => {
                const me = this;
                return me.checkTagInputValid(control, 'orderSearchTrackingStatus', me.validationErrorMessageFlag);
            }],
            'orderSearchCreationChannel': [(control: FormControl) => {
                const me = this;
                return me.checkTagInputValid(control, 'orderSearchCreationChannel', me.validationErrorMessageFlag);
            }],
            'orderSearchOrderCreator': [(control: FormControl) => {
                const me = this;
                return me.checkTagInputValid(control, 'orderSearchOrderCreator', me.validationErrorMessageFlag);
            }],
            'orderSeatchreasonOrderStatus': [(control: FormControl) => {
                const me = this;
                return me.checkTagInputValid(control, 'orderSeatchreasonOrderStatus', me.validationErrorMessageFlag);
            }],
        };

        this.SavedSearchModalHidden();
        this.populateBusinessUnit();
        this.populateReferenceNumber();
        this.populateDrayServices();
        this.populateOrderStatus();
        this.populateOrderCreationChannel();
        this.populateOriginMarketArea();
        this.populateDestinationMarketArea();

        // this.populateOriginDestinationMarArea();

    }

    /************    getHardCodedValues function: Function will return default hardcoded values    ************/

    public getHardCodedValues(jsonProp: string): any {
        let output = [];
        const hardCodedValuesJSON = {
            'hardCodedRefNumberTypes': ['Order Number', 'Load Number', 'Spot Pricing Number', 'Trailer Number'],
            'hardCodedAccountTypes': ['Bill To', 'Solicitor', 'Freight Forwarder', 'Line of Business'],
            'hardCodedshipmentrequirement': ['Cross Border', 'Food Safety Indicator', 'Hazmat', 'High Value',
                'Inbound', 'International', 'Refrigirated', 'Volume Shipments'
            ],
            'hardCodedAppoinmentList': ['Scheduled', 'Not Scheduled'],
            'hardCodedLocationList': ['Bill To', 'Solicitor', 'Freight Forwarder'],
            'hardCodedCustomFavorites': ['Add to Favorites', 'Manage Favorites']
        };
        output = hardCodedValuesJSON[jsonProp] || [];
        return output;
    }

    /************    checkTagInputValid function: Function will help to check tag input is valid or not    ************/

    public checkTagInputValid(control: FormControl, property: any, validationJson: any): any {
        validationJson[property] = false;
        if (control.value !== '') {
            validationJson[property] = true;
        }
        return null;
    }

    /************    SavedSearchModalHidden function: Function will call after favorite popup got closed    ************/

    public SavedSearchModalHidden(): void {
        if (!this.favoriteSelectFromPopup) {
            const inputParams = Object.assign({}, this.userInfoJson);
            this.PopulateSavedSearchList(inputParams);
        }
    }

    /************    SavedSearchModalShown function: Function will call after favorite popup got opened    ************/

    public SavedSearchModalShown(): void {
        this.favoriteSelectFromPopup = false;
        const inputParams = Object.assign({}, this.userInfoJson);
        this.GetSearchList({
            'inputParams': inputParams,
            'callBack': (results) => {
                this.savedSearchComponent.modalShown(results);
            }
        });
    };

    /************    PopulateSavedSearchList function: Function will populate list of favorites    ************/

    public PopulateSavedSearchList(inputParams: any): void {
        this.newSearch = this.hardCodedFavoriteList;
        this.GetSearchList({
            'inputParams': inputParams,
            'callBack': (results) => {
                const resultList = [];
                const resultListLength = results.length;
                for (let idx = 0; idx < resultListLength; idx++) {
                    resultList.push(results[idx]['userSavedSearchID']);
                }
                this.newSearch = resultList.concat(this.hardCodedFavoriteList);
            }
        });
    };

    /************    GetSearchList function: Function will implement service call for populating favorites    ************/

    public GetSearchList(serviceArguments: any): void {
        // const inputParams = serviceArguments['inputParams'];
        const inputParams = {};
        const callBackFn = serviceArguments['callBack'];
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.ordersearch.getSavedSearchList, inputParams, true)
            // this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.ordersearch.getSavedSearches, inputParams, false)
            .subscribe(results => {
                if (results !== undefined) {
                    if (callBackFn !== undefined) {
                        callBackFn(results);
                    }
                }
            });
    }

    /************    favoriteSearchSelected function: Selected from favorite list    ************/

    public favoriteSearchSelected(typeAheadEvent: any): void {
        if (typeAheadEvent !== undefined && typeAheadEvent['value'] !== undefined) {
            this.selectedFavorite = typeAheadEvent['value'];
            this.favoriteSelectFromPopup = true;
            if (this.hardCodedFavoriteList.some(x => x === this.selectedFavorite)) {
                switch (this.selectedFavorite) {
                    case 'Add to Favorites':
                        this.addFavoriteModal.show();
                        break;
                    case 'Manage Favorites':
                        this.manageFavoriteModal.show();
                        break;
                    default:
                        break;
                }
                this.orderSearchForm.controls['searchOrderNewSearch'].setValue('');
            }
        } else {
            // Need to Populate Saved search here
        }
    }

    /************    populateBusinessUnit function: Function will populate list of business unit    ************/

    public populateBusinessUnit(): void {
        this.businessUnitList = [];
        const url = this.jbhGlobals.endpoints.order.getbusinessunit;
        this.getSearchFieldData(url, (results) => {
            if (results !== undefined && results['_embedded']['serviceOfferingBusinessUnitTransitModeAssociations'] !== undefined) {
                let businessUnitList = [];
                const businessUnitListJson = results['_embedded']['serviceOfferingBusinessUnitTransitModeAssociations'];
                const businessUnitListJsonLength = businessUnitListJson.length;
                for (let businessUnitIdx = 0; businessUnitIdx < businessUnitListJsonLength; businessUnitIdx++) {
                    businessUnitList.push(businessUnitListJson[businessUnitIdx]
                        ['financeBusinessUnitServiceOfferingAssociation']['financeBusinessUnitCode']);
                }
                this.businessUnitList = businessUnitList;
                businessUnitList = null;
            }
        });
    };

    /************    populateBusinessUnit function: Function will populate list of business unit    ************/

    public populateServiceOffering(businessUnit: string): void {
        this.serviceOfferingList = [];
        const url = this.jbhGlobals.endpoints.order.getserviceoffering + '?financeBusinessUnitCode=' +
            businessUnit + '&projection=viewserviceoffering';
        this.getSearchFieldData(url, (results) => {
            if (results !== undefined && results['_embedded']['serviceOfferingBusinessUnitTransitModeAssociations'] !== undefined) {
                let serviceList = [];
                const serviceOfferingList = results['_embedded']['serviceOfferingBusinessUnitTransitModeAssociations'];
                const serviceOfferingListLength = serviceOfferingList.length;
                for (let serviceOfferingIdx = 0; serviceOfferingIdx < serviceOfferingListLength; serviceOfferingIdx++) {
                    serviceList.push(serviceOfferingList[serviceOfferingIdx]
                        ['financeBusinessUnitServiceOfferingAssociation']['serviceOfferingCode']);
                }
                this.serviceOfferingList = serviceList;
                serviceList = null;
            }
        });
    }

    /************    populateReferenceNumber function: Function will populate list
                            of Reference number types with hardcoded 4values    ************/

    public populateReferenceNumber(): void {
        this.referenceNumberTypeList = [];
        const url = this.jbhGlobals.endpoints.ordersearch.referenceNumber;
        this.getSearchFieldData(url, (results) => {
            let referenceNumberTypeList = [];
            if (results !== undefined && results['_embedded']['referenceNumberTypes'] !== undefined) {
                const refNumTypeJson = results['_embedded']['referenceNumberTypes'];
                const refNumTypeJsonLength = refNumTypeJson.length;
                for (let refNumTypeIdx = 0; refNumTypeIdx < refNumTypeJsonLength; refNumTypeIdx++) {
                    referenceNumberTypeList.push(refNumTypeJson[refNumTypeIdx]['referenceNumberTypeCode']);
                }
            }
            this.referenceNumberTypeList = referenceNumberTypeList.concat(this.hardCodedRefNumberTypes);
            referenceNumberTypeList = null;
        });
    }

    /************    populateDefaultRefTypeTxtBox function: Function
                            will populate list of Reference number, where reference type is hardcoded   ************/

    public populateDefaultRefTypeTxtBox(event: any): void {
        const txtBoxValue = event.target.value;
        const referenceNumType = this.orderSearchForm.controls['orderSearchReferrenceType']['value'][0]['id'];
        if (referenceNumType && this.hardCodedRefNumberTypes.some(x => x === referenceNumType)) {
            let url = '';
            let referenceNumberList = [];
            this.referenceNumberList = [];
            switch (referenceNumType) {
                case 'Order Number':
                    url = this.jbhGlobals.endpoints.ordersearch.getOrderNumber + '?orderId=' + txtBoxValue;
                    this.getDataForHardcodedFields(url, (results) => {
                        if (results !== undefined && results['_embedded']['orders'] !== undefined) {
                            const orderNumberList = results['_embedded']['orders'];
                            const orderNumberListLength = orderNumberList.length;
                            for (let refNumListIdx = 0; refNumListIdx < orderNumberListLength; refNumListIdx++) {
                                referenceNumberList.push(orderNumberList[refNumListIdx]['orderID']);
                            }
                        }
                    });
                    break;
                case 'Load Number':
                    url = this.jbhGlobals.endpoints.ordersearch.getLoadNumber + '/' + txtBoxValue;
                    this.getDataForHardcodedFields(url, (results) => {
                        if (results !== undefined) {
                            const resultsLength = results.length;
                            for (let refNumListIdx = 0; refNumListIdx < resultsLength; refNumListIdx++) {
                                referenceNumberList.push(results[refNumListIdx]['loadNumber']);
                            }
                        }
                    });
                    break;
                case 'Trailer Number':
                    url = this.jbhGlobals.endpoints.ordersearch.getTrailerNumber +
                        '/?trailerNumber=' + txtBoxValue + 'projection=viewtrailernumber';
                    this.getDataForHardcodedFields(url, (results) => {
                        if (results !== undefined && results['_embedded']['equipments'] !== undefined) {
                            const trailerList = results['_embedded']['equipments'];
                            const trailerListLength = trailerList.length;
                            for (let refNumListIdx = 0; refNumListIdx < trailerListLength; refNumListIdx++) {
                                referenceNumberList.push(trailerList[refNumListIdx]['trailerNumber']);
                            }
                        }
                    });
                    break;
                default:
                    referenceNumberList = [];
                    break;
            }
            this.referenceNumberList = referenceNumberList;
            referenceNumberList = null;
        }
    }

    /************    populateReferenceNumberType function: Function will
                            populate list of Reference number as per selection of reference type    ************/

    public populateReferenceNumberType(referenceNumType: string): void {
        this.referenceNumberList = [];
        if (!this.hardCodedRefNumberTypes.some(x => x === referenceNumType)) {
            const url = this.jbhGlobals.endpoints.ordersearch.referenceNumberType +
                '?referenceNumberTypeCode=' + referenceNumType + '&projection=viewreferencenumbervalue';
            this.getSearchFieldData(url, (results) => {
                let referenceNumberList = [];
                if (results !== undefined && results['_embedded']['stopReferenceNumbers'] !== undefined) {
                    const refNumberList = results['_embedded']['stopReferenceNumbers'];
                    const refNumberListLength = refNumberList.length;
                    for (let refNumListIdx = 0; refNumListIdx < refNumberListLength; refNumListIdx++) {
                        referenceNumberList.push(refNumberList[refNumListIdx]['referenceNumberValue']);
                    }
                }
                this.referenceNumberList = referenceNumberList;
                referenceNumberList = null;
            });
        }
    };

    /************    populateDrayServices function: Function will populate dray services    ************/

    public populateDrayServices(): void {
        this.orderSearchDrayServiceList = [];
        const url = this.jbhGlobals.endpoints.ordersearch.getDrayService;
        this.getSearchFieldData(url, (results) => {
            if (results !== undefined && results['_embedded']['serviceTypes'] !== undefined) {
                let orderSearchDrayServiceList = [];
                const orderSearchDrayServiceListJSON = results['_embedded']['serviceTypes'];
                const orderSearchDrayServiceListJSONLength = orderSearchDrayServiceList.length;
                for (let drayServiceIdx = 0; drayServiceIdx < orderSearchDrayServiceListJSONLength; drayServiceIdx++) {
                    orderSearchDrayServiceList.push(orderSearchDrayServiceListJSON[drayServiceIdx]['serviceTypeCode']);
                }
                this.orderSearchDrayServiceList = orderSearchDrayServiceList;
                orderSearchDrayServiceList = null;
            }
        });
    }

    /************    populateOrderCreationChannel function: Function will populate Order Creation Channel    ************/

    public populateOrderCreationChannel(): void {
        this.orderSearchCreationChannelList = [];
        const url = this.jbhGlobals.endpoints.ordersearch.orderCreationChannel;
        this.getSearchFieldData(url, (results) => {
            if (results !== undefined) {
                this.orderSearchCreationChannelList = results;
            }
        });
    };

    /************    populateOrderStatus function: Function will populate Order status    ************/

    public populateOrderStatus(): void {
        this.orderStatusList = [];
        const url = this.jbhGlobals.endpoints.ordersearch.orderStatus;
        this.getSearchFieldData(url, (results) => {
            if (results !== undefined && results['_embedded']['orderStatuses'] !== undefined) {
                let orderStatusList = [];
                const orderStatusListJSON = results['_embedded']['orderStatuses'];
                const orderStatusListJSONLength = orderStatusListJSON.length;
                for (let orderStatusIdx = 0; orderStatusIdx < orderStatusListJSONLength; orderStatusIdx++) {
                    orderStatusList.push(orderStatusListJSON[orderStatusIdx]['orderStatusCode']);
                }
                this.orderStatusList = orderStatusList;
                orderStatusList = null;
            }
        });
    };

    /************    populateOrderSeatchreasonOrderStatus function: Function
                            will populate reason code based on Order status    ************/

    public populateOrderSeatchreasonOrderStatus(event: any): void {
        this.OrderSeatchreasonOrderStatusList = [];
        const txtBoxValue = event.target.value;
        const url = this.jbhGlobals.endpoints.ordersearch.orderStatusReasonCode +
            '?orderStatusCode=' + txtBoxValue + '&projection=vieworderstatuseventreason';
        this.getSearchFieldData(url, (results) => {
            if (results !== undefined && results['_embedded']['orderStatusEventReasons'] !== undefined) {
                let OrderSeatchreasonOrderStatusList = [];
                const reasonCodeJSON = results['_embedded']['orderStatusEventReasons'];
                const reasonCodeJSONLength = reasonCodeJSON.length;
                for (let reasoncodeSerIndex = 0; reasoncodeSerIndex < reasonCodeJSONLength; reasoncodeSerIndex++) {
                    OrderSeatchreasonOrderStatusList.push(reasonCodeJSON[reasoncodeSerIndex]['orderStatusEventReasonDescription']);
                }
                this.OrderSeatchreasonOrderStatusList = OrderSeatchreasonOrderStatusList;
                OrderSeatchreasonOrderStatusList = null;
            }
        });
    }

    /************    populateFleetCode function: Function will populate Fleet Code based on business unit    ************/

    public populateFleetCode(businessUnit: string): void {
        this.orderSearchFleetCodeList = [];
        const url = this.jbhGlobals.endpoints.order.getfleetcode +
            '?businessunit=' + businessUnit;
        this.getSearchFieldData(url, (results) => {
            let fleetList = [];
            const resultsLength = results.length;
            for (let fleetListIdx = 0; fleetListIdx < resultsLength; fleetListIdx++) {
                fleetList.push(results[fleetListIdx]['id']);
            }
            this.orderSearchFleetCodeList = fleetList;
            fleetList = null;
        });
    }

    /************    populateOrderType function: Function will populate Order Type based on business unit & service offering   ************/

    public populateOrderType(businessUnit: string, serviceOffering: string): void {
        this.orderTypeList = [];
        const url = this.jbhGlobals.endpoints.order.getordertype + '?financeBusinessUnitCode=' +
            businessUnit + '?serviceOfferingCode=' +
            serviceOffering + '?projection=viewOrderType';
        this.getSearchFieldData(url, (results) => {
            if (results !== undefined && results['_embedded']['orderTypeFinanceBusinessUnitServiceOfferingAssociations'] !== undefined) {
                let orderTypeList = [];
                const orderTypeListJSON = results._embedded.orderTypeFinanceBusinessUnitServiceOfferingAssociations;
                const orderTypeListJSONLength = orderTypeListJSON.length;
                for (let orderTypeIdx = 0; orderTypeIdx < orderTypeListJSONLength; orderTypeIdx++) {
                    orderTypeList[orderTypeIdx] = orderTypeListJSON[orderTypeIdx]['orderType']['orderTypeCode'];
                }
                this.orderTypeList = orderTypeList;
                orderTypeList = null;
            }
        });
    }

    /************    populateServiceLevel function: Function will
                            populate Service Level based on business unit & service offering   ************/

    public populateServiceLevel(businessUnit: string, serviceOffering: string): void {
        this.serviceLevelList = [];
        const url = this.jbhGlobals.endpoints.order.getservicelevels + '?financeBusinessUnitCode=' +
            businessUnit + '&serviceOfferingCode=' + serviceOffering;
        this.getSearchFieldData(url, (results) => {
            if (results !== undefined && results['_embedded']['serviceLevelBusinessUnitServiceOfferingAssociations'] !== undefined) {
                let serviceLevelList = [];
                const serviceLevelListJSON = results['_embedded']['serviceLevelBusinessUnitServiceOfferingAssociations'];
                const serviceLevelListJSONLength = serviceLevelListJSON.length;
                for (let serviceLvlIdx = 0; serviceLvlIdx < serviceLevelListJSONLength; serviceLvlIdx++) {
                    serviceLevelList[serviceLvlIdx] = serviceLevelListJSON[serviceLvlIdx]['serviceLevel']['serviceLevelCode'];
                }
                this.serviceLevelList = serviceLevelList;
                serviceLevelList = null;
            }
        });
    };

    /************    populateInternationService function: Function will populate International Service based on dray services  ************/

    public populateInternationService(serviceCategoryCode: string): void {
        this.internationalServieceList = [];
        const url = this.jbhGlobals.endpoints.order.getinternationalservices + '?serviceCategoryCode=' + serviceCategoryCode;
        this.getSearchFieldData(url, (results) => {
            if (results !== undefined && results['_embedded']['serviceTypes'] !== undefined) {
                let internationalServieceList = [];
                const internationalServieceJSON = results['_embedded']['serviceTypes'];
                const internationalServieceJSONLength = internationalServieceJSON.length;
                for (let internationSerIndex = 0; internationSerIndex < internationalServieceJSONLength; internationSerIndex++) {
                    internationalServieceList.push(internationalServieceJSON[internationSerIndex]['serviceTypeCode']);
                }
                this.internationalServieceList = internationalServieceList;
                internationalServieceList = null;
            }
        });
    }

    /************    populateAccountTypeList function: Will Populate Account Type list based on Selection    ************/

    public populateAccountTypeList(accountType: string) {
        let locationNameList = [];
        this.locationNameList = [];
        switch (accountType) {
            case 'Bill To':
                this.orderSearchForm.controls['orderSearchName'].setValue('');
                const billtoUrl = this.jbhGlobals.endpoints.order.gettypeaheadbillto +
                    '?value=1010101&roletype=Bill To&active=yes&page=0&size=5&approved=true&addresstype=FREIGHT BILL';
                this.getDataForHardcodedFields(billtoUrl, (results) => {
                    if (results !== undefined && results['profileDTO']['0']['addressDTO'] !== undefined) {
                        for (let billtoIndex = 0; billtoIndex < results['totalRecords']; billtoIndex++) {
                            const billtoResult = results['profileDTO'][billtoIndex]['addressDTO']['id'] + ',' +
                                results['profileDTO'][billtoIndex]['addressDTO']['addressLine1'] + ',' +
                                results['profileDTO'][billtoIndex]['addressDTO']['addressLine2'] + ',' +
                                results['profileDTO'][billtoIndex]['addressDTO']['city'] + ',' +
                                results['profileDTO'][billtoIndex]['addressDTO']['state'] + ',' +
                                results['profileDTO'][billtoIndex]['addressDTO']['zipcode'] + ',' +
                                results['profileDTO'][billtoIndex]['addressDTO']['country'] + ',' +
                                results['profileDTO'][billtoIndex]['name'] + '(' + results['profileDTO'][billtoIndex]['code'] + ')';
                            locationNameList.push(billtoResult);
                        }
                    }
                });
                break;
            case 'Solicitor':
                this.orderSearchForm.controls['orderSearchName'].setValue('');
                const solicitorUrl = this.jbhGlobals.endpoints.order.gettypeaheadsolicitor +
                    '?value=RIFT8&roletype=Solicitor&active=yes&page=0' +
                    '&size=5&approved=true&addresstype=MAILING';
                this.getDataForHardcodedFields(solicitorUrl, (results) => {
                    if (results !== undefined && results['profileDTO']['0']['addressDTO'] !== undefined) {
                        for (let Solicitorindex = 0; Solicitorindex < results['totalRecords']; Solicitorindex++) {
                            const SolicitorResult = results['profileDTO'][Solicitorindex]['addressDTO']['id'] + ',' +
                                results['profileDTO'][Solicitorindex]['addressDTO']['addressLine1'] + ',' +
                                results['profileDTO'][Solicitorindex]['addressDTO']['addressLine2'] + ',' +
                                results['profileDTO'][Solicitorindex]['addressDTO']['city'] + ',' +
                                results['profileDTO'][Solicitorindex]['addressDTO']['state'] + ',' +
                                results['profileDTO'][Solicitorindex]['addressDTO']['zipcode'] + ',' +
                                results['profileDTO'][Solicitorindex]['addressDTO']['country'] + ',' +
                                results['profileDTO'][Solicitorindex]['name'] + '(' + results['profileDTO'][Solicitorindex]['code'] + ')';
                            locationNameList.push(SolicitorResult);
                        }
                    }
                });
                break;
            default:
                locationNameList = [];
                break;
        }
        this.locationNameList = locationNameList;
        locationNameList = null;
    }

    /************    populateOriginMarketArea function: Function will populate Orgin Marketing Area  ************/

    public populateOriginMarketArea(): void {
        this.originMarKetAreaList = [];
        const url = this.jbhGlobals.endpoints.ordersearch.OriginDestMarketAreaonZip + '?zipcode=31065';
        this.populateMarketAreaList(url, (results) => {
            let originMarKetAreaList = [];
            if (results !== undefined && results['marketingArea'] !== undefined) {
                originMarKetAreaList.push(results['marketingArea']);
            }
            this.originMarKetAreaList = originMarKetAreaList;
            originMarKetAreaList = null;
        });
    };

    /************    populateDestinationMarketArea function: Function will populate Destination Marketing Area  ************/

    public populateDestinationMarketArea(): void {
        this.destinationMarKetAreaList = [];
        const url = this.jbhGlobals.endpoints.ordersearch.OriginDestMarketAreaonZip + '?zipcode=31065';
        this.populateMarketAreaList(url, (results) => {
            let destinationMarKetAreaList = [];
            if (results !== undefined && results['marketingArea'] !== undefined) {
                destinationMarKetAreaList.push(results['marketingArea']);
            }
            this.destinationMarKetAreaList = destinationMarKetAreaList;
            destinationMarKetAreaList = null;
        });
    }

    /************    populateMarketAreaList function: Function will populate Marketing Area list  ************/

    public populateMarketAreaList(url: any, callBackFn: any): void {
        this.getSearchFieldData(url, (results) => {
            if (callBackFn !== undefined) {
                callBackFn(results);
            }
        });
    }

    /************    getDataForHardcodedFields function: Function will
                            implement service call for populating values for hardcoded fields    ************/

    public getDataForHardcodedFields(fieldUrl: string, callBackFn: any): void {
        this.getSearchFieldData(fieldUrl, (results) => {
            if (callBackFn !== undefined) {
                callBackFn(results);
            }
        });
    }

    /************    getSearchFieldData function: Function will implement service call for populating Search Field Data    ************/

    public getSearchFieldData(fieldUrl: string, callBackFn: any): void {
        const inputParams = {};
        this.jbhGlobals.apiService.getData(fieldUrl, inputParams, true).subscribe(data => {
            if (callBackFn !== undefined) {
                callBackFn(data);
            }
        });
    }

    /************    onSelectPrefix function: ng2 Select component - On Select Function    ************/

    public onSelectPrefix(event: Object, selectFieldValue: string): void {
        const selectedValue = event['id'];
        switch (selectFieldValue) {
            case 'orderSearchTypeList':
                this.populateAccountTypeList(selectedValue);
                break;
            case 'businessUnitList':
                this.selectedBusinessUnit = selectedValue;
                this.populateFleetCode(selectedValue);
                this.populateServiceOffering(selectedValue);
                this.orderSearchForm.controls['orderSearchFleetCode'].setValue('');
                this.orderSearchForm.controls['orderSearchServiceOffering'].setValue('');
                this.orderSearchForm.controls['orderSearchServiceLevel'].setValue('');
                this.orderSearchForm.controls['orderSearchOrderType'].setValue('');
                break;
            case 'serviceOfferingList':
                this.orderSearchForm.controls['orderSearchServiceLevel'].setValue('');
                this.orderSearchForm.controls['orderSearchOrderType'].setValue('');
                this.populateOrderType(this.selectedBusinessUnit, selectedValue);
                this.populateServiceLevel(this.selectedBusinessUnit, selectedValue);
                break;
            case 'referenceNumberTypeList':
                this.orderSearchForm.controls['orderSearchReferrenceValue'].setValue('');
                this.populateReferenceNumberType(selectedValue);
                break;
            case 'orderSearchDrayServiceList':
                this.populateInternationService(selectedValue);
                break;
            default:
                break;
        }
    }

    /************    addFavoriteBtnClicked function: Function will Implement Add Favorite    ************/

    public addFavoriteBtnClicked(): void {
        const inputParam = {};
        inputParam['personID'] = '225566';
        inputParam['userSearchName'] = this.newFavoriteName;
        inputParam['userSearchDefaultIndicator'] = 'Y';
        inputParam['applicationSearchFunctionCode'] = 'searchFunc';
        inputParam['userSearchCriteriaContent'] = btoa(this.orderSearch()); // Encrypted JSON to Post
        this.jbhGlobals.apiService.addData(this.jbhGlobals.endpoints.ordersearch.getSavedSearches, inputParam)
            .subscribe(stopData => {

            });
        this.newFavoriteName = '';
    }

    /************    showMoreSearch function: Show More / Show Less Functionality    ************/

    public showMoreSearch(): void {
        this.orderSearchMoreOrLess = !this.orderSearchMoreOrLess;
    }

    /************    orderSearch function: Will Emit orderSearchSaveForm parent function after clicking search    ************/

    public orderSearch(): string {
        // this.orderSearchSaveForm.emit(orderSearchForm);
        const formObj = this.orderSearchForm.controls;
        const formObjLen = Object.keys(formObj).length;
        const FormKeys = _.keys(formObj);
        const payLoad = {};
        for (let formObjIndex = 0; formObjIndex < formObjLen; formObjIndex++) {
            payLoad[FormKeys[formObjIndex]] = (formObj[FormKeys[formObjIndex]]) ? formObj[FormKeys[formObjIndex]]['_value'] : '';
        }
        return JSON.stringify(payLoad);
    }

    /************    typeaheadOnSelect function: Will trigger once typeahead got selected   ************/

    public typeaheadOnSelect(event: any, typeAheadField: string): void {

    };

    /************    typeaheadNoResultsCallBack function: Will trigger once typeahead has no results   ************/

    public typeaheadNoResultsCallBack(isNoResultExists: boolean, typeAheadField: string): void {
        this.validationErrorMessageFlag[typeAheadField] = isNoResultExists;
    }

    /************    searchOrderNewSearch function: NA   ************/

    public searchOrderNewSearch($event) {
        // console.log('Search String');
    }

    /************    ngSelectFocusOutEvent function: Will Trigger if Focus out called   ************/

    public ngSelectFocusOutEvent(event: any, errorField: string, dropDownArray: any) {
        const element = event.target;
        const errorExists = this.validationErrorMessageFlag[errorField];
        this.validationErrorMessageFlag[errorField] = (element.type === 'text') ? element.value !== '' : errorExists;
    }

    /************    onValidatedEmptyField function: To Validate Invalid input over ng-Select   ************/

    public onValidatedEmptyField(value: string, errorField: string, dropDownArray: any): void {
        this.validationErrorMessageFlag[errorField] = this.getElementExistsInArray(value, dropDownArray);
    }

    /************    getElementExistsInArray function: To Validate value, which exists in array   ************/

    public getElementExistsInArray(value: string, dropdownArray: any): boolean {
        const iteratedResults = dropdownArray.filter(function(item) {
            return typeof item === 'string' && item.toLowerCase().indexOf(value.toLowerCase()) > -1;
        });
        return (iteratedResults.length === 0);
    }

    /*************** Add more comp click fun **************/

    public addMoreAdd(): void {
        console.log(this.orderSearchForm.controls['orderSearchType']);
        if (this.orderSearchTypeList.length > this.accountTypes.length) {
            this.accountTypes.length++;
            this.addMorermbtn = true;
            (this.accountTypes.length === this.orderSearchTypeList.length) ?
                this.addMoreaddbtn = false : this.addMoreaddbtn = true;
        }
    }

    public addMoreRemove(): void {
        if (this.accountTypes.length > 1) {
            this.accountTypes.length--;
            this.addMoreaddbtn = true;
            (this.accountTypes.length === 1) ? this.addMorermbtn = false : this.addMorermbtn = true;
        }
    }

    public addMoreRefAdd(): void {
        if (this.referenceNumberTypeList.length > this.referrenceTypes.length) {
            this.referrenceTypes.length++;
            this.addMoreRefrmbtn = true;
            (this.referrenceTypes.length === this.referenceNumberTypeList.length) ?
                this.addMoreRefaddbtn = false : this.addMoreRefaddbtn = true;
        }
    }

    public addMoreRefRemove(): void {
        if (this.referrenceTypes.length > 1) {
            this.referrenceTypes.length--;
            this.addMoreRefaddbtn = true;
            (this.referrenceTypes.length === 1) ? this.addMoreRefrmbtn = false : this.addMoreRefrmbtn = true;
        }
    }

}
