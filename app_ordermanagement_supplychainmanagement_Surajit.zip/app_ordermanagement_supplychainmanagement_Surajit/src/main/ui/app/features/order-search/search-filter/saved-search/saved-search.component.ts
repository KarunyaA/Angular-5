import { Component, OnInit, Injectable, Input, Output, EventEmitter } from '@angular/core';
import { JBHGlobals } from '../../../../app.service';

@Component({
    selector: 'app-saved-search',
    templateUrl: './saved-search.component.html',
    styleUrls: ['./saved-search.component.scss']
})

@Injectable()
export class SavedSearchComponent implements OnInit {

    // List of Saved Search to populate in popup
    public savedSearchList = [];
    // List of Remove Saved Search popup Message
    public removeSavedSearchMessage: string;
    // List of Remove Saved Search popup Status
    public removeSavedSearchStatus: string;
    // Current User Info JSON
    public userInfoJson: Object = {};
    // Removable JSON from Popup
    public removeSavedSearchData: Object = {};
    // Selected Favorite from Favorites Popup
    public selectedFavorite: string;

    /************    Setter Function: Data, Model, Property will set from parent - Search Filter Component - Starts    ************/

    /************    parentUserInfoJson property: Data will be mapped from Parent Component    ************/

    @Input()
    set parentUserInfoJson(parentUserInfoJson: any) {
        this.userInfoJson = Object.assign({}, parentUserInfoJson);
    };

    /************    parentUserInfoJson property: Data will be mapped from Parent Component    ************/

    /************    Setter Function: Data, Model, Property will set from parent - Search Filter Component - Ends    ************/

    // To Parent Component, Emits when we Hide Saved Search Popup
    @Output() HideSavedSearchModal = new EventEmitter < any > ();
    // To Parent Component, Emits to get list of saved searches
    @Output() GetSearchList = new EventEmitter < any > ();
    // To Parent Component, Emits when favorite got selected
    @Output() FavoriteSearchSelected = new EventEmitter < any > ();

    constructor(
        public jbhGlobals: JBHGlobals
    ) {}

    ngOnInit() {

    }

    /************    modalShown function: Public method get triggers from parent search filter component    ************/

    public modalShown(savedSearchListData: any): void {
        this.savedSearchList = [];
        this.removeSavedSearchData = {};
        if (savedSearchListData.length !== 0) {
            this.savedSearchList = savedSearchListData;
        }
    };

    /************    removeSavedSearch function: method get triggers if we trigger over remove search x Icon    ************/

    public removeSavedSearch(): void {
        const url = this.jbhGlobals.endpoints.ordersearch.revomeSavedSearch + '/' + this.removeSavedSearchData['userSavedSearchID'];
        const copyJSON = Object.assign({}, this.userInfoJson);
        const inputParam = Object.assign(copyJSON, this.removeSavedSearchData);
        this.jbhGlobals.apiService.getData(url, inputParam, false).subscribe(data => {
            if (data !== undefined) {
                // this.removeSavedSearchStatus = data['RestResponse']['statusCode'];
                // this.removeSavedSearchMessage = data['RestResponse']['message'];
                // if (this.removeSavedSearchStatus.toUpperCase() === 'P') {
                this.populateSavedSearchList({});
                // }
            }
        });
    };

    /************    setRemovableData function: To Set removable Temp Data    ************/

    public setRemovableData(event: any, inputParam: any): void {
        this.removeSavedSearchData = inputParam;
        event.stopPropagation();
    };

    /************    warningPopupHidden function: Triggers when warning popup get hidden    ************/

    public warningPopupHidden(): void {
        this.removeSavedSearchData = {};
    };


    /************    Parent Component: Event Emitter Function Declaration - Starts    ************/

    /************    populateSavedSearchList function: method to populate Saved Searches    ************/

    /************    favoriteSelected function: Triggers when favorite got selected    ************/

    public favoriteSelected(typeAheadEvent: any): void {
        this.FavoriteSearchSelected.emit(typeAheadEvent);
        this.closeModal();
    };

    public populateSavedSearchList(inputParams: any): void {
        const copyJSON = Object.assign({}, this.userInfoJson);
        this.GetSearchList.emit({
            'inputParams': Object.assign(copyJSON, inputParams),
            'callBack': (results) => {
                this.modalShown(results);
            }
        });
    }

    /************    closeModal function: To Set removable Temp Data    ************/

    public closeModal(): void {
        this.HideSavedSearchModal.emit();
    };

    /************    Parent Component: Event Emitter Function Declaration - Ends    ************/
}
