import { Component, OnInit, Injectable, ViewChild } from '@angular/core';
import { JBHGlobals } from '../../app.service';
import { SearchFilterComponent } from './search-filter/search-filter.component';
import { SearchResultGridComponent } from './search-result-grid/search-result-grid.component';

@Component({
  selector: 'app-order-search',
  templateUrl: './order-search.component.html',
  styleUrls: ['./order-search.component.scss']
})

@Injectable()
export class OrderSearchComponent implements OnInit {

  // To View Search Filter Component
  @ViewChild(SearchFilterComponent) public searchFilterComponent: SearchFilterComponent;

  // To View Search Result Grid Component
  @ViewChild(SearchResultGridComponent) public searchResultGridComponent: SearchResultGridComponent;

  // Search Results Grid - JSON Data
  public searchGridResult: Object = {};
  // Search Results Grid Column - JSON Data
  public searchGridColumns: Object = {};
  // Search Results Grid - Filter Icon Visible Flag
  public additionalFilterFlag: boolean;
  // JSON will set User Information to Child Components
  public userInfoJson: Object = {
    user: 'loginUser'
  };

  constructor(
    public jbhGlobals: JBHGlobals
  ) { }

  ngOnInit() {
    const userInfoJson = Object.assign({}, this.userInfoJson);
    this.searchGridResult = {};
    this.additionalFilterFlag = true;
    this.getSearchGridColumns(userInfoJson);
    this.populateGridRecords(userInfoJson);
    this.setUpKeyboardShortcuts();
  }

  public setUpKeyboardShortcuts() {
      this.jbhGlobals.shortkeys.getData().subscribe(data => {
          if (data.keyCode === 'alt+1') {
              this.searchFilterComponent.searchFilterFirstNavigation.nativeElement.focus();
          } else if (data.keyCode === 'alt+2') {
              this.searchResultGridComponent.searchResultFirstNavigation.nativeElement.focus();
          }
      });
  }

  /************    getSearchGridColumns function: column Data to be mapped over search results grid Component    ************/

  public getSearchGridColumns(inputParams): void {
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.ordersearch.getSearchGridColumns, inputParams, false)
      .subscribe(data => {
        if (data !== undefined) {
          this.searchGridColumns = data;
        }
      });
  };

  /************    populateGridRecords function: Grid Data to be mapped over search results grid Component    ************/

  public populateGridRecords(inputDataParams): void {
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.ordersearch.getSearchGridRecords, inputDataParams, false)
      .subscribe(data => {
        if (data !== undefined) {
          this.searchGridResult = data;
        }
      });
  };

  /************    gridAdditionalFilterClicked function: Called from Search-Results Grid while click over Filter Icon    ************/

  public gridAdditionalFilterClicked(): void {
    this.additionalFilterFlag = !this.additionalFilterFlag;
  };

  /************    gridDropMenuSelected function: Called from Search-Results Grid while selecting items over dropdown    ************/

  public gridDropMenuSelected(selectedGridMenuId): void {
    console.log(selectedGridMenuId);
  };

  /************    searchOrder function: Called when search button got clicked    ************/

  public searchOrder(formData): void {
    // const OrderSearchformObj = formData.value;
  }
}
