import { Component, OnInit, Injectable, Input } from '@angular/core';
import { FormGroup } from '@angular/forms';

@Component({
    selector: 'app-add-more',
    templateUrl: './add-more.component.html',
    styleUrls: ['./add-more.component.scss']
})

@Injectable()
export class AddMoreComponent implements OnInit {

    @Input() addMoreForm: FormGroup;
    @Input() dataList;

    public validationErrorMessageFlag: any = {};
    public addMoreIndex: number;

    @Input()
    set addMoreIdx(indexArg) {
        this.addMoreIndex = indexArg;
    }

    constructor() {

    }

    ngOnInit() {
        this.validationErrorMessageFlag = {
            'locationName1': false,
        };
    }


    public typeaheadNoResultsCallBack(isNoResultExists: boolean, typeAheadField: string): void {
        this.validationErrorMessageFlag[typeAheadField] = isNoResultExists;
    }


    // <!-- Added for ng2-select method implementation Pras-918 -->

    public onSelectPrefix(value: string): void {

    }

    public onRemovePrefix(value: any): void {
        // console.log(value);
    }


    public onTypePrefix(event): void {
        // console.log(event);
    }

    // <!-- Added for ng2-select method implementation Pras-918 -->
}
