import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
    selector: 'app-manage-columns',
    templateUrl: './manage-columns.component.html',
    styleUrls: ['./manage-columns.component.scss']
})

export class ManageColumnsComponent implements OnInit {

    // Edit Column Model - List of Columns
    public columns = [];
    // Edit Column Model - Minimum no. of Columns for visibility
    public minimumNoOfColumns = 3;
    // Edit Column Model - Visible Property
    public visibleProperty = 'isVisible';
    // Edit Column Model - Error Status - If Required
    public errorStatus: string;
    // Edit Column Model - Error Status - If Required
    public errorMessage: string;
    // Edit Column Model - Text box selectedColumn - Typeahead field  - 2way binding
    public selectedColumn: string;

    // To Parent Component, Emits when we tends to close model
    @Output() HideEditColumnModel = new EventEmitter < any > ();
    // To Parent Component, Emits when we tends to click save in modal
    @Output() UpdateColumModel = new EventEmitter < any > ();

    constructor() {}

    ngOnInit() {

    }

    /************    Setter Function: Data, Model, Property will set from parent Component - Starts    ************/

    /************    gridColumns function: Data will be mapped from Parent Component    ************/

    @Input()
    set gridColumns(gridColumnsArr: any) {
        this.columns = gridColumnsArr;
    }

    /************    editColumnUpdateStatus function: Update status will be mapped from Parent Component    ************/

    @Input()
    set editColumnUpdateStatus(editColumnStatusMsgJson: any) {
        if (editColumnStatusMsgJson) {
            this.errorStatus = editColumnStatusMsgJson['statusCode'];
            this.errorMessage = editColumnStatusMsgJson['message'];
        }
    }

    /************    Setter Function: Data, Model, Property will set from parent Component - Starts    ************/

    /************    Parent Component: Event Emitter Function Declaration - Starts    ************/

    /************    closeModal function: Used to Close Edit Column Model    ************/

    public closeModal(): void {
        this.HideEditColumnModel.emit();
    }

    /************    saveBtnClicked function: Will update current status of column to user    ************/

    public saveBtnClicked(): void {
        this.UpdateColumModel.emit(this.columns);
    }

    /************    typeaheadOnSelect function: Typeahead select callback function    ************/

    public typeaheadOnSelect(typeAheadEvent: any): void {

    }

    /************    Parent Component: Event Emitter Function Declaration - Starts    ************/

    /************    manageColumnVisibility function: Will Handle column visibility    ************/

    public manageColumnVisibility(columnJsonArg: Object): void {
        // this.errorStatus = 'P';
        // this.errorMessage = '';
        const columnDataProp = this.checkAndReturnValidColumn(columnJsonArg['property']);
        if (columnDataProp['isMinimumColumsExists']) {
            columnDataProp['column']['isVisible'] = !columnDataProp['column']['isVisible'];
        } else {
            // this.errorStatus = 'F';
            // this.errorMessage = 'Invalid';
            columnDataProp['column']['isVisible'] = true;
        }
    }

    /************    checkAndReturnValidColumn function: Will check minimum column visibility    ************/

    public checkAndReturnValidColumn(columnProperty: string): Object {
        let counter = 0;
        const columnJsonProp = {
            isMinimumColumsExists: false,
            columnJsonProp: {}
        };
        for (let columnIdx = 0; columnIdx < this.columns.length; columnIdx++) {
            const columnJson = this.columns[columnIdx];
            if (columnJson[this.visibleProperty]) {
                counter = counter + 1;
            }
            if (columnProperty === columnJson['property']) {
                columnJsonProp['column'] = columnJson;
            }
        }
        columnJsonProp['isMinimumColumsExists'] = (counter > this.minimumNoOfColumns);
        return columnJsonProp;
    }

}
