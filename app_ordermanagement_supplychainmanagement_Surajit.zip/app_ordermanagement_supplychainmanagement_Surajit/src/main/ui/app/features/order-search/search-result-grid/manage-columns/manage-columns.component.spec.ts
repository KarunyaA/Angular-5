import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageColumnsComponent } from './manage-columns.component';

describe('ManageColumnsComponent', () => {
  let component: ManageColumnsComponent;
  let fixture: ComponentFixture<ManageColumnsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageColumnsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageColumnsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
