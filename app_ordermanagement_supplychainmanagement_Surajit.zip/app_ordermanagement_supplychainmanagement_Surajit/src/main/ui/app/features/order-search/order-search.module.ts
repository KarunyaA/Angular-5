import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

// import { SelectModule } from 'ng2-select';
import { SelectModule } from '../../shared/select';
import { TagInputModule } from 'ng2-tag-input';
import { TypeaheadModule } from 'ngx-bootstrap';
import { MyDatePickerModule } from 'mydatepicker';
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { OrderSearchRoutingModule } from './order-search-routing.module';
import { OrderSearchComponent } from './order-search.component';
import { SearchFilterComponent } from './search-filter/search-filter.component';
import { SearchResultGridComponent } from './search-result-grid/search-result-grid.component';
// <!-- Added for Saved Search -->
import { SavedSearchComponent } from './search-filter/saved-search/saved-search.component';
// <!-- Added for Saved Search -->
import { AddMoreComponent } from './search-filter/add-more/add-more.component';
import { ManageColumnsComponent } from './search-result-grid/manage-columns/manage-columns.component';

/*	Newly Added for Order-Search Module		*/
import { BsDropdownModule, ModalModule, SortableModule } from 'ngx-bootstrap';
import { JBHDataTableModule } from '../../shared/jbh-data-table/jbh-data-table.module';
import { AddMoreReferrenceComponent } from './search-filter/add-more-referrence/add-more-referrence.component';
/*	Newly Added for Order-Search Module		*/

@NgModule({
  imports: [
    CommonModule,
    OrderSearchRoutingModule,
    JBHDataTableModule,
    BsDropdownModule,
    ModalModule,
    TagInputModule,
    TypeaheadModule,
    MyDatePickerModule,
    PerfectScrollbarModule,
    FormsModule,
    ReactiveFormsModule,
    SelectModule,
    SortableModule.forRoot()
  ],
  declarations: [
    OrderSearchComponent,
    SearchFilterComponent,
    SearchResultGridComponent,
    SavedSearchComponent,
    AddMoreComponent,
    ManageColumnsComponent,
    AddMoreReferrenceComponent
  ]
})
export class OrderSearchModule { }
