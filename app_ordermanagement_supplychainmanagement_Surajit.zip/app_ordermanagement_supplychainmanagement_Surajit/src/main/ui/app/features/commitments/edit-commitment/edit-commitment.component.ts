import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray } from '@angular/forms';
import { Commitment } from '../model/commitment.model';
import { JBHGlobals } from '../../../app.service';
import { IMyOptions } from 'mydatepicker'; // IMyDateModel
import { NotificationsService } from 'angular2-notifications';
import { TypeaheadMatch } from 'ngx-bootstrap';
import * as _ from 'lodash';

@Component({
  selector: 'app-edit-commitment',
  templateUrl: './edit-commitment.component.html',
  styleUrls: ['./edit-commitment.component.scss']
})
export class EditCommitmentComponent implements OnInit {

  @Input()
  commitment: Commitment;

  @Input()
  allDetailsVisible: boolean;

  @Output()
  notifyCancel: EventEmitter<any> = new EventEmitter<any>();

  @Output()
  commitmentForm: EventEmitter<any> = new EventEmitter<any>();

  businessUnitList: string[] = [];
  serviceOfferingList: string[] = [];

  modifyForm: FormGroup;

  /* For typeaheads */
  typeaheadLoading: boolean;
  typeaheadNoResults: boolean;
  corpAcctDataSource: any[];
  public debounceValue: number;

  public myDatePickerOptions: IMyOptions = {
    dateFormat: 'dd-mm-yyyy',
    showClearDateBtn: false,
    selectionTxtFontSize: '14px',
    height: '30px',
    firstDayOfWeek: 'mo',
    sunHighlight: true
  };

  constructor(public formBuilder: FormBuilder,
    public jbhGlobals: JBHGlobals,
    public notifications: NotificationsService) { }

  ngOnInit() {
    this.debounceValue = this.jbhGlobals.settings.debounce;
    // to load business unit dropdown values
    this.loadBusinessUnit();

    this.modifyForm = this.formBuilder.group({
      corporateAccount: ['', Validators.required],
      lineOfBusiness: [''],
      billToAccount: [''],
      businessUnit: ['', Validators.required],
      serviceOffering: ['', Validators.required],
      originMarketingArea: ['', Validators.required],
      destinationMarketingArea: [''],
      shipperLocation: [''],
      schedules: this.formBuilder.array([
        this.initSchedule()
      ]),
      operationsTeamLeader: ['', Validators.required],
      operationsOwner: ['', Validators.required],
      orderOwner: ['', Validators.required],
      salesContact: ['', Validators.required]
    });

    this.modifyForm['controls']['corporateAccount']['valueChanges']
      .debounceTime(this.debounceValue)
      .distinctUntilChanged()
      .subscribe((value) => {
        if (value.length === 0 && value !== undefined) {
          this.modifyForm['controls']['corporateAccount']['setValue']('');
        }
        if (value !== undefined && value.length > 2) {
          this.getCorporateAccounts(value);
        }
      }, (err: Error) => {
        console.log(err);
      });
  }

  public getCorporateAccounts(value) {
    const params = {
      value: value
    };
    this.jbhGlobals.apiService
      .getData(this.jbhGlobals.endpoints.commitments.getcorpacctypeahead, params, false)
      .subscribe(data => {
        this.corpAcctDataSource = data;
      });
  }
  onStartChanged(ev, sch) {

  }

  initSchedule() {
    if (this.modifyForm != null &&
      this.modifyForm.controls['businessUnit'].value === 'JBI') {
      return this.formBuilder.group({
        scheduleType: ['Weekly', Validators.required],
        totalAmount: ['0', Validators.required],
        sunAmount: ['0', Validators.required],
        monAmount: ['0', Validators.required],
        tueAmount: ['0', Validators.required],
        wedAmount: ['0', Validators.required],
        thuAmount: ['0', Validators.required],
        friAmount: ['0', Validators.required],
        satAmount: ['0', Validators.required],
        effectiveDate: ['', Validators.required],
        endDate: ['', Validators.required],
        pricingIdentifier: ['']
      });
    } else {
      return this.formBuilder.group({
        scheduleType: ['Daily', Validators.required],
        sunAmount: ['0', Validators.required],
        monAmount: ['0', Validators.required],
        tueAmount: ['0', Validators.required],
        wedAmount: ['0', Validators.required],
        thuAmount: ['0', Validators.required],
        friAmount: ['0', Validators.required],
        satAmount: ['0', Validators.required],
        totalAmount: ['0', Validators.required],
        effectiveDate: ['', Validators.required],
        endDate: ['', Validators.required],
        pricingIdentifier: ['']
      });
    }
  }

  addSchedule() {
    // add address to the list
    const control = <FormArray>this.modifyForm.controls['schedules'];
    control.push(this.initSchedule());
  }

  // convenience function
  parseInt = (num) => parseInt(num, 10);

  // Method to allow only numbers
  _keyPress(event: any) {
    const pattern = /[0-9+]/;
    const inputChar = String.fromCharCode(event.charCode);

    if (!pattern.test(inputChar)) {
      event.preventDefault();
    }
  }

  populateForm() {
    /*var dummy = {
      corporateAccount: "Test",
      lineOfBusiness: "ABC",
      billToAccount: "",
      businessUnit: "",
      serviceOffering: "",
      originMarketingArea: "",
      destinationMarketingArea: "",
      shipperLocation: ""
    };
    this.modifyForm.setValue(dummy, {onlySelf: false});*/
  }

  public loadBusinessUnit() {
    // Get all BusinessUnits
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getbusinessunit).subscribe(data => {
      this.businessUnitList = data['_embedded']['serviceOfferingBusinessUnitTransitModeAssociations'];
    });
  }

  public loadServiceOfferingList(value) {
    // Get ServiceOffering for given business unit
    const params = { 'financeBusinessUnitCode': value, 'projection': 'viewserviceofferingbusinessunittransitmode' };
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getserviceoffering, params).subscribe(data => {
      this.serviceOfferingList = data['_embedded']['serviceOfferingBusinessUnitTransitModeAssociations'];
    });
  }

  onSubmit(modifyForm) {
    let formValid = true,
      errorMsg = '';

    const formValues = modifyForm.value;
    // console.log(formValues);

    // validate for overlapping dates
    if (_.isArray(formValues.schedules)) {
      // check if end date greater than effective date
      const schedulesLength = formValues.schedules.length;
      for (let idx = 0; idx < schedulesLength; idx++) {
        const thisSchedule = formValues.schedules[idx];
        const effDate = thisSchedule.effectiveDate.jsdate;
        const endDate = thisSchedule.endDate.jsdate;

        if (effDate >= endDate) {
          formValid = false;
          errorMsg = 'Effective date should be greater than End date.';
        }
      }
      if (schedulesLength > 1) {
        // overlapping dates check
        for (let idx1 = 0; idx1 < schedulesLength; idx1++) {
          const outerSchedule = formValues.schedules[idx1];
          const outerEffDate = outerSchedule.effectiveDate.jsdate;
          const outerEndDate = outerSchedule.endDate.jsdate;

          for (let idx2 = 0; idx2 < schedulesLength; idx2++) {
            if (idx1 === idx2) {
              continue;
            }
            const innerSchedule = formValues.schedules[idx2];
            const innerEffDate = innerSchedule.effectiveDate.jsdate;
            const innerEndDate = innerSchedule.endDate.jsdate;

            if ((outerEffDate > innerEffDate && outerEffDate < innerEndDate) ||
              (outerEndDate > innerEffDate && outerEndDate < innerEndDate)) {
              formValid = false;
              errorMsg = 'Overlapping date range found.';
            }
          }
        }
      }
    }
    if (formValid) {
      this.commitmentForm.emit(modifyForm);
    } else {
      this.notifications.error('Error', errorMsg);
    }
  }

  onCancel() {
    this.notifyCancel.emit();
  }

  public changeTypeaheadLoading(e: boolean): void {
    this.typeaheadLoading = e;
  }
  public changeTypeaheadNoResults(e: boolean): void {
    this.typeaheadNoResults = e;
  }
  public typeaheadOnSelect(e: TypeaheadMatch): void {
    console.log('Selected value: ', e.value);
  }
}
