import { Component, OnInit } from '@angular/core';
// import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
// import { Commitment } from '../model/commitment.model';
// import { Schedule } from '../model/schedule.model';
import { JBHGlobals } from '../../../app.service';

@Component({
  selector: 'app-commitments',
  templateUrl: './commitments.component.html',
  styleUrls: ['./commitments.component.scss']
})
export class CommitmentsComponent implements OnInit {
  /* Data table */
  public rows: any[] = [];
  public selectedRows = [];
  public count = 100;
  public offset = 0;
  public limit = 10;
  public pageoffset = 0;
  /* End data table */

  pageTitle = 'MODE TRANSPORTATION (EXME7)';
  commitment: any;
  commitmentArrayView: any[];

  // state variables
  filterOpen = false;
  commitmentDetailsOpen: boolean;
  commitmentFilterOpen: boolean;
  isViewCommitment: boolean;
  isMassUpdate: boolean;
  editOrMassUpdateLabel: string;
  isMultipleSelect: boolean;

  history: any[] = [];
  commitmentList: any[] = [];
  currentPage: number;
  pageSize: number;
  totalRecords: number;

  businessUnitList: string[] = [];
  serviceOfferingList: string[] = [];

  public filterTitle = 'Filter By';
  public FilterList: any[] =  [{
    'index': 1,
    'key': 'corporateAccount',
    'title': 'Corporate Account',
    'componentType': 'lsitType',
    'rootVal': ['corporateAccount'],
    'url': 'getcommitmentfilterdata'
  }, {
    'index': 2,
    'key': 'lineOfBusiness',
    'title': 'Line of Business',
    'componentType': 'lsitType',
    'rootVal': ['lineOfBusiness'],
    'url': 'getcommitmentfilterdata'
  }, {
    'index': 3,
    'key': 'billToAccount',
    'title': 'Bill To Account',
    'componentType': 'lsitType',
    'rootVal': ['billToAccount'],
    'url': 'getcommitmentfilterdata'
  }, /*{
    'index': 4,
    'key':'financeBusinessUnitCode',
    'title': 'Business Unit',
    'componentType': 'lsitType',
    'rootVal':['_embedded','serviceOfferingBusinessUnitTransitModeAssociations'],
    'url': 'getBusinessUnitServiceURL',
    'params':{}
  }, {
    'index': 5,
    'key':'serviceOfferingCode',
    'title': 'Service Offering',
    'componentType': 'lsitType',
    'rootVal':['_embedded','serviceOfferings'],
    'url': 'getServiceOfferingServiceURL',
    'params':{}
  },*/ {
    'index': 6,
    'key': 'origin',
    'title': 'Origin',
    'componentType': 'lsitType',
    'rootVal': ['origin'],
    'url': 'getcommitmentfilterdata'
  }, {
    'index': 7,
    'key': 'destination',
    'title': 'Destination',
    'componentType': 'lsitType',
    'rootVal': ['destination'],
    'url': 'getcommitmentfilterdata'
  }, {
    'index': 8,
    'key': 'shipper',
    'title': 'Shipper Location',
    'componentType': 'lsitType',
    'rootVal': ['shipperLocation'],
    'url': 'getcommitmentfilterdata'
  }, {
    'index': 9,
    'key': 'type',
    'title': 'Type',
    'componentType': 'lsitType',
    'rootVal': ['type'],
    'url': 'getcommitmentfilterdata'
  }, {
    'index': 10,
    'key': 'schedule',
    'title': 'Schedule',
    'componentType': 'lsitType',
    'rootVal': ['schedule'],
    'url': 'getcommitmentfilterdata'
  }, /*{
    'index': 11,
    'key':'dateRange',
    'title': 'Date Range',
    'componentType': 'lsitType',
    'rootVal': ['activeStatus'],
    'url': 'getcommitmentfilterdata',
    'params':{}
  },*/ {
    'index': 12,
    'key': 'status',
    'title': 'Status',
    'componentType': 'lsitType',
    'rootVal': ['status'],
    'url': 'getcommitmentfilterdata',
    'params': {}
  }, {
    'index': 13,
    'key': 'sales',
    'title': 'Sales Person',
    'componentType': 'lsitType',
    'rootVal': ['sales'],
    'url': 'getcommitmentfilterdata',
    'params': {}
  }, {
    'index': 14,
    'key': 'opTeamLeader',
    'title': 'Operations Team Leader',
    'componentType': 'lsitType',
    'rootVal': ['opTeamLeader'],
    'url': 'getcommitmentfilterdata',
    'params': {}
  }, {
    'index': 15,
    'key': 'orderOwner',
    'title': 'Order Owner',
    'componentType': 'lsitType',
    'rootVal': ['orderOwner'],
    'url': 'getcommitmentfilterdata',
    'params': {}
  }, {
    'index': 16,
    'key': 'pricingIdentifier',
    'title': 'Pricing Identifier',
    'componentType': 'lsitType',
    'rootVal': ['pricingIdentifier'],
    'url': 'getcommitmentfilterdata',
    'params': {}
  }];

  constructor(public jbhGlobals: JBHGlobals) {
    this.editOrMassUpdateLabel = 'Edit Commitment';
    this.commitmentDetailsOpen = false;
    this.commitmentFilterOpen = false;
    this.isViewCommitment = true;
    this.isMassUpdate = false;
    this.currentPage = 1;
    this.pageSize = 10;
    this.isMultipleSelect = false;
  }

  ngOnInit() {
    // to load commitment list from json
    this.loadCommitments();

    this.setUpKeyboardShortcuts();
  }

  public setUpKeyboardShortcuts() {
    this.jbhGlobals.shortkeys.getData().subscribe(data => {
      let el;
      if (data.keyCode === 'alt+1') {
        if (this.commitmentFilterOpen === true) {
          el = <HTMLElement>document.getElementById('commitmentFilter').children[0];
          el.focus();
        }
        if (this.commitmentDetailsOpen === true) {
          el = <HTMLElement>document.getElementById('toggleFilterBtn');
          el.focus();
        }
      } else if (data.keyCode === 'alt+2') {
        if (this.commitmentFilterOpen === true) {
          el = <HTMLElement>document.getElementById('toggleFilterBtn');
          el.focus();
        }
        if (this.commitmentDetailsOpen === true) {
          if (this.isViewCommitment === true) {
            el = <HTMLElement>document.getElementById('commitmentDetailsMenuBtn');
          } else {
            el = <HTMLElement>document.getElementById('closeCommitmentBtn');
          }
          el.focus();
        }
      } else if (data.keyCode === 'alt+3') {
        /*if (this.commitmentDetailsOpen === true) {
          if (this.isViewCommitment === true) {
            el = <HTMLElement>document.getElementById('viewCommitmentCancelBtn');
          } else if(this.isMassUpdate === true) {
            el = <HTMLElement>document.getElementById('massUpdateSaveBtn');
          } else {
            el = <HTMLElement>document.getElementById('editCommitmentSubmitBtn');
          }
          el.focus();
        }*/
      }
    });
  }

  public loadCommitments() {
    const params = { 'pageSize': this.pageSize, 'currentPage': this.currentPage };
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.commitments.getlist, params)
      .subscribe(data => {
        // this.commitmentList = data['commitmentList'];
        this.rows = data['commitmentList'];
        this.currentPage = data['currentPage'];
        // this.pageSize = data['pageSize'];
        this.totalRecords = data['totalRecords'];
      });
  }

  public fetchCommitmentDetails(indexArr, commitmentObjArr) {
    const params = { 'index': indexArr };
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.commitments.fetchcommitment, params)
      .subscribe(data => {
        this.commitment = data;

        this.commitmentArrayView = commitmentObjArr;

        this.commitmentDetailsOpen = true;
        this.commitmentFilterOpen = false;
        this.isViewCommitment = true;
      });
  }

  createNewCommitment() {
    this.commitmentDetailsOpen = true;
    this.commitmentFilterOpen = false;
    this.isViewCommitment = false;
    this.isMassUpdate = false;
    this.selectedRows = [];
  }
  editOrMassUpdateClick() {
    if (this.selectedRows.length === 1) {
      // edit commitment component
      this.isViewCommitment = false;
    } else {
      // mass update component generation
      this.isMassUpdate = true;
    }
  }
  viewCommitment(indexArr, commitmentObjArr) {
    this.isMassUpdate = false;
    // fetch data for that commitment
    this.fetchCommitmentDetails(indexArr, commitmentObjArr);
  }
  onGridActivate(ev) {
    // console.log(ev);
  }
  onGridSelect(ev) {
    // console.log(ev);
    const selectedIndexArray = [];
    const selectedLength = ev.selected.length;
    for (let idx = 0; idx < selectedLength; idx++) {
      selectedIndexArray.push(ev.selected[idx].$$index);
    }
    this.viewCommitment(selectedIndexArray, ev.selected);

    if (ev.selected.length > 1) {
      this.editOrMassUpdateLabel = 'Mass Update Commitments';
      this.isMultipleSelect = true;
    } else {
      this.editOrMassUpdateLabel = 'Edit Commitments';
      this.isMultipleSelect = false;
    }
    /*if(ev.selected.length === 0) {
      this.selectedRows = [];
      this.commitmentDetailsOpen = false;

      this.isViewCommitment = false;
    }*/
  }
  closeCommitment() {
    this.selectedRows = [];
    this.commitmentDetailsOpen = false;
  }
  saveCommitment(formData) {
    const formObj = formData.value;
    // massage data as per expected format
    const commitmentObj = {
      // commitmentID: 48 <-- Edit commitment
      nationalAccountID: formObj.corporateAccount,
      businessLineCode: formObj.lineOfBusiness,
      billToID: formObj.billToAccount,
      financeBusinessUnitCode: formObj.businessUnit,
      serviceOfferingCode: formObj.serviceOffering,
      originMarketingAreaID: formObj.originMarketingArea,
      destinationMarketingAreaID: formObj.destinationMarketingArea,
      originLocationID: formObj.shipperLocation,
      // why is this needed here
      /*effectiveTimestamp: "2016-03-25T00:00:00",
      expirationTimestamp: "2016-07-25T00:00:00",*/
      commitmentOwnership: [{
        // commitmentOwnershipID: '6'  <-- Edit commitment
        commitmentOwnerPersonID: formObj.orderOwner,
        commitmentOwnerManagerPersonID: formObj.operationsOwner,
        operationalTeamOwnerPersonID: formObj.operationsTeamLeader,
        salesPersonID: formObj.salesContact
      }],
      schedule: []
      // Edit commitment
      /*commitmentModification:[{
        commitmentModificationReasonID: {
          commitmentModificationReasonID : 1
        }
      }]*/
    };
    const schedulesLength = formObj.schedules.length;
    for (let idx = 0; idx < schedulesLength; idx++) {
      const thisSchedule = formObj.schedules[idx];
      const schObj = {
        // commitmentScheduleID: 24  <-- Edit commitment
        comScheduleTypeCode: {
          commitmentScheduleTypeCode: thisSchedule.scheduleType
        },
        effectiveTimestamp: thisSchedule.effectiveDate,
        expirationTimestamp: thisSchedule.endDate,
        commitmentschedulerequestforpricingassociation: [{
          // ScheduleRequestForPricingAssociationID: '1'  <-- Edit commitment
          requestForPricingNumber: thisSchedule.pricingIdentifier
        }],
        commitmentScheduleDetail: []
      };
      if (thisSchedule.scheduleType === 'Weekly') {
        schObj.commitmentScheduleDetail.push({
          // commitmentScheduleDetailID: 20  <-- Edit commitment
          commitmentScheduleDay: 'Total',
          commitmentOrderQuantity: thisSchedule.totalAmount
        });
      } else {
        schObj.commitmentScheduleDetail.push({
          commitmentScheduleDay: 'Sunday',
          commitmentOrderQuantity: thisSchedule.sunAmount
        });
        schObj.commitmentScheduleDetail.push({
          commitmentScheduleDay: 'Monday',
          commitmentOrderQuantity: thisSchedule.monAmount
        });
        schObj.commitmentScheduleDetail.push({
          commitmentScheduleDay: 'Tuesday',
          commitmentOrderQuantity: thisSchedule.tueAmount
        });
        schObj.commitmentScheduleDetail.push({
          commitmentScheduleDay: 'Wednesday',
          commitmentOrderQuantity: thisSchedule.wedAmount
        });
        schObj.commitmentScheduleDetail.push({
          commitmentScheduleDay: 'Thursday',
          commitmentOrderQuantity: thisSchedule.thuAmount
        });
        schObj.commitmentScheduleDetail.push({
          commitmentScheduleDay: 'Friday',
          commitmentOrderQuantity: thisSchedule.friAmount
        });
        schObj.commitmentScheduleDetail.push({
          commitmentScheduleDay: 'Saturday',
          commitmentOrderQuantity: thisSchedule.satAmount
        });
      }
      commitmentObj.schedule.push(schObj);
    }

    const data = commitmentObj;
    const url = this.jbhGlobals.endpoints.commitments.createcommitment;
    this.jbhGlobals.logger.info('Saving  Data', JSON.stringify(data));
    this.jbhGlobals.apiService.addData(url, data).subscribe(resp => {
      if (resp && resp['errors']) {
        console.log(resp['errors'][0].errorMessage);
      } else {
        // save successful
      }
    }, error => {
      console.log(error.json());
    });
  }

  toggleFilter() {
    this.commitmentFilterOpen = !this.commitmentFilterOpen;
    this.selectedRows = [];

    const filterOpen = this.commitmentFilterOpen;
    if (filterOpen === true) {
      this.commitmentDetailsOpen = false;
    }
  }

  /*filterChangeEvent(eve) {
    let checkFlag=event.target['checked'],
        checkBoxText=event.target['parentElement']['textContent'],
        url=this.jbhGlobals.endpoints.template.getElasticServiceURL,
        temp=this.FilterList[eve.num].key,
        obj={'match' :{}};

    obj.match[temp]= checkBoxText.trim();
    if(checkFlag){

    } else {

    }
    // console.log(checkFlag);
    // console.dir(obj);
  }
  filterClickReset(index) {
    let url=this.jbhGlobals.endpoints.template.getElasticServiceURL;
    // this.QueryParamDTO['query']['constant_score']['filter']['bool']['must'][index]['bool']['should']=[];
    // this.searchGridServiceCall(url, this.QueryParamDTO);
  }*/
}
