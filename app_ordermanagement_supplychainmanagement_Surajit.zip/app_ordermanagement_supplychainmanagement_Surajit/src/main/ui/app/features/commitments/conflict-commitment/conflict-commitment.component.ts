import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
// import { Schedule } from '../model/schedule.model';
// import { Commitment } from '../model/commitment.model';

@Component({
  selector: 'app-conflict-commitment',
  templateUrl: './conflict-commitment.component.html',
  styleUrls: ['./conflict-commitment.component.scss']
})
export class ConflictCommitmentComponent implements OnInit {

  @Input()
  inputObj: any;

  @Output()
  notifyCancel: EventEmitter<any> = new EventEmitter<any>();

  constructor() { }

  // convenience function
  parseInt = (num) => parseInt(num, 10);

  ngOnInit() {
    // assuming an ajax returns this object structure
    this.inputObj = {
      conflict: {
        schedules: [{
          scheduleType: 'Daily',
          effectiveDate: '11/20/2016',
          endDate: '11/20/2017',
          pricingIdentifier: '',
          aTotalAmount: 7,
          aSunAmount: 1,
          aMonAmount: 1,
          aTueAmount: 1,
          aWedAmount: 1,
          aThuAmount: 1,
          aFriAmount: 1,
          aSatAmount: 1
        }],
        operationsTeamLeader: 'Hugh, Account Representative',
        operationsOwner: 'Jackman, Account Representative',
        orderOwner: 'John, Customer Service Representative',
        salesContact: 'Snow, Customer Service Representative'
      },
      modified: {
        schedules: [],
        operationsTeamLeader: 'Hugh, Account Representative',
        operationsOwner: 'Jackman, Account Representative',
        orderOwner: 'John, Customer Service Representative',
        salesContact: 'Snow, Customer Service Representative'
      }
    };
  }

  closeModal() {
    this.notifyCancel.emit();
  }

}
