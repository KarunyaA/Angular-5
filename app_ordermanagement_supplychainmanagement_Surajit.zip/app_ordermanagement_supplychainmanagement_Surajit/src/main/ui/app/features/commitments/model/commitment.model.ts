import {Schedule} from './schedule.model';

export class Commitment {
    corporateAccount: string;
    lineOfBusiness: string;
    billToAccount: string;
    businessUnit: string;
    serviceOffering: string;
    originMarketingArea: string;
    destinationMarketingArea: string;
    shipperLocation: string;
    operationsTeamLeader: string;
    operationsTeamLeaderID: string;
    operationsTeamLeaderURL: string;
    operationsTeamLeaderTel: string;
    operationsTeamLeaderMail: string;
    operationsTeamLeaderSkype: string;
    operationsOwner: string;
    operationsOwnerID: string;
    operationsOwnerURL: string;
    operationsOwnerTel: string;
    operationsOwnerMail: string;
    operationsOwnerSkype: string;
    orderOwner: string;
    orderOwnerID: string;
    orderOwnerURL: string;
    orderOwnerTel: string;
    orderOwnerMail: string;
    orderOwnerSkype: string;
    salesContact: string;
    salesContactID: string;
    salesContactURL: string;
    salesContactTel: string;
    salesContactMail: string;
    salesContactSkype: string;
    schedules: Schedule[];
    history: any[];

    constructor(obj) {
        this.corporateAccount = obj.corporateAccount;
        this.lineOfBusiness = obj.lineOfBusiness;
        this.billToAccount = obj.billToAccount;
        this.businessUnit = obj.businessUnit;
        this.serviceOffering = obj.serviceOffering;
        this.originMarketingArea = obj.originMarketingArea;
        this.destinationMarketingArea = obj.destinationMarketingArea;
        this.shipperLocation = obj.shipperLocation;

        this.operationsTeamLeader = obj.operationsTeamLeader;
        this.operationsTeamLeaderID = obj.operationsTeamLeaderID;
        this.operationsTeamLeaderURL = obj.operationsTeamLeaderURL;
        this.operationsTeamLeaderTel = obj.operationsTeamLeaderTel;
        this.operationsTeamLeaderMail = obj.operationsTeamLeaderMail;
        this.operationsTeamLeaderSkype = obj.operationsTeamLeaderSkype;

        this.operationsOwner = obj.operationsOwner;
        this.operationsOwnerID = obj.operationsOwnerID;
        this.operationsOwnerURL = obj.operationsOwnerURL;
        this.operationsOwnerTel = obj.operationsOwnerTel;
        this.operationsOwnerMail = obj.operationsOwnerMail;
        this.operationsOwnerSkype = obj.operationsOwnerSkype;

        this.orderOwner = obj.orderOwner;
        this.orderOwnerID = obj.orderOwnerID;
        this.orderOwnerURL = obj.orderOwnerURL;
        this.orderOwnerTel = obj.orderOwnerTel;
        this.orderOwnerMail = obj.orderOwnerMail;
        this.orderOwnerSkype = obj.orderOwnerSkype;

        this.salesContact = obj.salesContact;
        this.salesContactID = obj.salesContactID;
        this.salesContactURL = obj.salesContactURL;
        this.salesContactTel = obj.salesContactTel;
        this.salesContactMail = obj.salesContactMail;
        this.salesContactSkype = obj.salesContactSkype;

        this.schedules = obj.schedules;
        this.history = obj.history;
    }
}
