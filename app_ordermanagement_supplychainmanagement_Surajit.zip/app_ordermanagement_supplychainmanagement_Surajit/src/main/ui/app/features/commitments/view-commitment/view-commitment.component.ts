import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Commitment } from '../model/commitment.model';
// import {Schedule} from '../model/schedule.model';

@Component({
  selector: 'app-view-commitment',
  templateUrl: './view-commitment.component.html',
  styleUrls: ['./view-commitment.component.scss']
})
export class ViewCommitmentsComponent implements OnInit {

    @Input()
    commitment: Commitment;

    // this is used for multiple selection
    @Input()
    isMultiple: boolean;

    // this is used for multiple selection
    @Input()
    commitmentArrayView: any[];

    @Output()
    notifyCancel: EventEmitter<any> = new EventEmitter<any>();

    view(id) {
        alert(id);
    }
    onCancel() {
        this.notifyCancel.emit();
    }
    ngOnInit(): void {

    }
}
