import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BsDropdownModule, AccordionModule, TypeaheadModule, PopoverModule, ModalModule } from 'ngx-bootstrap';
import { MyDatePickerModule } from 'mydatepicker';
import { JBHDataTableModule } from '../../shared/jbh-data-table/jbh-data-table.module';
import { JbhSearchFilterModule } from '../../shared/jbh-search-filter/jbh-search-filter.module';
// import { SelectModule } from 'ng2-select';
import { NguiAutoCompleteModule } from '@ngui/auto-complete';

import { CommitmentsRoutingModule } from './commitments-routing.module';
import { CommitmentsComponent } from './commitments/commitments.component';
import { ViewCommitmentsComponent } from './view-commitment/view-commitment.component';
import { EditCommitmentComponent } from './edit-commitment/edit-commitment.component';
import { ConflictCommitmentComponent } from './conflict-commitment/conflict-commitment.component';
import { UniquePipe } from './view-commitment/unique.pipe';
import { MassUpdateComponent } from './mass-update/mass-update.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    CommitmentsRoutingModule,
    BsDropdownModule.forRoot(),
    AccordionModule.forRoot(),
    TypeaheadModule.forRoot(),
    PopoverModule.forRoot(),
    ModalModule.forRoot(),
    MyDatePickerModule,
    JbhSearchFilterModule,
    JBHDataTableModule,
    NguiAutoCompleteModule
  ],
  declarations: [
    CommitmentsComponent,
    ViewCommitmentsComponent,
    EditCommitmentComponent,
    ConflictCommitmentComponent,
    UniquePipe,
    MassUpdateComponent
  ]
})
export class CommitmentsModule { }
