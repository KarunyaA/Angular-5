export class Schedule {
    scheduleType: string;
    effectiveDate: string;
    endDate: string;
    pricingIdentifier: string;

    pTotalAmount: number;
    pSunAmount: number;
    pMonAmount: number;
    pTueAmount: number;
    pWedAmount: number;
    pThuAmount: number;
    pFriAmount: number;
    pSatAmount: number;

    aTotalAmount: number;
    aSunAmount: number;
    aMonAmount: number;
    aTueAmount: number;
    aWedAmount: number;
    aThuAmount: number;
    aFriAmount: number;
    aSatAmount: number;
    info: string;

    constructor(obj) {
        this.scheduleType = obj.scheduleType;
        this.effectiveDate = obj.effectiveDate;
        this.endDate = obj.endDate;
        this.pricingIdentifier = obj.pricingIdentifier;

        this.pTotalAmount = obj.pTotalAmount;
        this.pSunAmount = obj.pSunAmount;
        this.pMonAmount = obj.pMonAmount;
        this.pTueAmount = obj.pTueAmount;
        this.pWedAmount = obj.pWedAmount;
        this.pThuAmount = obj.pThuAmount;
        this.pFriAmount = obj.pFriAmount;
        this.pSatAmount = obj.pSatAmount;

        this.aTotalAmount = obj.aTotalAmount;
        this.aSunAmount = obj.aSunAmount;
        this.aMonAmount = obj.aMonAmount;
        this.aTueAmount = obj.aTueAmount;
        this.aWedAmount = obj.aWedAmount;
        this.aThuAmount = obj.aThuAmount;
        this.aFriAmount = obj.aFriAmount;
        this.aSatAmount = obj.aSatAmount;

        this.info = obj.info;
    }
}
