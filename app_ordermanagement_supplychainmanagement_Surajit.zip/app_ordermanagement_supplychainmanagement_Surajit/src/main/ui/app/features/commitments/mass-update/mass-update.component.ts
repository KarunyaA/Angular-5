import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { JBHGlobals } from '../../../app.service';

@Component({
  selector: 'app-mass-update',
  templateUrl: './mass-update.component.html',
  styleUrls: ['./mass-update.component.scss']
})
export class MassUpdateComponent implements OnInit {

  modifyForm: FormGroup;

  businessUnitList: string[] = [];
  serviceOfferingList: string[] = [];

  reasonCodes: any[];

  constructor(public formBuilder: FormBuilder,
    public jbhGlobals: JBHGlobals) { }

  ngOnInit() {
    this.loadBusinessUnit();
    this.loadReasonCodes();

    this.modifyForm = this.formBuilder.group({
      corporateAccount: [''],
      lineOfBusiness: [''],
      billToAccount: [''],
      businessUnit: ['', Validators.required],
      serviceOffering: ['', Validators.required],
      originMarketingArea: ['', Validators.required],
      destinationMarketingArea: [''],
      shipperLocation: [''],
      operationsTeamLeader: ['', Validators.required],
      operationsOwner: ['', Validators.required],
      orderOwner: ['', Validators.required],
      salesContact: ['', Validators.required],
      reasonCode: ['', Validators.required]
    });

    /*this.modifyForm.valueChanges.subscribe(data => {
      console.log('Form changes', data)
    });*/
  }

  public loadReasonCodes() {
    const params = { 'pageSize': 10 };
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.commitments.getreasoncodes, params)
      .subscribe(data => {
        this.reasonCodes = data['modificationreasons'];
      });
  }

  public loadBusinessUnit() {
    // Get all BusinessUnits
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getbusinessunit).subscribe(data => {
      this.businessUnitList = data['_embedded']['serviceOfferingBusinessUnitTransitModeAssociations'];
    });
  }

  public loadServiceOfferingList(value) {
    // Get ServiceOffering for given business unit
    const params = { 'financeBusinessUnitCode': value, 'projection': 'viewserviceofferingbusinessunittransitmode' };
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getserviceoffering, params).subscribe(data => {
      this.serviceOfferingList = data['_embedded']['serviceOfferingBusinessUnitTransitModeAssociations'];
    });
  }

  clearField(field) {
    this.modifyForm.controls[field].setValue('');
  }

}
