import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConflictCommitmentComponent } from './conflict-commitment.component';

describe('ConflictCommitmentComponent', () => {
  let component: ConflictCommitmentComponent;
  let fixture: ComponentFixture<ConflictCommitmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ConflictCommitmentComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConflictCommitmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
