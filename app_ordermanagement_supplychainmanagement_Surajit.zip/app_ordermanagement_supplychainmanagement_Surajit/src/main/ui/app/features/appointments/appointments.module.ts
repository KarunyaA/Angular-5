import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AppointmentsRoutingModule } from './appointments-routing.module';
import { UnscheduledAppointmentsComponent } from './unscheduled-appointments/unscheduled-appointments.component';
import { StopsUnscheduledAppointmentsComponent } from './stops-unscheduled-appointments/stops-unscheduled-appointments.component';

@NgModule({
  imports: [
    CommonModule,
    AppointmentsRoutingModule
  ],
  declarations: [UnscheduledAppointmentsComponent, StopsUnscheduledAppointmentsComponent]
})
export class AppointmentsModule { }
