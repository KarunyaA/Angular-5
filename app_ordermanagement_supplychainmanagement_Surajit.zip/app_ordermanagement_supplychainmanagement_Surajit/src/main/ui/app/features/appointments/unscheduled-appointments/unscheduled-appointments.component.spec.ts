import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UnscheduledAppointmentsComponent } from './unscheduled-appointments.component';

describe('UnscheduledAppointmentsComponent', () => {
  let component: UnscheduledAppointmentsComponent;
  let fixture: ComponentFixture<UnscheduledAppointmentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UnscheduledAppointmentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UnscheduledAppointmentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
