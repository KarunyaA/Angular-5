import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stops-unscheduled-appointments',
  templateUrl: './stops-unscheduled-appointments.component.html',
  styleUrls: ['./stops-unscheduled-appointments.component.scss']
})
export class StopsUnscheduledAppointmentsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
