import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-unscheduled-appointments',
  templateUrl: './unscheduled-appointments.component.html',
  styleUrls: ['./unscheduled-appointments.component.scss']
})
export class UnscheduledAppointmentsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
