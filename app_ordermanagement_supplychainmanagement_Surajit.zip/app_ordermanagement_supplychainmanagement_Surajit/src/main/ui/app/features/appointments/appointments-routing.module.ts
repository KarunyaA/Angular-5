import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UnscheduledAppointmentsComponent } from './unscheduled-appointments/unscheduled-appointments.component';
import { StopsUnscheduledAppointmentsComponent } from './stops-unscheduled-appointments/stops-unscheduled-appointments.component';

const routes: Routes = [{
  path: 'unscheduledappointments',
  component: UnscheduledAppointmentsComponent // Rules List Component
}, {
  path: 'stopsunscheduledappointments',
  component: StopsUnscheduledAppointmentsComponent
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AppointmentsRoutingModule { }
