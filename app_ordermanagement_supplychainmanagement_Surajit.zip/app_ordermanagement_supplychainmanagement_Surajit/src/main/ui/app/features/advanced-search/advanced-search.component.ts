import { Http, Response } from '@angular/http';
import { Injectable, Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-advanced-search',
    templateUrl: './advanced-search.component.html',
    styleUrls: ['./advanced-search.component.scss']
})
export class AdvancedSearchComponent implements OnInit {
    rows = [];
    selected = [];
    count = 0;
    offset = 0;
    limit = 10;

    columns = [{
            name: '',
            maxWidth: '30',
            sortable: 'false',
            canAutoResize: 'false',
            draggable: 'false',
            resizeable: 'false',
            headerCheckboxable: 'true',
            checkboxable: 'true'
        },
        {
            name: 'country',
            prop: 'country'
        },
        {
            name: 'State',
            prop: 'name',
        },
        {
            name: 'State Code',
            prop: 'abbr'
        },
        {
            name: 'area',
            prop: 'area',
        },
        {
            name: 'Largest City',
            prop: 'largest_city'
        },
        {
            name: 'capital',
            prop: 'capital'
        }

    ];

    typeAheadColumns = [{
            name: 'State',
            prop: 'name'
        },
        {
            name: 'Largest City',
            prop: 'largest_city'
        }
    ];

    filterColumns = [{
            name: 'Country',
            prop: 'country'
        },
        {
            name: 'Largest City',
            prop: 'largest_city'
        }
    ];

    accountLookupService = 'http://services.groupkt.com/state/search/US?text=';
    accountSearchService = 'http://services.groupkt.com/state/search/US?text=';


    ngOnInit() {
        this.page(this.offset, this.limit);
    }

    fetch(cb) {
        const req = new XMLHttpRequest();
        req.open('GET', `http://services.groupkt.com/state/search/US?text=`);

        req.onload = () => {
            cb(JSON.parse(req.response));
        };

        req.send();
    }

    page(offset, limit) {
        this.fetch((results) => {

            this.count = results.RestResponse.result.length;

            const start = offset * limit;
            const end = start + limit;
            const rows = [...this.rows];

            for (let i = start; i < end; i++) {
                rows[i] = results.RestResponse.result[i];
            }

            this.rows = rows;
            console.log('Page Results', start, end, rows);
        });
    }

    onPage(event) {
        console.log('Page Event', event);
        this.page(event.offset, event.limit);
    }

    onSelect({
        selected
    }) {
        console.log('Select Event', selected, this.selected);
    }

    onActivate(event) {
        console.log('Activate Event', event);
    }

    updateRowPosition() {
        const ix = this.getSelectedIx();
        const arr = [...this.rows];
        arr[ix - 1] = this.rows[ix];
        arr[ix] = this.rows[ix - 1];
        this.rows = arr;
    }

    getSelectedIx() {
        return this.selected[0]['$$index'];
    }
}

