import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdvancedSearchRoutingModule } from './advanced-search-routing.module';
import { JBHDataTableModule } from 'app/shared/jbh-data-table/jbh-data-table.module';

import { AdvancedSearchComponent } from './advanced-search.component';

@NgModule({
  imports: [
    CommonModule,
    JBHDataTableModule,
    AdvancedSearchRoutingModule
  ],
  declarations: [AdvancedSearchComponent]
})
export class AdvancedSearchModule { }
