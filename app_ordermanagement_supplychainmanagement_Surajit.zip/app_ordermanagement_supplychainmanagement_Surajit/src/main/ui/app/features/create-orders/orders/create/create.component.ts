import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';

import { JBHGlobals } from './../../../../app.service';
import { OrderService } from './../order.service';
import { OrderFormBuilder } from '../order-form-builder.service';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.scss']
})

/*
  CreateComponent - is a form contains list of child components like account information, operation information, service offering
                     and shipment information.
                  - On form submit navigates to add stop with OrderDto data.
*/
export class CreateComponent implements OnInit {
  @ViewChild('accountinformation') accountinformation;
  @ViewChild('serviceoffering') serviceoffering;

  public sub: any;
  errorMessage: string;
  subscription: any;
  orderData: any;

  constructor(public orderFormBuilder: OrderFormBuilder,
    public route: ActivatedRoute,
    public jbhGlobals: JBHGlobals,
    public orderService: OrderService,
    public router: Router) {
  }

  ngOnInit() {
    this.loadOrderData();
    this.setUpKeyboardShortcuts();
  }

  public setUpKeyboardShortcuts() {
    this.jbhGlobals.shortkeys.getData().subscribe(data => {
      if (data.keyCode === 'alt+1') {
        this.accountinformation.billingDetailsRadio.nativeElement.focus();
      } else if (data.keyCode === 'alt+2') {
        this.serviceoffering.businessunit.nativeElement.focus();
      }
    });
  }

  public loadOrderData() {
    if (this.jbhGlobals.utils.isEmpty(this.orderData)) {
      this.orderService.getData().subscribe(sharedOrderData => {
        this.orderData = sharedOrderData;
      });
    }
  }

  public onSubmit(): void {
    this.jbhGlobals.logger.info('Form submit value');
    this.orderService.saveOrder().subscribe((response: any) => {
      this.jbhGlobals.logger.info('Submit Response');
      this.jbhGlobals.notifications.success('Order', 'Order Data Saved.');
      this.router.navigateByUrl('/create-orders/order/add-stops?id=' + this.orderData.orderID);
    }
    );
  }
}
