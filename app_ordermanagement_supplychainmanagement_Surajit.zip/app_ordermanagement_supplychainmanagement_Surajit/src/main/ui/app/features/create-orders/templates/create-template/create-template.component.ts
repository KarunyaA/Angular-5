import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { JBHGlobals } from './../../../../app.service';
import { OrderService } from './../../orders/order.service';
@Component({
  selector: 'app-create-template',
  templateUrl: './create-template.component.html',
  styleUrls: ['./create-template.component.scss']
})
export class CreateTemplateComponent implements OnInit {
    public sub: any;
    errorMessage: string;
    subscription: any;
    orderData: any;
    public dtaJson: any;
    public decData: any;
    constructor(public route: ActivatedRoute,
        public jbhGlobals: JBHGlobals,
        public orderService: OrderService,
        public router: Router) {}
    ngOnInit() {
        this.loadOrderData();
    }
    public loadOrderData() {
        if (this.jbhGlobals.utils.isEmpty(this.orderData)) {
            this.orderService.getData().subscribe(sharedOrderData => {
                this.orderData = sharedOrderData;
            });
        }
    }
    public onSubmit(): void {

        if (this.orderData.businessUnit && this.orderData.serviceOfferingCode &&
            this.orderData.customerID && this.orderData.orderBillingDetailDTOs != null &&
            (this.orderData.orderBillingDetailDTOs[0].lineOfBusinessCode ||
                this.orderData.orderBillingDetailDTOs[0].billingPartyCode) &&
            this.orderData.stopDTOs && this.orderData.stopDTOs[0].stop.locationID &&
            this.orderData.stopDTOs[this.orderData.stopDTOs.length - 1].stop.locationID) {

            const params = {
                'customerID': this.orderData.customerID,
                'lineOfBusiness': this.orderData.orderBillingDetailDTOs[0].lineOfBusinessCode,
                'billingPartyCode': this.orderData.orderBillingDetailDTOs[0].billingPartyCode,
                'businessUnit': this.orderData.businessUnit,
                'serviceOffering': this.orderData.serviceOfferingCode,
                'originMarketingArea': 'LOWEL',
                'destinationMarketingArea': 'USA',
                'originSiteCode': this.orderData.stopDTOs[0].stop.locationID,
                'destinationSiteCode': this.orderData.stopDTOs[this.orderData.stopDTOs.length - 1].stop.locationID
            };
            console.log(params);
        }

        this.dtaJson = {
            'glossary': {
                'pwd': 'password'
            }
        };

        const encodedStr = btoa(JSON.stringify(this.dtaJson));
        console.log(encodedStr);
        const actualStr = JSON.parse(atob(encodedStr));
        console.log(actualStr);

        this.router.navigateByUrl('/createorders/template/addstops');
        this.saveCall();
    }

    saveCall() {
        this.orderService.saveTemplate();
    }
}
