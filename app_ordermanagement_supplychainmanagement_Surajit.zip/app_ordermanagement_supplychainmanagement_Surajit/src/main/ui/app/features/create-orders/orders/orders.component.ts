import { Component } from '@angular/core';

import { JBHGlobals } from './../../../app.service';
import { OrderService } from './order.service';

@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.scss']
})
export class OrdersComponent {
  subscription: any;
  orderData: any;
  showOverlay = true;

  constructor(
    public jbhGlobals: JBHGlobals,
    public orderService: OrderService
  ) {

    this.orderService.getData().subscribe(sharedOrderData => {
      this.orderData = sharedOrderData;
    });

    this.jbhGlobals.commonDataService.getData().subscribe(data => {
      if (data) {
        this.showOverlay = data.headerOverlay;
      }
    });

  }

}
