import { Component, OnInit, ViewChildren, QueryList } from '@angular/core';
import { JBHGlobals } from '../../../../../app.service';
import { OrderService } from '../../order.service';
import { OrderFormBuilder } from '../../order-form-builder.service';
import { HandlingUnitsComponent } from '../handling-units/handling-units.component';

@Component({
  selector: 'app-stop-handling',
  templateUrl: './stop-handling.component.html' ,
  styleUrls: ['./stop-handling.component.scss']
})
export class StopHandlingComponent implements OnInit {
    public getHandlingData: any;
    public handlingForm: any;
    public orderData: any;
    public stopCheck: any;
    public enableDiv = true;
    @ViewChildren(HandlingUnitsComponent) handlingComponent: QueryList<HandlingUnitsComponent>;

  constructor(public jbhGlobals: JBHGlobals,
              public orderService: OrderService,
              public orderFormBuilder: OrderFormBuilder) {}

   ngOnInit() {
      this.handlingForm =  this.orderFormBuilder.addHandlingUnit();
      this.loadOrderData();
      if (this.orderData.stopDTOs && this.orderData.stopDTOs.stop) {
        this.stopCheck = this.orderData.stopDTOs.stop.stopID;
      }
      if (this.stopCheck) {
        this.enableDiv = true;
      }
  }

   public loadOrderData() {
       this.orderService.getData().subscribe( sharedOrderData => {
             if (!this.jbhGlobals.utils.isEmpty(sharedOrderData)) {
                    this.orderData = sharedOrderData;
                 }
       });
      }

    public onClickofRemoveHandlingUnit(i: number) {
        const stopId = this.orderData.stopDTOs.stop.stopID;
        const handlingArray = this.orderData.stopDTOs.itemHandlingDetailDTOs;
        const handlingUnitId = handlingArray[i].itemHandlingDetail.itemHandlingDetailID;
        if (stopId && handlingUnitId) {
                this.jbhGlobals.notifications.alert('Warning', 'All the associated data will get deleted');
                this.formDeleteServiceCall(stopId, handlingUnitId, handlingArray, i);
        } else {
            this.jbhGlobals.notifications.error('Error', 'Handling unit can not be deleted');
        }
    }
    public formDeleteServiceCall(stopId, handlingUnitId, handlingArray, i) {
          const url = this.jbhGlobals.endpoints.order.crudHandlingUnit + '/' + stopId + '/itemhandlingdetails/' + handlingUnitId;
          this.jbhGlobals.apiService.removeData(url).subscribe( data => {
             console.log(data);
             handlingArray.splice(i, 1);
        });
   }
   public stopHandlingFormSave() {
       this.handlingComponent.last.formSaveCall();
   }
}
