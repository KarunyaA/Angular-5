import { Component, OnInit, Input, ViewChild, ElementRef, Renderer } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { JBHGlobals } from '../../../../../app.service';
import { OrderService } from '../../order.service';
import { OrderFormBuilder } from '../../order-form-builder.service';
import { ItemHazmatComponent } from '../item-details/item-hazmat.component';

@Component({
  selector: 'app-item-details',
  templateUrl: './item-details.component.html',
  styleUrls: ['./item-details.component.scss']
})
export class ItemDetailsComponent implements OnInit {
  public itemForm: any;
  @Input() count: number;
  @Input() dataIndex: any;
  @Input() handlingIndex: any;
  public itemData: any;
  @ViewChild('transitem') transitem: any;
  @ViewChild('saveditem') saveditem: any;
  @ViewChild('pop') pop: any;
  @ViewChild('itemServiceQuantity') itemServiceQuantity: any;
  @ViewChild('itemBarCodeNumber') itemBarCodeNumber: any;
  @ViewChild('serialNumber') serialNumber: any;
  @ViewChild('itemCharacteristicsTag') itemCharacteristicsTag: any;
  @ViewChild('majorRadio') majorRadio: any;
  @ViewChild('minorRadio') minorRadio: any;
  @ViewChild('itemPopup') itemPopup: any;
  @ViewChild('itemDiv') itemDiv: any;
  @ViewChild(ItemDetailsComponent) hazmatComponent: ItemHazmatComponent;
  subscription: any;
  orderData: any;
  public serialNumberFlag: boolean;
  public itemDetailsForm: any;
  public barcodeFlag: boolean;
  public serviceFlag: boolean;
  public transItemFlag = true;
  public itemDimensionFlag = true;
  public showTransDetailIcon = false;
  public showSaveDetailIcon = false;
  public showHazmat = false;
  public showTemperature = false;
  public itemServiceList: any[] = [];
  public itemBarCodeTypeList: any[] = [];
  public itemCharacteristicsList: any[] = [];
  public itemTemperatureControlList: any[] = [];
  public itemCategoryList: any[] = [];
  public itemWeightList: any[] = [];
  public packageTypeList: any[] = [];
  public frieghtClassList: any[] = [];
  public itemLengthList: any[] = [];
  public itemDescriptionList: any[] = [];
  public transTypeaheadList: any[] = [];
  public saveItemList: any[] = [];
  public debounceValue: any;
  public onSelectTransValue = false;
  public transSearchFlag = false;
  public saveSearchFlag = false;
  public itemPopupHeading: string;
  public itemPopupButton: string;
  public itemVolume: any;
  public itemDensity: any;
  public volumeVal: any;
  public itemDescriptionNMFC: any;
  public popUpItemDescriptionNMFC: any;
  public itemdetailsForm: any;
  public stopDetails: any;
  public itemDescriptionSaved: any;
  public transEditFlag = false;
  public saveEditFlag = false;
  public popupFlag = false;
  public typeaheadFlag = true;
  public dcsFlag = false;
  public extremeLength: any;
  public icsLTLFlag = false;
  public icsLTLDirFlag = false;
  public validataDimensionFlag = false;
  public itemDenistyVal: any;
  public itemVolumeVal: any;
  public itemServiceDescription: any;
  public itemServiceCode: any;
  public itemClassificationFlag = false;
  public transPopCloseFlag = false;
  public savedPopCloseFlag = false;
  public stopID: any;
  public handlingUnitID: any;
  public modelNumberFlag = false;
  public flatbedFlag = false;
  public newModelNumberFlag: any;
  public standardServicesList: any[] = [];
  public standardServiceFlag = false;
  public emptyObj: any;
  public handlingData: any;
  public itemDescriptionObj = {
    'itemMake': '',
    'upc': '',
    'itemManufacturer': '',
    'modelNumber': '',
    'sku': '',
    'supplierSKU': '',
    'itemCategory': '',
    'itemClassification': '',
    'itemDescription': '',
    'nmfcNumber': '',
    'itemPartNumber': ''
  };
  public editItemArray = ['nmfcNumber', 'skuNumber', 'supplierSKU', 'itemMake',
    'itemModelNumber', 'itemManufacturer', 'itemCategory',
    'itemPartNumber', 'itemUniversalProductCode', 'itemClassificationCode'];
  public editItemObjArray = ['nmfcNumber', 'sku', 'supplierSKU', 'itemMake',
    'modelNumber', 'itemManufacturer', 'itemCategory',
    'itemPartNumber', 'upc', 'itemClassification'];

  constructor(public orderService: OrderService,
    public formBuilder: FormBuilder,
    public jbhGlobals: JBHGlobals,
    public orderFormBuilder: OrderFormBuilder,
    public elementRef: ElementRef,
    public renderer: Renderer) { }

  ngOnInit() {
    this.itemForm = this.orderFormBuilder.addItem();
    this.emptyObj = this.itemDescriptionObj;
    this.loadOrderData();
    this.itemData = this.orderData.stopDTOs.itemHandlingDetailDTOs[this.handlingIndex].stopItemDTOs;
    this.handlingData = this.orderData.stopDTOs.itemHandlingDetailDTOs[this.handlingIndex];
    this.debounceValue = this.jbhGlobals.settings.debounce;
    this.loadItemCharacteristics();
    this.loadTemperatureControl();
    this.loadCategory();
    this.loaditemWeight();
    this.loadPackageType();
    this.loadFreigthClass();
    this.loadUnitofLength();
    this.loadExtremeLength();
    this.onItemTypeChange('transactionalItem');
    this.itemPopup['onHidden'].subscribe((selectedTranDesc) => {
      this.onPopupOutsideClose();
    });
    if (this.icsLTLFlag || this.dcsFlag) {
      this.transItemFlag = false;
    } else {
      this.transItemFlag = true;
    }
    if (this.stopID && this.handlingUnitID && this.itemData[this.dataIndex].stopItem.stopItemID) {
      const itemDataPopulation = this.itemData[this.dataIndex].stopItem;
      this.populateItem(itemDataPopulation);
    }
    if (!this.itemData[this.dataIndex].stopItem.stopItemID) {
      this.itemForm['controls']['unitOfLengthMeasurementCode'].setValue('Inches');
      this.itemForm['controls']['unitOfWeightMeasurementCode'].setValue('Pounds');
      this.itemData[this.dataIndex].stopItem.unitOfLengthMeasurementCode = 'Inches';
      this.itemData[this.dataIndex].stopItem.unitOfWeightMeasurementCode = 'Pounds';
    }
    /*Transactional typeahead dropdown */
    this.itemForm['controls']['itemDescription']['valueChanges']
      .debounceTime(this.debounceValue)
      .distinctUntilChanged()
      .subscribe((selectedTranDesc) => {
        if (selectedTranDesc.length < 1) {
          this.transSearchFlag = false;
          this.saveSearchFlag = false;
          this.showTransDetailIcon = false;
          this.showSaveDetailIcon = false;
          this.onSelectTransValue = false;
        }
        if (selectedTranDesc !== undefined && selectedTranDesc.length > 2) {
          if (!this.onSelectTransValue) {
            this.typeaheadFlag = false;
            if (this.transitem.nativeElement.checked === true) {
              this.loadTransType(selectedTranDesc);
            } else {
              this.loadSavedItem(selectedTranDesc);
            }
          }
        } else {
          this.itemForm['controls']['freightClassCode'].setValue('');
        }
        this.itemComponentFocus();
      }, (err: Error) => {
        console.log(err);
      });
    this.itemForm['controls']['popupItemDescription']['valueChanges']
      .debounceTime(this.debounceValue)
      .distinctUntilChanged()
      .subscribe((selectedValue) => {
        if (selectedValue !== undefined && selectedValue.length > 2) {
          if (this.itemPopupHeading === 'Transactional Item') {
            this.loadTransType(selectedValue);
          } else {
            this.loadSavedItem(selectedValue);
          }
        }
        if (selectedValue.length < 1) {
          if (this.itemPopupHeading === 'Transactional Item') {
            this.itemForm['controls']['nmfcNumber'].setValue('');
          } else {
            this.dataPopulation(this.itemForm['controls'], this.itemDescriptionObj);
          }
        }
      }, (err: Error) => {
        console.log(err);
      });
    this.itemForm['controls']['nmfcNumber']['valueChanges']
      .debounceTime(this.debounceValue)
      .distinctUntilChanged()
      .subscribe((selectedValue) => {
        if (selectedValue !== undefined && selectedValue !== '' && selectedValue !== null) {
          if (selectedValue.length > 2) {
            if (this.itemPopupHeading === 'Transactional Item') {
              this.loadTransType(selectedValue);
            }
          }
        }
      }, (err: Error) => {
        console.log(err);
      });
    this.itemForm['controls']['itemLength']['valueChanges']
      .debounceTime(this.debounceValue)
      .distinctUntilChanged()
      .subscribe((itemlength) => {
        if (itemlength.length > 0) {
          this.itemData[this.dataIndex].stopItem.itemLength = itemlength;
          this.calculateVolume();
          this.calculateDensity();
          this.checkExtremeLength();
        } else {
          this.itemData[this.dataIndex].stopItem.itemLength = '';
          this.setMeasurementEmpty();
        }
        this.itemComponentFocus();
      }, (err: Error) => {
        console.log(err);
      });
    this.itemForm['controls']['itemWidth']['valueChanges']
      .debounceTime(this.debounceValue)
      .distinctUntilChanged()
      .subscribe((width) => {
        if (width.length > 0) {
          this.itemData[this.dataIndex].stopItem.itemWidth = width;
          this.calculateVolume();
          this.calculateDensity();
        } else {
          this.itemData[this.dataIndex].stopItem.itemWidth = '';
          this.setMeasurementEmpty();
        }
        this.itemComponentFocus();
      }, (err: Error) => {
        console.log(err);
      });
    this.itemForm['controls']['itemHeight']['valueChanges']
      .debounceTime(this.debounceValue)
      .distinctUntilChanged()
      .subscribe((height) => {
        if (height.length > 0) {
          this.itemData[this.dataIndex].stopItem.itemHeight = height;
          this.calculateVolume();
          this.calculateDensity();
        } else {
          this.itemData[this.dataIndex].stopItem.itemHeight = '';
          this.setMeasurementEmpty();
        }
        this.itemComponentFocus();
      }, (err: Error) => {
        console.log(err);
      });
    this.itemForm['controls']['unitOfLengthMeasurementCode']['valueChanges']
      .debounceTime(this.debounceValue)
      .distinctUntilChanged()
      .subscribe((unit) => {
        if (unit.length > 0) {
          this.itemData[this.dataIndex].stopItem.unitOfLengthMeasurementCode = unit;
          this.calculateVolume();
          this.calculateDensity();
          this.checkExtremeLength();
        } else {
          this.itemData[this.dataIndex].stopItem.unitOfLengthMeasurementCode = '';
          this.setMeasurementEmpty();
        }
        this.itemComponentFocus();
      }, (err: Error) => {
        console.log(err);
      });
    this.itemForm['controls']['itemWeight']['valueChanges']
      .debounceTime(this.debounceValue)
      .distinctUntilChanged()
      .subscribe((weight) => {
        if (weight.length > 0) {
          this.itemData[this.dataIndex].stopItem.itemWeight = weight;
          if (this.itemDimensionFlag) {
            this.calculateVolume();
            this.calculateDensity();
          }
          this.calculateVolumeConversion();
        } else {
          this.itemData[this.dataIndex].stopItem.itemWeight = '';
          this.itemData[this.dataIndex].stopItem.unitOfWeightMeasurementCode = '';
          this.itemForm['controls']['unitOfWeightMeasurementCode'].setValue('');
          this.setDensityEmpty();
          this.itemDensity = '';
        }
        this.itemComponentFocus();
      }, (err: Error) => {
        console.log(err);
      });
    this.itemForm['controls']['unitOfWeightMeasurementCode']['valueChanges']
      .debounceTime(this.debounceValue)
      .distinctUntilChanged()
      .subscribe((weightunit) => {
        if (weightunit.length > 0) {
          this.itemData[this.dataIndex].stopItem.unitOfWeightMeasurementCode = weightunit;
          if (this.itemDimensionFlag) {
            this.calculateVolume();
            this.calculateDensity();
          }
          this.calculateVolumeConversion();
        } else {
          this.itemData[this.dataIndex].stopItem.unitOfWeightMeasurementCode = '';
          this.setDensityEmpty();
          this.itemDensity = '';
        }
        this.itemComponentFocus();
      }, (err: Error) => {
        console.log(err);
      });
    this.itemForm['controls']['packagingUnitTypeCode']['valueChanges']
      .debounceTime(this.debounceValue)
      .distinctUntilChanged()
      .subscribe((packageUnit) => {
        if (packageUnit.length > 0) {
          this.itemData[this.dataIndex].stopItem.packagingUnitTypeCode = packageUnit;
        } else {
          this.itemData[this.dataIndex].stopItem.packagingUnitTypeCode = '';
        }
        this.itemComponentFocus();
      }, (err: Error) => {
        console.log(err);
      });
    this.itemForm['controls']['packagingUnitTypeQuantity']['valueChanges']
      .debounceTime(this.debounceValue)
      .distinctUntilChanged()
      .subscribe((value) => {
        if (!this.jbhGlobals.utils.isEmpty(value)) {
          this.itemData[this.dataIndex].stopItem.packagingUnitTypeQuantity = value;
        } else {
          this.itemData[this.dataIndex].stopItem.packagingUnitTypeQuantity = null;
        }
        this.itemComponentFocus();
      }, (err: Error) => {
        console.log(err);
      });
    this.itemForm['controls']['freightClassCode']['valueChanges']
      .debounceTime(this.debounceValue)
      .distinctUntilChanged()
      .subscribe((value) => {
        if (!this.jbhGlobals.utils.isEmpty(value)) {
          this.itemData[this.dataIndex].stopItem.freightClassCode = value;
        } else {
          this.itemData[this.dataIndex].stopItem.freightClassCode = null;
        }
        this.itemComponentFocus();
      }, (err: Error) => {
        console.log(err);
      });
    this.itemForm['controls']['itemTemperatureControlMethodCode']['valueChanges']
      .debounceTime(this.debounceValue)
      .distinctUntilChanged()
      .subscribe((value) => {
        if (value.length > 0) {
          this.itemData[this.dataIndex].stopItem.itemTemperatureControlMethodCode = value;
        } else {
          this.itemData[this.dataIndex].stopItem.itemTemperatureControlMethodCode = '';
        }
        this.itemComponentFocus();
      }, (err: Error) => {
        console.log(err);
      });
    this.itemForm['controls']['itemVolume']['valueChanges']
      .debounceTime(this.debounceValue)
      .distinctUntilChanged()
      .subscribe((itemVolume) => {
        if (itemVolume) {
          this.itemData[this.dataIndex].stopItem.itemVolume = itemVolume;
          this.itemVolumeVal = itemVolume + 'kg/m3';
          this.itemForm['controls']['itemVolume'].setValue(itemVolume);
          this.itemForm['controls']['unitOfVolumeMeasurementCode'].setValue('Cubic CM');
          this.calculateVolumeConversion();
        } else {
          this.itemVolumeVal = '';
          this.itemDenistyVal = '';
          this.itemData[this.dataIndex].stopItem.itemVolume = '';
          this.itemData[this.dataIndex].stopItem.unitOfVolumeMeasurementCode = '';
          this.itemForm['controls']['unitOfVolumeMeasurementCode'].setValue('');
          this.itemForm['controls']['itemVolume'].setValue('');
          this.setDensityEmpty();
        }
        this.itemComponentFocus();
      }, (err: Error) => {
        console.log(err);
      });
  }
  public loadOrderData() {
    if (this.jbhGlobals.utils.isEmpty(this.orderData)) {
      this.orderService.getData().subscribe(sharedOrderData => {
        this.orderData = sharedOrderData;
        if (this.orderData.stopDTOs) {
          this.stopID = this.orderData.stopDTOs.stop.stopID;
          const handlingData = this.orderData.stopDTOs.itemHandlingDetailDTOs[this.handlingIndex];
          this.handlingUnitID = handlingData.itemHandlingDetail.itemHandlingDetailID;
        }
        this.onBusinessUnitBased();
        this.volTrdCheck();
      });
    }
  }
  public onBusinessUnitBased() {
    switch (this.orderData.financeBusinessUnitCode) {
      case 'DCS':
        this.onServiceOfferingBased();
        break;
      case 'ICS':
        this.onServiceOfferingBased();
        break;
      case 'JBI':
      case 'JBT':
        break;
      default:
        break;
    }
  }

  public onServiceOfferingBased() {
    switch (this.orderData.serviceOfferingCode) {
      case 'Final Mile':
        this.dcsFlag = true;
        if (this.orderData.orderTypeCode === 'Standard') {
          this.modelNumberFlag = true;
        }
        if (this.orderData.orderTypeCode !== 'Other') {
          this.itemForm['controls']['itemModelNumber'].setValidators([Validators.required]);
          this.itemForm['controls']['itemModelNumber'].updateValueAndValidity();
          this.itemForm['controls']['itemweight'].setValidators([Validators.required]);
          this.itemForm['controls']['itemweight'].updateValueAndValidity();
        }
        break;
      case 'LTL Dir':
        this.icsLTLFlag = true;
        this.icsLTLDirFlag = true;
        this.mandateCheck();
        break;
      case 'LTL Cons':
        this.icsLTLFlag = true;
        this.mandateCheck();
        break;
      case 'Flatbed':
        this.flatbedFlag = true;
        break;
      case 'Refrigerated':
        this.mandateCheck();
        break;
      default:
        break;
    }
    this.disableSavedItem();
  }

  public disableSavedItem() {
    if (!this.dcsFlag || !this.icsLTLFlag) {
      this.saveditem.nativeElement.disabled = true;
    } else {
      this.saveditem.nativeElement.disabled = false;
    }
  }
  public mandateCheck() {
    if (this.orderData.orderRefrigeratedIndicator === 'Y') {
      this.itemForm['controls']['freightClassCode'].setValidators([]);
      this.itemForm['controls']['freightClassCode'].updateValueAndValidity();
      this.itemForm['controls']['itemWeight'].setValidators([Validators.required]);
      this.itemForm['controls']['itemWeight'].updateValueAndValidity();
    } else {
      this.itemForm['controls']['freightClassCode'].setValidators([]);
      this.itemForm['controls']['freightClassCode'].updateValueAndValidity();
      this.itemForm['controls']['itemWeight'].setValidators([Validators.required]);
      this.itemForm['controls']['itemWeight'].updateValueAndValidity();
    }
  }
  public volTrdCheck() {
    if (this.orderData.orderCarrierDetails !== null) {
      const carrrierDetails = this.orderData.orderCarrierDetails;
      for (let i = 0; i < carrrierDetails.length; i++) {
        if ((carrrierDetails[i].orderVolumeTradeShowTypeCode === 'TrdShip') ||
          (carrrierDetails[i].orderVolumeTradeShowTypeCode === 'VolShip')) {
          this.validateDimension();
          this.itemForm['controls']['itemWeight'].setValidators([Validators.required]);
          this.itemForm['controls']['itemWeight'].updateValueAndValidity();
        }
      }
    }
  }
  public onClickOfSerailNumber(event) {
    this.serialNumberFlag = true;
  }
  public onClickOfBardCode($event) {
    this.loadBarCodeType();
    this.barcodeFlag = true;
  }
  public onClickOfAdditionalService(event) {
    this.serviceFlag = true;
  }
  public itemFormSaveCall() {
    if (this.showHazmat) {
      this.hazmatComponent.getHazmatSpecficationId();
    }
    if (this.itemForm['valid'] && this.itemForm['dirty'] && this.popupFlag === false) {
      const form = this.itemData[this.dataIndex].stopItem;
      if (this.icsLTLFlag) {
        this.validateCubicCapacity(form);
      }
      const barcodeArrary = this.itemData[this.dataIndex].stopbarCode;
      this.checkNullable(form);
      form['stopItemBarcodeDetails'] = barcodeArrary;
      const itemId = this.itemData[this.dataIndex].stopItem.stopItemID,
        handlingTypeCode = this.handlingData.itemHandlingDetail.itemHandlingTypeCode,
        businessUnit = this.orderData.financeBusinessUnitCode,
        serviceOff = this.orderData.serviceOfferingCode,
        lob = (this.jbhGlobals.utils.isEmpty(this.orderData.lineOfBusinessCode)) ? 'TKLT' : this.orderData.lineOfBusinessCode;
      const params = form;
      params['itemHandlingDetail'] = {
        'itemHandlingDetailID': this.handlingUnitID,
        'itemHandlingTypeCode': handlingTypeCode
      };
      if (itemId && this.stopID && this.handlingUnitID) {
        this.itemFormUpdateServiceCall(params, this.stopID, this.handlingUnitID, handlingTypeCode, businessUnit, serviceOff, lob);
      } else if (!itemId && this.stopID && this.handlingUnitID) {
        this.itemFormSaveServiceCall(params, this.stopID, this.handlingUnitID, handlingTypeCode, businessUnit, serviceOff, lob);
      } else {

      }
    }
  }
  public checkNullable(form) {
    if (this.jbhGlobals.utils.isEmpty(form['itemLengthType'])) {
      form['itemLengthType'] = null;
    }
    if (this.jbhGlobals.utils.isEmpty(form['itemVolumeType'])) {
      form['itemVolumeType'] = null;
    }
    if (this.jbhGlobals.utils.isEmpty(form['itemStackingType'])) {
      form['itemStackingType'] = null;
    }
    if (this.jbhGlobals.utils.isEmpty(form['itemProtectionType'])) {
      form['itemProtectionType'] = null;
    }
    if (this.showHazmat === false) {
      form['stopItemHazardousMaterialDetails'] = [];
    }
  }
  public itemFormSaveServiceCall(params, stopId, handlingUnitId, handlingTypeCode, businessUnit, serviceOff, lob) {
    const saveCallUrl = this.jbhGlobals.endpoints.order.saveItemDetailServiceCall;
    const url = saveCallUrl + '/' + stopId + '/stopitems?businessUnit=' +
      businessUnit + '&serviceOffering=' + serviceOff + '&lob=' + lob;
    this.jbhGlobals.apiService.addData(url, params).subscribe(data => {
      console.log(data);
      return true;
    }, (err: Error) => {
      return false;
    });
  }
  public itemFormUpdateServiceCall(params, stopId, handlingUnitId, handlingTypeCode, businessUnit, serviceOff, lob) {
    const updateUrl = this.jbhGlobals.endpoints.order.crudHandlingUnit;
    const url = updateUrl + '/' + stopId + '/stopitems?businessUnit=' +
      businessUnit + '&serviceOffering=' + serviceOff + '&lob=' + lob;
    this.jbhGlobals.apiService.updateData(url, params).subscribe(data => {
      console.log(data);
      return true;
    }, (err: Error) => {
      return false;
    });
  }
  public loadBarCodeType() {
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getItemBarCodeType).subscribe(data => {
      this.itemBarCodeTypeList = data['_embedded']['barcodeTypes'];
    });
  }
  public loadItemCharacteristics() {
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getItemCharacteristics).subscribe(data => {
      this.itemCharacteristicsList = data;
      if (this.icsLTLFlag && this.itemCharacteristicsList.length > 0) {
        this.itemCharacteristicsList.push('Extreme Length');
      }
      const formdata = this.orderData.stopDTOs.itemHandlingDetailDTOs[this.handlingIndex].stopItemDTOs[this.dataIndex].stopItem;
      if (this.stopID && this.handlingUnitID && this.itemData[this.dataIndex].stopItem.stopItemID) {
        this.setItemCharacteristics(formdata);
      }
    }
    );
  }
  public loadTemperatureControl() {
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getItemTemperatureControl).subscribe(data => {
      this.itemTemperatureControlList = data['_embedded']['itemTemperatureControlMethods'];
    });
  }
  public loadCategory() {
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getItemCategory).subscribe(data => {
      this.itemCategoryList = data;
    });
  }
  public loaditemWeight() {
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getUnitOfWeight).subscribe(data => {
      this.itemWeightList = data['_embedded']['unitOfWeightMeasurements'];
    });
  }
  public loadPackageType() {
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getPackagingUnitType).subscribe(data => {
      this.packageTypeList = data['_embedded']['packagingUnitTypes'];
    });
  }
  public loadFreigthClass() {
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getFrieghtClass).subscribe(data => {
      this.frieghtClassList = data['_embedded']['freightClasses'];
    });
  }
  public loadUnitofLength() {
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getUnitofLength).subscribe(data => {
      this.itemLengthList = data['_embedded']['unitOfLengthMeasurements'];
    });
  }
  public loadExtremeLength() {
    const params = {
      'ParameterName': 'Extreme Length'
    };
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getExtremLength, params).subscribe(data => {
      this.extremeLength = data['parameterValue'];
      if (this.icsLTLFlag) {
        this.checkExtremeLength();
      }
    });
  }
  public loadTransType(value) {
    const url = this.jbhGlobals.endpoints.order.getTransTypeahead + '/' + value;
    this.jbhGlobals.apiService.getData(url, false).subscribe(data => {
      this.transSearchFlag = data.length < 1 ? true : false;
      this.transTypeaheadList = data;
    });
  }
  public loadSavedItem(value) {
    const url = this.jbhGlobals.endpoints.order.getSavedItem + '/' + value;
    this.jbhGlobals.apiService.getData(url, false).subscribe(data => {
      this.saveSearchFlag = data.length < 1 ? true : false;
      this.saveItemList = data;
    });
  }
  public loadItemService(value) {
    const url = this.jbhGlobals.endpoints.order.getItemServices;
    const params = {
      'modelNumber': 20185260,
      'productCategory': 'ALL',
      'tradingPartner': 'ABFS'
    };
    this.jbhGlobals.apiService.getData(url, params, false).subscribe(data => {
      this.standardServicesList = data['Standard Services'];
      this.itemServiceList = data['Additonal Services'];
      for (let i = 0; i < this.standardServicesList.length; i++) {
        const itemServiceObj = {
          stopItemServiceDetailID: '',
          itemServiceID: '',
          itemServiceTypeCode: this.standardServicesList[i].customerServiceTypeCode,
          itemServiceDescription: this.standardServicesList[i].serviceDescription,
          itemServiceQuantity: 0
        };
        this.itemData[this.dataIndex].stopItem.stopItemServiceDetails.push(itemServiceObj);
      }
      this.standardServiceFlag = false;
    });
  }
  public setMeasurementEmpty() {
    this.itemForm['controls']['itemVolume'].setValue('');
    this.itemForm['controls']['itemDensity'].setValue('');
    this.itemDensity = '';
    this.volumeVal = '';
  }
  public addSerialNumber(event) {
    const serialNumber = event.target.value;
    if (serialNumber !== '') {
      const serialObj = {
        'barCodeTypeCode': '',
        'stopItemBarCodeNumber': '',
        'stopItemSerialNumber': serialNumber,
        'stopitemSerialNumberDetailID': ''
      };
      this.serialNumberFlag = false;
      const serialArr = this.itemData[this.dataIndex].stopItem.stopItemSerialNumberDetails;
      if (this.jbhGlobals.utils.findIndex(serialArr, serialObj) === -1) {
        this.itemData[this.dataIndex].stopItem.stopItemSerialNumberDetails.push(serialObj);
        this.itemForm['controls']['serialNumber'].setValue('');
        this.itemComponentFocus();
      } else {
        this.jbhGlobals.notifications.error('Error', 'The serial number is already added');
      }
    }
  }
  public removeSerialNumber(i: number) {
    this.itemData[this.dataIndex].stopItem.stopItemSerialNumberDetails.splice(i, 1);
    this.itemComponentFocus();
  }
  public onSelectOfItemService(itemdesc, quantity, event?: any) {
    let itemServiceObj: any;
    if (event) {
      this.itemServiceCode = (event.item.customerServiceTypeCode) ? event.item.customerServiceTypeCode : '';
      this.itemServiceDescription = (event.item.serviceDescription) ? event.item.serviceDescription : '';
      this.itemForm['controls']['itemService'].setValue(this.itemServiceCode + ' ' + this.itemServiceDescription);
    }
    if (itemdesc.value !== '' && quantity.value !== '') {
      itemServiceObj = {
        stopItemServiceDetailID: '',
        itemServiceID: '',
        itemServiceTypeCode: this.itemServiceCode,
        itemServiceDescription: this.itemServiceDescription,
        itemServiceQuantity: quantity.value
      };
        const serviceArray = this.itemData[this.dataIndex].stopItem.stopItemServiceDetails;
      if (this.jbhGlobals.utils.findIndex(serviceArray, itemServiceObj) === -1) {
        this.itemData[this.dataIndex].stopItem.stopItemServiceDetails.push(itemServiceObj);
        this.itemComponentFocus();
      } else {
        this.jbhGlobals.notifications.error('Error', 'The service is already added');
      }
      this.serviceFlag = false;
      itemdesc.value = '';
      this.itemForm['controls']['itemService'].setValue('');
      quantity.value = '';
      this.itemServiceCode = '';
      this.itemServiceDescription = '';
    }
    this.standardServiceFlag = true;
  }
  public removeItemService(x: number) {
    const serviceArray = this.itemData[this.dataIndex].stopItem.stopItemServiceDetails;
    serviceArray.splice(x, 1);
    this.itemComponentFocus();
  }
  public barCodeTransform(items: any[], args: string): any {
    /* filter items array, items which match and return true will be kept, false will be filtered out */
    return items.filter(item => item.barcodeTypeDescription.toLowerCase().indexOf(args.toLowerCase()) !== -1);
  }
  public onBarCodeSelect(barcodeType, qunatity) {
    let itemBarCodeObj: any;
    const itemBarCodeType = this.itemForm.controls['itemBarCodeType'];
    const barcodeSelectObj = (itemBarCodeType.value !== '') ?
       this.barCodeTransform(this.itemBarCodeTypeList, itemBarCodeType.value)[0] : '';
    const itemBarCodeNumber = (this.itemBarCodeNumber.nativeElement.value) ? this.itemBarCodeNumber.nativeElement.value : '';
    if (itemBarCodeType.value !== '' && itemBarCodeNumber !== '' && !this.jbhGlobals.utils.isEmpty(barcodeSelectObj)) {
      const itemBarCodeArray = this.itemData[this.dataIndex].stopbarCode;
      itemBarCodeObj = {
        stopItemBarcodeDetail: {
          stopItemBarcodeDetailID: '',
          barcodeTypeCode: barcodeSelectObj.barcodeTypeCode,
          stopItemBarcodeNumber: itemBarCodeNumber
        },
        barcodeTypeDescription: barcodeSelectObj.barcodeTypeDescription
      };
      this.barcodeFlag = false;
      if (this.jbhGlobals.utils.findIndex(itemBarCodeArray, itemBarCodeObj) === -1) {
        this.itemData[this.dataIndex].stopbarCode.push(itemBarCodeObj);
        this.itemBarCodeNumber.nativeElement.value = '';
        this.itemForm.controls['itemBarCodeType'].setValue('');
        this.itemForm.controls['itemBarCodeNumber'].setValue('');
        this.itemComponentFocus();
      } else {
        this.jbhGlobals.notifications.error('Error', 'The bar code is already added');
      }
      this.barcodeFlag = false;
    } else {
      this.jbhGlobals.notifications.error('Error', 'Please enter both barcode Type and Quantity');
    }
  }
  public removeBarCode(y: number) {
    const barCodeArray = this.itemData[this.dataIndex].stopbarCode;
    barCodeArray.splice(y, 1);
    this.itemComponentFocus();
  }
  public onDimensionChange(value) {
    if (value === 'itemDimension') {
      this.itemForm.controls['itemVolume'].setValue('');
      this.itemData[this.dataIndex].stopItem.itemVolume = '';
      this.itemData[this.dataIndex].stopItem.unitOfVolumeMeasurementCode = '';
      this.setDensityEmpty();
      this.itemDimensionFlag = true;
    } else {
      this.itemForm.controls['itemLength'].setValue('');
      this.itemForm.controls['itemWidth'].setValue('');
      this.itemForm.controls['itemHeight'].setValue('');
      this.itemForm.controls['unitOfLengthMeasurementCode'].setValue('');
      this.itemData[this.dataIndex].stopItem.itemLength = '';
      this.itemData[this.dataIndex].stopItem.itemWidth = '';
      this.itemData[this.dataIndex].stopItem.itemHeight = '';
      this.itemData[this.dataIndex].stopItem.unitOfLengthMeasurementCode = '';
      this.setDensityEmpty();
      this.itemDimensionFlag = false;
    }
    this.validateModelNumber();
  }

  public onItemTypeChange(value) {
    this.transSearchFlag = false;
    this.saveSearchFlag = false;
    if (value === 'transactionalItem') {
      this.showTransDetailIcon = false;
      this.transItemFlag = true;
      this.itemData[this.dataIndex].stopItem.stopItemServiceDetails = [];
    } else {
      this.showSaveDetailIcon = false;
      this.transItemFlag = false;
    }
    this.itemForm.controls['freightClassCode'].setValue('');
    this.itemForm.controls['itemDescription'].setValue('');
    this.typeaheadFlag = false;
    this.onSelectTransValue = false;
  }

  public onTransValueSelected(event) {
    const transItemDesc = event.item.itemDescription ? event.item.itemDescription : '';
    const transItemNumber = event.item.nmfcNumber ? event.item.nmfcNumber : '';
    const freightClass = event.item.nmfcFreightClassification;
    if (event.item.itemDescription) {
      this.showTransDetailIcon = true;
      this.itemDescriptionNMFC = this.itemDescriptionObj;
      this.itemDescriptionNMFC['itemDescription'] = transItemDesc;
      this.itemDescriptionNMFC['nmfcNumber'] = transItemNumber;
      this.saveItemDescription(transItemDesc, freightClass, this.itemDescriptionNMFC);
    }
    this.itemForm['controls']['itemDescription'].setValue(transItemDesc + ' (' + transItemNumber + ')');
    this.itemForm['controls']['freightClassCode'].setValue(freightClass);
    this.typeaheadFlag = true;
    this.onSelectTransValue = true;
    this.transSearchFlag = false;
  }

  public onSavedItemValueSelected(event) {
    const savedItemDesc = event.item.itemDescription ? event.item.itemDescription : '';
    const savedModelNumber = event.item.modelNumber ? event.item.modelNumber : '';
    const freightClass = event.item.nmfcFreightClassification;
    if (!this.jbhGlobals.utils.isEmpty(event.item.itemDescription)) {
      this.showSaveDetailIcon = true;
      this.getSavedItemListService(event, savedItemDesc, savedModelNumber, freightClass, true);
    }
    if (savedModelNumber !== null && this.modelNumberFlag === true) {
      this.loadItemService(savedModelNumber);
    } else {
      this.standardServicesList = [];
      this.itemServiceList = [];
    }
    this.itemForm['controls']['itemDescription'].setValue(savedItemDesc + ' (' + savedModelNumber + ')');
    this.itemForm['controls']['freightClassCode'].setValue(freightClass);
    this.typeaheadFlag = true;
    this.onSelectTransValue = true;
    this.saveSearchFlag = false;
  }

  public getSavedItemListService(event, savedItemDesc, savedModelNumber, freightClass, flag) {
    const sku = (!this.jbhGlobals.utils.isEmpty(event.item.sku)) ? event.item.sku : '',
      supplierSKU = (!this.jbhGlobals.utils.isEmpty(event.item.supplierSKU)) ? event.item.supplierSKU : '',
      productCategory = (!this.jbhGlobals.utils.isEmpty(event.item.itemCategory)) ? event.item.itemCategory : '';
    savedItemDesc = (!this.jbhGlobals.utils.isEmpty(savedItemDesc)) ? savedItemDesc : '';
    savedModelNumber = (!this.jbhGlobals.utils.isEmpty(savedModelNumber)) ? savedModelNumber : '';
    const params = {
      'modelNumber': savedModelNumber,
      'sku': sku,
      'supplierSKU': supplierSKU,
      'productCategory': productCategory,
      'productDescription': savedItemDesc
    };
    const url = this.jbhGlobals.endpoints.order.getSaveItemDetails;
    this.jbhGlobals.apiService.getData(url, params, false).subscribe(data => {
      if (flag) {
        this.itemDescriptionSaved = data[0];
        this.saveItemDescription(savedItemDesc, freightClass, this.itemDescriptionSaved);
      } else {
        this.popUpItemDescriptionNMFC = data[0];
        if (this.popUpItemDescriptionNMFC) {
          this.popUpItemDescriptionNMFC['freightClass'] = freightClass;
          this.dataPopulation(this.itemForm['controls'], this.popUpItemDescriptionNMFC);
          this.itemForm['controls']['popupItemDescription'].setValue(savedItemDesc + ' (' + savedModelNumber + ')');
        }
      }
    });
  }

  public saveItemDescription(transItemDesc, freightClass, itemdesc) {
    for (let i = 0; i < this.editItemArray.length; i++) {
      const editObj = itemdesc[this.editItemObjArray[i]] ? itemdesc[this.editItemObjArray[i]] : '';
      this.itemData[this.dataIndex]['stopItem'][this.editItemArray[i]] = editObj;
    }
    this.itemData[this.dataIndex].stopItem.itemDescription = transItemDesc;
    this.itemData[this.dataIndex].stopItem.freightClassCode = freightClass;
    console.log(this.itemData[this.dataIndex].stopItem);
  }

  public onPopUpItemDescValueSelected(event) {
    const transItemDesc = event.item.itemDescription ? event.item.itemDescription : '';
    const transItemNumber = event.item.nmfcNumber ? event.item.nmfcNumber : '';
    const savedModelNumber = event.item.modelNumber;
    const freightClass = event.item.nmfcFreightClassification;
    if (event.item.itemDescription) {
      if (this.itemPopupHeading === 'Transactional Item') {
        this.itemDescriptionNMFC['freightClass'] = freightClass;
        this.itemDescriptionNMFC['nmfcNumber'] = transItemNumber;
        this.dataPopulation(this.itemForm['controls'], this.itemDescriptionNMFC);
        this.itemForm['controls']['popupItemDescription'].setValue(transItemDesc + ' (' + transItemNumber + ')');
      } else {
        this.getSavedItemListService(event, transItemDesc, savedModelNumber, freightClass, false);
      }
    }
  }

  public onNMFCSelected(event) {
    const transItemDesc = event.item.itemDescription ? event.item.itemDescription : '';
    const transItemNumber = event.item.nmfcNumber ? event.item.nmfcNumber : '';
    const freightClass = event.item.nmfcFreightClassification;
    if (event.item.itemDescription) {
      this.itemDescriptionNMFC['freightClass'] = freightClass;
      this.itemDescriptionNMFC['nmfcNumber'] = transItemNumber;
      this.dataPopulation(this.itemForm['controls'], this.itemDescriptionNMFC);
      this.itemForm['controls']['popupItemDescription'].setValue(transItemDesc + ' (' + transItemNumber + ')');
    }
    this.itemForm['controls']['nmfcNumber'].setValue((transItemNumber ? transItemNumber : ''));
  }

  public onEditItemClick(itemPopup, transItem) {
    this.pop.hide();
    itemPopup.show();
    this.popupFlag = true;
    this.itemPopupButton = 'Edit';
    this.itemForm['controls']['popupItemDescription'].setValidators([Validators.required]);
    this.itemForm['controls']['popupItemDescription'].updateValueAndValidity();
    if (transItem.name === 'editTransItem') {
      this.itemPopupHeading = 'Transactional Item';
      this.transEditFlag = true;
      this.transPopCloseFlag = false;
      this.transSearchFlag = false;
      this.dataPopulation(this.itemForm['controls'], this.itemDescriptionNMFC);
    } else {
      this.itemPopupHeading = 'Saved Item';
      this.transTypeaheadList = this.saveItemList;
      this.saveEditFlag = true;
      this.savedPopCloseFlag = false;
      this.saveSearchFlag = false;
      this.dataPopulation(this.itemForm['controls'], this.itemDescriptionSaved);
    }
  }

  public dataPopulation(form, itemDesc) {
    form['popupItemDescription'].setValue(itemDesc['itemDescription'] ? itemDesc['itemDescription'] : '');
    const len = this.editItemArray.length;
    for (let i = 0; i < len; i++) {
      const editArr = itemDesc[this.editItemObjArray[i]] ? itemDesc[this.editItemObjArray[i]] : '';
      form[this.editItemArray[i]].setValue(editArr);
    }
    if (itemDesc['itemClassification'] === 'MAJOR') {
      this.majorRadio.nativeElement.checked = true;
    }
    if (itemDesc['itemClassification'] === 'MINOR') {
      this.minorRadio.nativeElement.checked = true;
    }
    if (itemDesc['itemClassification'] === '') {
      this.majorRadio.nativeElement.checked = false;
      this.minorRadio.nativeElement.checked = false;
    }
  }

  public onEditClick(popup) {
    let itemDescObj = {};
    let validFlag = true;
    if (this.transEditFlag) {
      itemDescObj = this.itemDescriptionNMFC;
      this.transSearchFlag = false;
    } else {
      itemDescObj = this.itemDescriptionSaved;
      this.saveSearchFlag = false;
    }
    this.itemForm['controls']['itemDescription'].setValue(this.itemForm['controls']['popupItemDescription'].value);
    if (this.popUpItemDescriptionNMFC) {
      this.itemForm['controls']['freightClassCode'].setValue(this.popUpItemDescriptionNMFC.freightClass);
    }
    itemDescObj['itemDescription'] = this.itemForm['controls']['itemDescription'].value ?
     this.itemForm['controls']['itemDescription'].value : '';
    if (this.majorRadio.nativeElement.checked === true) {
      this.itemForm['controls']['itemClassificationCode'].setValue('MAJOR');
    }
    if (this.minorRadio.nativeElement.checked === true) {
      this.itemForm['controls']['itemClassificationCode'].setValue('MINOR');
    }
    for (let i = 0; i < this.editItemObjArray.length; i++) {
      if (this.itemForm['controls'][this.editItemArray[i]].valid) {
        const editArr = this.itemForm['controls'][this.editItemArray[i]].value ?
         this.itemForm['controls'][this.editItemArray[i]].value : '';
        itemDescObj[this.editItemObjArray[i]] = editArr;
      } else {
        validFlag = false;
      }
    }
    if (this.transEditFlag) {
      this.itemDescriptionNMFC = itemDescObj;
    } else {
      this.itemDescriptionSaved = itemDescObj;
    }
    const itemDesc = this.jbhGlobals.utils.split(this.itemForm['controls']['itemDescription'].value.toString(), '(')[0];
    if (validFlag && this.itemForm['controls']['itemDescription'].valid) {
      this.saveItemDescription(itemDesc, this.itemForm['controls']['freightClassCode'].value, itemDescObj);
      this.popupFlag = false;
      this.onSelectTransValue = true;
      this.itemDiv.nativeElement.focus();
      popup.hide();
      this.itemForm['controls']['popupItemDescription'].setValidators([]);
      this.itemForm['controls']['popupItemDescription'].updateValueAndValidity();
    }
    if (itemDescObj['modelNumber'] && itemDescObj['itemManufacturer']) {
      this.findModelNumber(itemDescObj['modelNumber'], itemDescObj['itemManufacturer']);
    }
  }

  public onAddNewItemClick(itemPopup, itemType) {
    itemPopup.show();
    this.itemPopupButton = 'Add';
    if (itemType.name === 'addNewTransItem') {
      this.itemPopupHeading = 'Transactional Item';
      this.transEditFlag = true;
      this.itemDescriptionNMFC = this.emptyObj;
    } else {
      this.itemPopupHeading = 'Saved Item';
      this.saveEditFlag = true;
      this.itemDescriptionSaved = this.emptyObj;
    }
    this.dataPopulation(this.itemForm['controls'], this.emptyObj);
  }

  public onCloseOfItemPopup(itemPopup) {
    itemPopup.hide();
    this.showTransDetailIcon = true;
    this.showSaveDetailIcon = true;
    if (this.itemPopupHeading === 'Transactional Item') {
      this.transPopCloseFlag = true;
    } else {
      this.savedPopCloseFlag = true;
    }
  }

  public onPopupOutsideClose() {
    if (this.itemDescriptionNMFC || this.itemDescriptionSaved) {
      let itemDescObj;
      if (this.itemPopupHeading === 'Transactional Item') {
        itemDescObj = this.itemDescriptionNMFC;
        this.transPopCloseFlag = true;
      } else {
        itemDescObj = this.itemDescriptionSaved;
        this.savedPopCloseFlag = true;
      }
      for (let i = 0; i < this.editItemArray.length; i++) {
        this.itemForm['controls'][this.editItemArray[i]].setValue(itemDescObj[this.editItemObjArray[i]]);
      }
    }
  }

  public findModelNumber(modelValue, manufacturerValue) {
    const url = this.jbhGlobals.endpoints.order.checkModelNumber;
    const params = {
      'modelNumber': modelValue,
      'manufacturer': manufacturerValue,
      'lob': 'TKLT'
    };
    this.jbhGlobals.apiService.getData(url, params, false).subscribe(data => {
      this.newModelNumberFlag = data;
      this.validateModelNumber();
    });
  }

  public validateModelNumber() {
    if (this.newModelNumberFlag) {
      this.itemForm['controls']['itemManufacturer'].setValidators([Validators.required]);
      this.itemForm['controls']['itemManufacturer'].updateValueAndValidity();
      if (this.itemDimensionFlag) {
        this.validataDimensionFlag = true;
        this.validateDimension();
      } else {
        this.validataDimensionFlag = false;
        this.validateDimension();
      }
    } else {
      this.itemForm['controls']['itemManufacturer'].setValidators([]);
      this.itemForm['controls']['itemManufacturer'].updateValueAndValidity();
      this.validataDimensionFlag = false;
      this.validateDimension();
    }
  }
  public onItemCharacteristicSelection(event, flag) {
    const itemCharacteristics = event.text;
    switch (itemCharacteristics) {
      case 'Temperature Control':
        this.showTemperature = flag;
        if (!flag) {
          this.itemData[this.dataIndex].stopItem.itemTemperatureControlMethodCode = '';
        }
        this.itemForm['controls']['itemTemperatureControlMethodCode'].setValue('');
        this.itemComponentFocus();
        break;
      case 'Hazmat':
        this.showHazmat = flag;
        if (!flag) {
          /* empty the hazmat data */
        }
        this.itemComponentFocus();
        break;
      case 'Freeze Protect':
        if (flag) {
          this.itemData[this.dataIndex].stopItem.itemProtectionType = 'Freeze';
        } else {
          this.itemData[this.dataIndex].stopItem.itemProtectionType = null;
        }
        this.itemComponentFocus();
        break;
      case 'Stackable':
        if (flag) {
          this.itemData[this.dataIndex].stopItem.itemStackingType = 'Stackable';
        } else {
          this.itemData[this.dataIndex].stopItem.itemStackingType = null;
        }
        this.itemComponentFocus();
        break;
      case 'Extreme Length':
        if (flag) {
          this.itemData[this.dataIndex].stopItem.itemLengthType = 'Extreme Length';
        } else {
          this.itemData[this.dataIndex].stopItem.itemLengthType = null;
        }
        this.checkExtremeLength();
        break;
      default:
        break;
    }
  }
  public calculateVolume() {
    const itemLength = this.itemForm.value.itemLength;
    const itemWidth = this.itemForm.value.itemWidth;
    const itemHeigth = this.itemForm.value.itemHeight;
    const itemUnit = this.itemForm.value.unitOfLengthMeasurementCode;
    if (itemLength && itemWidth && itemHeigth && !this.jbhGlobals.utils.isEmpty(itemUnit)) {
      const length = this.conversionToInches(itemLength, itemUnit);
      const width = this.conversionToInches(itemWidth, itemUnit);
      const height = this.conversionToInches(itemHeigth, itemUnit);
      const volume = (length * width * height) / (12 * 12 * 12);
      if (!isNaN(volume)) {
        this.volumeVal = volume.toFixed(4) + 'kg/m3';
      }
      this.itemForm['controls']['itemVolume'].setValue(parseFloat(volume.toFixed(4)));
      this.itemForm['controls']['unitOfVolumeMeasurementCode'].setValue('Cubic CM');
      this.itemData[this.dataIndex].stopItem.itemVolume = volume.toFixed(4);
      this.itemData[this.dataIndex].stopItem.unitOfVolumeMeasurementCode = 'Cubic CM';
    } else {
      this.itemForm['controls']['itemVolume'].setValue('');
      this.itemForm['controls']['unitOfVolumeMeasurementCode'].setValue('');
      this.itemData[this.dataIndex].stopItem.itemVolume = '';
      this.itemData[this.dataIndex].stopItem.unitOfVolumeMeasurementCode = '';
    }
  }
  public calculateDensity() {
    const itemLength = this.itemForm.value.itemLength;
    const itemWidth = this.itemForm.value.itemWidth;
    const itemHeigth = this.itemForm.value.itemHeight;
    const itemUnit = this.itemForm.value.unitOfLengthMeasurementCode;
    const itemWeight = this.itemForm.value.itemWeight;
    const itemWeightUnit = this.itemForm.value.unitOfWeightMeasurementCode;
    if (itemLength && itemWidth && itemHeigth && !this.jbhGlobals.utils.isEmpty(itemUnit) &&
      itemWeight && !this.jbhGlobals.utils.isEmpty(itemWeightUnit)) {
      const length = this.conversionToFeet(itemLength, itemUnit);
      const width = this.conversionToFeet(itemWidth, itemUnit);
      const height = this.conversionToFeet(itemHeigth, itemUnit);
      const weight = this.weightConversion(itemWeight, itemWeightUnit);
      const density = weight / (length * width * height);
      if (!isNaN(density)) {
        this.itemDensity = density.toFixed(4) + 'kg/m3';
      }
      this.itemForm['controls']['itemDensity'].setValue(parseFloat(density.toFixed(4)));
      this.itemForm['controls']['unitOfDensityMeasurementCode'].setValue('GM/CC');
      this.itemData[this.dataIndex].stopItem.itemDensity = parseFloat(density.toFixed(4));
      this.itemData[this.dataIndex].stopItem.unitOfDensityMeasurementCode = 'GM/CC';
    } else {
      this.setDensityEmpty();
      this.itemDensity = '';
    }
  }
  public conversionToInches(value, unit) {
    let measurement;
    switch (unit) {
      case 'Centimeter':
        measurement = parseFloat(value) / 2.54;
        break;
      case 'Feet':
        measurement = parseFloat(value) * 12;
        break;
      case 'Kilometers':
        measurement = parseFloat(value) * 39379.96;
        break;
      case 'Meter':
        measurement = parseFloat(value) / 0.0254;
        break;
      case 'Miles':
        measurement = parseFloat(value) * 63360;
        break;
      case 'Inches':
        measurement = parseFloat(value);
        break;
      default:
        break;
    }
    return measurement;
  }
  public conversionToFeet(value, unit) {
    switch (unit) {
      case 'Centimeter':
        value = parseFloat(value) / 30.48;
        break;
      case 'Inches':
        value = parseFloat(value) / 12;
        break;
      case 'Kilometers':
        value = parseFloat(value) * 3280.8398950131;
        break;
      case 'Meter':
        value = parseFloat(value) / 0.3048;
        break;
      case 'Miles':
        value = parseFloat(value) * 5280;
        break;
      case 'Inches':
        value = parseFloat(value);
        break;
      default:
        break;
    }
    return value;
  }
  public weightConversion(value, unit) {
    let weight;
    switch (unit) {
      case 'Grams':
        weight = parseFloat(value) / 453.59237;
        break;
      case 'Kilogram':
        weight = parseFloat(value) / 0.45359237;
        break;
      case 'Metric Tons':
        weight = parseFloat(value) / 0.00045359237;
        break;
      case 'Ounces':
        weight = parseFloat(value) / 16;
        break;
      case 'Tons':
        weight = parseFloat(value) / 0.00045359237;
        break;
      case 'Pounds':
        weight = parseFloat(value);
        break;
      default:
        break;
    }
    return weight;
  }
  public checkExtremeLength() {
    const length = this.itemForm.value.itemLength;
    const lengthUnit = this.itemForm.value.unitOfLengthMeasurementCode;
    const extremeVal = this.itemData[this.dataIndex].stopItem.itemLengthType;
    if (this.icsLTLFlag && length && !this.jbhGlobals.utils.isEmpty(lengthUnit)) {
      const itemLength = this.conversionToInches(length, lengthUnit);
      if (this.jbhGlobals.utils.isEmpty(extremeVal) && itemLength > parseFloat(this.extremeLength)) {
        this.jbhGlobals.notifications.alert('Warning', 'Length has exceeded 14inch');
        this.itemData[this.dataIndex].stopItem.itemLengthType = 'Extreme Length';
        if (this.itemCharacteristicsTag.active.indexOf({
          id: 'Extreme Length',
          text: 'Extreme Length'
        }) === -1) {
          this.itemCharacteristicsTag.active.push({
            id: 'Extreme Length',
            text: 'Extreme Length'
          });
        }
        this.validataDimensionFlag = true;
        this.validateDimension();
      } else if (!this.jbhGlobals.utils.isEmpty(extremeVal)) {
        this.validataDimensionFlag = false;
        this.validateDimension();
      }
      if (itemLength > 10.8 && itemLength < parseFloat(this.extremeLength)) {
        this.jbhGlobals.notifications.alert('Warning', 'Length has exceeded 10.8 Inches');
      }
    }
  }

  public calculateVolumeConversion() {
    const volume = this.itemForm.value.itemVolume;
    const weight = this.itemForm.value.itemWeight;
    const weightUnit = this.itemForm.value.unitOfWeightMeasurementCode;
    if (volume && weight && !this.jbhGlobals.utils.isEmpty(weightUnit)) {
      const weightConv = this.weightConversion(weight, weightUnit);
      const density = weightConv / volume * (12 * 12 * 12);
      if (!isNaN(density)) {
        this.itemDenistyVal = density.toFixed(4) + 'kg/m3';
      }
      this.itemForm['controls']['itemDensity'].setValue(parseFloat(density.toFixed(4)));
      this.itemForm['controls']['unitOfDensityMeasurementCode'].setValue('GM/CC');
      this.itemData[this.dataIndex].stopItem.itemDensity = parseFloat(density.toFixed(4));
      this.itemData[this.dataIndex].stopItem.unitOfDensityMeasurementCode = 'GM/CC';
    } else {
      this.itemDenistyVal = '';
      this.setDensityEmpty();
    }
  }

  public validateDimension() {
    const arr = ['itemLength', 'itemWidth', 'itemHeight', 'unitOfLengthMeasurementCode'];
    if (this.validataDimensionFlag) {
      for (let i = 0; i < arr.length; i++) {
        this.itemForm['controls'][arr[i]].setValidators([Validators.required]);
        this.itemForm['controls'][arr[i]].updateValueAndValidity();
      }
      this.itemForm['controls']['itemVolume'].setValidators([]);
      this.itemForm['controls']['itemVolume'].updateValueAndValidity();
    } else {
      for (let i = 0; i < arr.length; i++) {
        this.itemForm['controls'][arr[i]].setValidators([]);
        this.itemForm['controls'][arr[i]].updateValueAndValidity();
      }
      this.itemForm['controls']['itemVolume'].setValidators([Validators.required]);
      this.itemForm['controls']['itemVolume'].updateValueAndValidity();
    }
  }

  public setDensityEmpty() {
    this.itemForm['controls']['unitOfDensityMeasurementCode'].setValue('');
    this.itemForm['controls']['itemDensity'].setValue('');
    this.itemData[this.dataIndex].stopItem.unitOfDensityMeasurementCode = '';
    this.itemData[this.dataIndex].stopItem.itemDensity = '';
  }

  public onClickOfAddItem() {
    if (this.itemData[this.dataIndex].stopItem.stopItemID && this.itemForm['valid']) {
      const stopObject = {
        stopItem: this.orderFormBuilder.addItem()
      };
      this.orderData.stopDTOs.itemHandlingDetailDTOs[this.handlingIndex].stopItemDTOs.push(stopObject);
    } else {
      this.jbhGlobals.notifications.error('Error', 'Please fill all the required fields for item');
    }
  }

  public populateItem(itemDataPopulation) {
    const form = this.itemForm['controls'];
    this.itemForm.patchValue(itemDataPopulation);
    const itemDesc = {
      'itemMake': itemDataPopulation.itemMake,
      'upc': itemDataPopulation.itemUniversalProductCode,
      'itemManufacturer': itemDataPopulation.itemManufacturer,
      'modelNumber': itemDataPopulation.itemModelNumber,
      'sku': itemDataPopulation.skuNumber,
      'supplierSKU': itemDataPopulation.supplierSKU,
      'itemCategory': itemDataPopulation.itemCategory,
      'itemClassification': itemDataPopulation.itemClassificationCode,
      'itemDescription': itemDataPopulation.itemDescription,
      'nmfcNumber': itemDataPopulation.nmfcNumber,
      'itemPartNumber': itemDataPopulation.itemPartNumber
    };
    if (itemDataPopulation.itemVolume && !this.jbhGlobals.utils.isEmpty(itemDataPopulation.unitOfVolumeMeasurementCode)
      && !itemDataPopulation.itemLength && !itemDataPopulation.itemWidth && !itemDataPopulation.itemHeight) {
      this.itemDimensionFlag = false;
      this.itemVolumeVal = form.itemVolume.value + 'kg/m3';
      if (itemDataPopulation.itemWeight && !this.jbhGlobals.utils.isEmpty(itemDataPopulation.unitOfWeightMeasurementCode)) {
        this.itemDenistyVal = form.itemDensity.value + 'kg/m3';
      }
    } else {
      this.itemDimensionFlag = true;
      this.itemVolumeVal = '';
      this.itemDenistyVal = '';
    }

    if (itemDataPopulation.itemLength && itemDataPopulation.itemWidth && itemDataPopulation.itemHeight
      && !this.jbhGlobals.utils.isEmpty(itemDataPopulation.unitOfLengthMeasurementCode) && itemDataPopulation.itemVolume
      && !this.jbhGlobals.utils.isEmpty(itemDataPopulation.unitOfVolumeMeasurementCode)) {
      this.volumeVal = form.itemVolume.value + 'kg/m3';
      if (itemDataPopulation.itemWeight && !this.jbhGlobals.utils.isEmpty(itemDataPopulation.unitOfWeightMeasurementCode)) {
        this.itemDensity = form.itemDensity.value + 'kg/m3';
      }
    } else {
      this.volumeVal = '';
      this.itemDensity = '';
    }

    if (this.transItemFlag) {
      form.itemDescription.setValue((itemDataPopulation.itemDescription ? itemDataPopulation.itemDescription : '') +
        ' (' + (itemDataPopulation.nmfcNumber ? itemDataPopulation.nmfcNumber : '') + ')');
      this.transEditFlag = true;
      this.showTransDetailIcon = true;
      this.itemDescriptionNMFC = itemDesc;
    } else {
      form.itemDescription.setValue((itemDataPopulation.itemDescription ? itemDataPopulation.itemDescription : '') +
        ' (' + (itemDataPopulation.itemModelNumber ? itemDataPopulation.itemModelNumber : '') + ')');
      this.saveEditFlag = true;
      this.showSaveDetailIcon = true;
      this.itemDescriptionSaved = itemDesc;
    }
  }

  public setItemCharacteristics(itemDataPopulation) {
    this.itemCharacteristicsTag.active = [];
    if (itemDataPopulation.itemLengthType === 'Extreme Length') {
      if (this.jbhGlobals.utils.findIndex(this.itemCharacteristicsTag.active,
        { id: 'Extreme Length', text: 'Extreme Length' }) === -1) {
        this.itemCharacteristicsTag.active.push({ id: 'Extreme Length', text: 'Extreme Length' });
      }
    }
    if (itemDataPopulation.itemProtectionType === 'Freeze') {
      if (this.jbhGlobals.utils.findIndex(this.itemCharacteristicsTag.active,
        { id: 'Freeze Protect', text: 'Freeze Protect' }) === -1) {
        this.itemCharacteristicsTag.active.push({ id: 'Freeze Protect', text: 'Freeze Protect' });
      }
    }
    if (itemDataPopulation.itemStackingType === 'Stackable') {
      if (this.jbhGlobals.utils.findIndex(this.itemCharacteristicsTag.active, { id: 'Stackable', text: 'Stackable' }) === -1) {
        this.itemCharacteristicsTag.active.push({ id: 'Stackable', text: 'Stackable' });
      }
    }
    if (itemDataPopulation.itemTemperatureControlMethodCode.length > 0) {
      if (this.jbhGlobals.utils.findIndex(this.itemCharacteristicsTag.active,
        { id: 'Temperature Control', text: 'Temperature Control' }) === -1) {
        this.itemCharacteristicsTag.active.push({ id: 'Temperature Control', text: 'Temperature Control' });
        const tempMethod = this.itemData[this.dataIndex].stopItem.itemTemperatureControlMethodCode;
        this.showTemperature = true;
        this.itemForm['controls']['itemTemperatureControlMethodCode'].setValue(tempMethod);
      }
    }

    if (this.itemData[this.dataIndex].stopItem.stopItemHazardousMaterialDetails) {
      if (this.jbhGlobals.utils.findIndex(this.itemCharacteristicsTag.active, { id: 'Hazmat', text: 'Hazmat' }) === -1) {
        this.itemCharacteristicsTag.active.push({ id: 'Hazmat', text: 'Hazmat' });
        this.showHazmat = true;
        /* Todo setHazmat Values; */
      }
    }
  }
  public validateCubicCapacity(form) {
    const density = form['itemDensity'];
    const volume = form['itemVolume'];
    const length = form['itemLength'];
    const unitLength = form['unitOfVolumeMeasurementCode'];
    let lengthVal: any;
    if (length && !this.jbhGlobals.utils.isEmpty(unitLength)) {
      lengthVal = this.conversionToFeet(length, unitLength);
    }
    if (density && volume && lengthVal) {
      if (density < 6 && volume > 750 && lengthVal > 13) {
        form['itemVolumeType'] = 'Cubic Capacity';
      }
    } else {
      form['itemVolumeType'] = '';
    }
  }
  public itemComponentFocus() {
    if (this.itemForm['dirty']) {
      this.itemDiv.nativeElement.focus();
    }
  }
}
