import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StopResequenceComponent } from './stop-resequence.component';

describe('StopResequenceComponent', () => {
  let component: StopResequenceComponent;
  let fixture: ComponentFixture<StopResequenceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StopResequenceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StopResequenceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
