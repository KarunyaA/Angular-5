import {Component, OnInit} from '@angular/core';
import {OrderService} from '../../orders/order.service';
import {JBHGlobals} from '../../../../app.service';
import {OrderFormBuilder} from '../order-form-builder.service';

@Component({
  selector: 'app-orderoverview',
  templateUrl: './orderoverview.component.html',
  styleUrls: ['./orderoverview.component.scss']
})
export class OrderoverviewComponent implements OnInit {
    subscription: any;
    orderData: any;
    indicator: any;
    count: number;
    serviceoffering: string;
    orderOverViewList: any;
    originStopLocation: any;
    originStopAddress: any;
    destinationStopLocation: any;
    destinationStopAddress: any;
    destinationStopAddress12345: any;
    originStop: any;
    destinationStop: any;
    orderOverViewListStop: any;
    orderOverViewListStopvalue: any;
    orderOverViewEquipment: any;
    orderOverViewEquipmentIndicator: any;
    billtoaccountprofile: any;
    billtoaccountaddress: any;
   /* stopAppointmentValue: any;
    appointmentValue: any;*/
 constructor(public jbhGlobals: JBHGlobals, public orderService: OrderService) {}

  ngOnInit() {

    if (this.jbhGlobals.utils.isEmpty(this.orderData)) {
      this.subscription = this.orderService.getData().subscribe(sharedOrderData => {
        this.orderData = sharedOrderData;
        if (!this.jbhGlobals.utils.isEmpty(this.orderData) && this.orderData.length !== 0) {
        }
      });

    }
    this.setOrderOverviewData();
    this.setOrderOverviewDataStops();
    /*this.stopvalue();*/
  }
  setOrderOverviewData() {
    const me = this;
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getorderoverview).subscribe(data => {
      me.orderOverViewList = data;
      me.orderOverViewEquipment = data['orderEquipmentRequirementDTOs'][0];
      me.indicator = data['orderEquipmentRequirementDTOs'][0]['orderEquipmentRequirement']['equipmentTypeRequiredIndicator'];
      me.billtoaccountprofile = data['orderBillingDetailDTOs'][0]['profileDTO'];
      me.billtoaccountaddress = data['orderBillingDetailDTOs'][0]['profileDTO']['addressDTO'];
   });
  }
  setOrderOverviewDataStops() {
    const me = this;
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getstopresequencelistorderoverview).subscribe(data => {
      me.orderOverViewListStop = data;
      me.count = data['totalElements'];
      me.originStop = data['content'][0]['locationDTO'];
      me.destinationStop = data['content'][me.count - 1]['locationDTO'];
      me.originStopAddress = data['content'][0]['locationDTO']['addressDTO'];
      me.destinationStopAddress = data['content'][me.count - 1]['locationDTO']['addressDTO'];
      });
  }
/*stopvalue(){
 const me=this;
  this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getStopAppointment).subscribe(data => {
      me.stopAppointmentValue = data;
      me.appointmentValue=data['stop']['appointment'][0]['lastUpdateTimestampString'];
    });
  }*/

}


/* ngAfterContentChecked() {
        if (this.orderData !== 'undefined') {
            this.subscription = this.orderService.getData().subscribe(sharedOrderData => {
                this.orderData = sharedOrderData;
                  this.getData();
           });
        }

    }*/
