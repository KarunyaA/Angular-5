import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MassUpdateSummaryComponent } from './mass-update-summary.component';

describe('MassUpdateSummaryComponent', () => {
  let component: MassUpdateSummaryComponent;
  let fixture: ComponentFixture<MassUpdateSummaryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MassUpdateSummaryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MassUpdateSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
