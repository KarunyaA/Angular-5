import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import {OrderService} from '../../order.service';
import { JBHGlobals } from '../../../../../app.service';

@Component({
  selector: 'app-documents',
  templateUrl: './documents.component.html',
  styleUrls: ['./documents.component.scss', '../instructions/instructions.component.scss']
})
export class DocumentsComponent implements OnInit  {
    addDocumentDetail: FormGroup;
    orderData: any;
    public subscription: any;
    

  constructor(public formBuilder: FormBuilder, public orderService: OrderService, public jbhGlobals: JBHGlobals) { }

  ngOnInit() {
    this.addDocumentFormBuilder();
    if (this.jbhGlobals.utils.isEmpty(this.orderData)) {
        this.subscription = this.orderService.getData().subscribe(sharedOrderData => {
            this.orderData = sharedOrderData;
        });
    }
    }
   public addDocumentFormBuilder() {
      this.addDocumentDetail = this.formBuilder.group({
        'docInputText': '',
        'docInputfile': '',
        });
    }

    documentSave(form) {
    }


}
