import { Component, Input, OnInit, ViewChild } from '@angular/core';
import {JBHGlobals} from '../../../../../app.service';

import {OrderService} from '../../order.service';
import { OrderFormBuilder } from '../../order-form-builder.service';

@Component({
  selector: 'app-serviceoffering',
  templateUrl: './serviceoffering.component.html',
  styleUrls: ['./serviceoffering.component.scss']
})
export class ServiceofferingComponent implements OnInit {
  @ViewChild('businessunit') businessunit;
  public transitMode: string;
  public dollarInputRequired = false;
  public businessUnitList: string[] = [];
  public serviceLevelList: string[] = [];
  public freightChargeList: string[] = [];
  public serviceOfferingList: string[] = [];
  public operationalServicesList: any[] = [];
  public operationalServicesListDescription: string[] = [];
  public operationalOwnerList: string[] = [];
  public operationalOwnerListDescription: string[] = [];
  public operationalOwnerIconDetails: any;
  public oprOwnerValue: string;
  public debounceValue: number;
  public selServiceLevel: string;
  public selServiceOff: string;
  public selectedBunit: string;
  public selectedServiceOffering: string;
  public isEditOrder = false;

  @Input() serviceOfferingDetail: any;
  @Input() isCurrViewTemplate: boolean;
  subscription: any;
  orderData: any;
  public placeholder = 'Operational Services';

  constructor(public jbhGlobals: JBHGlobals,
              public orderService: OrderService,
              public orderFormBuilder: OrderFormBuilder) {

  }

  public loadBusinessUnit() {
    // Get all BusinessUnits
     this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getbusinessunit).subscribe( data => {
            this.businessUnitList = data['_embedded']['serviceOfferingBusinessUnitTransitModeAssociations'];
          }
      );
  }

 public loadServiceLevels() {
      // Get all ServiceLevels
      const  params = {'financeBusinessUnitCode': this.selectedBunit, 'serviceOfferingCode': this.selectedServiceOffering};
      this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getservicelevels, params).subscribe( data => {
            this.serviceLevelList = data['_embedded']['serviceLevelBusinessUnitServiceOfferingAssociations'];
            this.selServiceLevel = this.serviceLevelList[0]['serviceLevel']['serviceLevelCode'];
          }
      );
  }

  public  loadFreightChargeTerms() {
      // Get all FreightChargeTerms
      this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getfreightchargeterms).subscribe( data => {
            this.freightChargeList = data['_embedded']['freightChargeTerms'];
          }
      );
  }

  public loadOperationalOwner(selectedOprOwner) {
      // Get all OperationalOwner
      this.operationalOwnerListDescription = [];
      const params = {'projectCode': selectedOprOwner};
      this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getoperationalowner, params, false).subscribe( data => {
            this.operationalOwnerList = data['_embedded']['projects'];
            for ( let i = 0; i < this.operationalOwnerList.length; i++) {
              this.operationalOwnerListDescription.push(this.operationalOwnerList[i]['projectDescription'].trim());
            }
          }
      );
  }

  public onClickOpr() {
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getOperationalOwnerIcon).subscribe( data => {
          this.operationalOwnerIconDetails = data;
        }
    );
  }

  public onMailing() {
    window.location.href = 'mailto:' + this.operationalOwnerIconDetails.emailAddress;
  }

  public onCalling() {
    window.location.href = 'tel:' + this.operationalOwnerIconDetails.phoneNumber;
  }

  public onChating() {
    window.location.href = 'sip:Justin.Horton@jbhunt.com';
  }

  public  loadOperationalServices() {
      // Get all OperationalServices
      this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getoperationalservices).subscribe( data => {
          this.operationalServicesList = data['_embedded']['serviceTypes'];
            for ( let i = 0; i < this.operationalServicesList.length; i++) {
              this.operationalServicesListDescription.push(this.operationalServicesList[i]['serviceTypeDescription']);
            }
          }
       );
  }

 public  loadServiceOfferingList(value) {
      // Get all ServiceOffering
      const  params = {'financeBusinessUnitCode': value, 'projection': 'viewserviceofferingbusinessunittransitmode'};
      this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getserviceoffering, params).subscribe( data => {
            this.serviceOfferingList = data['_embedded']['serviceOfferingBusinessUnitTransitModeAssociations'];
          }
      );
  }

  public onSelectOperationalService(value) {
     if (value === 'Limitation of Liability') {
        this.dollarInputRequired = true;
      }

      const oprServiceObj = this.oprTransform(this.operationalServicesList, value.value)[0];
       const OrderServicesObj = {
            'serviceCount' : 1,
            'serviceLevelTypeCode' : 'ORDER',
            'serviceType' : oprServiceObj.serviceTypeCode,
            'stopID' : '',
            'unitOfServiceMeasurementCode' : 'Hours'
          };

      if (this.orderData.orderServices === undefined) {
        this.orderData.orderServices = [];
      }

      this.orderData.orderServices.push(OrderServicesObj);
      this.orderService.saveData(this.orderData);
  }

 public onRemoveOperationalService(value) {
     if (value === 'Limitation of Liability') {
       this.dollarInputRequired = false;
     }
     const oprServiceObj = this.oprTransform(this.operationalServicesList, value.value)[0];
     for ( let i = 0; i < this.orderData.orderServices.length; i++) {
        if (this.orderData.orderServices[i].serviceType === oprServiceObj.serviceTypeCode) {
            this.orderData.orderServices.splice(i, 1);
        }
      }
      this.orderService.saveData(this.orderData);
  }

  public onSelectServiceOffering(value) {
    const obj = this.transform(this.serviceOfferingList, value)[0];

    this.selectedServiceOffering = value;
    this.transitMode = obj.transitModeCode;
    this.orderData.transitModeCode = this.transitMode;
    this.orderData.serviceOfferingCode = this.selectedServiceOffering;
    this.orderService.saveData(this.orderData);
    this.loadServiceLevels();
  }

  transform(items: any[], args: string): any {
        // filter items array, items which match and return true will be kept, false will be filtered out
      return items.filter(item => item.serviceOfferingCode.toLowerCase().indexOf(args.toLowerCase()) !== -1 );
  }

   public getOrder() {
      this.subscription = this.orderService.getData().subscribe(sharedOrderData => {
        this.orderData = sharedOrderData;
        if (this.orderData !== 'undefined' || this.orderData.length !== 0 && this.isEditOrder) {
          this.populateData();
        }
      });
    }

populateData() {
  if (this.orderData.financeBusinessUnitCode) {
    this.serviceOfferingDetail['controls']['financeBusinessUnitCode'].setValue(this.orderData.financeBusinessUnitCode);
  }
  if (this.orderData.serviceOfferingCode) {
    this.serviceOfferingDetail['controls']['serviceOfferingCode'].setValue(this.orderData.serviceOfferingCode);
  }
  if (this.orderData.orderBillingDetailDTOs !== null) {
    const freightValue = this.orderData.orderBillingDetailDTOs[0].freightChargeTermTypeCode;
    this.serviceOfferingDetail['controls']['freightChargeTermTypeCode'].setValue(freightValue);
  }
  if (this.orderData.requestedServiceLevelCode) {
    this.serviceOfferingDetail['controls']['requestedServiceLevelCode'].setValue(this.orderData.requestedServiceLevelCode);
  }
  if (this.orderData.orderOperationalElements !== null) {
    this.serviceOfferingDetail['controls']['projectCode'].setValue(this.orderData.orderOperationalElements[0].projectCode);
  }
  if (this.orderData.orderServices !== null) {
    this.serviceOfferingDetail['controls']['orderServices'].setValue(this.orderData.orderServices[0].serviceType);
  }
}

  ngOnInit() {
  this.serviceOfferingDetail = this.orderFormBuilder.orderForm.controls['serviceOfferingDetail'];
  this.debounceValue = this.jbhGlobals.settings.debounce;
  this.getOrder();

  this.serviceOfferingDetail['controls']['financeBusinessUnitCode']['valueChanges']
      .debounceTime(this.debounceValue)
      .distinctUntilChanged()

      .subscribe((selectedBusinessUnit) => {
        this.selServiceOff = '';
        this.selServiceLevel = '';
        this.selectedBunit = selectedBusinessUnit;
        this.orderData.financeBusinessUnitCode = this.selectedBunit;
        this.transitMode = '';
        this.orderService.saveData(this.orderData);
        this.loadServiceOfferingList(selectedBusinessUnit);
    }, (err: Error) => {
      console.log(err);
  });

  this.serviceOfferingDetail['controls']['freightChargeTermTypeCode']['valueChanges']
    .debounceTime(this.debounceValue)
    .distinctUntilChanged()

    .subscribe((selectedFreightCharge) => {
      if (this.orderData.orderBillingDetailDTOs === undefined) {
         this.orderData.orderBillingDetailDTOs = [];
          const freightObj = {
            'freightChargeTermTypeCode' : selectedFreightCharge
          };
          this.orderData.orderBillingDetailDTOs.push(freightObj);
      }else {
         this.orderData.orderBillingDetailDTOs[0].freightChargeTermTypeCode = selectedFreightCharge;
      }

       this.orderService.saveData(this.orderData);

    }, (err: Error) => {
      console.log(err);
  });

  this.serviceOfferingDetail['controls']['transitModeCode']['valueChanges']
    .debounceTime(this.debounceValue)
    .distinctUntilChanged()

     .subscribe((transitModeValue) => {
       this.orderData.transitModeCode = transitModeValue;
       this.orderService.saveData(this.orderData);
    }, (err: Error) => {
      console.log(err);
  });

  this.serviceOfferingDetail['controls']['requestedServiceLevelCode']['valueChanges']
    .debounceTime(this.debounceValue)
    .distinctUntilChanged()

     .subscribe((selectedServiceLevel) => {
       this.orderData.requestedServiceLevelCode = selectedServiceLevel;
       this.orderService.saveData(this.orderData);
    }, (err: Error) => {
    console.log(err);
  });

  this.serviceOfferingDetail['controls']['projectCode']['valueChanges']
    .debounceTime(this.debounceValue)
    .distinctUntilChanged()

     .subscribe((selectedOprOwner) => {
      if (selectedOprOwner !== undefined && selectedOprOwner.length > 2) {
        this.loadOperationalOwner(selectedOprOwner);
      }
    }, (err: Error) => {
    console.log(err);
  });
  if (this.isCurrViewTemplate) {
     this.serviceOfferingDetail['controls']['scac']['valueChanges']
        .debounceTime(this.debounceValue)
        .distinctUntilChanged()

         .subscribe((scac) => {
          this.orderData.scac = scac;
          this.orderService.saveData(this.orderData);
        }, (err: Error) => {
        console.log(err);
      });

      this.serviceOfferingDetail['controls']['tradingPartner']['valueChanges']
        .debounceTime(this.debounceValue)
        .distinctUntilChanged()

         .subscribe((tradingPartner) => {
          this.orderData.tradingPartner = tradingPartner;
          this.orderService.saveData(this.orderData);
        }, (err: Error) => {
        console.log(err);
      });
    }
    this.loadBusinessUnit();
    this.loadFreightChargeTerms();
    this.loadOperationalServices();
  }

  oprTransform(items: any[], args: string): any {
        // filter items array, items which match and return true will be kept, false will be filtered out
      return items.filter(item => item.serviceTypeDescription.toLowerCase().indexOf(args.toLowerCase()) !== -1 );
  }
  oprOwnerOnSelect(selectedVal) {
    this.oprOwnerValue = selectedVal.value.trim();
    if (this.orderData.orderOperationalElements) {
      this.orderData['orderOperationalElements'][0].projectCode = this.oprOwnerValue;
    }else {
       this.orderData.orderOperationalElements = [];
        const oprObj = {
          'projectCode' : this.oprOwnerValue
        };
        this.orderData.orderOperationalElements.push(oprObj);
    }
    this.orderService.saveData(this.orderData);
  }

  onRemoveServiceTypes(items: any[], args: string): any {
        // filter items array, items which match and return true will be kept, false will be filtered out
      return items.filter(item => item.serviceTypeDescription.toLowerCase().indexOf(args.toLowerCase()) === -1 );
  }
}
