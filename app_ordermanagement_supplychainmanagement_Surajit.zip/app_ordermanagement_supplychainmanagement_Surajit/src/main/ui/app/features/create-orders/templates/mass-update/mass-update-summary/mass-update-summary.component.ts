import { Component, OnInit } from '@angular/core';

import { JBHGlobals } from 'app/app.service';

@Component({
  selector: 'app-mass-update-summary',
  templateUrl: './mass-update-summary.component.html',
  styleUrls: ['./mass-update-summary.component.scss']
})
export class MassUpdateSummaryComponent implements OnInit {
    rows: any[];
    selected = [];
    count = 0;
    offset = 0;
    limit = 5;
    favUrl = '';
    valWidth = 1;

    // columns = [
    //   {
    //    name: 'Date / Time of Upload',
    //    prop: 'uploadDetails',
    //    sortable: false,
    //    canAutoResize: false,
    //    draggable: false,
    //    resizeable: false,
    //    reorderable: false,
    //    frozenLeft: true
    //  }, {
    //    name: 'Number of Failed Records',
    //    prop: 'failedRecords',
    //    draggable: false,
    //    resizeable: false,
    //    reorderable: false
    //  }, {
    //    name: 'Number of Success Records',
    //    prop: 'successRecords',
    //    draggable: false,
    //    resizeable: false,
    //    reorderable: false
    //  }, {
    //    name: 'Upload Progress / Status',
    //    prop: 'progress',
    //    draggable: false,
    //    resizeable: false,
    //    reorderable: false
    //  }

    //  ];

    constructor(public jbhGlobals: JBHGlobals) {
        this.favUrl = this.jbhGlobals.endpoints.template.getMassUpdateSummary;
        this.jbhGlobals.apiService.getData(this.favUrl).subscribe(data => {
            this.rows = data;
            console.log(this.rows);

        });
    }

    ngOnInit() {}

    page(offset, limit) {
        //    this.jbhGlobals.apiService.getData(this.favUrl).subscribe(data => {
        //      this.count = data.length;
        //
        //      const start = offset * limit;
        //      const end = start + limit;
        //      const rows = [...this.rows];
        //
        //      for (let i = start; i < end; i++) {
        //        rows[i] = data[i];
        //      }
        //
        //      this.rows = rows;
        //      console.log('Page Results', start, end, rows);
        //    });
    }

    onPage(event) {
        //    console.log('Page Event', event);
        //    this.page(event.offset, event.limit);
    }

    onSelect({
        selected
    }) {
        //        console.log('Select Event', selected, this.selected);
        //        this.selected.splice(0, this.selected.length);
        //        this.selected.push(...selected);
    }

    onActivate(event) {
        //        console.log('Activate Event', event);
    }

}
