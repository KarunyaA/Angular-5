import { Component, OnInit } from '@angular/core';
import { IMyOptions, IMyDateModel } from 'mydatepicker';

@Component({
  selector: 'app-order-shipping-options',
  templateUrl: './order-shipping-options.component.html',
  styleUrls: ['./order-shipping-options.component.scss']
})
export class OrderShippingOptionsComponent implements OnInit {

  public shippingErrorList = ['Initial Service Offering', 'Rate Publication Code', 'Rate Item Code', 'Rate Item Code'];
  public shippingWarningList = ['Initial Service Offering', 'Rate Item Code', 'Rate Publication', 'Rate Item Code'];
  public filterData: Object = {};
  public deliveryDate: any;
  public pickUpDate: any;
  public deliveryDateTime: any;
  public duration: string;
  public pickUpDateTime: any;

  public myDatePickerOptions: IMyOptions = {
    todayBtnTxt: 'Today',
    dateFormat: 'mm-dd-yyyy',
    firstDayOfWeek: 'mo',
    showClearDateBtn: false,
    editableDateField: false,
    sunHighlight: true,
    height: '34px',
    width: '120px',
    inline: false,
    // disableUntil: {year: 2016, month: 8, day: 10},
    selectionTxtFontSize: '14px'
  };
  ngOnInit() {

  }
  constructor() {
    this.duration = '1-3 Days';
  }
  public btnClick(e, selBtnNum): void {
    const btnArray = e.target.parentElement.getElementsByTagName('button');
    for (let item = 0; item < btnArray.length; item++) {
      if (btnArray[item].id !== selBtnNum) {
        btnArray[item].removeAttribute('class');
        btnArray[item].setAttribute('class', 'btn btn-default btn-group-primary');
      }
    }
    if (selBtnNum === 1) {
      this.duration = '1-3 Days';
    } else if (selBtnNum === 2) {
      this.duration = '1-6 Days';
    } else if (selBtnNum === 3) {
      this.duration = '1-10 Days';
    }
    this.setFilterValues();
    e.target.setAttribute('class', 'btn btn-default btn-group-primary active');
  }
  private setFilterValues() {
    console.log(this.pickUpDate, this.deliveryDate);
    console.log(this.pickUpDateTime, this.deliveryDateTime);
    if (this.pickUpDate !== undefined && this.deliveryDate !== undefined) {
      // && this.pickUpDateTime !== undefined && this.deliveryDateTime !== undefined)
      this.filterData = { 'pickDate': this.pickUpDate, 'deliveryDate': this.deliveryDate, 'duration': this.duration };
    }
  }
  onpickUpDateChanged(event: IMyDateModel) {
    // event properties are: event.date, event.jsdate, event.formatted and event.epoc
    this.pickUpDate = event.epoc;
    this.setFilterValues();
  }
  ondeliveryDateChanged(event: IMyDateModel) {
    // event properties are: event.date, event.jsdate, event.formatted and event.epoc
    this.deliveryDate = event.epoc;
    this.setFilterValues();
  }

}
