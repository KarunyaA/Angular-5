import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OrderShippingOptionsComponent } from './order-shipping-options.component';

describe('OrderShippingOptionsComponent', () => {
  let component: OrderShippingOptionsComponent;
  let fixture: ComponentFixture<OrderShippingOptionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrderShippingOptionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrderShippingOptionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
