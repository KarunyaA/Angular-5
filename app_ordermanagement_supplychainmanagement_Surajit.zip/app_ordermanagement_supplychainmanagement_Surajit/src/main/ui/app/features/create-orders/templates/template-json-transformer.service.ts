import {
  Injectable
} from '@angular/core';

import {
  JBHGlobals
} from 'app/app.service';
import {
  IOrderDtoModel
} from 'app/features/create-orders/orders/order-dto-model';
import {
  ITemplateEntityModel
} from 'app/features/create-orders/templates/template-entity-model';

@Injectable()
export class TemplateJsonTransformerService {

  constructor(private jbhGlobals: JBHGlobals) {

  }

  orderDtoToEntity(source: IOrderDtoModel, target: ITemplateEntityModel):
    ITemplateEntityModel {
    const me = this;
    const _ = me.jbhGlobals.utils;

    const mapProp: Object = {
      // orderCrossesBorderDetailDTOs:"orderCrossBorderDetails",
      // orderEquipmentRequirementDTOs:"orderEquipmentRequirement",
      // referenceNumberDTOs:"orderReferenceNumbers",
      // commentDTOs:"orderComments",
      orderRequestorDTOs: 'orderRequestorDetail',
      // stopDTOs:"stops",
      // chargeDTOs:"orderCharges",
      orderBillingDetailDTOs: 'orderBillingDetail',
      internationalService: 'internationalServices',
      // orderMaterialHandlingRequirementAssociation:"orderMaterialHandlingRequirementAssociations",
      customerID: 'customerID',
      serviceOfferingCode: 'serviceOfferingCode',
      requestedServiceLevelCode: 'requestedServiceLevelCode',
      servicePriorityTypeCode: 'servicePriorityTypeCode',
      transitModeCode: 'transitModeCode',
      financeBusinessUnitCode: 'financeBusinessUnitCode',
      orderSourceCode: 'orderSourceCode',
      orderStatusCode: 'orderStatusCode',
      orderTypeCode: 'orderTypeCode',
      orderSubTypeCode: 'orderSubTypeCode',
      orderValueTypeCode: 'orderValueTypeCode',
      orderVolumeTypeCode: 'orderVolumeTypeCode',
      shipmentIdentificationNumber: 'shipmentIdentificationNumber',
      orderTrackingNumber: 'orderTrackingNumber',
      orderValueAmount: 'orderValueAmount',
      orderRefrigeratedIndicator: 'orderRefrigeratedIndicator',
      orderGroupingID: 'orderGroupingID',
      // orderUnifiedCustomerRequestAssociations:"orderUnifiedCustomerRequestAssociations",
      // orderAdditionalInstructions:"orderAdditionalInstructions",
      orderCarrierDetails: 'orderCarrierDetails',
      // orderStatusWorkflows:"orderStatusWorkflows",
      // orderStatusEvents:"orderStatusEvents",
      // orderFoodSafetyDetails:"orderFoodSafetyDetails",
      internationalOrderElement: 'internationalOrderElement',
      // orderMonitorInformations:"orderMonitorInformations",
      orderOperationalElements: 'orderOperationalElement',
      orderServices: 'orderServices',
      orderID: 'orderID'
      // orderAssociatedParties:"orderAssociatedParties"
    };
    _.map(source, function (o, key) {
      if (_.hasIn(mapProp, key)) {
        switch (key) {
          case 'orderBillingDetailDTOs':
            target[mapProp[key]] = [];
            _.map(o, function (so) {

              _.map(so.orderBillingAdditionalInstruction,
                function (sso) {
                  sso.orderID =
                    source.orderID;
                });

              target[mapProp[key]].push({
                autoRateIndicator: so
                  .autoRateIndicator,
                billToID: so.profileDTO
                  .partyID,
                contactID: 9,
                contactTypeCode: so
                  .profileDTO.contactDTO
                  .contactType,
                freightChargeTermTypeCode: so
                  .freightChargeTermTypeCode,
                // ratingCycleType:so.ratingCycleDTO.ratingCode,
                ratingCycleType: 'load',
                lineOfBusinessCode: so
                  .lineOfBusinessCode
              });
            });
            break;
          case 'orderRequestorDTOs':
            target[mapProp[key]] = [];
            _.map(o, function (so) {
              target[mapProp[key]].push({
                contactID: '',
                contactTypeCode: so
                  .profileDTO.contactDTO
                  .contactType,
                solicitorID: so.profileDTO
                  .partyID
              });
            });
            break;
          default:
            if (_.isObject(o)) {
              _.map(o, function (so) {
                delete so[
                  'lastUpdateTimestampString'
                ];
              });
            }
            target[mapProp[key]] = o;
        }
      }
    });
    return target;
  }
}
