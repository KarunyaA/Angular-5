import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { JBHGlobals } from './../../../../app.service';
import { OrderService } from './../order.service';
import { OrderFormBuilder } from '../order-form-builder.service';

@Component({
  selector: 'app-add-stops',
  templateUrl: './add-stops.component.html',
  styleUrls: ['./add-stops.component.scss']
})

export class AddStopsComponent implements OnInit {
    @ViewChild('stopChild') stopChild: any;
    errorMessage: string;
    subscription: any;
    orderData: any;
    public orderID: any;
    public debounceValue: number;
    public newStopId: number;
    public firstStopOpened = false;
    public stopData: any;
    public requestedAppts: any;
    public scheduledAppts: any;
    public businessUnitCode: string[] = ['DCS', 'ICS'];
    public serviceOfferingCode: string[] = ['FMS', 'LTL'];
    public orderTypeCode: string[] = ['standard', 'return', 'other'];
    public stopDataLoaded = false;
    public businessUnit: boolean;
    public serviceOffering: boolean;
    public orderType: boolean;
    public activeStop: any;
    public stopResequenceList: any[] = [];
    public stopSaveActionSuccess = true;
    constructor(public orderFormBuilder: OrderFormBuilder,
        public route: ActivatedRoute,
        public jbhGlobals: JBHGlobals,
        public orderService: OrderService) {}

    ngOnInit() {
        this.loadOrderData();
        this.debounceValue = this.jbhGlobals.settings.debounce;
    }
    public addStopList() {
        if (this.stopResequenceList.length === 1) {
            this.stopResequenceList.push({
                stop: {
                    stopID: null,
                    stopSequenceNumber: 2
                }
            });
        } else if (this.stopResequenceList.length === 0) {
            this.stopResequenceList.push({
                stop: {
                    stopID: null,
                    stopSequenceNumber: 1
                }
            });
            this.stopResequenceList.push({
                stop: {
                    stopID: null,
                    stopSequenceNumber: 2
                }
            });
        }
    }
    public getResequenceList() {
        let orderId: any;
        orderId = this.orderID + '/stops';
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getstopresequencelist).subscribe(data => {
            if (!this.jbhGlobals.utils.isEmpty(data)) {
                this.stopResequenceList = data['content'];
                this.addStopList();
            } else if (this.jbhGlobals.utils.isEmpty(data)) {
                this.stopResequenceList = [];
                this.addStopList();
            }
        }, (err: Error) => {
             return false;
        });
    }
    public loadOrderData() {
        // if(this.jbhGlobals.utils.isEmpty(this.orderData)) {
        this.orderService.getData().subscribe(sharedOrderData => {
            if (!this.jbhGlobals.utils.isEmpty(sharedOrderData)) {
                this.orderData = sharedOrderData;
                this.orderID = this.orderData.orderID;
                this.getResequenceList();
                // this.stopReason = this.orderData.stopDTOs[0].stop.stopReason;
                this.businessUnit = this.isServiceOfferingExist();
                this.serviceOffering = this.isBusinessUnitExist();
                this.orderType = this.isOrderTypeExist();
                /* this.businessUnit = this.orderData.financeBusinessUnitCode;
                 this.serviceOffering = this.orderData.serviceOfferingCode;
                 this.orderType = this.orderData.orderTypeCode; */
            }
        }, (err: Error) => {
             return false;
        });
        // }
    }
    public isBusinessUnitExist() {
        const businessUnit: string = this.orderData.financeBusinessUnitCode;
        if (!this.jbhGlobals.utils.isEmpty(businessUnit) && (this.businessUnitCode.indexOf(businessUnit) !== -1)) {
            return true;
        } else {
            return false;
        }
    }
    public isServiceOfferingExist() {
        const serviceOffering: string = this.orderData.serviceOfferingCode;
        if (!this.jbhGlobals.utils.isEmpty(serviceOffering) && (this.serviceOfferingCode.indexOf(serviceOffering) !== -1)) {
            return true;
        } else {
            return false;
        }
    }
    public isOrderTypeExist() {
        const orderType: string = this.orderData.orderTypeCode;
        if (!this.jbhGlobals.utils.isEmpty(orderType) && (this.orderTypeCode.indexOf(orderType) !== -1)) {
            return true;
        } else {
            return false;
        }
    }
    public addStopDetails(stopForm) {
        this.jbhGlobals.apiService.addData(this.jbhGlobals.endpoints.order.crudStopDetails, stopForm).subscribe(stopData => {
            if (!this.jbhGlobals.utils.isEmpty(stopData)) {
                if (stopData['stopID']) {
                    //  this.newStopId = stopData['stopID'];
                    this.jbhGlobals.logger.info('Stops Added Successfully');
                }
            }
        }, (err: Error) => {
             return false;
        });
    }
    public updateStopDetails(stopId, stopForm) {
        this.jbhGlobals.apiService.updateData(this.jbhGlobals.endpoints.order.crudStopDetails + stopId, stopForm).subscribe(stopData => {
            if (!this.jbhGlobals.utils.isEmpty(stopData)) {
                this.jbhGlobals.logger.info('Stops Updated Successfully');
            }
        }, (err: Error) => {
             return false;
        });
    }
    public getFistStop(stopId: number, group: any, stopPosition: number) {
        if (stopPosition === 0 && !this.firstStopOpened) {
            this.activeStop = group;
            group.isOpen = true;
            this.firstStopOpened = true;
        }
        return false;
    }
    public onStopCollpse(event, stopId: number, group: any, stopPostion: number) {
        if (this.activeStop !== null && this.stopChild) {
             this.stopChild.stopDetailSaveForm();
          //  if (this.stopChild.stopForm.touched && this.stopChild.stopForm.dirty) {
               // this.stopChild.handlingUnitRef.stopHandlingFormSave();
                // this.stopChild.stopDetailSaveForm();
               /*  if (!this.jbhGlobals.utils.isEmpty(this.stopChild.stopForm.value.stopID)) {
                    const stopID = '/' + this.stopChild.stopForm.value.stopID;
                    this.updateStopDetails(stopID, this.stopChild.stopForm.value);
                } else {
                    this.addStopDetails(this.stopChild.stopForm.value);
                }
                if (!this.stopSaveActionSuccess) {
                    alert('Error');
                    event.stopPropagation();
                    return;
                } */
           // }
            this.activeStop = null;
        }
        if (!group.isOpen) {
            this.activeStop = group;
        }
    }
    public preventCollpase(event) {
        event.stopPropagation();
    }
    public addAppointment(appt: number) {
        if (appt === 0) {
            this.orderData.stopDTOs.stop.appointment.push(this.orderFormBuilder.requestedAppointments());
        }
        if (appt === 1) {
            this.orderData.stopDTOs.stop.appointment.push(this.orderFormBuilder.scheduledAppointments());
        }
        // this.orderData.stopDTOs.stop.appointment.push(apptCtrl);
        // this.orderService.saveData(this.orderData);
    }
    public removeStop(event, indx: number, stopId: number) {
        event.stopPropagation();
        this.stopResequenceList.splice(indx, 1);
        if (stopId && stopId !== undefined) {
            const stopID = '/' + stopId;
            this.jbhGlobals.apiService.removeData(this.jbhGlobals.endpoints.order.crudStopDetails + stopID).subscribe(chargeData => {
                this.jbhGlobals.logger.info('Stop Deleted');
            }, (err: Error) => {
             return false;
        });
        }
    }
    public initAddStopDetails(group: any, indx: number) {
        const stopCtrl = {
            'stop': {
               'stopID': '',
               'stopSequenceNumber': ''
             }
        };
        this.stopResequenceList.splice((indx + 1), 0, stopCtrl);
        group.isOpen = true;
    }
    onSubmit(val) {
        console.log(val.value);
    }
}
