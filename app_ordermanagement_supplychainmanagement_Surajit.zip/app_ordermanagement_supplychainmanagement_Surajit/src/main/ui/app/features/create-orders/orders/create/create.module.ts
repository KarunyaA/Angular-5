import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RlTagInputModule } from '../../../../shared/tag-input';
import { TagInputModule } from 'ng2-tag-input';
import { TypeaheadModule } from 'ngx-bootstrap/typeahead';
import { PopoverModule } from 'ngx-bootstrap/popover';
import { ModalModule } from 'ngx-bootstrap';
// import { SelectModule } from 'ng2-select';
import { SelectModule } from '../../../../shared/select';

import { CreateRoutingModule } from './create-routing.module';
import { CreateComponent } from './create.component';
import { AccountinformationComponent } from './accountinformation/accountinformation.component';
import { ServiceofferingComponent } from './serviceoffering/serviceoffering.component';
import { ShipmentinformationComponent } from './shipmentinformation/shipmentinformation.component';
import { OperationinformationComponent } from './operationinformation/operationinformation.component';
import { TypeaheadComponent } from './accountinformation/typeahead/typeahead.component';
import { ManageoverlayModule } from '../manageoverlay/manageoverlay.module';
import { AddcontactComponent } from './accountinformation/addcontact/addcontact.component';
import { OrderFormBuilder} from '../order-form-builder.service';

@NgModule({
  imports: [
    CommonModule,
    PopoverModule.forRoot(),
    ModalModule.forRoot(),
    FormsModule,
    ReactiveFormsModule,
    TypeaheadModule.forRoot(),
    RlTagInputModule,
    CreateRoutingModule,
    ManageoverlayModule,
    TagInputModule,
    SelectModule
  ],
  providers: [OrderFormBuilder],
  declarations: [
      CreateComponent,
      AccountinformationComponent,
      ServiceofferingComponent,
      ShipmentinformationComponent,
      OperationinformationComponent,
      TypeaheadComponent,
      AddcontactComponent
  ],
   exports: [
          CreateComponent,
          AccountinformationComponent,
          ServiceofferingComponent,
          ShipmentinformationComponent,
          OperationinformationComponent
          ]
})

/*
  CreateorderModule - This module contains create component module and manage overlay module
                    - It helps to generate an order by its components.
*/
export class CreateorderModule { }
