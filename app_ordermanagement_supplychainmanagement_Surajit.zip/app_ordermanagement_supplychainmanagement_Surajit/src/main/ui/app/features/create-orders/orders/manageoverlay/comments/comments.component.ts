import { Component, AfterContentChecked } from '@angular/core';
// import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { OrderService } from '../../order.service';
import { JBHGlobals } from '../../../../../app.service';

@Component({
    selector: 'app-comments',
    templateUrl: './comments.component.html',
    styleUrls: ['./comments.component.scss'],
    providers: []
})

export class CommentsComponent implements AfterContentChecked {

    public commentSuggestions: any = [];
    public cmmntSgtnsList: any = [];
    public currntSuggstns: any = [];
    public tmpCmntsListBakUp: any = [];
    public subscription: any;
    public selectedCmntDivv: any;
    public orderData: any;
    public cmntTypes: any;
    public stopNum: any;
    public tempCmntArr: string[];
    public cmntArrBackUp2: any = [];
    public newComment: string;
    public selectedCmntDiv: any;
    public cmntTagReference: any;
    public currentCmntTags: any = [];
    public commentsTagData: any = ['Order'];
    public commentsTagDataDuplicate: any = this.commentsTagData;
    public commentsFilter: any = ['All Tags'];
    public innerHtmlCmnt: any = [];
    public stopsLoaded = false;
    public filterLoaded = false;
    public cmntFilterLoaded = false;
    public editCall = false;
    public stopTagsLoaded = false;
    public orderAndStops: any = [];
    public filteredArr: any = [];
    public editIndex: any;
    public stopIdEdt: any;
    public orderObjResponce: any = [];
    public stopObjResponce: any = [];
    public newTag2Code: any;
    public loadCmnts: any = [];
    public orderNumber: any;
    public stopAndIds: any;
    public TmpObjCmnt: any = {
        'commentTypeDescription': null,
        'comment': {
            'commentID': null,
            'remark': null,
            'commentTypeCode': null,
            'location': null,
            'commentLevelTypeCode': null,
            'lastUpdateTimestampString': null
        },
        'firstName': 'frstname',
        'lastName': 'LstNme',
        'stopNumber': null,
        'locationCode': null,
        'lastUpdateTimestamp': this.getCrrntDate()
    };

    constructor(public orderService: OrderService, public jbhGlobals: JBHGlobals) {
        // OrderDTO service
        this.subscription = this.orderService.getData().subscribe(sharedOrderData => {
            this.orderData = sharedOrderData;
        });

        // Using JBHGlobals services   // commentsLIST
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.mockInitialComments).subscribe(data => {
            this.loadCmnts = data;
        });

        // this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getInitialCommentsList + 2 + "/comments").subscribe(data => {
        //     this.loadCmnts = data;
        //     console.log(this.loadCmnts);
        // });

        // Using JBHGlobals services   // getComntType<-- service link  getCommentType
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getComntType).subscribe(data => {
            this.cmntTypes = data;
        });

        const StopParams = {
            orderID: 1,
            projection: 'viewstop'
        };

        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getStopNumId, StopParams).subscribe(data => {
            this.stopAndIds = data;
        });
    }

    ngAfterContentChecked() {
        // this.getCommentTypes();
        if (this.stopAndIds) { // Form loading OrderDto& Comments
            this.loadStopTags();
        }

        if (this.orderData.length !== 0) { // Form loading OrderDto& Comments
            this.orderNumber = this.orderData['orderID'];
        }

        if (this.loadCmnts.length !== 0) { // Form loading OrderDto& Comments
            this.loadCommentsList();
        }

        if (this.commentsTagDataDuplicate && this.commentsTagDataDuplicate.length > 1) {
            this.loadFilterOptns(); // To load filter Dropdown
        }

    }


    public loadStopTags() {

        if (this.stopAndIds.length !== 0 && this.stopTagsLoaded.toString() === false.toString()) {
            for (let i = 0; i < this.stopAndIds._embedded.stops.length; i++) {
                const stpNbr = this.stopAndIds._embedded.stops[i].stopSequenceNumber;
                // const stpId = this.stopAndIds._embedded.stops[i].stopID;
                this.commentsTagData.push('Stop ' + stpNbr);
                this.commentsFilter.push('Stop ' + stpNbr);
                this.commentsTagData = this.jbhGlobals.utils.uniq(this.commentsTagData);
                this.commentsFilter = this.jbhGlobals.utils.uniq(this.commentsFilter);
                this.stopTagsLoaded = true;
            }
        }

    }

    public loadCommentsList() {

        // Load Initial Comments for Stop&Order
        if (this.loadCmnts && this.loadCmnts._embedded.commentDToes.length !== 0 && this.stopsLoaded.toString() === false.toString()) {
            this.tempCmntArr = [];
            const ordStpCmnts = this.loadCmnts._embedded.commentDToes;
            this.tempCmntArr = ordStpCmnts;
            this.tmpCmntsListBakUp = this.tempCmntArr;
            this.stopsLoaded = true;
        }

        if (this.loadCmnts && this.filterLoaded.toString() === false.toString()) { // Filter DropDwnLoad
            for (let i = 0; i < this.loadCmnts._embedded.commentDToes.length; i++) {
                if (this.loadCmnts._embedded.commentDToes[i].stopNumber === null) {
                    this.commentsFilter.push('Order');
                    this.commentsFilter.push(this.loadCmnts._embedded.commentDToes[i].commentTypeDescription);
                } else {
                    this.commentsFilter.push('Stop' + ' ' + this.loadCmnts._embedded.commentDToes[i].stopNumber);
                    this.commentsFilter.push(this.loadCmnts._embedded.commentDToes[i].commentTypeDescription);
                }
            }
            const UniqueArr = this.jbhGlobals.utils.uniq(this.commentsFilter); // For filtering Duplicates
            this.commentsFilter = UniqueArr;
            this.filterLoaded = true;
        }

    }

    public loadFilterOptns() {

        // let cmntFltrLen = this.commentsTagDataDuplicate.length;
        //      this.commentsFilter=[];
        //      this.commentsFilter[0]="All Tags";
        // if (this.cmntFilterLoaded == false) {

        //         for (let i = 0; i < cmntFltrLen; i++) {
        //             this.commentsFilter.push(this.commentsTagDataDuplicate[i]);
        //         }
        //         for (let j = 0; j <  this.tempCmntArr.length; j++) {
        //             if(this.tempCmntArr) {
        //            this.commentsFilter.push(this.tempCmntArr[j]['commentTypeDescription']);
        //             }
        //         }

        //     this.cmntFilterLoaded = true;
        // }

    }

    public cmntFiltrOnSelect(event, currntVal, cmntFeedDiv) {
        this.tempCmntArr = this.tmpCmntsListBakUp;
        this.cmntArrBackUp2 = this.tempCmntArr;

        if (currntVal.toString() === 'All Tags') {
            this.tempCmntArr = this.tmpCmntsListBakUp;
        } else if (currntVal.toString() !== 'All Tags') {
            // const curVal = currntVal;
            // const newFltrArr = this.filterMethod(this.cmntArrBackUp2, curVal);
        }

    }

    public filterMethod(tempCmntArr, curSelVal) {
        this.filteredArr = [];
        const stpNumFilter = curSelVal.substring(curSelVal.length - 1, curSelVal.length);
        const selStpNumFilter = curSelVal.substring(0, 4).toLowerCase();

        if (curSelVal.toLowerCase().toString() === 'order') {
            for (let i = 0; i < tempCmntArr.length; i++) {
                if (tempCmntArr[i].stopNumber === null) {
                    this.filteredArr.push(tempCmntArr[i]);
                }
            }
            this.tempCmntArr = this.filteredArr;
        } else if (curSelVal.toString() === 'All Tags') {
            this.tempCmntArr = this.tmpCmntsListBakUp;
        } else if (curSelVal.toString() !== 'All Tags' && selStpNumFilter.toString()
         !== 'stop' && curSelVal.toLowerCase().toString() !== 'order') {
            for (let i = 0; i < tempCmntArr.length; i++) {
                if (tempCmntArr[i]['commentTypeDescription'].toString() === curSelVal.toString()) {
                    this.filteredArr.push(tempCmntArr[i]);
                }
            }
            this.tempCmntArr = this.filteredArr;
        } else {
            for (let j = 0; j < tempCmntArr.length; j++) {
                if (stpNumFilter.toString() === tempCmntArr[j]['stopNumber'].toString()) {
                    this.filteredArr.push(tempCmntArr[j]);
                }
            }
            this.tempCmntArr = this.filteredArr;
        }
        // return tempCmntArr.filter(tempCmntArr => tempCmntArr.commentLevelTypeCode == curSelVal);
    }

    public editCommentSection(index, cmntDivRef, primaryTag, remark, secondTag, cmntTxtArea) {

        const objIndex: number = index;
        const TmpFullArr = this.tempCmntArr[index];


        this.editIndex = this.tempCmntArr[index]['comment']['commentID'];

        // Getting Old Values
        const oldRemark: any = remark.innerHTML;
        let oldStopNumber: any; // Stop
        if (TmpFullArr['stopNumber'] == null) {
            oldStopNumber = 'Order';
        } else {
            oldStopNumber = 'Stop ' + TmpFullArr['stopNumber'];
        }
        const oldCommentTypeCode: any = TmpFullArr['commentTypeDescription']; // commentType

        // Setting Values For Editing
        this.currentCmntTags.push(oldStopNumber);
        this.currentCmntTags.push(oldCommentTypeCode);
        this.innerHtmlCmnt = oldRemark;

        this.tempCmntArr.splice(objIndex, 1); // deleting in cmntDTO
        this.editCall = true;

        // let stpNo: any = oldCommentLevelTypeCode.substring(5, 6); //deleting in stopDTO
        // for (let i = 0; i < this.orderData.stopDTOs.length; i++) {
        //     if (this.orderData.stopDTOs[i].stop.stopSequenceNumber == stpNo) {
        //         this.orderData.stopDTOs[i].stop.stopComments.splice(0, 1);
        //         this.stopsLoaded = false; // To reload the comments&Stops
        //     }
        // }

    }

    public getRemovedCmntVal(CurrentCmntValue, cmntTagRef) {

        this.cmmntSgtnsList = [];

        const stop = CurrentCmntValue.substring(0, 4).toLowerCase();
        if (CurrentCmntValue.toLowerCase().toString() === 'order') {
            this.cmntTagReference.autocompleteItems = this.commentsTagDataDuplicate;
        } else if (stop.toString() === 'stop') {
            this.currentCmntTags = [];
            this.cmntTagReference.autocompleteItems = this.commentsTagDataDuplicate;
        }
        if (CurrentCmntValue.toLowerCase().toString() !== 'order' && stop.toString() !== 'stop') {
            this.cmmntSgtnsList = [];
            if (this.cmntTypes) {
                const commentTypeObj = this.cmntTypes._embedded.commentTypes;
                this.commentsTagData = [];
                for (let i = 0; i <= commentTypeObj.length - 1; i++) { // For adding noOfStops
                    this.commentsTagData.push(commentTypeObj[i].commentTypeDescription);
                }
                this.cmntTagReference.autocompleteItems = this.commentsTagData;
            }
        }
    }

    public getCurrentCmntVal(CurrentCmntValue, cmntTagRef, cmntTxtArea) {
        this.cmntTagReference = cmntTagRef;
        const stop = CurrentCmntValue.substring(0, 4).toLowerCase();

        // Setting & getting commentTypes Frm Service.
        if (stop.toString() !== 'orde' && stop.toString() !== 'stop') {
            const params = {
                'commentTypeCode': CurrentCmntValue
            };

            this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.postCommentType, params).subscribe(data => {
                this.commentSuggestions = data;
                if (this.commentSuggestions.length !== 0) {
                    const cmntSgstnLen = this.commentSuggestions._embedded.commentTemplates.length;
                    if (cmntSgstnLen !== 0) {
                        for (let i = 0; i < cmntSgstnLen; i++) {
                            this.currntSuggstns.push(this.commentSuggestions._embedded.commentTemplates[i].commentText);
                        }
                    } else {
                        this.currntSuggstns = [];
                    }
                }

                this.cmmntSgtnsList = this.currntSuggstns;
            });

        } else {
            this.currntSuggstns = [];
        }
        // Setting & getting commentTypes Frm Service Ends.


        if (this.currentCmntTags.length === 2) {
            this.cmntTagReference.autocompleteItems = [];
        }
        if (CurrentCmntValue.toLowerCase().toString() === 'order') {
            this.orderAndStops.push(CurrentCmntValue);
            this.cmntTagReference.autocompleteItems = this.orderAndStops;

            //  -----------------
            if (this.cmntTypes) {
                const commentTypeObj = this.cmntTypes._embedded.commentTypes;
                this.commentsTagData = [];
                for (let i = 0; i <= commentTypeObj.length - 1; i++) {
                    this.commentsTagData.push(commentTypeObj[i].commentTypeDescription);
                }
                this.cmntTagReference.autocompleteItems = this.commentsTagData;
            } else {
                this.cmntTagReference.autocompleteItems = [];
            }
            // -------------------
        } else if (stop.toString() === 'stop') {

            if (this.cmntTypes) {
                const commentTypeObj = this.cmntTypes._embedded.commentTypes;
                this.commentsTagData = [];
                for (let i = 0; i < commentTypeObj.length; i++) {
                    this.commentsTagData.push(commentTypeObj[i].commentTypeDescription);
                }
                this.cmntTagReference.autocompleteItems = this.commentsTagData;
            }
        }

    }

    public getCrrntDate() {
        const date = new Date().toString(); // Getting Date
        const time = date.substring(16, 21);
        const mnth = date.substring(4, 7);
        const day = date.substring(8, 10);
        const yr = date.substring(11, 15);
        const crrDateField = time + ' AM ' + mnth + ' ' + day + ' ' + yr;
        return crrDateField;
    }

    public commentSave(commentsForm) {
        event.preventDefault();

        // const dateField = this.getCrrntDate();

        this.newComment = commentsForm.value.cmntSgVal;

        let newTag1: any;
        let newTag2: any = 'default';

        if (this.currentCmntTags[0]) {
            newTag1 = this.currentCmntTags[0];
            this.stopNum = newTag1.substring(newTag1.length - 1, newTag1.length);
        }
        if (this.currentCmntTags[1]) {
            newTag2 = this.currentCmntTags[1];
        }

        if (newTag1 !== undefined && newTag2 !== undefined && this.newComment !== undefined) {
            if (this.cmntTypes) {
                for (let i = 0; i < this.cmntTypes._embedded.commentTypes.length; i++) {
                    if (this.cmntTypes._embedded.commentTypes[i].commentTypeDescription === newTag2) {
                        this.newTag2Code = this.cmntTypes._embedded.commentTypes[i].commentTypeCode;
                    }
                }
            }

            if (newTag1.toLowerCase().toString() === 'order' && this.editCall.toString() === false.toString()) { // For Saving OrderCmnts

                const OrdrParams = {
                    'order': '/' + this.orderNumber,
                    'commentID': '',
                    'remark': this.newComment,
                    'commentTypeCode': this.newTag2Code,
                    'location': ''
                };

                this.jbhGlobals.apiService.addData(this.jbhGlobals.endpoints.order.postOrderComments, OrdrParams).subscribe(data => {
                    this.orderObjResponce = data; // responce data
                    // console.log( this.orderObjResponce + "new added");
                    this.TmpObjCmnt.comment.commentTypeCode = this.orderObjResponce.commentTypeCode;
                    this.TmpObjCmnt.comment.lastUpdateTimestampString = this.orderObjResponce.lastUpdateTimestampString;
                    this.TmpObjCmnt.comment.commentID = this.orderObjResponce.commentID;
                    this.TmpObjCmnt.comment.remark = this.orderObjResponce.remark;
                    this.TmpObjCmnt.commentTypeDescription = this.newTag2Code;
                    this.TmpObjCmnt.comment.commentLevelTypeCode = 'Order';
                    this.tempCmntArr.push(this.TmpObjCmnt);
                    this.filterLoaded = false;
                    // this.tempCmntArr = [];
                    // let combinedArr = this.jbhGlobals.utils.concat(,this.orderObjResponce);
                });
            } else if (newTag1.substring(0, 4).toLowerCase().toString() === 'stop'
             && this.editCall.toString() === false.toString()) {

                if (this.stopNum) {
                    for (let i = 0; i < this.stopAndIds._embedded.stops.length; i++) {
                        const stpNbr = this.stopAndIds._embedded.stops[i].stopSequenceNumber;
                        if (this.stopNum.toString() === stpNbr.toString()) {
                            console.log(this.stopNum + '-');
                            console.log(stpNbr);
                            this.stopIdEdt = this.stopAndIds._embedded.stops[i].stopID;
                        }

                    }
                }
                const StopParams = {
                    'remark': this.newComment,
                    'commentTypeCode': this.newTag2Code,
                    'location': null,
                    'stop': '/' + this.stopIdEdt, // stop ID /
                    'order': '/' + this.orderNumber
                };

                this.jbhGlobals.apiService.addData(this.jbhGlobals.endpoints.order.postStopComments, StopParams).subscribe(data => {
                    this.stopObjResponce = data;
                    this.TmpObjCmnt.comment.commentTypeCode = this.stopObjResponce.commentTypeCode;
                    this.TmpObjCmnt.comment.lastUpdateTimestampString = this.stopObjResponce.lastUpdateTimestampString;
                    this.TmpObjCmnt.comment.commentID = this.stopObjResponce.commentID;
                    this.TmpObjCmnt.comment.remark = this.stopObjResponce.remark;
                    this.TmpObjCmnt.commentTypeDescription = this.newTag2Code;
                    this.TmpObjCmnt.comment.commentLevelTypeCode = 'STOP';
                    this.tempCmntArr.push(this.TmpObjCmnt);
                    this.filterLoaded = false;
                });
            }


            // Edit Coments Logic
            if (newTag1.toLowerCase().toString() === 'order' && this.editCall.toString() === true.toString()) {

                const OrdrParams = {
                    'order': '/' + this.orderNumber,
                    'remark': this.newComment,
                    'commentTypeCode': this.newTag2Code,
                    'location': ''
                };
                // "commentID": this.editIndex,
this.jbhGlobals.apiService.updateData(this.jbhGlobals.endpoints.order.updateOrderComments +
            '/' + this.editIndex, OrdrParams).subscribe(data => {
            this.orderObjResponce = data; // responce data
            this.TmpObjCmnt.comment.commentTypeCode = this.orderObjResponce.commentTypeCode;
            this.TmpObjCmnt.comment.lastUpdateTimestampString = this.orderObjResponce.lastUpdateTimestampString;
            this.TmpObjCmnt.comment.commentID = this.orderObjResponce.commentID;
            this.TmpObjCmnt.comment.remark = this.orderObjResponce.remark;
            this.TmpObjCmnt.commentTypeDescription = this.newTag2Code;
            this.TmpObjCmnt.commentLevelTypeCode = 'Order';
            this.tempCmntArr.push(this.TmpObjCmnt);
            this.editCall = false;
            this.filterLoaded = false;
        });
            } else if (newTag1.substring(0, 4).toLowerCase().toString() === 'stop' && this.editCall.toString() === true.toString()) {
                // const delCmntId = this.tempCmntArr[this.editIndex]['comment']['commentID'];

                if (this.stopNum) {
                    for (let i = 0; i < this.stopAndIds._embedded.stops.length; i++) {
                        const stpNbr = this.stopAndIds._embedded.stops[i].stopSequenceNumber;
                        if (this.stopNum === stpNbr) {
                            console.log(this.stopNum + '-');
                            console.log(stpNbr);
                            this.stopIdEdt = this.stopAndIds._embedded.stops[i].stopID;
                        }

                    }
                }

                const StopParams = {
                    'remark': this.newComment,
                    'commentTypeCode': this.newTag2Code,
                    'location': null,
                    'stop': '/' + this.stopIdEdt,
                    'order': '/' + this.orderNumber
                };
    this.jbhGlobals.apiService.updateData(this.jbhGlobals.endpoints.order.updateStopComments +
     '/' + this.editIndex, StopParams).subscribe(data => {
        this.stopObjResponce = data;
        this.TmpObjCmnt.comment.commentTypeCode = this.stopObjResponce.commentTypeCode;
        this.TmpObjCmnt.comment.lastUpdateTimestampString = this.stopObjResponce.lastUpdateTimestampString;
        this.TmpObjCmnt.comment.commentID = this.stopObjResponce.commentID;
        this.TmpObjCmnt.comment.remark = this.stopObjResponce.remark;
        this.TmpObjCmnt.commentTypeDescription = this.newTag2Code;
        this.TmpObjCmnt.commentLevelTypeCode = 'STOP';
        this.tempCmntArr.push(this.TmpObjCmnt);
        this.editCall = false;
        this.filterLoaded = false;

    });
            }

            commentsForm.reset(); // Resetting commentsForm
            this.currentCmntTags = []; // Resetting TagField
            this.commentsTagData = []; // Resetting TagField
            this.commentsTagData = this.commentsTagDataDuplicate; // Resetting TagFieldD
            this.tmpCmntsListBakUp = this.tempCmntArr; // Resetting TagFieldD
            this.loadFilterOptns(); // for loading filterDropDwn
            this.cmntFilterLoaded = false; // for loading filterDropDwn

        } else {
            alert('Tags & Comments cannot be Empty.');
        }

    }

    public editEnableVerify(stopCmnts) {
        this.selectedCmntDiv = stopCmnts;
    }

    public delCommentSection(i, cmntDivRef, primaryTag, remark, secondTag, cmntTxtArea, stopCmntsi) {
        this.selectedCmntDivv = i;
    }

    public undoDelCommentSection(i) {
        this.selectedCmntDivv = null;
    }

    public cmntPmntDel(indx, cmntDivRef, primaryTag, remark, secondTag, cmntTxtArea) {

        const objIndex: number = indx;
        const TmpFullArr = this.tempCmntArr[indx];

        if (TmpFullArr['comment']['commentLevelTypeCode'].toLowerCase().toString() === 'order') {
            const delCmntId = this.tempCmntArr[indx]['comment']['commentID'];
            this.jbhGlobals.apiService.removeData(this.jbhGlobals.endpoints.order.delOrderComments + '/' + delCmntId).subscribe(data => {});
            this.tempCmntArr.splice(objIndex, 1); // deleting in cmntDTO
        } else if (TmpFullArr['comment']['commentLevelTypeCode'].substring(0, 4).toLowerCase().toString() === 'stop') {
            const delCmntId = this.tempCmntArr[indx]['comment']['commentID'];
            this.jbhGlobals.apiService.removeData(this.jbhGlobals.endpoints.order.delStopComments +
             '/' + delCmntId).subscribe(data => {});
            this.tempCmntArr.splice(objIndex, 1); // deleting in cmntDTO
        }


    }


}



