import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddStopsComponent } from './add-stops.component';
import { TypeaheadModule } from 'ngx-bootstrap/typeahead';

const routes: Routes = [{path: '', component: AddStopsComponent}];

@NgModule({
  imports: [
  TypeaheadModule.forRoot(),
  RouterModule.forChild(routes)
  ],
  exports: [RouterModule],
  providers: []
})
export class AddStopsRoutingModule { }
