import {
  NgModule
} from '@angular/core';
import {
  Routes,
  RouterModule
} from '@angular/router';
import {
  OrdersComponent
} from './orders.component';
import {
  CreateComponent
} from './create/create.component';
import {
  AddStopsComponent
} from './add-stops/add-stops.component';
import {
  StandardsComponent
} from './standards/standards.component';
import {
  OrderShippingOptionsComponent
} from './order-shipping-options/order-shipping-options.component';

const routes: Routes = [{
  path: '',
  component: OrdersComponent,
  pathMatch: '?',
  children: [{
    path: 'create',
    component: CreateComponent
  },
  {
    path: 'addstops',
    component: AddStopsComponent
  },
  {
    path: 'ordershippingoptions',
    component: OrderShippingOptionsComponent
  },
  {
    path: 'standards',
    component: StandardsComponent

  }
  ]
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: []
})
export class OrdersRoutingModule { }
