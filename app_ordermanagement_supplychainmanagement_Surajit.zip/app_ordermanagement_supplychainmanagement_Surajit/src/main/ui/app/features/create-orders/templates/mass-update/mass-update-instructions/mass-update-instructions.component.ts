import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { JBHGlobals } from '../../../../../app.service';
import { TemplateService } from './../../template.service';
import { FormBuilder, FormGroup, FormArray, Validators } from '@angular/forms';
@Component({
  selector: 'app-mass-update-instructions',
  templateUrl: './mass-update-instructions.component.html',
  styleUrls: ['./mass-update-instructions.component.scss']
})
export class MassUpdateInstructionsComponent implements OnInit {

    public templateIds: any[] = [];

    public massInsRows: any[] = [];

    public instructionsTypeList: any[] = [{
            'id': 'order',
            'name': 'Order'
        },
        {
            'id': 'billing',
            'name': 'Billing'
        },
        {
            'id': 'equipment',
            'name': 'Loading/Equipment'
        },
        {
            'id': 'stop',
            'name': 'Stop'
        },
        {
            'id': 'facility',
            'name': 'Facility Contact Information'
        },
        {
            'id': 'location',
            'name': 'Location Directions'
        }
    ];

    public selectedInsRow;

    public massExistingInstructions: any[] = [];

    public removedExistingList: any[] = [];

    public insform: FormGroup;

    public errorInfo: any = {
        'message': 'Please review the newly added instruction, that needs your attention.'
    };

    constructor(public router: Router, public jbhGlobals: JBHGlobals, public ts: TemplateService, public fb: FormBuilder) {
        // initialize form with empty FormArray for payOffs
        this.insform = new FormGroup({
            newInsArr: new FormArray([])
        });
    }

    ngOnInit() {
        if (this.ts.massUpdateTemplateIds.length) {
            this.templateIds = this.ts.massUpdateTemplateIds;

            this.ts.massUpdateTemplateIds = [];
            console.log(this.templateIds);
            this.getExistingMassUpdateIns();


        } else {
            this.redirectToGridPage();
        }
    }
    public getExistingMassUpdateIns(): void {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.template.getMassUpdateIns).subscribe(data => {
            this.massExistingInstructions = data['insdetails'];
        });
    }

    public addMassUpdateInstructions(): void {
        if (this.insform.valid) {
            const newInsRow = {
                'additionalInstructionType': '',
                'additionalInstructionDescription': ''
            };
            // create a new form group and add it to form array
            const newInsGroup = this.fb.group({
                instype: ['', Validators.required],
                insdesc: ['', Validators.required]
            });
            const insformarr = < FormArray > this.insform.controls['newInsArr'];

            this.massInsRows.push(newInsRow);

            insformarr.push(newInsGroup);
        } else {
            this.jbhGlobals.notifications.error('Review Instructions', this.errorInfo.message);
        }
    }

    public onFieldRowSelected(item: any): void {
        if (this.selectedInsRow !== item) {
            this.selectedInsRow = item;
        }
    }

    //    public onInstructionTypeSelection($event): void {
    //        this.selectedInsRow.additionalInstructionType = $event.target.value;
    //    }
    //
    //    public onInstructionDescChange($event): void {
    //        this.selectedInsRow.additionalInstructionDescription = $event.target.value;
    //    }

    public removeInsItem(delItem, indx): void {
        const insformarr = < FormArray > this.insform.controls['newInsArr'];
        insformarr.removeAt(indx);

        this.massInsRows = this.massInsRows.filter(item => item !== delItem);
    }

    public removeExistingIns(delItem): void {
        this.removedExistingList.push(delItem);
        this.massExistingInstructions = this.massExistingInstructions.filter(item => item !== delItem);
    }

    public updateInstructions(): void {
        const reqObj = {
            'templateId': [],
            'addedIntructions': [],
            'removedIntructions': []
        };

        reqObj.templateId = this.templateIds;
        reqObj.addedIntructions = this.massInsRows;
        reqObj.removedIntructions = this.removedExistingList;

        console.log(reqObj);
        // console.log(this.insform.valid)
        // console.log(this.massInsRows)
    }

    public redirectToGridPage(): void {
        this.router.navigateByUrl('/createorders');
    }

}
