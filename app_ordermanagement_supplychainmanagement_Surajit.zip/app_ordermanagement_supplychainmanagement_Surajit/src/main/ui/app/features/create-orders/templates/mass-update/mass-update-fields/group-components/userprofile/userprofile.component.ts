import { Component, OnInit } from '@angular/core';
// import {FormBuilder, FormGroup, Validators, FormControl} from '@angular/forms';
import { JBHGlobals } from 'app/app.service';
@Component({
  selector: 'app-userprofile',
  templateUrl: './userprofile.component.html',
  styleUrls: ['./userprofile.component.scss']
})
export class UserprofileComponent implements OnInit {

    public typeAheadList: any[] = [];

    constructor(public jbhGlobals: JBHGlobals) {}

    ngOnInit() {}

    public getBillToTypeAhead(value, billToPartyType) {
        const params = {
            value: value,
            roletype: billToPartyType,
            active: 'yes',
            page: 0,
            size: 5,
            approved: true,
            addresstype: 'FREIGHT BILL'
        };

        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.gettypeaheadbillto, params, false).subscribe(data => {
            this.typeAheadList = [];
            this.typeAheadList.push(data['profileDTO']);
        });
    }
    public typeaheadOnSelect(eve) {
        // this.billtocode = eve.item.code;
        //        this.billtopartytype = 'Bill To';
        //        this.billtoaddressvalue = eve.item.name + '-' + eve.item.addressDTO.addressline1 + 
        //        ' ' + eve.item.addressDTO.addressline2 +
        //        ',' + eve.item.addressDTO.city + ' ' + eve.item.addressDTO.cityID + ' ' + eve.item.addressDTO.country +
        //        ' ' + eve.item.addressDTO.state + ' ' + eve.item.addressDTO.zipcode;
        //        this.typeaheadModule['controls']['billToCode']['setValue'](this.billtoaddressvalue);
        //
        //        this.typeaheadModule['controls']['contactTypeCode'].setValidators([Validators.required]);
        //        this.typeaheadModule['controls']['contactTypeCode'].updateValueAndValidity();

        //        this.onSelectbilltoaddress(this.billtocode, this.billtopartytype);

        //        this.typeaheadModule['controls']['lineofBusiness']['setValue']('');
        //        this.typeaheadModule['controls']['lineofbusinessContact']['setValue']('');

        //        if (this.orderData['orderBillingDetailDTOs'].length === 0) {
        //            console.log('len lob');
        //            const orderDto = {
        //                'profileDTO': {
        //                    'partyID': eve.item.id
        //                },
        //                'lineOfBusinessCode': null
        //            };
        //            this.orderData['orderBillingDetailDTOs'].push(orderDto);
        //        } else {
        //            this.orderData['orderBillingDetailDTOs'][0].profileDTO.partyID  = eve.item.id;
        //            this.orderData['orderBillingDetailDTOs'][0].lineOfBusinessCode = null;
        //        }
        //  this.orderData['orderBillingDetailDTOs'][0].profileDTO.partyID  = eve.item.code;
        //  this.orderData['orderBillingDetailDTOs'][0].profileDTO.lineOfBusinessCode = null;
        //        this.orderService.saveData(this.orderData);
        //        console.log('hi rohan check here for data', this.orderData);
    }
}
