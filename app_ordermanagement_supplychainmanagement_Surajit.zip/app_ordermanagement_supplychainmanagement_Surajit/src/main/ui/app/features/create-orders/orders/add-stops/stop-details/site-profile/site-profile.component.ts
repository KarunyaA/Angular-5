import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { FormBuilder } from '@angular/forms';

import { JBHGlobals } from '../../../../../../app.service';
import { OrderService } from '../../../order.service';
import { OrderFormBuilder } from '../../../order-form-builder.service';

@Component({
  selector: 'app-site-profile',
  templateUrl: './site-profile.component.html',
  styleUrls: ['./site-profile.component.scss']
})
export class SiteProfileComponent implements OnInit {
  @Input() siteProfile: any;
  @ViewChild('siteProfileModal') siteProfileModal: any;
  public siteProfileList: any[] = [];
  public facilityHoursList: any[] = [];
  public daysofweekList: string[] = [];
  public facilityoperatingDetailsList: any[] = [];
  public siteRequirementList: any[] = [];
  public isEditInstructionsFlag = false;
  public isEditInstructionsFlagValueChange = false;
  public isEditDirectionsFlag = false;
  public isEditDirectionsFlagValueChange = false;
  public generalInstructionValue: any = '';
  public directionValue: any = '';

  constructor( public jbhGlobals: JBHGlobals,
    public formBuilder: FormBuilder,
    public orderService: OrderService,
    public orderFormBuilder: OrderFormBuilder ) {  }

  ngOnInit() {
     this.siteProfile = this.orderFormBuilder.orderForm['controls']['siteProfile'];
  }

  // service call
  public loadLocationProfile() {
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getlocationprofile).subscribe( data => {
         this.siteProfileList = data['locationProfileDTO'];
         this.facilityHoursList = this.siteProfileList[0].facilityOperationDTO;
         this.siteRequirementList = this.siteProfileList[0].facilityOverviewRequirementCodeDTO;
         for (let i = 0; i < this.facilityHoursList.length; i++) {
           this.daysofweekList.push(this.facilityHoursList[i].day);
           this.facilityoperatingDetailsList.push(this.facilityHoursList[i].facilityOperatingHourDTO[0]);
         }
        }
      );
  }

  public onShowSiteProfileModal() {
    this.siteProfileModal.show();
    this.loadLocationProfile();
  }

  public onClickSiteProfileHide() {
    this.siteProfileModal.hide();
  }

  public onEditDirections() {
    this.siteProfile['controls']['customerDirections'].setValue(this.siteProfileList[0].customerDirections);
    this.isEditDirectionsFlag = true;
  }

  public onEditGeneralInstructions() {
    this.siteProfile['controls']['generalInstructions'].setValue(this.siteProfileList[0].generalInstructions);
    this.isEditInstructionsFlag = true;
  }

  public onSaveGeneralInstructions() {
    const params = {
      'locationProfileDTO': {
        'generalInstructionDTO': this.siteProfile['controls']['generalInstructions'].value,
        'locationId': this.siteProfileList[0].locationCode
      }
    };
    this.jbhGlobals.apiService.updateData(this.jbhGlobals.endpoints.order.savegeneralinstructions, params).subscribe( data => {
        this.generalInstructionValue = data['locationProfileDTO']['generalInstructionDTO'];
    });

    this.isEditInstructionsFlag = false;
    this.isEditInstructionsFlagValueChange = true;
  }

  public onSaveDirections() {
    const params = {
      'locationProfileDTO': {
        'customerDirection': {
          'direction': this.siteProfile['controls']['customerDirections'].value,
          'locationId': this.siteProfileList[0].locationCode
        }
      }
    };
    this.jbhGlobals.apiService.updateData(this.jbhGlobals.endpoints.order.savecustomerdirections, params).subscribe( data => {
        this.directionValue = data['locationProfileDTO']['customerDirection']['direction'];
    });
    this.isEditDirectionsFlag = false;
    this.isEditDirectionsFlagValueChange = true;
  }
}
