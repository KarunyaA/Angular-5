// declare module namespace {

export interface Chronology {
  id: string;
  calendarType: string;
}

export interface LastUpdateTimestampString {
  month: string;
  year: number;
  dayOfMonth: number;
  dayOfWeek: string;
  dayOfYear: number;
  monthValue: number;
  hour: number;
  minute: number;
  nano: number;
  second: number;
  chronology: Chronology;
}

export interface OrderType {
  orderTypeCode: string;
  orderTypeDescription: string;
  effectiveTimestamp: string;
  expirationTimestamp: Date;
  lastUpdateTimestampString: LastUpdateTimestampString;
}

export interface Chronology2 {
  id: string;
  calendarType: string;
}

export interface LastUpdateTimestampString2 {
  month: string;
  year: number;
  dayOfMonth: number;
  dayOfWeek: string;
  dayOfYear: number;
  monthValue: number;
  hour: number;
  minute: number;
  nano: number;
  second: number;
  chronology: Chronology2;
}

export interface Self {
  href: string;
}

export interface OrderTypeFinanceBusinessUnitServiceOfferingAssociation {
  href: string;
}

export interface Links {
  self: Self;
  orderTypeFinanceBusinessUnitServiceOfferingAssociation: OrderTypeFinanceBusinessUnitServiceOfferingAssociation;
}

export interface IOrderTypeModel {
  orderTypeFinanceBusinessUnitServiceOfferingAssociationID: number;
  serviceOfferingCode: string;
  financeBusinessUnitCode: string;
  orderType: OrderType;
  effectiveTimestamp: string;
  expirationTimestamp: Date;
  lastUpdateTimestampString: LastUpdateTimestampString2;
  _links: Links;
}

export class OrderTypeModel implements IOrderTypeModel {
  orderTypeFinanceBusinessUnitServiceOfferingAssociationID: number;
  serviceOfferingCode: string;
  financeBusinessUnitCode: string;
  orderType: OrderType;
  effectiveTimestamp: string;
  expirationTimestamp: Date;
  lastUpdateTimestampString: LastUpdateTimestampString2;
  _links: Links;
}

// }

