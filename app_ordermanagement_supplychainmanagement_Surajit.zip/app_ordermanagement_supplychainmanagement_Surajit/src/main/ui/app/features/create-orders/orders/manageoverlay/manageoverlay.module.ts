import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ManageoverlayRoutingModule } from './manageoverlay-routing.module';
import { ManageoverlayComponent } from './manageoverlay.component';
import { ReferenceComponent } from './reference/reference.component';
import { ChargesComponent } from './charges/charges.component';
import { CommentsComponent } from './comments/comments.component';
import { InstructionsComponent } from './instructions/instructions.component';
import { DocumentsComponent } from './documents/documents.component';
import { FormsModule, ReactiveFormsModule  } from '@angular/forms';
import { RlTagInputModule } from '../../../../shared/tag-input';
import { OrderService } from './../order.service';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { TagInputModule } from 'ng2-tag-input';
import { TypeaheadModule } from 'ngx-bootstrap/typeahead';
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
import { JbhUtilsModule } from '../../../../shared/jbh-utils/jbh-utils.module';
import { SafepipeModule } from 'app/shared/safepipe/safepipe.module';


@NgModule({
  imports: [
    TabsModule.forRoot(),
    CommonModule,
    ManageoverlayRoutingModule,
    FormsModule,
    PerfectScrollbarModule,
    TagInputModule,
    SafepipeModule,
    ReactiveFormsModule,
    RlTagInputModule,
    JbhUtilsModule,
    TypeaheadModule.forRoot()
  ],
  declarations: [ ManageoverlayComponent,
                  CommentsComponent,
                  ReferenceComponent,
                  ChargesComponent,
                  InstructionsComponent,
                  DocumentsComponent ],
  exports: [ ManageoverlayComponent,
             CommentsComponent,
             ReferenceComponent,
             ChargesComponent,
             InstructionsComponent,
             DocumentsComponent ]
})
export class ManageoverlayModule { }
