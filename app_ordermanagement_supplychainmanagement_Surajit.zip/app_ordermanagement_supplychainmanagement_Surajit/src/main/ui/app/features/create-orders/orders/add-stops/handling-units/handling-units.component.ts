import { Component, OnInit, Input, ChangeDetectorRef, ViewChild, ViewChildren, QueryList } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { JBHGlobals } from '../../../../../app.service';
import { OrderService } from '../../order.service';
import { OrderFormBuilder } from '../../order-form-builder.service';
import { ItemDetailsComponent } from '../item-details/item-details.component';

@Component({
  selector: 'app-handling-units',
  templateUrl: './handling-units.component.html',
  styleUrls: ['./handling-units.component.scss']
})
export class HandlingUnitsComponent implements OnInit {
  public handlingDimensionFlag = true;
  @Input() handlingForm: any;
  @Input() indx: any;
  public itemHanlingUnitList: any[]= [];
  public handlingUnitArray: any[] = [];
  public itemWeightList: any[] = [];
  public itemLengthList: any[] = [];
  public handlingReferenceList: any[] = [];
  public handlingDetails: any;
  subscription: any;
  orderData: any;
  public handlingUnitDensity: any;
  public debounceValue: any;
  public volumeVal: any;
  public handlingVolume: any;
  public handlingUnitVolume: any;
  public handlingVolumeVal: any;
  public handlingDensityVal: any;
  public referenceObject: any = {};
  public stopId: any;
  public handlingUnitId: number;
  public deleteFlag = false;
  public flatbedFlag = false;
  public enableItemDiv = true;
  public handlingDataPopulation: any;
  @ViewChild('handlingDiv') handlingDiv: any;
  @ViewChildren(ItemDetailsComponent) itemComponent: QueryList<ItemDetailsComponent>;

  constructor(public jbhGlobals: JBHGlobals,
              public formBuilder: FormBuilder,
              public orderService: OrderService,
              public orderFormBuilder: OrderFormBuilder,
              public changeDetector: ChangeDetectorRef) { }

   ngOnInit() {
      this.loadOrderData();
      this.loadHandlingUnit();
      this.loadHandlingWeight();
      this.loadUnitofLength();
      this.loadHandlingReference();
      this.handlingForm = this.orderFormBuilder.addHandlingUnit();
      this.handlingDetails = this.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx].itemHandlingDetail;
      if (!this.handlingUnitId) {
        this.handlingForm.controls['itemHandlingTypeCode'].setValue('Pallet');
        this.handlingForm.controls['itemHandlingTypeQuantity'].setValue(1);
        this.handlingForm.controls['unitOfLengthMeasurementCode'].setValue('Inches');
        this.handlingForm.controls['unitOfWeightMeasurementCode'].setValue('Pounds');
        this.handlingDetails.itemHandlingTypeCode = 'Pallet';
        this.handlingDetails.itemHandlingTypeQuantity = 1;
        this.handlingDetails.unitOfLengthMeasurementCode = 'Inches';
        this.handlingDetails.unitOfWeightMeasurementCode = 'Pounds';
      }
      this.debounceValue = this.jbhGlobals.settings.debounce;
          this.handlingForm.controls['itemHandlingUnitLength']['valueChanges']
                .debounceTime(this.debounceValue)
                      .distinctUntilChanged()
                      .subscribe((handlinglength) => {
                           if (handlinglength) {
                              this.handlingForm.controls['itemHandlingUnitLength'].setValue(handlinglength);
                              this.calculateVolume();
                              this.calculateDensity();
                              this.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx].itemHandlingDetail
                              .itemHandlingUnitLength = handlinglength;
                           } else {
                              this.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx].itemHandlingDetail.itemHandlingUnitLength = '';
                              this.setMeasurementEmpty();
                           }
                          this.setHandlingDivFocus();
                      }, (err: Error) => {
                        console.log(err);
           });
           this.handlingForm.controls['itemHandlingUnitWidth']['valueChanges']
                .debounceTime(this.debounceValue)
                      .distinctUntilChanged()
                      .subscribe((width) => {
                          if (width) {
                              this.handlingForm.controls['itemHandlingUnitWidth'].setValue(width);
                              this.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx].itemHandlingDetail.itemHandlingUnitWidth = width;
                              this.calculateVolume();
                              this.calculateDensity();
                          } else {
                              this.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx].itemHandlingDetail.itemHandlingUnitWidth = '';
                              this.setMeasurementEmpty();
                           }
                          this.setHandlingDivFocus();
                      }, (err: Error) => {
                        console.log(err);
           });
       this.handlingForm.controls['itemHandlingUnitHeight']['valueChanges']
                .debounceTime(this.debounceValue)
                      .distinctUntilChanged()
                      .subscribe((heigth) => {
                          if (heigth) {
                              this.handlingForm.controls['itemHandlingUnitHeight'].setValue(heigth);
                              this.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx].itemHandlingDetail.itemHandlingUnitHeight = heigth;
                              this.calculateVolume();
                              this.calculateDensity();
                          } else {
                              this.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx].itemHandlingDetail.itemHandlingUnitHeight = '';
                              this.setMeasurementEmpty();
                           }
                          this.setHandlingDivFocus();
                      }, (err: Error) => {
                        console.log(err);
           });

         this.handlingForm.controls['unitOfLengthMeasurementCode']['valueChanges']
                .debounceTime(this.debounceValue)
                      .distinctUntilChanged()
                      .subscribe((unit) => {
                           if (unit.length > 0) {
                              this.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx]
                              .itemHandlingDetail.unitOfLengthMeasurementCode = unit;
                              this.calculateVolume();
                              this.calculateDensity();
                           } else {
                               this.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx]
                               .itemHandlingDetail.unitOfLengthMeasurementCode = '';
                               this.setMeasurementEmpty();
                           }
                          this.setHandlingDivFocus();
                      }, (err: Error) => {
                        console.log(err);
           });
            this.handlingForm.controls['itemHandlingUnitWeight']['valueChanges']
                .debounceTime(this.debounceValue)
                      .distinctUntilChanged()
                      .subscribe((weight) => {
                          if (weight) {
                              this.handlingForm.controls['itemHandlingUnitWeight'].setValue(parseFloat(weight));
                              this.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx].itemHandlingDetail.itemHandlingUnitWeight = weight;
                              if (this.handlingDimensionFlag) {
                                  this.calculateVolume();
                                  this.calculateDensity();
                              }
                              this.calculateVolumeConversion();
                           } else {
                                this.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx].itemHandlingDetail.itemHandlingUnitWeight = '';
                                this.handlingUnitDensity = '';
                           }
                          this.setHandlingDivFocus();
                      }, (err: Error) => {
                        console.log(err);
           });
        this.handlingForm.controls['unitOfWeightMeasurementCode']['valueChanges']
                .debounceTime(this.debounceValue)
                      .distinctUntilChanged()
                      .subscribe((weightunit) => {
                          if (weightunit.length > 0) {
                              this.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx]
                              .itemHandlingDetail.unitOfWeightMeasurementCode = weightunit;
                              if (this.handlingDimensionFlag) {
                                  this.calculateVolume();
                                  this.calculateDensity();
                              }
                              this.calculateVolumeConversion();
                          } else {
                                this.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx]
                                .itemHandlingDetail.unitOfWeightMeasurementCode = '';
                                this.handlingUnitDensity = '';
                          }
                          this.setHandlingDivFocus();
                      }, (err: Error) => {
                      console.log(err);
           });
           this.handlingForm.controls['itemHandlingUnitVolume']['valueChanges']
                .debounceTime(this.debounceValue)
                      .distinctUntilChanged()
                      .subscribe((itemVolume) => {
                          if (itemVolume) {
                              this.handlingVolumeVal = itemVolume + 'kg/m3';
                              this.handlingForm['controls']['unitOfVolumeMeasurementCode'].setValue('Cubic CM');
                              this.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx]
                              .itemHandlingDetail.itemHandlingUnitVolume = itemVolume;
                              this.calculateVolumeConversion();
                          } else {
                              this.handlingVolumeVal = '';
                              this.handlingDensityVal = '';
                              this.handlingVolume = '';
                              this.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx].itemHandlingDetail.itemHandlingUnitVolume = '';
                          }
                          this.setHandlingDivFocus();
                      }, (err: Error) => {
                        console.log(err);
           });
          this.handlingForm.controls['itemHandlingTypeCode']['valueChanges']
                .debounceTime(this.debounceValue)
                      .distinctUntilChanged()
                      .subscribe((value) => {
                          if (value.length > 0) {
                             this.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx]
                             .itemHandlingDetail.itemHandlingTypeCode = value;
                          } else {
                              this.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx]
                              .itemHandlingDetail.itemHandlingTypeCode = '';
                          }
                          this.setHandlingDivFocus();
                      }, (err: Error) => {
                        console.log(err);
           });
          this.handlingForm.controls['itemHandlingTypeQuantity']['valueChanges']
                    .debounceTime(this.debounceValue)
                          .distinctUntilChanged()
                          .subscribe((value) => {
                              if (value) {
                                 this.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx].
                                 itemHandlingDetail.itemHandlingTypeQuantity = value;
                              } else {
                                  this.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx].
                                  itemHandlingDetail.itemHandlingTypeQuantity = '';
                              }
                              this.setHandlingDivFocus();
                          }, (err: Error) => {
                            console.log(err);
               });
    }

   public loadOrderData() {
       if (this.jbhGlobals.utils.isEmpty(this.orderData)) {
       this.orderService.getData().subscribe( sharedOrderData => {
            this.orderData = sharedOrderData;
             this.onBusinessUnitBased();
            this.stopId = this.orderData.stopDTOs.stop.stopID;
            this.handlingDataPopulation = this.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx].itemHandlingDetail;
            this.handlingUnitId = this.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx].itemHandlingDetail.itemHandlingDetailID;
            if (this.stopId && this.handlingUnitId) {
              this.enableItemDiv = true;
              this.populateData(this.handlingDataPopulation);
            }
        });
      }
  }

    public onBusinessUnitBased() {
     switch (this.orderData.financeBusinessUnitCode) {
         case 'DCS':
             this.onServiceOfferingBased();
             break;
         case 'IC':
             this.onServiceOfferingBased();
             break;
         case 'JBI':
             this.onServiceOfferingBased();
             break;
         case 'JBT':
             this.onServiceOfferingBased();
             break;
         default:
             break;
     }
    }
   public onServiceOfferingBased() {
     switch (this.orderData.serviceOfferingCode) {
         /*case "Final Mile":
             this.dcsFlag = true;
             break;
         case "LTL Dir":
             this.icsLTLFlag = true;
             break;
         case "LTL Cons":
             this.icsLTLFlag = true;
             break;*/
         case 'Flatbed':
             this.flatbedFlag = true;
             break;
         default:
             break;
     }
    }
  public setMeasurementEmpty() {
        this.handlingForm.controls['itemHandlingUnitVolume'].setValue('');
        this.handlingForm.controls['itemHandlingUnitDensity'].setValue('');
        this.handlingUnitDensity = '';
        this.handlingUnitVolume = '';
        this.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx].itemHandlingDetail.itemHandlingUnitVolume = '';
        this.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx].itemHandlingDetail.itemHandlingUnitDensity  = '';
    }
   public formSaveCall() {
     this.itemComponent.last.itemFormSaveCall();
     const itemHandlingDetailForm = this.handlingForm;
     if (itemHandlingDetailForm['valid'] && itemHandlingDetailForm['dirty']) {
         const form = this.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx].itemHandlingDetail;
         const handlingUnitId = form.itemHandlingDetailID;
         form['itemHandlingDetailID'] = handlingUnitId;
         if (!handlingUnitId && this.stopId) {
            this.formSaveServiceCall(form, this.stopId);
         } else if (handlingUnitId && this.stopId) {
            this.formUpdateServiceCall(form, handlingUnitId, this.stopId);
         }
      }
   }
   public formSaveServiceCall(form, stopId) {
      const params = form;
      const url = this.jbhGlobals.endpoints.order.crudHandlingUnit + '/' + stopId + '/itemhandlingdetails';
      this.jbhGlobals.apiService.addData(url, params, false).subscribe( data => {
             delete data['@id'];
             delete data['lastUpdateTimestampString'];
             delete data['stopItems'];
             const response = data;
             this.saveHandlingResponseToOrder(response);
      }, (err: Error) => {
             return false;
        });
   }

   public formUpdateServiceCall(form, handlingUnitId, stopId) {
     let params = {};
     const url = this.jbhGlobals.endpoints.order.crudHandlingUnit + '/' + stopId + '/itemhandlingdetails/' + handlingUnitId;
     params = form;
     this.jbhGlobals.apiService.updateData(url, params).subscribe( data => {
         delete data['@id'];
         const response = data;
         this.saveHandlingResponseToOrder(response);
      }, (err: Error) => {
             return false;
       });
   }

   public saveHandlingResponseToOrder(response) {
         const url = this.jbhGlobals.endpoints.order.getstopbyid;
         this.jbhGlobals.apiService.getData(url).subscribe( data => {
           this.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx].itemHandlingDetail = response;
           console.log(this.orderData.stopDTOs);
       });
   }
   public loadHandlingUnit() {
          const url = this.jbhGlobals.endpoints.order.getHandlingUnit;
          const params = {'page': 0, 'size': 200};
          this.jbhGlobals.apiService.getData(url, params, false).subscribe( data => {
                 this.itemHanlingUnitList = data['_embedded']['itemHandlingTypes'];
           });
   }
   public loadHandlingWeight() {
          this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getUnitOfWeight).subscribe( data => {
                 this.itemWeightList = data['_embedded']['unitOfWeightMeasurements'];
           });
   }
   public loadUnitofLength() {
          this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getUnitofLength).subscribe( data => {
                 this.itemLengthList = data['_embedded']['unitOfLengthMeasurements'];
           });
   }
   public loadHandlingReference() {
          if (this.stopId) {
              const params = this.stopId + '/' + 'stopreferencenumbertypes';
              this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.gethandlingreference + params).subscribe( data => {
                     this.handlingReferenceList = data;
               });
           }
   }
   public onClickOfAddHandlingUnit() {
        if (this.stopId && this.handlingDetails.itemHandlingDetailID && this.handlingForm['valid']) {
            let stopItemArray: any;
            const stopItemObj = {
                stopItem: this.orderFormBuilder.addItem()
             };
            stopItemArray = [];
            stopItemArray.push(stopItemObj);
            const handlingUnitObject = {
                  itemHandlingDetail: this.orderFormBuilder.addHandlingUnit(),
                  stopItemDTOs: stopItemArray
                };
            this.orderData.stopDTOs.itemHandlingDetailDTOs.push(handlingUnitObject);
            this.changeDetector.markForCheck();
        } else {
           this.jbhGlobals.notifications.error('Error', 'Please fill all the required fields');
        }
    }
    public onClickofRemoveItem(i: number) {
        if (this.stopId && this.handlingUnitId) {
            const itemArray = this.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx].stopItemDTOs;
            if (itemArray.length > 0 && itemArray[i]) {
                const stopItemId = itemArray[i].stopItem.stopItemID;
                if (this.stopId && this.handlingUnitId && stopItemId) {
                        this.jbhGlobals.notifications.alert('Warning', 'All the associated data will get deleted');
                        this.itemDeleteServiceCall(this.stopId, stopItemId, itemArray, i);
                } else {
                    this.jbhGlobals.notifications.error('Error', 'Handling unit can not be deleted');
                }
              }
        }
     }
    public itemDeleteServiceCall(stopId, stopItemId, itemArray, i) {
        const url = this.jbhGlobals.endpoints.order.crudHandlingUnit + '/' + stopId + '/stopitems/' + stopItemId;
         this.jbhGlobals.apiService.removeData(url).subscribe( data => {
             console.log(data);
             /* To do remove the item data from orderDto */
             itemArray.splice(i, 1);
        });
    }
    public onDimensionClick(value) {
       if (value === 'handlingDimension')  {
            this.handlingForm.controls['itemHandlingUnitVolume'].setValue('');
            this.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx].itemHandlingDetail.itemHandlingUnitVolume = '';
            this.handlingDimensionFlag = true;
        } else {
           this.handlingForm.controls['itemHandlingUnitLength'].setValue('');
           this.handlingForm.controls['itemHandlingUnitWidth'].setValue('');
           this.handlingForm.controls['itemHandlingUnitHeight'].setValue('');
           this.handlingForm.controls['unitOfLengthMeasurementCode'].setValue('');
           this.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx].itemHandlingDetail.itemHandlingUnitLength = '';
           this.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx].itemHandlingDetail.itemHandlingUnitWidth = '';
           this.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx].itemHandlingDetail.itemHandlingUnitHeight = '';
           this.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx].itemHandlingDetail.unitOfLengthMeasurementCode = '';
           this.handlingDimensionFlag = false;
        }
    }
   public calculateVolume() {
       const handLength = this.handlingForm.value.itemHandlingUnitLength;
       const handWidth = this.handlingForm.value.itemHandlingUnitWidth;
       const handHeigth = this.handlingForm.value.itemHandlingUnitHeight;
       const handUnit = this.handlingForm.value.unitOfLengthMeasurementCode;
       if (handLength && handWidth
          && handHeigth && !this.jbhGlobals.utils.isEmpty(handUnit)) {
            const length = this.conversionToInches(handLength, handUnit);
            const width = this.conversionToInches(handWidth, handUnit);
            const height = this.conversionToInches(handHeigth, handUnit);
            const volume = (length * width * height) / (12 * 12 * 12);
            if (!isNaN(volume)) {
              this.handlingUnitVolume = volume.toFixed(4) + 'kg/m3';
              this.handlingForm['controls']['itemHandlingUnitVolume'].setValue(parseFloat(volume.toFixed(4)));
              this.handlingForm['controls']['unitOfVolumeMeasurementCode'].setValue('Cubic CM');
              this.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx]
              .itemHandlingDetail.itemHandlingUnitVolume = parseFloat(volume.toFixed(4));
              this.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx].itemHandlingDetail.unitOfVolumeMeasurementCode = 'Cubic CM';
            } else {
               // To do throw error saying volume digits should not be greater than 7 digits
            }
         } else {
           this.handlingForm['controls']['unitOfVolumeMeasurementCode'].setValue('');
           this.handlingForm['controls']['itemHandlingUnitVolume'].setValue('');
           this.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx].itemHandlingDetail.itemHandlingUnitVolume = '';
           this.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx].itemHandlingDetail.unitOfVolumeMeasurementCode = '';
           this.handlingUnitVolume = '';
         }

    }
    public calculateDensity() {
       const handLength = this.handlingForm.value.itemHandlingUnitLength;
       const handWidth = this.handlingForm.value.itemHandlingUnitWidth;
       const handHeigth = this.handlingForm.value.itemHandlingUnitHeight;
       const handUnit = this.handlingForm.value.unitOfLengthMeasurementCode;
       const handWeight = this.handlingForm.value.itemHandlingUnitWeight;
       const handWeightUnit = this.handlingForm.value.unitOfWeightMeasurementCode;
        if (handLength && handWidth && handHeigth && !this.jbhGlobals.utils.isEmpty(handUnit)
          && handWeight && !this.jbhGlobals.utils.isEmpty(handWeightUnit)) {
            const length = this.conversionToFeet(handLength, handUnit);
            const width = this.conversionToFeet(handWidth, handUnit);
            const height = this.conversionToFeet(handHeigth, handUnit);
            const weight = this.weightConversion(handWeight, handWeightUnit);
            const density = weight / (length * width * height);
            if (!isNaN(density)) {
              this.handlingUnitDensity = density.toFixed(4) + 'kg/m3';
              this.setDenityVal(density.toFixed(4));
             }
         } else {
            this.handlingUnitDensity = '';
            this.setDensityEmpty();
        }
    }
    public setVolumeEmpty() {
           this.handlingForm['controls']['unitOfVolumeMeasurementCode'].setValue('');
           this.handlingForm['controls']['itemHandlingUnitVolume'].setValue('');
           this.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx].itemHandlingDetail.itemHandlingUnitVolume = '';
           this.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx].itemHandlingDetail.unitOfVolumeMeasurementCode = '';
           this.handlingUnitVolume = '';
    }
    public conversionToInches(value, unit) {
      let measurement;
      switch (unit) {
           case 'Centimeter':
               measurement = parseFloat(value) / 2.54;
               break;
          case 'Feet':
               measurement = parseFloat(value) * 12;
               break;
           case 'Kilometers':
               measurement = parseFloat(value) * 39379.96;
               break;
           case 'Meter':
               measurement = parseFloat(value) / 0.0254;
               break;
           case 'Miles':
               measurement = parseFloat(value) * 63360;
               break;
           case 'Inches':
               measurement = parseFloat(value);
               break;
           default:
               break;
       }
       return measurement;
    }
    public conversionToFeet(value, unit) {
      switch (unit) {
           case 'Centimeter':
               value = parseFloat(value) / 30.48;
               break;
          case 'Inches':
               value = parseFloat(value) / 12;
               break;
           case 'Kilometers':
               value = parseFloat(value) * 3280.8398950131;
               break;
           case 'Meter':
               value = parseFloat(value) / 0.3048;
               break;
           case 'Miles':
               value = parseFloat(value) * 5280;
               break;
           case 'Inches':
               value = parseFloat(value);
               break;
           default:
               break;
       }
       return value;
    }
    public weightConversion(value, unit) {
      let weight;
      switch (unit) {
           case 'Grams':
               weight = parseFloat(value) / 453.59237;
               break;
          case 'Kilogram':
               weight = parseFloat(value) / 0.45359237;
               break;
           case 'MetricTons':
               weight = parseFloat(value) / 0.00045359237;
               break;
           case 'Ounces':
               weight = parseFloat(value) / 16;
               break;
           case 'Tons':
               weight = parseFloat(value) / 0.00045359237;
               break;
           case 'Pounds':
               weight = parseFloat(value);
               break;
           default:
               break;
       }
       return weight;
    }
    public calculateVolumeConversion() {
        const volume = this.handlingForm.value.itemHandlingUnitVolume;
        const weight = this.handlingForm.value.itemHandlingUnitWeight;
        const weightUnit = this.handlingForm.value.unitOfWeightMeasurementCode;
        if (volume && weight && !this.jbhGlobals.utils.isEmpty(weightUnit)) {
            const density = this.weightConversion(weight, weightUnit) / volume * (12 * 12 * 12);
            if (!isNaN(density)) {
              this.handlingDensityVal = parseFloat(density.toFixed(4)) + 'kg/m3';
              this.setDenityVal(density.toFixed(4));
             }
         } else {
            this.setDensityEmpty();
            this.handlingDensityVal = '';
         }
    }
    public setDensityEmpty() {
      this.handlingForm['controls']['unitOfDensityMeasurementCode'].setValue('');
      this.handlingForm['controls']['itemHandlingUnitDensity'].setValue('');
      this.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx].itemHandlingDetail.itemHandlingUnitDensity = '';
      this.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx].itemHandlingDetail.unitOfDensityMeasurementCode = '';
    }
    public setDenityVal(value) {
      this.handlingForm['controls']['itemHandlingUnitDensity'].setValue(parseFloat(value));
      this.handlingForm['controls']['unitOfDensityMeasurementCode'].setValue('GM/CC');
      this.handlingForm.value.itemHandlingUnitDensity = parseFloat(value);
      this.handlingForm.value.unitOfDensityMeasurementCode = 'GM/CC';
      this.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx].itemHandlingDetail.itemHandlingUnitDensity = parseFloat(value);
      this.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx].itemHandlingDetail.unitOfDensityMeasurementCode = 'GM/CC';
    }
    public onReferenceSelect(event) {
       let referenceNumberAssociation = [];
       referenceNumberAssociation = this.orderData.stopDTOs.itemHandlingDetailDTOs[this.indx]
       .itemHandlingDetail.itemHandlingDetailReferenceNumberAssociations;
       const value = !this.jbhGlobals.utils.isEmpty (event.target.value) ? event.target.value : '';
       if (value) {
            this.referenceObject = {
                    'itemHandlingDetailReferenceNumberAssociationID': '',
                    'stopReferenceNumber': {
                        'referenceNumberID': parseInt(value, 10)
                    }
             };
              referenceNumberAssociation[0] = this.referenceObject;
              this.setHandlingDivFocus();
        } else {
            referenceNumberAssociation = [];
            this.setHandlingDivFocus();
        }
    }
    public populateData(handlingDataPopulation) {
        this.handlingForm.patchValue(handlingDataPopulation);
        if (handlingDataPopulation.itemHandlingDetailReferenceNumberAssociations.length > 0) {
          const referenceVal = handlingDataPopulation.itemHandlingDetailReferenceNumberAssociations[0].
          stopReferenceNumber.referenceNumberID;
          this.handlingForm['controls'].itemReference.setValue(referenceVal);
        }
        if (handlingDataPopulation.itemHandlingUnitVolume &&
           !this.jbhGlobals.utils.isEmpty(handlingDataPopulation.unitOfVolumeMeasurementCode)
           && !handlingDataPopulation.itemHandlingUnitLength
             && !handlingDataPopulation.itemHandlingUnitWidth && !handlingDataPopulation.itemHandlingUnitHeight) {
           this.handlingDimensionFlag = false;
           this.handlingVolumeVal  = this.handlingForm['controls'].itemHandlingUnitVolume.value + 'kg/m3';
           if (handlingDataPopulation.itemHandlingUnitWeight
              && !this.jbhGlobals.utils.isEmpty(handlingDataPopulation.unitOfWeightMeasurementCode)) {
                this.handlingDensityVal = this.handlingForm['controls'].itemHandlingUnitDensity.value + 'kg/m3';
            }
        } else {
            this.handlingDimensionFlag = true;
            this.handlingVolumeVal = '';
            this.handlingDensityVal = '';
        }

        if (handlingDataPopulation.itemHandlingUnitLength && handlingDataPopulation.itemHandlingUnitWidth
         && handlingDataPopulation.itemHandlingUnitHeight
           && !this.jbhGlobals.utils.isEmpty(handlingDataPopulation.unitOfLengthMeasurementCode)
             && handlingDataPopulation.itemHandlingUnitVolume
            && !this.jbhGlobals.utils.isEmpty(handlingDataPopulation.unitOfVolumeMeasurementCode)) {
           this.handlingUnitVolume  = this.handlingForm['controls'].itemHandlingUnitVolume.value + 'kg/m3';
           if (handlingDataPopulation.itemHandlingUnitWeight
             && !this.jbhGlobals.utils.isEmpty(handlingDataPopulation.unitOfWeightMeasurementCode)) {
                this.handlingUnitDensity = this.handlingForm['controls'].itemHandlingUnitDensity.value + 'kg/m3';
           }
        } else {
            this.handlingUnitVolume = '';
            this.handlingUnitDensity = '';
        }

    }
    public setHandlingDivFocus() {
      if (this.handlingForm['dirty']) {
        this.handlingDiv.nativeElement.focus();
      }
    }
}
