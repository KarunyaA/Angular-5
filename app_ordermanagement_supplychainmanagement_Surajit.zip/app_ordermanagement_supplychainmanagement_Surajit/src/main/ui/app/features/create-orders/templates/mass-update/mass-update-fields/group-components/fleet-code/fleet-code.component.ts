import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-fleet-code',
  templateUrl: './fleet-code.component.html',
  styleUrls: ['./fleet-code.component.scss']
})
export class FleetCodeComponent implements OnInit {

    fleetCodeForm: FormGroup;

    constructor(public formBuilder: FormBuilder) {}

    ngOnInit() {
        this.fleetCodeForm = this.formBuilder.group({
            businessunit: [''],
            serviceoffering: [''],
            fleetcode: ['']
        });
    }

}
