import {Component, Input, OnInit, AfterViewInit, ViewChild,  ViewChildren, ElementRef} from '@angular/core';
import {FormGroup, Validators } from '@angular/forms';
// import {AppointmentDetailsComponent} from './appointment-details.component';
import {SiteProfileComponent} from './site-profile/site-profile.component';
// import { ReasonPipe } from './stop-reason-pipe';
import {JBHGlobals} from '../../../../../app.service';
import {OrderService} from '../../order.service';
import {OrderFormBuilder} from '../../order-form-builder.service';

@Component({
  selector: 'app-stop-details',
  templateUrl: './stop-details.component.html',
  styleUrls: ['./stop-details.component.scss']
})
export class StopDetailsComponent implements OnInit, AfterViewInit  {
  @ViewChildren('apptRequestedChild') apptRequestedChild: any;
  @ViewChildren('apptScheduledChild') apptScheduledChild: any;
  @ViewChild('serviceTypeCodeTag') serviceTypeCodeTag: any;
  @ViewChild('appointmentNumber') appointmentNumber: ElementRef;
  @ViewChild('appointmentInsTag') appointmentInsTag: any;
  @Input() stopNumber;
  @Input() finalStop;
  @Input() stopDataLoaded;
  @ViewChild('handlingUnitRef') handlingUnitRef: any;
  @ViewChild(SiteProfileComponent) siteprofile: SiteProfileComponent;
  public stopForm: any;
  public stopDetails: any;
  public requestedAppts: any = {};
  public scheduledAppts: any = {};
  public stopServices: FormGroup;
  public stopServiceObject: any;
  @Input() stopResequenceDetails: any;
  public stopReasonList: string[] = [];
  public isStopMiles = false;
  public totalMilesList: string[] = [];
  public stopSaveActionSuccess = true;
  public appointmentInstructionListObj: any;
  public appointmentInstructionObj: string[] = [];
  public serviceLevelTypeCodeListObj: any;
  public serviceLevelTypeCodeObj: Array < string > = [];
  public locationLoading: boolean;
  public locationNoResults: boolean;
  public isFirstStop = false;
  public roleType: string;
  public stopTotalMiles = 0;
  public locationCode: string;
  public preStopNumber: number;
  public curStopZip: number;
  public prevStopZip: number;
  public zipCode: string;
  public debounceValue: number;
  public scheduledForm: any;
  public appointmentInstruction: FormGroup;
  public orderData: any;
  public stopId: number;
  public currentStopId: number;
  public stopReasonType;
  public locationContactTypeRes: any[] = [];
  public locationContactList: string[] = [];
  public appointmentInstructionList: any[] = [];
  public serviceLevelTypeCodeList: any[] = [];
  public typeAheadList: string[] = [];
  constructor(public orderFormBuilder: OrderFormBuilder, public jbhGlobals: JBHGlobals,
      public orderService: OrderService) {}
  ngOnInit() {
      if (this.stopNumber === 0) {
          this.isFirstStop = true;
      } else {
          this.isFirstStop = false;
      }
      this.loadStopReason();
      this.loadLocationContact();
      this.loadAppointmentInstruction();
      this.loadStopServicesList();
      this.stopForm = this.orderFormBuilder.getStopDetailList();
      this.loadOrderData();
      this.debounceValue = this.jbhGlobals.settings.debounce;
      this.stopServices = this.stopForm['controls']['stopServices']['controls'][0];
      this.appointmentInstruction = this.orderFormBuilder.getAppointmentInstruction();
      this.stopForm['controls']['locationID']['valueChanges']
          .debounceTime(this.debounceValue)
          .distinctUntilChanged()
          .subscribe((value) => {
              if (value !== undefined && value.length > 2) {
                  this.roleType = 'solicitor';
                  this.getLocationTypeAhead(value, this.roleType);
              }
          }, (err: Error) => {
              console.log(err);
          });
      if (this.stopNumber === 0) {
          this.stopForm.controls['stopReason'].setValue('Pickup');
          this.stopReasonType = 'Pickup';
      } else if (this.finalStop) {
          this.stopForm.controls['stopReason'].setValue('Delivery');
          this.stopReasonType = 'Delivery';
      }
      this.currentStopId = this.stopResequenceDetails[this.stopNumber]['stop']['stopID'];
      /* if (this.newStopId && this.newStopId!= undefined) {
         this.loadStopDetails(this.newStopId);
       }
       else { */
      //  this.loadStopDetails(this.currentStopId);
      // }
      this.scheduledForm = this.orderFormBuilder.scheduledAppointments();
      //    this.appointmentInstruction = this.orderFormBuilder.getAppointmentInstruction();
      // this.stopServices = this.orderFormBuilder.getStopServices();
  }
  ngAfterViewInit() {
      this.loadStopDetails(this.currentStopId);
  }
  public loadStopDetails(stopId: number) {
      let stopUrl: string;
      // if (stopId==null || !stopId) {
      //  stopUrl = this.jbhGlobals.endpoints.order.getstopmockdata; } else { }
      stopUrl = this.jbhGlobals.endpoints.order.getstopbyid;
      this.jbhGlobals.apiService.getData(stopUrl).subscribe(data => {
          if (!this.jbhGlobals.utils.isEmpty(data)) {
              this.stopDetails = data['stopDTO']['stop'];
              this.orderData.stopDTOs = data['stopDTO'];
              // this.stopForm['controls']['stopServices']['patchValue'](data['stopDTO']['stop']['stopServices'])
              this.stopId = this.orderData.stopDTOs.stop.stopID;
              if (this.stopId) {
                  this.populateStopData(this.orderData.stopDTOs);
              }
              if (this.orderData.stopDTOs.stop.appointment) {
                  const apptArr = this.orderData.stopDTOs.stop.appointment;
                  let requestedExist = false;
                  let scheduledExist = false;
                  const apptInstruction = this.orderFormBuilder.getAppointmentInstruction();
                  for (const appts of apptArr) {
                      if (appts['appointmentTypeCode'] === 'requested') {
                          requestedExist = true;
                          this.requestedAppts = appts;
                      } else if (appts['appointmentTypeCode'] === 'scheduled') {
                          this.scheduledAppts = appts;
                          scheduledExist = true;
                          if (!this.scheduledAppts.appointmentInstructionAssociation) {
                              this.scheduledAppts.appointmentInstructionAssociation = [apptInstruction.value];
                          }
                          /* if (!this.scheduledAppts.appointmentConfirmationNumber) {
                             this.scheduledAppts['appointmentConfirmationNumber'] = '';
                           }  */
                      }
                  }
                  if (!requestedExist) {
                      this.addAppointments(0);
                  }
                  if (!scheduledExist) {
                      this.addAppointments(1);
                  }
              }
              if (this.orderData.stopDTOs.stop.stopServices) {
                  const stopService = this.orderFormBuilder.getStopServices();
                  if (this.orderData.stopDTOs.stop.stopServices.length === 0) {
                      this.stopServiceObject = [stopService.value];
                  } else {
                      this.stopServiceObject = this.orderData.stopDTOs.stop.stopServices;
                  }
                  // this.stopForm['controls']['stopServices']['patchValue'](this.stopServiceObject);
              }
          }
      }, (err: Error) => {
             return false;
        });
      if (this.stopNumber > 0) {
          this.stopTotalMiles = 0;
          /* this.preStopNumber = (this.stopNumber-1);
           this.curStopZip = this.stopResequenceDetails[this.stopNumber]['locationDTO']['addressDTO']['zipCode'];
           this.prevStopZip = this.stopResequenceDetails[this.preStopNumber]['locationDTO']['addressDTO']['zipCode'];
           this.zipCode = "zip/"+this.prevStopZip+"/zip/"+this.curStopZip;
           this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getstopmiles+this.zipCode).subscribe( data=>{
           let currentStopMile = data; */
          this.totalMilesList = this.jbhGlobals.utils.clone(this.stopResequenceDetails);
          const currentStopResequenceList = this.totalMilesList.slice(0, this.stopNumber + 1);
          for (const resequenceObj of currentStopResequenceList) {
              if (resequenceObj['stopMiles'] && resequenceObj['stopMiles'] !== undefined) {
                 this.stopTotalMiles = (this.stopTotalMiles + resequenceObj['stopMiles']);
                 this.isStopMiles = true;
              }
          }
          // });
      }
  }
  public loadStopReason() {
      this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getstopreason).subscribe(data => {
          this.stopReasonList = data['_embedded']['stopReasons'];
      }, (err: Error) => {
             return false;
        });
  }
  public loadAppointmentInstruction() {
      this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getappointmentinstruction).subscribe(data => {
          this.appointmentInstructionList = this.jbhGlobals.utils.uniqBy(data['_embedded']['appointmentInstructions'],
              'appointmentInstructionText');
          this.appointmentInstructionListObj = this.jbhGlobals.utils.clone(this.appointmentInstructionList);
          this.appointmentInstructionList = this.jbhGlobals.utils.map(this.appointmentInstructionList, 'appointmentInstructionText');
      }, (err: Error) => {
             return false;
        });
  }
  public loadStopServicesList() {
      this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getstopserviceslist).subscribe(data => {
          this.serviceLevelTypeCodeList = this.jbhGlobals.utils.uniqBy(data['_embedded']['serviceTypes'], 'serviceTypeDescription');
          this.serviceLevelTypeCodeListObj = this.jbhGlobals.utils.clone(this.serviceLevelTypeCodeList);
          this.serviceLevelTypeCodeList = this.jbhGlobals.utils.map(this.serviceLevelTypeCodeList, 'serviceTypeDescription');
      }, (err: Error) => {
             return false;
        });
  }
  public loadLocationContact() {
      this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getlocationcontact).subscribe(data => {
          this.locationContactList = data['LocationContactList'];
      }, (err: Error) => {
             return false;
        });
  }
  public changeLocationLoading(e: boolean): void {
      this.locationLoading = e;

  }
  public changeLocationNoResults(e: boolean): void {
      this.locationNoResults = e;
  }
  public onLocationBlur(eve) {
      this.stopForm['controls']['locationID'].setValidators([Validators.required]);
      this.stopForm['controls']['locationID'].updateValueAndValidity();
  }
  public onStopServiceSelection(eve) {
      const serviceTypeVal = this.jbhGlobals.utils.find(this.serviceLevelTypeCodeListObj, {
          serviceTypeDescription: eve.text
      });
      const stopServiceObject: any = {
          serviceID: '',
          serviceCount: '',
          unitOfServiceMeasurementCode: '',
          serviceLevelTypeCode: serviceTypeVal.serviceTypeCode,
          effectiveTimestamp: '',
          serviceType: serviceTypeVal.serviceTypeDescription,
          serviceCategoryCode: ''
      };
      // this.serviceLevelTypeCodeObj.push(serviceTypeVal);
      this.serviceLevelTypeCodeObj.push(stopServiceObject);
  }
  public onApptInstructionSelection(eve) {
      const apptInstruction = this.jbhGlobals.utils.find(this.appointmentInstructionListObj, {
          appointmentInstructionText: eve.text
      });
      const appointmentInsObj: any = {
          appointmentInstructionAssociationID: '',
          appointmentInstruction: apptInstruction.appointmentInstructionID,
          appointmentInstructionAdditionalDetail: apptInstruction.appointmentInstructionText
      };
      this.appointmentInstructionObj.push(appointmentInsObj);
  }
  public onApptInstructionRemove(eve) {
      this.jbhGlobals.utils.remove(this.appointmentInstructionObj, {
          appointmentInstructionAdditionalDetail: eve.text
      });
  }
  public onStopServiceRemove(eve) {
      this.jbhGlobals.utils.remove(this.serviceLevelTypeCodeObj, {
          serviceType: eve.text
      });
  }
  public typeaheadOnSelect(eve) {
      this.locationCode = eve.item.code;
      this.stopForm['controls']['locationID']['setValue'](eve.item.name + '-' +
          eve.item.addressDTO.addressLine1 + ' ' + eve.item.addressDTO.addressLine2 +
          ',' + eve.item.addressDTO.city + ' ' + eve.item.addressDTO.country +
          ' ' + eve.item.addressDTO.state + ' ' + eve.item.addressDTO.zipcode + ' ' + '(' + eve.item.code + ')');
      if (this.stopReasonType !== undefined) {
          if (!this.jbhGlobals.utils.isEmpty(this.stopForm.value.stopID)) {
              const stopId = '/' + this.stopForm.value.stopID;
              this.updateStopDetails(stopId, this.stopForm.value);
          } else {
              this.addStopDetails(this.stopForm.value);
          }
      }
      this.onSelectContactType(this.locationCode);
      if (this.stopNumber > 0) {
          this.preStopNumber = (this.stopNumber - 1);
          this.curStopZip = eve.item.addressDTO.zipcode;
          this.prevStopZip = this.stopResequenceDetails[this.preStopNumber]['locationDTO']['addressDTO']['zipCode'];
          this.zipCode = 'zip/' + this.prevStopZip + '/zip/' + this.curStopZip;
          this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getstopmiles + this.zipCode).subscribe(data => {
              const currentStopMile = data;
              this.totalMilesList = this.jbhGlobals.utils.clone(this.stopResequenceDetails);
              const currentStopResequenceList = this.totalMilesList.slice(0, this.stopNumber);
              for (const resequenceObj of currentStopResequenceList) {
                  if (resequenceObj['stopMiles'] && resequenceObj['stopMiles'] !== undefined) {
                     this.stopTotalMiles = (this.stopTotalMiles + resequenceObj['stopMiles']);
                     this.isStopMiles = true;
                  }
              }
              // this.stopTotalMiles = (this.stopTotalMiles+currentStopMile);
          }, (err: Error) => {
                 return false;
            });
      }
  }
  public onSelectContactType(locationCode) {
      const params = {
          code: locationCode,
          roletype: 'solicitor',
          active: 'yes'
      };
      this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getlocationContactType, params, false).subscribe(data => {
          if (data !== undefined) {
              this.locationContactTypeRes = data;
          }
      }, (err: Error) => {
             return false;
        });
  }
  public loadOrderData() {
      if (this.jbhGlobals.utils.isEmpty(this.orderData)) {
          this.orderService.getData().subscribe(sharedOrderData => {
              this.orderData = sharedOrderData;
          }, (err: Error) => {
             return false;
        });
      }
  }
  public onStopReasonChange(reason: string) {
      this.stopReasonType = reason.trim();
      if (this.locationCode !== undefined) {
         if (!this.jbhGlobals.utils.isEmpty(this.stopForm.value.stopID)) {
            const stopId = '/' + this.stopForm.value.stopID;
            this.updateStopDetails(stopId, this.stopForm.value);
         } else {
            this.addStopDetails(this.stopForm.value);
         }
      }
  }
  public getLocationTypeAhead(value, roleType) {
      const params = {
          value: value,
          roletype: roleType,
          active: 'yes',
          page: 0,
          size: 5,
          approved: true,
          addresstype: 'mailing'
      };
      this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.gettypeaheadbillto, params, false).subscribe(data => {
          if (data['profileDTO'] !== undefined) {
              this.typeAheadList = data['profileDTO'];
          }
      }, (err: Error) => {
             return false;
        });
  }
  public addAppointments(appt: number) {
      const stopCtrl = this.orderFormBuilder.getInitDateTimeDetails();
      const apptInstruction = this.orderFormBuilder.getAppointmentInstruction();
      if (appt === 0) {
          if (this.apptRequestedChild && this.apptRequestedChild.isApptReqSaved === false) {
              this.jbhGlobals.notifications.alert('Warning', 'Current appointment not saved');
              return;
          }
          const isReqApptFormValid = this.jbhGlobals.utils.findIndex(this.apptRequestedChild._results, function(obj)
          {
             return obj.appointmentForm.valid === false;
          });
          if (isReqApptFormValid !== -1) {
              this.jbhGlobals.notifications.alert('Warning', 'Please enter all the required fields');
              return;
          }
          if (!this.requestedAppts.appointmentDateTimeDetails) {
              this.requestedAppts.appointmentDateTimeDetails = [stopCtrl.value];
          } else {
              this.requestedAppts.appointmentDateTimeDetails.push(stopCtrl.value);
          }
      } else if (appt === 1) {
          if (this.apptScheduledChild && this.apptScheduledChild.isApptScheduledSaved === false) {
              this.jbhGlobals.notifications.alert('Warning', 'Current appointment not saved');
              return;
          }
          const isSchdApptFormValid = this.jbhGlobals.utils.findIndex(this.apptScheduledChild._results, function(obj)
          {
             return obj.appointmentForm.valid === false;
          });
          if (isSchdApptFormValid !== -1) {
              this.jbhGlobals.notifications.alert('Warning', 'Please enter all the required fields');
              return;
          }
          if (!this.scheduledAppts.appointmentDateTimeDetails) {
              this.scheduledAppts.appointmentDateTimeDetails = [stopCtrl.value];
          } else {
              this.scheduledAppts.appointmentDateTimeDetails.push(stopCtrl.value);
          }
          if (!this.scheduledAppts.appointmentInstructionAssociation) {
              this.scheduledAppts.appointmentInstructionAssociation = [apptInstruction.value];
          }
      }
  }
  public onClickSiteProfileShow() {
      this.siteprofile.onShowSiteProfileModal();
  }
  public addStopDetails(stopForm) {
      this.jbhGlobals.apiService.addData(this.jbhGlobals.endpoints.order.crudStopDetails, stopForm).subscribe(stopData => {
          if (!this.jbhGlobals.utils.isEmpty(stopData)) {
              if (stopData['stopID']) {
                  //  this.newStopId = stopData['stopID'];
                  this.jbhGlobals.logger.info('Stops Added Successfully');
              }
          }
      }, (err: Error) => {
             return false;
        });
  }
  public updateStopDetails(stopId, stopForm) {
      this.jbhGlobals.apiService.updateData(this.jbhGlobals.endpoints.order.crudStopDetails + stopId, stopForm).subscribe(stopData => {
          if (!this.jbhGlobals.utils.isEmpty(stopData)) {
              this.jbhGlobals.logger.info('Stops Updated Successfully');
          }
      }, (err: Error) => {
             return false;
        });
  }
  /*  public populateApptInst(eve: any) {
       debugger;
       if (!this.appointmentInsTag.active && this.appointmentInstructionList.length > 0) {
           this.appointmentInsTag.active = [this.appointmentInstructionList[0]];
       }
    } */
  public populateStopData(stopData) {
      this.serviceTypeCodeTag.active = [];
      const stopServices = stopData.stop.stopServices;
      const stopLocation = stopData.locationDTO;
      let partyName;
      let addressLine1;
      let addressLine2;
      let city;
      let country;
      let state;
      let zip;
      if (stopLocation.partyName !== undefined) {
          partyName = stopLocation.partyName;
      }
      if (stopLocation.addressDTO.addressLineOne !== undefined) {
          addressLine1 = stopLocation.addressDTO.addressLineOne;
      }
      if (stopLocation.addressDTO.addressLineTwo !== undefined) {
          addressLine2 = stopLocation.addressDTO.addressLineTwo;
      }
      if (stopLocation.addressDTO.city !== undefined) {
          city = stopLocation.addressDTO.city;
      }
      if (stopLocation.addressDTO.country !== undefined) {
          country = stopLocation.addressDTO.country;
      }
      if (stopLocation.addressDTO.state !== undefined) {
          state = stopLocation.addressDTO.state;
      }
      if (stopLocation.addressDTO.zipCode !== undefined) {
          zip = stopLocation.addressDTO.zipCode;
      }
      this.stopForm['controls']['locationID']['setValue'](partyName + '-' + addressLine1 + ' ' + addressLine2 +
          ',' + city + ' ' + country + ' ' + state + ' ' + zip);
      this.stopForm['controls']['stopReason']['setValue'](stopData.stop.stopReason);
      this.stopForm['controls']['locationContactType']['setValue'](stopData.stop.locationContactType);
      // this.stopForm['controls']['appointment']['controls'][1]['controls']
      // ['appointmentInstructionAssociation'].setValue([{appointmentInstruction: "Appointment Required"}]);
      const isScheduledApptExist = this.jbhGlobals.utils.find(stopData.stop.appointment, {
          appointmentTypeCode: 'scheduled'
      });
      if (isScheduledApptExist && isScheduledApptExist !== undefined) {
         // this.appointmentNumber.nativeElement.value = isScheduledApptExist.appointmentConfirmationNumber;
      }
      for (let i = 0; i < stopServices.length; i++) {
          this.serviceTypeCodeTag.active.push({
              id: stopServices[i].serviceLevelTypeCode,
              text: stopServices[i].serviceType
          });
      }
  }
  public stopDetailSaveForm() {
      if (this.stopForm.touched && this.stopForm.dirty) {
          if (this.stopServices.touched && this.stopServices.dirty) {
              for (let i = 0; i < this.serviceLevelTypeCodeObj.length; i++) {
                  this.stopForm['controls']['stopServices']['value'][i] = this.serviceLevelTypeCodeObj[i];
              }
          }
      }
      if (this.appointmentInstruction.touched && this.appointmentInstruction.dirty) {
          for (let j = 0; j < this.appointmentInstructionObj.length; j++) {
              this.stopForm['controls']['appointment']['controls'][1]['controls']
                  ['appointmentInstructionAssociation']['value'][j] = this.appointmentInstructionObj[j];
          }
      }
      if (!this.jbhGlobals.utils.isEmpty(this.stopForm.value.stopID)) {
          const stopID = '/' + this.stopForm.value.stopID;
          this.updateStopDetails(stopID, this.stopForm.value);
      } else {
          this.addStopDetails(this.stopForm.value);
      }
      if (!this.stopSaveActionSuccess) {
          alert('Error');
          event.stopPropagation();
          return;
      }
  }
}
