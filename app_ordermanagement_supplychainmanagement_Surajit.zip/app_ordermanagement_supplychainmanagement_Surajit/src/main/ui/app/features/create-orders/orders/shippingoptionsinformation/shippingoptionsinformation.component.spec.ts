import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShippingoptionsinformationComponent } from './shippingoptionsinformation.component';

describe('ShippingoptionsinformationComponent', () => {
  let component: ShippingoptionsinformationComponent;
  let fixture: ComponentFixture<ShippingoptionsinformationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShippingoptionsinformationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShippingoptionsinformationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
