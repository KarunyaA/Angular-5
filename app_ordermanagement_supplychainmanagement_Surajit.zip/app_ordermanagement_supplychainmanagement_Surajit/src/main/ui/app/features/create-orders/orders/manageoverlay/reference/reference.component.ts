import { Component, ViewChild, ElementRef, AfterContentChecked } from '@angular/core';
// import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import {JBHGlobals} from '../../../../../app.service';
// import { Observable } from 'rxjs/Observable';
// import { SafeHtmlPipe } from 'app/shared/safepipe/safe-html.pipe';


@Component({
  selector: 'app-reference',
  templateUrl: './reference.component.html',
  styleUrls: ['./reference.component.scss', '../charges/charges.component.scss']
})

export class ReferenceComponent implements AfterContentChecked {

    public parntRefDisplay: any;
    private edtSelNum: any;
    private sSeqNum: any;
    // private sRefId: any;
    private sRefCode: any;
    private sRefNumVal: any;
    private oUpdateIndex: any;
    private newStopRef: any;
    private oRefId: any;
    private oRefCode: any;
    private stopLevelNum: any;
    private oRefNumVal: any;
    public stpIdDelRef: any;
    // private nwStpID: any;
    private edtSelVal: any;
    private referencesList: any;
    public orderRefLst: any;
    private prefType: any;
    public oRefOval: any;
    private stopsRefLst: any;
    private stopLvel: any;
    // private refNTypeCode: any;
    private getreferencesType: any;
    private parentRefTypes: any;
    private stpIDSave: any;
    // private innerHtmlpref: any = [];
    private prefValTxt: any;
    private associatedPref: any;
    private parentrefId: any;
    private oldLen: any;
    private editedOrderRef: any;
    private aParentRefObj: any = [];
    public refTypeArr: any = [];
    private associatedRefArr: any = [];
    private stopNIds: any = [];
    private stopNums: any = [];
    private orderRefLstz: any = [];
    private asParRefVals: any = [];
    private pRefTypeArr: any = [];
    private orderRefSrchLst: any = [];
    private refTypeLoaded = false;
    private stopSave = false;
    private refTListLoaded = false;
    private orderRefUpdate = false;
    private stopLvlsLoaded = false;
    private stopEdit = false;
    private edtStpObj: any;
    // private sIdEdtRef: any;
    // private sDescEdtRef: any;
    private obj: any;
    private urlStopId: any;
    private stopEdtRefNumId: any;
    private tree: any;
    private indent: any = 20;
    // private requestObj: any = [];

    @ViewChild('treeContainer') treeContainer: ElementRef;

    // @ViewChild('parRefVal') parRefVal:ElementRef;

    constructor(private jbhGlobals: JBHGlobals, private elementRef: ElementRef) {

        // Using JBHGlobals services ReferenceList Initial
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getreferencesList
        + 1 + '/referencenumbers').subscribe(data => {
            this.referencesList = data;
        });

        // reference List Mock Service
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getreferencesListMok).subscribe(data => {
            this.referencesList = data;
        });

        // Using JBHGlobals services ReferenceType Initial
        // this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getreferencesType).subscribe(data => {
        //     this.getreferencesType = data;
        // });

        // Parent ReferenceType & ref Values for Stop
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.mokParentRefTypeNVal).subscribe(data => {
            this.parentRefTypes = data;
        });

        // For Populating Stop Level
        const StopParams = {
            orderID: 1,
            projection: 'viewstop'
        };
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getStopNumId, StopParams).subscribe(data => {
            this.stopNIds = data;
        });

    };


    ngAfterContentChecked() {

        // Reference Type service Loading
        if (this.getreferencesType && this.getreferencesType.length !== 0) {
            this.getReferencesType();
        }

        // Initial ReferencesOrder&Stop
        if (this.referencesList && this.referencesList.length !== 0) {
            this.getReferenceList();
        }

        // Populating Stop Level numbers
        if (this.stopNIds) { // Form loading OrderDto& Comments
            this.loadStopLevels();
        }

    }


    public generateTree(): void {

        const me = this;
        this.tree = '<ul>';
        for (let i = 0; i < this.obj.Stop.length; i++) {
            this.frameLi(this.obj.Stop[i].referenceNumberTypeDescription, this.obj.Stop[i]
            .referenceNumber.referenceNumberID, 0, this.obj.Stop[i].stopID);
            this.extractDTO(this.obj.Stop[i].referenceNumberDTOs, this.indent);
        }

        this.tree = this.tree + '</ul>';

        this.treeContainer.nativeElement.insertAdjacentHTML('beforeend', this.tree);

        const editlist = this.treeContainer.nativeElement.querySelectorAll('.stopEdtBtn');

        for (let i = 0; i < editlist.length; i++) {
            editlist[i].addEventListener('click', function(event) {

                this.sIdEdtRef = event.target.getAttribute('data-desc-attr').split('-')[0];
                this.sDescEdtRef = event.target.getAttribute('data-desc-attr').split('-')[1];

                if (this.sIdEdtRef && this.sDescEdtRef) {
                    me.stopEdtDel(this.sIdEdtRef, this.sDescEdtRef);
                }

            });
        }

        const deleteList = this.treeContainer.nativeElement.querySelectorAll('.stopDelBtn');

        for (let i = 0; i < deleteList.length; i++) {
            deleteList[i].addEventListener('click', function(event) {

                this.sIdDelRef = event.target.getAttribute('data-desc-attr').split('-')[0];
                this.sDescDelRef = event.target.getAttribute('data-desc-attr').split('-')[1];
                this.stpIdDelRef = event.target.getAttribute('data-desc-attr').split('-')[2];

                if (this.sIdDelRef && this.sDescDelRef && this.stpIdDelRef) {
                    me.stopDel(this.sIdDelRef, this.sDescDelRef, this.stpIdDelRef);
                }

            });
        }

    }

    public extractDTO(dto, indentVal) {

        if (dto) {
            this.tree = this.tree + '<ul>';

            for (let i = 0; i < dto.length; i++) {
                this.frameLi(dto[i].referenceNumberTypeDescription, dto[i].referenceNumber.referenceNumberID, indentVal, dto[i].stopID);

                if (dto[i].referenceNumberDTOs !== null) {
                    this.indent = this.indent + 10;
                    this.extractDTO(dto[i].referenceNumberDTOs, this.indent);
                }
            }

            this.tree = this.tree + '</ul>';
        }
    }

    private frameLi(desc, id, indentVal, stopID): void {
        const className = id + '-' + desc + '-' + stopID;

        this.tree = this.tree + '<li class="child-li ref-list" style="text-indent:' + indentVal + 'px;">' + desc + '</li>' +
            '<div class="clearfix"><div class="pull-right pad-top10 pad-bottom10">' +
            '<a class="stopEdtBtn font12 link-primary pad-right10" data-desc-attr="' + className + '">Edit</a>' +
            '<a class="stopDelBtn link-primary font12" data-desc-attr="' + className + '">Delete</a></div></div>';

    }

    private stopEdtDel(sid, sDescriptn) {

        this.stopEdtRefNumId = sid;

        this.stopEdit = true;

        if (this.stopSave === true) {

            if (this.orderRefLstz.length !== 0) {
                for (let i = 0; i < this.orderRefLstz.length; i++) {
                    if (sid.toString() === this.orderRefLstz[i].referenceNumber.referenceNumberID.toString()) {
                        this.edtStpObj = this.orderRefLstz[i];
                    }
                }
            }

            // setting sel Optns in RefType dropDown

            this.edtSelVal = this.edtStpObj.referenceNumberTypeDescription;
            this.oRefOval = this.edtStpObj.referenceNumber.referenceNumberValue;
            this.sSeqNum = this.edtStpObj.stopSequenceNumber;

            this.edtSelNum = this.sSeqNum; // setting seq number

            // Edit Logic STarts ------------

            this.orderRefSrchLst = this.orderRefLstz;
            if (this.orderRefSrchLst.length !== 0) {
                for (let i = 0; i < this.orderRefSrchLst.length; i++) {
                    if (this.orderRefSrchLst[i].referenceNumberDTOs !== null) {
                        for (let j = 0; j < this.orderRefSrchLst[i].referenceNumberDTOs.length; j++) {
                            if (this.orderRefSrchLst[i].referenceNumberDTOs[j]
                              .referenceNumberTypeDescription.toString() === this.edtSelVal.toString()
                            && this.orderRefSrchLst[i].referenceNumberDTOs[j]
                            .referenceNumber.referenceNumberValue.toString() === this.oRefOval.toString()) {
                                this.aParentRefObj.push(this.orderRefSrchLst[i]);
                            }
                        }
                    }
                }
            }

            // Edit Logic ENds --------------

            if (this.sSeqNum) { //  setting associated parent type
                this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getAssociatedRefNVals
                 + 1 + '/referenceNumbers').subscribe(data => {
                    this.associatedRefArr = data;
                    // console.clear();
                    // console.log(this.associatedRefArr);
                    this.pRefTypeArr = this.associatedRefArr;
                    // console.log(this.pRefTypeArr);
                    this.asParRefVals = [];

                    if (this.associatedRefArr.length !== 0) {
                        for (let k = 0; k < this.associatedRefArr.length; k++) {

                            if (this.associatedRefArr[k].referenceNumberTypeDescription) {
                                if (this.associatedRefArr[k].referenceNumberTypeDescription.toString() === this.edtSelVal.toString()) {
                                    this.asParRefVals.push(this.associatedRefArr[k].referenceNumber.referenceNumberValue);
                                    // console.log(this.associatedRefArr[k].referenceNumber.referenceNumberValue);
                                }
                            }
                        }
                    }


                });
            }



        }

    }

    private loadStopLevels() {

        if (this.stopLvlsLoaded === false && this.stopNIds.length !== 0) {

            for (let i = 0; i < this.stopNIds._embedded.stops.length; i++) {
                const stpNbr = this.stopNIds._embedded.stops[i].stopSequenceNumber;
                // let stpId = this.stopNIds._embedded.stops[i].stopID;
                this.stopNums.push(stpNbr);
            }
            this.stopNums = this.jbhGlobals.utils.uniq(this.stopNums);

            this.stopLvlsLoaded = true;
        }

    }

    private getReferenceList() {


        const me = this;

        if (this.refTListLoaded === false) {


            this.orderRefLst = this.referencesList.Order;
            this.stopsRefLst = this.referencesList.Stop;
            //  Temp obj ---
            this.obj = this.referencesList;
            this.generateTree();
            //  Temp obj---
            this.refTListLoaded = true;
            me.orderRefLstz = [];

            // this.process(this.stopsRefLst[0], function(object) {
            //     if (object.referenceNumberTypeDescription && object.referenceNumber.referenceNumberValue) {
            //         me.orderRefLstz.push(object);
            //         console.log(object);
            //     }
            // });
            if (this.stopsRefLst.length !== 0) {
                for (let y = 0; y < this.stopsRefLst.length; y++) {
                    this.process(this.stopsRefLst[y], function(object) {
                        if (object.referenceNumberTypeDescription && object.referenceNumber.referenceNumberValue) {
                            me.orderRefLstz.push(object);
                            // console.log(object);
                        }
                    });

                }
            }


        }

    }

    private process(obj, func) {
        const me = this;
        func(obj);
        if (obj.referenceNumberDTOs !== null) {
            obj.referenceNumberDTOs.forEach(referenceNumberDTOs => {
                me.process(referenceNumberDTOs, func);
            });
        }
    }



    // private process(obj, func) {
    //     const me = this;
    //     func(obj);
    //     if (obj.referenceNumberDTOs !== null) {
    //         obj.referenceNumberDTOs.forEach(referenceNumberDTOs => {
    //             me.process(referenceNumberDTOs, func);
    //         });
    //     }
    // }


    private getReferencesType() {
        if (this.refTypeLoaded === false) {
            this.refTypeArr = this.getreferencesType._embedded.referenceNumberTypes;
            this.refTypeLoaded = true;
        }
    }

    public stopsave() {
        this.stopSave = true;

        this.oRefOval = null;
    }
    public ordersaveFlg() {
        this.stopSave = false;
    }

    public orderDel(index, reftype, refVal) {

        // const edtOrdrObj = this.orderRefLst[index];

        const delObjId = this.orderRefLst[index].referenceNumber.referenceNumberID;

        this.jbhGlobals.apiService.removeData(this.jbhGlobals.endpoints.order.deleteOrderRef + delObjId).subscribe(data => {});
        this.refTListLoaded = false;

    }

    public stopDel(sRefDelId, sRefDesc, stopIdDel) {
 // /ordermanagementorderservices/stops/{stopid}/stopreferencenumbers/{stopreferencenumberid}
        const delObjId = sRefDelId;
        // this.jbhGlobals.apiService.removeData(this.jbhGlobals.endpoints.order.deleteStopRef + "stopId" + delObjId).subscribe(data => {});
        this.jbhGlobals.apiService.removeData(this.jbhGlobals.endpoints.order.deleteStopRef
          + stopIdDel + '/stopreferencenumbers/' + delObjId).subscribe(data => {});
        this.refTListLoaded = false;

    }


    public aParentRefOnSel($event, parReftype) {
        this.associatedPref = parReftype;

        this.asParRefVals = []; // clearing the associated parent ref value

        if (this.associatedRefArr.length !== 0) {
            for (let k = 0; k < this.associatedRefArr.length; k++) {
                if (this.associatedRefArr[k].referenceNumberTypeDescription !== null
                && this.associatedRefArr[k].referenceNumberTypeDescription === this.associatedPref) {
                    this.asParRefVals.push(this.associatedRefArr[k].referenceNumber.referenceNumberValue);
                    // console.log(this.associatedRefArr[k].referenceNumber.referenceNumberValue);
                }
            }
        }

    }

    public orderEdtDel(index, reftype, refVal) {

        this.oUpdateIndex = index;
        // const edtOrdrObj = this.orderRefLst[index];
        this.oRefId = this.orderRefLst[index].referenceNumber.referenceNumberID;
        this.oRefCode = this.orderRefLst[index].referenceNumber.referenceNumberTypeCode;
        this.oRefNumVal = this.orderRefLst[index].referenceNumber.referenceNumberValue;

        // setting sel Optn in RefType dropDown
        this.edtSelVal = this.orderRefLst[index].referenceNumberTypeDescription;
        this.oRefOval = this.oRefNumVal;

        if (this.edtSelVal !== undefined && this.oRefOval !== undefined) {
            this.orderRefUpdate = true;
        }

    }

    public stopLevelOnSel($event, stplevl) {
        this.stopLvel = stplevl;
this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getAssociatedRefNVals
          + 1 + '/referenceNumbers').subscribe(data => {
            this.associatedRefArr = data;
            this.pRefTypeArr = this.associatedRefArr;
        });

    }

    public saveReferences(e, refForm, reftype, refVal) {

        e.preventDefault();

        const refType = reftype.value;
        const refValTxt = refVal.value;

        if (refForm.value.ParRefType !== undefined && refForm.value.ParRefVal !== undefined) {
            if (refForm.value.ParRefType !== '') {
                this.prefType = refForm.value.ParRefType;
            }
            this.prefValTxt = refForm.value.ParRefVal;

            this.stopLevelNum = this.stopLvel;
            // this.stopLevelNum = refForm.value.stopLvl;
        }

        const currRefTypeObj = this.jbhGlobals.utils.find(this.refTypeArr, ['referenceNumberTypeDescription', refType]);
        const refNumTypeCode = currRefTypeObj.referenceNumberTypeCode;

        // -------------------OrderUpdate Starts
        if (this.orderRefUpdate === true && this.stopSave === false) {

            const OrdrParams = {
                'order': '/1',
                'referenceNumberID': this.oRefId,
                'referenceNumberTypeCode': this.oRefCode,
                'referenceNumberValue': this.oRefNumVal
            };

this.jbhGlobals.apiService.addData(this.jbhGlobals.endpoints.order.updateOrderRefEdit
+ this.oRefId, OrdrParams).subscribe(data => {
                this.editedOrderRef = data;

                if (this.editedOrderRef !== undefined && this.editedOrderRef.length !== 0) {
                    this.orderRefLst.splice(this.oUpdateIndex, 1);
                    this.orderRefLst.push(this.editedOrderRef);
                    this.orderRefUpdate = false;
                    this.refTListLoaded = false; // Reloading the initial list
                    this.oRefOval = null;
                }
            });
        } else if (this.orderRefUpdate === false && this.stopSave === false) {

            const OrdrParams = {
                'order': '/1',
                'referenceNumberID': '',
                'referenceNumberTypeCode': refNumTypeCode,
                'referenceNumberValue': refValTxt
            };

// Order Ref Save
            this.jbhGlobals.apiService.addData(this.jbhGlobals.endpoints.order.postReferencesType, OrdrParams).subscribe(data => {
                this.getreferencesType = data;
                if (this.getreferencesType.length !== 0) {
                    this.getreferencesType = null;
                }
            });

            this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getreferencesList
             + 1 + '/referencenumbers').subscribe(data => {
                this.referencesList = data;
                this.orderRefLst = this.referencesList.Order;
            });

            if (this.oldLen !== this.referencesList.Order.length) {
                this.refTListLoaded = false;
            }
            this.refTListLoaded = false;

        }

        // Stop save
        if (this.stopSave.toString() === true.toString()
         && this.stopEdit.toString() === false.toString()) {
            if (refNumTypeCode !== null && refValTxt !== null && this.prefType !== null
              && this.prefValTxt !== null && this.stopLevelNum !== null) {
            if (refNumTypeCode !== '' && refValTxt !== '' && this.prefType !== '' &&
             this.prefValTxt !== '' && this.stopLevelNum !== '') {
            if (refNumTypeCode !== undefined && refValTxt !== undefined && this.prefType !== undefined
             && this.prefValTxt !== undefined && this.stopLevelNum !== undefined) {

                        const OrdrParams = {
                            'referenceNumberTypeCode': refNumTypeCode,
                            'referenceNumberValue': refValTxt,
                            'associatedReferenceNumber': [{
                                'referenceNumber': {
                                    'referenceNumberTypeCode': this.prefType,
                                    'referenceNumberValue': this.prefValTxt
                                }
                            }]
                        };

                        for (let j = 0; j < this.stopNIds._embedded.stops.length; j++) {
                            if (this.stopNIds._embedded.stops[j].stopSequenceNumber === this.stopLevelNum) {
                                this.stpIDSave = this.stopNIds._embedded.stops[j].stopID;
                            }
                        }

this.jbhGlobals.apiService.addData(this.jbhGlobals.endpoints.order.postStopRef
 + 1 + '/stops/'
 + this.stpIDSave + '/stopReferenceNumbers', OrdrParams).subscribe(data => {
                            this.getreferencesType = data;
                        });

                    }
                }
            }

        } else if (this.stopEdit === true && this.stopSave !== false) { // For edit
            // 'referenceNumberID': this.sRefId,  this.stopEdtRefNumId
            //     'referenceNumberTypeCode': this.refNTypeCode,   this.edtStpObj..
            //     'referenceNumberValue': refValTxt

this.parentrefId = this.aParentRefObj[0]['referenceNumber']['referenceNumberID'];

            this.sRefCode = this.edtStpObj['referenceNumber']['referenceNumberTypeCode'];
            this.sRefNumVal = this.edtStpObj['referenceNumber']['referenceNumberValue'];

            // console.log(this.stopEdtRefNumId + '  stop id');
            // console.log(this.sRefCode + '   stop numtypeCOde');
            // console.log(this.sRefNumVal + '  stop  refNumValue');


            // for (let i = 0; i < this.getreferencesType._embedded.referenceNumberTypes.length; i++) {
            // if (this.getreferencesType._embedded.referenceNumberTypes[i].referenceNumberTypeDescription === refType) {
            //       this.refNTypeCode = this.getreferencesType._embedded.referenceNumberTypes[i].referenceNumberTypeCode;
            //     }
            // }

            // // Getting stopid
            // if (this.stopNIds.length !== 0) {
            //     for (let i = 0; i < this.stopNIds._embedded.stops.length; i++) {
            //         let stpNbr = this.stopNIds._embedded.stops[i].stopSequenceNumber;
            //         if (this.stopLevelNum.toString() === stpNbr.toString()) {
            //             this.nwStpID = this.stopNIds._embedded.stops[i].stopID;
            //         }
            //     }
            // }


            // this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getAssociatedRefNVals
             // + 1 + '/referenceNumbers').subscribe(data => {
            //     this.associatedRefArr = data;
            // });

            // this.innerHtmlpref - value
            // this.associatedPref  - type

            // if (this.associatedRefArr) {
            // for (let k = 0; k < this.associatedRefArr.length; k++) {
            // if (this.associatedRefArr[k].referenceNumberTypeDescription !== null &&
              // this.associatedRefArr[k].referenceNumberTypeDescription === this.associatedPref &&
               // this.associatedRefArr[k].referenceNumber.referenceNumberValue == this.innerHtmlpref) {
            //             this.parentrefId = this.associatedRefArr[k].referenceNumber.referenceNumberID;
            //         }
            //     }
            // }

            // let urlStopId = this.stopLvel;

            if (this.stopLvel && this.stopLvel !== '' && this.stopLvel !== undefined) {
                this.urlStopId = this.stopLvel;
            } else {
                this.urlStopId = this.edtStpObj['stopSequenceNumber'];
            }

            const editStopParams = {
                'referenceNumberID': this.stopEdtRefNumId,
                'referenceNumberTypeCode': this.sRefCode,
                'referenceNumberValue': this.sRefNumVal
            };

 // /ordermanagementorderservices/stops/{stopid}/stopreferencenumbers/{associatereferencenumberid}
            this.jbhGlobals.apiService.addData(this.jbhGlobals.endpoints.order.updateStopRef
             + 1 + '/stops/' + this.urlStopId + '/stopReferenceNumbers/'
             + this.parentrefId, editStopParams).subscribe(data => {
                this.newStopRef = data;
                // console.log(this.newStopRef + '<-----');
            });


        }

    }

}
