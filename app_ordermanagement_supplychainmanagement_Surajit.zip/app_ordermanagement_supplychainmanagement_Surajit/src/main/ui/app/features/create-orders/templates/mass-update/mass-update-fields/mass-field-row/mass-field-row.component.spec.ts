import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MassFieldRowComponent } from './mass-field-row.component';

describe('MassFieldRowComponent', () => {
  let component: MassFieldRowComponent;
  let fixture: ComponentFixture<MassFieldRowComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MassFieldRowComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MassFieldRowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
