import { Injectable } from '@angular/core';
import { Response } from '@angular/http';
import { ActivatedRoute } from '@angular/router';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';

import { JBHGlobals } from 'app/app.service';
import { JbhJsonTransformerService } from 'app/shared/jbh-utils/jbh-json-transformer.service';
import { IOrderDtoModel } from './order-dto-model';
import { IOrderEntityModel } from './order-entity-model';
import { TemplateJsonTransformerService } from 'app/features/create-orders/templates/template-json-transformer.service';
import { ITemplateEntityModel } from 'app/features/create-orders/templates/template-entity-model';

@Injectable()
export class OrderService {
  public sharingData: BehaviorSubject<IOrderDtoModel[]>;
  public orderEntity = <IOrderEntityModel>{};
  public templateEntity = <ITemplateEntityModel>{};
  public data: IOrderDtoModel;

  constructor(public jbhGlobals: JBHGlobals,
    public transformerService: JbhJsonTransformerService,
    public transformerServiceTemplate: TemplateJsonTransformerService,
    public route: ActivatedRoute) {
    this.sharingData = <BehaviorSubject<IOrderDtoModel[]>>new BehaviorSubject([]);
    this.init();
    this.jbhGlobals.logger.info('Order Service initialized');
  }

  init(): void {
    this.route.queryParams.subscribe(
      (queryParam: any) => {
        if (!this.jbhGlobals.utils.isEmpty(queryParam['id']) &&
          this.jbhGlobals.utils.isEmpty(this.data)) {
          this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getorder + queryParam['id']).subscribe(data => {
            data['orderID'] = parseInt(queryParam['id'], 10);
            this.saveData(data);
            this.jbhGlobals.logger.info('Order Dto Loaded', data);
          });
        }
      });
  }

  saveData(orderDtoData): void {
    this.data = orderDtoData;
    this.sharingData.next(orderDtoData);
  }

  getData() {
    return this.sharingData.asObservable();
  }

  getDataAsEntity(): IOrderEntityModel {
    return this.transformerService.orderDtoToEntity(this.data, this.orderEntity);
  }

  getDataAsDto(): IOrderDtoModel {
    return this.data;
  }

  saveOrder(): Observable<Response[]> {
    const data = this.getDataAsEntity();
      console.log(data);
    const url = this.jbhGlobals.endpoints.order.updateorder + data.orderID;
    this.jbhGlobals.logger.info('Saving  Data', JSON.stringify(data));
    return this.jbhGlobals.apiService.updateData(url, data);
  }

  saveTemplate(): void {
    const data = this.getDataAsTempalteEntity();
      console.log(data);
      console.log('coming');
  }
  getDataAsTempalteEntity(): ITemplateEntityModel {
    return this.transformerServiceTemplate.orderDtoToEntity(this.data, this.templateEntity);
  }
}
