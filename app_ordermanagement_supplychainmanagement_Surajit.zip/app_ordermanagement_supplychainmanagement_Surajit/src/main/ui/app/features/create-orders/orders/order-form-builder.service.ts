import { Injectable } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { JBHGlobals } from '../../../app.service';
import { Router } from '@angular/router';

@Injectable()
export class OrderFormBuilder {

  orderForm: FormGroup;

  constructor(public jbhGlobals: JBHGlobals,
    public formBuilder: FormBuilder,
    public router: Router) {
    this.getFormBuilder();
  }


  getFormBuilder() {
    if (this.router.url !== '/createorders/template/create') {
      this.orderForm = this.formBuilder.group({
        orderValueTypeCode: '',
        orderBillingDetail: this.formBuilder.group({
          typeaheadModule: this.formBuilder.group({
            billToCode: ['', Validators.required],
            contactTypeCode: '',
            solicitorCode: ['', Validators.required],
            solicitorCodeContact: '',
            aditionalparty: '',
            lineofBusiness: ['', Validators.required],
            lineofbusinessContact: '',
          })
        }),
        contactDetail: this.formBuilder.group({
          firstname: ['', Validators.required],
          lastname: ['', Validators.required],
          contactCombo: '',
          email: ['', Validators.required],
          phone: '',
          Extension: '',
          checkbox: '',
        }),
        shipmentInformation: this.formBuilder.group({
          shipmentRequirementsTags: '',
          shipmentIdentificationNumber: ['', Validators.compose([Validators.required, Validators.pattern('^[A-Za-z0-9]+$')])],
          orderTypeCode: ['', Validators.required],
          orderSubTypeCode: '',
          rmaNumber: ['', Validators.compose([Validators.required,
            Validators.pattern('^[A-Za-z0-9]{1,30}$'),
            Validators.minLength(1),
            Validators.maxLength(30)
          ])],
          vesselNumber: ['', Validators.compose([Validators.minLength(1), Validators.maxLength(30)])],
          voyageNumber: ['', Validators.compose([Validators.minLength(1), Validators.maxLength(30)])],
          carrierName: '',
          carrierQuoteNumber: ['', Validators.compose([Validators.required, Validators.pattern('^[A-Za-z0-9]{1,30}$')])],
          carrierBoothNumber: ['', Validators.compose([Validators.required, Validators.pattern('^[A-Za-z0-9]{1,30}$')])],
          volcarrierName: '',
          volcarrierQuoteNumber: ['', Validators.compose([Validators.required, Validators.pattern('^[A-Za-z0-9]{1,30}$')])],
          serviceType: ['', Validators.compose([Validators.required])],
          showinCelsiuss: '',
          showinCelsius: '',
          unitOfTemperatureMeasurementCode: '',
          temperatureLowRange: '',
          frontZonePrecoolTemperature: '',
          temperatureHighRange: '',
          rearZonePrecoolTemperature: '',
          customsbrokercarrier: ['', Validators.compose([Validators.required])],
          clearingCountryCode: ['', Validators.compose([Validators.required])],
          inbondFreight: '',
          bondHolderCarrierName: '',
          bondHolder: ['', Validators.compose([Validators.required])],
          bondType: '',
          bondNumber: [
            '',
            Validators.compose([Validators.required, Validators.pattern('^[A-Za-z0-9]{1,20}$'), Validators.maxLength(20)])
          ],
          entryNumber: ['', Validators.compose([Validators.required, Validators.pattern('^[A-Za-z0-9]{1,20}$'), Validators.maxLength(20)])],
          portOfEntry: '',
          portOfExit: '',
          orderValueAmount: [''],
          autoRateIndicator: '',
          fleetCode: ''
        }),

        serviceOfferingDetail: this.formBuilder.group({
          financeBusinessUnitCode: ['', Validators.required],
          serviceOfferingCode: ['', Validators.required],
          serviceLevelTypeCode: '',
          transitModeCode: '',
          requestedServiceLevelCode: '',
          freightChargeTermTypeCode: '',
          projectCode: '',
          dollaramount: '',
          orderServices: ''
        }),

        stopDTOs: this.getStopDetailList(), // this.formBuilder.array([ ]),

        siteProfile: this.formBuilder.group({
          customerDirections: '',
          generalInstructions: ''
        }),

        stopItemForm: this.addItem(),
        itemHandlingDetailDTOs: this.formBuilder.array([
          this.formBuilder.group({
            itemHandlingDetail: this.addHandlingUnit(),
            stopItemDTOs: this.formBuilder.array([
              this.addItemDto()
            ])
          })
        ]),

        operationInformationDetail: this.formBuilder.group({
          equipmentCategoryCode: ['', Validators.required],
          equipmentTypeCode: ['', Validators.required],
          equipmentLengthCode: ['', Validators.required],
          equipmentTypeRequiredIndicator: '',
          equipmentLengthRequiredIndicator: '',
          equipOption: '',
          freightSecurement: '',
          protectionMaterialHandling: '',
          orderNonCompanyEquipmentDetails: '',
          trailerPrefix: ['', Validators.required],
          trailerNumber: ['', Validators.required]
        })

      });
    } else {
      this.createTemplate();
    }
  }
  getInitDateTimeDetails() {
    return this.formBuilder.group({

      appointmentStartTimestamp: [
        '',
        Validators.compose([Validators.required, Validators.pattern('^(0[1-9]|1[0-2]):[0-5][0-9] (am|pm|AM|PM)$')])
      ],

      appointmentDateTimeDetailID: '',
      primaryAppointmentIndicator: '',
      appointmentEndDate: '',
      appointmentStartDate: '',

      appointmentEndTimestamp: [
        '',
        Validators.compose([Validators.required, Validators.pattern('^(0[1-9]|1[0-2]):[0-5][0-9] (am|pm|AM|PM)$')])
      ],
    });
  }
  getAppointmentInstruction() {
    return this.formBuilder.group({
      appointmentInstructionAssociationID: '',
      appointmentInstruction: '',
      appointmentInstructionAdditionalDetail: ''
    });
  }
  requestedAppointments() {
    return this.formBuilder.group({
      appointmentTypeCode: '',
      appointmentID: '',
      requestCallBackIndicator: '',
      recommendedAppointmentTimeStamp: '',
      appointmentInboundDate: '',
      appointmentDateTimeDetails: this.formBuilder.array([
        this.getInitDateTimeDetails()
      ])
    });
  }
  scheduledAppointments() {
    return this.formBuilder.group({
      appointmentTypeCode: '',
      appointmentID: '',
      requestCallBackIndicator: '',
      appointmentInboundDate: '',
      appointmentConfirmationNumber: '',
      appointmentInstructionAssociation: this.formBuilder.array([
        this.getAppointmentInstruction()
      ]),
      appointmentDateTimeDetails: this.formBuilder.array([
        this.getInitDateTimeDetails()
      ])
    });
  }
  getStopDetailList() {
    return this.formBuilder.group({
      stopID: '',
      locationID: ['', Validators.required],
      locationContactID: '',
      locationContactType: '',
      highCostDeliveryIndicator: '',
      stopReason: '',
      stopSequenceNumber: '',
      totalStopWeight: '',
      unitOfWeightMeasurementCode: '',
      initialOfferedDate: '',
      stopServices: this.formBuilder.array([
        this.getStopServices()
      ]),
      appointment: this.formBuilder.array([
        this.requestedAppointments(),
        this.scheduledAppointments()
      ])
    });
  }
  getStopServices() {
    return this.formBuilder.group({
      serviceID: '',
      serviceCount: '',
      unitOfServiceMeasurementCode: '',
      serviceLevelTypeCode: '',
      effectiveTimestamp: '',
      serviceType: '',
      serviceCategoryCode: ''
    });
  }
  addHandlingUnit() {
    return this.formBuilder.group({
      itemHandlingDetailID: '',
      itemHandlingTypeCode: ['', Validators.compose([Validators.required])],
      itemHandlingTypeQuantity: '',

      itemHandlingUnitHeight: [
        '',
        Validators.compose([this.jbhGlobals.customValidator.allowNull, this.jbhGlobals.customValidator.stopMeasurement])
      ],

      itemHandlingUnitLength: [
        '',
        Validators.compose([this.jbhGlobals.customValidator.allowNull, this.jbhGlobals.customValidator.stopMeasurement])
      ],

      itemHandlingUnitWidth: [
        '',
        Validators.compose([this.jbhGlobals.customValidator.allowNull, this.jbhGlobals.customValidator.stopMeasurement])
      ],

      unitOfLengthMeasurementCode: '',
      itemHandlingUnitVolume: '',
      unitOfVolumeMeasurementCode: '',

      itemHandlingUnitWeight: [
        '',
        Validators.compose([this.jbhGlobals.customValidator.allowNull, this.jbhGlobals.customValidator.stopMeasurement])
      ],

      unitOfWeightMeasurementCode: '',
      itemHandlingUnitDensity: '',
      unitOfDensityMeasurementCode: '',
      itemReference: '',
      itemHandlingDetailReferenceNumberAssociations: this.formBuilder.array([])
    });
  }

  addItemDto() {
    return this.formBuilder.group({
      stopItem: this.addItem(),
      unnaCode: '',
      properShippingName: '',
      primaryHazmatClass: '',
      secondaryHazmatClass: '',
      packagingGroup: '',
      stopbarCode: this.formBuilder.array([])
    });
  }

  addItem() {
    return this.formBuilder.group({
      stopItemID: '',
      packagingUnitTypeQuantity: ['', Validators.compose([this.jbhGlobals.customValidator.onlyNumber])],
      freightClassCode: ['', Validators.compose([Validators.maxLength(10)])],
      itemDensity: '',
      itemDescription: ['', Validators.compose([Validators.required, Validators.maxLength(80)])],

      itemHeight: [
        '',
        Validators.compose([this.jbhGlobals.customValidator.allowNull, this.jbhGlobals.customValidator.stopMeasurement])
      ],

      itemLength: [
        '',
        Validators.compose([this.jbhGlobals.customValidator.allowNull, this.jbhGlobals.customValidator.stopMeasurement])
      ],

      itemQuantity: ['', Validators.compose([this.jbhGlobals.customValidator.onlyNumber])],
      itemLengthType: null,
      itemVolumeType: null,
      itemStackingType: null,

      itemVolume: [
        '',
        Validators.compose([this.jbhGlobals.customValidator.allowNull, this.jbhGlobals.customValidator.stopMeasurement])
      ],

      itemWeight: [
        '',
        Validators.compose([this.jbhGlobals.customValidator.allowNull, this.jbhGlobals.customValidator.stopMeasurement])
      ],

      itemWidth: [
        '',
        Validators.compose([this.jbhGlobals.customValidator.allowNull, this.jbhGlobals.customValidator.stopMeasurement])
      ],

      nmfcNumber: ['', Validators.compose([this.jbhGlobals.customValidator.onlyNumber])],
      packagingUnitTypeCode: ['', Validators.compose([Validators.maxLength(10)])],
      skuNumber: ['', Validators.compose([Validators.maxLength(30)])],
      unitOfLengthMeasurementCode: ['', Validators.compose([Validators.maxLength(10)])],
      unitOfVolumeMeasurementCode: ['', Validators.compose([Validators.maxLength(10)])],
      unitOfWeightMeasurementCode: ['', Validators.compose([Validators.maxLength(10)])],
      unitOfDensityMeasurementCode: ['', Validators.compose([Validators.maxLength(10)])],
      stopItemHazardousMaterialDetails: this.formBuilder.array([
        this.addHazmat()
      ]),
      itemModelNumber: ['', Validators.compose([Validators.maxLength(30)])],
      itemClassificationCode: ['', Validators.compose([Validators.maxLength(10)])],
      itemTemperatureControlMethodCode: ['', Validators.compose([Validators.maxLength(10)])],
      supplierSKU: ['', Validators.compose([Validators.maxLength(30)])],
      itemMake: ['', Validators.compose([Validators.maxLength(30)])],
      itemManufacturer: ['', Validators.compose([Validators.maxLength(30)])],
      itemCategory: ['', Validators.compose([Validators.maxLength(30)])],
      itemPartNumber: ['', Validators.compose([Validators.maxLength(30)])],
      itemProtectionType: null,
      itemUniversalProductCode: ['', Validators.compose([Validators.maxLength(30)])],
      itemService: ['', Validators.compose([Validators.maxLength(1000)])],
      itemBarCodeType: ['', Validators.compose([Validators.maxLength(10)])],
      stopItemSerialNumberDetails: this.formBuilder.array([]),
      stopItemBarcodeDetails: this.formBuilder.array([]),
      stopItemServiceDetails: this.formBuilder.array([]),
      itemCharacteristics: '',
      popupItemDescription: ['', Validators.compose([Validators.maxLength(80)])],
      itemServiceQuantity: ['', Validators.compose([this.jbhGlobals.customValidator.onlyNumber])],
      serialNumber: ['', Validators.compose([this.jbhGlobals.customValidator.onlyNumber])],
      itemBarCodeNumber: ['', Validators.compose([Validators.maxLength(80)])],
    });
  }

  addHazmat() {
    return this.formBuilder.group({
      stopItemHazardousMaterialDetailID: '',
      driverCertificationRequiredIndicator: false,
      emergencyResponsePhoneNumber: '',
      unnaCode: '',
      propershippingname: '',
      packaginggroup: '',
      hazmatclasscodes: '',
      sechazmatclasscodes: '',
      hazardousMaterialSpecificationID: '',
      providerContractNumber: '',
      unitOfWeightMeasurementCode: '',
      netExplosiveMassQuantity: '',
      limitedQuantityIndicator: false,
      reportableQuantityIndicator: false,
      hazardousMaterialTechnicalname: '',
      placardRequiredIndicator: false
    });
  }

  createTemplate() {
    this.orderForm = this.formBuilder.group({
      orderValueTypeCode: '',
      orderBillingDetail: this.formBuilder.group({
        typeaheadModule: this.formBuilder.group({
          billToCode: ['', Validators.required],
          contactTypeCode: '',
          solicitorCode: ['', Validators.required],
          solicitorCodeContact: '',
          aditionalparty: '',
          lineofBusiness: ['', Validators.required],
          lineofbusinessContact: '',
        })
      }),
      shipmentInformation: this.formBuilder.group({
        shipmentRequirementsTags: '',
        shipmentIdentificationNumber: ['', Validators.compose([Validators.required, Validators.pattern('^[A-Za-z0-9]+$')])],
        orderTypeCode: ['', Validators.required],
        orderSubTypeCode: '',

        rmaNumber: [
          '',
          Validators.compose([
            Validators.required,
            Validators.pattern('^[A-Za-z0-9]{1,30}$'),
            Validators.minLength(1),
            Validators.maxLength(30)
          ])
        ],

        vesselNumber: ['', Validators.compose([Validators.minLength(1), Validators.maxLength(30)])],
        voyageNumber: ['', Validators.compose([Validators.minLength(1), Validators.maxLength(30)])],
        carrierName: '',
        carrierQuoteNumber: ['', Validators.compose([Validators.required, Validators.pattern('^[A-Za-z0-9]{1,30}$')])],
        carrierBoothNumber: ['', Validators.compose([Validators.required, Validators.pattern('^[A-Za-z0-9]{1,30}$')])],
        volcarrierName: '',
        volcarrierQuoteNumber: ['', Validators.compose([Validators.required, Validators.pattern('^[A-Za-z0-9]{1,30}$')])],
        serviceType: ['', Validators.compose([Validators.required])],
        showinCelsiuss: '',
        showinCelsius: '',
        unitOfTemperatureMeasurementCode: '',
        temperatureLowRange: '',
        frontZonePrecoolTemperature: '',
        temperatureHighRange: '',
        rearZonePrecoolTemperature: '',
        customsbrokercarrier: ['', Validators.compose([Validators.required])],
        clearingCountryCode: ['', Validators.compose([Validators.required])],
        inbondFreight: '',
        bondHolderCarrierName: '',
        bondHolder: ['', Validators.compose([Validators.required])],
        bondType: '',

        bondNumber: [
          '',
          Validators.compose([Validators.required, Validators.pattern('^[A-Za-z0-9]{1,20}$'), Validators.maxLength(20)])
        ],

        entryNumber: [
          '',
          Validators.compose([Validators.required, Validators.pattern('^[A-Za-z0-9]{1,20}$'), Validators.maxLength(20)])
        ],

        portOfEntry: '',
        portOfExit: '',
        orderValueAmount: [''],
        autoRateIndicator: '',
        fleetCode: ''
      }),

      serviceOfferingDetail: this.formBuilder.group({
        financeBusinessUnitCode: ['', Validators.required],
        serviceOfferingCode: ['', Validators.required],
        serviceLevelTypeCode: '',
        transitModeCode: '',
        requestedServiceLevelCode: '',
        freightChargeTermTypeCode: '',
        tradingPartner: '',
        projectCode: '',
        scac: '',
        dollaramount: '',
        orderServices: ''
      }),

      stopDTOs: this.getStopDetailList(), // this.formBuilder.array([ ]),

      siteProfile: this.formBuilder.group({
        customerDirections: '',
        generalInstructions: ''
      }),

      stopItemForm: this.addItem(),
      itemHandlingDetailDTOs: this.formBuilder.array([
        this.formBuilder.group({
          itemHandlingDetail: this.addHandlingUnit(),
          stopItemDTOs: this.formBuilder.array([
            this.addItemDto()
          ])
        })
      ]),

      operationInformationDetail: this.formBuilder.group({
        equipmentCategoryCode: '',
        equipmentTypeCode: '',
        equipmentLengthCode: '',
        equipmentTypeRequiredIndicator: '',
        equipmentLengthRequiredIndicator: '',
        equipOption: '',
        freightSecurement: '',
        protectionMaterialHandling: '',
        orderNonCompanyEquipmentDetails: '',
        trailerPrefix: '',
        trailerNumber: ''
      })

    });

  }
}
