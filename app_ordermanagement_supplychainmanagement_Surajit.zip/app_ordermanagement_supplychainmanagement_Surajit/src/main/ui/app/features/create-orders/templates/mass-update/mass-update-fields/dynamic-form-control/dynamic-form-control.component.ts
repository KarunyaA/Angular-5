import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';

import {JBHGlobals} from '../../../../../../app.service';

// import { ServiceOfferingComponent } from '../group-components/service-offering/service-offering.component';

@Component({
  selector: 'app-dynamic-form-control',
  templateUrl: './dynamic-form-control.component.html',
  styleUrls: ['./dynamic-form-control.component.scss']
})

export class DynamicFormControlComponent implements OnInit {

    @Input() templateDTO: any;

    public _control: any = {};
    @Input() set control(val: any) {
        if (val) {
            this._control = val;
            this.loadComponentServices();
        }
    }

    @Output() change: EventEmitter < any > = new EventEmitter();

    public checkBoxStatus;

    constructor(public jbhGlobals: JBHGlobals) {}

    ngOnInit() {
        if (this._control.fieldType === 'checkbox') {
            this.checkBoxStatus = this.templateDTO[this._control.fieldId];
        }
    }

    public setCheckValue(val, key): void {
        this.checkBoxStatus = val;
        this.templateDTO[key] = val;
        // [(ngModel)] = "this.templateDTO[cntl.fieldid]"
    }

    public loadComponentServices(): void {
        if (this._control.fieldType === 'dropdown') {
            switch (this._control.fieldId) {
                case 'financeBusinessUnitCode':
                    {
                        this.loadBusinessUnit();
                        break;
                    }
                case 'serviceOfferingCode':
                    {
                        this.loadServiceOffering();
                        break;
                    }
                case 'requestedServiceLevelCode':
                    {
                        this.loadServiceLevel();
                        break;
                    }
                case 'tradingPartnerCode':
                    {
                        this.loadTradingPartner();
                        break;
                    }
                case 'fleetCode':
                    {
                        this.loadFleetCode();
                        break;
                    }
                case 'orderTypeCode':
                    {
                        this.loadOrderType();
                        break;
                    }
                case 'unitOfOrderWeight':
                    {
                        this.loadUnitOfOrderWeight();
                        break;
                    }
                case 'unitOfMeasureForLWH':
                    {
                        this.loadUnitofLWH();
                        break;
                    }
                case 'operationalservices':
                    {
                        this.loadOperationalServices();
                        break;
                    }
                case 'customclearancecountry':
                    {
                        this.loadClearingCustoms();
                        break;
                    }
                case 'bondholderrole':
                    {
                        this.loadBondHolderRole();
                        break;
                    }
                case 'bondholderparty':
                    {
                        this.loadBondHolderParty();
                        break;
                    }
                case 'bondholdertype':
                    {
                        this.loadBondHolderTypes();
                        break;
                    }
                case 'portofentry':
                    {
                        this.loadPortOfEntry();
                        break;
                    }
                case 'portofexit':
                    {
                        this.loadPortOfExit();
                        break;
                    }
                case 'internationalservices':
                    {
                        this.loadInternationalServices();
                        break;
                    }
                case 'equipmenttype':
                    {
                        this.loadInternationalServices();
                        break;
                    }
                case 'equipmentlength':
                    {
                        this.loadInternationalServices();
                        break;
                    }
                case 'equipmentcategory':
                    {
                        this.loadInternationalServices();
                        break;
                    }
                case 'floorRequirement':
                    {
                        this.getFloorRequirement();
                        break;
                    }
                case 'doorRequirement':
                    {
                        this.getDoorRequirement();
                        break;
                    }
                case 'roofRequirement':
                    {
                        this.getRoofRequirement();
                        break;
                    }
                case 'freightSecurement':
                    {
                        this.getFreightSecurement();
                        break;
                    }
                case 'personalProtectionEquipment':
                    {
                        this.loadPersonalProtectionEquipment();
                        break;
                    }
                case 'materialHandlingEquipment':
                    {
                        this.loadMaterialHandlingEquipment();
                        break;
                    }
                case 'freightChargeTerms':
                    {
                        this.loadFreightChargeTerms();
                        break;
                    }
                case 'stopReason':
                    {
                        this.loadStopReason();
                        break;
                    }
                case 'stopServices':
                    {
                        this.loadStopServicesList();
                        break;
                    }
                default:
                    {
                        break;
                    }
            }
        }

    }

    public loadBusinessUnit(): void {

        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getbusinessunit).subscribe(data => {

            const options = [];
            for (const opt of data['_embedded']['serviceOfferingBusinessUnitTransitModeAssociations']) {
                const obj = {
                    'name': '',
                    'id': ''
                };
                obj.name = opt['financeBusinessUnitServiceOfferingAssociation']['financeBusinessUnitCode'];
                obj.id = obj.name;
                options.push(obj);
            }
            this._control.options = options;
        });
    }

    public loadServiceOffering(): void {
        const params = {
            'financeBusinessUnitCode': 'DCS',
            'projection': 'viewserviceofferingbusinessunittransitmode'
        };
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getserviceoffering, params).subscribe(data => {
            const options = [];
            for (const opt of data['_embedded']['serviceOfferingBusinessUnitTransitModeAssociations']) {
                const obj = {
                    'name': '',
                    'id': ''
                };
                obj.name = opt['serviceOfferingCode'];
                obj.id = obj.name;
                options.push(obj);
            }
            this._control.options = options;
        });
    }

    public loadServiceLevel(): void {
        const params = {
            'financeBusinessUnitCode': 'DCS',
            'serviceOfferingCode': 'Dedicated'
        };
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getservicelevels, params).subscribe(data => {
            const options = [];
            for (const opt of data['_embedded']['serviceLevelBusinessUnitServiceOfferingAssociations']) {
                const obj = {
                    'name': '',
                    'id': ''
                };
                obj.name = opt['serviceLevel']['serviceLevelCode'];
                obj.id = obj.name;
                options.push(obj);
            }
            this._control.options = options;
        });
    }

    public loadTradingPartner(): void {
        this._control.options = [{
                'name': 'TP 1'
            },
            {
                'name': 'TP 2'
            },
            {
                'name': 'TP 3'
            },
            {
                'name': 'TP 4'
            }
        ];
    }

    public loadFleetCode(): void {
        const params = {
            'businessunit': 'DCS'
        };
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getfleetcode, params).subscribe(data => {
            const options = [];
            for (const opt of data) {
                const obj = {
                    'name': '',
                    'id': ''
                };
                obj.name = opt['description'];
                obj.id = opt['id'];
                options.push(obj);
            }
            this._control.options = options;
        });
    }

    public loadOrderType() {
        const params = {
            'financeBusinessUnitCode': 'DCS',
            'serviceOfferingCode': 'Dedicated'
        };
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getordertype, params, false).subscribe(data => {
            const options = [];
            for (const opt of data['_embedded']['orderTypeFinanceBusinessUnitServiceOfferingAssociations']) {
                const obj = {
                    'name': '',
                    'id': ''
                };
                obj.name = opt['orderType']['orderTypeDescription'];
                obj.id = opt['orderType']['orderTypeCode'];
                options.push(obj);
            }
            this._control.options = options;
        });
    }
    public loadUnitOfOrderWeight() {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getUnitOfWeight).subscribe(data => {
            const options = [];
            for (const opt of data['_embedded']['unitOfWeightMeasurements']) {
                const obj = {
                    'name': '',
                    'id': ''
                };
                obj.name = opt['unitOfWeightMeasurementDescription'];
                obj.id = opt['unitOfWeightMeasurementCode'];
                options.push(obj);
            }
            this._control.options = options;
        });
    }
    public loadUnitofLWH() {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getUnitofLength).subscribe(data => {
            const options = [];
            for (const opt of data['_embedded']['unitOfLengthMeasurements']) {
                const obj = {
                    'name': '',
                    'id': ''
                };
                obj.name = opt['unitOfLengthMeasurementDescription'];
                obj.id = opt['unitOfLengthMeasurementCode'];
                options.push(obj);
            }
            this._control.options = options;
        });
    }

    public loadOperationalServices() {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getoperationalservices).subscribe(data => {
            //          const options = [];
            //          for (const opt of data['_embedded']['serviceTypes']) {
            //            const obj = {
            //                        'name': '',
            //                        'id': ''
            //                    };
            //            obj.name = opt['unitOfLengthMeasurementDescription'];
            //            obj.id = opt['unitOfLengthMeasurementCode'];
            //                options.push(obj);
            //            }
            //          this._control.options = options;

            //            this.operationalServicesList = data['_embedded']['serviceTypes'];
            //              for ( let i = 0; i < this.operationalServicesList.length; i++) {
            //                this.operationalServicesListDescription.push(this.operationalServicesList[i]['serviceTypeDescription']);
            //              }
        });
    }
    public loadClearingCustoms() {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getclearingcustoms).subscribe(data => {
            const options = [];
            for (const opt of data['country']) {
                const obj = {
                    'name': '',
                    'id': ''
                };
                obj.name = opt['name'];
                obj.id = opt['code'];
                options.push(obj);
            }
            this._control.options = options;
        });
    }
    public loadBondHolderRole() {
        const params = {
            'businessUnit': 'DCS',
            'transitMode': 'Truck'
        };
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getbondholderrole, params).subscribe(data => {
            const options = [];
            for (const opt of data) {
                const obj = {
                    'name': '',
                    'id': ''
                };
                obj.name = opt['bondHolderDescription'];
                obj.id = opt['bondHolderCode'];
                options.push(obj);
            }
            this._control.options = options;
        });
    }
    public loadBondHolderParty() {
        const params = {
            'bondHolderCode': 'Broker'
        };
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getbondholderparty, params, true).subscribe(data => {
            // this.bondHolderPartyList = data['_embedded']['bondHolderCarriers'];
            const options = [];
            for (const opt of data['_embedded']['bondHolderCarriers']) {
                const obj = {
                    'name': '',
                    'id': ''
                };
                obj.name = opt['bondHolderCarrierTypeDescription'];
                obj.id = obj.name;
                options.push(obj);
            }
            this._control.options = options;
        });
    }
    public loadBondHolderTypes() {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getbondholdertype).subscribe(data => {
            // this.bondHolderTypesList = data['_embedded']['bondTypes'];
            const options = [];
            for (const opt of data['_embedded']['bondTypes']) {
                const obj = {
                    'name': '',
                    'id': ''
                };
                obj.name = opt['bondTypeDescription'];
                obj.id = opt['bondTypeCode'];
                options.push(obj);
            }
            this._control.options = options;
        });
    }

    public loadPortOfEntry() {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getportofentry).subscribe(data => {
            // this.portOfEntryList = data['EntryPort'];
            const options = [];
            for (const opt of data['_embedded']['EntryPort']) {
                const obj = {
                    'name': '',
                    'id': ''
                };
                obj.name = opt['description'];
                obj.id = opt['id'];
                options.push(obj);
            }
            this._control.options = options;
        });
    }
    public loadPortOfExit() {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getportofexit).subscribe(data => {
            // this.portOfExitList = data['ExitPort'];
            const options = [];
            for (const opt of data['_embedded']['ExitPort']) {
                const obj = {
                    'name': '',
                    'id': ''
                };
                obj.name = opt['description'];
                obj.id = opt['code'];
                options.push(obj);
            }
            this._control.options = options;
        });
    }
    public loadInternationalServices() {
        const params = {
            'serviceCategoryCode': 'IOS'
        };
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getinternationalservices, params).subscribe(data => {
            // this.internationalServicesList = data['_embedded']['serviceTypes'];
            const options = [];
            for (const opt of data['_embedded']['serviceTypes']) {
                const obj = {
                    'name': '',
                    'id': ''
                };
                obj.name = opt['serviceTypeDescription'];
                obj.id = opt['serviceTypeCode'];
                options.push(obj);
            }
            this._control.options = options;
        });
    }
    public getEquipmentType() {
        const params = {
            financebusinessunitcode: 'ICS',
            serviceofferingcode: 'Dedicated'
        };
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getEquipmentType, params).subscribe(data => {
            // this.equipmentType = data['_embedded']['equipmentTypes'];
            const options = [];
            for (const opt of data['_embedded']['equipmentTypes']) {
                const obj = {
                    'name': '',
                    'id': ''
                };
                obj.name = opt['equipmentTypeDescription'];
                obj.id = obj.name;
                options.push(obj);
            }
            this._control.options = options;
        });
    }
    public getEquipmentLength() {
        const params = {
            'equipmentclassificationtypeassociationid': 7
        };
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getEquipmentLength, params).subscribe(data => {
            // this.equipmentLength = data['_embedded']['equipmentRequirementSpecificationAssociations'];
            const options = [];
            for (const opt of data['_embedded']['equipmentRequirementSpecificationAssociations']) {
                const obj = {
                    'name': '',
                    'id': ''
                };
                obj.name = opt['equipmentRequirementSpecification']['equipmentRequirementSpecificationDescription'];
                obj.id = obj.name;
                options.push(obj);
            }
            this._control.options = options;
        });
    }
    public getEquipmentCategory() {
        const params = {
            financebusinessunitcode: 'ICS',
            serviceofferingcode: 'Dedicated'
        };
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getEquipmentCategory, params).subscribe(data => {
            // this.equipmentCategory = data['_embedded']['equipmentClassifications'];
            const options = [];
            for (const opt of data['_embedded']['equipmentClassifications']) {
                const obj = {
                    'name': '',
                    'id': ''
                };
                obj.name = opt['equipmentClassificationDescription'];
                obj.id = obj.name;
                options.push(obj);
            }
            this._control.options = options;
        });
    }
    public getFloorRequirement() {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getEquipmentOptionFeatures).subscribe(data => {
            const options = [];
            //          for (const opt of data['_embedded']['equipmentRequirementSpecificationAssociations']) {
            //            const equipCode = opt['equipmentRequirementType']['equipmentRequirementTypeCode'];
            //            if(equipCode === 'Floor') {
            //              const obj = {
            //                          'name': '',
            //                          'id': ''
            //                      };
            //              const description = opt['equipmentRequirementSpecification']['equipmentRequirementSpecificationDescription'];
            //              obj.name = description + ' ' + equipCode;
            //              obj.id = description;
            //              options.push(obj);
            //            }
            //          }

            //          Mock Data Service
            for (const opt of data) {
                const equipCode = opt['code'];
                if (equipCode === 'Floor') {
                    const obj = {
                        'name': '',
                        'id': ''
                    };
                    obj.name = opt['associatedDescription'] + ' ' + equipCode;
                    obj.id = opt['associatedDescription'];
                    options.push(obj);
                }
            }
            this._control.options = options;
        });
    }
    public getDoorRequirement() {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getEquipmentOptionFeatures).subscribe(data => {
            const options = [];
            //          for (const opt of data['_embedded']['equipmentRequirementSpecificationAssociations']) {
            //            const equipCode = opt['equipmentRequirementType']['equipmentRequirementTypeCode'];
            //            if(equipCode === 'Door') {
            //              const obj = {
            //                          'name': '',
            //                          'id': ''
            //                      };
            //              const description = opt['equipmentRequirementSpecification']['equipmentRequirementSpecificationDescription'];
            //              obj.name = description + ' ' + equipCode;
            //              obj.id = description;
            //              options.push(obj);
            //            }
            //          }

            //          Mock Data Service
            for (const opt of data) {
                const equipCode = opt['code'];
                if (equipCode === 'Door') {
                    const obj = {
                        'name': '',
                        'id': ''
                    };
                    obj.name = opt['associatedDescription'] + ' ' + equipCode;
                    obj.id = opt['associatedDescription'];
                    options.push(obj);
                }
            }
            this._control.options = options;
        });
    }
    public getRoofRequirement() {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getEquipmentOptionFeatures).subscribe(data => {
            const options = [];
            //          for (const opt of data['_embedded']['equipmentRequirementSpecificationAssociations']) {
            //            const equipCode = opt['equipmentRequirementType']['equipmentRequirementTypeCode'];
            //            if(equipCode === 'Roof') {
            //              const obj = {
            //                          'name': '',
            //                          'id': ''
            //                      };
            //              const description = opt['equipmentRequirementSpecification']['equipmentRequirementSpecificationDescription'];
            //              obj.name = description + ' ' + equipCode;
            //              obj.id = description;
            //              options.push(obj);
            //            }
            //          }

            //          Mock Data Service
            for (const opt of data) {
                const equipCode = opt['code'];
                if (equipCode === 'Roof') {
                    const obj = {
                        'name': '',
                        'id': ''
                    };
                    obj.name = opt['associatedDescription'] + ' ' + equipCode;
                    obj.id = opt['associatedDescription'];
                    options.push(obj);
                }
            }
            this._control.options = options;
        });
    }
    public getFreightSecurement() {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getEquipmentOptionFeatures).subscribe(data => {
            const options = [];
            //          for (const opt of data['_embedded']['equipmentRequirementSpecificationAssociations']) {
            //            const equipCode = opt['equipmentRequirementType']['equipmentRequirementTypeCode'];
            //            if(equipCode === 'Freight') {
            //              const obj = {
            //                          'name': '',
            //                          'id': ''
            //                      };
            //              const description = opt['equipmentRequirementSpecification']['equipmentRequirementSpecificationDescription'];
            //              obj.name = description + ' ' + equipCode;
            //              obj.id = description;
            //              options.push(obj);
            //            }
            //          }

            //          Mock Data Service
            for (const opt of data) {
                const equipCode = opt['code'];
                if (equipCode === 'Freight') {
                    const obj = {
                        'name': '',
                        'id': ''
                    };
                    obj.name = opt['associatedDescription'] + ' ' + equipCode;
                    obj.id = opt['associatedDescription'];
                    options.push(obj);
                }
            }
            this._control.options = options;
        });
    }
    public loadPersonalProtectionEquipment() {
        // Get all PersonalProtection And MaterialHandling Equipment
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getProtectionMaterialHandling).subscribe(data => {
            const options = [];
            for (const opt of data['_embedded']['equipmentRequirementSpecificationAssociations']) {
                const equipCode = opt['equipmentRequirementType']['equipmentRequirementTypeCode'];
                if (equipCode === 'PersnalPro') {
                    const obj = {
                        'name': '',
                        'id': ''
                    };
                    obj.name = opt['equipmentRequirementSpecification']['equipmentRequirementSpecificationDescription'];
                    obj.id = obj.name;
                    options.push(obj);
                }
            }
            this._control.options = options;
        });
    }
    public loadMaterialHandlingEquipment() {
        // Get all PersonalProtection And MaterialHandling Equipment
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getProtectionMaterialHandling).subscribe(data => {
            const options = [];
            for (const opt of data['_embedded']['equipmentRequirementSpecificationAssociations']) {
                const equipCode = opt['equipmentRequirementType']['equipmentRequirementTypeCode'];
                if (equipCode === 'MatHandEqu') {
                    const obj = {
                        'name': '',
                        'id': ''
                    };
                    obj.name = opt['equipmentRequirementSpecification']['equipmentRequirementSpecificationDescription'];
                    obj.id = obj.name;
                    options.push(obj);
                }
            }
            this._control.options = options;
        });
    }
    public loadFreightChargeTerms() {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getfreightchargeterms).subscribe(data => {
            // this.freightChargeList = data['_embedded']['freightChargeTerms'];
            const options = [];
            for (const opt of data['_embedded']['freightChargeTerms']) {
                const obj = {
                    'name': '',
                    'id': ''
                };
                obj.name = opt['freightCode'];
                obj.id = obj.name;
                options.push(obj);
            }
            this._control.options = options;
        });
    }
    public loadStopReason() {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getstopreason).subscribe(data => {
            // this.stopReasonList = data['_embedded']['stopReasons'];
            const options = [];
              for (const opt of data['_embedded']['stopReasons']) {
                  const obj = {
                      'name': '',
                      'id': ''
                  };
                  obj.name = opt['stopReasonDescription'];
                  obj.id = opt['stopReasonCode'];
                  options.push(obj);
              }
              this._control.options = options;
        });
    }
    public loadAppointmentInstruction() {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getappointmentinstruction).subscribe(data => {
//            let appointmentInstructionList = this.jbhGlobals.utils.uniqBy(data['_embedded']['appointmentInstructions'],
//              'appointmentInstructionText');
//            let appointmentInstructionListObj = this.jbhGlobals.utils.clone(appointmentInstructionList);
//            appointmentInstructionList = this.jbhGlobals.utils.map(appointmentInstructionList, 'appointmentInstructionText');
        });
    }
    public loadStopServicesList() {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getstopserviceslist).subscribe(data => {
//            this.serviceLevelTypeCodeList = this.jbhGlobals.utils.uniqBy(data['_embedded']['serviceTypes'], 'serviceTypeDescription');
//            this.serviceLevelTypeCodeListObj = this.jbhGlobals.utils.clone(this.serviceLevelTypeCodeList);
//            this.serviceLevelTypeCodeList = this.jbhGlobals.utils.map(this.serviceLevelTypeCodeList, 'serviceTypeDescription');
            console.log(data);
        });
    }
}
