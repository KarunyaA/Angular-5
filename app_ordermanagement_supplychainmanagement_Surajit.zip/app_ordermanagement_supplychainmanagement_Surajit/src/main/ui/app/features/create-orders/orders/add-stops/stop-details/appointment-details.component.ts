import { Component, Input, OnInit } from '@angular/core';
import { IMyOptions, IMyDateModel } from 'mydatepicker';
import { JBHGlobals } from '../../../../../app.service';
import { OrderService } from '../../order.service';
import { DatePipe } from '@angular/common';
import { OrderFormBuilder } from '../../order-form-builder.service';

@Component({
  selector: 'app-appointment-details',
  templateUrl: './appointment-details.component.html',
  styleUrls: ['./appointment-details.component.scss'],
  providers: [ DatePipe ]
})
export class AppointmentDetailsComponent implements OnInit {
    @Input() apptType;
   @Input() stopID;
   @Input() position;
   @Input() appointmentData;
   @Input() scheduledAppts;
   @Input() apptRequested;
   public appointmentForm: any;
   public apptStartDate: any;
   public apptStartTime: any;
   public apptEndDate: any;
   public apptEndTime: any;
   public apptJson: any;
   public apptStartDateTime: any;
   public apptEndDateTime: any;
   public isApptReqSaved = true;
   public isApptScheduledSaved = true;
   @Input() dateTimeForm: any;
   public orderData: any;
   public myDatePickerOptions: IMyOptions = {
       todayBtnTxt: 'Today',
       dateFormat: 'mm-dd-yyyy',
       firstDayOfWeek: 'mo',
       showTodayBtn: false,
       showClearDateBtn: false,
       editableDateField: false,
       sunHighlight: true,
       height: '34px',
       width: '170px',
       inline: false,
       // disableUntil: {year: 2016, month: 8, day: 10},
       dayLabels: { su: 'S', mo: 'M', tu: 'T', we: 'W', th: 'T', fr: 'F', sa: 'S' },
       selectionTxtFontSize: '14px'
   };
   constructor(public jbhGlobals: JBHGlobals, public datePipe: DatePipe,
       public orderService: OrderService,
       public orderFormBuilder: OrderFormBuilder) {}
   ngOnInit() {
       this.appointmentForm = this.orderFormBuilder.getInitDateTimeDetails();
       this.loadOrderData();
       this.populateApptDetails();
   }
   public loadOrderData() {
       if (this.jbhGlobals.utils.isEmpty(this.orderData)) {
           this.orderService.getData().subscribe(sharedOrderData => {
               if (!this.jbhGlobals.utils.isEmpty(sharedOrderData)) {
                   this.orderData = sharedOrderData;
               }
           }, (err: Error) => {
             return false;
        });
       }
   }
   public populateApptDetails() {
       if (this.apptType === 0) {
           this.apptStartDateTime = this.apptRequested.appointmentStartTimestamp;
           this.apptEndDateTime = this.apptRequested.appointmentEndTimestamp;
       } else if (this.apptType === 1) {
           this.apptStartDateTime = this.scheduledAppts.appointmentStartTimestamp;
           this.apptEndDateTime = this.scheduledAppts.appointmentEndTimestamp;
       }
       if (this.apptStartDateTime && this.apptStartDateTime !== undefined &&
           this.apptEndDateTime && this.apptEndDateTime !== undefined) {
           this.setAppointmentDetails(this.apptStartDateTime, this.apptEndDateTime);
       }
   }
   public setAppointmentDetails(apptStartDateTime, apptEndDateTime) {
       const startDateLimit = apptStartDateTime.indexOf('T');
       const datePipe = new DatePipe('en-US');
       const startDate = apptStartDateTime.substr(0, startDateLimit);
       const apptStartDate = new Date(startDate);
       this.appointmentForm['controls']['appointmentStartDate']['setValue']({
           date: {
               year: apptStartDate.getFullYear(),
               month: apptStartDate.getMonth(),
               day: apptStartDate.getDate()
           }
       });
       const apptStartTime = datePipe.transform(apptStartDateTime, 'hh:mm a');
       this.appointmentForm['controls']['appointmentStartTimestamp']['setValue'](apptStartTime);
       const endDateLimit = apptEndDateTime.indexOf('T');
       const endDate = apptEndDateTime.substr(0, endDateLimit);
       const apptEndDate = new Date(endDate);
       this.appointmentForm['controls']['appointmentEndDate']['setValue']({
           date: {
               year: apptEndDate.getFullYear(),
               month: apptEndDate.getMonth(),
               day: apptEndDate.getDate()
           }
       });
       const appEndTime = datePipe.transform(apptEndDateTime, 'hh:mm a');
       this.appointmentForm['controls']['appointmentEndTimestamp']['setValue'](appEndTime);
   }
   public removeAppointmentDate(appt: number, pos: number, apptId: number) {
       const appointmentArray = this.orderData.stopDTOs.stop.appointment[appt].appointmentDateTimeDetails;
       appointmentArray.splice(pos, 1);
       const apptID = '/' + apptId;
       if (!apptID) {
           this.jbhGlobals.apiService.removeData(this.jbhGlobals.endpoints.order.crudApptDetails + apptID).subscribe(apptData => {
               this.jbhGlobals.logger.info('Appointment Deleted');
           }, (err: Error) => {
             return false;
        });
       }
   }
   public appointmentJson(apptType: number, appointmentStartTime: any, appointmentEndTime: any,
       primaryCallBack: string, apptId: number, stopId: number): any {
       const stopID = '/' + stopId;
       if (apptType === 1) {
           return this.apptJson = {
               'appointmentID': apptId,
               'appointmentTypeCode': 'scheduled',
               'appointmentConfirmationNumber': '',
               'requestCallBackIndicator': 'Y',
               'appointmentInboundDate': '',
               'appointmentDetails': [{
                   'appointmentDetailID': '',
                   'appointmentSetReasonCode': '02'
               }],
               'appointmentDateTimeDetails': [{
                   'appointmentDateTimeDetailID': '',
                   'appointmentStartTimestamp': appointmentStartTime,
                   'appointmentEndTimestamp': appointmentEndTime,
                   'primaryAppointmentIndicator': primaryCallBack
               }],
               'appointmentInstructionAssociations': [{
                   'appointmentInstructionAssociationID': '',
                   'appointmentInstruction': 1,
                   'appointmentInstructionAdditionalDetail': ''
               }],
               'stop': stopID
           };
       } else {
           return this.apptJson = {
               'appointmentID': apptId,
               'appointmentTypeCode': 'requested',
               'requestCallBackIndicator': 'Y',
               'recommendedAppointmentTimeStamp': '',
               'appointmentInboundDate': '',
               'appointmentDetails': [{
                   'appointmentDetailID': '',
                   'appointmentSetReasonCode': '02'
               }],
               'appointmentDateTimeDetails': [{
                   'appointmentDateTimeDetailID': '',
                   'appointmentStartTimestamp': appointmentStartTime,
                   'appointmentEndTimestamp': appointmentEndTime,
                   'primaryAppointmentIndicator': primaryCallBack
               }],
               'stop': stopID
           };
       }
   }
   public addAppointmentDetails(apptType: number, apptStartDate: any, apptStartTime: any,
       apptEndDate: any, apptEndTime: any, primaryCallBack: string, stopId: number) {
       let appointmentStartTime = apptStartDate + ' ' + apptStartTime;
       let appointmentEndTime = apptEndDate + ' ' + apptEndTime;
       const datePipe = new DatePipe('en-US');
       appointmentStartTime = datePipe.transform(appointmentStartTime, 'yyyy-MM-ddThh:mm:ss.000');
       appointmentEndTime = datePipe.transform(appointmentEndTime, 'yyyy-MM-ddThh:mm:ss.000');
       const apptId: any = '';
       this.apptJson = this.appointmentJson(apptType, appointmentStartTime, appointmentEndTime, primaryCallBack, apptId, stopId);
       this.jbhGlobals.apiService.addData(this.jbhGlobals.endpoints.order.crudApptDetails, this.apptJson).subscribe(apptData => {
           if (!this.jbhGlobals.utils.isEmpty(apptData)) {
               if (apptType === 0) {
                   this.isApptReqSaved = true;
               } else {
                   this.isApptScheduledSaved = true;
               }
               this.jbhGlobals.logger.info('Appointment Added Successfully');
           }
       }, (err: Error) => {
             if (apptType === 0) {
                 this.isApptReqSaved = false;
             } else {
                 this.isApptScheduledSaved = false;
             }
             return false;
        });
   }
   public updateAppointmentDetails(apptType: number, apptStartDate: any, apptStartTime: any,
       apptEndDate: any, apptEndTime: any, primaryCallBack: string, apptId: number, stopId: number) {
       let appointmentStartTime = apptStartDate + ' ' + apptStartTime;
       let appointmentEndTime = apptEndDate + ' ' + apptEndTime;
       const datePipe = new DatePipe('en-US');
       appointmentStartTime = datePipe.transform(appointmentStartTime, 'yyyy-MM-ddThh:mm:ss.000');
       appointmentEndTime = datePipe.transform(appointmentEndTime, 'yyyy-MM-ddThh:mm:ss.000');
       const apptID = '/' + apptId;
       this.apptJson = this.appointmentJson(apptType, appointmentStartTime, appointmentEndTime, primaryCallBack, apptId, stopId);
       this.jbhGlobals.apiService.updateData(this.jbhGlobals.endpoints.order.crudApptDetails + apptID,
           this.apptJson).subscribe(apptData => {
           if (!this.jbhGlobals.utils.isEmpty(apptData)) {
               if (apptType === 0) {
                   this.isApptReqSaved = true;
               } else {
                   this.isApptScheduledSaved = true;
               }
               this.jbhGlobals.logger.info('Appointment Updated Successfully');
           }
       }, (err: Error) => {
             return false;
        });
   }
   onStartDateChanged(event: IMyDateModel) {
       this.apptStartDate = event.formatted;
       /* if (this.apptEndDate && !(this.apptStartDate <= this.apptEndDate)) {
           this.jbhGlobals.notifications.alert('Warning', 'Start date must be lesser than or equal to end date');
           return;
       } */
   }
   onStartTimeChanged(apptType, startTimeStamp) {
       if (/^(0[1-9]|1[0-2]):[0-5][0-9] (am|pm|AM|PM)$/i.test(startTimeStamp) === false) {
           this.appointmentForm.controls['appointmentStartTimestamp'].setValue('');
           return;
       }
       this.apptStartTime = startTimeStamp;
       /* if (this.apptEndTime && !(this.apptStartTime < this.apptEndTime)) {
           this.jbhGlobals.notifications.alert('Warning', 'Start time must be lesser than end time');
           return;
       } */
   }
   onEndDateChanged(event: IMyDateModel) {
       this.apptEndDate = event.formatted;
       if (!(this.apptEndDate >= this.apptStartDate)) {
           this.jbhGlobals.notifications.alert('Warning', 'End date must be greater than or equal to start date');
           return;
       }
   }
   onEndTimeChanged(appt: any, apptType, endTimeStamp, indx: number) {
       if (/^(0[1-9]|1[0-2]):[0-5][0-9] (am|pm|AM|PM)$/i.test(endTimeStamp) === false) {
           this.appointmentForm.controls['appointmentEndTimestamp'].setValue('');
           return;
       }
       let apptId;
       if (appt && appt.appointmentID) {
           apptId = appt.appointmentID;
       }
       this.apptEndTime = endTimeStamp;
       let primaryIndicator;
       if (!(this.apptEndTime > this.apptStartTime)) {
           this.jbhGlobals.notifications.alert('Warning', 'End time must be greater than start time');
           return;
       }
       if (indx === 0) {
           primaryIndicator = 'Y';
       } else {
           primaryIndicator = 'N';
       }
       if (!this.stopID) {
           this.jbhGlobals.notifications.alert('Warning', 'Stop should be created before adding appointment');
           return;
       } else if (apptId) {
           this.updateAppointmentDetails(apptType, this.apptStartDate, this.apptStartTime,
           this.apptEndDate, this.apptEndTime, primaryIndicator, apptId, this.stopID);
       } else {
           this.addAppointmentDetails(apptType, this.apptStartDate, this.apptStartTime,
           this.apptEndDate, this.apptEndTime, primaryIndicator, this.stopID);
       }
   }
}

