import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddStopsRoutingModule } from './add-stops-routing.module';
import { AddStopsComponent } from './add-stops.component';
import { HandlingUnitsComponent } from './handling-units/handling-units.component';
import { ItemDetailsComponent } from './item-details/item-details.component';
import { StopDetailsComponent } from './stop-details/stop-details.component';
import { AppointmentDetailsComponent } from './stop-details/appointment-details.component';
import { ReactiveFormsModule} from '@angular/forms';
import { ItemHazmatComponent } from './item-details/item-hazmat.component';
// import { DatepickerModule } from 'ngx-bootstrap/datepicker';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { MyDatePickerModule } from 'mydatepicker';
import { TypeaheadModule } from 'ngx-bootstrap/typeahead';
import { PopoverModule } from 'ngx-bootstrap/popover';
import { TagInputModule } from 'ng2-tag-input';
import { AccordionModule } from 'ngx-bootstrap';
import { ModalModule } from 'ngx-bootstrap';
import { SiteProfileComponent } from './stop-details/site-profile/site-profile.component';
import { StopHandlingComponent } from './handling-units/stop-handling.component';
import { DeliveryHandlingUnitsComponent } from './delivery-handling-units/delivery-handling-units.component';
// import { SelectModule } from 'ng2-select';
import { SelectModule } from '../../../../shared/select';
import { JbhUtilsModule } from '../../../../shared/jbh-utils/jbh-utils.module';
import { StopResequenceComponent } from './stop-details/stop-resequence/stop-resequence.component';
import { CreateLocationComponent } from './stop-details/create-location/create-location.component';

@NgModule({
    imports: [
        CommonModule,
        AddStopsRoutingModule,
        PopoverModule.forRoot(),
        MyDatePickerModule,
        TypeaheadModule.forRoot(),
        //  DatepickerModule.forRoot(),
        BsDropdownModule.forRoot(),
        AccordionModule.forRoot(),
        ReactiveFormsModule,
        TagInputModule,
        ModalModule.forRoot(),
        SelectModule,
        JbhUtilsModule
    ],

    declarations: [
        AddStopsComponent,
        AppointmentDetailsComponent,
        HandlingUnitsComponent,
        ItemDetailsComponent,
        StopDetailsComponent,
        ItemHazmatComponent,
        SiteProfileComponent,
        StopHandlingComponent,
        DeliveryHandlingUnitsComponent,
        StopResequenceComponent,
        CreateLocationComponent
    ],

    exports: [
        AddStopsComponent,
        AppointmentDetailsComponent,
        HandlingUnitsComponent,
        ItemDetailsComponent,
        StopDetailsComponent,
        ItemHazmatComponent,
        SiteProfileComponent,
        StopHandlingComponent,
        DeliveryHandlingUnitsComponent,
        StopResequenceComponent,
        CreateLocationComponent
    ]
})

export class AddStopsModule { }
