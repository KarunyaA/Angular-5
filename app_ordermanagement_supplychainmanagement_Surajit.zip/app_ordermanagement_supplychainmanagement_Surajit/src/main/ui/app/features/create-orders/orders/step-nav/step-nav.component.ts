import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'jbh-step-nav',
  templateUrl: './step-nav.component.html',
  styleUrls: ['./step-nav.component.scss']
})
export class StepNavComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
