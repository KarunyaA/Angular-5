import { Component,  Input, ViewChild, OnInit } from '@angular/core';
import { JBHGlobals } from '../../../../../app.service';
import { OrderService } from '../../order.service';
import { OrderFormBuilder } from '../../order-form-builder.service';

@Component({
    selector: 'app-item-hazmat',
    templateUrl: './item-hazmat.component.html',
    styleUrls: ['./item-details.component.scss']
})

export class ItemHazmatComponent implements OnInit {
    public itemHazmatForm: any;
    @Input() handlingIndex: any;
    @Input() dataIndex: any;
    public subscription: any;
    public orderData: any;
    public getUNNumberList: any[] = [];
    public getHazmatData: any[] = [];
    public debounceValue: any;
    public getProperShipping: any[] = [];
    public getPrimaryHzdList: any[] = [];
    public getSecondaryHzdList: any[] = [];
    public getPackagingGroup: any[] = [];
    public properShippingTemp: any[] = [];
    public primaryHazmatTemp: any[] = [];
    public secondaryHazmatTemp: any[] = [];
    public packagingGroupTemp: any[] = [];
    public hazMatSpecification: any[] = [];
    public itemWeightList: any[] = [];
    public unnNo: any;
    public finalHazmatObj: any;
    @ViewChild('netExplosiveQnty') netExplosiveQnty: any;
    @ViewChild('unitOfWeightMeasurementCode') unitOfWeightMeasurementCode: any;
    @ViewChild('placad') placad: any;
    @ViewChild('driverreq') driverreq: any;

    constructor(
        public jbhGlobals: JBHGlobals,
        public orderService: OrderService,
        public orderFormBuilder: OrderFormBuilder) {}

    ngOnInit() {
        this.loaditemWeight();
        this.itemHazmatForm = this.orderFormBuilder.addHazmat();
        if (this.jbhGlobals.utils.isEmpty(this.orderData)) {
            this.subscription = this.orderService.getData().subscribe(sharedOrderData => {
                this.orderData = sharedOrderData;
            });
        }
        this.debounceValue = this.jbhGlobals.settings.debounce;
        this.itemHazmatForm['controls']['unnaCode']['valueChanges']
            .debounceTime(this.debounceValue)
            .distinctUntilChanged()
            .subscribe((value) => {
                if (value !== undefined && value.length > 1) {
                    this.getUNNumber(value);
                }
            }, (err: Error) => {
                console.log(err);
            });

    }

    public getUNNumber(val) {

        const unnObj = {
            'unnaCode': val,
            'projection': 'viewhazardousmaterialspecification'
        };

        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getUnnNo, unnObj).subscribe(data => {
            this.getUNNumberList = data;
        });
    }

    public loaditemWeight() {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getUnitOfWeight).subscribe(data => {
            this.itemWeightList = data['_embedded']['unitOfWeightMeasurements'];
        });
    }

    public selUNANumber(event) {
        this.netExplosiveQnty.nativeElement.disabled = 'disabled';
        this.unitOfWeightMeasurementCode.nativeElement.disabled = 'disabled';
        this.netExplosiveQnty.nativeElement.value = '';
        this.placad.nativeElement.disabled = 'disabled';
        this.placad.nativeElement.checked = false;
        this.driverreq.nativeElement.checked = false;
        this.unnNo = event.value;
        const unnObj = {
            'briefingReferenceRequests': {
                'briefing': [{
                    'hazMatSpecification': [{
                        'unnaCode': event.value,
                        'properShippingName': {
                            'name': ''
                        },
                        'packagingGroup': {
                            'code': ''
                        },
                        'hazMatClassType': [{
                            'hazMatClass': {
                                'code': ''
                            }
                        }]
                    }]
                }]
            }
        };

        this.jbhGlobals.apiService.addData(this.jbhGlobals.endpoints.order.getHazmatSecdy, unnObj).subscribe(data => {
            this.getHazmatData = data;
            this.getHazmatListData(this.getHazmatData);
        });

    }

    public getHazmatListData(hazMatData) {
        this.getProperShipping = hazMatData['properShippingName'];
        this.getPackagingGroup = hazMatData['packagingGroup'];
        this.getPrimaryHzdList = hazMatData['hazmatClassCodes'];
        this.getSecondaryHzdList = hazMatData['secHazmatClassCodes'];
        if (hazMatData['hazmatClassCodes'][0]['code'] === '1.4S') {
            this.netExplosiveQnty.nativeElement.disabled = false;
            this.unitOfWeightMeasurementCode.nativeElement.disabled = false;
        }
    }

    public onSelectProperShipping(properShippingVal) {
        if (this.jbhGlobals.utils.isEmpty(this.properShippingTemp)) {
            this.properShippingTemp = this.getHazmatData['packageGroupAndProperShippingNameMapping'][0]['properShippingName'];
            this.getHazmatDetailsByProperShipperName(properShippingVal.value);
        } else {
            this.getHazmatDetailsByProperShipperName(properShippingVal.value);
        }
    }

    public getHazmatDetailsByProperShipperName(properShippingVal) {
        this.getPackagingGroup = [];
        this.getPrimaryHzdList = [];
        this.getSecondaryHzdList = [];
        const properlen = this.properShippingTemp.length;
        for (let i = 0; i < properlen; i++) {
            if (this.properShippingTemp[i]['properShippingName'] === properShippingVal) {
                this.getPackagingGroup = this.properShippingTemp[i]['packageGroups'];
                this.getPrimaryHzdList = this.properShippingTemp[i]['hazmatClassCodes'];
                this.getSecondaryHzdList = this.properShippingTemp[i]['secHazmatClassCodes'];
            }

        }
    }


    public onSelectPrimaryHazmat(primaryHazmat) {
        if (this.jbhGlobals.utils.isEmpty(this.primaryHazmatTemp)) {
            this.primaryHazmatTemp = this.getHazmatData['packageGroupAndProperShippingNameMapping'][0]['hazmatClassCodes'];
            this.getHazmatDetailsByPrimaryClass(primaryHazmat.value);
        } else {
            this.getHazmatDetailsByPrimaryClass(primaryHazmat.value);
        }
    }

    public getHazmatDetailsByPrimaryClass(primaryHazmatVal) {
        this.getPackagingGroup = [];
        this.getSecondaryHzdList = [];
        this.getProperShipping = [];
        const primaryhazlen = this.primaryHazmatTemp.length;
        for (let i = 0; i < primaryhazlen; i++) {
            if (this.primaryHazmatTemp[i]['hazmatClassCode'] === primaryHazmatVal) {
                this.getPackagingGroup = this.primaryHazmatTemp[i]['packageGroups'];
                this.getSecondaryHzdList = this.primaryHazmatTemp[i]['secHazmatClassCodes'];
                this.getProperShipping = this.primaryHazmatTemp[i]['properShippingNames'];
            }

        }
    }

    public onSelectSecondaryHazmat(secHazmat) {
        if (this.jbhGlobals.utils.isEmpty(this.secondaryHazmatTemp)) {
            this.secondaryHazmatTemp = this.getHazmatData['packageGroupAndProperShippingNameMapping'][0]['secHazmatClassCodes'];
            this.getHazmatDetailsBySecondaryClass(secHazmat.value);
        } else {
            this.getHazmatDetailsBySecondaryClass(secHazmat.value);
        }
    }

    public getHazmatDetailsBySecondaryClass(secHazmatVal) {
        this.getPackagingGroup = [];
        this.getPrimaryHzdList = [];
        this.getProperShipping = [];
        const sechazlen = this.secondaryHazmatTemp.length;
        for (let i = 0; i < sechazlen; i++) {
            if (this.secondaryHazmatTemp[i]['secHazmatClassCodes'] === secHazmatVal) {
                this.getPackagingGroup = this.secondaryHazmatTemp[i]['packageGroups'];
                this.getPrimaryHzdList = this.secondaryHazmatTemp[i]['hazmatClassCodes'];
                this.getProperShipping = this.secondaryHazmatTemp[i]['properShippingNames'];
            }

        }
    }


    public onSelectPackingGroup(packGrp) {
        if (this.jbhGlobals.utils.isEmpty(this.packagingGroupTemp)) {
            this.packagingGroupTemp = this.getHazmatData['packageGroupAndProperShippingNameMapping'][0]['packageGroup'];
            this.getHazmatDetailsByPackagingGroup(packGrp.value);
        } else {
            this.getHazmatDetailsByPackagingGroup(packGrp.value);
        }
    }

    public getHazmatDetailsByPackagingGroup(packGrpVal) {
        this.getSecondaryHzdList = [];
        this.getPrimaryHzdList = [];
        this.getProperShipping = [];
        const pkglen = this.packagingGroupTemp.length;
        for (let i = 0; i < pkglen; i++) {
            if (this.packagingGroupTemp[i]['packageGroupName'] === packGrpVal) {
                this.getPrimaryHzdList = this.packagingGroupTemp[i]['hazmatClassCodes'];
                this.getSecondaryHzdList = this.packagingGroupTemp[i]['secHazmatClassCodes'];
                this.getProperShipping = this.packagingGroupTemp[i]['properShippingNames'];
            }

        }
    }

    public getHazmatSpecficationId(): any {
        const hazData = this.itemHazmatForm.value;
        this.hazMatSpecification = this.getHazmatData['briefingReference'][0]['hazMatSpecification'];
        const hazLen = this.hazMatSpecification.length;
        for (let i = 0; i < hazLen; i++) {
            const secHazClassCode = (this.hazMatSpecification[i].hazMatClassType[1] !== undefined) ?
             this.hazMatSpecification[i].hazMatClassType[1].hazMatClass.code : '';
            if (this.hazMatSpecification[i].packagingGroup.code === hazData.packaginggroup &&
                this.hazMatSpecification[i].properShippingName.name === hazData.propershippingname &&
                this.hazMatSpecification[i].hazMatClassType[0].hazMatClass.code === hazData.hazmatclasscodes &&
                secHazClassCode === hazData.sechazmatclasscodes
            ) {
                console.log(this.hazMatSpecification[i].hazMatSpecificationId);
                this.hazMatSpecification = this.hazMatSpecification;
                this.itemHazmatForm.value.stopItemHazardousMaterialDetailID = this.hazMatSpecification[0]['hazMatSpecificationId'];
                return this.finalHazmatObj = this.getPlaCardDetails();
            }
        }

    }

    public getPlaCardDetails(): any {
        const me = this;
        this.hazMatSpecification[0]['unnaCode'] = this.unnNo;
        this.hazMatSpecification[0]['properShippingName']['code'] = this.hazMatSpecification[0]['properShippingName']['name'];
        const PlacardVal = this.hazMatSpecification[0]['placard']['name'] + ' ' + this.hazMatSpecification[0]['unnaCode'].slice(-4);
        const operatorCodeHeader = {
            'userNameToken': 'rcon333'
        };
        const plaCardReqData = {
            'briefingRequests': {
                'briefing': [{
                    'briefingId': '',
                    'employeeId': '',
                    'dispatchType': {
                        'operatorCode': 'MUTR2'
                    },
                    'orderType': {
                        'orderNumber': '',
                        'truckDetails': {
                            'truckNumber': [
                                ''
                            ]
                        }
                    },
                    'highValue': {
                        'commodity': {
                            'type': {
                                'code': ''
                            },
                            'effDate': '',
                            'expDate': ''
                        },
                        'commodityName': ''
                    },
                    'auditFields': {
                        'auditFields': '',
                        'createdByName': '',
                        'createdByDate': '',
                        'updatedById': '',
                        'updatedByName': '',
                        'updatedByDate': ''
                    },
                    'orderNumbers': [
                        ''
                    ],
                    'hazMat': {
                        'placardingList': [{
                            //  'code': '11',
                            'code': PlacardVal
                        }],
                        'stopNumber': 1,
                        'detail': [{
                            'hazMatSpecification': this.hazMatSpecification[0],
                            'shipperDetails': {
                                'shipperId': ''
                            },
                            'placardException': {
                                'placardException': {
                                    'code': 'None'
                                }
                            },
                            'packageMeasurementType': {
                                'packageMeasurement': {
                                    'code': 'None'
                                }
                            },
                            'unitOfWeightMeasurementType': {
                                'unitOfWeightMeasurement': {
                                    'code': this.itemHazmatForm['controls']['unitOfWeightMeasurementCode']['value']
                                }
                            },
                            'commodityCode': '',
                            'packageQuantity': 2,
                            'weightQuantity': 3254,
                            'weightCategoryCode': 'BULK',
                            'facilityType': null
                        }]
                    }
                }]
            }
        };

        this.jbhGlobals.apiService.addData(this.jbhGlobals.endpoints.order.getPlaCardDetails, plaCardReqData, operatorCodeHeader)
            .subscribe(data => {
                if (data['briefings'][0]['hazMat']['placardingList'][0]['code'] !== 'NON REQUIRED') {
                    /* if(me.hazMatSpecification['hazMatClassType'][0]['hazMatClass']['code'] === '1.4') {
                       me.itemHazmatForm.value.driverCertificationRequiredIndicator=true;
                        me.itemHazmatForm.value.placardRequiredIndicator=true;
                        console.log();
                        return true;
                     } else if((me.itemHazmatForm.value.driverCertificationRequiredIndicator === false) ?
                    true:(me.itemHazmatForm.value.placardRequiredIndicator  === false) ?true:false){ */
                    me.placad.nativeElement.checked = true;
                    console.log(me.itemHazmatForm.value.stopItemHazardousMaterialDetailID);
                       this.finalHazmatObj = {
                        stopItemHazardousMaterialDetailID: me.itemHazmatForm.value.stopItemHazardousMaterialDetailID,
                        driverCertificationRequiredIndicator:  me.itemHazmatForm.value.driverCertificationRequiredIndicator,
                        emergencyResponsePhoneNumber: me.itemHazmatForm.value.emergencyResponsePhoneNumber,
                        hazardousMaterialSpecificationID: me.itemHazmatForm.value.hazardousMaterialSpecificationID,
                        providerContractNumber: me.itemHazmatForm.value.providerContractNumber,
                        unitOfWeightMeasurementCode: me.itemHazmatForm.value.unitOfWeightMeasurementCode,
                        netExplosiveMassQuantity: me.itemHazmatForm.value.netExplosiveMassQuantity,
                        limitedQuantityIndicator: me.itemHazmatForm.value.limitedQuantityIndicator
                          };
                } else {
                     this.finalHazmatObj = {
                        stopItemHazardousMaterialDetailID: me.itemHazmatForm.value.stopItemHazardousMaterialDetailID,
                        driverCertificationRequiredIndicator:  me.itemHazmatForm.value.driverCertificationRequiredIndicator,
                        emergencyResponsePhoneNumber: me.itemHazmatForm.value.emergencyResponsePhoneNumber,
                        hazardousMaterialSpecificationID: me.itemHazmatForm.value.hazardousMaterialSpecificationID,
                        providerContractNumber: me.itemHazmatForm.value.providerContractNumber,
                        unitOfWeightMeasurementCode: me.itemHazmatForm.value.unitOfWeightMeasurementCode,
                        netExplosiveMassQuantity: me.itemHazmatForm.value.netExplosiveMassQuantity,
                        limitedQuantityIndicator: me.itemHazmatForm.value.limitedQuantityIndicator
                          };
                }

            }/*,(err: Error) => {
                  this.jbhGlobals.notifications.error('Error', err);
             return false;
        }*/);

            return this.finalHazmatObj;
    }
}

