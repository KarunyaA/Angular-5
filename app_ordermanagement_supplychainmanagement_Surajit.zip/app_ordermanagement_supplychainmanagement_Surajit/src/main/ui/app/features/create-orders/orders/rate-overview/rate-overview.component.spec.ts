import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RateOverviewComponent } from './rate-overview.component';

describe('RateOverviewComponent', () => {
  let component: RateOverviewComponent;
  let fixture: ComponentFixture<RateOverviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RateOverviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RateOverviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
