import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TemplatesComponent } from './templates.component';

import { TemplatesSearchComponent } from './templates-search/templates-search.component';
import { MassUpdateComponent } from './mass-update/mass-update.component';
import { MassUpdateFieldsComponent } from './mass-update/mass-update-fields/mass-update-fields.component';
import { MassUpdateInstructionsComponent } from './mass-update/mass-update-instructions/mass-update-instructions.component';
import { MassUpdateItemsComponent } from './mass-update/mass-update-items/mass-update-items.component';
import { CreateTemplateComponent } from './create-template/create-template.component';
import { TemplatesStopsComponent } from './templates-stops/templates-stops.component';
import { MassUpdateSummaryComponent } from './mass-update/mass-update-summary/mass-update-summary.component';
const routes: Routes = [{
    path: '',
    component: TemplatesComponent,
    children: [{
            path: '',
            component: TemplatesSearchComponent
        },
        {
            path: 'massupdate',
            component: MassUpdateComponent,
            children: [{
                    path: 'fields',
                    component: MassUpdateFieldsComponent
                },
                {
                    path: 'instructions',
                    component: MassUpdateInstructionsComponent
                },
                {
                    path: 'items',
                    component: MassUpdateItemsComponent
                },
                {
                    path: 'summary',
                    component: MassUpdateSummaryComponent
                }
            ]
        },
        {
            path: 'create',
            component: CreateTemplateComponent
        },
        {
            path: 'addstops',
            component: TemplatesStopsComponent
        }
    ]
}];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
    providers: []
})
export class TemplatesRoutingModule {}
