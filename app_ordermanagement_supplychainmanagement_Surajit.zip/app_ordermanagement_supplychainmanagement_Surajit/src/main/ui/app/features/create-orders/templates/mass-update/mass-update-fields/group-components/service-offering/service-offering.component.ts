import { Component, Input, OnInit } from '@angular/core';
import { JBHGlobals } from 'app/app.service';

@Component({
  selector: 'app-service-offering',
  templateUrl: './service-offering.component.html',
  styleUrls: ['./service-offering.component.scss']
})
export class ServiceOfferingComponent implements OnInit {

    @Input() templateDTO: any;

    // public serviceOfferingForm: FormGroup;

    public buOptions: any[] = [];
    public soOptions: any[] = [];

    constructor(public jbhGlobals: JBHGlobals) {}

    ngOnInit() {
        //  	this.serviceOfferingForm = this.formBuilder.group({
        //  		businessunit: [''],
        //  		serviceoffering: ['']
        //  	});

        this.loadBusinessUnit();
        if (this.templateDTO['businessunit']) { this.loadServiceOffering(); }
    }

    public onBuChange($event): void {
        this.templateDTO['serviceoffering'] = undefined;
        this.loadServiceOffering();
    }

    public loadBusinessUnit(): void {

        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getbusinessunit).subscribe(data => {

            const options = [];
            for (const opt of data['_embedded']['serviceOfferingBusinessUnitTransitModeAssociations']) {
                const obj = {
                    'name': ''
                };
                obj.name = opt['financeBusinessUnitServiceOfferingAssociation']['financeBusinessUnitCode'];
                options.push(obj);
            }
            this.buOptions = options;
        });
    }

    public loadServiceOffering(): void {
        const params = {
            'financeBusinessUnitCode': this.templateDTO['businessunit'],
            'projection': 'viewserviceofferingbusinessunittransitmode'
        };

        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getserviceoffering, params).subscribe(data => {
            const options = [];
            for (const opt of data['_embedded']['serviceOfferingBusinessUnitTransitModeAssociations']) {
                const obj = {
                    'name': ''
                };
                obj.name = opt['serviceOfferingCode'];
                options.push(obj);
            }
            this.soOptions = options;
        });
    }
}
