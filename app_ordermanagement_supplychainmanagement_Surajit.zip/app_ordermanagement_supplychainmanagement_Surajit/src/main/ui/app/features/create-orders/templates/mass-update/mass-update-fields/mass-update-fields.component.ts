import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { JBHGlobals } from '../../../../../app.service';
import { FormBuilder, FormGroup, FormArray, Validators } from '@angular/forms';
@Component({
  selector: 'app-mass-update-fields',
  templateUrl: './mass-update-fields.component.html',
  styleUrls: ['./mass-update-fields.component.scss']
})
export class MassUpdateFieldsComponent implements OnInit {

    public massfieldform: FormGroup;
    public updatableElements: any[] = [];

    public massFieldRows: any[] = [];
    public selectedFieldRow;

    public templateDTO: any = {};

    public errorMsgs: any = {
        'duplicate': 'This field already added, please select another.',
        'message': 'Please review the field below that needs your attention and update again.'
    };

    constructor(public router: Router, public jbhGlobals: JBHGlobals, public fb: FormBuilder) {
        // initialize form with empty FormArray
        this.massfieldform = new FormGroup({
            fieldsArr: new FormArray([])
        });
    }


    ngOnInit() {
        this.getMassUpdateFields();
    }

    public getMassUpdateFields(): void {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.template.getMassUpdateFields).subscribe(data => {
            this.updatableElements = data['elementsData'];
        });
    }

    public addmassupdatefield(): void {
        if (this.massfieldform.valid) {
            const newrow = {
                'id': '',
                'fieldId': '',
                'fieldInfo': {},
                'errormsg': ''
            };
            this.massFieldRows.push(newrow);

            // create a new form group and add it to form array
            const newFieldGroup = this.fb.group({
                fieldtype: ['', Validators.compose([Validators.required])]
            });
            const formfieldsarr = < FormArray > this.massfieldform.controls['fieldsArr'];
            formfieldsarr.push(newFieldGroup);
        } else {
            this.jbhGlobals.notifications.error('Review a Field', this.errorMsgs.message);
        }
    }

    public onRemoveFieldItem(delItem, indx): void {
        const formfieldsarr = < FormArray > this.massfieldform.controls['fieldsArr'];
        formfieldsarr.removeAt(indx);
        this.massFieldRows = this.massFieldRows.filter(item => item !== delItem);
    }

    public onFieldRowSelected(item: any): void {
        if (this.selectedFieldRow !== item) {
            this.selectedFieldRow = item;
        }
    }

    public onMassFieldChange($event): void {

        // let errmsg: string;
        const selItem: any = this.updatableElements.find(itm => itm.id === $event.target.value);

        this.selectedFieldRow.id = '';
        this.selectedFieldRow.fieldInfo = {};
        this.selectedFieldRow.fieldId = '';
        this.selectedFieldRow.errormsg = '';

        //        errmsg = this.checkForDuplicateField($event.target.value);
        //        if (errmsg) {
        //            this.selectedFieldRow.errormsg = errmsg;
        //        } else {
        this.selectedFieldRow.id = selItem.id;
        this.selectedFieldRow.fieldInfo = selItem.fieldInfo;
        this.selectedFieldRow.fieldId = selItem.fieldInfo.fieldId;
        //        }
    }

    public checkForDuplicateField(itemId): string {
        let itm: any;
        let errmsg = '';
        itm = this.massFieldRows.filter(obj => obj.id === itemId);
        if (itm.length) {
            errmsg = this.errorMsgs.duplicate;
        }
        return errmsg;
    }

    public onFieldValueControlChange($event): void {
        // this.l('working');
    }

    public updateFields(): void {
        // this.l(this.selectedFieldRow);
        console.log(this.templateDTO);
    }

    public redirectToGridPage(): void {
        this.router.navigateByUrl('/createorders');
    }

    //  public duplicateCheck(obj) {
    //  console.log(obj);
    //  let flag: boolean = false;
    //  let obj: any;
    //  if(c.value !== ''){
    //    obj = this.massFieldRows.find( item => item.id === c.value );
    //    if(obj){ flag = true }
    //  }
    //  return !flag ? null : {'duplicate': true};
    // }
}
