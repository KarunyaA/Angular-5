import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';

import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { AccordionModule } from 'ngx-bootstrap';
import { TypeaheadModule } from 'ngx-bootstrap';
import { PopoverModule } from 'ngx-bootstrap/popover';
import { TagInputModule } from 'ng2-tag-input';
import { ProgressbarModule } from 'ngx-bootstrap';

// import { SelectModule } from 'ng2-select';
import { SelectModule } from '../../../shared/select';

import { JBHDataTableModule } from '../../../shared/jbh-data-table/jbh-data-table.module';
import { TemplatesRoutingModule } from './templates-routing.module';
import { TemplatesComponent } from './templates.component';
import { TemplatesSearchComponent } from './templates-search/templates-search.component';
import { MassUpdateComponent } from './mass-update/mass-update.component';
import { MassUpdateFieldsComponent } from './mass-update/mass-update-fields/mass-update-fields.component';
import { MassUpdateItemsComponent } from './mass-update/mass-update-items/mass-update-items.component';
import { MassUpdateInstructionsComponent } from './mass-update/mass-update-instructions/mass-update-instructions.component';
import { DynamicFormControlComponent } from './mass-update/mass-update-fields/dynamic-form-control/dynamic-form-control.component';
import { ServiceOfferingComponent } from './mass-update/mass-update-fields/group-components/service-offering/service-offering.component';
import { JbhSearchFilterModule } from '../../../shared/jbh-search-filter/jbh-search-filter.module';
import { RatingModule } from 'ngx-bootstrap/rating';
import { TemplateService } from './template.service';
import { FleetCodeComponent } from './mass-update/mass-update-fields/group-components/fleet-code/fleet-code.component';
import { CreateTemplateComponent } from './create-template/create-template.component';

import { CreateorderModule } from '../../../features/create-orders/orders/create/create.module';
import { AddStopsModule } from '../../../features/create-orders/orders/add-stops/add-stops.module';
import { OrderService } from '../orders/order.service';
import { OrderFormBuilder } from '../orders/order-form-builder.service';
import { MassFieldRowComponent } from './mass-update/mass-update-fields/mass-field-row/mass-field-row.component';
import { TemplatesStopsComponent } from './templates-stops/templates-stops.component';

import { UserprofileComponent } from './mass-update/mass-update-fields/group-components/userprofile/userprofile.component';
import { MassUpdateSummaryComponent } from './mass-update/mass-update-summary/mass-update-summary.component';
import { BulkUploadModule } from './bulk-upload/bulk-upload.module';


@NgModule({
  imports: [
    CommonModule,
    TemplatesRoutingModule,
    JBHDataTableModule,
    BsDropdownModule.forRoot(),
    AccordionModule.forRoot(),
    TypeaheadModule.forRoot(),
    PopoverModule.forRoot(),
    RatingModule.forRoot(),
    ProgressbarModule.forRoot(),
    FormsModule,
    ReactiveFormsModule,
    JbhSearchFilterModule,
    TagInputModule,
    CreateorderModule,
    AddStopsModule,
    SelectModule,
    BulkUploadModule
    // SelectModule
  ],
  declarations: [
    TemplatesComponent,
    TemplatesSearchComponent,
    MassUpdateComponent,
    MassUpdateFieldsComponent,
    MassUpdateItemsComponent,
    MassUpdateInstructionsComponent,
    DynamicFormControlComponent,
    ServiceOfferingComponent,
    FleetCodeComponent,
    CreateTemplateComponent,
    MassFieldRowComponent,
    TemplatesStopsComponent,
    UserprofileComponent,
    MassUpdateSummaryComponent
  ],
  providers: [TemplateService, OrderService, OrderFormBuilder]
})
export class TemplatesModule { }
