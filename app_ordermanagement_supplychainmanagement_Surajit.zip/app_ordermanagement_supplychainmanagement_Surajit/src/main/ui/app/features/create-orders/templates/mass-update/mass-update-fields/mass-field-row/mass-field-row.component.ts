import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';

@Component({
  selector: 'app-mass-field-row',
  templateUrl: './mass-field-row.component.html',
  styleUrls: ['./mass-field-row.component.scss']
})
export class MassFieldRowComponent implements OnInit {

    @Input() updatableElements: any[];

    @Input() fieldItem: any;

    @Input() errormsg: string;

    @Input() templateDTO: any;

    @Output() massFieldChange: EventEmitter < any > = new EventEmitter();

    @Output() deleteFieldRow: EventEmitter < any > = new EventEmitter();

    constructor() {}

    ngOnInit() {}

    public onFieldSelection($event): void {
        const emitObj: any = {};
        emitObj.target = this;
        emitObj.selItem = this.updatableElements[$event.target.value - 1];

        this.massFieldChange.emit(emitObj);
    }

    public onFieldValueControlChange($event): void {
        // this.l('working');
        // this.l($event.target.value);
    }

    public removeItem() {
        // this.massFieldRows = this.massFieldRows.filter(item => item != del_item);
        const emitObj: any = {};
        emitObj.target = this;
        emitObj.delItem = this.fieldItem;

        this.deleteFieldRow.emit(emitObj);
    }
}
