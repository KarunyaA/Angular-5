import {
  NgModule
} from '@angular/core';
import {
  CommonModule
} from '@angular/common';
import {
  FormsModule,
  ReactiveFormsModule
} from '@angular/forms';

import {
  CreateOrdersRoutingModule
} from './create-orders-routing.module';
import {
  CreateOrdersComponent
} from './create-orders.component';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    CreateOrdersRoutingModule
  ],

  declarations: [CreateOrdersComponent]
})
export class CreateOrdersModule { }
