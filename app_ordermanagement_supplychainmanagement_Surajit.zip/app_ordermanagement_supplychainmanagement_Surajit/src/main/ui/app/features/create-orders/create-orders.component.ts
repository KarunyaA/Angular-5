import {
  Component
} from '@angular/core';

@Component({
  selector: 'app-create-orders',
  templateUrl: './create-orders.component.html',
  styleUrls: ['./create-orders.component.scss']
})

export class CreateOrdersComponent {

}
