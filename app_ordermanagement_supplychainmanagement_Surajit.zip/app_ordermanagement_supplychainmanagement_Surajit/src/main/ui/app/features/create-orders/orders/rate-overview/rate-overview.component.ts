import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { JBHGlobals } from '../../../../app.service';
@Component({
    selector: 'app-rate-overview',
    templateUrl: './rate-overview.component.html',
    styleUrls: ['./rate-overview.component.scss']
})
export class RateOverviewComponent implements OnInit {

    public overViewList = [];
    public overAllRating = 1;
    @Input() item;
    @Input() row;

    constructor(public router: Router, public jbhGlobals: JBHGlobals) {     
    }
    private getRateOverview() {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.shippingoptions.getrateoverview, '', false)
            .subscribe(data => {
                if (data !== undefined) {
                    this.overViewList = data['rateDetails'];
                    this.overAllRating = data['overAllRating'];
                }
            });
    }
    ngOnInit() {
        this.getRateOverview();
    }
    hidePopOver() {
        console.log(this.row);
        console.log(this.item);
        this.item.hide();
    }
}
