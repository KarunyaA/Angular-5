import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OrdersRoutingModule } from './orders-routing.module';
import { OrdersComponent } from './orders.component';
import { OrderoverviewComponent } from './orderoverview/orderoverview.component';
import { StepNavComponent } from './step-nav/step-nav.component';
import { CreateorderModule } from './create/create.module';
import { AddStopsModule } from './add-stops/add-stops.module';
import { OrderService } from './order.service';
import { ModalModule } from 'ngx-bootstrap';


import { AccordionModule } from 'ngx-bootstrap';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { StandardsComponent } from './standards/standards.component';
import { ManageoverlayModule } from './manageoverlay/manageoverlay.module';
import { OrderShippingOptionsComponent } from './order-shipping-options/order-shipping-options.component';

import { JBHDataTableModule } from '../../../../app/shared/jbh-data-table/jbh-data-table.module';
import { MyDatePickerModule } from 'mydatepicker';
import { RatingModule } from 'ngx-bootstrap/rating';
import { PopoverModule } from 'ngx-bootstrap/popover';
import { BsDropdownModule } from 'ngx-bootstrap';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { ShippingoptionsinformationComponent } from './shippingoptionsinformation/shippingoptionsinformation.component';
import { JbhUtilsModule } from '../../../../app/shared/jbh-utils/jbh-utils.module';
import { RateOverviewComponent } from './rate-overview/rate-overview.component';

@NgModule({
  imports: [
    CommonModule,
    OrdersRoutingModule,
    CreateorderModule,
    AddStopsModule,
    ManageoverlayModule,
    AccordionModule.forRoot(),
    TabsModule.forRoot(),
    PerfectScrollbarModule,
    MyDatePickerModule,
    JBHDataTableModule,
    RatingModule.forRoot(),
    PopoverModule.forRoot(),
    BsDropdownModule.forRoot(),
    ModalModule.forRoot(),
    FormsModule,
    ReactiveFormsModule,
    JbhUtilsModule
  ],
  declarations: [
    OrdersComponent,
    OrderoverviewComponent,
    StepNavComponent,
    StandardsComponent,
    OrderShippingOptionsComponent,
    ShippingoptionsinformationComponent,
    RateOverviewComponent
  ],
  exports: [
    OrdersComponent,
    OrderoverviewComponent,
    StepNavComponent,
    StandardsComponent,
    OrderShippingOptionsComponent,
    ShippingoptionsinformationComponent,
    RateOverviewComponent
  ],
  providers: [OrderService]
})

export class OrdersModule { }
