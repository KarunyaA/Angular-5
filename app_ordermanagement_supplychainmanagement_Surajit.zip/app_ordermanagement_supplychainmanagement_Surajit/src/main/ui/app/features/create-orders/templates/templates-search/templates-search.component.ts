import {Component, OnInit, ViewChild} from '@angular/core';
import {Router} from '@angular/router';

import {JBHGlobals} from '../../../../app.service';
import { TemplateService } from './../template.service';
@Component({
  selector: 'app-templates-search',
  templateUrl: './templates-search.component.html',
  styleUrls: ['./templates-search.component.scss']
})
export class TemplatesSearchComponent implements OnInit {

    /******************  Gloabal Variable for this Module Declared  ********************/

    @ViewChild('popOverList2') pop: any;
    public rows: any[] = [];
    public selected = [];
    public count = 0;
    public offset = 0;
    public limit = 10;
    public pageoffset = 0;
    public flag = 0;
    public menuSelection = '';
    public menuHiddeShowFlag = false;
    public billToVal: string;
    public originVal: string;
    public destinationVal: string;
    public filterTitle = 'Filter By';
    public favouriteList: Array < any >= [1];
    public massUpdateFlag = false;
    public billTo: string;
    public orgin: string;
    public destination: string;
    public fliterCmpLoad: boolean;
    public searchQueryParam: Object;
    public massUpdateFlagBool = false;
    public menuSelectedForMassUpdate = '';
    public favouriteIdList: Array < Object > ;
    public elasticParam: Object;
    public blurValueBillToClearFlag = true;
    public blurValueOriginClearFlag = true;
    public blurValueDestinationClearFlag = true;
    public originMockData: any[] = [];
    public destinationMockData: any[] = [];
    public val = 1;
    public val2 = 0.7;
    public popOverFlag = false;
    public originSelectedData = {
        'region': null
    };
    public destinationSelectedData = {
        'region': null
    };
    public gridMenu = [{
            'name': 'Create New Order',
            'id': 'order'
        },
        {
            'name': 'Create New Template',
            'id': 'template'
        },
        {
            'name': 'Mass Update Fields',
            'id': 'massfields'
        },
        {
            'name': 'Mass Update Items',
            'id': 'massitems'
        },
        {
            'name': 'Mass Update Additional Instructions',
            'id': 'massins'
        },
        {
            'name': 'Mass Update Summary',
            'id': 'masssummary'
        }
    ];

    /******************  Mock  Data  ********************/

    public profileDTOs: any[] = [{
        'addressDTO': [{
            'city': 'ROGERS',
            'state': 'AR',
            'zipcode': '12345',
            'country': 'USA',
            'street': 'main Street'
        }],
        'name': 'COCOLA456',
        'code': 'B11B'
    }, {
        'addressDTO': [{
            'city': 'ROGERS',
            'state': 'AR',
            'zipcode': '12345',
            'country': 'USA',
            'street': 'main Street'
        }],
        'name': 'COCOLA125',
        'code': 'B11B'
    }, {
        'addressDTO': [{
            'city': 'ROGERS',
            'state': 'AR',
            'zipcode': '12345',
            'country': 'USA',
            'street': 'main Street'
        }],
        'name': 'COCOLA',
        'code': 'B11B'
    }, {
        'addressDTO': [{
            'city': 'ROGERS',
            'state': 'AR',
            'zipcode': '12345',
            'country': 'USA',
            'street': 'main Street'
        }],
        'name': 'COCOLA',
        'code': 'B11B'
    }, {
        'addressDTO': [{
            'city': 'ROGERS',
            'state': 'AR',
            'zipcode': '12345',
            'country': 'USA',
            'street': 'main Street'
        }],
        'name': 'COCOLA',
        'code': 'B11B'
    }];

    public FilterList: any[] = [{
        'index': 0,
        'key': 'orderBillingDetailDTOs.solicitorCode',
        'title': 'Solicitor',
        'checkSelectionKey': 'code',
        'componentType': 'lsitType',
        'rootVal': ['ProfileDTO'],
        'count': 0,
        'paginationSize': 2,
        'pagination': true,
        'url': 'getMdmMockServiceURL',
        'params': {
            'value': 'Coc',
            'roletype': 'Solicitor',
            'active': 'yes',
            'page': 0,
            'size': 2,
            'approved': true,
            'addresstype': 'mailing'
        }
    }, {
        'index': 1,
        'title': 'Line of Business',
        'key': 'lineOfBusinessCode',
        'rootVal': ['ProfileDTO'],
        'checkSelectionKey': 'code',
        'componentType': 'lsitType',
        'count': 0,
        'pagination': true,
        'paginationSize': 2,
        'url': 'getMdmMockServiceURL',
        'params': {
            'value': 'Coc',
            'roletype': 'LineOfBusiness',
            'active': 'yes',
            'page': 0,
            'size': 2,
            'approved': true,
            'addresstype': 'PHYSICAL'
        }
    }, {
        'index': 2,
        'key': 'Customer',
        'title': 'Customer',
        'checkSelectionKey': 'code',
        'rootVal': ['ProfileDTO'],
        'componentType': 'lsitType',
        'count': 0,
        'paginationSize': 2,
        'pagination': true,
        'url': 'getMdmMockServiceURL',
        'params': {
            'value': 'Coc',
            'roletype': 'Customer',
            'active': 'yes',
            'page': 0,
            'size': 2,
            'approved': true,
            'addresstype': 'PHYSICAL'
        }
    }, {
        'index': 3,
        'key': 'tradingPartnerCode',
        'checkSelectionKey': 'TradingPartner',
        'title': 'Trading Partner',
        'rootVal': ['profileResponseDTO'],
        'componentType': 'lsitType',
        'count': 0,
        'url': 'getTradingPartner'
    }, {
        'index': 4,
        'key': 'owner.inits',
        'title': 'Order Owner',
        'checkSelectionKey': 'divisionCode',
        'rootVal': [],
        'count': 0,
        'componentType': 'lsitType',
        'url': ''
    }, {
        'index': 5,
        'key': 'noOfIntermediateStops',
        'title': 'Number of Stops',
        'checkSelectionKey': 'key',
        'rootVal': ['aggregations', 'IntermediateStops', 'buckets'],
        'componentType': 'lsitType',
        'url': 'getElasticServiceURL',
        'count': 0,
        'methodType': 'addData',
        'params': {
            'size': 0,
            'aggs': {
                'IntermediateStops': {
                    'terms': {
                        'field': 'noOfIntermediateStops'
                    }
                }
            }
        }
    }, {
        'index': 6,
        'key': 'financeBusinessUnitCode',
        'title': 'Business Unit',
        'checkSelectionKey': 'financeBusinessUnitCode',
        'componentType': 'lsitType',
        'deepNestFlag': true,
        'count': 0,
        'rootVal': ['_embedded', 'serviceOfferingBusinessUnitTransitModeAssociations'],
        'url': 'getBusinessUnitServiceURL',
        'params': {}
    }, {
        'index': 7,
        'key': 'serviceOfferingCode',
        'title': 'Service Offering',
        'checkSelectionKey': 'serviceOfferingCode',
        'componentType': 'lsitType',
        'rootVal': ['_embedded', 'serviceOfferings'],
        'url': 'getServiceOfferingServiceURL',
        'count': 0,
        'params': {}
    }, {
        'index': 8,
        'key': 'transitMode',
        'title': 'Transit Mode',
        'checkSelectionKey': 'transitModeCode',
        'componentType': 'lsitType',
        'count': 0,
        'rootVal': ['_embedded', 'transitModes'],
        'url': 'getTransitModeServiceURL'
    }, {
        'index': 9,
        'key': 'templateActiveStatus',
        'title': 'Template Status',
        'checkSelectionKey': 'val',
        'count': 0,
        'componentType': 'lsitType',
        'rootVal': ['ativeStatus'],
        'url': 'getFilterData',
        'params': {}
    }, {
        'index': 10,
        'key': 'fleetCode',
        'title': 'Fleet Code',
        'checkSelectionKey': 'divisionCode',
        'componentType': 'lsitType',
        'count': 0,
        'paginationSize': 7,
        'pagination': true,
        'rootVal': ['_embedded', 'fleets'],
        'url': 'getFleetCodeServiceURL',
        'params': {
            'start': 0,
            'end': 6
        }
    }, {
        'index': 11,
        'key': 'scac',
        'title': 'SCAC',
        'checkSelectionKey': '',
        'componentType': 'lsitType',
        'count': 0,
        'rootVal': [],
        'url': ''
    }, {
        'index': 12,
        'key': 'awards',
        'title': 'Awards',
        'checkSelectionKey': 'value',
        'componentType': 'lsitType',
        'count': 0,
        'rootVal': ['awarded'],
        'url': 'getFilterData',
        'params': {}
    }, {
        'index': 13,
        'key': 'desirabilityIndex',
        'checkSelectionKey': 'fullVal',
        'title': 'Desirability Index',
        'componentType': 'rating',
        'rootVal': [],
        'url': ''
    }];

    public QueryParamDTO = {
        'query': {
            'constant_score': {
                'filter': {
                    'bool': {
                        'must': []
                    }
                }
            }
        },
        'sort': {
            'templateID': 'asc'
        },
        'size': this.limit,
        'from': 0
    };

    /******************  System Provided Methods  ********************/

    constructor(public router: Router, public jbhGlobals: JBHGlobals, public ts: TemplateService) {}

    ngOnInit() {
        console.log('TSC Before: ' + this.ts.testVar);
        this.ts.testVar = 'Its working';
        console.log('TSC After: ' + this.ts.testVar);
        const param = '?personID=346&userFavoriteEntity=Template&projection=favoriteProjection';
        const favUrl = this.jbhGlobals.endpoints.template.getFavouriteTemplateServiceURL + '' + param;
        this.searchGridDevCall(favUrl);
        // this.typeadheadQuery(event);
    }

    /******************  Custom Function For ser Template Grid Service Call and Dependency Functions  ********************/

    public searchGridDevCall(favUrl: string): void {
        const me = this;
        me.jbhGlobals.apiService.getData(favUrl).subscribe(data => {
            me.favouriteList = me.templateIDGetter(data);
            this.elasticParam = {
                'query': {
                    'bool': {
                        'filter': {
                            'terms': {
                                'templateID': this.favouriteList
                            }
                        }
                    }
                },
                'size': me.limit,
                'from': 0
            };
            const url = me.jbhGlobals.endpoints.template.getElasticServiceURL;
            me.searchGridServiceCall(url, this.elasticParam);
            me.favouriteIdList = me.favouriteIdListeGenerator(data);
        });
    }

    public templateIDGetter(data: Array < Object > ): Array < number > {
        const arr = [];
        if (data) {
            const dataList = data['_embedded']['favorites'];
            for (let i = 0; i < dataList.length; i++) {
                arr.push(parseInt(dataList[i]['userFavoriteEntityReferenceID'], 10));
            }
        }
        return arr;
    }
    public favouriteIdListeGenerator(data: Array < Object > ): Array < Object > {
        const arr = [];
        if (data) {
            const dataList = data['_embedded']['favorites'];
            for (let i = 0; i < dataList.length; i++) {
                const obj = {};
                obj['templateId'] = dataList[i]['userFavoriteEntityReferenceID'];
                obj['favouriteId'] = dataList[i]['_links']['self']['href'];
                arr.push(obj);
            }
        }
        return arr;
    }
    public searchGridServiceCall(url: string, param: Object): void {
        const me = this;
        me.jbhGlobals.apiService.addData(url, param).subscribe(data => {
            if (data && data['hits'] && data['hits']['hits']) {
                me.count = data['hits']['total'];
                me.searchGridJsonFormatter(data['hits']['hits'], true);
            } else {
                console.log('data is not populating');
            }
        });
    }

    public searchGridJsonFormatter(data: Array < Object > , favFlag: boolean): void {
        const temp = [];
        for (let i = 0; i < data.length; i++) {
            const obj = {};
            if (data[i]['_source']['billingDetails'] && data[i]['_source']['billingDetails'][0]) {
                obj['billToAccount'] = data[i]['_source']['billingDetails'][0]['billToCode'];
            }
            obj['templateID'] = data[i]['_source']['templateID'];

            if (data[i]['_source']['orderBillingDetailDTOs'] && data[i]['_source']['orderBillingDetailDTOs'][0]) {
                obj['solicitor'] = data[i]['_source']['orderBillingDetailDTOs'][0]['solicitorCode'];
            }
            if (data[i]['_source']['originStop'] && data[i]['_source']['originStop']['locationDTO']) {
                obj['origin'] = data[i]['_source']['originStop']['locationDTO']['addressDTO']['city'] + ', ' +
                    data[i]['_source']['originStop']['locationDTO']['addressDTO']['state'] + ', ' +
                    data[i]['_source']['originStop']['locationDTO']['addressDTO']['country'] + ', ' +
                    data[i]['_source']['originStop']['locationDTO']['addressDTO']['cityID'] + ', ' +
                    data[i]['_source']['originStop']['locationDTO']['addressDTO']['zipCode'];
            }
            if (data[i]['_source']['destinationStop'] && data[i]['_source']['destinationStop']['locationDTO']) {
                obj['destination'] = data[i]['_source']['destinationStop']['locationDTO']['addressDTO']['city'] + ', ' +
                    data[i]['_source']['destinationStop']['locationDTO']['addressDTO']['state'] + ', ' +
                    data[i]['_source']['destinationStop']['locationDTO']['addressDTO']['country'] + ', ' +
                    data[i]['_source']['destinationStop']['locationDTO']['addressDTO']['cityID'] + ', ' +
                    data[i]['_source']['destinationStop']['locationDTO']['addressDTO']['zipCode'];
            }
            obj['stops'] = data[i]['_source']['numberOfIntermediateStops'];

            if (data[i]['_source']['desirabilityIndex']) {
                obj['rating'] = Math.round(data[i]['_source']['desirabilityIndex'] / 20);
            }
            obj['services'] = data[i]['_source']['serviceOfferingCode'] + '-' + data[i]['_source']['financeBusinessUnitCode'];
            obj['favouriteStatus'] = this.favouriteFlagChecker(data[i]['_source']['templateID'], this.favouriteList);
            obj['activeStatus'] = data[i]['_source']['templateActiveStatus'];
            obj['awardedStatus'] = data[i]['_source']['awards'];
            temp.push(obj);
        }
        console.log(temp);
        this.rows = temp;
        // this.count= this.rows.length;
    }


    /******************  Search Grid Event  ********************/

    public favouriteFlagChecker(val, arr): boolean {
        if (arr.indexOf(val) !== -1) {
            return true;
        }
        return false;
    }

    public onSelect({
        selected
    }) {
        this.selected.splice(0, this.selected.length);
        this.selected.push(...selected);
    }

    public onActivate(event) {
        console.log('Activate Event', event);
    }

    public updateRowPosition() {
        const ix = this.getSelectedIx(),
            arr = [...this.rows];
        arr[ix - 1] = this.rows[ix];
        arr[ix] = this.rows[ix - 1];
        this.rows = arr;
    }

    public getSelectedIx() {
        return this.selected[0]['$$index'];
    }

    public getOrderId(url: string, params: Object): void {
        this.jbhGlobals.apiService.addData(url, params).subscribe(data => {
            this.router.navigateByUrl('/createorders/order/create?id=' + data['orderID']);
        });
    }

    public menuClickEvent(val: string) {
        if (val === 'order') {
            const url = this.jbhGlobals.endpoints.order.getOrderId,
                params = {
                    'orderStatusCode': 'Incomplete',
                    'orderTypeCode': 'other',
                    'orderSubTypeCode': 'CLC',
                    'orderGroupingID': 1
                };
            this.getOrderId(url, params);
        } else if (val === 'template') {
            this.router.navigateByUrl('/createorders/template/create');
        } else if (val === 'masssummary') {
            this.router.navigateByUrl('/createorders/template/massupdate/summary');
        } else {
            this.menuSelectedForMassUpdate = val;
        }
    }

    public massUpdate(eve) {
        const val = this.menuSelectedForMassUpdate;


        for (const itm of this.selected) {
            this.ts.massUpdateTemplateIds.push(itm['templateID']);
        }

        if (val === 'massfields') {
            this.router.navigateByUrl('/createorders/template/massupdate/fields');
        } else if (val === 'massitems') {
            // this.massUpdateFlag=true;
            this.router.navigateByUrl('/createorders/template/massupdate/items');
        } else if (val === 'massins') {
            this.router.navigateByUrl('/createorders/template/massupdate/instructions');
        }
    }

    public cancelEvent(eve) {
        this.menuSelectedForMassUpdate = '';
        this.selected = [];
    }

    public favStatus(row) {
        if (row.favouriteStatus) {
            this.favouriteDeleteCall(row);
        } else {
            this.favouriteSaveCall(row);
        }
    }

    public favouriteSaveCall(row): void {
        const url = this.jbhGlobals.endpoints.template.getFavouriteSaveServiceURL,
            params = {
                'personID': '346',
                'activeDirectoryUserID': 'TEmp123',
                'userFavoriteEntity': 'Template',
                'userFavoriteEntityReferenceID': '' + row.templateID
            };
        this.jbhGlobals.apiService.addData(url, params).subscribe(data => {
            row.favouriteStatus = true;
            const obj = {};
            obj['templateId'] = data['userFavoriteEntityReferenceID'];
            obj['favouriteId'] = data['_links']['self']['href'];
            this.favouriteIdList.push(obj);
        });
    }

    public favouriteDeleteCall(row): void {

        const favID = this.favouriteIDSeperator(this.favouriteIdList, row.templateID);
        const url = this.jbhGlobals.endpoints.template.getFavouriteSaveServiceURL + '/' + favID;
        this.jbhGlobals.apiService.removeData(url).subscribe(data => {
            this.arrayObjSplicer(this.favouriteIdList, 1, row.templateID, 'templateId');
            row.favouriteStatus = false;
        });
    }

    public arrayObjSplicer(arr: Array < Object > , num: number, val: string, matchingKey: string): void {
        const len = arr.length;
        for (let i = 0; i < len; i++) {
            if (arr[i][matchingKey] === val) {
                arr.splice(i, num);
                break;
            }
        }
    }

    public favouriteIDSeperator(arr, templateId): string {
        let val = '';
        if (arr && arr.length > 0) {
            for (let i = 0; i < arr.length; i++) {
                if (arr[i].templateId === templateId) {
                    val = this.lastStringEmitter((arr[i].favouriteId).split('/'));
                }
            }
        }
        return val;
    }

    public lastStringEmitter(arr): string {
        const len = arr.length;
        return arr[len - 1].trim();
    }

    public viewMenuClick(eve, pop, row) {
        this.popOverFlag = false;
        pop.hide();
    }

    public templateMenuClick(eve, pop, row) {
        if (row.activeStatus === 'Active') {
            const url = this.jbhGlobals.endpoints.template.getInActivateSaveServiceURL + '/' + row.templateID;
            this.activateStatusServiceCall(row, url, null);
        } else {
            const url = this.jbhGlobals.endpoints.template.getActivateServiceURL + '/' + row.templateID;
            this.activateStatusServiceCall(row, url, 'Active');
        }
        pop.hide();
    }
    public activateStatusServiceCall(row, url, status) {
        this.jbhGlobals.apiService.patchData(url, {}).subscribe(data => {
            row.activeStatus = status;
        });
    }

    public createOrderFromTemplate(row) {
        const url = this.jbhGlobals.endpoints.order.orderFromTemplate + '' + row['templateID'],
            params = {};
        this.getOrderId(url, params);
    }

    public onRowMultiSelect(eve, row) {
        console.log(row);
    }

    public massClickEvent(val, event) {
        this.menuSelection = val;
        this.menuHiddeShowFlag = true;
    }

    public typeaheadOriginSelect(eve) {
        this.orgin = eve.value;
        this.originSelectedData = eve['item'];
        this.blurValueOriginClearFlag = false;
    }

    public typeaheadDestinationSelect(val) {
        this.destination = val;
        this.blurValueDestinationClearFlag = false;
    }

    public typeaheadOnSelect(eve) {
        this.billTo = eve.item.code + '&' + eve.item.name;
        this.billToVal = eve.item.name + '-' + eve.item.code + ' ' + eve.item.addressDTO[0].street +
            ',' + eve.item.addressDTO[0].city + ' ' + eve.item.addressDTO[0].state + ' ' + eve.item.addressDTO[0].country +
            ' ' + eve.item.addressDTO[0].zipcode;
        this.blurValueBillToClearFlag = false;

    }

    public typeaheadOnBlur(eve, flag) {
        const me = this,
            time = setInterval(function() {
                if (me.blurValueBillToClearFlag && flag === 'billTo') {
                    eve.target.value = null;
                } else if (me.blurValueOriginClearFlag && flag === 'origin') {
                    eve.target.value = null;
                } else if (me.blurValueDestinationClearFlag && flag === 'destination') {
                    eve.target.value = null;
                }
                clearInterval(time);
            }, 500);
    }

    public billToQuery(eve) {
        this.blurValueBillToClearFlag = true;
        this.billTo = '';
    }

    public addidtionalsearch() {
        if (this.flag === 0) {
            this.flag = 1;
            this.fliterCmpLoad = true;
            this.searchElasticQuery(event);
        } else {
            this.flag = 0;
        }
    }

    public searchElasticQuery(eve) {
        const primaryArraylist = [{
            'val': this.billToVal,
            'code': this.billTo,
            'key': 'orderAssociatedParties.billTo'
        }, {
            'val': this.originVal,
            'code': this.orgin,
            'key': 'originStop.locationDTO.addressDTO.' + this.originSelectedData['region']
        }, {
            'val': this.destinationVal,
            'code': this.destination,
            'key': 'destinationStop.locationDTO.addressDTO.' + this.destinationSelectedData['region']
        }];
        const primaryValList = this.primarySearchParamCreation(primaryArraylist);
        const url = this.jbhGlobals.endpoints.template.getElasticServiceURL;

        if (this.QueryParamDTO.query.constant_score.filter.bool.must.length < 13) {
            this.QueryParamDTO.query.constant_score.filter.bool.must = this.pushObj(14);
        }
        if (primaryValList.length > 0) {
            this.removeQuery(this.QueryParamDTO.query.constant_score.filter.bool.must);
            for (let i = 0; i < primaryValList.length; i++) {
                this.QueryParamDTO.query.constant_score.filter.bool.must.push(primaryValList[i]);
            }
            this.offset = 0;
            this.QueryParamDTO.from = 0;
            this.elasticParam = this.QueryParamDTO;
            this.searchGridServiceCall(url, this.elasticParam);
        }
    }

    public removeQuery(arr) {
        const leng = arr.length;
        if (leng > 13) {
            arr.splice(14, leng - 14);
        }
    }

    public popOverOnBlur(pop, popup) {
        const me = this;
        me.popOverFlag = true;
        setTimeout(() => {
                const popOVerList = this.pop['nativeElement'];
                popOVerList.setAttribute('tabindex', '1');
                popOVerList.focus();
                popOVerList.addEventListener('blur', function(event) {
                    if (me.popOverFlag) {
                        popup.hide();
                        me.popOverFlag = false;
                    }
                });
            },
            500);
    }

    public primarySearchParamCreation(arr) {
        const array = [];
        for (let i = 0; i < arr.length; i++) {
            const obj = {
                'match': {}
            };
            if (arr[i].code) {
                obj.match[arr[i].key] = arr[i].code;
                array.push(obj);
            }
        }
        return array;
    }

    /******************** on filter checkbox select and unselect it will get triggered ******************/
    public changeEvent(eve) {
        const checkFlag = event.target['checked'],
            url = this.jbhGlobals.endpoints.template.getElasticServiceURL,
            temp = this.FilterList[eve.num].key,
            valKey = this.FilterList[eve.num].checkSelectionKey,
            obj = {
                'match': {}
            };
        obj.match[temp] = eve.data['fullVal'][valKey];
        if (checkFlag) {
            if (eve.num !== 13) {
                this.QueryParamDTO['query']['constant_score']['filter']['bool']['must'][eve.num]['bool']['should'].push(obj);
            } else {
                const val = parseInt(event.target['value'], 10);
                const tempObj = {
                    'range': {
                        'desirabilityIndex': {
                            'gte': val
                        }
                    }
                };
                this.QueryParamDTO.query.constant_score.filter.bool.must[eve.num].bool.should = [tempObj];
            }

            this.offset = 0;
            this.QueryParamDTO.from = 0;
            this.elasticParam = this.QueryParamDTO;
            this.searchGridServiceCall(url, this.elasticParam);
        } else {
            this.arrayObjValChecker(this.QueryParamDTO.query.constant_score.filter.bool.must[eve.num].bool.should, obj, temp);
            this.offset = 0;
            this.QueryParamDTO.from = 0;
            this.elasticParam = this.QueryParamDTO;
            this.searchGridServiceCall(url, this.elasticParam);
        }
        this.FilterList[eve.num].count = this.QueryParamDTO.query.constant_score.filter.bool.must[eve.num].bool.should.length;
    }

    public arrayObjValChecker(arr, obj, key) {
        for (let i = 0; i < arr.length; i++) {
            if (arr[i].match[key] === obj.match[key]) {
                arr.splice(i, 1);
                break;
            }
        }
    }

    public pushObj(leng) {
        const arr = [];
        for (let i = 0; i < leng; i++) {
            let filterObj = {
                'bool': {
                    'should': []
                }
            };
            if (i === 9) {
                filterObj = {
                    'bool': {
                        'should': [{
                            'match': {
                                'templateActiveStatus': 'Active'
                            }
                        }]
                    }
                };
            }
            arr.push(filterObj);
        }
        return arr;
    }
    public clickReset(index) {
        const url = this.jbhGlobals.endpoints.template.getElasticServiceURL;
        this.QueryParamDTO['query']['constant_score']['filter']['bool']['must'][index]['bool']['should'] = [];
        this.elasticParam = this.QueryParamDTO;
        this.searchGridServiceCall(url, this.elasticParam);
    }

    public typeadheadOriginQuery(eve) {
        const url = this.jbhGlobals.endpoints.template.getLocationData;
        const params = {};
        this.originMockData = [];
        this.jbhGlobals.apiService.getData(url, params, false).subscribe(data => {
            const dataList = data['locationDto'];
            for (let i = 0; i < dataList.length; i++) {
                const obj = Object.assign(dataList[i], dataList[i]['addressDTO'][0]);
                this.objectFramer(obj, this.originMockData);
            }
        });
        this.blurValueOriginClearFlag = true;
        this.orgin = '';
    }

    public typeadheadDestinationQuery(eve) {
        const url = this.jbhGlobals.endpoints.template.getLocationData;
        const params = {};
        this.destinationMockData = [];
        this.jbhGlobals.apiService.getData(url, params, false).subscribe(data => {
            const dataList = data['locationDto'];
            for (let i = 0; i < dataList.length; i++) {
                const obj = Object.assign(dataList[i], dataList[i]['addressDTO'][0]);
                this.objectFramer(obj, this.destinationMockData);
            }
        });
        this.blurValueDestinationClearFlag = true;
        this.destination = '';
    }

    public objectFramer(obj, arr) {
        for (const key in obj) {
            if (obj.hasOwnProperty(key) && key !== 'addressDTO') {
                let final = {};
                final = {
                    'name': obj[key],
                    'region': key
                };
                arr.push(final);
            }
        }
    }

    public onPage(eve) {
        this.offset = eve.offset;
        this.limit = eve.limit;
        const url = this.jbhGlobals.endpoints.template.getElasticServiceURL,
            param = this.elasticParam;
        param['from'] = eve.offset * 10;
        param['size'] = eve.limit;
        this.searchGridServiceCall(url, param);
    }

    public searchCallOnClick(obj) {
        const url = this.jbhGlobals.endpoints.template.getElasticServiceURL;
        const ObjVal = {
            'wildcard': {
                'scac': {
                    'value': '*' + obj.data['value'].toLowerCase() + '*'
                }
            }
        };
        this.QueryParamDTO['query']['constant_score']['filter']['bool']['must'][obj.num]['bool']['should'] = [ObjVal];
        this.offset = 0;
        this.QueryParamDTO.from = 0;
        this.elasticParam = this.QueryParamDTO;
        this.searchGridServiceCall(url, this.elasticParam);
    }
}
