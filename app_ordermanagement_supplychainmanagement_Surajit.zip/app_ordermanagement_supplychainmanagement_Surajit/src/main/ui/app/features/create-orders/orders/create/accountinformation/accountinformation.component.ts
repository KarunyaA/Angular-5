import {Component, Input, OnInit, ViewChild, AfterContentChecked} from '@angular/core';
import {FormGroup, Validators, FormsModule} from '@angular/forms';

import {TypeaheadComponent} from './typeahead/typeahead.component';
import {AddcontactComponent} from './addcontact/addcontact.component';
import {OrderService} from '../../order.service';
import { OrderFormBuilder } from '../../order-form-builder.service';


@Component({
    selector: 'app-accountinformation',
    templateUrl: './accountinformation.component.html',
    styleUrls: ['./accountinformation.component.scss']
})
export class AccountinformationComponent implements OnInit, AfterContentChecked {
    public billto: boolean;
    public selectFlag: boolean;
    subscription: any;
    orderData: any;

    @Input() orderBillingDetail: any;
    @Input() typeaheadModule: any;
    @Input() isCurrViewTemplate: boolean;
    @ViewChild('r1') billingDetailsRadio;
    constructor( public orderFormBuilder: OrderFormBuilder, public orderService: OrderService) {}

    ngOnInit() {
             this.orderBillingDetail = this.orderFormBuilder.orderForm['controls']['orderBillingDetail'];
             this.typeaheadModule = this.orderFormBuilder.orderForm.controls['orderBillingDetail']['controls']['typeaheadModule'];

    }


    ngAfterContentChecked() {
        if (this.orderData !== 'undefined') {
            this.subscription = this.orderService.getData().subscribe(sharedOrderData => {
                this.orderData = sharedOrderData;
            });
        }
    }

    radio(value) {
        if (value === 'billToAccountRadio') {
            this.billto = false;
            this.typeaheadModule['controls']['lineofBusiness'].setValidators([]);
            this.typeaheadModule['controls']['lineofBusiness'].updateValueAndValidity();

        } else {
            this.billto = true;
            this.typeaheadModule['controls']['billToCode'].setValidators([]);
            this.typeaheadModule['controls']['billToCode'].updateValueAndValidity();

        }

    }


    onChangeDropDown(value) {
        if (value > 1) {
            this.selectFlag = true;
            console.log(this.selectFlag);

        } else {

            this.selectFlag = false;

        }

    }


}
