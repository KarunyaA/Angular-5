import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { JBHGlobals } from '../../../../../app.service';
import { OrderService } from './../../order.service';

@Component({
    selector: 'app-charges',
    templateUrl: './charges.component.html',
    styleUrls: ['./charges.component.scss', '../comments/comments.component.scss']
})


export class ChargesComponent implements OnInit {

    public unitCodeList: string[] = [];
    public chargeList: Array < string > = [];
    public chargeListFlag = false;
    public onEditAuthDetail = false;
    public chargeDtoDetails: FormGroup;
    public typeHeadChargeCodeList: string[] = [];
    public editDelIndex: number;
    public delIndex: number;
    public updatedChargeCode: any;
    public subscription: any;
    public orderData: any;
    public unitFlag = false;
    public flatFlag = false;
    public addBtn = true;
    public editBtn = false;
    public gbEdtIdx: number;
    public showEditBtn: boolean;
    public debounceValue: any;
    public levelCode: Array < Object > ;
    @Input() totCharges: number;

    /* levelCode : Array<any>= [
        { chargeLvlCode: 'order' , chargeLevelTypeCode: 'ORDER'},

        { chargeLvlCode: 'stop' , chargeLevelTypeCode: 'STOP'}/*,
        { chargeLvlCode:"stop1" , chargeLevelTypeCode: "STOP 1"}
      ]; */

    constructor(public formBuilder: FormBuilder,
        public jbhGlobals: JBHGlobals,
        public orderService: OrderService) {}

    ngOnInit() {
        this.debounceValue = this.jbhGlobals.settings.debounce;
        this.frameChargeListFormBuilder();
        }

   public chargeTabClick() {
          this.unitFlag = false;
          this.flatFlag = true;
           if (this.jbhGlobals.utils.isEmpty(this.orderData)) {
            this.subscription = this.orderService.getData().subscribe(sharedOrderData => {
                this.orderData = sharedOrderData;
                if (!this.jbhGlobals.utils.isEmpty(this.orderData) && this.orderData.length !== 0) {
                    this.getDataService();
                }
            });
        }
    }

    public frameChargeListFormBuilder() {
        this.chargeDtoDetails = this.formBuilder.group({
            'chargeID': '',
            'chargeQuantity': ['0', Validators.compose([Validators.required,
                this.jbhGlobals.customValidator.chargeRateQuantity
            ])],
            'chargeUnitCode': '', // Unit type
            'chargeCode': '',
            'order': '',
            'chargeUnitRateAmount': ['00.0000', Validators.compose([Validators.required,
                this.jbhGlobals.customValidator.chargeRateCalculationAmount
            ])],
            'customerAuthorizationFirstName': '',
            'customerAuthorizationLastName': '',
            'customerAuthorizationNumber': '',
            'chargeLevelTypeCode': '',
            'chargeClassDescription': '',
            'chargeUnitCalculation': ''

        });

        this.chargeDtoDetails['controls']['chargeClassDescription']['valueChanges']
            .debounceTime(this.debounceValue)
            .distinctUntilChanged()
            .subscribe((chargeSearchVal) => {
                 const tabType = ( this.flatFlag === true ) ? 'FLAT' : 'UNIT';
                this.getChargeCodeList(chargeSearchVal, tabType);
            }, (err: Error) => {
                console.log(err);
            });
    }

    public getChargeCodeList(val, tabName) {
        let responseData: any;
        if (val !== undefined) {
        /* let stopreason='Delivery',serviceoffering=this.orderData.serviceOfferingCode,
                level=this.chargeDtoDetails.value.chargeLevelTypeCode; */
                const stopreason = 'Delivery',
                    serviceoffering = this.orderData.serviceOfferingCode,
                    level = this.chargeDtoDetails.value.chargeLevelTypeCode;
                const chargeCodeParam = val + '/' + stopreason + '/' + serviceoffering + '/' + level + '/' + tabName + '/' + 'MANUAL';
                this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getChargeCodes + chargeCodeParam).subscribe(data => {
                    responseData = data;
                    if (responseData !== undefined) {
                        this.typeHeadChargeCodeList = responseData;
                    }
                    this.jbhGlobals.logger.info('Getting flat Charge Code List --->');
                    this.jbhGlobals.logger.info( this.typeHeadChargeCodeList);
                });
            }
        }

    public getUnitCodeList(chargeCode) {
        const unitParam = {
            'chargecode': chargeCode,
        };
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getChargeUnitCodes, unitParam).subscribe(data => {
            this.unitCodeList = data['_embedded']['unitTypes'];
            this.jbhGlobals.logger.info('Getting Unit Code data --->');
        });
    }

    public selChargeUnitCode(selEvnt) {
        this.updatedChargeCode = selEvnt.item.chargeClassCode;
        this.getUnitCodeList(selEvnt.item.chargeClassCode);
    }

    public pushToChargeDto(chargeDto, param ?: any) {
        let custAuthName: string;
        let chargeDtoVal: any;
        const updateParam = param ? param : null;
        chargeDtoVal = chargeDtoVal ? chargeDto['value'] : chargeDto;
        custAuthName = chargeDtoVal['customerAuthorizationFirstName'].split(/(\s+)/);
        chargeDtoVal['customerAuthorizationFirstName'] = custAuthName[0];
        chargeDtoVal['customerAuthorizationLastName'] = custAuthName[2];
        chargeDtoVal['order'] = '/' + this.orderData['orderID'];
        chargeDtoVal['chargeCode'] = this.updatedChargeCode;
        chargeDtoVal['chargeUnitRateAmount'] = parseFloat(chargeDtoVal['chargeUnitRateAmount']);
        chargeDtoVal['chargeQuantity'] = parseFloat(chargeDtoVal['chargeQuantity']);
        this.chargeListFlag = false;
        this.addToChargeDto(chargeDtoVal, updateParam);
    }

    public addToChargeDto(chargeDto, updateParam) {
        const levelCode = chargeDto['chargeLevelTypeCode'];
        if (updateParam === 'update') {
            this.updateChargeService(chargeDto, levelCode);
        } else {
            this.addChargeService(chargeDto, levelCode);
        }
    }

    public addChargeService(chargeDto, levelCode) {
        if (levelCode.indexOf('ST') >= 0) {
            chargeDto['stop'] = '/1';
            this.jbhGlobals.apiService.addData(this.jbhGlobals.endpoints.order.stopcharge, chargeDto).subscribe(chargeData => {
                if (!this.jbhGlobals.utils.isEmpty(chargeData)) {
                    this.jbhGlobals.logger.info('Adding stopCharge Data --->');
                    this.jbhGlobals.logger.info(chargeData);
                    this.getDataService();
                }
            });
        } else {
            this.jbhGlobals.apiService.addData(this.jbhGlobals.endpoints.order.charge, chargeDto).subscribe(chargeData => {
                if (!this.jbhGlobals.utils.isEmpty(chargeData)) {
                    this.jbhGlobals.logger.info('Adding Charge Data --->');
                    this.jbhGlobals.logger.info(chargeData);
                    this.getDataService();
                }
            });
        }
    }

    public updateChargeService(chargeDto, levelCode) {
        if (levelCode.indexOf('ST') >= 0) {
            chargeDto['stop'] = '/1';
            this.jbhGlobals.apiService.updateData(this.jbhGlobals.endpoints.order.stopcharge + chargeDto.chargeID, chargeDto)
            .subscribe(chargeData => {
                if (!this.jbhGlobals.utils.isEmpty(chargeData)) {
                    this.jbhGlobals.logger.info('Updated Charge Data --->');
                    this.jbhGlobals.logger.info(chargeData);
                    this.getDataService();
                    this.chargeDtoDetails.reset();
                }
            });
        } else {
            this.jbhGlobals.apiService.updateData(this.jbhGlobals.endpoints.order.charge + chargeDto.chargeID, chargeDto)
            .subscribe(chargeData => {
                if (!this.jbhGlobals.utils.isEmpty(chargeData)) {
                    this.jbhGlobals.logger.info('Updated Charge Data --->');
                    this.jbhGlobals.logger.info(chargeData);
                    this.getDataService();
                    this.chargeDtoDetails.reset();

                }
            });
        }
    }

    public deleteChargeService(chargeId, levelCode) {
        if (levelCode.indexOf('ST') >= 0) {
            this.jbhGlobals.apiService.removeData(this.jbhGlobals.endpoints.order.stopcharge + chargeId).subscribe(chargeData => {
                this.delIndex = null;
                this.editDelIndex = null;
                this.getDataService();
            });
        } else {
            this.jbhGlobals.apiService.removeData(this.jbhGlobals.endpoints.order.charge + chargeId).subscribe(chargeData => {
                this.delIndex = null;
                this.editDelIndex = null;
                this.getDataService();
            });

        }
    }


    public getDataService() {
        let getChargeData;
        const me = this;
        me.totCharges = 0;
        getChargeData = this.jbhGlobals.endpoints.order.getorder + this.orderData['orderID'] + '/charges';
        this.jbhGlobals.apiService.getData(getChargeData).subscribe(chargeData => {
            if (!this.jbhGlobals.utils.isEmpty(chargeData)) {
                this.jbhGlobals.logger.info('Getting charge datalist --->');
                this.jbhGlobals.logger.info(chargeData);
                me.chargeList = [];
                me.levelCode = [];
                if (chargeData.length === 0) {
                    me.levelCode.push({
                        'chargeLvlCode': 'ORDER',
                        'chargeLevelTypeCode': 'ORDER'
                    });
                    //   me.totCharges = chargeData['_embedded']['chargeDToes'][0]['charge']['chargeUnitRateAmount'];
                    // me.chargeList.push(chargeData['_embedded']['chargeDToes'][0]['charge']);
                } else {
                    const arrLen = chargeData.length;
                    for (let i = 0; i < arrLen; i++) {
                        me.levelCode.push({
                            'chargeLvlCode': chargeData[i]['charge']['chargeLevelTypeCode'],
                            'chargeLevelTypeCode': chargeData[i]['charge']['chargeLevelTypeCode']
                        });
                        me.totCharges = me.totCharges + chargeData[i]['charge']['chargeUnitRateAmount'];
                        me.chargeList.push(chargeData[i]['charge']);
                        this.chargeListFlag = true;
                    }
                }
            } else {
                me.chargeList = [];
                me.levelCode = [];
                me.levelCode.push({
                        'chargeLvlCode': 'ORDER',
                        'chargeLevelTypeCode': 'ORDER'
                    });

            }
        });


    }
    public showUnitContent(el) {
        el.target.classList.remove('active');
        if (el.target.innerHTML === 'Flat') {
            this.unitFlag = false;
            this.flatFlag = true;
            el.target.classList.add('active');
            el.target.nextElementSibling.classList.remove('active');
        } else {
            //  this.chargeList.pop();
            this.flatFlag = false;
            this.unitFlag = true;
            el.target.previousElementSibling.classList.remove('active');
            el.target.classList.add('active');
        }
    }

    public enableChargeEdit(chargeIndex) {
        this.showEditBtn = true;
        this.onEditAuthDetail = true;
        this.editDelIndex = chargeIndex;
    }



    public editCharges(index) {
        let editValue: any;
        this.gbEdtIdx = index;
        this.addBtn = false;
        this.editBtn = true;
        editValue = this.chargeList[index];
        if (!this.jbhGlobals.utils.isEmpty(editValue['chargeUnitCode'])) {
            //  this.chargeList.pop();
            this.flatFlag = false;
            this.unitFlag = true;
        } else {
            this.unitFlag = false;
            this.flatFlag = true;
        }

        editValue['chargeUnitRateAmount'] = editValue['chargeUnitRateAmount'].toString();
        editValue['chargeQuantity'] = editValue['chargeQuantity'].toString();
        this.chargeDtoDetails.patchValue(editValue);
    }

    public delCharges(index) {

        this.showEditBtn = false;
        this.editDelIndex = null;
        this.delIndex = index;
    }

    public chargeCloseIcon(index) {
        const levelCode = this.chargeList[index]['chargeLevelTypeCode'];
        const chargeId = this.chargeList[index]['chargeID'];
        this.chargeList.splice(0, index);
        this.deleteChargeService(chargeId, levelCode);
    }

    public undoDelChargeSection(i) {
        this.delIndex = null;
        this.editDelIndex = null;

    }

    public onSaveCharge() {
        this.chargeList.splice(0, this.gbEdtIdx);
        const updateParam = 'update';
        this.pushToChargeDto(this.chargeDtoDetails.getRawValue(), updateParam);
        this.chargeDtoDetails.reset();
        this.onEditAuthDetail = false;
        this.addBtn = true;
        this.editBtn = false;
        this.showEditBtn = false;

    }

    public onAddCharges() {
        if (this.updatedChargeCode !== undefined) {
            this.pushToChargeDto(this.chargeDtoDetails.value);
            this.chargeDtoDetails.reset();
        }
    }

    public onCancelCharge() {
        this.chargeDtoDetails.reset();
        this.addBtn = true;
        this.editBtn = false;
        this.showEditBtn = false;
        this.onEditAuthDetail = false;
    }
}

