import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ManageoverlayComponent } from './manageoverlay.component';
import { CommentsComponent } from './comments/comments.component';
const routes: Routes = [{
    path: '',
    component: ManageoverlayComponent
  }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: []
})
export class ManageoverlayRoutingModule { }
