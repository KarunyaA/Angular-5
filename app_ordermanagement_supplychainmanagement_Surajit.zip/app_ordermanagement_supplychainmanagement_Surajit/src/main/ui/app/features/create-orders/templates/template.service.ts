import { Injectable } from '@angular/core';

@Injectable()
export class TemplateService {

  public testVar = 'Initial Value';

  public massUpdateTemplateIds = [];

  constructor() {
    console.log('Template Service Initialized');
  }

}
