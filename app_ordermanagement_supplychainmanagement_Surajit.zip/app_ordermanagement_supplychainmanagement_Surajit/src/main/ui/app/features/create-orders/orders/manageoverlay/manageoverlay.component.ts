import { Component, OnInit, ViewChild } from '@angular/core';

import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import {JBHGlobals} from './../../../../app.service';
import { OrderService } from './../order.service';
import { ChargesComponent } from './charges/charges.component';


@Component({
  selector: 'app-manageoverlay',
  templateUrl: './manageoverlay.component.html',
  styleUrls: ['./manageoverlay.component.scss']
})
export class ManageoverlayComponent implements OnInit {
	  public subscription: any;
    public orderData: any;

   @ViewChild (ChargesComponent) CharesComponent: any;

  constructor(
    public jbhGlobals: JBHGlobals,
    public orderService: OrderService) {

  }

  ngOnInit() {

  }
  public clickManageTab() {
   this.CharesComponent.chargeTabClick();
  }

}
