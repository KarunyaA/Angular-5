import { TestBed, inject } from '@angular/core/testing';

import { OrderFormBuilder } from './order-form-builder.service';

describe('OrderFormBuilder', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [OrderFormBuilder]
    });
  });

  it('should ...', inject([OrderFormBuilder], (service: OrderFormBuilder) => {
    expect(service).toBeTruthy();
  }));
});
