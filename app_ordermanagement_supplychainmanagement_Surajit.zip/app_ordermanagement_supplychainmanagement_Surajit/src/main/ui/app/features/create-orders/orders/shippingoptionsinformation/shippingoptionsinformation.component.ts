import { Component, Input, OnInit, OnChanges, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { JBHGlobals } from '../../../../app.service';
@Component({
  selector: 'app-shippingoptionsinformation',
  templateUrl: './shippingoptionsinformation.component.html',
  styleUrls: ['./shippingoptionsinformation.component.scss']
})
export class ShippingoptionsinformationComponent implements OnInit, OnChanges, OnDestroy {
  public rows: any[];
  public selected = [];
  public columns = [];
  public createGridMenu = [{
    'id': 'createopportunity',
    'name': 'Create Opportunity'
  }, {
    'id': 'createwithoutrate',
    'name': 'Create Without Rate'
  }, {
    'id': 'createspotoffer',
    'name': 'Create Spot Offer'
  }];
  @Input() parentData: any;
  constructor(public router: Router, public jbhGlobals: JBHGlobals) {
  }
  getAllShippingOptions() {
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.shippingoptions.getshippingoptions, '', false)
      .subscribe(data => {
        if (data !== undefined) {
          this.rows = data;
        }
      });
  }
  ngOnChanges() {
    this.getAllShippingOptions();
  }
  public showPopOver(pop, row) {
    if (!pop.isOpen) {
      pop.show();
    } else {
      pop.hide();
    }
  }
  ngOnInit() {
    this.getAllShippingOptions();
  }
  ngOnDestroy() {
  }
  menuClickEvent(selectedVal) {
    if (selectedVal === 'createopportunity') {
      // this.router.navigateByUrl('/automationrules/rules');
    } else if (selectedVal === 'createwithoutrate') {
      // this.router.navigateByUrl('/configure-rule/exporttoexcel');
    } else if (selectedVal === 'createspotoffer') {
      // this.router.navigateByUrl('/configure-rule/exporttoexcel');
    }

  }
}
