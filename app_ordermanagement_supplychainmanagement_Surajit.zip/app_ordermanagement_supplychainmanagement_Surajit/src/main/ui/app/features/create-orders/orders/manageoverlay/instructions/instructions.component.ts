import { Component, ViewChild, OnInit} from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import {OrderService} from '../../order.service';
import { JBHGlobals } from '../../../../../app.service';

@Component({
  selector: 'app-instructions',
  templateUrl: './instructions.component.html',
  styleUrls: ['./instructions.component.scss', '../comments/comments.component.scss']
})
export class InstructionsComponent implements OnInit {

@ViewChild('additionInstructionKey') additionInstructionKey: any;
  insTag= [];
  InsComments= [];
  lastUpdateTimestampString: string;
  selectedCmntDiv: any;
  orderData: any;
  public subscription: any;
  addInstructionDetail: FormGroup;
  public insArr: Array<string> = [];
  public instDesc: string[]= [];
  public instrTagInst: any;
  public addtionalInstructionValue: any;
  public addInstructioncode: any;
  public innerHtmlIns: any = '';
  public instructionResponse: any = [];
  public editIns: any;
  public getInstructionResponse: any = [];
  public editIndex: any;
  public additionalInstructionText: string[] = [];
  public additionalInstructionType: any = [];
  public editCall = false;
  public innerHtmlTag: string[] = [];
  public oldInstructiondesc: any = [];
  public editDelIndex: number;
  public selectedInstDiv: any;
  public insEdtIdx: number;
  public textCount: any;
  public showEditInsBtn: boolean;
  public instructionObj: Array<string> = [];
  public showdelInsBtn: boolean;
  public delInsDisplay: boolean;
  public delDivHide: boolean;
  public tabIndex: string;
  public instructionTagInput: string[]= ['Order', 'Stop', 'Billing', 'Equipment'];
addInstructionCode = new FormControl();
constructor(public formBuilder: FormBuilder, public orderService: OrderService, public jbhGlobals: JBHGlobals) {
}
ngOnInit() {
 this.addInstructionFormBuilder();
        if (this.jbhGlobals.utils.isEmpty(this.orderData)) {
            this.subscription = this.orderService.getData().subscribe(sharedOrderData => {
                this.orderData = sharedOrderData;
                if (!this.jbhGlobals.utils.isEmpty(this.orderData) && this.orderData.length !== 0) {
                    this.getDataService();
                }
            });
        }
    }

/*public instructionTabClick() {
         if (this.jbhGlobals.utils.isEmpty(this.orderData)) {
            this.subscription = this.orderService.getData().subscribe(sharedOrderData => {
                this.orderData = sharedOrderData;
                debugger;
                if (!this.jbhGlobals.utils.isEmpty(this.orderData) && this.orderData.length !== 0) {
                    this.getDataService();
                }
            });
        }
    }*/

public addInstructionFormBuilder() {
      this.addInstructionDetail = this.formBuilder.group({
        'instDesc': [Validators.compose([ Validators.required])],
        'instrTagInst': '',
        'additionalInstructionId': '',
        'stop': '',
        'order': '',
        'orderEquipmentRequirement': '',
        });
    }
instructionSave() {
 if (this.editCall === false) {
const obj = {instDesc: null, instrTagInst: null, lastUpdateTimestampString: null};
obj.instDesc = this.addInstructionDetail.value.instDesc;
obj.instrTagInst = this.addInstructionDetail.value.instrTagInst[0].value;
obj.lastUpdateTimestampString = new Date().toLocaleString();

const instructionObj = {
          'additionalInstructionText': this.addInstructionDetail.value.instDesc,
          'additionalInstructionId': '',
          'additionalInstructionType': this.addInstructionDetail.value.instrTagInst[0].value,
          'order': this.orderData['orderID'],
          'orderBillingDetail': '',
          'stop': this.orderData['stopID'],
          'orderEquipmentRequirement': null
        };
switch (this.addInstructionDetail.value.instrTagInst[0].value) {
case 'Order': {
this.instructionObj['order'] = this.orderData.orderId;
this.showEditInsBtn = false;
this.showdelInsBtn = false;
this.addInstructionDetail.reset();
this.innerHtmlIns = '';
this.onAdditionalInstruction(instructionObj);
break;
}
case 'Billing': {
this.instructionObj['order'] = this.orderData.orderId;
this.instructionObj['orderBillingDetail'] = this.orderData.billingId;
this.showEditInsBtn = false;
this.showdelInsBtn = false;
this.addInstructionDetail.reset();
this.innerHtmlIns = '';
this.onAdditionalInstruction(instructionObj);
break;
}
case 'Stop': {
this.instructionObj['order'] = this.orderData.orderId;
this.instructionObj['stop'] = this.orderData.stopId;
this.showEditInsBtn = false;
this.showdelInsBtn = false;
this.addInstructionDetail.reset();
this.innerHtmlIns = '';
this.onAdditionalInstruction(instructionObj);
break;
}
case 'Equipment': {
this.instructionObj['order'] = this.orderData.orderId;
this.instructionObj['orderEquipmentRequirement'] = this.orderData.EquipmentId;
this.showEditInsBtn = false;
this.showdelInsBtn = false;
this.addInstructionDetail.reset();
this.innerHtmlIns = '';
this.onAdditionalInstruction(instructionObj);
break;
}
default:
instructionObj['order'] = this.orderData.orderId;
this.showEditInsBtn = false;
this.showdelInsBtn = false;
this.addInstructionDetail.reset();
this.innerHtmlIns = '';
this.onAdditionalInstruction(instructionObj);
}
} else {
 this.updateInstructionService (this.addInstructionDetail.value);
  const obj = {instDesc: null, instrTagInst: null, lastUpdateTimestampString: null};
obj.instDesc = this.addInstructionDetail.value.instDesc;
obj.instrTagInst = this.addtionalInstructionValue;

if (this.addInstructionDetail.value.instrTagInst[0].value !== undefined) {
  this.addInstructionDetail.value.instrTagInst[0] = this.addInstructionDetail.value.instrTagInst[0].value;
} else {
  this.addInstructionDetail.value.instrTagInst[0] = this.addInstructionDetail.value.instrTagInst[0];
}
obj.lastUpdateTimestampString = new Date().toLocaleString();
const instructionObj = {
          'additionalInstructionText': this.addInstructionDetail.value.instDesc,
          'additionalInstructionId': this.addInstructionDetail.value.additionalInstructionId,
          'additionalInstructionType': this.addInstructionDetail.value.instrTagInst[0],
           'order': this.orderData['orderID'],
          'orderBillingDetail': this.orderData['orderBillingDetailDTOs']['profileDTO'][0]['partyID'],
          'stop': this.orderData['stopID'],
          'orderEquipmentRequirement': null,
          };
switch (this.addInstructionDetail.value.instrTagInst[0]) {
case 'Order': {
this.instructionObj['order'] = this.orderData.orderId;
this.showEditInsBtn = false;
this.showdelInsBtn = false;
this.addInstructionDetail.reset();
this.innerHtmlIns = '';
this.onAdditionalInstruction(instructionObj);
break;
}
case 'Billing': {
this.instructionObj['order'] = this.orderData.orderId;
instructionObj['orderBillingDetail'] = this.orderData.billingId;
this.showEditInsBtn = false;
this.showdelInsBtn = false;
this.addInstructionDetail.reset();
this.innerHtmlIns = '';
this.onAdditionalInstruction(instructionObj);
break;
}
case 'Stop': {
this.instructionObj['order'] = this.orderData.orderId;
instructionObj['stop'] = this.orderData.stopId;
this.showEditInsBtn = false;
this.showdelInsBtn = false;
this.addInstructionDetail.reset();
this.innerHtmlIns = '';
this.onAdditionalInstruction(instructionObj);
break;
}
case 'Equipment': {
this.instructionObj['order'] = this.orderData.orderId;
instructionObj['orderEquipmentRequirement'] = this.orderData.EquipmentId;
this.showEditInsBtn = false;
this.showdelInsBtn = false;
this.addInstructionDetail.reset();
this.innerHtmlIns = '';
this.onAdditionalInstruction(instructionObj);
break;
}
default:
this.instructionObj['order'] = this.orderData.orderId;
this.showEditInsBtn = false;
this.showdelInsBtn = false;
this.addInstructionDetail.reset();
this.innerHtmlIns = '';
this.onAdditionalInstruction(instructionObj);
}
}
}

public onAdditionalInstruction(instructionObj) {
this.jbhGlobals.apiService.addData(this.jbhGlobals.endpoints.order.postInstruction, instructionObj).subscribe( instructionData => {
  if (!this.jbhGlobals.utils.isEmpty(instructionData)) {
                    this.jbhGlobals.logger.info('Adding instructionData --->');
                    this.jbhGlobals.logger.info(instructionData);
                    this.getDataService();
                }
                });
}
public updateInstructionService(data) {
 }
public getDataService() {
let getInstructionData;
const me = this;
 getInstructionData = this.jbhGlobals.endpoints.order.getInstruction + this.orderData ['orderID'] + '/orderAdditionalInstructions';
 this.jbhGlobals.apiService.getData(getInstructionData).subscribe(instructionData => {
if (!this.jbhGlobals.utils.isEmpty(instructionData)) {
   this.jbhGlobals.logger.info('Getting Instruction data list --->');
                this.jbhGlobals.logger.info(instructionData);
                me.insArr = [];
                if (instructionData ['_embedded']['additionalInstructions'].length === 1) {
                  me.insArr.push(instructionData ['_embedded']['additionalInstructions'][0]);
                    } else {

                      const data = instructionData ['_embedded']['additionalInstructions'];
                      const arrLen = data.length;
                        for (let i = 0; i < arrLen; i++) {
                             me.insArr.push(data[i]);
}
}
}
  });
}
public deleteInstructionService(instructionId) {
 this.jbhGlobals.apiService.removeData(this.jbhGlobals.endpoints.order.removeInstruction + instructionId).subscribe(instructionData => {
           this.getDataService();
           this.addInstructionDetail.reset();
           this.editDelIndex = null;
           this.selectedInstDiv = null;
           this.innerHtmlIns = '';
            });
       }
enableChargeEdit(chargeIndex) {
      this.showEditInsBtn = true;
      this.showdelInsBtn = true;
       this.editDelIndex = chargeIndex;
}
editCommentSection(index) {

let editIns: any;
editIns = this.insArr[index];
this.addInstructionDetail.patchValue(editIns);
this.innerHtmlIns = editIns.additionalInstructionText;
this.innerHtmlTag = [];
this.innerHtmlTag.push(editIns.additionalInstructionType);
this.editCall = true;
}
delCommentSection(i) {
  this.selectedInstDiv = i;
  this.showdelInsBtn = true;
 }
instPmntDel(index) {
     const instructionId = this.insArr[index]['additionalInstructionId'];
     this.insArr.splice(index, 1);
     this.deleteInstructionService(instructionId);
}
undoDelInstSection(i) {
        this.selectedInstDiv = null;
    }
  }



