import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BulkUploadRoutingModule } from './bulk-upload-routing.module';
import { BulkUploadComponent } from './bulk-upload.component';

@NgModule({
  imports: [
    CommonModule,
    BulkUploadRoutingModule
  ],
  declarations: [BulkUploadComponent],
  exports: [BulkUploadComponent]
})
export class BulkUploadModule { }
