import { Component, OnInit } from '@angular/core';
import { JBHGlobals } from '../../../../../app.service';

@Component({
  selector: 'app-delivery-handling-units',
  templateUrl: './delivery-handling-units.component.html',
  styleUrls: ['./delivery-handling-units.component.scss']
})
export class DeliveryHandlingUnitsComponent implements OnInit {

  public handlingUnitList: Array<Object>;
  public handlingUnitSelectedList: Array<Object>;
  /* public selectedColor:string='list-group-item'; */

  constructor(public jbhGlobals: JBHGlobals) { }

  ngOnInit() {
    this.stopServiceCall();
  }

  public stopServiceCall(): void {
    const url = this.jbhGlobals.endpoints.order.getstopbyid;

    this.jbhGlobals.apiService.getData(url).subscribe(data => {
      /* this.itemBarCodeTypeList = data['_embedded']['barcodeTypes']; */
      if (data) {
        const list = data['stopDTO']['itemHandlingDetailDTOs'];
        this.handlingUnitSelectedList = list;
        this.servicecall();
      } else {
        this.servicecall();
      }
    });
  }

  public servicecall(): void {
    const stopId = 1,
      url = this.jbhGlobals.endpoints.order.updateorder + '' + stopId + '/fetchUnDeliveredItems';
    this.jbhGlobals.apiService.getData(url).subscribe(data => {
      /* this.itemBarCodeTypeList = data['_embedded']['barcodeTypes']; */
      this.handlingUnitList = data;
      console.log(this.handlingUnitList);
    }
    );
  }

  public saveCallOnClick(obj: Object, parent: any): void {
    const stopId = 4,
      checkbox = event.target;
    if (checkbox['checked']) {
      this.formSaveServiceCall(obj, stopId, parent, checkbox);
    } else {
      const itemhandLingId = obj['itemHandlingDetail']['itemHandlingDetailID'];
      this.formDeleteServiceCall(stopId, itemhandLingId, 'Delivery', parent, checkbox);
    }
  }
  public formSaveServiceCall(obj, stopId, parent, checkbox) {
    let params = {};
    const url = this.jbhGlobals.endpoints.order.crudHandlingUnit + '/' + stopId + '/itemhandlingdetails';
    params = obj;
    this.jbhGlobals.apiService.addData(url, params).subscribe(data => {
      this.stopServiceCall();
    }, (err: Error) => {
      checkbox['checked'] = false;
    });
  }

  public formDeleteServiceCall(stopId, handlingUnitId, reason, parent, checkbox) {
    const url = this.jbhGlobals.endpoints.order.crudHandlingUnit + '/' + stopId + '/itemhandlingdetails/' + handlingUnitId;
    this.jbhGlobals.apiService.removeData(url).subscribe(data => {
      this.stopServiceCall();
    }, (err: Error) => {
      checkbox['checked'] = true;
    });
  }
}
