import {Component, Input, OnInit, ViewChild, AfterContentChecked} from '@angular/core';
import {FormBuilder, FormGroup, Validators, FormControl} from '@angular/forms';
import { Http, Response, Headers, RequestOptions, URLSearchParams } from '@angular/http';

import {JBHGlobals} from '../../../../../../app.service';
import {OrderService} from '../../../order.service';
import { OrderFormBuilder } from '../../../order-form-builder.service';
import {AddcontactComponent} from '../addcontact/addcontact.component';

@Component({
    selector: 'app-typeahead',
    templateUrl: './typeahead.component.html',
    styleUrls: ['./typeahead.component.scss'],
})
export class TypeaheadComponent implements OnInit, AfterContentChecked {
   @ViewChild(AddcontactComponent) addcontact: AddcontactComponent;
    subscription: any;
    orderData: any;
    public flag: boolean;
    public selected: string;
    public typeaheadLoading: boolean;
    public typeaheadNoResults: boolean;
    public typeaheadLoadingSolicitor: boolean;
    public typeaheadNoResultsSolicitor: boolean;
    public typeaheadLoadingLob: boolean;
    public typeaheadNoResultsLob: boolean;


    public billtopartytype: string;
    public billtopartycode: string;
    public billtocode: string;
    public solicode: string;
    public lobcode: string;
    public additionalpartytype: string;

    public lobpartytype: string;
    public lobpartycode: string;
    public solipartytype: string;
    public solipartycode: string;
    public addpartytype: string;

    public billToContactTypeRes: any;
    public solicitorContactTypeRes: any;
    public lineOfBusinessContactTypeRes: any;

    public contactValue: any;

    public displaytypeaheadvalue: string[] = [];
    public typeAheadListSolicitor: string[] = [];
    public hiddenTypeAheadList: string[] = [];
    public typeAheadList: string[] = [];
    public typeAheadListLOB: string[] = [];

    public debounceValue: number;
    public orderId: number;
    public additionalPartyValue: string;
    public additionalPartyId: number;

    private lobValue: any;
    private billValue: any;
    private soliValue: any;

    private billtoaddressvalue: any;
    private lobaddressvalue: any;
    private soliaddressvalue: any;




    @Input() typeaheadModule: any;
    @Input() parentdata: any;


    lineofbusiness = new FormControl();


    constructor(public jbhGlobals: JBHGlobals, public orderService: OrderService, public orderFormBuilder: OrderFormBuilder) {}

    ngOnInit() {

      this.typeaheadModule = this.orderFormBuilder.orderForm.controls['orderBillingDetail']['controls']['typeaheadModule'];
      this.debounceValue = this.jbhGlobals.settings.debounce;

      this.typeaheadModule['controls']['billToCode']['valueChanges']

            .debounceTime(this.debounceValue)
            .distinctUntilChanged()

            .subscribe((value) => {


                     this.billtopartytype = 'Bill To';
             if ( value.length === 0 && value !== undefined) {
                      this.typeaheadModule['controls']['contactTypeCode']['setValue']('');
                      this.billToContactTypeRes = [];

                       }


                 if (value !== undefined && value.length > 2) {
                 this.getBillToTypeAhead(value, this.billtopartytype);
                 }
                }, (err: Error) => {
                    console.log(err);
                }

            );

       this.typeaheadModule['controls']['lineofBusiness']['valueChanges']
            .debounceTime(this.debounceValue)
            .distinctUntilChanged()

            .subscribe((value) => {




                this.lobpartytype = 'lineofbusiness' ;
                if ( value.length === 0 && value !== undefined) {
                      this.typeaheadModule['controls']['lineofbusinessContact']['setValue']('');
                      this.lineOfBusinessContactTypeRes = [];
                       }

                  if (value !== undefined && value.length > 2) {
                this.getLineOfBusinessTypeAhead(value, this.lobpartytype);
            }

            }, (err: Error) => {
                console.log(err);
            });

       this.typeaheadModule['controls']['solicitorCode']['valueChanges']
            .debounceTime(this.debounceValue)
            .distinctUntilChanged()
            .subscribe((value) => {
                this.solipartytype = 'Solicitor';
                 if ( value.length === 0 && value !== undefined) {
                      this.typeaheadModule['controls']['solicitorCodeContact']['setValue']('');
                      this.solicitorContactTypeRes = [];
                       }

                if (value !== undefined && value.length > 2) {
        this.getSolicitorTypeAhead(value, this.solipartytype);
      }
       }, (err: Error) => {
                console.log(err);
            });


        this.typeaheadModule['controls']['aditionalparty']['valueChanges']

            .debounceTime(this.debounceValue)
            .distinctUntilChanged()

            .subscribe((value) => {

                   this.additionalpartytype = 'AdditionalParty';
                     if (value !== undefined && value.length > 2) {
                   this.getAdditionalPartyTypeAhead(value, this.additionalpartytype);
               }

                }, (err: Error) => {
                    console.log(err);
                }

            );

     this.typeaheadModule['controls']['contactTypeCode']['valueChanges']
            .debounceTime(this.debounceValue)
            .distinctUntilChanged()
            .subscribe((billToContactCodeValue) => {
                  const obj = this.transform(this.billToContactTypeRes, billToContactCodeValue)[0];
                      this.contactValue = billToContactCodeValue;

            if (obj !== undefined) {

            if (this.orderData['orderBillingDetailDTOs'].length === 0) {
                  const contactOrderDto = {
                     'profileDTO': {
                         'contactId' : obj.contactId,
                         'contactType' : obj.contactMethod
                      }
                  };
                  this.orderData['orderBillingDetailDTOs'].push(contactOrderDto);
              } else if (this.orderData['orderBillingDetailDTOs'][0].profileDTO.contactDTO === undefined) {
                  const contactOrderDto = {
                         'contactId' : obj.contactId,
                         'contactType' : obj.contactMethod
                  };
                  this.orderData['orderBillingDetailDTOs'][0].profileDTO.contactDTO = contactOrderDto;
              } else {
                   this.orderData['orderBillingDetailDTOs'][0].profileDTO.contactDTO.contactId = obj.contactId; // obj.profileCode;
                    this.orderData['orderBillingDetailDTOs'][0].profileDTO.contactDTO.contactType = obj.contactMethod;
              }
          }

               this.orderService.saveData(this.orderData);


               /* this.orderData['orderBillingDetailDTOs'][0].profileDTO.contactDTO.contactId = obj.profileCode;
                this.orderData['orderBillingDetailDTOs'][0].profileDTO.contactDTO.contactType = obj.contactMethod;
                this.orderService.saveData(this.orderData);
                console.log("hi rohan check here for data",this.orderData)*/

                    this.billToContactCodeChangeDetection(billToContactCodeValue);
            }, (err: Error) => {
                console.log(err);
            });

            this.typeaheadModule['controls']['lineofbusinessContact']['valueChanges']
            .debounceTime(this.debounceValue)
            .distinctUntilChanged()
            .subscribe((lobContactCodeValue) => {

                  const obj = this.transform(this.lineOfBusinessContactTypeRes, lobContactCodeValue)[0];
                      this.contactValue = lobContactCodeValue;

                    if (obj !== undefined) {

                     if (this.orderData['orderBillingDetailDTOs'].length === 0) {
                  const contactOrderDto = {
                     'profileDTO': {
                         'contactId' : obj.contactId,
                         'contactType' : obj.contactMethod
                      }
                  };
                  this.orderData['orderBillingDetailDTOs'].push(contactOrderDto);
              } else if (this.orderData['orderBillingDetailDTOs'][0].profileDTO.contactDTO === undefined) {
                  const contactOrderDto = {
                         'contactId' : obj.contactId,
                         'contactType' : obj.contactMethod
                  };
                  this.orderData['orderBillingDetailDTOs'][0].profileDTO.contactDTO = contactOrderDto;
              } else {
                   this.orderData['orderBillingDetailDTOs'][0].profileDTO.contactDTO.contactId = obj.contactId;
                    this.orderData['orderBillingDetailDTOs'][0].profileDTO.contactDTO.contactType = obj.contactMethod;
              }
          }

                /*if (this.orderData['orderBillingDetailDTOs'][0].profileDTO.contactDTO == undefined) {
                  let contactOrderDto = {
                         "contactId":  obj.contactValue,//obj.profileCode saran,
                         "contactType":  obj.contactMethod
                  }
                  this.orderData['orderBillingDetailDTOs'][0].profileDTO.contactDTO = contactOrderDto;
              }else{
                    this.orderData['orderBillingDetailDTOs'][0].profileDTO.contactDTO.contactId = obj.contactValue;//obj.profileCode;
                    this.orderData['orderBillingDetailDTOs'][0].profileDTO.contactDTO.contactType = obj.contactMethod;
              }*/
               this.orderService.saveData(this.orderData);


               /* this.orderData['orderBillingDetailDTOs'][0].profileDTO.contactDTO.contactId = obj.profileCode;
                this.orderData['orderBillingDetailDTOs'][0].profileDTO.contactDTO.contactType = obj.contactMethod;
                this.orderService.saveData(this.orderData);
                console.log("hi rohan check here for data",this.orderData)*/

                  //  this.billToContactCodeChangeDetection(billToContactCodeValue)
            }, (err: Error) => {
                console.log(err);
            });

       this.typeaheadModule['controls']['solicitorCodeContact']['valueChanges']
            .debounceTime(this.debounceValue)
            .distinctUntilChanged()
            .subscribe((solicitorContactCodeValue) => {

                    const objsoli = this.transformSolicitor(this.solicitorContactTypeRes, solicitorContactCodeValue)[0];

                this.contactValue = solicitorContactCodeValue;

                if (this.orderData['orderRequestorDTOs'][0].profileDTO.contactDTO === undefined) {
                  const soliContactOrderDto = {
                         'contactId': objsoli.contactId,
                         'contactType': objsoli.contactMethod
                  };
                  this.orderData['orderRequestorDTOs'][0].profileDTO.contactDTO = soliContactOrderDto;
              } else {
                    this.orderData['orderRequestorDTOs'][0].profileDTO.contactDTO.contactId  = objsoli.contactId; // objsoli.contactId;
                   this.orderData['orderRequestorDTOs'][0].profileDTO.contactDTO.contactType  = objsoli.contactMethod;
              }
               this.orderService.saveData(this.orderData);

                this.solicitorContactCodeChangeDetection(solicitorContactCodeValue);
            }, (err: Error) => {
                console.log(err);
            });
 }

 transform(items: any[], args: string): any {
        // filter items array, items which match and return true will be kept, false will be filtered out
      return items.filter(item => item.contactValue.toLowerCase().indexOf(args.toLowerCase()) !== -1 );
  }

   transformSolicitor(items: any[], args: string): any {
        // filter items array, items which match and return true will be kept, false will be filtered out
      // return items.filter(item => item.firstName.toLowerCase().indexOf(args.toLowerCase()) !== -1 );
      return items.filter(item => item.contactValue.toLowerCase().indexOf(args.toLowerCase()) !== -1 );
  }

    ngAfterContentChecked() {
        if (this.orderData !== 'undefined') {
            this.subscription = this.orderService.getData().subscribe(sharedOrderData => {
                this.orderData = sharedOrderData;
            });
        }
    }

 public getBillToTypeAhead(value, billToPartyType) {

            const params = {
            value: value,
            roletype: billToPartyType,
            active: 'yes',
            page: 0,
            size: 5,
            approved: true,
            addresstype: 'FREIGHT BILL'
        };

       this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.gettypeaheadbillto, params, false).subscribe(data => {
    this.typeAheadList = [];
           // if(data['profileDTO'] !== undefined){

               // this.typeAheadList = data['profileDTO'];
            // }

            this.typeAheadList.push(data['profileDTO']);

        });
 }
    public getSolicitorTypeAhead(value, solipartytype) {

        const params = {
            value: value,
            roletype: solipartytype,
            active: 'yes',
            page: 0,
            size: 5,
            approved: true,
            addresstype: 'MAILING'

     };
 this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.gettypeaheadsolicitor, params, false).subscribe(data => {
           //  if(data['profileDTO'] !== undefined){
               this.typeAheadListSolicitor = [];
            this.typeAheadListSolicitor.push(data['profileDTO']);
        // }
     });
 }
    public getLineOfBusinessTypeAhead(value, lobpartytype) {
        const params = {
            value: value,
            roletype: lobpartytype,
            active: 'yes',
            page: 0,
            size: 5,
            approved: true,
            addresstype: 'physical'
         };
      this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.gettypeaheadlob, params, false).subscribe(data => {
             if (data['profileDTO'] !== undefined) {
            this.typeAheadListLOB = data['profileDTO'];
        }
});
  }

    public getAdditionalPartyTypeAhead(value, additionalpartytype) {
         const params = {
            value: value,
            roletype: additionalpartytype,
            active: 'yes',
            page: 0,
            size: 5,
            approved: true,
            addresstype: 'physical'
            };
       if (value !== undefined && value.length > 1) {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getadditionalparty, params, false).subscribe(data => {
            this.hiddenTypeAheadList = data['profileDTO'];

        });
    }
    }
 public onSelectbilltoaddress(billToPartyCode, billToPartyType) {

        const params = {
            code: billToPartyCode,
            roletype: billToPartyType,
            active: 'yes'
        };

        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getbilltocontact, params, false).subscribe(data => {
             if (data !== undefined) {

            this.billToContactTypeRes = data;

        }

        });

    }
    public onSelectSolicitorContact(solipartycode, solipartytype) {
        const params = {
            code: solipartycode,
            roletype: solipartytype,
            active: 'yes'
        };
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getsolicitorcontact, params, false).subscribe(data => {
            if (data !== undefined) {
            this.solicitorContactTypeRes = data;
        }

        });

    }

    public onSelectLineOfBusiness(lobpartycode, lobpartytype) {
        const params = {
            code: lobpartycode,
            roletype: lobpartytype,
            active: 'yes'
        };
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getlobcontact, params, false).subscribe(data => {
            if (data !== undefined) {
            this.lineOfBusinessContactTypeRes = data;
        }

        });

    }
    public onClickAdditionalParty() {
      this.flag = true;
    }

    public selectval(element, eve) {
        this.flag = false;
        this.additionalPartyValue = eve.item.name + '-' + eve.item.addressDTO.addressLine1 + ' ' + eve.item.addressDTO.addressLine2 +
            ',' + eve.item.addressDTO.city + ' ' + eve.item.addressDTO.country +
            ' ' + eve.item.addressDTO.state + ' ' + eve.item.addressDTO.zipcode + ' ' + '(' + eve.item.code + ')';

        if (this.displaytypeaheadvalue.indexOf(this.additionalPartyValue) === -1) {
            this.displaytypeaheadvalue.push(this.additionalPartyValue);
        element.value = '';
        this.orderId = this.orderData.orderID;
        this.additionalPartyId = eve.item.id;
        this.additionalPartyValue = eve.item.code;

       this.createAdditionalParty(this.orderId, this.additionalPartyId, this.additionalPartyValue);

     }

    }

    public createAdditionalParty(orderId, additionalPartyId, additionalPartyValue) {
        const params = {
            order: orderId,
            partyID: additionalPartyId,
            partyRoleCode: additionalPartyValue,
        };
        this.jbhGlobals.apiService.addData(this.jbhGlobals.endpoints.order.getadditionalpartysave, params).subscribe(data => {
         });
    }
    public delethobby(i: any) {
        this.displaytypeaheadvalue.splice(i, 1);
        this.jbhGlobals.apiService.removeData(this.jbhGlobals.endpoints.order.getadditionalpartydelet + '/' + 25).subscribe(data => {
          console.log(data);
         }, (err: Error) => {
            console.log(err);
        });

    }

    public typeaheadOnSelect(eve) {
        this.billtocode = eve.item.code;
        this.billtopartytype = 'Bill To';
         this.billtoaddressvalue = eve.item.name + '-' + eve.item.addressDTO.addressline1 + ' ' + eve.item.addressDTO.addressline2 +
      ',' + eve.item.addressDTO.city + ' ' + eve.item.addressDTO.cityID + ' ' + eve.item.addressDTO.country +
      ' ' + eve.item.addressDTO.state + ' ' + eve.item.addressDTO.zipcode;
       this.typeaheadModule['controls']['billToCode']['setValue'](this.billtoaddressvalue);

            this.typeaheadModule['controls']['contactTypeCode'].setValidators([Validators.required]);
            this.typeaheadModule['controls']['contactTypeCode'].updateValueAndValidity();

            this.onSelectbilltoaddress(this.billtocode, this.billtopartytype);

             this.typeaheadModule['controls']['lineofBusiness']['setValue']('');
              this.typeaheadModule['controls']['lineofbusinessContact']['setValue']('');

              if (this.orderData['orderBillingDetailDTOs'].length === 0) {
                console.log('len lob');
                  const orderDto = {
                     'profileDTO': {
                            'partyID': eve.item.id
                     },
                     'lineOfBusinessCode': null
                  };
                  this.orderData['orderBillingDetailDTOs'].push(orderDto);
              } else {
                   this.orderData['orderBillingDetailDTOs'][0].profileDTO.partyID  = eve.item.id;
                   this.orderData['orderBillingDetailDTOs'][0].lineOfBusinessCode = null;
              }

          //  this.orderData['orderBillingDetailDTOs'][0].profileDTO.partyID  = eve.item.code;
          //  this.orderData['orderBillingDetailDTOs'][0].profileDTO.lineOfBusinessCode = null;

         this.orderService.saveData(this.orderData);
            console.log('hi rohan check here for data', this.orderData);


    }
    public typeaheadOnSelectLOB(eve) {
        this.lobcode = eve.item.code;
         this.lobpartytype = 'lineofbusiness';
        this.lobaddressvalue = eve.item.name + '-' + eve.item.addressDTO.addressline1 + ' ' + eve.item.addressDTO.addressline2 +
      ',' + eve.item.addressDTO.city + ' ' + eve.item.addressDTO.cityID + ' ' + eve.item.addressDTO.country +
      ' ' + eve.item.addressDTO.state + ' ' + eve.item.addressDTO.zipcode;
       this.typeaheadModule['controls']['billToCode']['setValue'](this.lobaddressvalue);

            this.onSelectLineOfBusiness(this.lobcode, this.lobpartytype);

            this.typeaheadModule.controls['lineofbusinessContact'].setValidators([Validators.required]);
            this.typeaheadModule.controls['lineofbusinessContact'].updateValueAndValidity();
            this.typeaheadModule['controls']['billToCode']['setValue']('');
            this.typeaheadModule['controls']['contactTypeCode']['setValue']('');


            if (this.orderData['orderBillingDetailDTOs'].length === 0) {
                  const orderDto = {
                     'profileDTO': {
                            'partyID': null
                     },
                     'lineOfBusinessCode': eve.item.code
                  };
                  this.orderData['orderBillingDetailDTOs'].push(orderDto);
              } else {
                   this.orderData['orderBillingDetailDTOs'][0].lineOfBusinessCode = eve.item.code;
                     this.orderData['orderBillingDetailDTOs'][0].profileDTO.partyID = null;
              }
               this.orderService.saveData(this.orderData);

    }

    public typeaheadOnSelectSoli(eve) {
        this.solicode = eve.item.code;
        this.solipartytype = 'Solicitor';
      this.soliaddressvalue = eve.item.name + '-' + eve.item.addressDTO.addressline1 + ' ' + eve.item.addressDTO.addressline2 +
      ',' + eve.item.addressDTO.city + ' ' + eve.item.addressDTO.cityID + ' ' + eve.item.addressDTO.country +
      ' ' + eve.item.addressDTO.state + ' ' + eve.item.addressDTO.zipcode;
       this.typeaheadModule['controls']['billToCode']['setValue'](this.soliaddressvalue);
            this.onSelectSolicitorContact(this.solicode, this.solipartytype);

            this.typeaheadModule.controls['solicitorCodeContact'].setValidators([Validators.required]);
            this.typeaheadModule.controls['solicitorCodeContact'].updateValueAndValidity();

             if (this.orderData['orderRequestorDTOs'].length === 0) {
                  const solicitorOrderDto = {
                     'profileDTO': {
                            'partyID': eve.item.code
                     }
                  };
                  this.orderData['orderRequestorDTOs'].push(solicitorOrderDto);
              } else {
                    this.orderData['orderRequestorDTOs'][0].profileDTO.partyID  = eve.item.code;
              }
              this.orderService.saveData(this.orderData);


 }
 public changeTypeaheadLoading(e: boolean): void {
    this.typeaheadLoading = e;

  }

  public changeTypeaheadNoResults(e: boolean): void {
    this.typeaheadNoResults = e;

  }
  public changeTypeaheadLoadingLOB(e: boolean): void {

    this.typeaheadLoadingLob = e;
  }

  public changeTypeaheadNoResultsLOB(e: boolean): void {

     this.typeaheadNoResultsLob = e;
  }
  public changeTypeaheadLoadingSoli(e: boolean): void {

    this.typeaheadLoadingSolicitor = e;

  }

  public changeTypeaheadNoResultsSoli(e: boolean): void {

    this.typeaheadNoResultsSolicitor = e;

  }

 /*
  public typeaheadOnSelect(e: TypeaheadMatch): void {
    console.log('Selected value: ', e.value);
  }*/

  billToContactCodeChangeDetection(billToContactCodeValue) {
        // console.log("billToContactValue search result ->", billToContactCodeValue.length);
    }



    solicitorContactCodeChangeDetection(solicitorContactCodeValue) {
        // console.log("SolicitorContactValue search result ->", solicitorContactCodeValue);
    }

    onBlurType(eve) {
        this.typeaheadModule['controls']['billToCode'].setValidators([Validators.required]);
            this.typeaheadModule['controls']['billToCode'].updateValueAndValidity();
    }
    onBlurTypeLOB(eve) {
        this.typeaheadModule['controls']['lineofBusiness'].setValidators([Validators.required]);
            this.typeaheadModule['controls']['lineofBusiness'].updateValueAndValidity();
    }
    private billToAddContactChange(eve) {

      console.log(eve);
    }
    onChangeDropDown(value) {
     if (value === 'popup') {
           this.addcontact.showModal();
       }
     }

}
