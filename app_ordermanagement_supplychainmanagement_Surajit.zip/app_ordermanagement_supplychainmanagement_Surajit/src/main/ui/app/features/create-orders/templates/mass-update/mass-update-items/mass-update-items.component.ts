import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mass-update-items',
  templateUrl: './mass-update-items.component.html',
  styleUrls: ['./mass-update-items.component.scss']
})
export class MassUpdateItemsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
