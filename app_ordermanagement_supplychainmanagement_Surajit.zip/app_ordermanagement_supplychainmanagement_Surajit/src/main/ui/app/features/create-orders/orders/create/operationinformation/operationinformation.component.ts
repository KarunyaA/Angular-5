import { Component, Input, OnInit } from '@angular/core';
import { JBHGlobals } from '../../../../../app.service';
import { OrderService } from '../../order.service';
import { OrderFormBuilder } from '../../order-form-builder.service';

@Component({
  selector: 'app-operationinformation',
  templateUrl: './operationinformation.component.html',
  styleUrls: ['./operationinformation.component.scss']
})

export class OperationinformationComponent implements OnInit {
  public value: any = {};
  public equipmentType: any[] = [];
  public equipmentCategory: any[] = [];
  public equipmentLength: any[] = [];
  public trailerPrefix: any[] = [];
  public trailerNumber: any[] = [];
  public equipOptionList: string[] = [];
  public equipList: any[] = [];
  public selectedEquipList: any[] = [];
  public selectedEquipDescription: string[] = [];
  public freightSecurementList: string[] = [];
  public personalProtectionMaterialList: any[] = [];
  public personalProtectionMaterialListDescription: string[] = [];
  public freightSecureList: any[] = [];
  public freightSecureListDescription: string[] = [];
  public selectedEquipmentTags: any = [];
  public selectedFreightTags: any = [];
  public selectedProtectionTags: any = [];
  public trailerPrefixList: any = [];
  public trailerPrefixListDescription: any = [];
  public trailerNumberListDescription: any = [];
  public flag = true;
  public equipPlaceholder = 'Equipment Options';
  public freightPlaceholder = 'Freight Securement';
  public protectionPlaceholder = 'Personal Protection';
  public manualPallet = 'Manual Pallet Jack';
  public handTrucks = 'Hand Trucks';
  public moffets = 'Moffets';
  public forkLifts = 'Fork Lifts';
  public liftGates = 'Lift Gates';
  public isManualPallet = false;
  public isHandtrucks = false;
  public isMoffets = false;
  public isForkLifts = false;
  public isLiftGates = false;
  public financeBUValue = '';
  public serviceOfferingValue = '';
  public manualPalletSpecID = '';
  public handtrucksSpecID = '';
  public moffetsSpecID = '';
  public forkLiftsSpecID = '';
  public liftGatesSpecID = '';
  public selCategory = '';
  public selType = '';
  public selLength = '';
  public debounceValue: number;
  public hasTrailerNumber = false;
  public hasTrailerPrefix = false;
  public selNumber = '';
  public selPrefix = '';
  public isCompanyTrailer = false;

  @Input() operationInformationDetail: any;
  subscription: any;
  orderData: any;

  constructor(public jbhGlobals: JBHGlobals, public orderService: OrderService, public orderFormBuilder: OrderFormBuilder) {
  }

  public onClickTrailerEquip(onSelEquipment) {
    this.operationInformationDetail['controls']['trailerPrefix'].setValue('');
    this.operationInformationDetail['controls']['trailerNumber'].setValue('');
    this.operationInformationDetail['controls']['orderNonCompanyEquipmentDetails'].setValue('');
    this.selectedFreightTags = [];
    this.selectedProtectionTags = [];
    this.selectedEquipmentTags = [];
    const requirementDTO = this.orderData.orderEquipmentRequirementDTOs;
    if (onSelEquipment === true) {
       this.flag = true ;
      if (requirementDTO !== undefined) {
        if (requirementDTO[0].trailerNumber !== undefined) {
           requirementDTO[0].trailerNumber = '';
        }
        if (requirementDTO[0].trailerPrefix !== undefined) {
           requirementDTO[0].trailerPrefix = '';
        }
        if (requirementDTO[0].orderEquipmentRequirement.orderNonCompanyEquipmentDetails) {
            requirementDTO[0].orderEquipmentRequirement.orderNonCompanyEquipmentDetails = '';
        }
        if (requirementDTO[0].orderEquipmentRequirement.trailerPreloadedIndicator) {
            requirementDTO[0].orderEquipmentRequirement.trailerPreloadedIndicator = 'N';
        }
      }
    } else {
       this.flag = false;
      if (requirementDTO) {
        if (requirementDTO.orderEquipmentRequirement !== undefined) {
          requirementDTO[0].orderEquipmentRequirement.trailerPreloadedIndicator = 'Y';
          if (requirementDTO.orderEquipmentRequirement.equipmentLengthRequiredIndicator !== undefined) {
            requirementDTO[0].orderEquipmentRequirement.equipmentLengthRequiredIndicator = '';
          }
          if (requirementDTO.orderEquipmentRequirement.equipmentTypeRequiredIndicator !== undefined) {
            requirementDTO[0].orderEquipmentRequirement.equipmentTypeRequiredIndicator = '';
          }
        }
        if (requirementDTO.orderEquipmentRequirement !== undefined) {
          requirementDTO[0].orderEquipmentRequirement.orderEquipmentTypeCategoryDetailDTO = [];
        }
     }
    }
    if (requirementDTO !== undefined) {
      if (requirementDTO[0].orderEquipmentRequirementSpecificationAssociationDTOs !== undefined) {
        requirementDTO[0].orderEquipmentRequirementSpecificationAssociationDTOs = [];
      }
      if (requirementDTO[0].orderEquipmentTypeCategoryDetailDTO !== undefined) {
        requirementDTO[0].orderEquipmentTypeCategoryDetailDTO = {};
      }
      if (requirementDTO[0].orderEquipementRequirementFeatureAssociationDTOs !== undefined) {
        requirementDTO[0].orderEquipementRequirementFeatureAssociationDTOs = [];
      }
    }
     this.orderService.saveData(this.orderData);
  }
  public getEquipmentType() {
    this.financeBUValue = this.orderData.financeBusinessUnitCode;
    this.serviceOfferingValue = this.orderData.serviceOfferingCode;
    const params = {
      financebusinessunitcode: this.financeBUValue,
      serviceofferingcode: this.serviceOfferingValue
    };
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getEquipmentType, params).subscribe(data => {
      if (data !== undefined) {
        this.equipmentType = data['_embedded']['equipmentTypes'];
      }
    });
  }
  public getEquipmentCategory() {
    this.financeBUValue = this.orderData.financeBusinessUnitCode;
    this.serviceOfferingValue = this.orderData.serviceOfferingCode;
    const params = {
      financebusinessunitcode: this.financeBUValue,
      serviceofferingcode: this.serviceOfferingValue
    };
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getEquipmentCategory, params).subscribe(data => {
      if (data !== undefined) {
        this.equipmentCategory = data['_embedded']['equipmentClassifications'];
      }
    });
  }
  public getEquipmentLength() {
    const params = {
      'equipmentclassificationtypeassociationid': 7
    };
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getEquipmentLength, params).subscribe(data => {
      if (data !== undefined) {
        this.equipmentLength = data['_embedded']['equipmentRequirementSpecificationAssociations'];
      }
    });
  }
  public getEquipmentOption() {
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getEquipmentOptionFeatures).subscribe(data => {
      this.equipList = data;
      for (let i = 0; i < this.equipList.length; i++) {
        const equipCode = this.equipList[i]['code'];
        if (equipCode !== 'Freight' && equipCode !== 'Length' && equipCode !== 'MatHandEqu' && equipCode !== 'PersnalPro') {
         if ((this.equipList[i]['code'] === 'Door') || (this.equipList[i]['code'] === 'Roof') || (this.equipList[i]['code'] === 'Floor')) {
            this.equipOptionList.push(this.equipList[i]['associatedDescription'] + '&nbsp;' + this.equipList[i]['code']);
          }else {
            this.equipOptionList.push(this.equipList[i]['associatedDescription'] + '&nbsp;' + 'Other');
          }
        }
      }
    });
  }
  public getFreightSecurement() {
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getEquipmentOptionFeatures).subscribe(data => {
      this.freightSecureList = data;
      for (let i = 0; i < this.freightSecureList.length; i++) {
        const freightCode = this.freightSecureList[i]['code'];
        if (freightCode === 'Freight') {
          this.freightSecureListDescription.push(this.freightSecureList[i]['associatedDescription']);
        }
      }
    });
  }

  public equipSelectedData(value: any): void {
   this.selectedEquipmentTags = value;
  }
  public freightSelectedData(value: any): void {
   this.selectedFreightTags = value;
  }
  public protSelectedData(value: any): void {
    this.selectedProtectionTags = value;
  }
  public onSelectEquipOptionsService(value) {
    let selVal = value.id;
    selVal = selVal.substring(0, selVal.indexOf('&'));
    const equipRequirementObj = this.transformEquip(this.equipList, selVal)[0];
    for (let i = 0; i < this.selectedEquipList.length; i++) {
      if (this.selectedEquipList[i].type === equipRequirementObj.code) {
          this.selectedEquipmentTags.splice(this.selectedEquipmentTags.indexOf(this.selectedEquipList[i].desc), 1);
      }
    }
    const equipObj = {
      'type': equipRequirementObj.code,
      'desc': equipRequirementObj.description
    };
    this.selectedEquipList.push(equipObj);

    if (this.selectedEquipmentTags.indexOf(value) !== -1) {
      const selEquipObj = this.transformEquip(this.equipList, selVal)[0];
      if (selEquipObj.equipmentClassificationTypeFeatureAssociationID !== null) {
        this.frameFeatureSpecificationOrderDTO(selEquipObj);
      }else {
        this.frameEquipSpecificationOrderDTO(selEquipObj);
      }
    }
  }
  public onRemoveEquipOptionsService(value) {
    let remVal = value.id;
    remVal = remVal.substring(0, remVal.indexOf('&'));
    const removeEquipObj = this.transformEquip(this.equipList, remVal)[0];
    this.removeEquipSpecificationOrderDTO(removeEquipObj);
  }
  public onSelectFreightSecureService(selectedFreight) {
    const freightSecureObj = this.equipListTransform(this.freightSecureList, selectedFreight.id)[0];
    this.frameEquipSpecificationOrderDTO(freightSecureObj);
  }
  public onRemoveFreightSecureService(value) {
    const removeFreightObj = this.equipListTransform(this.freightSecureList, value.id)[0];
    this.removeEquipSpecificationOrderDTO(removeFreightObj);
  }
  public loadProtectionMaterialHandling() {
    // Get all PersonalProtection And MaterialHandling Equipment
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getProtectionMaterialHandling).subscribe(data => {
      this.personalProtectionMaterialList = data['_embedded']['equipmentRequirementSpecificationAssociations'];
      for (let i = 0; i < this.personalProtectionMaterialList.length; i++) {
        const eSpc = this.personalProtectionMaterialList[i]['equipmentRequirementSpecification'];
        const eDesc = eSpc['equipmentRequirementSpecificationDescription'];
        this.personalProtectionMaterialListDescription.push(eDesc);
      }
    });
  }
  public onSelectProtectionHandling(value, event) {
    const protectionObj = this.protectionListTransform(this.personalProtectionMaterialList, value.id)[0];
    if (value.id.trim() === this.manualPallet) {
      this.isManualPallet = true;
      this.manualPalletSpecID = protectionObj.equipmentRequirementSpecificationAssociationID;
    }
    if (value.id.trim() === this.handTrucks) {
      this.isHandtrucks = true;
      this.handtrucksSpecID = protectionObj.equipmentRequirementSpecificationAssociationID;
    }
    if (value.id.trim() === this.moffets) {
      this.isMoffets = true;
      this.moffetsSpecID = protectionObj.equipmentRequirementSpecificationAssociationID;
    }
    if (value.id.trim() === this.forkLifts) {
      this.isForkLifts = true;
      this.forkLiftsSpecID = protectionObj.equipmentRequirementSpecificationAssociationID;
    }
    if (value.id.trim() === this.liftGates) {
      this.isLiftGates = true;
      this.liftGatesSpecID = protectionObj.equipmentRequirementSpecificationAssociationID;
    }
    this.frameProtectionSpecificationOrderDTO(protectionObj);
  }
  public onBlurQuantity(value, requiredQtyField) {
    let reqFieldSpecID = '';
    if (requiredQtyField === 'Manual') {
      reqFieldSpecID = this.manualPalletSpecID;
    }
    if (requiredQtyField === 'HandTrucks') {
      reqFieldSpecID = this.handtrucksSpecID;
    }
    if (requiredQtyField === 'Moffets') {
      reqFieldSpecID = this.moffetsSpecID;
    }
    if (requiredQtyField === 'ForkLifts') {
      reqFieldSpecID = this.forkLiftsSpecID;
    }
    if (requiredQtyField === 'LiftGates') {
      reqFieldSpecID = this.liftGatesSpecID;
    }
    const orderEq = this.orderData.orderEquipmentRequirementDTOs[0].orderEquipmentRequirement[0];
    const eA = orderEq.orderEquipmentRequirementSpecificationAssociations;
    if (eA === undefined) {
      orderEq.orderEquipmentRequirementSpecificationAssociations = [];
    }
    const vl = {
      'equipmentRequirementSpecificationAssociationID': reqFieldSpecID,
      'orderEquipmentRequirementSpecificationDetails': [{
        'specificationDetailValue': value
      }]
    };
    eA.push(vl);
    this.orderService.saveData(this.orderData);
  }
  public onRemoveProtectionHandling(value) {
    const removeProtectionObj = this.protectionListTransform(this.personalProtectionMaterialList, value.id)[0];
    if (value.id.trim() === this.manualPallet) {
      this.isManualPallet = false;
    }
    if (value.id.trim() === this.handTrucks) {
      this.isHandtrucks = false;
    }
    if (value.id.trim() === this.moffets) {
      this.isMoffets = false;
    }
    if (value.id.trim() === this.forkLifts) {
      this.isForkLifts = false;
    }
    if (value.id.trim() === this.liftGates) {
      this.isLiftGates = false;
    }
    this.removeProtectionSpecificationOrderDTO(removeProtectionObj);
  }
  protectionListTransform(items: any[], args: string): any {
    // filter items array, items which match and return true will be kept, false will be filtered out
    const s = args.toLowerCase();
    return items.filter(item =>
      item.equipmentRequirementSpecification.equipmentRequirementSpecificationDescription.toLowerCase().indexOf(s) !== -1);
  }
  transformEquip(items: any[], args: string): any {
    // filter items array, items which match and return true will be kept, false will be filtered out
    return items.filter(item => item.associatedDescription.toLowerCase().indexOf(args.toLowerCase()) !== -1);
  }
  public onSelectEquipmentType(value) {
    const obj = this.transform(this.equipmentType, value)[0];
    if (this.orderData.orderEquipmentRequirementDTOs === undefined) {
      this.orderData.orderEquipmentRequirementDTOs = [];
    }
    if (this.orderData.orderEquipmentRequirementDTOs.length === 0) {
      const orderEquipmentTypeDetailObj = {
        'orderEquipmentTypeCategoryDetailDTO': {
          'equipmentTypeCode': obj.equipmentTypeCode,
          'equipmentTypeDescription': obj.equipmentTypeDescription
        }
      };
      this.orderData.orderEquipmentRequirementDTOs.push(orderEquipmentTypeDetailObj);
    } else if (this.orderData.orderEquipmentRequirementDTOs[0].orderEquipmentTypeCategoryDetailDTO === undefined) {
      const typeCode = {
          'equipmentTypeCode': obj.equipmentTypeCode,
          'equipmentTypeDescription': obj.equipmentTypeDescription
      };
      this.orderData.orderEquipmentRequirementDTOs[0].orderEquipmentTypeCategoryDetailDTO = [];
      this.orderData.orderEquipmentRequirementDTOs[0].orderEquipmentTypeCategoryDetailDTO = typeCode;
    } else {
      const eReq = this.orderData.orderEquipmentRequirementDTOs[0].orderEquipmentTypeCategoryDetailDTO;
      eReq.equipmentTypeCode = obj.equipmentTypeCode;
      eReq.equipmentTypeDescription = obj.equipmentTypeDescription;
    }
    this.orderService.saveData(this.orderData);
  }
  public onSelectEquipmentCategory(value) {
    const obj = this.categoryTransform(this.equipmentCategory, value)[0];
    if (this.orderData.orderEquipmentRequirementDTOs === undefined) {
      this.orderData.orderEquipmentRequirementDTOs = [];
    }
    const orderEquipmentCategoryDetailObj = {
        'orderEquipmentTypeCategoryDetailDTO': {
          'equipmentCategoryClassificationTypeAssociationID': 1, // from servce
          'equipmentCategoryCode': obj.equipmentClassificationCode,
          'equipmentCategoryDescription': obj.equipmentClassificationDescription
        }
      };
    if (this.orderData.orderEquipmentRequirementDTOs.length === 0) {
      this.orderData.orderEquipmentRequirementDTOs.push(orderEquipmentCategoryDetailObj);
    } else if (this.orderData.orderEquipmentRequirementDTOs[0].orderEquipmentTypeCategoryDetailDTO === undefined) {
      const catCode = {
          'equipmentCategoryClassificationTypeAssociationID': 1, // from servce
          'equipmentCategoryCode': obj.equipmentClassificationCode,
          'equipmentCategoryDescription': obj.equipmentClassificationDescription
      };
      this.orderData.orderEquipmentRequirementDTOs[0].orderEquipmentTypeCategoryDetailDTO = [];
      this.orderData.orderEquipmentRequirementDTOs[0].orderEquipmentTypeCategoryDetailDTO = catCode;
    } else {
      const eReqC = this.orderData.orderEquipmentRequirementDTOs[0].orderEquipmentTypeCategoryDetailDTO;
      eReqC.equipmentCategoryCode = obj.equipmentClassificationCode;
      eReqC.equipmentCategoryDescription = obj.equipmentClassificationDescription;
    }
    this.orderService.saveData(this.orderData);
  }
  public onSelectEquipmentLength(value) {
    const lengthObj = this.protectionListTransform(this.equipmentLength, value)[0];
    this.frameProtectionSpecificationOrderDTO(lengthObj);
  }
  public loadTrailerPrefixByNumber(selectedNumber) {
    // Get all OperationalOwner
    this.selNumber = selectedNumber;
    this.trailerPrefixListDescription = [];
    this.hasTrailerPrefix = false;
    const params = {
      'trailernumber': this.selNumber
    };
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getTrailerPrefixByNumber, params, false).subscribe( data => {
        this.hasTrailerPrefix = true;
          if (data['trailerPrefix']) {
            this.trailerPrefixListDescription.push(data['trailerPrefix'].trim());
          }
        }
    );

    this.checkForCompanyTrailer();
  }

  public loadTrailerNumberByPrefix(selectedPrefix) {
    // Get all OperationalOwner
    this.selPrefix = selectedPrefix;
    this.trailerNumberListDescription = [];
     this.hasTrailerNumber = false;
    const params = {
     'trailerprefix': selectedPrefix
    };
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getNumberByPrefix, params, false).subscribe( data => {
          this.hasTrailerNumber = true;
          if (data['trailerNumber']) {
            this.trailerNumberListDescription.push(data['trailerNumber'].trim());
          }
        }
    );
    this.checkForCompanyTrailer();
  }

  public checkForCompanyTrailer() {
    if (this.selNumber && this.selPrefix) {
      const qParam = '/' + this.selPrefix + '/' + this.selNumber;
       this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.isCompanyTrailer + qParam).subscribe( data => {
          if (data['id']) {
            this.isCompanyTrailer = true;
          }
        }
      );
    }
    this.saveTrailerNoDTO();
    this.saveTrailerPrefixDTO();
  }
  public saveTrailerNoDTO() {
    if (this.orderData.orderEquipmentRequirementDTOs === undefined) {
      this.orderData.orderEquipmentRequirementDTOs = [];
    }
    if (this.orderData.orderEquipmentRequirementDTOs.length === 0) {
      const trailerNumberObj = {
        'trailerNumber': this.selNumber
      };
      this.orderData.orderEquipmentRequirementDTOs.push(trailerNumberObj);
    } else if (this.orderData['orderEquipmentRequirementDTOs'][0].trailerNumber === undefined) {
      this.orderData['orderEquipmentRequirementDTOs'][0].trailerNumber = this.selNumber;
    } else {
      this.orderData['orderEquipmentRequirementDTOs'][0].trailerNumber = this.selNumber;
    }
    this.orderService.saveData(this.orderData);
  }

  public onSelectPrefix(value: any): void {
    const selectedPrefix = value.id.trim();
    this.selPrefix = selectedPrefix;
    this.checkForCompanyTrailer();
  }
  public onSelectTrailerNumber(value: any): void {
    const selectedNumber = value.id.trim();
    this.selNumber = selectedNumber;
    this.checkForCompanyTrailer();
  }
  public saveTrailerPrefixDTO() {
    if (this.orderData.orderEquipmentRequirementDTOs === undefined) {
      this.orderData.orderEquipmentRequirementDTOs = [];
    }
    if (this.orderData.orderEquipmentRequirementDTOs.length === 0) {
      const trailerPrefixObj = {
        'trailerPrefix': this.selPrefix
      };
      this.orderData.orderEquipmentRequirementDTOs.push(trailerPrefixObj);
    } else if (this.orderData['orderEquipmentRequirementDTOs'][0].trailerPrefix === undefined) {
      this.orderData['orderEquipmentRequirementDTOs'][0].trailerPrefix = this.selPrefix;
    } else {
      this.orderData['orderEquipmentRequirementDTOs'][0].trailerPrefix = this.selPrefix;
    }
    this.orderService.saveData(this.orderData);
  }
  transform(items: any[], args: string): any {
    // filter items array, items which match and return true will be kept, false will be filtered out
    return items.filter(item => item.equipmentTypeDescription.toLowerCase().indexOf(args.toLowerCase()) !== -1);
  }
  onBlurChasisNo(value) {
    if (this.orderData.orderEquipmentRequirementDTOs === undefined) {
      this.orderData.orderEquipmentRequirementDTOs = [];
    }
    if (this.orderData.orderEquipmentRequirementDTOs.length === 0) {
      const orderEquipmentReqObj = {
        'orderEquipmentRequirement': {
          'orderNonCompanyEquipmentDetails': value,
          'trailerPreloadedIndicator': 'Y'
        }
      };
      this.orderData.orderEquipmentRequirementDTOs.push(orderEquipmentReqObj);
    } else if (this.orderData['orderEquipmentRequirementDTOs'][0].orderEquipmentRequirement === undefined) {
      const orderEquipmentReqObj = {
        'orderNonCompanyEquipmentDetails': value,
        'trailerPreloadedIndicator': 'Y'
      };
      this.orderData['orderEquipmentRequirementDTOs'][0].orderEquipmentRequirement = orderEquipmentReqObj;
    } else {
      this.orderData['orderEquipmentRequirementDTOs'][0].orderEquipmentRequirement.orderNonCompanyEquipmentDetails = value;
      this.orderData['orderEquipmentRequirementDTOs'][0].orderEquipmentRequirement.trailerPreloadedIndicator = 'Y';
    }
    this.orderService.saveData(this.orderData);
  }
  ngOnInit() {
    this.getOrder();
    this.operationInformationDetail = this.orderFormBuilder.orderForm.controls['operationInformationDetail'];
    const eType = this.operationInformationDetail['controls']['equipmentTypeRequiredIndicator'];
    eType['valueChanges'].debounceTime(this.debounceValue).distinctUntilChanged().subscribe((equipTypeIndicator) => {
      let eTypeVal = 'N';
      if (equipTypeIndicator) {
        eTypeVal = 'Y';
      }
      if (this.orderData.orderEquipmentRequirementDTOs === undefined) {
        this.orderData.orderEquipmentRequirementDTOs = [];
      }
      if (this.orderData.orderEquipmentRequirementDTOs.length === 0) {
        const orderEquipmentReqObj = {
          'orderEquipmentRequirement': {
            'equipmentTypeRequiredIndicator': eTypeVal
          }
        };
        this.orderData.orderEquipmentRequirementDTOs.push(orderEquipmentReqObj);
      } else if (this.orderData['orderEquipmentRequirementDTOs'][0].orderEquipmentRequirement === undefined) {
        const orderEquipmentReqObj = {
          'equipmentTypeRequiredIndicator': eTypeVal
        };
        this.orderData['orderEquipmentRequirementDTOs'][0].orderEquipmentRequirement = orderEquipmentReqObj;
      } else {
        this.orderData['orderEquipmentRequirementDTOs'][0].orderEquipmentRequirement.equipmentTypeRequiredIndicator = eTypeVal;
      }
      this.orderService.saveData(this.orderData);
    }, (err: Error) => {
      console.log(err);
    });
    const eLen = this.operationInformationDetail['controls']['equipmentLengthRequiredIndicator'];
    eLen['valueChanges'].debounceTime(this.debounceValue).distinctUntilChanged().subscribe((equipLengthIndicator) => {
      let eLenVal = 'N';
      if (equipLengthIndicator) {
        eLenVal = 'Y';
      }
      if (this.orderData.orderEquipmentRequirementDTOs.length === 0) {
        const orderEquipmentReqObj = {
          'orderEquipmentRequirement': {
            'equipmentLengthRequiredIndicator': eLenVal
          }
        };
        this.orderData.orderEquipmentRequirementDTOs.push(orderEquipmentReqObj);
      } else if (this.orderData['orderEquipmentRequirementDTOs'][0].orderEquipmentRequirement === undefined) {
        const orderEquipmentReqObj = {
          'equipmentLengthRequiredIndicator': eLenVal
        };
        this.orderData['orderEquipmentRequirementDTOs'][0].orderEquipmentRequirement = orderEquipmentReqObj;
      } else {
        this.orderData['orderEquipmentRequirementDTOs'][0].orderEquipmentRequirement.equipmentLengthRequiredIndicator = eLenVal;
      }
      this.orderService.saveData(this.orderData);
    }, (err: Error) => {
      console.log(err);
    });
    this.getEquipmentType();
    this.getEquipmentLength();
    this.getEquipmentOption();
    this.getFreightSecurement();
    this.loadProtectionMaterialHandling();
  }
  categoryTransform(items: any[], args: string): any {
    // filter items array, items which match and return true will be kept, false will be filtered out
    return items.filter(item => item.equipmentClassificationDescription.toLowerCase().indexOf(args.toLowerCase()) !== -1);
  }
  equipListTransform(items: any[], args: string): any {
    // filter items array, items which match and return true will be kept, false will be filtered out
    return items.filter(item => item.associatedDescription.toLowerCase().indexOf(args.toLowerCase()) !== -1);
  }
  frameProtectionSpecificationOrderDTO(obj) {
    /*obj.equipmentRequirementType.equipmentRequirementTypeCode,
    obj.equipmentRequirementType.equipmentRequirementTypeDescription,*/
    const equipSpecObj = {
      'equipmentRequirementSpecificationAssociationID': obj.equipmentRequirementSpecificationAssociationID,
      'equipmentRequirementSpecificationCode': obj.equipmentRequirementSpecification.equipmentRequirementSpecificationCode,
      'equipmentRequirementSpecificationDescription': obj.equipmentRequirementSpecification.equipmentRequirementSpecificationDescription,
      'equipmentRequirementSpecificationDetail': [{
        'detailDescription': null,
        'id': 1
      }],
      'equipmentRequirementTypeCode': obj.equipmentRequirementType.equipmentRequirementTypeCode,
      'equipmentRequirementTypeDescription': obj.equipmentRequirementType.equipmentRequirementTypeDescription
      /*'orderEquipmentRequirementSpecificationAssociationID': 0 // pend*/
    };
    if (this.orderData.orderEquipmentRequirementDTOs === undefined) {
      this.orderData.orderEquipmentRequirementDTOs = [];
    }
    const eReq = this.orderData.orderEquipmentRequirementDTOs;
    if (eReq.length === 0) {
      const eqObj = {
        'orderEquipmentRequirementSpecificationAssociationDTOs': [equipSpecObj]
      };
      eReq.push(eqObj);
    } else if (eReq[0].orderEquipmentRequirementSpecificationAssociationDTOs === undefined) {
      let eAso = eReq[0].orderEquipmentRequirementSpecificationAssociationDTOs;
      eAso = [];
      eAso.push(equipSpecObj);
    } else {
      eReq[0].orderEquipmentRequirementSpecificationAssociationDTOs.push(equipSpecObj);
    }
    this.orderService.saveData(this.orderData);
  }
  removeProtectionSpecificationOrderDTO(obj) {
     const orderEquip = this.orderData.orderEquipmentRequirementDTOs[0];
    for (let i = 0; i < orderEquip.orderEquipmentRequirementSpecificationAssociationDTOs.length; i++) {
      const equipDesc = orderEquip.orderEquipmentRequirementSpecificationAssociationDTOs[i].equipmentRequirementSpecificationDescription;
      if (equipDesc === obj.equipmentRequirementSpecification.equipmentRequirementSpecificationDescription) {
          orderEquip.orderEquipmentRequirementSpecificationAssociationDTOs.splice(i, 1);
      }
    }
    this.orderService.saveData(this.orderData);
  }
  frameEquipSpecificationOrderDTO(obj) {
    const equipSpecObj = {
      'equipmentRequirementSpecificationAssociationID': obj.equipmentRequirementSpecificationAssociationID,
      'equipmentRequirementSpecificationCode': obj.associatedCode,
      'equipmentRequirementSpecificationDescription': obj.associatedDescription,
      'equipmentRequirementSpecificationDetail': [{
        'detailDescription': null,
        'id': 1
      }],
      'equipmentRequirementTypeCode': obj.code,
      'equipmentRequirementTypeDescription': obj.description,
      // 'orderEquipmentRequirementSpecificationAssociationID': 0 // pend
    };
    if (this.orderData.orderEquipmentRequirementDTOs === undefined) {
      this.orderData.orderEquipmentRequirementDTOs = [];
    }
    const eReq = this.orderData.orderEquipmentRequirementDTOs;
    if (eReq.length === 0) {
      const eqObj = {
        'orderEquipmentRequirementSpecificationAssociationDTOs': [equipSpecObj]
      };
      eReq.push(eqObj);
    } else if (eReq[0].orderEquipmentRequirementSpecificationAssociationDTOs === undefined) {
      eReq[0].orderEquipmentRequirementSpecificationAssociationDTOs = [];
      eReq[0].orderEquipmentRequirementSpecificationAssociationDTOs.push(equipSpecObj);
    } else {
      eReq[0].orderEquipmentRequirementSpecificationAssociationDTOs.push(equipSpecObj);
    }
    this.orderService.saveData(this.orderData);
  }
  removeEquipSpecificationOrderDTO(obj) {
     const orderEquip = this.orderData.orderEquipmentRequirementDTOs[0];
    for (let i = 0; i < orderEquip.orderEquipmentRequirementSpecificationAssociationDTOs.length; i++) {
      const equipDesc = orderEquip.orderEquipmentRequirementSpecificationAssociationDTOs[i].equipmentRequirementSpecificationDescription;
      if (equipDesc === obj.associatedDescription) {
          orderEquip.orderEquipmentRequirementSpecificationAssociationDTOs.splice(i, 1);
      }
    }
    this.orderService.saveData(this.orderData);
  }
  public frameFeatureSpecificationOrderDTO(featureObj) {
     const eqFtObj = {
      'equipmentCategoryClassificationTypeFeatureAssociationID': featureObj.equipmentClassificationTypeFeatureAssociationID,
      'equipmentFeatureCode': featureObj.associatedCode,
      'equipmentFeatureDescription': featureObj.associatedDescription
      /*'orderEquipmentRequirementFeatureAssociationID': 0 // pend*/
    };
    if (this.orderData.orderEquipmentRequirementDTOs === undefined) {
      this.orderData.orderEquipmentRequirementDTOs = [];
    }
    const eFt = this.orderData.orderEquipmentRequirementDTOs;
    if (eFt.length === 0) {
      const eqObj = {
        'orderEquipmentRequirementFeatureAssociationDTOs': [eqFtObj]
      };
      eFt.push(eqObj);
    } else if (eFt[0].orderEquipmentRequirementFeatureAssociationDTOs === undefined) {
      eFt[0].orderEquipmentRequirementFeatureAssociationDTOs = [];
      eFt[0].orderEquipmentRequirementFeatureAssociationDTOs.push(eqFtObj);
    } else {
      eFt[0].orderEquipmentRequirementFeatureAssociationDTOs.push(eqFtObj);
    }
    this.orderService.saveData(this.orderData);
  }
  public getOrder() {
    this.subscription = this.orderService.getData().subscribe(sharedOrderData => {
      this.orderData = sharedOrderData;
      if (this.orderData !== 'undefined' || this.orderData.length !== 0) {
        this.serviceOfferingValue = this.orderData.serviceOfferingCode;
        this.financeBUValue = this.orderData.financeBusinessUnitCode;
      }
      this.getEquipmentCategory();
      this.getEquipmentType();
    });
  }
  public onRemoveTrailerNumber(value: any): void {
  }
  public onTypeTrailerNumber(selectedNumber: any): void {
    if (selectedNumber !== undefined && selectedNumber.length > 5) {
      this.loadTrailerPrefixByNumber(selectedNumber);
    }
  }
  public onRemovePrefix(value: any): void {
  }
  public onTypePrefix(selectedPrefix: any): void {
    if (selectedPrefix !== undefined && selectedPrefix.length > 3) {
      this.loadTrailerNumberByPrefix(selectedPrefix);
    }
  }
  public refreshValue(value: any): void {
    this.value = value;
  }
}
