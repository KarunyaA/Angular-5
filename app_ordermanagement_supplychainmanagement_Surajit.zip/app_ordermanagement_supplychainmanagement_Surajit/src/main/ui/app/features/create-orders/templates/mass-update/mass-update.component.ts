import { Component, OnInit } from '@angular/core';
import { TemplateService } from './../template.service';
@Component({
  selector: 'app-mass-update',
  templateUrl: './mass-update.component.html',
  styleUrls: ['./mass-update.component.scss']
})
export class MassUpdateComponent implements OnInit {

  constructor( public ts: TemplateService ) { }

  ngOnInit() {
    console.log('Tmui Before: ' + this.ts.testVar);
    this.ts.testVar = 'working';
    console.log('Tmui After: ' + this.ts.testVar);
  }

}
