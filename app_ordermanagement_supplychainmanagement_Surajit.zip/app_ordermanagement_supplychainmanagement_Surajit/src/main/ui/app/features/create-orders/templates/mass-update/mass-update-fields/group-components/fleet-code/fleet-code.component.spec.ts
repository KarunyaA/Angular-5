import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FleetCodeComponent } from './fleet-code.component';

describe('FleetCodeComponent', () => {
  let component: FleetCodeComponent;
  let fixture: ComponentFixture<FleetCodeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FleetCodeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FleetCodeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
