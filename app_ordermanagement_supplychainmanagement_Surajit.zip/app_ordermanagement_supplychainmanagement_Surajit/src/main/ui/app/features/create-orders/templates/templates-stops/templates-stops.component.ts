import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { JBHGlobals } from './../../../../app.service';
import { OrderService } from './../../orders/order.service';
import { OrderFormBuilder } from '../../orders/order-form-builder.service';

@Component({
  selector: 'app-add-stops',
  templateUrl: './templates-stops.component.html',
  styleUrls: ['./templates-stops.component.scss']
})
export class TemplatesStopsComponent implements OnInit {

    @ViewChild('stopChild') stopChild: any;
    errorMessage: string;
    subscription: any;
    orderData: any;
    public orderID: any;
    public stopReason: any;
    public debounceValue: number;
    public status: any = {
        isFirstOpen: true,
        isOpen: false
    };
    public firstStopOpened = false;
    public stopData: any;
    public requestedAppts: any;
    public scheduledAppts: any;
    public businessUnitCode: string[] = ['DCS', 'ICS'];
    public serviceOfferingCode: string[] = ['FMS', 'LTL'];
    public orderTypeCode: string[] = ['standard', 'return', 'other'];
    public oneAtATime = true;
    public stopDataLoaded = false;
    public businessUnit: boolean;
    public serviceOffering: boolean;
    public orderType: boolean;
    public stopDetails: any;
    public activeStop: any;
    public stopResequenceList: any[] = [];
    public stopResequenceMockList: any[] = [];
    public stopDetailsChange = true;
    public stopSaveActionSuccess = true;

    constructor(public orderFormBuilder: OrderFormBuilder,
        public route: ActivatedRoute,
        public jbhGlobals: JBHGlobals,
        public orderService: OrderService) {}

    ngOnInit() {
        this.loadOrderData();
        this.debounceValue = this.jbhGlobals.settings.debounce;
    }

    public addStopList() {
        if (this.stopResequenceList.length === 1) {
            this.stopResequenceList.push({
                stop: {
                    stopID: null,
                    stopSequenceNumber: 2
                }
            });
        } else if (this.stopResequenceList.length === 0) {
            this.stopResequenceList.push({
                stop: {
                    stopID: null,
                    stopSequenceNumber: 1
                }
            });
            this.stopResequenceList.push({
                stop: {
                    stopID: null,
                    stopSequenceNumber: 2
                }
            });
        }
    }

    public getResequenceList() {
        let orderId: any;
        orderId = this.orderID + '/stops';
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getstopresequencelist + orderId).subscribe(data => {
            if (!this.jbhGlobals.utils.isEmpty(data)) {
                this.addStopList();
            } else if (this.jbhGlobals.utils.isEmpty(data)) {
                this.stopResequenceList = [];
                this.addStopList();
            }
        });
    }

    public loadOrderData() {
        this.orderService.getData().subscribe(sharedOrderData => {
            if (!this.jbhGlobals.utils.isEmpty(sharedOrderData)) {
                this.orderData = sharedOrderData;
                this.orderID = this.orderData.orderID;
                this.getResequenceList();
                this.businessUnit = this.isServiceOfferingExist();
                this.serviceOffering = this.isBusinessUnitExist();
                this.orderType = this.isOrderTypeExist();
            }
        });
    }

    public isBusinessUnitExist() {
        const businessUnit: string = this.orderData.financeBusinessUnitCode;
        if (!this.jbhGlobals.utils.isEmpty(businessUnit) && (this.businessUnitCode.indexOf(businessUnit) !== -1)) {
            return true;
        } else {
            return false;
        }
    }

    public isServiceOfferingExist() {
        const serviceOffering: string = this.orderData.serviceOfferingCode;
        if (!this.jbhGlobals.utils.isEmpty(serviceOffering) && (this.serviceOfferingCode.indexOf(serviceOffering) !== -1)) {
            return true;
        } else {
            return false;
        }
    }

    public isOrderTypeExist() {
        const orderType: string = this.orderData.orderTypeCode;
        if (!this.jbhGlobals.utils.isEmpty(orderType) && (this.orderTypeCode.indexOf(orderType) !== -1)) {
            return true;
        } else {
            return false;
        }
    }

    public addStopDetails(stopForm) {
        this.jbhGlobals.apiService.addData(this.jbhGlobals.endpoints.order.crudStopDetails, stopForm).subscribe(stopData => {
            if (!this.jbhGlobals.utils.isEmpty(stopData)) {
                this.jbhGlobals.logger.info('Stops Added Successfully');
            }
        });
    }

    public updateStopDetails(stopId, stopForm) {
        this.jbhGlobals.apiService.updateData(this.jbhGlobals.endpoints.order.crudStopDetails + stopId, stopForm).subscribe(stopData => {
            if (!this.jbhGlobals.utils.isEmpty(stopData)) {
                this.jbhGlobals.logger.info('Stops Updated Successfully');
            }
        });
    }

    public getFistStop(stopId: number, group: any, stopPosition: number) {
        if (stopPosition === 0 && !this.firstStopOpened) {
            this.activeStop = group;
            group.isOpen = true;
            this.firstStopOpened = true;
        }
        return false;
    }

    public onStopCollpse(event, stopId: number, group: any, stopPostion: number) {
        if (this.activeStop !== null && this.stopChild) {
            if (this.stopChild.stopForm.touched && this.stopChild.stopForm.dirty) {
                if (!this.jbhGlobals.utils.isEmpty(this.stopChild.stopForm.value.stopID)) {
                    const stopID = '/' + this.stopChild.stopForm.value.stopID;
                    this.updateStopDetails(stopID, this.stopChild.stopForm.value);
                } else {
                    this.addStopDetails(this.stopChild.stopForm.value);
                }
                if (!this.stopSaveActionSuccess) {
                    alert('Error');
                    event.stopPropagation();
                    return;
                }
            }
            this.activeStop = null;
        }
        if (!group.isOpen) {
            this.activeStop = group;
        }
    }

    public preventCollpase(event) {
        event.stopPropagation();
    }

    public addAppointment(appt: number) {
        if (appt === 0) {
            this.orderData.stopDTOs.stop.appointment.push(this.orderFormBuilder.requestedAppointments());
        }
        if (appt === 1) {
            this.orderData.stopDTOs.stop.appointment.push(this.orderFormBuilder.scheduledAppointments());
        }
    }

    public removeStop(event, indx: number, stopId: number) {
        event.stopPropagation();
        this.stopResequenceList.splice(indx, 1);
        if (!this.jbhGlobals.utils.isEmpty(stopId)) {
            const stopID = '/' + stopId;
            this.jbhGlobals.apiService.removeData(this.jbhGlobals.endpoints.order.crudStopDetails + stopID).subscribe(chargeData => {
                this.jbhGlobals.logger.info('Stop Deleted');
            });
        }
    }

    public initAddStopDetails(indx: number) {
        const stopCtrl = {
            'stopID': '',
            'stopSequenceNumber': ''
        };
        this.stopResequenceList.splice((indx + 1), 0, stopCtrl);
    }

    onSubmit(val) {
        console.log(val.value);
    }
}
