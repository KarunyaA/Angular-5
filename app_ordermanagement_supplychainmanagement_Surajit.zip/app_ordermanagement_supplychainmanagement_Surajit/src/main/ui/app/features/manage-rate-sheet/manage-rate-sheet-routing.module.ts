import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ManageRateSheetComponent } from './manage-rate-sheet.component';

const routes: Routes = [{
  path: '',
  component: ManageRateSheetComponent
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ManageRateSheetRoutingModule { }
