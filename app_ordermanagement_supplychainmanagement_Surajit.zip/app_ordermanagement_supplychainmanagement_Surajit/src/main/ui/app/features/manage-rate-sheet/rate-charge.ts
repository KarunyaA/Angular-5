export class RateCharge {

  public level: string;
  public chargeCode: string;
  public quantity: string;
  public amount: string;

  // constructor(public level: string,public chargeCode: string,public quantity: string,public amount: string) {  	  }
}
