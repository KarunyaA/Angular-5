import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageRateSheetComponent } from './manage-rate-sheet.component';

describe('ManageRateSheetComponent', () => {
  let component: ManageRateSheetComponent;
  let fixture: ComponentFixture<ManageRateSheetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ManageRateSheetComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageRateSheetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
