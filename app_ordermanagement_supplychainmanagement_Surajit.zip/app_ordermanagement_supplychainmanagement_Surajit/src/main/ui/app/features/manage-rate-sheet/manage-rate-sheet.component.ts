import { Http } from '@angular/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { RateCharge } from './rate-charge';
// import { JBHGlobals } from '../../app.service';
import { QuickRateService } from '../shipping-options/quick-rate.service';

@Component({
  selector: 'app-manage-rate-sheet',
  templateUrl: './manage-rate-sheet.component.html',
  styleUrls: ['./manage-rate-sheet.component.scss'],
  providers: [QuickRateService]
})

export class ManageRateSheetComponent implements OnInit {

  pageTitle: string;
  addChargeForm: any;
  sendToCustomerForm: any;
  billingInstructionForm: any;
  rateInfoRow = [];
  modalTitle: string;
  isModel: boolean;
  delModel = new RateCharge();

  public rateOrderDeails = {
    'OrderId': '',
    'OrderStatus': '',
    'Truck': '',
    'Trailer': '',
    'billAddress': '',
    'billPhone': '',
    'Pickup': '',
    'OrgAppointmentNo': '',
    'OrgAddress': '',
    'OrgPersonName': '',
    'Delivery': '',
    'DesAppointmentNo': '',
    'DesAddress': '',
    'DesPersonName': '',
    'IntermediateStops': '',
    'OrderOwner': '',
    'OrderCreator': '',
    'RateType': '',
    'RateStatus': '',
    'RateContact': '',
    'PublicationSection': '',
    'PublicationItem': '',
    'totalBillMilles': ''
  };

  @ViewChild('staticModal') public staticModal: ModalDirective;
  @ViewChild('deleteChargeModal') public deleteChargeModal: ModalDirective;
  @ViewChild('sidebarLeft') leftsideBar;
  @ViewChild('centerGrid') centerGrid;
  @ViewChild('sidebarRight') rightsideBar;
  @ViewChild('sidebarRightBillBlock') rightsideBarBillBlock;
  rateInfocolumns = [{
    name: 'Level',
    prop: 'Level'
  }, {
    name: 'Charge',
    prop: 'Charge'
  }, {
    name: 'UnitRate',
    prop: 'UnitRate'
  }, {
    name: 'Quantity',
    prop: 'Quantity'
  }, {
    name: 'Amount',
    prop: 'Amount'
  }, {
    name: 'Commodity',
    prop: 'Commodity'
  }, {
    name: 'Class',
    prop: 'Class'
  }, {
    name: 'RatingClass',
    prop: 'RatingClass'
  }, {
    name: 'Weight',
    prop: 'Weight'
  }, {
    name: 'Rate',
    prop: 'Rate'
  }, {
    name: 'RateType',
    prop: 'RateType'
  }, {
    name: 'Total',
    prop: 'Total'
  }, {
    name: 'Handling Type',
    prop: 'HandlingType'
  }, {
    name: 'Handling Quantity',
    prop: 'HandlingQuantity'
  }];

  constructor(public http: Http, public fb: FormBuilder, public quickService: QuickRateService) {
    this.pageTitle = 'Rate Sheet';
    this.modalTitle = 'Add';
    this.isModel = false;
  }


  public popOverOnBlur(pop, popup) { }

  public onActivate(event) {
    console.log('Activate Event', event);
  }
  public onSelect({ selected }) {
    // console.log({selected});
  }
  public showModel() {
    console.log(this.rateInfocolumns);
  }
  ngOnInit() {

    this.quickService.fetch(this.quickService.jbhGlobals.endpoints.manageratesheets.rateInfoUrl, (data) => {
      this.rateInfoRow = data;
    });
    this.quickService.fetch(this.quickService.jbhGlobals.endpoints.manageratesheets.rateOrderDetailsUrl, (data) => {
      this.rateOrderDeails = data;
    });

    this.createForm();
    this.setUpKeyboardShortcuts();
  }
  public setUpKeyboardShortcuts() {
    this.quickService.jbhGlobals.shortkeys.getData().subscribe(data => {

      switch (data.keyCode) {
        case 'alt+1':
          this.leftsideBar.nativeElement.focus();
          break;

        case 'alt+2':
          this.centerGrid.nativeElement.focus();
          break;

        case 'alt+3':
          this.rightsideBar.nativeElement.focus();
          break;

        case 'alt+4':
          this.rightsideBarBillBlock.nativeElement.focus();
          break;

        default:
          break;
      }
    });
  }
  createForm() {
    this.addChargeForm = this.fb.group({
      levelField: ['', Validators.required],
      chargeCode: ['', Validators.required],
      unitRate: ['', Validators.required],
      quantity: ['', Validators.required],
      authNumber: ['', Validators.required],
      authBy: ['', Validators.required]
    });
    this.sendToCustomerForm = this.fb.group({
      contact: ['', Validators.required],
      feedback: ''
    });
    this.billingInstructionForm = this.fb.group({
      tagOrder: ['', Validators.required],
      comment: ['', Validators.required]
    });
    console.log(this.billingInstructionForm);
  }
  submitChargeForm(value: any): void {
    if (value.valid) {
      console.log('Submit Form Data: ');
      console.log(value);
    }
  }
  submitTagForm(value: any): void {
    if (value.valid) {
      console.log(value);
      this.billingInstructionForm.reset();
    }
  }
  onAddChargeClick(event) {
    this.modalTitle = 'Add';
    this.addChargeForm.reset();
    this.staticModal.show();
  }
  onEditMenuClick(event, pop, row) {
    pop.hide();
    this.modalTitle = 'Edit';
    this.addChargeForm = this.fb.group({
      levelField: row.Level,
      chargeCode: row.Charge,
      unitRate: row.UnitRate,
      quantity: row.Quantity,
      authNumber: '',
      authBy: ''
    });
    this.staticModal.show();
  }
  onDeleteMenuClick(event, pop, row) {
    pop.hide();
    this.delModel.level = row.Level;
    this.delModel.chargeCode = row.Charge;
    this.delModel.quantity = row.Quantity;
    this.delModel.amount = row.Amount;
    this.deleteChargeModal.show();
  }

}

