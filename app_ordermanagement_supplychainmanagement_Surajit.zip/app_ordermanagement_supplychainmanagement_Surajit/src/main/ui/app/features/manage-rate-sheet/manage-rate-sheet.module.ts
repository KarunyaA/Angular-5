import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ManageRateSheetRoutingModule } from './manage-rate-sheet-routing.module';
import { ManageRateSheetComponent } from './manage-rate-sheet.component';
import { JBHDataTableModule } from '../../shared/jbh-data-table/jbh-data-table.module';
import { PopoverModule, ModalModule, BsDropdownModule } from 'ngx-bootstrap';
import { JbhUtilsModule } from '../../shared/jbh-utils/jbh-utils.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule, ReactiveFormsModule,
    PopoverModule.forRoot(),
    JbhUtilsModule,
    ModalModule.forRoot(),
    BsDropdownModule.forRoot(),
    ManageRateSheetRoutingModule, JBHDataTableModule
  ],
  declarations: [ManageRateSheetComponent]
})
export class ManageRateSheetModule { }
