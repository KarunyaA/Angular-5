import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-load-information',
  templateUrl: './load-information.component.html',
  styleUrls: ['./load-information.component.scss']
})
export class LoadInformationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
