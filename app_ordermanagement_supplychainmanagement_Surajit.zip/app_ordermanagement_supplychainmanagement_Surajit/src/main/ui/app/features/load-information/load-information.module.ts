import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoadInformationRoutingModule } from './load-information-routing.module';
import { LoadInformationComponent } from './load-information.component';

@NgModule({
  imports: [
    CommonModule,
    LoadInformationRoutingModule
  ],
  declarations: [LoadInformationComponent]
})
export class LoadInformationModule { }
