import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BsDropdownModule } from 'ngx-bootstrap';
import { PopoverModule } from 'ngx-bootstrap/popover';
import { ModalModule } from 'ngx-bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { OpportunityArviewRoutingModule } from './opportunity-arview-routing.module';


import { RatingModule } from 'ngx-bootstrap/rating';

import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';

import { OpportunityArviewComponent } from './opportunity-arview.component';
import { AccordionModule } from 'ngx-bootstrap/accordion';
// import { JBHGlobals } from 'app/app.service';
import { MyDatePickerModule } from 'mydatepicker';
import { JBHDataTableModule } from 'app/shared/jbh-data-table/jbh-data-table.module';
import { JbhSearchFilterModule } from '../../../shared/jbh-search-filter/jbh-search-filter.module';


@NgModule({
  imports: [
    CommonModule,
    OpportunityArviewRoutingModule,
    JBHDataTableModule,
    AccordionModule.forRoot(),
    BsDropdownModule.forRoot(),
    PopoverModule.forRoot(),
    ModalModule.forRoot(),
    MyDatePickerModule,

    RatingModule.forRoot(),
    JbhSearchFilterModule,
    PerfectScrollbarModule,
    FormsModule,
    ReactiveFormsModule




  ],
  declarations: [OpportunityArviewComponent]



})
export class OpportunityArviewModule { }
