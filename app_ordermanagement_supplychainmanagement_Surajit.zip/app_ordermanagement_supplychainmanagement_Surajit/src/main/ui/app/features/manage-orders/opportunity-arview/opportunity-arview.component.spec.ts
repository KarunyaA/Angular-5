import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OpportunityArviewComponent } from './opportunity-arview.component';

describe('OpportunityArviewComponent', () => {
  let component: OpportunityArviewComponent;
  let fixture: ComponentFixture<OpportunityArviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [OpportunityArviewComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OpportunityArviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
