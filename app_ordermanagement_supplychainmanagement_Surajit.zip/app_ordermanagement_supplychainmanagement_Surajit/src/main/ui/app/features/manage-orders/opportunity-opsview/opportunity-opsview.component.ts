import { Component, ViewChild, OnInit } from '@angular/core';
import { IMyOptions } from 'mydatepicker';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { JBHGlobals } from 'app/app.service';
import { JBHDataTableComponent } from 'app/shared/jbh-data-table/components/jbh-data-table.component';
import { ValidationService } from 'app/shared/jbh-validation/validation.service';
import { Keys } from '../../../shared/jbh-data-table/utils/keys';

@Component({
  selector: 'app-opportunity-opsview',
  templateUrl: './opportunity-opsview.component.html',
  styleUrls: ['./opportunity-opsview.component.scss']
})
export class OpportunityOpsviewComponent implements OnInit {
  @ViewChild(JBHDataTableComponent) jbhdatatable: JBHDataTableComponent;
  @ViewChild('splitViewTemplateContainer') splitViewTemplateContainer;
  rows: any[];
  selected = [];
  fleets: any[];
  count = 0;
  offset = 0;
  limit = 5;
  favUrl = '';
  singleselect = true;
  showPickup = false;
  showDelivery = false;
  showRate = false;
  yesSelected = false;
  opsViewForm: FormGroup;
  selectedcount = 0;
  val = 1;
  val2 = 0.7;
  flag = 0;
  filterTitle = 'Filter By';
  rate: any = 3;
  orderSearchTypeList = ['fleet1', 'fleet2', 'fleet3'];

  public FilterList: any[] = [
    //  {
    //   'index': 0,
    //   'key': 'opportunity',
    //   'title': 'Order Number',
    //   'componentType': 'lsitType',
    //   'rootVal': [],
    //   'url': 'ordernumber',




    //  },
    {
      'index': 0,
      'title': 'Origin',
      'key': 'opportunity',
      'rootVal': [],
      'componentType': 'lsitType',
      // 'url': 'origin',
      'url': 'Orgintest',

    }, {
      'index': 1,
      'key': 'opportunity',
      'title': 'Destination',
      'rootVal': [],
      'componentType': 'lsitType',
      // 'url': 'destination',
      'url': 'Orgintest',

    }, {
      'index': 2,
      'key': 'opportunity',
      'title': 'Bill To Account',
      'rootVal': [],
      'componentType': 'lsitType',
      // 'url': 'billto',
      'url': 'billAcctest',
    }, {
      'index': 3,
      'key': 'opportunity',
      'title': 'Status',
      'rootVal': [],
      'componentType': 'lsitType',
      // 'url': 'opp',
      'url': 'statustest',

    }, {
      'index': 4,
      'key': 'opportunity',
      'title': 'Opportunity Creator',
      'rootVal': [],
      'componentType': 'lsitType',
      // 'url': 'opportunitycreator',
      'url': 'orderownertest',

    }, {
      'index': 5,
      'key': 'opportunity',
      'title': 'Order Owener',
      'componentType': 'lsitType',
      'rootVal': [],
      // 'url': 'orderowner',
      'url': 'orderownertest',


    }];

  columns = [{
    name: 'Status',
    prop: 'Status',
    sortable: false,
    canAutoResize: false,
    draggable: false,
    resizeable: false,
    reorderable: false,
    frozenLeft: true,
  }, {
    name: 'Bill To Account',
    prop: 'billtoaccount',
    draggable: false,
    resizeable: false,
    reorderable: false
  }, {
    name: 'Origin',
    prop: 'origin',
    draggable: false,
    resizeable: false,
    reorderable: false
  }, {
    name: 'Destination',
    prop: 'destination',
    draggable: false,
    resizeable: false,
    reorderable: false
  }, {
    name: 'Pickup',
    prop: 'pickup',
    draggable: false,
    resizeable: false,
    reorderable: false
  }, {
    name: 'Delivery',
    prop: 'delivery',
    draggable: false,
    resizeable: false,
    reorderable: false
  }, {
    name: 'Service Offering',
    prop: 'serviceoffer',
    draggable: false,
    resizeable: false,
    reorderable: false
  }, {
    name: 'Order',
    prop: 'order',
    draggable: false,
    resizeable: false,
    reorderable: false
  }, {
    name: 'Assigned To',
    prop: 'assignto',
    draggable: false,
    resizeable: false,
    reorderable: false
  }

  ];

  /* datepicker changes */
  myDatePickerOptions: IMyOptions = {
    todayBtnTxt: 'Today',
    dateFormat: 'dd-mm-yyyy',
    firstDayOfWeek: 'mo',
    showClearDateBtn: false,
    sunHighlight: true,
    height: '34px',
    width: '115px',
    inline: false,
    // disableUntil: {year: 2016, month: 8, day: 10},
    selectionTxtFontSize: '14px'
  };
  constructor(public formBuilder: FormBuilder, public jbhGlobals: JBHGlobals) {
    this.favUrl = this.jbhGlobals.endpoints.opportunities.opsview;
    this.jbhGlobals.apiService.getData(this.favUrl).subscribe(data => {
      /*  this.rows = data[0]['opsGrid'];*/
      this.rows = data;
      console.log(this.rows);

    });

    this.opsViewForm = this.formBuilder.group({

    });
  }


  ngOnInit() {
    this.page(this.offset, this.limit);
    /* this.opsViewForm = new FormGroup({
     });*/
    this.opsViewForm = this.formBuilder.group({
      pickupDate: ['', Validators.required],
      pickupTime: ['', Validators.compose([Validators.required, ValidationService.timeValidator])],
      deliveryDate: ['', Validators.required],
      deliveryTime: ['', Validators.compose([Validators.required, ValidationService.timeValidator])],
      requestedRate: ['', Validators.compose([Validators.required, ValidationService.rateValidator])],
      commentsAR: ['', Validators.maxLength(10)],
      assignedFleet: ['', Validators.required]
    });
  }
  public addidtionalsearch() {
    if (this.flag === 0) {
      this.flag = 1;
      //  this.fliterCmpLoad=true;
      //  this.searchElasticQuery(event);
    } else {
      this.flag = 0;
    }
  }
  public changeEvent(eve) {
    console.log('obk', eve);
  }
  public clickReset(index) {
    console.log('obk', index);
  }

  acceptOpp(opsViewForm) {
     console.log('Accept Form', opsViewForm);
  }

  conditionAccept(opsViewForm) {
    console.log(opsViewForm);
    if (this.isDateValid(this.opsViewForm.controls['pickupDate'], this.opsViewForm.controls['deliveryDate']) < 0) {
       this.jbhGlobals.notifications.alert('Error', 'Deliver date to be greater than Pickup date');
    } else {
      this.jbhGlobals.notifications.success('Conditionally Accepted');
    }
  }

  rejectOpp(opsViewForm) {
    console.log(opsViewForm);
  }

  isDateValid(pickup, delivery) {
    if (!!pickup.value && !!delivery.value) {
      console.log(delivery.value.jsdate.getTime(), pickup.value.jsdate.getTime());
      return delivery.value.jsdate.getTime() - pickup.value.jsdate.getTime();
    }
  }

  page(offset, limit) {
    this.jbhGlobals.apiService.getData(this.favUrl).subscribe(data => {
      /* this.count = data[0]['opsGrid'].length;*/
      this.count = data.length;

      const start = offset * limit;
      const end = start + limit;
      const rows = [...this.rows];

      for (let i = start; i < end; i++) {
        /*rows[i] = data[0]['opsGrid'][i];*/
        rows[i] = data[i];
      }

      this.rows = rows;
      console.log('Page Results', start, end, rows);
    });
  }

  onPage(event) {
    console.log('Page Event', event);
    this.page(event.offset, event.limit);
  }


  onActivate(event) {
    console.log('Activate Event', this.selected, event);
    if (event.type === 'click' && event.column.name !== 'checkboxedCol' && this.selected.length <= 1) {
      this.selected.splice(0, this.selected.length);
      this.selected.push(event.row);
      this.onCleanup();
      this.setUpKeyboardShortcuts();
      this.jbhdatatable.isDataTableDetailOpen = true;
    } else if (event.type === 'click' && event.column.name === 'checkboxedCol') {

      this.jbhdatatable.isDataTableDetailOpen = false;
      this.onCleanup();
    }
  }

  onSelect({ selected }) {
    if (selected) {
      if (selected.length > 1) {
        this.singleselect = false;
      } else {
        this.singleselect = true;
      }
    }
    console.log('Select Event', selected, this.selected);
  }

  onSelectPrefix(value): void {
    // console.log(value);
  }

  onRemovePrefix(value: any): void {
    // console.log(value);
  }


  onTypePrefix(event): void {
    // console.log(event);
  }

  refreshValue(value: any): void {
    // console.log(value);
  }

  onDataPrefix(value) {
    console.log(value);
  }

  setUpKeyboardShortcuts() {
    this.jbhGlobals.shortkeys.getData().subscribe(data => {
      if (data.keyCode === 'ctrl+!' && this.jbhdatatable.isDataTableDetailOpen) {
        this.jbhdatatable.SplitViewTemplate.nativeElement.querySelector('.Conditionbtn').focus();
      } else if (data.keyCode === Keys.escape) {
      }
    });
  }
  /* Cleanup code goes here */
  onCleanup() {
    console.log('Cleanup Event');
    this.yesSelected = false;
    this.showPickup = false;
    this.showDelivery = false;
    this.showRate = false;
    this.opsViewForm.reset();
  }

  resetPickup(event) {
    if (!event.target.checked) {
      this.opsViewForm.controls['pickupDate'].reset();
      this.opsViewForm.controls['pickupTime'].reset();
    }
  }

  resetDelivery(event) {
    if (!event.target.checked) {
      this.opsViewForm.controls['deliveryDate'].reset();
      this.opsViewForm.controls['deliveryTime'].reset();
    }
  }

  resetRate(event) {
    if (!event.target.checked) {
      this.opsViewForm.controls['requestedRate'].reset();
    }
  }

  }
