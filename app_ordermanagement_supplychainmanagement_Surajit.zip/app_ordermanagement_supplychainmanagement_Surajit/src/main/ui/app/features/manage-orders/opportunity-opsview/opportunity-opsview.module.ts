import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { MyDatePickerModule } from 'mydatepicker';
import { BsDropdownModule } from 'ngx-bootstrap';
import { PopoverModule } from 'ngx-bootstrap/popover';
import { TypeaheadModule } from 'ngx-bootstrap';
import { ModalModule } from 'ngx-bootstrap';
import { SelectModule } from '../../../shared/select';

import { OpportunityOpsviewRoutingModule } from './opportunity-opsview-routing.module';
import { OpportunityOpsviewComponent } from './opportunity-opsview.component';
import { JBHDataTableModule } from 'app/shared/jbh-data-table/jbh-data-table.module';

import { JbhSearchFilterModule } from '../../../shared/jbh-search-filter/jbh-search-filter.module';

import { JbhUtilsModule } from 'app/shared/jbh-utils/jbh-utils.module';
import { RatingModule } from 'ngx-bootstrap/rating';

@NgModule({
  imports: [
    CommonModule,
    JBHDataTableModule,
    FormsModule,
    ReactiveFormsModule,
    OpportunityOpsviewRoutingModule,
    JbhSearchFilterModule,
    AccordionModule.forRoot(),
    MyDatePickerModule,
    RatingModule.forRoot(),
    BsDropdownModule.forRoot(),
    PopoverModule.forRoot(),
    TypeaheadModule.forRoot(),
    ModalModule.forRoot(),
    JbhUtilsModule,
    SelectModule
  ],
  declarations: [OpportunityOpsviewComponent]
})
export class OpportunityOpsviewModule { }
