import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ManageOrdersComponent } from './manage-orders.component';

const routes: Routes = [
  {
    path: '',
    component: ManageOrdersComponent
  },
  {
    path: 'opportunity-ar',
    loadChildren: 'app/features/manage-orders/opportunity-arview/opportunity-arview.module#OpportunityArviewModule'
  },
  {
    path: 'opportunity-ops',
    loadChildren: 'app/features/manage-orders/opportunity-opsview/opportunity-opsview.module#OpportunityOpsviewModule'
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: []
})
export class ManageOrdersRoutingModule { }
