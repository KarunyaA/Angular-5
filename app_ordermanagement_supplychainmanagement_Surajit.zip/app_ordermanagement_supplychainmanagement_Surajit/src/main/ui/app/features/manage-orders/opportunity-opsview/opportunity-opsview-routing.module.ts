import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { OpportunityOpsviewComponent } from './opportunity-opsview.component';

const routes: Routes = [
  {
    path: '',
    component: OpportunityOpsviewComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: []
})
export class OpportunityOpsviewRoutingModule { }
