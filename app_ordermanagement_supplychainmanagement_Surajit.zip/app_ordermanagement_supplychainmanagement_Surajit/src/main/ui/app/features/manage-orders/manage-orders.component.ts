import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-orders',
  templateUrl: './manage-orders.component.html',
  styleUrls: ['./manage-orders.component.scss']
})

export class ManageOrdersComponent implements OnInit {

  orderType: string;

  constructor() { }

  ngOnInit() {
    this.orderType = window.location.pathname.split('/')[2];
  }

}
