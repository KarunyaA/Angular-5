

export let ManageOrdersRoutes = [
  {
    path: 'opportunity-ar',
    loadChildren: 'app/features/manage-orders/opportunity-arview/opportunity-arview.module#OpportunityArviewModule',

    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Opportunity ARView',
      pathIcon: `fa fa-building`,
      order: 2
    }
  }, {
    path: 'opportunity-ops',
    loadChildren: 'app/features/manage-orders/opportunity-opsview/opportunity-opsview.module#OpportunityOpsviewModule',

    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Opportunity-OPSView',
      pathIcon: `fa fa-building`,
      order: 2
    }
  }, {
    path: 'active',
    loadChildren: 'app/features/manage-orders/manage-orders.module#ManageOrdersModule',

    data: {
      createSidebarEntry: true,
      queryParams: { id: 1234 },
      pathDisplayText: 'Active Orders',
      pathIcon: `fa fa-building`,
      order: 2
    }
  }, {
    path: 'planned',
    loadChildren: 'app/features/manage-orders/manage-orders.module#ManageOrdersModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Planned Orders',
      pathIcon: `fa fa-building`,
      order: 2
    }
  }, {
    path: 'requested',
    loadChildren: 'app/features/manage-orders/manage-orders.module#ManageOrdersModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Requested Orders',
      pathIcon: `fa fa-building`,
      order: 2
    }
  }, {
    path: 'unscheduled',
    loadChildren: 'app/features/manage-orders/manage-orders.module#ManageOrdersModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'UnScheduled Orders',
      pathIcon: `fa fa-building`,
      order: 2
    }
  }
];

