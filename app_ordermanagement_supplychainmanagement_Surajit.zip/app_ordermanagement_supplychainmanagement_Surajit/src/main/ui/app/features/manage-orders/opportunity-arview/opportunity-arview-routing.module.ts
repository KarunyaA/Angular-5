import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { OpportunityArviewComponent } from './opportunity-arview.component';

const routes: Routes = [
  {
    path: '',
    component: OpportunityArviewComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: []
})
export class OpportunityArviewRoutingModule { }
