
import { Component, ViewChild, OnInit } from '@angular/core';
import { IMyOptions } from 'mydatepicker';
import { FormBuilder, FormGroup } from '@angular/forms';

import { JBHGlobals } from 'app/app.service';
import { JBHDataTableComponent } from 'app/shared/jbh-data-table/components/jbh-data-table.component';
import { Keys } from '../../../shared/jbh-data-table/utils/keys';
@Component({
  selector: 'app-opportunity-arview',
  templateUrl: './opportunity-arview.component.html',
  styleUrls: ['./opportunity-arview.component.scss']

})
export class OpportunityArviewComponent implements OnInit {

  rows = [];
  selected = [];
  count = 0;
  offset = 0;
  limit = 5;
  favUrl = '';
  arViewForm: FormGroup;
  selectedcount = 0;
  val = 1;
  val2 = 0.7;
  flag = 0;
  conditionwrapper = false;
  filterTitle = 'Filter By';
  @ViewChild(JBHDataTableComponent) jbhdatatable: JBHDataTableComponent;
  @ViewChild('splitViewTemplateContainer') splitViewTemplateContainer;

  public FilterList: any[] = [
    //  {
    //   'index': 0,
    //   'key': 'opportunity',
    //   'title': 'Order Number',
    //   'componentType': 'lsitType',
    //   'rootVal': [],
    //   'url': 'ordernumber',



    //  },
    {
      'index': 0,
      'title': 'Origin',
      'key': 'opportunity',
      'rootVal': [],
      'componentType': 'lsitType',
      // 'url': 'origin',
      'url': 'Orgintest',


    }, {
      'index': 1,
      'key': 'opportunity',
      'title': 'Destination',
      'rootVal': [],
      'componentType': 'lsitType',
      // 'url': 'destination',
      'url': 'Orgintest',

    }, {
      'index': 2,
      'key': 'opportunity',
      'title': 'Bill To Account',
      'rootVal': [],
      'componentType': 'lsitType',
      // 'url': 'billto',
      'url': 'billAcctest',

    }, {
      'index': 3,
      'key': 'opportunity',
      'title': 'Status',
      'rootVal': [],
      'componentType': 'lsitType',
      'url': 'statustest',

    }, {
      'index': 4,
      'key': 'opportunity',
      'title': 'Opportunity Creator',
      'rootVal': [],
      'componentType': 'lsitType',
      'url': 'orderownertest',

    }, {
      'index': 5,
      'key': 'opportunity',
      'title': 'Order Owener',
      'componentType': 'lsitType',
      'rootVal': [],
      'url': 'orderownertest',


    }];
  columns = [{
    name: 'Status',
    prop: 'Status',
    sortable: false,
    canAutoResize: false,
    draggable: false,
    resizeable: false,
    reorderable: false,
    frozenLeft: true,
  }, {
    name: 'Bill To Account',
    prop: 'billtoaccount',
    draggable: false,
    resizeable: false,
    reorderable: false
  }, {
    name: 'Origin',
    prop: 'origin',
    draggable: false,
    resizeable: false,
    reorderable: false
  }, {
    name: 'Destination',
    prop: 'destination',
    draggable: false,
    resizeable: false,
    reorderable: false
  }, {
    name: 'Pickup',
    prop: 'pickup',
    draggable: false,
    resizeable: false,
    reorderable: false
  }, {
    name: 'Delivery',
    prop: 'delivery',
    draggable: false,
    resizeable: false,
    reorderable: false
  }, {
    name: 'Service Offering',
    prop: 'serviceoffer',
    draggable: false,
    resizeable: false,
    reorderable: false
  }, {
    name: 'Order',
    prop: 'order',
    draggable: false,
    resizeable: false,
    reorderable: false
  }, {
    name: 'Assigned To',
    prop: 'assignto',
    draggable: false,
    resizeable: false,
    reorderable: false
  }

  ];

  //  public gridMenu = [{
  //   'name': 'Pop up 1',
  //   'id': 'popup1'
  //  }, {
  //   'name': 'Pop up 2',
  //   'id': 'popup2'
  //  }, {
  //   'name': 'Pop up 3',
  //   'id': 'popup3'
  //  }];
  myDatePickerOptions: IMyOptions = {
    todayBtnTxt: 'Today',
    dateFormat: 'dd-mm-yyyy',
    firstDayOfWeek: 'mo',
    showClearDateBtn: false,
    sunHighlight: true,
    height: '32px',
    width: '210px',
    inline: false,
    // disableUntil: {year: 2016, month: 8, day: 10},
    selectionTxtFontSize: '14px'
  };
  public addidtionalsearch() {
    if (this.flag === 0) {
      this.flag = 1;
      //  this.fliterCmpLoad=true;
      //  this.searchElasticQuery(event);
    } else {
      this.flag = 0;
    }
  }
  public changeEvent(eve) {
    console.log('obk', eve);
  }
  public clickReset(index) {
    console.log('obk', index);
  }
  constructor(public formBuilder: FormBuilder, public jbhGlobals: JBHGlobals) {
    this.favUrl = this.jbhGlobals.endpoints.opportunities.Arview;
    this.jbhGlobals.apiService.getData(this.favUrl).subscribe(data => {
      this.rows = data;

    });


  }


  ngOnInit() {
    this.page(this.offset, this.limit);
    this.arViewForm = this.formBuilder.group({

    });
  }

  page(offset, limit) {


    this.jbhGlobals.apiService.getData(this.favUrl).subscribe(data => {
      this.count = data.length;

      const start = offset * limit;
      const end = start + limit;
      const rows = [...this.rows];

      for (let i = start; i < end; i++) {
        rows[i] = data[i];
      }

      this.rows = rows;
      console.log('Page Results', start, end, rows);
    });
  }

  onPage(event) {
    console.log('Page Event', event);
    this.page(event.offset, event.limit);
  }


  onActivate(event) {
    if (event.row.opportunityStatus === 'Conditionally Accepted') {
      this.conditionwrapper = true;
    } else {
      this.conditionwrapper = false;
    }
    console.log('Activate Event', event);
    this.jbhdatatable.isDataTableDetailOpen = true;
    this.selected.splice(0, this.selected.length);
    this.selected.push(event.row);
    this.setUpKeyboardShortcuts();
  }

  onSelect({ selected }) {
    console.log('Select Event', selected, this.selected);
  }
  setUpKeyboardShortcuts() {
    this.jbhGlobals.shortkeys.getData().subscribe(data => {
      if (data.keyCode === 'ctrl+!' && this.jbhdatatable.isDataTableDetailOpen) {
        this.jbhdatatable.SplitViewTemplate.nativeElement.querySelector('.Conditionbtn').focus();
      } else if ((data.keyCode === Keys.escape && this.jbhdatatable.isDataTableDetailOpen)
        || (data.keyCode === Keys.left && this.jbhdatatable.isDataTableDetailOpen)) {
        this.jbhdatatable.SplitViewTemplate.nativeElement.querySelector('.closekshortcut').focus();
      }
    });
  }
  /* Cleanup code goes here */
  onCleanup() {
    console.log('Cleanup Event');
  }
  cancelOPPClick() {
    const canceloppURL = this.jbhGlobals.endpoints.opportunities.cancelopportunities;
    this.jbhGlobals.apiService.patchData(canceloppURL, {}).subscribe(data => {
      console.log('cancelopportunities', data);

    });
  }

}
