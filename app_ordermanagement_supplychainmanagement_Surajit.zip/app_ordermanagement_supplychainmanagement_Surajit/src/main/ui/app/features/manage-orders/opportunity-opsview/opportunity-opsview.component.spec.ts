import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OpportunityOpsviewComponent } from './opportunity-opsview.component';

describe('OpportunityOpsviewComponent', () => {
  let component: OpportunityOpsviewComponent;
  let fixture: ComponentFixture<OpportunityOpsviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [OpportunityOpsviewComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OpportunityOpsviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
