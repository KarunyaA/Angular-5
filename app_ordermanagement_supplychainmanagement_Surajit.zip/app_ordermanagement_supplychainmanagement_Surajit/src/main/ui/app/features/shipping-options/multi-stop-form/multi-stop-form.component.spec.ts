import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MultiStopFormComponent } from './multi-stop-form.component';

describe('MultiStopFormComponent', () => {
  let component: MultiStopFormComponent;
  let fixture: ComponentFixture<MultiStopFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MultiStopFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MultiStopFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
