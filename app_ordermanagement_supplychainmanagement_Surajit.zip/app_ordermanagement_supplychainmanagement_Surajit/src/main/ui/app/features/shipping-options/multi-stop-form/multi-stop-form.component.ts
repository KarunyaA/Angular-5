import {
  Component,
  OnInit
} from '@angular/core';
import {
  FormBuilder,
  Validators
} from '@angular/forms';

@Component({
  selector: 'app-multi-stop-form',
  templateUrl: './multi-stop-form.component.html',
  styleUrls: ['../request-shipping-options/request-shipping-options.component.scss']
})
export class MultiStopFormComponent implements OnInit {
  public shipOptnsMultiStopListFlag: boolean;
  public equipType: string[];
  public wghtUnit: string[];
  public hUnit = [];
  public handleUnitQuantity = [];
  public classes = [];
  public wghtUnit2 = [];
  public wghtUnit3 = [];
  public show: boolean;
  public nmfc;
  public category;
  public wght: number;
  public unitWeight;
  public itemArr: any;

  multiStopForm: any;
  constructor(private fb: FormBuilder) {
    this.shipOptnsMultiStopListFlag = false;
    this.equipType = ['Equipment Type', 'A', 'B', 'C'];
    this.wghtUnit = ['lbs', 'kg', 'gm'];
    this.hUnit = ['A', 'B'];
    this.handleUnitQuantity = ['A', 'B'];
    this.classes = ['D', 'F'];
    this.wghtUnit2 = ['lbs', 'kg', 'gm'];
    this.wghtUnit3 = ['lbs', 'kg', 'gm'];
    this.show = true;
    this.nmfc = '';
    this.category = '';
    this.wght = 0;
    this.unitWeight = '';
    this.itemArr = [];
    this.multiStop();
  }
  multiStop() {
    this.multiStopForm = this.fb.group({
      billToAccountMultiSt: ['', Validators.required],
      equipTypeMultiSt: [''],
      totalWeightMultiSt: [''],
      wghtUnitMultiSt: [''],
      contactNameMultiSt: [''],
      contactEmailMultiSt: [''],
      originMultiSt: ['', Validators.required],
      destMultiSt: ['', Validators.required],
      pckUpDateMultiSt: [''],
      pckUpTimeMultiSt: [''],
      deliveryDateMultiSt: [''],
      deliveryTimeMultiSt: [''],
      spotNumMultiSt: [''],
      handlingUnitMultiSt: [''],
      handleUnitQuantityMultiSt: [''],
      volMultiSt: [''],
      weightUnitMultiSt: [''],
      nmfcMultiSt: ['', Validators.required],
      classMultiSt: ['', Validators.required],
      totWghtMultiSt: [''],
      wghtUnitNmfcMultiST: ['']
    });
  }
  onBlurMethod(value: string): void {
    const $itemArr = this.itemArr;
    $itemArr.push(value);
    for (let i = 0; i < $itemArr.length; i++) {
      console.log('item-->' + $itemArr[i]);
    }
  }
  submitFormMultiSt(value: any): void {
    if (value.valid) {
      this.multiStop();
    }
  };
  ngOnInit() { }
  showHideShippingOptsList(showHide) {
    this.shipOptnsMultiStopListFlag = true;
  }
}
