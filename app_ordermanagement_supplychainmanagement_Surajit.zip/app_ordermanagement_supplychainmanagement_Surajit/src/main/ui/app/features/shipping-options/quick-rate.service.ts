import { Injectable } from '@angular/core';
import { JBHGlobals } from '../../app.service';

@Injectable()
export class QuickRateService {

  public rateRowcolumns = [{
    name: 'Service offering',
    prop: 'ServiceOffering'
  },
  {
    name: 'Rate Type',
    prop: 'RateType'
  },
  {
    name: 'Rate',
    prop: 'Rate'
  },
  {
    name: 'rating',
    prop: 'rating'
  }
  ];

  public rateExpirecolumns = [{
    name: 'Service offering',
    prop: 'ServiceOffering'
  },
  {
    name: 'Rate',
    prop: 'Rate'
  },
  {
    name: 'rating',
    prop: 'rating'
  }
  ];
  public rateOverViewcolumns = [{
    name: '',
    prop: 'ServiceOffering'
  },
  {
    name: 'Pickup',
    prop: 'Pickup'
  },
  {
    name: 'Delivery',
    prop: 'Delivery'
  }
  ];
  public rateOverviewRatecolumns = [{
    name: '',
    prop: 'ServiceOffering'
  },
  {
    name: 'Recommended',
    prop: 'Recommended'
  },
  {
    name: 'Estimated PTE',
    prop: 'Estimated'
  }
  ];
  public sendToCustomerDropdown = ['Line Hall', 'Drive lead', 'Fuel surchage'];
  public rateRow = [];
  constructor(public jbhGlobals: JBHGlobals) { }

  getRates(): any {
    return this.update_fetch(this.jbhGlobals.endpoints.quickrates.rateUrl);
  }
  fetch(url, cb) {
    this.jbhGlobals.apiService.getData(url).subscribe(data => {
      return cb(data);
    });
  }
  update_fetch(url): any {
    this.jbhGlobals.apiService.getData(url).subscribe();
  }
}
