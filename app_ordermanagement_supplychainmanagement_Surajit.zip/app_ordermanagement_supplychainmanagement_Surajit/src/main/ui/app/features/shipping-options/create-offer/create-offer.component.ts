import { Http } from '@angular/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { QuickRateService } from '../quick-rate.service';

@Component({
  selector: 'app-create-offer',
  templateUrl: './create-offer.component.html',
  styleUrls: ['./create-offer.component.scss'],
  providers: [QuickRateService]
})
export class CreateOfferComponent implements OnInit {

  pageTitle = 'Create Offer';
  offerForm: any;
  addChargeForm: any;
  rateOverViewRow = [];
  rateOverViewRateRow = [];
  selected = [];
  sendToCustomerData = [];
  sendToCustomerDropdown = [];
  totalRate: number;
  rateOverViewcolumns = [];
  rateOverviewRatecolumns = [];

  @ViewChild('createSectionKey') createSectionKey;
  @ViewChild('rateOverviewKey') rateOverviewKey;
  @ViewChild('sendToCustomerKey') sendToCustomerKey;
  constructor(public http: Http, public fb: FormBuilder, public quickService: QuickRateService) { }

  ngOnInit() {

    this.rateOverViewcolumns = this.quickService.rateOverViewcolumns;
    this.rateOverviewRatecolumns = this.quickService.rateOverviewRatecolumns;

    this.createForm();
    this.quickService.fetch(this.quickService.jbhGlobals.endpoints.quickrates.overviewUrl, (data) => {
      this.rateOverViewRow = data;
    });
    this.quickService.fetch(this.quickService.jbhGlobals.endpoints.quickrates.overviewRateUrl, (data) => {
      this.rateOverViewRateRow = data;
    });
    this.quickService.fetch(this.quickService.jbhGlobals.endpoints.quickrates.chargeAmountUrl, (data) => {
      this.sendToCustomerData = data;
      this.totalRate = this.calculateTotals(data);
    });
    this.sendToCustomerDropdown = this.quickService.sendToCustomerDropdown;
    this.setUpKeyboardShortcuts();
  }
  private setUpKeyboardShortcuts() {
    this.quickService.jbhGlobals.shortkeys.getData().subscribe(data => {
      if (data.keyCode === 'alt+1') {
        this.createSectionKey.nativeElement.focus();
      } else if (data.keyCode === 'alt+2') {
        this.rateOverviewKey.nativeElement.focus();
      } else if (data.keyCode === 'alt+3') {
        this.sendToCustomerKey.nativeElement.focus();
      }
    });
  }
  createForm() {

    this.offerForm = this.fb.group({
      customerType: ['', Validators.required],
      billAddress: ['124 Real Street, Bentonville, AR 72712, Coca-Cola', Validators.required],
      billContact: ['Patrick Jones (132) 480-239-2392', Validators.required],
      customerName: ['Patrick Jones', Validators.required],
      customerEmail: ['Patrick.Jones@gmail.com', Validators.required],
      comments: ''
    });

    this.addChargeForm = this.fb.group({
      chargeField: ['', Validators.required],
      amountField: ['', Validators.required]
    });

  }
  addCharges(values: any): void {

    this.totalRate += parseInt(values.amountField, 10);
    this.sendToCustomerData.push({
      charge: values.chargeField,
      amount: values.amountField
    });
    this.addChargeForm.reset();
  }
  submitForm(value: any): void {
    console.log('Reactive Form Data: ');
    console.log(value);
    this.createForm();
  }
  calculateTotals(data) {
    let totalPrice = 0;
    data.forEach((d) => {
      totalPrice += parseInt(d.amount, 10);
    });
    return totalPrice;
  }
}
