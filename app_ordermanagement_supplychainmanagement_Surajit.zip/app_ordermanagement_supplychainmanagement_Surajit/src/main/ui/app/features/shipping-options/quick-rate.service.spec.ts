import { TestBed, inject } from '@angular/core/testing';

import { QuickRateService } from './quick-rate.service';

describe('QuickRateService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [QuickRateService]
    });
  });

  it('should ...', inject([QuickRateService], (service: QuickRateService) => {
    expect(service).toBeTruthy();
  }));
});
