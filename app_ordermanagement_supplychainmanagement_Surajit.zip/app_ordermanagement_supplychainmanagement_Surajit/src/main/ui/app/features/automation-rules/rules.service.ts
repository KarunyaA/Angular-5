import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import 'rxjs/add/operator/delay';
import { RuleModel, rule } from './model/rule.model';

@Injectable()
export class RulesService {
  delayMs = 500;
  // Fake server get; assume nothing can go wrong
  getRule(): Observable<RuleModel> {
    return of(rule).delay(this.delayMs); // simulate latency with delay
  }
}
