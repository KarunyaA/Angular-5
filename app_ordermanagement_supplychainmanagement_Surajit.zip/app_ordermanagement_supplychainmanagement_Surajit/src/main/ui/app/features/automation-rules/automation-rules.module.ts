import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PopoverModule } from 'ngx-bootstrap/popover';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BsDropdownModule } from 'ngx-bootstrap';
import { AutomationRulesRoutingModule } from './automation-rules-routing.module';
import { RulesListComponent } from './rules-list/rules-list.component';

import { JBHDataTableModule } from '../../../app/shared/jbh-data-table/jbh-data-table.module';

import { ConfigureRuleComponent } from './configure-rule/configure-rule.component';
import { RulesService } from './rules.service';
import { JbhSearchFilterModule } from '../../../app/shared/jbh-search-filter/jbh-search-filter.module';
import { ConfiguredRulesListComponent } from './rules-list/configured-rules-list.component';
import { JbhUtilsModule } from './../../shared/jbh-utils/jbh-utils.module';
@NgModule({
  imports: [
    CommonModule,
    AutomationRulesRoutingModule,
    JBHDataTableModule,
    PopoverModule.forRoot(),
    BsDropdownModule.forRoot(),
    FormsModule,
    ReactiveFormsModule,
    JbhSearchFilterModule,
    JbhUtilsModule
  ],
  declarations: [RulesListComponent, ConfigureRuleComponent, ConfiguredRulesListComponent],
  providers: [RulesService]
})
export class AutomationRulesModule { }
