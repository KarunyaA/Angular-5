import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { JBHGlobals } from '../../../app.service';

@Component({
  selector: 'app-rules-list',
  templateUrl: './rules-list.component.html',
  styleUrls: ['./rules-list.component.scss']
})
export class RulesListComponent implements OnInit {
  rows: any[];
  selected = [];

  public flag = 0;
  public rulesFilterList: any[] = [{
    'index': 0,
    'key': 'orderBillingDetailDTOs.solicitorCode',
    'title': 'Business Unit',
    'componentType': 'lsitType',
    'rootVal': ['ProfileDTO'],
    'pagination': true,
    'url': 'getMdmMockServiceURL',
    'params': {
      'value': 'Coc',
      'roletype': 'Solicitor',
      'active': 'yes',
      'page': 0,
      'size': 2,
      'approved': true,
      'addresstype': 'mailing'
    }
  }, {
    'index': 1,
    'title': 'Service Offering',
    'key': 'lineOfBusinessCode',
    'rootVal': ['ProfileDTO'],
    'componentType': 'lsitType',
    'pagination': true,
    'url': 'getMdmMockServiceURL',
    'params': {
      'value': 'Coc',
      'roletype': 'LineOfBusiness',
      'active': 'yes',
      'page': 0,
      'size': 2,
      'approved': true,
      'addresstype': 'PHYSICAL'
    }
  }, {
    'index': 2,
    'key': 'Customer',
    'title': 'Association Level',
    'rootVal': ['ProfileDTO'],
    'componentType': 'lsitType',
    'pagination': true,
    'url': 'getMdmMockServiceURL',
    'params': {
      'value': 'Coc',
      'roletype': 'Customer',
      'active': 'yes',
      'page': 0,
      'size': 2,
      'approved': true,
      'addresstype': 'PHYSICAL'
    }
  }, {
    'index': 3,
    'key': 'tradingPartnerCode',
    'title': 'Rule Category',
    'rootVal': [],
    'componentType': 'lsitType',
    'url': ''
  }];
  ngOnInit() { }


  constructor(public router: Router, public jbhGlobals: JBHGlobals) {
    this.fetch((data) => {
      this.rows = data;
    });
  }


  fetch(cb) {
    const req = new XMLHttpRequest();
    req.open('GET', `api/automation-rules/rules.json`);

    req.onload = () => {
      cb(JSON.parse(req.response));
    };

    req.send();
  }

  updateRowPosition() {
    const ix = this.getSelectedIx();
    const arr = [...this.rows];
    arr[ix - 1] = this.rows[ix];
    arr[ix] = this.rows[ix - 1];
    this.rows = arr;
  }

  getSelectedIx() {
    return this.selected[0]['$$index'];
  }
  onSelect(event) {
    this.router.navigateByUrl('/automationrules/configurenewrule');
  }

}
