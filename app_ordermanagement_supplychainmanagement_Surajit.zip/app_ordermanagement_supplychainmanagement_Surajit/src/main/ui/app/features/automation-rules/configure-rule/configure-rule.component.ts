import { Component, OnInit, ViewChild } from '@angular/core';
import { FormArray, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/finally';

import { RuleModel, businessUnits, serviceOfferings, resultantActions, attributesArr, operators, values } from '../model/rule.model';
import { AttributeModel } from '../model/attribute.model';
import { RulesService } from '../rules.service';

import { JBHGlobals } from '../../../app.service';

@Component({
  selector: 'app-configure-rule',
  templateUrl: './configure-rule.component.html',
  styleUrls: ['./configure-rule.component.scss']
})

export class ConfigureRuleComponent implements OnInit {

  rule: Observable<RuleModel>;
  isLoading = false;
  selectedRule: any;
  ruleForm: any;

  businessUnits = businessUnits;
  serviceOfferings = serviceOfferings;
  resultantActions = resultantActions;
  attributesArr = attributesArr;
  operators = operators;
  values = values;
  @ViewChild('formHeaderSectionKey') formHeaderSectionKey;
  @ViewChild('formMiddleSectionKey') formMiddleSectionKey;
  @ViewChild('formBottomSectionKey') formBottomSectionKey;

  constructor(public router: Router, public fb: FormBuilder, public ruleService: RulesService,
    public jbhGlobals: JBHGlobals) {
    this.createForm();
    this.setUpKeyboardShortcuts();
  }
  private setUpKeyboardShortcuts() {
    this.jbhGlobals.shortkeys.getData().subscribe(data => {
      if (data.keyCode === 'alt+1') {
        this.formHeaderSectionKey.nativeElement.focus();
      } else if (data.keyCode === 'alt+2') {
        this.formMiddleSectionKey.nativeElement.focus();
      } else if (data.keyCode === 'alt+3') {
        this.formBottomSectionKey.nativeElement.focus();
      }
    });
  }
  createForm() {
    this.jbhGlobals.logger.info('Create Form Called');
    this.ruleForm = this.fb.group({
      businessUnit: ['', Validators.required],
      serviceOffering: ['', Validators.required],
      globalOverride: true,
      resultantAction: ['', Validators.required],
      addedAttributes: this.fb.array([])
    });
  }

  ngOnInit() {
    this.getRule();
  }

  getRule() {
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.automationrules.configurenewrule)
      .subscribe(data => {
        this.selectedRule = data;
        this.ruleForm.reset({
          businessUnit: this.selectedRule.businessUnit,
          serviceOffering: this.selectedRule.serviceOffering,
          globalOverride: this.selectedRule.globalOverride,
          resultantAction: this.selectedRule.resultantAction
        });
        this.setAttributes(this.selectedRule.addedAttributes);
      });
    this.isLoading = true;
  }

  get addedAttributes(): FormArray {
    return this.ruleForm.get('addedAttributes') as FormArray;
  }

  addNewAttribute() {
    this.addedAttributes.push(this.fb.group(new AttributeModel()));
  }

  setAttributes(addedAttributes: AttributeModel[]) {
    const ruleFGs = addedAttributes.map(AttributeModel => this.fb.group(AttributeModel));
    const ruleFormArray = this.fb.array(ruleFGs);
    this.ruleForm.setControl('addedAttributes', ruleFormArray);
  }

  onCancel() {
    this.router.navigateByUrl('/automationrules/configuredrules');
  }

}
