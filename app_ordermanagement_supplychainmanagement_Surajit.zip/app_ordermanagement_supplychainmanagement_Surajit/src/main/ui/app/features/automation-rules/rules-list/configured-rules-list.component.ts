import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { JBHGlobals } from '../../../app.service';

@Component({
  selector: 'app-configured-rules-list',
  templateUrl: './configured-rules-list.component.html',
  styleUrls: ['./configured-rules-list.component.scss']
})
export class ConfiguredRulesListComponent implements OnInit {


  public rows: any[];
  public selected = [];

  public rulesGridMenu = [{
    'name': 'Export To Excel',
    'id': 'exporttoexcel'
  },
  {
    'name': 'Configure New Rule',
    'id': 'configurenewrule'
  }
  ];
  public rulesFilterTitle = 'Filter By';
  public flag = 0;
  public rulesFilterList: any[] = [{
    'index': 0,
    'key': 'orderBillingDetailDTOs.solicitorCode',
    'title': 'Business Unit',
    'componentType': 'lsitType',
    'rootVal': [],
    'pagination': true,
    'url': ''
  }, {
    'index': 1,
    'title': 'Service Offering',
    'key': 'lineOfBusinessCode',
    'rootVal': [],
    'componentType': 'lsitType',
    'pagination': true,
    'url': ''
  }, {
    'index': 2,
    'key': 'Customer',
    'title': 'Association Level',
    'rootVal': [],
    'componentType': 'lsitType',
    'pagination': true,
    'url': ''
  }, {
    'index': 3,
    'key': 'tradingPartnerCode',
    'title': 'Rule Category',
    'rootVal': [],
    'componentType': 'lsitType',
    'url': ''
  }, {
    'index': 4,
    'key': 'owner.inits',
    'title': 'Global override flag status',
    'rootVal': [],
    'componentType': 'lsitType',
    'url': ''
  }, {
    'index': 5,
    'key': 'Number of Stops',
    'title': 'Status',
    'rootVal': [],
    'componentType': 'lsitType',
    'url': ''
  }];
  @ViewChild('formSectionKey') formSectionKey;
  @ViewChild('gridSectionKey') gridSectionKey;

  fetch(cb) {
    const req = new XMLHttpRequest();
    req.open('GET', `api/automation-rules/configuredrules.json`);

    req.onload = () => {
      cb(JSON.parse(req.response));
    };

    req.send();
  }

  updateRowPosition() {
    const ix = this.getSelectedIx();
    const arr = [...this.rows];
    arr[ix - 1] = this.rows[ix];
    arr[ix] = this.rows[ix - 1];
    this.rows = arr;
  }
  ngOnInit() { this.setUpKeyboardShortcuts(); }
  constructor(public router: Router, public jbhGlobals: JBHGlobals) {
    this.fetch((data) => {
      this.selected = [data[2]];
      this.rows = data;
    });
  }
  private setUpKeyboardShortcuts() {
    this.jbhGlobals.shortkeys.getData().subscribe(data => {
      if (data.keyCode === 'alt+1') {
        this.formSectionKey.nativeElement.focus();
      } else if (data.keyCode === 'alt+2') {
        this.gridSectionKey.nativeElement.focus();
      }
    });
  }
  getSelectedIx() {
    return this.selected[0]['$$index'];
  }

  menuClickEvent(selectedVal) {
    if (selectedVal === 'configurenewrule') {
      this.router.navigateByUrl('/automationrules/rules');
    } else if (selectedVal === 'exporttoexcel') {
      this.router.navigateByUrl('/configure-rule/exporttoexcel');
    }

  }

  onRulesListMenuClick(event, pop, row) {
    const currEle = event.srcElement.id;
    pop.hide();
    switch (currEle) {
      case 'copy':
        {
          this.router.navigateByUrl('/automationrules/configurenewrule');
          break;
        }
      case 'inActivate':
        {
          console.log('In Activate Rule called');
          break;
        }
      case 'viewEdit':
        {
          this.router.navigateByUrl('/automationrules/configurenewrule');
          break;
        }
      case 'activate':
        {
          console.log('Activate Rule called');
          break;
        }
      default:
        {
          break;
        }
    }
  }

  onActivate(event) {
    console.log('Activate Event', event);
    this.selected.splice(0, this.selected.length);
    this.selected.push(event.row);
  }

  public additionalSearch() {
    if (this.flag === 0) {
      this.flag = 1;
    } else {
      this.flag = 0;
    }
  }
}
