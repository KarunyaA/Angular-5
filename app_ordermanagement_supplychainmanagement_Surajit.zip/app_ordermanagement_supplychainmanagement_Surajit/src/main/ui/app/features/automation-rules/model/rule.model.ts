import { AttributeModel } from './attribute.model';

export class RuleModel {
  businessUnit: string;
  serviceOffering: string;
  globalOverride: boolean;
  resultantAction: string;
  addedAttributes: AttributeModel[];
}

export const rule: RuleModel = {
  businessUnit: 'BU 1',
  serviceOffering: 'SO 1',
  globalOverride: false,
  resultantAction: 'RA 1',
  addedAttributes: [{
    attribute: 'A 1',
    operator: 'O 1',
    value: 'V 1'
  },
  {
    attribute: 'A 2',
    operator: 'O 2',
    value: 'V 2'
  },
  {
    attribute: 'A 3',
    operator: 'O 3',
    value: 'V 3'
  },
  {
    attribute: 'A 4',
    operator: 'O 4',
    value: 'V 4'
  }
  ]
};

export const businessUnits = ['BU 1', 'BU 2', 'BU 3', 'BU 4'];
export const serviceOfferings = ['SO 1', 'SO 2', 'SO 3', 'SO 4'];
export const resultantActions = ['RA 1', 'RA 2', 'RA 3', 'RA 4'];

export const attributesArr = ['A 1', 'A 2', 'A 3', 'A 4'];
export const operators = ['O 1', 'O 2', 'O 3', 'O 4'];
export const values = ['V 1', 'V 2', 'V 3', 'V 4'];
