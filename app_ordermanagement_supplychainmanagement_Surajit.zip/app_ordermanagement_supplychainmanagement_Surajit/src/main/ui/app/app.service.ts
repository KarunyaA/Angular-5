import {
  ConfigStaticLoader
} from '@nglibs/config';
import {
  ConfigService
} from '@nglibs/config';
import {
  Injectable
} from '@angular/core';
import {
  NotificationsService
} from 'angular2-notifications';
import * as _ from 'lodash';

import {
  ApiClientService
} from '../app/shared/jbh-utils/api-client.service';
import {
  LoggerService
} from '../app/shared/jbh-utils/logger.service';
import {
  ShortcutkeyService
} from '../app/shared/jbh-utils/shortcutkey.service';
import {
  AppSharedDataService
} from '../app/shared/jbh-utils/app-shared-data.service';

import { ValidationService } from '../app/shared/jbh-validation/validation.service';
import { AppConfig } from '../config/app.config';



export function configFactory() {
  return new ConfigStaticLoader('./config/app.config.json');
}


@Injectable()
export class JBHGlobals {

  public endpoints: any;
  public apiService: ApiClientService;
  public logger: LoggerService;
  public notifications: NotificationsService;
  public shortkeys: any;
  public settings: any;
  public commonDataService: any;
  public utils: any;
  public customValidator: any;
  public userDetails: any;

  constructor(private config: ConfigService,
    private apiClientService: ApiClientService,
    private log4js: LoggerService,
    private ns: NotificationsService,
    private shortcutkeyService: ShortcutkeyService,
    private appSharedDataService: AppSharedDataService
  ) {
    const appConfig = AppConfig.getConfig();
    this.endpoints = appConfig.api;
    this.apiService = apiClientService;
    this.logger = log4js;
    this.logger.init(appConfig.system.enableLog);
    this.notifications = ns;
    this.settings = appConfig.settings;
    this.utils = _;
    this.logger.info('JBH Globals initialized');
    this.shortkeys = shortcutkeyService;
    this.commonDataService = appSharedDataService;
    this.customValidator = ValidationService;
  }
}
