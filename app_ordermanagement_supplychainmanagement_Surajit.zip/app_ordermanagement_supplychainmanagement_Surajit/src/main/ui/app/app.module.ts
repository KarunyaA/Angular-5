import { BrowserModule } from '@angular/platform-browser';
import { NgModule} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { CommonModule } from '@angular/common';

// import { Logger } from "angular2-logger/core";
// import { ConfigModule, ConfigLoader } from 'ng2-config';
import { ConfigModule, ConfigLoader } from '@nglibs/config';
import { SimpleNotificationsModule } from 'angular2-notifications';

import { CoreModule } from './core/core.module';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SharedModule } from './shared/shared.module';

import { JbhJsonTransformerService } from './shared/jbh-utils/jbh-json-transformer.service';
import { JbhUtilsModule } from 'app/shared/jbh-utils/jbh-utils.module';
import { configFactory, JBHGlobals } from './app.service';
import { SpinnerService, SpinnerComponent } from './shared/spinner/index';
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';

import { ApiClientService } from './shared/jbh-utils/api-client.service';
// import { JbhJsonTransformerService } from './shared/jbh-utils/jbh-json-transformer.service';
import { LoggerService } from 'app/shared/jbh-utils/logger.service';
import { HotkeysService } from 'app/shared/jbh-utils/hotkeys.service';
import { AppSharedDataService } from 'app/shared/jbh-utils/app-shared-data.service';
import { ShortcutkeyService } from 'app/shared/jbh-utils/shortcutkey.service';
import { TemplateJsonTransformerService } from 'app/features/create-orders/templates/template-json-transformer.service';
const PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  suppressScrollX: false,
  minScrollbarLength: 10,
  maxScrollbarLength: 50
};


@NgModule({
  declarations: [
    AppComponent,
    SpinnerComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    CommonModule,
    CoreModule,
    SharedModule,
    AppRoutingModule,
    SimpleNotificationsModule.forRoot(),
    JbhUtilsModule,
    // SafepipeModule,
    PerfectScrollbarModule.forRoot(PERFECT_SCROLLBAR_CONFIG),
    ConfigModule.forRoot({
      provide: ConfigLoader,
      useFactory: (configFactory)
    })
  ],
  providers: [
    JBHGlobals,
    ApiClientService,
    LoggerService,
    SpinnerService,
    JbhJsonTransformerService,
    TemplateJsonTransformerService,
    HotkeysService,
    AppSharedDataService,
    ShortcutkeyService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
