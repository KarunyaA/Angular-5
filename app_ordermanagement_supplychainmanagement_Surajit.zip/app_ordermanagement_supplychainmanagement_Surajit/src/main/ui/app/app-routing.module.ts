import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ManageOrdersRoutes } from './features/manage-orders/manage-orders-routing.config';
import { SharedDemoRoutes } from './shared/shared-routing.config';


const routes: Routes = [
  {
    path: 'dashboard',
    loadChildren: 'app/features/dashboard/dashboard.module#DashboardModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Dashboard',
      pathIcon: `icon-jbh_home pull-right`,
      order: 1
    }
  },
  {
    path: 'createorders',
    loadChildren: 'app/features/create-orders/create-orders.module#CreateOrdersModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Create Order',
      pathIcon: `icon-jbh_add pull-right`,
      order: 1
    }
  },
  // Entry for Order Search - Not To Commit
  {
    path: 'ordersearch',
    loadChildren: 'app/features/order-search/order-search.module#OrderSearchModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Order Search',
      pathIcon: `icon-jbh_search pull-right`,
      order: 1
    }
  },
  // Entry for Order Search - Not To Commit
  {
    path: 'shippingoptions',
    loadChildren: 'app/features/shipping-options/shipping-options.module#ShippingOptionsModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Shipping Options',
      pathIcon: `icon-jbh_item pull-right`,
      order: 1
    }
  },
  {
    path: 'manageorders',
    children: [...ManageOrdersRoutes],
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Manage Orders',
      pathIcon: `icon-jbh_multi_item pull-right`,
      order: 1
    }
  },
  {
    path: 'opportunityorders',
    loadChildren: 'app/features/opportunity-orders/opportunity-orders.module#OpportunityOrdersModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Opportunity Orders',
      pathIcon: `icon-jbh_placeholder pull-right`,
      order: 1
    }
  },
  {
    path: 'advancedsearch',
    loadChildren: 'app/features/advanced-search/advanced-search.module#AdvancedSearchModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Advanced Search',
      pathIcon: `icon-jbh_search pull-right`,
      order: 1
    }
  },
  {
    path: 'settings',
    loadChildren: 'app/features/settings/settings.module#SettingsModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Settings',
      pathIcon: `icon-jbh_placeholder pull-right`,
      order: 1
    }
  }, {
    path: 'automationrules',
    loadChildren: 'app/features/automation-rules/automation-rules.module#AutomationRulesModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Automation Rules',
      pathIcon: `icon-jbh_placeholder pull-right`,
      order: 1
    }
  }, {
    path: 'sharedimplementations',
    children: [...SharedDemoRoutes],
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'RI Demos',
      pathIcon: `icon-jbh_placeholder pull-right`,
      order: 1
    }

  }, {
    path: 'commitments',
    loadChildren: 'app/features/commitments/commitments.module#CommitmentsModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Commitments',
      pathIcon: `icon-jbh_placeholder pull-right`,
      order: 1
    }
  },
  {
    path: 'manageratesheet',
    loadChildren: 'app/features/manage-rate-sheet/manage-rate-sheet.module#ManageRateSheetModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Manage Rate Sheet',
      pathIcon: `icon-jbh_item pull-right`,
      order: 1
    }
  },
  {
    path: 'vieworder',
    loadChildren: 'app/features/view-order/view-order.module#ViewOrderModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'View Order',
      pathIcon: `icon-jbh_item pull-right`,
      order: 1
    }
  },
  {
    path: 'loadinformation',
    loadChildren: 'app/features/load-information/load-information.module#LoadInformationModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Load Information',
      pathIcon: `icon-jbh_search pull-right`,
      order: 1
    }
  },
  {
    path: 'appointments',
    loadChildren: 'app/features/appointments/appointments.module#AppointmentsModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Appointments',
      pathIcon: `icon-jbh_placeholder pull-right`,
      order: 1
    }
  },
  {
    path: 'viewucr',
    loadChildren: 'app/features/view-ucr/view-ucr.module#ViewUcrModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'View UCR',
      pathIcon: `icon-jbh_search pull-right`,
      order: 1
    }
  },
  {
    path: 'bulkupload',
    loadChildren: 'app/features/create-orders/templates/bulk-upload/bulk-upload.module#BulkUploadModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Bulk Upload',
      pathIcon: `icon-jbh_search pull-right`,
      order: 1
    }
  },
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
  { path: '**', redirectTo: 'dashboard', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  providers: []
})

export class AppRoutingModule { }
