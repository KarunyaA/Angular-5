import {
  Component,
  Output,
  EventEmitter
} from '@angular/core';


@Component({
  selector: 'app-jbh-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent {

  @Output() sidebarOpenEvent: EventEmitter<boolean> = new EventEmitter<
    boolean>();
  @Output() overlayShowEvent: EventEmitter<boolean> = new EventEmitter<
    boolean>();
    showWindow = true;
    displayLayer: string;
  applicationName = 'Order Management';
  isSidebarOpen = false;
  private isFullScreen = false;

  getFullScreenIcon(): any {
    return this.isFullScreen ? 'icon-size-actual' :
      'icon-size-fullscreen';
  }

  toggleFullScreen() {
    const doc: any = window.document;
    const docEl: any = doc.documentElement;

    const requestFullScreen: any = docEl.requestFullscreen || docEl.mozRequestFullScreen ||
      docEl.webkitRequestFullScreen || docEl.msRequestFullscreen;
    const cancelFullScreen: any = doc.exitFullscreen || doc.mozCancelFullScreen ||
      doc.webkitExitFullscreen || doc.msExitFullscreen;

    if (!doc.fullscreenElement && !doc.mozFullScreenElement && !doc.webkitFullscreenElement &&
      !doc.msFullscreenElement) {
      requestFullScreen.call(docEl);
      this.isFullScreen = true;
    } else {
      cancelFullScreen.call(doc);
      this.isFullScreen = false;
    }
  }

  toggleMobleSidebar(): any {
    this.isSidebarOpen = !this.isSidebarOpen;
    this.sidebarOpenEvent.emit(this.isSidebarOpen);
  }

  manageOverlayToggle() {
    this.showWindow = !this.showWindow;
    this.overlayShowEvent.emit(this.showWindow);
  }
}
