package com.jbhunt.ordermanagement.util;

import java.util.List;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@RefreshScope
@Component
@ConfigurationProperties(prefix = "contactstatuscodes")
public class OrderProperties {
	
	private List<Map<String, Map<String,String>>> contactStatusCodesTypes;


}
