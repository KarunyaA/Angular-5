package com.jbhunt.ordermanagement.util;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.jbhunt.contact.entities.PhoneCallVO;
import com.jbhunt.contact.entities.StatusCodeVO;
import com.jbhunt.contact.factory.GetPhoneCallRequestFactory;
import com.jbhunt.contact.specifications.GetPhoneCallByTrackingNumberSpecification;
import com.jbhunt.contact.specifications.GetStatusCodeByCallDirectionSpecification;
import com.jbhunt.contact.specifications.GetStatusCodeByCallResultSpecification;
import com.jbhunt.contact.specifications.GetStatusCodeByPreCallIntentSpecification;

@Service
public class ContactWebserviceUtil {

	private ContactWebserviceClient contactWebserviceClient;

	@Autowired
	public ContactWebserviceUtil(ContactWebserviceClient contactWebserviceClient,
			GetPhoneCallRequestFactory getPhoneCallRequestFactory) {
		this.contactWebserviceClient = contactWebserviceClient;
	}

	public List<PhoneCallVO> getPhoneCallBySpecification() {
		GetPhoneCallByTrackingNumberSpecification phoneCallSpecification = new GetPhoneCallByTrackingNumberSpecification();
		return contactWebserviceClient.getPhoneCallRequestBySpecification(phoneCallSpecification);
	}

	@Cacheable(value = "contactWebserviceCache", cacheManager = "supplyChainManagementCacheManager")
	public List<StatusCodeVO> getStatusCodesByCallIntent() {
		GetStatusCodeByPreCallIntentSpecification callIntentSpecification = new GetStatusCodeByPreCallIntentSpecification();
		return contactWebserviceClient.getStatusCodesBySpecification(callIntentSpecification);
	}

	@Cacheable(value = "contactWebserviceCache", cacheManager = "supplyChainManagementCacheManager")
	public List<StatusCodeVO> getStatusCodesByCallResult() {
		GetStatusCodeByCallResultSpecification sp = new GetStatusCodeByCallResultSpecification();
		return contactWebserviceClient.getStatusCodesBySpecification(sp);
	}

	@Cacheable(value = "contactWebserviceCache", cacheManager = "supplyChainManagementCacheManager")
	public List<StatusCodeVO> getStatusCodesByCallDirection() {
		GetStatusCodeByCallDirectionSpecification callDirectionSpecification = new GetStatusCodeByCallDirectionSpecification();
		return contactWebserviceClient.getStatusCodesBySpecification(callDirectionSpecification);
	}

}
