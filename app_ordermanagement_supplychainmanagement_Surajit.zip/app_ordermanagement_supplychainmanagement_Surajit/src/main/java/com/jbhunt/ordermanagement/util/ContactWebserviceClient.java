package com.jbhunt.ordermanagement.util;

import static com.jbhunt.ordermanagement.constant.OrderConstants.CALLDIRECTION;
import static com.jbhunt.ordermanagement.constant.OrderConstants.CALLINTENT;
import static com.jbhunt.ordermanagement.constant.OrderConstants.CALLRESULTS;
import static com.jbhunt.ordermanagement.constant.OrderConstants.RECORDSTATUS;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.annotation.Resource;

import org.datacontract.schemas._2004._07.com_jbhunt_lib_util_model.SpecificationBaseStatusCodeVO;
import org.springframework.stereotype.Component;

import com.jbhunt.contact.IContactWebService;
import com.jbhunt.contact.entities.PhoneCallVO;
import com.jbhunt.contact.entities.StatusCodeVO;
import com.jbhunt.contact.factory.GetPhoneCallRequestFactory;
import com.jbhunt.contact.factory.GetStatusCodeRequestFactory;
import com.jbhunt.contact.requestresponseobjects.GetPhoneCallsRequest;
import com.jbhunt.contact.requestresponseobjects.GetPhoneCallsResponse;
import com.jbhunt.contact.requestresponseobjects.GetStatusCodesRequest;
import com.jbhunt.contact.requestresponseobjects.GetStatusCodesResponse;
import com.jbhunt.contact.specifications.GetPhoneCallByTrackingNumberSpecification;
import com.jbhunt.contact.specifications.GetStatusCodeByCallDirectionSpecification;
import com.jbhunt.contact.specifications.GetStatusCodeByCallResultSpecification;
import com.jbhunt.contact.specifications.GetStatusCodeByPreCallIntentSpecification;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ContactWebserviceClient {

	@Resource(name = "contactRequestWebServicePort")
	private IContactWebService iContactWebService = null;
	private OrderProperties orderProperties;

	private GetStatusCodeRequestFactory getStatusCodeRequestFactory;
	
	private GetPhoneCallRequestFactory getPhoneCallRequestFactory;


	public ContactWebserviceClient(GetStatusCodeRequestFactory getStatusCodeRequestFactory, GetPhoneCallRequestFactory getPhoneCallRequestFactory,
			OrderProperties orderProperties) {
		this.getStatusCodeRequestFactory = getStatusCodeRequestFactory;
		this.getPhoneCallRequestFactory = getPhoneCallRequestFactory;
		this.orderProperties = orderProperties;
	}

	public List<PhoneCallVO> getPhoneCallRequestBySpecification(GetPhoneCallByTrackingNumberSpecification phoneCallSpecification) {
		GetPhoneCallsRequest request = getPhoneCallRequestFactory.getPhoneCallRequest(phoneCallSpecification);
		GetPhoneCallsResponse response = iContactWebService.getPhoneCalls(request);
		return response.getPhoneCalls().getPhoneCallVO();
	}	
	
	@HystrixCommand(fallbackMethod = "populateStaticValues")
	public List<StatusCodeVO> getStatusCodesBySpecification(SpecificationBaseStatusCodeVO specification) {
		log.info("Inside the method................");
		GetStatusCodesRequest request = getStatusCodeRequestFactory.getStatusCodesRequest(specification);
		GetStatusCodesResponse response = iContactWebService.getStatusCodes(request);
		return response.getStatusCodes().getStatusCodeVO();
	}

	public List<StatusCodeVO> populateStaticValues(SpecificationBaseStatusCodeVO specification) {
		List<StatusCodeVO> statusCodeVo = new ArrayList<>();
		Map<String, Map<String, String>> val = new LinkedHashMap<>();

		if (specification instanceof GetStatusCodeByPreCallIntentSpecification) {
			val = orderProperties.getContactStatusCodesTypes().stream()
					.flatMap(mapping -> mapping.entrySet().stream()
							.filter(ma -> ma.getKey().equalsIgnoreCase(CALLINTENT)))
					.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
		}

		if (specification instanceof GetStatusCodeByCallDirectionSpecification) {
			val = orderProperties.getContactStatusCodesTypes().stream()
					.flatMap(mapping -> mapping.entrySet().stream()
							.filter(ma -> ma.getKey().equalsIgnoreCase(CALLDIRECTION)))
					.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
		}

		if (specification instanceof GetStatusCodeByCallResultSpecification) {
			val = orderProperties.getContactStatusCodesTypes().stream()
					.flatMap(mapping -> mapping.entrySet().stream()
							.filter(ma -> ma.getKey().equalsIgnoreCase(CALLRESULTS)))
					.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
		}
		if (Optional.of(val).isPresent()) {
			val.entrySet().forEach(items -> {
				items.getValue().forEach((key, value) -> {
					StatusCodeVO statusCodeVO = new StatusCodeVO();
					statusCodeVO.setCode(key);
					statusCodeVO.setPresentationName(value);
					statusCodeVO.setRecordStatus(RECORDSTATUS);
					statusCodeVo.add(statusCodeVO);
				});
			});
		}
		return statusCodeVo;
	}
}
