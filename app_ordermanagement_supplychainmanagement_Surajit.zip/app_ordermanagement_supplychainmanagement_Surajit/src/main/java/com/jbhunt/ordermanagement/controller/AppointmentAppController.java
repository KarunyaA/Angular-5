package com.jbhunt.ordermanagement.controller;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jbhunt.contact.entities.PhoneCallVO;
import com.jbhunt.contact.entities.StatusCodeVO;
import com.jbhunt.ordermanagement.constant.OrderConstants;
import com.jbhunt.ordermanagement.util.ContactWebserviceUtil;

@RestController
@RequestMapping("/appointment")
public class AppointmentAppController {

	private ContactWebserviceUtil contactWebserviceUtil;

	@Autowired
	public AppointmentAppController(ContactWebserviceUtil contactWebserviceUtil) {
		this.contactWebserviceUtil = contactWebserviceUtil;
	}

	@GetMapping(value = "/contact/callintent/")
	public ResponseEntity<Map<String, String>> fetchCalllogIntent() {
		List<Optional<StatusCodeVO>> callintentOptional = contactWebserviceUtil.getStatusCodesByCallIntent().stream()
				.map(result -> Optional.of(result).filter(statusCode -> OrderConstants.RECORDSTATUS.equalsIgnoreCase(statusCode.getRecordStatus())))
				.collect(Collectors.toList());
		Map<String, String> callintentMap = callintentOptional.stream().filter(Optional::isPresent).map(Optional::get)
				.collect(Collectors.toMap(StatusCodeVO::getCode, StatusCodeVO::getPresentationName));
		return new ResponseEntity<Map<String, String>>(callintentMap, HttpStatus.OK);
	}

	@GetMapping(value = "/contact/callresult/")
	public ResponseEntity<Map<String, String>> fetchCalllogResult(Object eventRepository) {
		List<Optional<StatusCodeVO>> callresultOptional  = contactWebserviceUtil.getStatusCodesByCallResult().stream()
				.map(result -> Optional.of(result).filter(statusCode -> OrderConstants.RECORDSTATUS.equalsIgnoreCase(statusCode.getRecordStatus())))
				.collect(Collectors.toList());
		Map<String, String> callresultMap = callresultOptional.stream()
				.filter(Optional::isPresent)
				.map(Optional::get)
				.collect(Collectors.toMap(StatusCodeVO::getCode,StatusCodeVO::getPresentationName));
		return new ResponseEntity<Map<String, String>>(callresultMap,HttpStatus.OK);
	}

	@GetMapping(value = "/contact/calldirection/")
	public ResponseEntity<Map<String, String>> fetchCalllogDirection() {
		List<Optional<StatusCodeVO>> calldirectionOptional  = contactWebserviceUtil.getStatusCodesByCallDirection().stream()
				.map(direction -> Optional.of(direction).filter(statusCode ->OrderConstants.RECORDSTATUS.equalsIgnoreCase(statusCode.getRecordStatus())))
				.collect(Collectors.toList());
		Map<String, String> callDirectionMap = calldirectionOptional.stream()
				.filter(Optional::isPresent)
				.map(Optional::get)
				.collect(Collectors.toMap(StatusCodeVO::getCode,StatusCodeVO::getPresentationName));
		return new ResponseEntity<Map<String, String>>(callDirectionMap,HttpStatus.OK);		
	}

	@GetMapping(value = "/calllog/{orderTrackingNumber}")
	public ResponseEntity<List<PhoneCallVO>> fetchCalllog(@PathVariable String orderTrackingNumber) {
		List<PhoneCallVO> phoneCallOptional  = contactWebserviceUtil.getPhoneCallBySpecification().stream()
				.collect(Collectors.toList());
		return new ResponseEntity<List<PhoneCallVO>>(phoneCallOptional,HttpStatus.OK);	
	}

	@PostMapping(value = "/calllog")
	public ResponseEntity<String> saveCalllog(Object obj) {
		// integration of ws_contact webservice will done via
		// wsc_ContactWebservice project
		return new ResponseEntity<String>("call log", HttpStatus.CREATED);
	}
	}
