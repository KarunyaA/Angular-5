package com.jbhunt.ordermanagement.constant;

public final class OrderConstants {
	
	public static final String CALLRESULTS = "callresults";

	public static final String CALLDIRECTION = "calldirection";

	public static final String CALLINTENT = "callintent";
	
	public static final String RECORDSTATUS = "A";

	private OrderConstants() {
		
	}
	
}
