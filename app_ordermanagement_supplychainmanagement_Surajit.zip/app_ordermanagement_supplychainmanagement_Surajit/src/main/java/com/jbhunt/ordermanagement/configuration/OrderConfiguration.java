package com.jbhunt.ordermanagement.configuration;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import org.springframework.beans.factory.config.MethodInvokingFactoryBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.jbhunt.biz.securepid.FusePIDReader;
import com.jbhunt.biz.securepid.PIDCredentials;
import com.jbhunt.contact.factory.GetPhoneCallRequestFactory;
import com.jbhunt.contact.factory.GetStatusCodeRequestFactory;
import com.jbhunt.contact.factory.SavePhoneCallRequestFactory;
import com.jbhunt.hrms.EOIAPIUtil.apiutil.EOIAPIUtil;
import com.jbhunt.hrms.EOIAPIUtil.util.AuditInformation;

import lombok.extern.slf4j.Slf4j;

@Configuration
@Slf4j
public class OrderConfiguration {

	@Bean
	public EOIAPIUtil eoiapiUtil() {
		return new EOIAPIUtil(
				new AuditInformation(jbhLdapCredentials().getUsername(), "app_ordermanagement_supplychainmanagement"));
	}

	@Bean
	public PIDCredentials jbhLdapCredentials() {
		FusePIDReader fusePIDReader = new FusePIDReader("app_ordermanagement_supplychainmanagement");
		return fusePIDReader.readPIDCredentials("ldapresource");
	}
	
	@Bean
	public GetStatusCodeRequestFactory getStatusCodeRequestFactory() {
		GetStatusCodeRequestFactory factory = new GetStatusCodeRequestFactory();
		return factory;
	}
	@Bean
	public GetPhoneCallRequestFactory getPhoneCallRequestFactory() {
		GetPhoneCallRequestFactory phoneCallfactory = new GetPhoneCallRequestFactory();
		return phoneCallfactory;
	}
	@Bean(name = "contactRequestWebServicePort")
	public MethodInvokingFactoryBean methodInvokingFactoryBean() {
	    MethodInvokingFactoryBean methodInvokingFactoryBean = new MethodInvokingFactoryBean();
	    methodInvokingFactoryBean.setStaticMethod("com.jbhunt.contact.ContactPortFactory.getPortStub");
	    return methodInvokingFactoryBean;
	}
	@Bean
	public SavePhoneCallRequestFactory savePhoneCallRequestFactory()   {
		try {
			Constructor<SavePhoneCallRequestFactory> constructor = SavePhoneCallRequestFactory.class.getDeclaredConstructor();
			constructor.setAccessible(Boolean.TRUE);
			return constructor.newInstance();
		} catch (NoSuchMethodException | SecurityException | InstantiationException  | IllegalAccessException | IllegalArgumentException  | InvocationTargetException e) {
			log.error("Save Phone call Request Factory method", e);
		}
		return null;
	}
}
