import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-rating',
  templateUrl: './rating.component.html',
  styleUrls: ['./rating.component.scss']
})
export class RatingComponent implements OnInit {
  starArray: any = [];
  @Input() resultValue: any;
  constructor() { }

  ngOnInit() {
    this.calculateRating();
  }
  calculateRating() {
    const starRate = 5 - ((this.resultValue < 0) ? 5 : (0.5 * (this.resultValue - 1)));
    let halfFlag = true;
    for (let j = 1; j <= 5; j++) {
      if (j <= starRate) {
        this.starArray.push({ 'val': 'f' });
      } else {
        if ((starRate * 10) % 10 !== 0 && halfFlag) {
          this.starArray.push({ 'val': 'h' });
          halfFlag = false;
        } else {
          this.starArray.push({ 'val': 'e' });
        }
      }
    }
  }

}
