import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JBHSliderComponent } from './jbh-slider.component';

describe('JBHSliderComponent', () => {
  let component: JBHSliderComponent;
  let fixture: ComponentFixture<JBHSliderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JBHSliderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JBHSliderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
