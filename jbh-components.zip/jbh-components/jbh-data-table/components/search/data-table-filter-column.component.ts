import { Component, Input, Output, EventEmitter, ViewChild, OnInit, forwardRef } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import { Http, Response } from '@angular/http';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

const noop = () => {
};


@Component({
  selector: 'datatable-filter-column',
  template: `
    <div class="filter-column" [ngClass]="{'open': isOpen }">
      <div class="filter-column-row" (click)="showOrHideFilters()">
        <span>{{displayProperty}}</span>
        <span class="pull-right">({{this._filterValues.length}})<i class="icon" [ngClass]="{'icon-arrow-up': isOpen, 'icon-arrow-down': !isOpen}"></i></span>
      </div>
      
      <div #filterValuesContainer [hidden]="!(isOpen)">
        <div class="filter-column-detail">
          <div class="input-group input-group-sm">
            <input type="text" class="form-control">
          </div>
            <div class="filter-detail">
              <div *ngFor="let filterValue of _filterValues">
                <div class="filter-detail-row">
                  <input type="checkbox" name="filterValue" placeholder="search" />
                  <span>{{filterValue}}</span>
                </div>
                 
              </div>
            </div> 
            </div>
      </div>
    </div>
  `,
  styles: [`
    .filter-column {
      text-align: left;
      vertical-align: top;
      padding: 10px;
    }
     .filter-column.open {
        background: #e2e2e2;
    }
    
    .filter-column-row {
        user-select: none;
    }
   
    .filter-column-row i {
      padding-left: 10px;
    }
    
    .filter-column-detail {
      padding:10px 0px;
    }
    .filter-detail-row {
      padding-top: 10px;
    }
    .filter-detail-row span{
      padding-left: 5px;
    }
      
    
    `],
})
export class DataTableFilterColumnComponent {
  abstract;

  public isOpen = false;
  public _rows: any[] = [];
  public _searchProperty: string;
  public _displayProperty: string;
  public _filterValues: any[] = [];

  /**
   * The complete list of rows.
   */
  @Input() set rows(val: any[]) {
    this._rows = val;
    this.initializeFilterValues();
  }

  /**
   * Get the columns.
   *
   * @readonly
   * @type {any[]}
   * @memberOf JBHDataTableComponent
   */
  get rows(): any[] {
    return this._rows;
  }

  /**
   * The property of a list item that should be used for matching.
   */
  @Input() set searchProperty(val: string) {
    this._searchProperty = val;
    this.initializeFilterValues();
  }

  get searchProperty(): string {
    return this._searchProperty;
  }

  private initializeFilterValues() {
    this._filterValues = [];
    if (this._rows == null || this._rows.length === 0) return;
    for (let i = 0; i < this._rows.length; i++) {
      console.log('record:' + this._rows[i][this._searchProperty]);
      console.log('index:' + this._filterValues.indexOf(this._rows[i][this._searchProperty]));
      if (this._rows[i][this._searchProperty] && this._filterValues.indexOf(this._rows[i][this._searchProperty]) < 0) {
        this._filterValues.push(this._rows[i][this._searchProperty]);
      }
    }
  }


  /**
   * The property of a list item that should be used for matching.
   */
  @Input() set displayProperty(val: string) {
    this._displayProperty = val;
  }

  get displayProperty(): string {
    return this._displayProperty;
  }



  public showOrHideFilters() {
    this.isOpen = !(this.isOpen);
  }
}
