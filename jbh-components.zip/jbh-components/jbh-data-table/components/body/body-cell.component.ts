import { Component, Input, PipeTransform, HostBinding, Output, EventEmitter, HostListener, ElementRef, ViewContainerRef, ViewChild } from '@angular/core';

import { deepValueGetter, Keys } from '../../utils';
import { SortDirection } from '../../types';

@Component({
  selector: 'datatable-body-cell',
  template: `
    <div class="datatable-body-cell-label " [ngClass]="{'checkbox-alignment': column.checkboxable }" [ngSwitch]="true">
      <div
        *ngIf="column.checkboxable && checkboxIdentity(row)" 
        class="datatable-checkbox checkbox checkbox-body">
        <input 
          type="checkbox"
          [checked]="isSelected"
          (click)="onCheckboxChange($event)" 
        />
        <label></label>
      </div>
    <div
      *ngIf="column.isRadio && checkboxIdentity(row)" 
      class="radio radio-primary">
      <input 
        type="radio"
        [checked]="isSelected"
        (click)="onCheckboxChange($event)" 
      />
      <label></label>
    </div>

      
      <span [title]="toolTipValue"
        *ngIf="!column.cellTemplate"
        [innerHTML]="value">
      </span>
      
      <span [title]="toolTipValue"
        *ngIf="column.cellTemplate && cellTemplateFlag && column['name']===colReferenceName && !row.cellTemplate"
        [innerHTML]="value">
      </span>
      
      <ng-template #cellTemplate
        *ngIf="column.cellTemplate && !cellTemplateFlag"
        [ngTemplateOutlet]="column.cellTemplate"
        [ngOutletContext]="{ value: value, toolTipValue: toolTipValue, row: row, column: column }">
      </ng-template>
      
      <ng-template #cellTemplate
        *ngIf="column.cellTemplate && cellTemplateFlag && column['name']!==colReferenceName"
        [ngTemplateOutlet]="column.cellTemplate"
        [ngOutletContext]="{ value: value, toolTipValue: toolTipValue, row: row, column: column }">
      </ng-template>
      
      <ng-template #cellTemplate
        *ngIf="column.cellTemplate && cellTemplateFlag && column['name']===colReferenceName"
        [ngTemplateOutlet]="row.cellTemplate"
        [ngOutletContext]="{ value: value, toolTipValue: toolTipValue, row: row, column: column }">
      </ng-template>
      
      <span *ngIf="column.cellClass" class="{{column.cellClass}}"></span>
    </div>
  `,
})
export class DataTableBodyCellComponent {

  @Input() row: any;
  @Input() column: any;
  @Input() rowHeight: number;
  @Input() isSelected: boolean;
  @Input() maxChar: number;
  @Input() cellTemplateFlag: boolean;
  @Input() colReferenceName: string;
  @Input() checkboxIdentity: any;
  @ViewChild('cellTemplate', { read: ViewContainerRef }) cellTemplate: ViewContainerRef;

  isRowTemplate = false;

  @Input() set sorts(val: any[]) {
    this._sorts = val;
    this.calcSortDir = this.calcSortDir(val);
  }

  get sorts(): any[] {
    return this._sorts;
  }

  @Output() activate: EventEmitter<any> = new EventEmitter();

  @HostBinding('class.datatable-body-cell')
  get columnCssClasses(): any {
    let cls = 'datatable-body-cell';

    if (this.column.cssClasses) {
      cls += ' ' + this.column.cssClasses;
    }
    return cls;
  }

  @HostBinding('class.active')
  isFocused = false;

  @HostBinding('class.sort-active')
  get isSortActive(): boolean {
    return !this.sortDir;
  }

  @HostBinding('class.isCheckBoxCol')
  get isCheckBoxCol(): boolean {
    return this.column.checkboxable;
  }

  @HostBinding('class.sort-asc')
  get isSortAscending(): boolean {
    return this.sortDir === SortDirection.asc;
  }

  @HostBinding('class.sort-desc')
  get isSortDescending(): boolean {
    return this.sortDir === SortDirection.desc;
  }

  @HostBinding('style.width.px')
  get width(): number {
    return this.column.width;
  }

  @HostBinding('style.height')
  get height(): string | number {
    const height = this.rowHeight;
    if (isNaN(height)) {
      return height;
    }
    return height + 'px';
  }

  get toolTipValue(): any {
    if (!this.row || !this.column || !this.column.prop) {
      return '';
    }

    const val = deepValueGetter(this.row, this.column.prop);
    const userPipe: PipeTransform = this.column.pipe;

    if (userPipe) {
      return userPipe.transform(val);
    }

    if (val !== undefined) {
      return val.toString().replace(/<[^>]*>/g, '');
    }

    return '';
  }

  get value(): any {
    if (!this.row || !this.column || !this.column.prop) {
      return '';
    }



    const val = deepValueGetter(this.row, this.column.prop);
    const userPipe: PipeTransform = this.column.pipe;

    if (userPipe) {
      return userPipe.transform(val);
    }

    if (val !== undefined) {
      const str = val;

      if (str.toString().length > this.column.maxChar) {
        return (str.toString().slice(0, this.column.maxChar - 1) + '...');
      }
      return str;
    }

    return '';
  }

  sortDir: SortDirection;
  element: any;
  _sorts: any[];

  constructor(element: ElementRef) {
    this.element = element.nativeElement;
  }

  @HostListener('focus')
  onFocus(): void {
    this.isFocused = true;
  }

  @HostListener('blur')
  onBlur(): void {
    this.isFocused = false;
  }

  @HostListener('click', ['$event'])
  onClick(event: MouseEvent): void {
    this.activate.emit({
      type: 'click',
      event,
      row: this.row,
      column: this.column,
      value: this.value,
      toolTipValue: this.toolTipValue,
      cellElement: this.element
    });
  }

  @HostListener('dblclick', ['$event'])
  onDblClick(event: MouseEvent): void {
    this.activate.emit({
      type: 'dblclick',
      event,
      row: this.row,
      column: this.column,
      value: this.value,
      toolTipValue: this.toolTipValue,
      cellElement: this.element
    });
  }

  @HostListener('keydown', ['$event'])
  onKeyDown(event: KeyboardEvent): void {
    const keyCode = event.keyCode;
    const isTargetCell = event.target === this.element;

    const isAction = keyCode === Keys.return ||
      keyCode === Keys.down ||
      keyCode === Keys.up ||
      keyCode === Keys.left ||
      keyCode === Keys.right;

    if (isAction && isTargetCell) {
      event.preventDefault();
      event.stopPropagation();

      this.activate.emit({
        type: 'keydown',
        event,
        row: this.row,
        column: this.column,
        value: this.value,
        toolTipValue: this.toolTipValue,
        cellElement: this.element
      });
    }
  }

  onCheckboxChange(event): void {
    this.activate.emit({
      type: 'checkbox',
      event,
      row: this.row,
      column: this.column,
      value: this.value,
      toolTipValue: this.toolTipValue,
      cellElement: this.element
    });
  }

  calcSortDir(sorts: any[]): any {
    if (!sorts) {
      return;
    }

    const sort = sorts.find((s: any) => {
      return s.prop === this.column.prop;
    });

    if (sort) {
      return sort.dir;
    }
  }

}
