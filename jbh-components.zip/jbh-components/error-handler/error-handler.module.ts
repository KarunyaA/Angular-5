import { ErrorHandler, ModuleWithProviders, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ErrorHandlerService } from './error-handler.service';

@NgModule({
    declarations: [],
    exports: [],
    imports: [],
    providers: [
        { provide: ErrorHandler, useClass: ErrorHandlerService }
    ]
})
export class ErrorHandlerModule {
    static forRoot(): ModuleWithProviders {
        return {
            ngModule: ErrorHandlerModule,
            providers: [
                ErrorHandlerService
            ]
        };
    }
}
