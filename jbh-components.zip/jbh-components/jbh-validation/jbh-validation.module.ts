import { ModuleWithProviders, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { JbhValidationComponent } from './jbh-validation.component';
import { ValidationService } from './validation.service';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [JbhValidationComponent],
  exports: [JbhValidationComponent]
})
export class JbhValidationModule {
  static forRoot(): ModuleWithProviders {
    return { ngModule: JbhValidationModule, providers: [ValidationService] };
  }
}
