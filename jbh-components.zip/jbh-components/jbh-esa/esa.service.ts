import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions } from '@angular/http';
import { UserService } from './user.service';
import { Location } from '@angular/common';

@Injectable()
export class EsaService {

  constructor(
    private http: Http,
    public userService: UserService,
    location: Location) { }

  load() {
    let esaURL: string;
    let path: any;
    path = location.pathname.split('/');
    esaURL = '/' + path[1] + '/user';
    if (UserService.URL) {
      esaURL = UserService.URL;
    }

    console.log("esaurl", esaURL);

    return new Promise((resolve) => {
	  
        const headers = new Headers();
        headers.append('Cache-Control', 'no-cache');
        headers.append('Pragma', 'no-cache');
		const defaultOptions = new RequestOptions({
            headers: headers
        });
      this.http.get(esaURL,defaultOptions).map(res => res.json())
        .subscribe(data => {
          const me = this;
          this.userService.userDetails = data;
          resolve(null);
        }, error => {
          console.error('INITIALIZATION:', error);
          this.userService.userDetails = error;
          resolve(null);
        });
    })
  }
}
