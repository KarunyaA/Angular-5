import { TestBed, inject } from '@angular/core/testing';

import { TimeoutNotifierService } from './timeout-notifier.service';

describe('TimeoutNotifierService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [TimeoutNotifierService]
    });
  });

  it('should ...', inject([TimeoutNotifierService], (service: TimeoutNotifierService) => {
    expect(service).toBeTruthy();
  }));
});
