import { Injectable } from '@angular/core';
import * as moment from 'moment';
import 'moment-timezone';
import { Md5 } from 'ts-md5/dist/md5';

@Injectable()
export class UtilityFunctionsService {

	getUtilities(): any {
		const utils = {
			isValueEmpty: function (val: any) {
				/*test results
				---------------
				[]        true, empty array
				{}        true, empty object
				null      true
				undefined true
				""        true, empty string
				''        true, empty string
				0         false, number
				true      false, boolean
				false     false, boolean
				Date      false
				function  false*/

				if (val === undefined)
					return true;
				if (typeof (val) == 'function'
					|| typeof (val) == 'number'
					|| typeof (val) == 'boolean'
					|| Object.prototype.toString.call(val) === '[object Date]')
					return false;
				if (val == null || val.length === 0)        // null or 0 length array
					return true;
				if (typeof (val) == 'object') {
					// empty object
					var r = true;
					for (var f in val)
						r = false;
					return r;
				}
				return false;
			},

			getTimeZoneAbbr: function (zoneId: string, offsetDateTime: string): string {
				if (zoneId && offsetDateTime) {
					return moment(offsetDateTime).tz(zoneId).format('z');
				}
				return 'One or more the params are empty';
			},

			objectToQuerystring: function (obj: any, url?: string): string {
				url = url ? url : '';
				obj = obj ? obj : {};
				const queryString: string = Object.keys(obj).reduce(function (str, key, i) {
					let delimiter: string;
					let val: string;
					delimiter = (url.indexOf('?') < 0 && i === 0) ? '?' : '&';
					key = encodeURIComponent(key);
					val = encodeURIComponent(obj[key]);
					return [str, delimiter, key, '=', val].join('');
				}, '');
				return url + queryString;
			},

			queryStringToObject: function (queryString: any): any {
				if (queryString.indexOf('?') > -1) {
					queryString = queryString.split('?')[1];
				}
				const pairs = queryString.split('&');
				const result = {};
				pairs.forEach(function (pair) {
					pair = pair.split('=');
					result[pair[0]] = decodeURIComponent(pair[1] || '');
				});
				return result;
			},

			getURLBasePath(url: string): string {
				const path: any = new URL(url);
				return path.pathname + (path.search ? path.search : '');
			},

			getHashKey(data: string): any {
				return Md5.hashStr(data);
			}
		}
		return utils;
	}

}

