import { ModuleWithProviders, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpModule } from '@angular/http';

import { ApiClientService } from './api-client.service';
import { LoggerService } from './logger.service';
import { ShortcutkeyService } from './shortcutkey.service';
import { AppSharedDataService } from './app-shared-data.service';
import { MouseEventService } from './mouseevent.service';
import { BroadcasterService } from './broadcaster.service';
import { LocalStorageService } from './local-storage.service';
import { WebSocketService } from './web-socket.service';
import { HttpInterceptorService } from './http-interceptor.service';
import { TimeoutNotifierService } from './timeout-notifier.service';
import { UtilityFunctionsService } from './utility-functions.service';

@NgModule({
  imports: [
    CommonModule,
    HttpModule
  ],
  declarations: []
})

export class JbhCoreServicesModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: JbhCoreServicesModule,
      providers: [
        ApiClientService,
        LoggerService,
        ShortcutkeyService,
        AppSharedDataService,
        MouseEventService,
        BroadcasterService,
        LocalStorageService,
        WebSocketService,
        HttpInterceptorService,
        TimeoutNotifierService,
		UtilityFunctionsService
      ]
    };
  }
}
