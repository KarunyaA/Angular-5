import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/filter';
import 'rxjs/add/operator/map';

interface BroadcastEvent {
  key: any;
  data ?: any;
}

@Injectable()
export class BroadcasterService {

  private _eventBus: BehaviorSubject < BroadcastEvent > ;

  constructor() {
    this._eventBus = new BehaviorSubject < BroadcastEvent > ({ key: 'test', data: 'test' });
  }

  broadcast(key: any, data ?: any): void {
    this._eventBus.next({ key, data });
  }

  on < T >(key: any): Observable < T > {
    return this._eventBus.asObservable()
      .filter(event => event.key === key)
      .map(event => event.data as T);
  }
}
