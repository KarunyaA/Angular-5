import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Injectable()
export class AppSharedDataService {

    private sharingData: BehaviorSubject<string[]>;
    private shareNotificationCount = new BehaviorSubject({});

    constructor() {
        this.sharingData = <BehaviorSubject<string[]>>new BehaviorSubject([]);
        this.shareNotificationCount = <BehaviorSubject<string[]>>new BehaviorSubject([]);
    }

    saveData(data): void {
        this.sharingData.next(data);
    }

    getData() {
        return this.sharingData.asObservable();
    }
    saveNotificationCountData(data): void {
        this.shareNotificationCount.next(data);
    }

    getNotificationCountData() {
        return this.shareNotificationCount.asObservable();
    }
}
