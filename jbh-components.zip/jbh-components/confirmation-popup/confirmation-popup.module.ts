import { ModuleWithProviders, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ConfirmationPopupComponent } from './confirmation-popup.component';
import { BsDropdownModule } from 'ngx-bootstrap';
import { ModalModule } from 'ngx-bootstrap';

@NgModule({
  imports: [
    CommonModule,
    BsDropdownModule,
    ModalModule
  ],
  declarations: [ConfirmationPopupComponent],
  exports: [ConfirmationPopupComponent]
})
export class ConfirmationPopupModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: ConfirmationPopupModule,
      providers: []
    };
  }
}
