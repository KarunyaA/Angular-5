import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';

@Component({
  selector: 'app-confirmation-popup',
  templateUrl: './confirmation-popup.component.html',
  styleUrls: ['./confirmation-popup.component.scss']
})
export class ConfirmationPopupComponent implements OnInit {

    @ViewChild('deleteButtonModal') deleteButtonModal;
    @Input() popupMessage: string;
    @Output() confirmEvent = new EventEmitter < any > ();

    constructor() {}

    ngOnInit() {}

    onConfirmingAction(confirmAction: boolean) {
        const Obj = {
            'model': this.deleteButtonModal,
            'flag': confirmAction
        };
        this.confirmEvent.emit(Obj);
    }
}
