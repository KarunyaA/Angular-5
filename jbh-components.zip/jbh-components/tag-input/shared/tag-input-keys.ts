export const KEYS = {
  backspace: 8,
  comma: 188,
  downArrow: 40,
  enter: 13,
  esc: 27,
  space: 32,
  upArrow: 38
};
