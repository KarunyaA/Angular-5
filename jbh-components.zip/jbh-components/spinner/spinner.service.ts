import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Observer } from 'rxjs/Observer';

@Injectable()
export class SpinnerService {
  spinnerObservable: Observable<boolean>;
  spinnerText: string;
  showStatus = false;
  private spinnerObserver: Observer<boolean>;

  constructor() {
    this.spinnerObservable = new Observable<boolean>(observer => {
      this.spinnerObserver = observer;
      this.spinnerText = 'Loading Page Components ...';
    }
    ).share();
  }

  show() {
    this.showStatus = true;
    if (this.spinnerObserver) {
      this.spinnerObserver.next(true);
    }
  }

  hide() {
    this.showStatus = false;
    if (this.spinnerObserver) {
      this.spinnerObserver.next(false);
    }
  }
}
