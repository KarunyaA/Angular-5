import { Component, EventEmitter, Input, Output, OnInit, ViewChildren } from '@angular/core';
import { Subject } from 'rxjs/Subject';
@Component({
    selector: 'jbh-search-filter',
    templateUrl: './jbh-search-filter.component.html',
    styleUrls: ['./jbh-search-filter.component.scss']
})
export class JbhSearchFilterComponent implements OnInit {

    /***************** Variable Declaration ****************/
    @Input() filterList: any[];
    @Input() closeOthers: boolean;
    @Input() filterTitle: string;
    @Input() filterTabIndex: string;
    @Input() isDateRange: string;
    @Input() timePickerFlag: boolean;
    @Output() checkedEvent = new EventEmitter<any>();
    @Output() searchEvent = new EventEmitter<any>();
    @Output() clickEvent: EventEmitter<number> = new EventEmitter<number>();
    @Output() typeaheadEvent = new EventEmitter<any>();
    @Output() DatechangedEvent = new EventEmitter<any>();
    @Output() onKeyEnterEvent = new EventEmitter<any>();
    @Output() timepickerchangedEvent = new EventEmitter<any>();
	@Output() clickResetAllEvent: EventEmitter<number> = new EventEmitter<number>();
    @Output() freetextChangedEvent = new EventEmitter<any>();
    @Output() closeEvent = new EventEmitter < any > ();
	@ViewChildren('resetCount') resetCount;

    @Input() count: any = [];
	@Input() resetAll: boolean = false;
    typeAheadSubject = new Subject < string > ();
	flagShowHide = false;
    isOpen = '';
    solicitorDataList: any[];
	cnt: Number = 0;
    resetCheckAllValue: Number = 0;
    bgColor = false;
	resetAllFlag = false;

    /***************** System Provided Methods ****************/
    constructor() { }

    ngOnInit() {
        this.typeAheadSubject
        .debounceTime(1000)
        .distinctUntilChanged()
        .subscribe((value) => {
            this.typeaheadEvent.emit(value);
        });
    }
    /******************  Filter Component Events  ********************/
    toggle(eve, val, bodyContent, headContent) {
        if (bodyContent.style.display === 'none') {
            this.flagShowHide = true;
            val['isOpen'] = true;
            bodyContent.style.display = 'block';
            headContent.style.backgroundColor = '#f9f9f9';
            this.bgColor = true;
        } else {
            val['isOpen'] = false;
            bodyContent.style.display = 'none';
            this.bgColor = false;
            headContent.style.backgroundColor = '#ffffff';
        }
    }

    changeEvent(object) {
        this.count[object.num] = object.count;
        this.checkedEvent.emit(object);
    }
    datechangeEventcall(object) {
        this.DatechangedEvent.emit(object);
    }
    timepickerchangeEventcall(eve) {
        this.timepickerchangedEvent.emit(eve);
    }
    searchCallOnClick(object) {
        this.searchEvent.emit(object);
    }
    /***************** OnReset Btn Click Reset all the checkbox ****************/
	resetCheckValue(eve) {
		this.count[eve] = '';
		if (!this.resetAllFlag) {
        this.clickEvent.emit(eve);
		}
		if (eve === this.filterList.length-1) {
			this.resetAllFlag = false;
		}
    }
	resetAllCheckValue() {
        /*this.clickResetAllEvent.emit();
        this.cnt = Number(this.cnt) + Number(1);
        this.resetCheckAllValue = this.cnt;*/
		this.resetAllFlag = true;
		let filterArray = this.filterList;
		for(let i=0;i<filterArray.length;i++) {
				this.resetCount['_results'][i].resetCheckValue(i);
				filterArray[i].count = 0;
		}
		this.filterList = filterArray;
		this.clickResetAllEvent.emit();
    }

    /***************** typeAhead search query  ****************/
    typeAheadSearchCall(eve) {
        this.typeAheadSubject.next(eve);
    }
    onKeyEnter(eve) {
        this.onKeyEnterEvent.emit(eve);
    }
    onFreetextChangedEvent(eve): void {
        this.freetextChangedEvent.emit(eve);
    }
    /***************** On click of close button ****************/
    onClickClose(): void {
        this.closeEvent.emit();
    }
}
