package com.jbhunt.ordermanagement.interceptor;

import java.io.IOException;

import javax.servlet.http.HttpSession;

import lombok.extern.slf4j.Slf4j;

import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;


/**
 * This is a custom interceptor extending ClientHttpRequestInterceptor that
 * handles sending the Authorization & usernametoken as a header to the Secure
 * services running in JBossFuse.
 */
@Slf4j
public class BasicAuthInterceptor implements ClientHttpRequestInterceptor {

	private final String username;
	private final String password;

	private static final String SESS_USER = "jbhSecurityUserId";

	/**
	 * The username & password are injected from the securePid.
	 * 
	 * @param username
	 * @param password
	 */
	public BasicAuthInterceptor(String username, String password) {
		this.username = username;
		this.password = password;
	}

	@Override
	public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution) throws IOException {

		log.info("BasicAuthInterceptor.intercept() is called");

		// Build the auth-header
		final String auth = username + ":" + password;
		final byte[] encodedAuth = Base64.encodeBase64(auth.getBytes());
		final String authHeader = "Basic " + new String(encodedAuth);

		// Add the auth-header
		request.getHeaders().add("Authorization", authHeader);
		request.getHeaders().add("usernametoken", getUserId());

		log.info("User ID**"+getUserId());
		log.info("Headers**:"+request.getHeaders());		
		log.debug("User ID**"+getUserId());	
		log.debug("Headers**:"+request.getHeaders()); 
	
		return execution.execute(request, body);
	}

	/**
	 * The userId is retrieved from the session variable "jbhSecurityUserId"
	 * which will be set when the user performs the SSO login.
	 * 
	 * @param request
	 * @return userId
	 */
	private String getUserId() {
		ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
		HttpSession session = attr.getRequest().getSession(true);
		if (session.getAttribute(SESS_USER) != null) {
			return session.getAttribute(SESS_USER).toString().trim().toUpperCase();
		}
		return null;
	}
}
