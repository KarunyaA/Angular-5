
package com.jbhunt.ordermanagement.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.cache.ehcache.EhCacheCacheManager;
import org.springframework.cache.ehcache.EhCacheManagerFactoryBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.UrlResource;
import org.springframework.context.annotation.Primary;

import com.jbhunt.ordermanagement.properties.OrderProperties;

@Configuration
public class EhCacheConfiguration {

	@Autowired
	private OrderProperties properties; 
	
	@Bean
	@Primary
	public CacheManager supplyChainManagementCacheManager() throws Exception {
		return new EhCacheCacheManager(getEhCacheFactory().getObject());
	}	
	
	@Bean
	public EhCacheManagerFactoryBean getEhCacheFactory() throws Exception {
		EhCacheManagerFactoryBean factoryBean = new EhCacheManagerFactoryBean();
		factoryBean.setConfigLocation(new UrlResource(properties.getEhcacheUrl()));
		return factoryBean;
	}


}
