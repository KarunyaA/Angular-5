import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header-dummy',
  templateUrl: './header-dummy.component.html',
  styleUrls: ['./header-dummy.component.scss']
})
export class HeaderDummyComponent implements OnInit {

  applicationName = 'ORDER';
  constructor() { }

  ngOnInit(): void {
  }

}
