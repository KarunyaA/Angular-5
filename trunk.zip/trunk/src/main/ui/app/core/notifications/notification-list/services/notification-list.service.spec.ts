import { TestBed, inject } from '@angular/core/testing';

import { NotificationListService } from './notification-list.service';

describe('NotificationListService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [NotificationListService]
    });
  });

  it('should be created', inject([NotificationListService], (service: NotificationListService) => {
    expect(service).toBeTruthy();
  }));
});
