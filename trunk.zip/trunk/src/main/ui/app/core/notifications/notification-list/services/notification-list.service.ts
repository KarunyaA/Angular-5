import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Response } from '@angular/http';
import { JBHGlobals } from '../../../../app.service';
@Injectable()
export class NotificationListService {

  constructor(private jbhGlobals: JBHGlobals) { }
  getNotificationServiceList(loggedInUserId) {
    return this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.notificationlist + '?userId=' +
      loggedInUserId, '', false);
  }
  updateNotificationDetails(notificationId) {
    return this.jbhGlobals.apiService.patchData(this.jbhGlobals.endpoints.order.selectedNotificationListClick +
      '/' + notificationId, '', false);
  }
}
