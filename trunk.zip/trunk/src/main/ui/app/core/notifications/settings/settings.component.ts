import { Component, OnInit } from '@angular/core';
import { NgFor } from '@angular/common';
import { JBHGlobals } from '../../../app.service';
import { SettingsService } from './services/settings.service';

@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.scss'],
  providers: [SettingsService]
})
export class SettingsComponent implements OnInit {
  serviceList = [];
  constructor(public jbhGlobals: JBHGlobals, public settingsService: SettingsService) { }
  ngOnInit() {
    this.settingsService.getSettingList().subscribe(resFetchData => this.serviceList = resFetchData);
  }
}
