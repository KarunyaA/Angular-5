import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'searchFilter'
})
export class SearchFilterPipe implements PipeTransform {

  transform(notificationCriteria: any, term: any): any {
    if (term === undefined) { return notificationCriteria };
    return notificationCriteria.filter(function (value) {
      return value.notificationTitle.toLowerCase().includes(term.toLowerCase());
    });
  }
}
