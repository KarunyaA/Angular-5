import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TabsModule } from 'ngx-bootstrap';
import { FormsModule } from '@angular/forms';
// import { MomentModule } from 'angular2-moment';
import { NotificationListComponent } from './notification-list/notification-list.component';
import { SettingsComponent } from './settings/settings.component';
import { TaskListComponent } from './task-list/task-list.component';
import { SearchFilterPipe } from './search-filter.pipe';

@NgModule({
  imports: [
    CommonModule,
    TabsModule,
    FormsModule
    // MomentModule
  ],
  declarations: [NotificationListComponent, SettingsComponent, TaskListComponent, SearchFilterPipe],
  exports: [NotificationListComponent, SettingsComponent, TaskListComponent, SearchFilterPipe]
})
export class NotificationsModule { }
