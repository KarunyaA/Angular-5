import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule, PlatformLocation } from '@angular/common';
import { TabsModule } from 'ngx-bootstrap';

import { SimpleNotificationsModule } from 'angular2-notifications';
import { PerfectScrollbarConfigInterface, PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { SpinnerModule, SpinnerService } from 'jbh-components/spinner';
import { CoreModule } from './core/core.module';
import { JbhCoreServicesModule } from 'jbh-components/jbh-core-services';
import { ErrorHandlerModule, JbhValidationModule } from 'jbh-components';
import { TemplateJsonTransformerService } from './features/create-orders/templates/services/template-json-transformer.service';
import { TemplateStopsJsonTransformerService } from './features/create-orders/templates/services/template-stops-json-transformer.service';
import { JbhJsonTransformerService } from './features/create-orders/orders/services/jbh-json-transformer.service';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { JBHGlobals } from './app.service';
import { BusinessUnitService, JbhEsaModule, UserService } from 'jbh-components/jbh-esa';
import { ErrorsModule } from 'jbh-components/errors';
import { TimeoutNotifierService } from 'jbh-components/jbh-core-services/timeout-notifier.service';
import { NgIdleKeepaliveModule } from '@ng-idle/keepalive';
import { SidebarRightModule } from './core/sidebar-right/sidebar-right.module';

import { OrderService } from './features/create-orders/orders/services/order.service';
import { TemplateService } from './features/create-orders/templates/services/template.service';
import { ScreenSizeService } from './shared/screen-size.service';

const PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  suppressScrollX: false,
  minScrollbarLength: 10,
  maxScrollbarLength: 50
};
// UserService.URL = 'data/esaorder.json';
@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    CommonModule,
    CoreModule,
    TabsModule.forRoot(),
    AppRoutingModule,
    SidebarRightModule,
    SimpleNotificationsModule.forRoot(),
    PerfectScrollbarModule.forRoot(PERFECT_SCROLLBAR_CONFIG),
    ErrorHandlerModule,
    JbhEsaModule.forRoot(),
    ErrorsModule.forRoot(),
    SpinnerModule.forRoot(),
    JbhCoreServicesModule.forRoot(),
    JbhValidationModule.forRoot(),
    NgIdleKeepaliveModule.forRoot()
  ],
  providers: [
    JBHGlobals,
    JbhJsonTransformerService,
    TemplateService,
    TemplateJsonTransformerService,
    TemplateStopsJsonTransformerService,
    TimeoutNotifierService,
    OrderService,
    ScreenSizeService
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
 /* constructor(private platformLocation: PlatformLocation) {
    let hostName: any;
    if (this.platformLocation && this.platformLocation['location']
      && this.platformLocation['location']['host']) {
      hostName = this.platformLocation['location']['host'];
      if ((hostName.indexOf('order-tst') === -1 ? (hostName.indexOf('order-prof') === -1 ? true : false) : false)) {
        UserService.URL = 'data/esaorder.json';
      }
    }
  } */
}
