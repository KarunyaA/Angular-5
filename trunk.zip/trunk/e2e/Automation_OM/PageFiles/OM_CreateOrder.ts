﻿import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";
import { Update_Objects } from "../ObjectRepository/Objects_Order"
import { Key, WebElement } from "selenium-webdriver";
import { ExcelReader } from "../CommonFiles/ReadFromXL"
import { DataDictionary } from "../DataFiles/DictionaryData"
import { ReusableFunctions } from "../FunctionalLibrary/ReusableFunctions"
import { CommonFunctions } from "../FunctionalLibrary/CommonFunctions"
var common = new CommonFunctions()
var DictBU_OM = new DataDictionary();
var DictBU_EOM = new DataDictionary();
var OrderID;
let OBJCreate = new Update_Objects();
var ReadFromXL = new ExcelReader();
var DataDictLib = new DataDictionary();
var DataDictLib1 = new DataDictionary();
let reuse = new ReusableFunctions();
var ExcelDataSourceForConf = require('../CommonFiles/ReadFromXL');
var PushAndPullDataDictLib = require('../DataFiles/DictionaryData');
/////////////////////////////////////////////////////////////////////////////////////////////////
var icon_loading = element(by.xpath("//*[@class='spinner' and @role='progressbar']"));
////////////////////////////////////////// Create Order Page ///////////////////////////////////////////////////////////////////////////////

var BillTo = element(by.css("[id=\"billtoaccount\"]"));
var BillToValue = element(by.xpath("//ul[@class=\"dropdown-menu\"]//li[@class=\"active\"]//a"));
var BTContact = element(by.css("[placeholder=\"Bill To Account Contact\"]"));
var ContactValue = element(by.xpath("//ul[@class=\"ui-select-choices dropdown-menu\"]//li//div[@class=\"ui-select-choices-row active\"]//a"));
var BU = element(by.xpath("//*[@formcontrolname='financeBusinessUnitCode']//i[2]"));
var BUclick = element(by.xpath("//input[@placeholder='Business Unit']"));
var BUValue = element(by.xpath("//*[@id='financeBusinessUnitCode']//ul//a/div"));
var SO = element(by.xpath("//ng-select[@formcontrolname='serviceOfferingCode']//i[2]"));
var SOclick = element(by.xpath("//input[@placeholder='Service Offering']"));
var SOValue = element(by.xpath("//ul[@class=\"ui-select-choices dropdown-menu\"]//li//a[contains(text(),'OTR')]/ancestor::a"));
var OPOwner = element(by.css("[id=\"operationalOwner\"]"));
var OPValue = element(by.xpath("//ul[@class=\"dropdown-menu\"]//li[@class=\"active\"]//a"));
var NextButton = element(by.buttonText("Next"));
var Tradingpartner = element(by.css("[formcontrolname='tradingPartnerCode']"));
var InfoIcon = element(by.id(`btn-billToAcnt`));


//ADD Stop objects:
var Location = element(by.css("[formcontrolname='locationID']"));
var LocationContact = element(by.css("[placeholder='Contact']"));
var DestinationTab = element(by.xpath("//i[@class='glyphicon accordianIcon icon-jbh_expand']"));
var TemplateDestinationTab = element(by.xpath("//i[@class='glyphicon accordianIconCustomize textBold icon-jbh_expand']"));
var AddStopDestinationTab = element.all(by.xpath("//i[@class='glyphicon accordianIcon icon-jbh_expand']"));
var TemplateAddStopDestinationTab = element.all(by.xpath("//i[@class='glyphicon accordianIconCustomize textBold icon-jbh_expand']"));
var PalletChckBX = element(by.xpath("//a[@class='list-group-item']//following::input[@type='checkbox']"));;
var MultiplePalletChckBX = element.all(by.xpath("//a[@class='list-group-item']//following::input[@type='checkbox']"));;
var TemplatePalletChckBX = element(by.xpath("//a[@class='list-group-item']//following::input[@type='checkbox']"));;
var SaveButton = element(by.buttonText("Save"));
var Savebuttonreject = element.all(by.xpath("//button[@id='btn-save' and text()='Save']"));
var ItmdescDD = element(by.xpath("//ul[@class='dropdown-menu']//li[@class='active']//a//h5"));
var scac = element(by.xpath("//*[@placeholder='SCAC']"));
var scacsearch = element(by.xpath("//span[text()='SCAC ']"));
var scactext = element(by.xpath("//div[@class='panel-heading']//span[text()='SCAC ']//following::input[1]"))
var scacenter = element(by.xpath("//div[@class='panel-heading']//span[text()='SCAC ']//following::span[1]"))
var three_dotOtr = element.all(by.xpath("//span[text()='OTR']//following::button[@id='btn-popOver']"));
var three_dotInter = element.all(by.xpath("//span[text()='Intermodal']//following::button[@id='btn-popOver']"));
var three_dotLTL = element.all(by.xpath("//span[text()='LTL']//following::button[@id='btn-popOver']"));
var ViewTemplate = element(by.xpath("//a[text()='View Template']"));
var copy_view = element.all(by.xpath("//span[text()='OTR']//following::button[@id='btn-popOver']//following::div/ul/li/a']"));
var threedot_temp = element(by.xpath("//button[@id='btn-popOver']"));
var tempdrop = element.all(by.xpath("//button[@id='btn-popOver']//following::div/ul/li/a[text()='Create Order']"));
var apnmt_ordovrview = element(by.xpath("//div[text()='Scheduled Appointment ']//following::span[1]/span[1]"));
var apnmt_stop = element(by.xpath("//span[text()='Origin']//following::span[@class='pad0 font-styles'][1]"));
var Utilitiesicon = element(by.id("i-ManageOverlay"));
var toollist = element.all(by.xpath("//div[@class='panel-body']/tabset/ul/li/a"));
var addComment = element(by.css("[formcontrolname='commentLevel']"));
var addCommenttext = element(by.xpath("//*[@id='commentLevel']//div//input"));
var templateType = element(by.xpath("//*[@id='span-optional']//following::div[1]//div[1]//span[1]//span"));
var templatetypetext = element(by.xpath("//*[@id='span-optional']//following::div[1]//div[1]//input[1]"));
var Commenttext = element(by.css("[formcontrolname='commentTxtarea']"));
var Savebutton = element.all(by.buttonText("Save"));
var SavebuttonCommnt = element(by.xpath("//textarea[@formcontrolname='commentTxtarea']//following::button[text()='Save'][1]"));
var addedutilityref = element(by.xpath("//div[@class='ps-content']//div//span[@class='instItmLvldesc']//p"));
var apntEditcmnt = element(by.xpath("//*[@class='editDisable hidden-xs hidden-sm hidden-md editEnable']"));
var apntEditRef = element(by.xpath("//h4[text()='Order']//following::div[1]/div"));
var UtilEditCharge = element(by.xpath("//strong[text()='ORDER']"));
var utilityedit = element(by.css("[id='a-edit']"));
var Utilrefdelete = element(by.xpath("//h4[text()='Order']//following::div[1]/div//a[@id='a-delete']"));
var UtilrefEdit = element(by.xpath("//h4[text()='Order']//following::div[1]/div//a[@id='a-edit']"));
var Utilchargedelete = element(by.xpath("//strong[text()='ORDER']//following::a[@id='a-delete']"));
var UtilChargeEdit = element(by.xpath("//strong[text()='ORDER']//following::a[@id='a-edit']"));
//document
var browse= element(by.xpath("//*[@id='span-jbhSearch']"))
//reference
var Refercmnt = element(by.xpath("//input[@placeholder='Reference Value']"));
var ReferenceType = element(by.xpath("//ng-select[@placeholder='Reference Type']//i[2]"))
var ReferenceTyp = element(by.xpath("//ng-select[@placeholder='Reference Type']"))
var ReferenceType1 = element(by.css('[id="RefType"]')).element(by.cssContainingText('option', 'Bill of Lading'))
var savebutton1 = element.all(by.xpath("//label[text()='Reference Value']//following::button[@class='btn-dark-primary'][1]"));
var AddbuttonRef = element(by.xpath("//button[@id='btn-add' and @name='refSave']"));
var Addbutton = element.all(by.xpath("//h3[contains(text(),'Add a Reference')]//following::button[text()='Add'][1]"));
var Addbuttoncharge = element.all(by.xpath("//button[@id='btn-add' ]"));
//charge
var Chargelevel = element(by.css('[formcontrolname="chargeLevelTypeCode"]'))
var chargecode = element(by.id("chargeDescriptionTxt"));
var chargeamount = element(by.id("chargeUnitRateAmountTxt"));
var chargequantity = element(by.id("chargeQuantityTxt"));
var authno = element(by.id("customerAuthorizationNumberTxt"));
var authby = element(by.id("customerAuthorizationFirstNameTxt"));
var originstopedit = element(by.xpath("//span[text()='Origin']//following::span[@id='span-ritArr'][1]"));
var pickupstopedit = element(by.xpath("//span[text()='Origin']//following::span[@id='span-ritArr'][2]"));
var editbtn = element(by.id("span-jbhedit"));
var requestedservices = element(by.xpath("//h3[text()='Requested Service(s)']//following::input[@role='combobox'][1]"));
var miles = element(by.xpath("//button[@id='btn-info']//following::div[@class='col-md-1']/span"));
var TotalMiles = element(by.xpath("//span[text()='Total Miles']//following::span[1]"));
//Instruction
var txt_instruction=element(by.xpath("//*[@placeholder='Instruction']"));
var dd_TagsInstr = element(by.css('[formcontrolname="instrTagInst"]'));
var btn_SaveIntruction=element.all(by.xpath("//h3[text()='Add an Instruction']//following::button[@id='btn-save']"));
//Multiple stops
var stopdots = element(by.css("[class='dots-span']"));

var stopdotstemplate = element(by.css("[id='span-locDetails']"));
var addstop = element(by.xpath("//a[text()='Add Stop']"));;
var stopstitle = element.all(by.xpath("//div[@class='accordion-toggle']"));
var expandicon = element.all(by.xpath("//i[@class='glyphicon accordianIcon icon-jbh_expand']"));
var expandiconTemplate = element.all(by.xpath("//i[@class='glyphicon accordianIconCustomize textBold icon-jbh_expand']"));
var StopReason = element(by.id("stopReason"));
var StopReasonText = element(by.xpath("//li/div/a/div[text()='Pickup']"));

var interservice = element(by.id("serviceType"));
var interservicetext = element(by.xpath("//*[@id='serviceType']//span[@class='ui-select-match']//following::input[1]"));
var inbondToggle = element(by.xpath("//*[@for='inbond-freight' and @class='jbh-toggle-label']"));
var shipmentreq = element(by.id("shipment-requirement"));
var shipmentreqText = element(by.xpath("//*[@id='shipment-requirement']//span[@class='ui-select-match']//following::input[1]"));
var ordernumber = element(by.className("ordernumber"));
var freightcharges = element(by.id("freightChargeTermTypeCode"));
var freightchargestext = element(by.xpath("//input[@placeholder='Freight Charge Terms']"));
var trailernobutton = element(by.buttonText("Trailer Number"));
var Trailernumber = element(by.xpath("//input[@placeholder='Trailer Number']"));
var Trailerprefix = element(by.xpath("//span[text()='Trailer Prefix']"));
var TrailerPrefixText = element(by.xpath("//input[@placeholder='Trailer Prefix']"));
var ShipmentIdentificationNo = element(by.xpath("//input[@placeholder='Shipment Identification']"));
var shippromarytype = element(by.id("orderTypeCode"));
var shipsecndarytype =  element(by.css("[formcontrolname='orderSubTypeCode']"));//element(by.id("orderSubTypeCode"));
var shipsecndarytypetext = element(by.xpath("//input[@placeholder='Secondary Order Type']"));
var ordervalue = element(by.id("order-value"));
var fleetcode = element(by.id("fleetCode"));
var appointmentMinReq=element(by.xpath("//h3[text()='Requested Appointments']//following::*[@formcontrolname='minutes'][2]"));
var AddappointmentIcon = element(by.xpath("//a[@id='a-addNwAppt2']"));
var icon_Additem = element(by.xpath("//a[@id='a-add-NwItem']"));
var AddappointmentIconReq = element(by.id("a-adNwAppt"));
var AddappointmentIconSch = element(by.xpath("//h3[text()='Requested Appointments']//following::*[@formcontrolname='appointmentEndDate'][1]//input[1]"));
var AddappointmentIconschedule = element(by.xpath("//p[text()='Primary Appointment']//following::h3[text()='Scheduled Appointments']//following::i[1]"));
var tagname = element.all(by.css("[formcontrolname='packagingUnitTypeQuantity']"));
var tagname1 = element.all(by.css("[formcontrolname='itemWeight']"));
var tagname2 = element.all(by.css("[formcontrolname='itemDescription']"));
var itemunit = element.all(by.css("[formcontrolname=\"itemHeight\"]"));
var itemchar = element.all(by.css("[formcontrolname='itemCharacteristics']"));
var itemcharname = element.all(by.css("[formcontrolname='itemCharacteristics']"));
var NMFCNumber = element.all(by.css("[formcontrolname='freightClassCode']"));
var PickDateorderOverview = element(by.xpath("//div[text()='Scheduled Appointment']//following::span[1]"));
var DelidateorderOverview = element(by.xpath("//div[text()='Scheduled Appointment']//following::span[2]"));
var itemchar_type = element(by.xpath("//*[@placeholder='Item Characteristics']"));
var unnacode = element(by.xpath("//*[@id='unnaCode']"));
var shippingname = element(by.xpath("//span[text()='Proper Shipping Name']"));
var stopbox = element(by.css('[formcontrolname="locationID"]'));
var primary = element(by.xpath("//span[text()='Primary Hazard Class']"));
var secondary = element(by.xpath("//span[text()='Secondary Hazard Class']"));
var utilityDelete = element(by.css("[id='a-delete']"));
var SelectFirstorder = element.all(by.xpath("//div[@class='datatable-row-center datatable-row-group']//following::div[@class='GridRowSpanStyle']//h6"));
var Destin = element(by.css("[placeholder='Destination Marketing Area']"));
var Overidewarning = element(by.xpath("//h3[text()='Warnings']//following::p[1]"));
var warningMsg = element(by.xpath("//p[text()='Override All']//following::li[1]"));
var equipcategory = element(by.xpath("//*[@id='equipmentCategoryCode']"));
var equipcategorytext = element(by.xpath("//input[@placeholder='Equipment Category']"));
var equiptypecode = element(by.xpath("//*[@id='equipmentTypeCode']"));
var equiplength = element(by.xpath("//*[@id='equipmentLengthCode']"));
var ordernumber = element(by.className("ordernumber"));
var btn_TrailingNumber = element(by.id("btn-trailEquip"));
//Add Contact
var contact_dropdown = element(by.xpath("//span[span[contains(text(),'Bill To Account Contact')]]/i[2]"));
var addnew = element(by.xpath("//div[span[@class='icon-jbh_add']]"));
var firstname = element(by.css("[id='firstname']"));
var secondname = element(by.css("[id='lastname']"));
var preferedcontact = element(by.xpath("//label[contains(text(),'Preferred Contact Method')]//following::i[@class='caret pull-right'][1]"));
var contactselect = element(by.xpath("//label[contains(text(),'Preferred Contact Method')]//following::ul[@class='ui-select-choices dropdown-menu']//li//div//a//div[contains(text(),'Phone Number')]"));
var input = element(by.css("[id ='phonenumber']"));
var email = element
var details = element(by.className(`btn btn-secondary`));
var contactnav = element(by.xpath("//*[contains(text(),'Contacts')]"));

//copy orders
var copydropdown = element(by.xpath("//div[contains(text(),'Copies')]//following::i[@class='caret pull-right']"));

//Operational Owner
var OPOwner = element(by.css("[id=\"operationalOwner\"]"));
var OPValue = element(by.xpath("//ul[@class=\"dropdown-menu\"]//li[@class=\"active\"]//a"));
var NextButton = element(by.buttonText("Next"));
var Tradingpartner = element(by.css("[formcontrolname='tradingPartnerCode']"));

var OPService = element(by.css("[id=\"orderServices\"]"));
var OPServiceclose = element.all(by.xpath("//*[@formcontrolname='orderServices']//a"));
var shipmentreqclose = element.all(by.xpath("//*[@formcontrolname='shipmentRequirementsTags']//a"));
var protectionMaterialHandling = element(by.css("[formcontrolname='protectionMaterialHandling']"));

export class CreateOrderFunctions {

  /*********************************************************************
	 * 
	* MethodName:  Enteringdata
	* Description: To Enter the values in the First page of Order Creation
	* Parameter (if any):  NIL
	* Return type:  Void
	 ********************************************************************/

  async Enteringdata(Testcasename: string) {
    var TcRow = ReadFromXL.FindRowNum(Testcasename,"CreateOrder");

    DataDictLib.pushToDictionaryWithSheet(TcRow,"CreateOrder");
    var BUValue = DataDictLib.getFromDictionary('BU');
    var SOValue = DataDictLib.getFromDictionary('SO');
    var BillToValue = DataDictLib.getFromDictionary('BillTO');
    var OpOwner = DataDictLib.getFromDictionary('OpOwner');
    var TitleCreate = DataDictLib.getFromDictionary('CreateTitle');
    var Trailernumber = DataDictLib.getFromDictionary('Trailernumber');
    var TrailerPrefix = DataDictLib.getFromDictionary('TrailerPrefix');
    //var Scac =DataDictLib.getFromDictionary('scac');
     var TcRow=ReadFromXL.FindRowNum(Testcasename,"Template");
     DataDictLib.pushToDictionaryWithSheet(TcRow,"Template");
    var Scac =DataDictLib.getFromDictionary('SCACTemp');
    //var Scac: string = "SCAC";
    reuse.EnterValue(BillTo, BillToValue, "Bill to value")
    browser.sleep(2000);
    BillTo.sendKeys(protractor.Key.ENTER);

    icon_loading.isPresent().then((elem) => {
      if (elem == true) {
        console.log("Loading icon is present")
      }
      browser.sleep(2000);
    })
    browser.sleep(5000);
    //reuse.ClickElement(BTContact,"Contact for Bil to")
    //browser.sleep(2000)
    //BTContact.sendKeys(protractor.Key.ENTER); 
    browser.executeScript("window.scrollTo(0,100)");
    //BU.sendKeys("");
    reuse.ClickElement(BU, "Click BU Drop down")

    reuse.EnterValue(BUclick, BUValue, "Bu to value")
    BUclick.sendKeys(protractor.Key.ENTER);
  
    browser.sleep(2000);
    reuse.ClickElement(SO, "Click SO Drop down")
    reuse.EnterValue(SOclick, SOValue, "SO to value")
    // browser.sleep(2000)
    SOclick.sendKeys(protractor.Key.ENTER);
    browser.sleep(3000);
    if (Scac != "Null") {
      scac.isPresent().then((elem) => {
        if (elem === true) {
          Tradingpartner.click();
          browser.sleep(1000);
          for (let i: number = 0; i < Scac.length; i++) {
            reuse.ClickElement(scac, "Click SCAC value");
            // (scac).clear();
            (scac).sendKeys(Scac.charAt(i));
            // scac.se(Scac);
            browser.sleep(3000);
            // element.sendKeys(string.charAt(i));
          }
        }
      })
    }
    if (TrailerPrefix != "NULL") {
      this.Trailer("0000000105", TrailerPrefix)
    }
    if (TitleCreate === "Create New Order") {
      reuse.EnterValue(OPOwner, OpOwner, "Operational owner")
      browser.sleep(2000)
      OPOwner.sendKeys(protractor.Key.ENTER);

    } else {
      console.log("Create new template do not contain this field");
    }
    if (TitleCreate === "Create New Order") {
      await reuse.getTextValueFromElement(ordernumber).then((text) => {
        OrderID = text
      });
      console.log("base order " + OrderID);
      return OrderID
    }
  }
  /*********************************************************************
    * 
   * MethodName:  AddContact
   * Description: To Add the Bill TO Contact
   * Parameter (if any):  NIL
   * Return type:  Void
    ********************************************************************/
  AddContact(Testcasename) {

    BillTo.click();
    BillTo.sendKeys("HASPAW")

    browser.sleep(10000);
    contact_dropdown.click();
    contact_dropdown.sendKeys(protractor.Key.TAB);
    browser.sleep(2000);
    browser.executeScript("window.scrollTo(0,200)");
    addnew.click();
    browser.executeScript("window.scrollTo(0,-500)");
    firstname.click();
    firstname.sendKeys("Arun");
    preferedcontact.click();
    contactselect.click();
    input.sendKeys("8913133499240");

  }
  /*********************************************************************
     * 
    * MethodName:  CopyOrder  
    * Description: To Create Copies of an Order 
    * Parameter (if any):  NIL
    * Return type:  Void
     ********************************************************************/
  CopyOrder(Testcasename) {
    var TcRow = ReadFromXL.FindRowNum(Testcasename, "CreateOrder");
    DataDictLib.pushToDictionaryWithSheet(TcRow, "CreateOrder");
    // var Copyvalue =DataDictLib.getFromDictionary('Copyvalue');
    var Copyvalue = 5
    var copyval = element(by.xpath("//ul[@class='ui-select-choices dropdown-menu']//li//div//a//div[contains(text()," + Copyvalue + ")]"));


    copydropdown.click();
    copyval.click();
  }
  
  /*********************************************************************
     * 
    * MethodName:  Trailer Name   
    * Description: To Add the Trailer Name if specified in the test case
    * Parameter (if any):  NIL
    * Return type:  Void
     ********************************************************************/

  Trailer(Trailerno: string, Trailervalue: string): void {
    trailernobutton.isPresent().then((elem) => {
      if (elem === true) {
        reuse.ClickElement(trailernobutton, "Click Trailer button");
        reuse.EnterValue(Trailernumber, Trailerno, "Trailer number")
        browser.sleep(2000);
        Trailernumber.sendKeys(protractor.Key.TAB);
        browser.sleep(3000);
        reuse.EnterValue(TrailerPrefixText, Trailervalue, "Trailer number")
        reuse.ClickElement(Trailerprefix, "Click trialer Prefix drop down");
        reuse.EnterValue(Trailernumber, Trailerno, "Trailer number")
        TrailerPrefixText.sendKeys(protractor.Key.ENTER);
        browser.sleep(2000)
      }
    });
  }
  /*********************************************************************
	 * 
	* MethodName:  Freight Charges
	* Description: To Enter the values in Freight charges 
	* Parameter (if any):  charge value
	* Return type:  Void
	 ********************************************************************/
  Freightcharges(charge: string): void {
    freightcharges.isPresent().then((elem) => {
      if (elem === true) {
        reuse.ClickElement(freightcharges, "Click Freight charges");
        reuse.EnterValue(freightcharges, charge, "Freight charge value")
        freightcharges.sendKeys(protractor.Key.ENTER);
      }
    });
  }
  /*********************************************************************
    * 
   * MethodName:  Shipmentdetails
   * Description: To Enter the shipment values in the First page of Order Creation
   * Parameter (if any):  charge,ordervalue,fleetcode
   * Return type:  Void
    ********************************************************************/
  Shipmentdetails(Testcasename: string): void {
    var TcRow = ReadFromXL.FindRowNum(Testcasename, "Shipment&Equipment");
    DataDictLib.pushToDictionaryWithSheet(TcRow, "Shipment&Equipment");
    var charge = DataDictLib.getFromDictionary('Shipmentid');
    var ShipReq = DataDictLib.getFromDictionary('ShipmentRequirements');
    var ordervaluetext = DataDictLib.getFromDictionary('Ordervalue');
    var fltcode = DataDictLib.getFromDictionary('fleetcode');
    ShipmentIdentificationNo.isPresent().then((elem) => {
      if (elem === true) {
        ShipmentIdentificationNo.clear();
        reuse.EnterValue(ShipmentIdentificationNo, charge, "Shipment identification number")
        browser.sleep(2000);
        ShipmentIdentificationNo.sendKeys(protractor.Key.TAB);
        shippromarytype.sendKeys(protractor.Key.TAB);
        shipsecndarytype.sendKeys(protractor.Key.ENTER);
       // reuse.ClickElement(shipsecndarytype, "Click Shipment secondary type");
        reuse.EnterValue(shipsecndarytype, "Will", "Shipment secondary type value")
        shipsecndarytype.sendKeys(protractor.Key.ENTER);
        //reuse.EnterValue(ordervalue,ordervaluetext,"Order value") 
        shipsecndarytype.sendKeys(protractor.Key.TAB); 
        shipmentreq.isPresent().then((elem) => {
          if (elem === true) {
            shipmentreqclose.count().then(function (total) {
              shipmentreqclose.each(function (item) {
                var index = 0
                if (total > index) {
                  item.click();
                }
              })
            });
          //  reuse.ClickElement(shipmentreq, "Click shipmentreq");
          shipmentreq.sendKeys(protractor.Key.TAB); 
            reuse.EnterValue(shipmentreq, ShipReq, "shipmentreq value")
            shipmentreq.sendKeys(protractor.Key.ENTER);
            reuse.EnterValue(fleetcode, fltcode, "fleetcode value")
          }
        });


      }
    });
  }

  /*************************************************************************************
    * 
   * MethodName:  AddstopsOrigin
   * Description: To Enter the origin details in the Add Stops page of Order Creation
   * Parameter (if any):  NIL
   * Return type:  Void
    ************************************************************************************/
  AddstopsOrigin(Testcasename: string, Scheduled: string, Requested: string, pickupdate: string): void {
    var TcRow1 = ReadFromXL.FindRowNum(Testcasename, "CommonData");    
    DataDictLib1.pushToDictionaryWithSheet(TcRow1, "CommonData");
    var TitleCreate = DataDictLib1.getFromDictionary('CreateTitle');
    reuse.ClickElement(NextButton, "Next Button")
    //this.ClickButtonwithText("Next");
    browser.sleep(6000);
    var TcRow = ReadFromXL.FindRowNum(Testcasename, "StopDetails");   
    DataDictLib.pushToDictionaryWithSheet(TcRow, "StopDetails");
    var Pickup = DataDictLib.getFromDictionary('Pickup');
    var Delivery = DataDictLib.getFromDictionary('Delivery');
    var ItemQty = DataDictLib.getFromDictionary('ItemQty');
    var ItemWt = DataDictLib.getFromDictionary('ItemWt');
    var ItemChar = DataDictLib.getFromDictionary('ItemChar');
    //var TitleCreate = DataDictLib.getFromDictionary('CreateTitle');

    var NoOfAppoint = DataDictLib.getFromDictionary('NoOfAppoint');
    var NoOfItem = DataDictLib.getFromDictionary('NoOfitems');
    var NoOfStop = DataDictLib.getFromDictionary('Noofstops');
    common.EnterTextBox("locationID", Pickup);
    browser.sleep(5000);
    reuse.ClickElement(BillToValue,"BillTo value")
    browser.sleep(20000);
   // common.SelectDRopdownValue("Contact");
   var EC = protractor.ExpectedConditions;
   browser.wait(EC.invisibilityOf(icon_loading), 15000).then(function () {
   
    browser.sleep(4000);
    browser.executeScript("window.scrollTo(0,-400)");
    browser.executeScript("window.scrollTo(0,200)");
    if (Requested == "Requested") {
      if (NoOfAppoint == 1) {
        common.Selectcalendericon(pickupdate, 0);
        browser.sleep(2000);
        common.SelectTime("08:00", 0);
        browser.sleep(2000);
        common.Selectcalendericon(pickupdate, 1);
        browser.sleep(2000);
        common.SelectTime("09:00", 1);
        //common.SelectTime("09:00",1);
        browser.sleep(2000);
      }
      if (NoOfAppoint > 1) {
        for (var i = 2; i < NoOfAppoint; i++) {
          console.log(NoOfAppoint + 2)
          common.Selectcalendericon(pickupdate, i);
          browser.sleep(2000);
          common.SelectTime("08:00", i);
          // browser.sleep(2000);
          common.Selectcalendericon(pickupdate, i + 1);
          browser.sleep(2000);
          common.SelectTime("09:00", i + 1);
          //common.SelectTime("09:00",1);
          browser.sleep(2000);
        }

      }

    }
    if (Scheduled == "Scheduled") {
      if (NoOfAppoint == 1) {
        var apnmntHR=element.all(by.id("hours"));
        var apnmntMIN=  element.all(by.id("minutes"));
        if (TitleCreate === "Create New Order") {
           browser.executeScript("window.scrollTo(0,-150)");
          apnmntMIN.get(1).click();
          (apnmntMIN.get(1)).sendKeys(protractor.Key.TAB);
          (AddappointmentIcon).sendKeys(protractor.Key.TAB);
         // reuse.ClickElement(AddappointmentIcon, "Scheduled appointment")
          common.Selectcalendericon(pickupdate, 2);
          browser.sleep(2000);
          common.SelectTime("08:30", 2);
          browser.sleep(5000); 
          common.Selectcalendericon(pickupdate, 3);
          browser.sleep(2000);
          common.SelectTime("09:30", 3);
          browser.sleep(2000);
        }
        if (TitleCreate === "Create New Template") {
          AddappointmentIcon.click();
          common.Selectcalendericon(pickupdate, 0);
          browser.sleep(2000);
          common.SelectTime("08:30", 0);
          browser.sleep(2000);
          common.Selectcalendericon(pickupdate, 1);
          browser.sleep(2000);
          common.SelectTime("09:30", 1);
          browser.sleep(2000);
        }
      }
      if (NoOfAppoint > 1) {
        for (var i = 4; i <= 4; i++) {
          console.log(NoOfAppoint + 2)
          AddappointmentIcon.click();
          common.Selectcalendericon(pickupdate, 2);
          browser.sleep(2000);
          common.SelectTime("08:00", 2);
          // browser.sleep(2000);
          common.Selectcalendericon(pickupdate, 3);
          browser.sleep(2000);
          common.SelectTime("09:00", 3);
          browser.sleep(4000);
          browser.executeScript("window.scrollTo(0,-100)");
          AddappointmentIcon.click();
          browser.sleep(4000);
          AddappointmentIconschedule.click();
          common.Selectcalendericon(pickupdate, i);
          browser.sleep(2000);
          common.SelectTime("09:00", i);
          // browser.sleep(2000);
          common.Selectcalendericon(pickupdate, i + 1);
          browser.sleep(2000);
          common.SelectTime("10:00", i + 1);
          browser.sleep(2000);
        }
      }
    }
  });
    browser.sleep(6000)  
    this.HandlingUnit(Testcasename);
    browser.sleep(3000)
    this.Itemdetails(Testcasename);

    var tagname = element(by.css("[formcontrolname=\"itemDescription\"]"));
    tagname.sendKeys(protractor.Key.ENTER);

    browser.sleep(6000);
  }
  /*****************************************************************************************
     * 
    * MethodName:  AppointmentOrigin
    * Description: To add appointment details when an order is created from a saved template
    * Parameter (if any):  Scheduled,pickupdate,Ordername
    * Return type:  Void
     ***************************************************************************************/
  AppointmentOrigin(Testcasename: string, Scheduled: string, pickupdate: string, Ordername: string): void {
    var TcRow = ReadFromXL.FindRowNum(Testcasename, "StopDetails");
    DataDictLib.pushToDictionaryWithSheet(TcRow, "StopDetails");
    var NoOfAppoint = DataDictLib.getFromDictionary('NoOfAppoint');
    var NoOfItem = DataDictLib.getFromDictionary('NoOfitems');
    var NoOfStop = DataDictLib.getFromDictionary('Noofstops');
    if (Scheduled == "Scheduled") {
      if (NoOfAppoint == 1) {
        AddappointmentIcon.click();
        if (Ordername === "Create New Order") {
          AddappointmentIcon.click();
          common.Selectcalendericon(pickupdate, 2);
          browser.sleep(2000);
          common.SelectTime("08:30", 2);
          browser.sleep(2000);
          common.Selectcalendericon(pickupdate, 3);
          browser.sleep(2000);
          common.SelectTime("09:30", 3);
          browser.sleep(2000);
        }
        if (Ordername === "Create New Template") {
          AddappointmentIcon.click();
          common.Selectcalendericon(pickupdate, 0);
          browser.sleep(2000);
          common.SelectTime("08:30", 0);
          browser.sleep(2000);
          common.Selectcalendericon(pickupdate, 1);
          browser.sleep(2000);
          common.SelectTime("09:30", 1);
          browser.sleep(2000);
        }
      }
    }
  }
  /*****************************************************************************************
     * 
    * MethodName:  AppointmentOrigin
    * Description: To add appointment details in origin when an order is created from a saved template
    * Parameter (if any):  Scheduled,pickupdate,Ordername
    * Return type:  Void
     ***************************************************************************************/
  AppiontmentDestination(Testcasename: string, Scheduled: string, DeliveryDate: string, Ordername: string, Index: number) {
    var TcRow = ReadFromXL.FindRowNum(Testcasename, "StopDetails");
    DataDictLib.pushToDictionaryWithSheet(TcRow, "StopDetails");
    var NoOfAppoint = DataDictLib.getFromDictionary('NoOfAppoint');
    var NoOfItem = DataDictLib.getFromDictionary('NoOfitems');
    var NoOfStop = DataDictLib.getFromDictionary('Noofstops');


    if (Scheduled == "Scheduled") {

      if (Ordername === "Create New Order") {
        AddappointmentIcon.click();
        common.Selectcalendericon(DeliveryDate, Index);
        browser.sleep(2000);
        common.SelectTime("08:30", Index);
        // browser.sleep(2000);
        common.Selectcalendericon(DeliveryDate, (Index + 1));
        browser.sleep(2000);
        common.SelectTime("09:30", (Index + 1));
        browser.sleep(2000);
      }
      if (Ordername === "Create New Template") {
        AddappointmentIcon.click();
        common.Selectcalendericon(DeliveryDate, 0);
        browser.sleep(2000);
        common.SelectTime("08:30", 0);
        browser.sleep(2000);
        common.Selectcalendericon(DeliveryDate, 1);
        browser.sleep(2000);
        common.SelectTime("09:30", 1);
        browser.sleep(2000);
      }


    }
  }
  /*****************************************************************************************
     * 
    * MethodName:  AppointmentDestination
    * Description: To add appointment details in Dest when an order is created from a saved template
    * Parameter (if any):  Scheduled,pickupdate,Ordername
    * Return type:  Void
     ***************************************************************************************/

  HandlingUnit(Testcasename) {
    var TcRow = ReadFromXL.FindRowNum(Testcasename, "StopDetails");

    DataDictLib.pushToDictionaryWithSheet(TcRow, "StopDetails");
    var ItemQty = DataDictLib.getFromDictionary('ItemQty');
    var ItemWt = DataDictLib.getFromDictionary('ItemWt');
    //dropdownopt.click();
    common.EnterTextBox("itemHandlingTypeQuantity", ItemQty)
    browser.sleep(2000);
    common.EnterTextBox("itemHandlingUnitWeight", ItemWt);
    browser.sleep(2000);

    var Handlingunit = element(by.css("[formcontrolname=\"itemHandlingUnitHeight\"]"));
    Handlingunit.sendKeys(protractor.Key.TAB);
    browser.sleep(5000);

  }
  /*****************************************************************************************
     * 
    * MethodName:  Itemdetails
    * Description: To item details in origin when an order is created 
    * Parameter (if any):  Scheduled,pickupdate,Ordername
    * Return type:  Void
     ***************************************************************************************/
  Itemdetails(Testcasename: string) {
    var TcRow = ReadFromXL.FindRowNum(Testcasename, "StopDetails");

    DataDictLib.pushToDictionaryWithSheet(TcRow, "StopDetails");
    var ItemQty = DataDictLib.getFromDictionary('ItemQty');
    var ItemWt = DataDictLib.getFromDictionary('ItemWt');
    var ItemChar = DataDictLib.getFromDictionary('ItemChar');
    var NoOfItem = DataDictLib.getFromDictionary('NoOfitems');
    if (NoOfItem == 0) {
      common.EnterTextBox("packagingUnitTypeQuantity", ItemQty);
      common.EnterTextBox("itemWeight", ItemWt);

      browser.sleep(5000);
      var itemunit = element(by.css("[formcontrolname=\"itemHeight\"]"));
      itemunit.sendKeys(protractor.Key.TAB);
      browser.sleep(12000);
      common.EnterTextBox("itemDescription", ItemChar)
      browser.sleep(5000);
      var tagname = element(by.css("[formcontrolname=\"itemDescription\"]"));
    }
    console.log("The number of items to be added",NoOfItem)
    if (NoOfItem >= 1) {
      common.EnterTextBox("packagingUnitTypeQuantity", ItemQty);
      common.EnterTextBox("itemWeight", ItemWt);

      browser.sleep(5000);
      var itemunit = element(by.css("[formcontrolname=\"itemHeight\"]"));
      itemunit.sendKeys(protractor.Key.TAB);
      browser.sleep(12000);

      common.EnterTextBox("itemDescription", ItemChar)
      browser.sleep(6000);
      var tagname = element(by.css("[formcontrolname=\"itemDescription\"]"));
      tagname.sendKeys(protractor.Key.ENTER);
      browser.sleep(5000);
      //(AddappointmentIcon).click();
      reuse.ClickElement((icon_Additem), "Apointment Add icon click")
      browser.sleep(5000);
      for (var i = 1; i <= NoOfItem; i++) {
        var j = 5;

        var AddItem = ((j += 2));
        console.log((j += 2));
        console.log("Console value for j is ", j);
        var ItemQtyvalue = (tagname.get(i));
        var ItemWeightValue = (tagname1.get(i));
        var itemunitvalue = (itemunit.get(i));
        var ItemWeightValue = (tagname1.get(i));
        var ItemCharName = (tagname2.get(i));

        var ItemCharFreezeName = (itemchar.get(i));
        var NMFCNumber = (NMFCNumber.get(i));
        ItemQtyvalue.clear();
        reuse.EnterValue(ItemQtyvalue, ItemQty, "Item Qauntity value")

        ItemWeightValue.clear();
        reuse.EnterValue(ItemWeightValue, ItemWt, "Item Weight value")
        browser.sleep(5000);
        itemunit.sendKeys(protractor.Key.TAB);
        browser.sleep(5000);
        reuse.ClickElement(ItemCharName, "Click SO Drop down")
        ItemCharName.sendKeys(protractor.Key.TAB);
        NMFCNumber.sendKeys(protractor.Key.TAB);
        //ItemCharFreezeName.click();
        browser.sleep(3000);
        ItemCharName.clear();
        reuse.EnterValue(ItemCharName, ItemChar, "Item Characteristics name")
        browser.sleep(5000);
        ItemCharName.sendKeys(protractor.Key.ENTER);
        browser.sleep(5000);
        //var tagname=element(by.css("[formcontrolname=\"itemDescription\"]"));
        //ItemCharName.sendKeys(protractor.Key.ENTER);
        //browser.sleep(5000);
        reuse.ClickElement((icon_Additem), "Apointment Add icon click")
        browser.sleep(5000);
      }
    }
  }
  DimensionsDetails(Testcasename: string) {
    var TcRow = ReadFromXL.FindRowNum(Testcasename, "StopDetails");

    DataDictLib.pushToDictionaryWithSheet(TcRow, "StopDetails");
      var HandlingUnitLength:number = DataDictLib.getFromDictionary('ItemLength');
      var HandlingUnitWidth = DataDictLib.getFromDictionary('ItemWidth');
      var HandlingUnitHeight = DataDictLib.getFromDictionary('ItemHeight');
      var HandlingUnitVolume = DataDictLib.getFromDictionary('ItemVolume');


    var ItemLength=element(by.css("[formcontrolname=\"itemHandlingUnitLength\"]"));
    ItemLength.clear();
    ItemLength.click();
    ItemLength.sendKeys(HandlingUnitLength);
    var ItemWidth=element(by.css("[formcontrolname=\"itemHandlingUnitWidth\"]"));
    ItemWidth.clear();
    ItemWidth.sendKeys(15);
    var ItemHeight=element(by.css("[formcontrolname=\"itemHandlingUnitHeight\"]"));
    ItemHeight.clear();
    ItemHeight.click();
    ItemHeight.sendKeys(HandlingUnitHeight);


    
     
    
      reuse.ClickButtonwithText("Volume");
      common.EnterTextBox("itemHandlingUnitVolume", HandlingUnitVolume);
      browser.sleep(5000);
      
    
  }
  /*****************************************************************************************
     * 
    * MethodName:  AddstopsDestination
    * Description: To add Destination stop details when an order is created 
    * Parameter (if any):  Scheduled,Requested,DeliveryDate
    * Return type:  Void
     ***************************************************************************************/
  AddstopsDestination(Testcasename: string, Scheduled: string, Requested: string, DeliveryDate): void {
   
    var TcRow1 = ReadFromXL.FindRowNum(Testcasename, "CommonData");    
        DataDictLib1.pushToDictionaryWithSheet(TcRow1, "CommonData");
        var TitleCreate = DataDictLib1.getFromDictionary('CreateTitle');
       //var TitleCreate="Create New order"
    var Delivery = DataDictLib.getFromDictionary('Delivery');
    var pickupdate = DataDictLib.getFromDictionary('Pickup');
    var deliverdate = DataDictLib.getFromDictionary('Delivery');
    var StartTime = DataDictLib.getFromDictionary('PickupDate');
    var endTime = DataDictLib.getFromDictionary('Deliverydate');
    if (TitleCreate === "Create New Order") {
      console.log("Entered")
      reuse.ClickElement(DestinationTab, "Click Destination Tab")
      browser.sleep(4000);

    } if (TitleCreate === "Create New Template") {
       reuse.ClickElement(TemplateDestinationTab, "Click SO Drop down")
      browser.sleep(7000);
    }
    common.EnterTextBox("locationID", Delivery);
    browser.sleep(5000);
    reuse.ClickElement(BillToValue, "Click destination from drop down")
    browser.sleep(7000);
    //common.SelectDRopdownValue("Contact");
    browser.sleep(5000);
    var EC = protractor.ExpectedConditions;
    browser.wait(EC.invisibilityOf(icon_loading), 20000).then(function () {
      browser.sleep(4000);
     // browser.executeScript("window.scrollTo(0,-400)");
     // browser.executeScript("window.scrollTo(0,200)");
    if (Requested == "Requested") {
      common.Selectcalendericon(DeliveryDate, 0);
      browser.sleep(2000);
      common.SelectTime("08:00", 0);
      // browser.sleep(2000);
      common.Selectcalendericon(DeliveryDate, 1);
      browser.sleep(2000);
      common.SelectTime("09:00", 1);
      //common.SelectTime("09:00",1);
      browser.sleep(2000);
    }
    if (Scheduled == "Scheduled") {
      var apnmntHR=element.all(by.id("hours"));
      var apnmntMIN=  element.all(by.id("minutes"));
      if (TitleCreate === "Create New Order") {
        // browser.executeScript("window.scrollTo(0,-150)");
        //  var a1= element(by.xpath("//div[@class='panel-body card-block']"))         
        //  // browser.executeScript("window.scrollTo(0,-2000)"); 
        //   browser.sleep(3000);
        //  // reuse.ClickElement(a1,"Click a1");
        //   for(var i=0; i<16; i++)
        //   {
        //    a1.sendKeys(protractor.Key.TAB);
        //   }
       
        //   browser.sleep(3000);
        // AddappointmentIconReq.click();
       // AddappointmentIconSch.click();
       // AddappointmentIconSch.sendKeys(protractor.Key.TAB);
       // apnmntHR.get(1).sendKeys(protractor.Key.TAB);
       appointmentMinReq.click();
       (appointmentMinReq).sendKeys(protractor.Key.TAB);
        (AddappointmentIcon).sendKeys(protractor.Key.TAB);
        //AddappointmentIcon.click();
        common.Selectcalendericon(DeliveryDate, 2);
        browser.sleep(5000);
        common.SelectTime("09:30", 2);
        // browser.sleep(2000);
        common.Selectcalendericon(DeliveryDate, 3);
        browser.sleep(2000);
        common.SelectTime("10:30", 3);
        browser.sleep(2000);
      }
      if (TitleCreate === "Create New Template") {
        AddappointmentIcon.click();
        common.Selectcalendericon(pickupdate, 0);
        browser.sleep(2000);
        common.SelectTime("08:30", 0);
        browser.sleep(2000);
        common.Selectcalendericon(pickupdate, 1);
        browser.sleep(2000);
        common.SelectTime("09:30", 1);
        browser.sleep(2000);
      }

    }
    browser.sleep(8000);
   
    // this.DateValidationCreateOrderOverview("01/04/2018","01/05/2018");

    if (TitleCreate === "Create New Order") {
      PalletChckBX.isPresent().then((elem) => {
        browser.executeScript("window.scrollTo(0,100)");
      reuse.SAClickElement(PalletChckBX, "Click Pallet checkbox")
        browser.sleep(2000);
      })
      //NextButton.click();
    } else {
      PalletChckBX.isPresent().then((elem) => {   
        browser.executeScript("window.scrollTo(0,100)");  
      reuse.SAClickElement(TemplatePalletChckBX, "Click Template Pallet check box")
        browser.sleep(3000);
      })
    }
  });
    browser.sleep(4000);
    console.log("End of destination function");
  }
  /*****************************************************************************************
     * 
    * MethodName:  MultiplePalletCheckbox
    * Description: To select multiple pallet checkbox when multiple stops are added
    * Parameter (if any):  Title
    * Return type:  Void
     ***************************************************************************************/
  MultiplePalletCheckbox(Testcasename, Title): void {
    var DataDictLib1 = new DataDictionary();
    var DataDictLib2 = new DataDictionary();
    var TcRow1 = ReadFromXL.FindRowNum(Testcasename, "CreateOrder")
    DataDictLib2.pushToDictionaryWithSheet(TcRow1, "CreateOrder")
    var TcRow = ReadFromXL.FindRowNum(Testcasename, "StopDetails")
    DataDictLib1.pushToDictionaryWithSheet(TcRow, "StopDetails");
    var Stopnumber = DataDictLib1.getFromDictionary('StopNumber');
    var TitleCreate = DataDictLib2.getFromDictionary('CreateTitle')

    if (TitleCreate === "Create New Order") {
      reuse.ClickElement((AddStopDestinationTab.get(Stopnumber)), "Click Destination tab")
      browser.sleep(3000);
      browser.executeScript("window.scrollTo(0,500)");
      if (Stopnumber >= 1) {
        browser.sleep(3000);
        for (var i = 1; i <= Stopnumber; i++) {
          console.log(i,"I value in multiple pallet checkbox")
          browser.executeScript("window.scrollTo(0,500)");
          reuse.ClickElement((MultiplePalletChckBX.get(i)), "Click Multiple pallet checkbox")
          browser.sleep(6000);
        }
      }
    }
    //        else (TitleCreate === "Create New Template") 
    //        {
    //                    TemplateAddStopDestinationTab.get((Stopnumber)).click();
    //         browser.sleep(3000); 
    //         browser.executeScript("window.scrollTo(0,500)");               
    //         if(Stopnumber>=1)
    //         {
    //           browser.sleep(3000);
    //           for(var i=1;i<=Stopnumber;i++)
    //           {
    // browser.executeScript("window.scrollTo(0,500)");
    //         (MultiplePalletChckBX.get(i)).click();
    //             browser.sleep(6000);
    //            }}                      
    // }
  }
  /*****************************************************************************************
     * 
    * MethodName:  AddIntermediateStopDetails
    * Description: To add intermediate stops(multiple stops) while creating an order
    * Parameter (if any):  Requested,Pickupdate,StopNumber
    * Return type:  Void
     ***************************************************************************************/
  AddIntermediateStopDetails(Testcasename: string, Requested: string, Pickupdate: string, StopNumber: number): void {
    // NextButton.click();
    //this.ClickButtonwithText("Next");
    console.log(StopNumber," the i value is")
    browser.sleep(5000);
    var DataDictLibStop = new DataDictionary();
    var TcRow = ReadFromXL.FindRowNum(Testcasename, "InterStops")
    DataDictLib.pushToDictionaryWithSheet(TcRow, "InterStops")
    var Stopvalue = DataDictLib.getFromDictionary('Stop'+StopNumber);
    console.log("Location value is "+Stopvalue)
    //var Delivery =DataDictLib.getFromDictionary('Delivery');
    console.log("ItemQty" + StopNumber)
    var ItemQty = DataDictLib.getFromDictionary('ItemQty' + StopNumber);
    var ItemWt = DataDictLib.getFromDictionary('ItemWt' + StopNumber);
    var ItemChar = DataDictLib.getFromDictionary('ItemChar' + StopNumber);
    var TitleCreate = DataDictLib.getFromDictionary('CreateTitle');
    console.log("Console values are as below ",+Stopvalue, +ItemQty, +ItemWt);

    var NoOfAppoint = DataDictLib.getFromDictionary('NoOfAppoint');
    var NoOfItem = DataDictLib.getFromDictionary('NoOfitems');
    var NoOfStop = DataDictLib.getFromDictionary('Noofstops');
    common.EnterTextBox("locationID", Stopvalue);
    browser.sleep(5000);
    reuse.ClickElement(BillToValue,"BillTo value")
    browser.sleep(20000);
    reuse.ClickElement(StopReason, "Click stopreason drop down")
    reuse.ClickElement(StopReasonText, "Click the reason from drop down")
    browser.sleep(3000);
   // common.SelectDRopdownValue("Contact");
   // browser.sleep(4000);
    if (Requested == "Requested") {
      if (NoOfAppoint == 1) {
        common.Selectcalendericon(Pickupdate, 0);
        browser.sleep(2000);
        common.SelectTime("08:00", 0);
        // browser.sleep(2000);
        common.Selectcalendericon(Pickupdate, 1);
        browser.sleep(2000);
        common.SelectTime("09:00", 1);
        //common.SelectTime("09:00",1);
        browser.sleep(2000);
      }
      if (NoOfAppoint > 1) {
        for (var i = 2; i < NoOfAppoint; i++) {
          console.log(NoOfAppoint + 2)
          common.Selectcalendericon(Pickupdate, i);
          browser.sleep(2000);
          common.SelectTime("08:00", i);
          // browser.sleep(2000);
          common.Selectcalendericon(Pickupdate, i + 1);
          browser.sleep(2000);
          common.SelectTime("09:00", i + 1);
          //common.SelectTime("09:00",1);
          browser.sleep(2000);
        }

      }

    }
    if (Requested == "Scheduled") {
      var apnmntHR=element.all(by.id("hours"));
      var apnmntMIN=  element.all(by.id("minutes"));
      if (TitleCreate === "Create New Order") {
         browser.executeScript("window.scrollTo(0,-150)");
        apnmntMIN.get(1).click();
        (apnmntMIN.get(1)).sendKeys(protractor.Key.TAB);
        (AddappointmentIcon).sendKeys(protractor.Key.TAB);
        common.Selectcalendericon(Pickupdate, 2);
        browser.sleep(2000);
        common.SelectTime("08:00", 2);
        // browser.sleep(2000);
        common.Selectcalendericon(Pickupdate, 3);
        browser.sleep(2000);
        common.SelectTime("09:00", 3);
        browser.sleep(2000);
      }
      if (NoOfAppoint > 1) {
        for (var i = 4; i <= 4; i++) {
          console.log(NoOfAppoint + 2)
          reuse.ClickElement((AddappointmentIcon), "Click add appointment icon")
          common.Selectcalendericon(Pickupdate, 2);
          browser.sleep(2000);
          common.SelectTime("08:00", 2);
          // browser.sleep(2000);
          common.Selectcalendericon(Pickupdate, 3);
          browser.sleep(2000);
          common.SelectTime("09:00", 3);
          browser.sleep(4000);
          browser.executeScript("window.scrollTo(0,-100)");
          reuse.ClickElement((AddappointmentIcon), "Click add appointment icon")
          browser.sleep(4000);
          AddappointmentIconschedule.click();
          common.Selectcalendericon(Pickupdate, i);
          browser.sleep(2000);
          common.SelectTime("09:00", i);
          // browser.sleep(2000);
          common.Selectcalendericon(Pickupdate, i + 1);
          browser.sleep(2000);
          common.SelectTime("10:00", i + 1);
          browser.sleep(2000);
        }
      }
    }
    browser.sleep(3000)
    this.HandlingUnit(Testcasename);
    browser.sleep(3000)
    this.Itemdetails(Testcasename);
    
    var tagname = element(by.css("[formcontrolname=\"itemDescription\"]"));
    tagname.sendKeys(protractor.Key.ENTER);
    browser.executeScript("window.scrollTo(0,-500)");
    browser.sleep(15000);
  }
  /*****************************************************************************************
    * 
   * MethodName:  AppointmentOrigin
   * Description: To add InternationalShipment details when an order is created 
   * Parameter (if any):  NIL
   * Return type:  Void
    ***************************************************************************************/


  InternationalShipment(): void {
    shipmentreq.isPresent().then((elem) => {
      if (elem === true) {
        reuse.ClickElement(shipmentreq, "Click Shipment Requirements")
        reuse.EnterValue(shipmentreqText, "Inter", "Shipment Requirements text")
        shipmentreqText.sendKeys(protractor.Key.ENTER);
        reuse.ClickElement(interservice, "Select International service")
        reuse.EnterValue(interservicetext, "door", "Select International service value")
        interservicetext.sendKeys(protractor.Key.ENTER);
        //inbondToggle.click();
        //  bondholder.click();
        //  bondholdertext.sendKeys("Door");
        //  bondholdertext.sendKeys(protractor.Key.ENTER);
        //  bondholderparty.click();
        //  bondholderpartytext.sendKeys("Door");
        //  bondholderpartytext.sendKeys(protractor.Key.ENTER);
        // bondholderpartytype.click();
        // bondholderpartytypetext.sendKeys("Immediate Export");
        //bondholderpartytypetext.sendKeys(protractor.Key.ENTER);
      }
    });

  }
  /*****************************************************************************************
     * 
    * MethodName:  AppointmentValidation
    * Description: To validate the appointmetn details of the order
    * Parameter (if any):  NIL
    * Return type:  Void
     ***************************************************************************************/

  AppointmentValidation() {
    this.ElementValidation(apnmt_ordovrview);
    this.ElementValidation(apnmt_stop);
  }
  /*****************************************************************************************
     * 
    * MethodName:  ElementValidation
    * Description: To validate the element details of the order
    * Parameter (if any):  Scheduled,pickupdate,Ordername
    * Return type:  Void
     ***************************************************************************************/
  ElementValidation(Objelement): void {

    Objelement.isPresent().then((elem) => {
      if (elem == true) {
        Objelement.getText().then((text) => {
          console.log(text);
          console.log("Appointment details is present in order overview" + text);
        })
      }
    })
  };
  /*****************************************************************************************
* 
* MethodName:  DateValidationCreateOrderOverview
* Description: To validate the date details in order overview
* Parameter (if any):  AppointmnetDatepickup,appointmentdateDelivery
* Return type:  Void
***************************************************************************************/

  DateValidationCreateOrderOverview(AppointmnetDatepickup, appointmentdateDelivery): void {

    PickDateorderOverview.isPresent().then((elem) => {
      if (elem == true) {
        PickDateorderOverview.getText().then((text) => {
          var date = text.split(" ");
          var PickupDate = date[0];
          var pickupTime = date[1];
          if (PickupDate == AppointmnetDatepickup) {
            console.log("Pickup Appointment details and Time zone in Order overview  is same as the appointment date while creating the order " + text);
          }
        })
      }
    });
    DelidateorderOverview.isPresent().then((elem) => {
      if (elem == true) {
        DelidateorderOverview.getText().then((text) => {
          var date = text.split(" ");
          var Deliverydate = date[0];
          var DeliveryTime = date[1];
          if (Deliverydate == appointmentdateDelivery) {
            console.log("Delivery Appointment details and Time Zone in Order overview is same as the appointment date while creating the order " + text);
          }
        })
      }
    });
  }
  /*****************************************************************************************
     * 
    * MethodName:  HazmatDetails
    * Description: To add appointment details when an order is created from a saved template
    * Parameter (if any):  Scheduled,pickupdate,Ordername
    * Return type:  Void
     ***************************************************************************************/
  HazmatDetails() {

    var itemcharname = element.all(by.css("[formcontrolname='itemCharacteristics']"));
        var itemchar_type = element(by.xpath("//*[@placeholder='Item Characteristics']"));
        var unnacode = element(by.xpath("//*[@id='unnaCode']"));
        var shippingname = element(by.xpath("//span[text()='Proper Shipping Name']"));
        var primary = element(by.xpath("//span[text()='Primary Hazard Class']"));
        var secondary = element(by.xpath("//span[text()='Secondary Hazard Class']"));

    var Item = DataDictLib.getFromDictionary('HAZMAT')
    var UNNA = DataDictLib.getFromDictionary('UNNA');
    var UNNAval = DataDictLib.getFromDictionary('UNNAval');
    //var shippingname = DataDictLib.getFromDictionary('Hazmatshippingname');

    console.log("Entered Hazmat")
    // this.ElementWait(true,stopbox);
    //this.hazmatdropdowns("Item Characteristics","Haazmat")
    browser.sleep(6000);
    itemcharname.isPresent().then((elem) => {
      if (elem === true) {
        reuse.ClickElement(itemcharname, "Click Item char name");
        browser.sleep(3000);
        reuse.EnterValue(itemchar_type, Item, "Enter the Item Characteristic type")
        // itemchar_type.sendKeys(protractor.Key.SPACE);
        // itemchar_type.sendKeys(protractor.Key.ENTER);
        browser.sleep(3000);

        reuse.ClickElement(unnacode, "Click Unna code")
        reuse.EnterValue(unnacode, UNNAval, "Enter the UNNA Code")
        unnacode.sendKeys(protractor.Key.ENTER);
        //this.hazmatdropdowns("Proper Shipping Name","-Butyl chloroformate")
        reuse.ClickElement(shippingname, "Click shippingname")
        reuse.EnterValue(shippingname, shippingname, "Enter the Shipping name")
        shippingname.sendKeys(protractor.Key.ENTER);
        reuse.ClickElement(primary, "Click primary value")
        primary.sendKeys(protractor.Key.TAB);
        primary.sendKeys(protractor.Key.ENTER);


        //this.hazmatdropdowns("Secondary Hazard Class","");
        reuse.ClickElement(secondary, "Click secondary value")
        secondary.sendKeys(protractor.Key.TAB);
        secondary.sendKeys(protractor.Key.ENTER);
      }
    });
  }
  /*****************************************************************************************
     * 
    * MethodName:  AppointmentOrigin
    * Description: To add appointment details when an order is created from a saved template
    * Parameter (if any):  Scheduled,pickupdate,Ordername
    * Return type:  Void
     ***************************************************************************************/
  utilities(utilityoption, option): void {
    browser.executeScript("window.scrollTo(0,-500)");
    reuse.ClickElement(Utilitiesicon, "Click on the utilities icon")
    browser.sleep(2000);
    
    //browse.click();

    switch (utilityoption) {
      case "Comment": {
        //Utilitiesicon.click();
        //Utilitiesicon.click();
        reuse.ClickElement((toollist.get(0)), "Click on the Comment icon")
        reuse.ClickElement(addComment, "Click on the Add comment")
        addCommenttext.sendKeys(protractor.Key.ENTER);
        browser.sleep(2000);
        reuse.EnterValue(addCommenttext, "Ap", "Add comment text")
        addCommenttext.sendKeys(protractor.Key.ENTER);
        browser.sleep(2000);
        reuse.ClickElement(templateType, "Click on the templatetype value")
        reuse.ClickElement(templateType, "Click on the templatetype value")        
        templatetypetext.sendKeys("Appointment ");
        browser.sleep(2000);
        templatetypetext.sendKeys(protractor.Key.ENTER);
        Commenttext.clear();
        reuse.EnterValue(Commenttext, "Test", "Comment etxt")
        browser.sleep(1000);
        Commenttext.sendKeys(protractor.Key.TAB);
        //browser.executeScript("window.scrollTo(0,-500)"); 
        (Savebuttonreject.get(0)).sendKeys(protractor.Key.ENTER);
        browser.sleep(4000);
        reuse.ClickElement(addedutilityref, "Click on the add utilities Reference")
        var EC = protractor.ExpectedConditions;
        browser.wait(EC.visibilityOf(apntEditcmnt), 5000).then(function () {
          console.log("Edit or Delete option is available ")
          if (option == "Edit") {
            reuse.ClickElement(utilityedit, "Click on the utilities Edit option")
            browser.sleep(4000);
          }
          if (option == "Delete") {
            reuse.ClickElement(utilityDelete, "Click on the utilities delete option")
            browser.sleep(4000);
          }
        });
        browser.executeScript("window.scrollTo(0,-500)");
        reuse.ClickElement(Utilitiesicon, "Click on the utilities icon")
        break;
      }
      case "Documents": {
        reuse.ClickElement((toollist.get(1)), "Click on the Documents icon from utilities pane")
        break;
      }
      case "Reference": {
        //Utilitiesicon.click();
        // Utilitiesicon.click();
       // var ivon_ref=element(by.xpath("//i[@class='icon icon-jbh_three-stack manage-reference']"))
        var icon_Order=element(by.id("btn-order"))
        var icon_stop=element(by.id("btn-stops"))
        reuse.ClickElement((toollist.get(2)), "Click on the Reference icon from utilities pane")
        browser.sleep(4000);
        browser.executeScript("window.scrollTo(0,200)");
        //reuse.ClickButtonwithText("Order")
      reuse.ClickElement(icon_Order,"Order button")
      icon_Order.sendKeys(protractor.Key.TAB);
      icon_stop.sendKeys(protractor.Key.TAB);
        browser.sleep(2000);
        ReferenceType.sendKeys(protractor.Key.ENTER);
       // reuse.ClickElement(ReferenceType, "Click on the reference type")
        reuse.EnterValue(ReferenceType, "Appointment", "Appointment type")
        ReferenceType.sendKeys(protractor.Key.ENTER);
        ReferenceType.sendKeys(protractor.Key.TAB);
        reuse.EnterValue(Refercmnt, "Test", "Refernce comment value")
        browser.sleep(3000);
        Refercmnt.sendKeys(protractor.Key.TAB);
       // browser.executeScript("window.scrollTo(0,50)");
       //(Addbutton.get(1)).sendKeys(protractor.Key.ENTER);
        reuse.ClickElement((AddbuttonRef), "Click on ADD bUTTON")
        browser.sleep(10000);
        
        //browser.executeScript("window.scrollBy(0,-3000)"); 
        //browser.executeScript("window.scrollTo(0,-500)"); 
        //toollist.get(2).click();
        browser.executeScript("window.scrollBy(0,-5000)");
        var EC = protractor.ExpectedConditions;
        browser.wait(EC.visibilityOf(apntEditRef), 5000).then(function () {
          console.log("Edit or Delete option is available ")
          if (option == "Edit") {
            browser.executeScript("window.scrollTo(0,-200)");
            reuse.ClickElement(apntEditRef, "Click on the Appointment edit or Delete")
            browser.sleep(4000);
            reuse.ClickElement(UtilrefEdit, "Click on the utilities Reference edit ")
            browser.sleep(2000);
            reuse.ClickElement(ReferenceType1, "Click on the Reference type 1")
            reuse.EnterValue(Refercmnt, "123456", "Charge Amount value")
            browser.sleep(3000);
            reuse.ClickElement(savebutton1, "Click on the save button")
            browser.sleep(2000);
          }
          if (option == "Delete") {
            browser.executeScript("window.scrollTo(0,-200)");
            reuse.ClickElement(apntEditRef, "Click on the Appointment edit or Delete")
            browser.sleep(4000);
            reuse.ClickElement(Utilrefdelete, "Click on the utilities Reference Delete ")
            browser.sleep(2000);
          }

        });
        browser.executeScript("window.scrollTo(0,-500)");
        reuse.ClickElement(Utilitiesicon, "Click on the utilities icon")
        break;
      }

      case "Instruction": {
        reuse.ClickElement((toollist.get(3)), "Click on the Instruction icon from utilities pane")
        reuse.EnterValue(txt_instruction, "Testsgsdfghsdfhadfhsdfhdfhsadfgsadfbhadfhfgadfghadfhadfgdfha", "Instruction value")
        txt_instruction.sendKeys(protractor.Key.TAB);
        dd_TagsInstr.sendKeys(protractor.Key.ENTER);
        //reuse.ClickElement(dd_TagsInstr, "Click on the tad drop down")
        reuse.EnterValue(dd_TagsInstr, "Order", "Tag value")
        dd_TagsInstr.sendKeys(protractor.Key.ENTER);
        dd_TagsInstr.sendKeys(protractor.Key.TAB);
        reuse.ClickElement((btn_SaveIntruction.get(0)),"Save button for instruction")
        browser.sleep(15000);
        browser.executeScript("window.scrollTo(0,-500)");
        reuse.ClickElement(Utilitiesicon, "Click on the utilities icon")
        break;
      }
      case "Charge": {
        reuse.ClickElement((toollist.get(3)), "Click on the Instruction icon from utilities pane");
        (toollist.get(3)).sendKeys(protractor.Key.TAB);
        reuse.ClickElement((toollist.get(4)), "Click on the Charge icon from utilities pane")
        reuse.ClickElement(Chargelevel, "Click on the charge level")
        reuse.EnterValue(Chargelevel, "Order", "Appointment type")
        Chargelevel.sendKeys(protractor.Key.ENTER);
        browser.sleep(2000);
        chargeamount.clear();
        reuse.EnterValue(chargeamount, "10", "Charge Amount value")
        chargequantity.clear();
        reuse.EnterValue(chargequantity, "15", "Charge quantity value")
        reuse.EnterValue(chargecode, "DEAD", "Charge code valueS")
        //chargecode.sendKeys(protractor.Key.SPACE);
        chargecode.sendKeys(protractor.Key.BACK_SPACE);
        chargecode.sendKeys(protractor.Key.BACK_SPACE);
        browser.sleep(2000);
        reuse.EnterValue(chargecode, "A", "Charge code value")
        browser.sleep(2000);
        reuse.ClickElement(BillToValue, "Click on the Active option")
        browser.sleep(2000);
        reuse.EnterValue(authno, "12369", "authorization number")
        reuse.EnterValue(authby, "keerthana", "Authorized by")

        authby.sendKeys(protractor.Key.TAB);
        reuse.ClickElement((Addbuttoncharge.get(2)), "Click on the Addbuttoncharge")
        browser.sleep(2000);
        reuse.ClickElement(UtilEditCharge, "Click on the utilities UtilEditCharge")
        var EC = protractor.ExpectedConditions;
        browser.wait(EC.visibilityOf(UtilEditCharge), 3000).then(function () {
          console.log("Edit or Delete option is available ")
          if (option == "Edit") {
            reuse.ClickElement(UtilChargeEdit, "Click on the utilities UtilChargeEdit")
            reuse.ClickElement(ReferenceType1, "Click on the utilities ReferenceType1")
            reuse.EnterValue(Refercmnt, "123456", "referenc ecomment")
            //browser.executeScript("window.scrollTo(0,300)");
            browser.sleep(3000);

            reuse.ClickElement(savebutton1, "Click on the utilities savebutton1")
            browser.sleep(1000);
          }
          if (option == "Delete") {
            browser.sleep(1000);
            reuse.ClickElement(Utilchargedelete, "Click on the utilities Utilchargedelete")
            browser.sleep(2000);
          }
        });
        browser.executeScript("window.scrollTo(0,-500)");
        reuse.ClickElement(Utilitiesicon, "Click on the utilities icon")
        break;
      }

    }
  }
  /*****************************************************************************************
     * 
    * MethodName:  TotalMilesCreateOrderOverview
    * Description: To validate the total miles in the order overview
    * Parameter (if any): OBJElement
    * Return type:  Void
     ***************************************************************************************/
  TotalMilesCreateOrderOverview(OBJElement) {
    OBJElement.isPresent().then((elem) => {
      var value = 0;
      {
        var Disp = OBJElement.getText().then((text ) => {
          if (text.trim() != "0") {
            console.log("Total miles is displayed for the order " + text);
          }
        })
      }
    });
  }
  /*****************************************************************************************
* 
* MethodName:  addmultiplestops
* Description: To add multiple stops in creating order
* Parameter (if any):  stopreason
* Return type:  Void
***************************************************************************************/
  addmultiplestops(Testcasename, stopreason: string, Appointmentdate: string, AppointmentType: string): void {
    var TcRow = ReadFromXL.FindRowNum(Testcasename, "StopDetails")
    DataDictLib.pushToDictionaryWithSheet(TcRow, "StopDetails")
    var TcRow = ReadFromXL.FindRowNum(Testcasename, "CreateOrder")
    DataDictLib1.pushToDictionaryWithSheet(TcRow, "CreateOrder")
    var Pickup = DataDictLib.getFromDictionary('Pickup');
    var Stopnumber = DataDictLib.getFromDictionary('StopNumber');
    var TitleCreate = DataDictLib1.getFromDictionary('CreateTitle');
    browser.executeScript("window.scrollTo(0,-500)");
    console.log( Stopnumber,"Stop number from")
    //var TitleCreate="Create New order"
    console.log("No of stops from sheet",Stopnumber)
    if (Stopnumber >= 1) {
      browser.sleep(3000);
      browser.executeScript("window.scrollTo(0,-500)");
      if(TitleCreate=="Create New Order"){
        for(var i=1;i<=Stopnumber;i++)
        {         
                  reuse.ClickElement((expandicon.get(0)), "Click on Expand icon of the origin")
                  browser.sleep(7000);
                  browser.executeScript("window.scrollTo(0,-500)");
                  reuse.ClickElement(stopdots, "Click overflow menu for adding stops")
                  reuse.ClickElement(addstop, "Select add stops from the menu")
                  browser.sleep(5000);
                  console.log("I value in add multiplestops function",i)
                  this.AddIntermediateStopDetails(Testcasename,"NULL","29/Dec/2017",i);
                  browser.sleep(7000);
        }
      }
      else (TitleCreate == "Create New Template")
      {
        for (var i = 1; i <= Stopnumber; i++) {
          expandiconTemplate.isPresent().then((elem) => {
            if (elem === true) {
              reuse.ClickElement((expandiconTemplate.get(0)), "Click on Expand icon of the origin")
              browser.sleep(5000);
              reuse.ClickElement(stopdotstemplate, "Click overflow menu for adding stops")
              reuse.ClickElement(addstop, "Select add stops from the menu")
              browser.sleep(5000);
              reuse.ClickElement((expandiconTemplate.get(1)), "Click on Expand icon of the origin")
              browser.sleep(5000);
              this.AddIntermediateStopDetails(Testcasename, AppointmentType, Appointmentdate, i);
              browser.sleep(7000);
            }
          });
        }
      }

    }
  }
  /*****************************************************************************************
    * 
   * MethodName:  SelectFirstorder
   * Description: To Select the first order from the list of orders displaye din Advanced search results
   * Parameter (if any):  Scheduled,pickupdate,Ordername
   * Return type:  Void
    ***************************************************************************************/


  SelectFirstorder() {
    SelectFirstorder.isPresent().then((elem) => {
      if (elem === true) {
        reuse.ClickElement((SelectFirstorder.get(0)), "Click the firstorder from the results list ")
        browser.sleep(4000);
        var viewpage = element(by.xpath("//span[text()='Order']"));
        // this.ElementWait(true,viewpage);
      }
    });
  }
  /*****************************************************************************************
     * 
    * MethodName:  Overrideall
    * Description: To overide the warning message while clicking next in Destination page
    * Parameter (if any):  NIl
    * Return type:  Void
     ***************************************************************************************/
  Overrideall() {
    Overidewarning.isPresent().then((elem) => {
      if(elem==true){
    warningMsg.isPresent().then((elem) => {
    
      var value = 0;
      {
        var Disp = warningMsg.getText().then((text) => {

          if (text.trim() == "Customer credit status is CREDIT HLD.") {
            console.log("Credit check failure is displayed as warning " + text);
          }
        })
      }
    });
    Overidewarning.isPresent().then((elem) => {
      if(elem==true){
      browser.sleep(2000);
      reuse.ClickElement(Overidewarning, "Click warning overide while clicking  next in Destination")
      browser.sleep(10000);
      }
    });
  }
  });
}
  /*****************************************************************************************
  * 
 * MethodName:  Equipment
 * Description: To add Equipment details when an order is created 
 * Parameter (if any):  NIL
 * Return type:  Void
  ***************************************************************************************/
  Equipment(Testcasename: string): void {

    var TcRow = ReadFromXL.FindRowNum(Testcasename, "Shipment&Equipment");

    DataDictLib.pushToDictionaryWithSheet(TcRow, "Shipment&Equipment");
    var EquipcategoryValue = DataDictLib.getFromDictionary('EquipmentCategory');
    var EquipmentTypeValue = DataDictLib.getFromDictionary('EquipmentType');
    var EquipmentLengthValue = DataDictLib.getFromDictionary('EquipmentLength');

    var protectionMaterialHandlingtext = DataDictLib.getFromDictionary('ProtectionMaterialHandling');
    reuse.ClickButtonwithText("Trailing Equipment");
   // reuse.ClickElement(btn_TrailingNumber,"Trailing number button")
    reuse.ClickElement(equipcategory, "Click Equipcategory Drop down")
    reuse.EnterValue(equipcategory, EquipcategoryValue, "Equipcategory to value")
    equipcategory.sendKeys(protractor.Key.ENTER);
    browser.sleep(2000);
    reuse.ClickElement(equiptypecode, "Click equiptypecode Drop down")
    reuse.EnterValue(equiptypecode, EquipmentTypeValue, "equiptypecode to value")
    equiptypecode.sendKeys(protractor.Key.ENTER);
    browser.sleep(2000);
    reuse.ClickElement(equiplength, "Click equiplength Drop down")
    reuse.EnterValue(equiplength, EquipmentLengthValue, "equiplength to value")
    equiplength.sendKeys(protractor.Key.ENTER);
    browser.sleep(2000);
    browser.executeScript("window.scrollTo(0,200)");
    //reuse.ClickElement(protectionMaterialHandling, "Click protectionMaterialHandling Drop down")
    //reuse.EnterValue(protectionMaterialHandling, protectionMaterialHandlingtext,"equiplength to value")
    //protectionMaterialHandling.sendKeys(protractor.Key.ENTER);




  }
  /*****************************************************************************************
    * 
   * MethodName:  dropdown
   * Description: To select value from a dropdown
   * Parameter (if any):  strval,Objelement
   * Return type:  Void
    ***************************************************************************************/
  dropdown(Objelement: any, strval: string): void {
    Objelement.count().then(function (total) {
      Objelement.each(function (item) {
        var index = 0
        if (total > index) {
          var Disp = item.getText().then((elem) => {
            if (elem.trim() === strval) {
              reuse.ClickElement(item, "Click drop down item")
              browser.sleep(3000);
            }
            else {
              console.log("View drop down is not available with the values");
            }
          });
        }
      })
    });
  }


  Operationalservices(Testcasename: string): void {
    OPService.isPresent().then((elem) => {
      if (elem === true) {
        OPServiceclose.count().then(function (total) {
          OPServiceclose.each(function (item) {
            var index = 0
            if (total > index) {
              item.click();
            }
          })
        });

        var TcRow = ReadFromXL.FindRowNum(Testcasename, "Shipment&Equipment");
        DataDictLib.pushToDictionaryWithSheet(TcRow, "Shipment&Equipment");
        var charge = DataDictLib.getFromDictionary('OPService');
        reuse.ClickElement(OPService, "Click OPService");
        reuse.EnterValue(OPService, charge, "OPService value")
        OPService.sendKeys(protractor.Key.ENTER);
      }
    });
  }

  CheckBilltoDetails(Testcasename: string) {
    var TcRow = ReadFromXL.FindRowNum(Testcasename, "CreateOrder");
    DataDictLib.pushToDictionaryWithSheet(TcRow, "CreateOrder");
    var BillTo = DataDictLib.getFromDictionary('BillTO');

    InfoIcon.click();
    const BilltoPopup = element(by.className(`billToPopover`));
    BilltoPopup.isDisplayed().
      then(result => {
        if (!result) {
          throw new Error(`Bill to Details Popup is not displayed`);
        }
      });

    expect(BilltoPopup.getText()).toContain(BillTo); // data to be displayed

    details.click();
    browser.sleep(3000);
  contactnav.click();
    
    


    // browser.getAllWindowHandles().then(function (handles) {
    //   browser.switchTo().window(handles[1]).then(function () {
        
    //   });
    // });

  }
  /*********************************************************************
     * 
    * MethodName:  BillToInfo  
    * Description: To View the BillTo details
    * Parameter (if any):  NIL
    * Return type:  Void
     ********************************************************************/
    BillToInfo(Testcasename) {
      
      
        }











}


























