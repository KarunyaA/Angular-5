import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";
import { Update_Objects } from "../ObjectRepository/Objects_Order"
import { Key, WebElement } from "selenium-webdriver";

import { ExcelReader } from "../CommonFiles/ReadFromXL"

import { DataDictionary } from "../DataFiles/DictionaryData"
import { ReusableFunctions } from "../FunctionalLibrary/ReusableFunctions"
var DictBU_OM = new DataDictionary();
var DictBU_EOM = new DataDictionary();
var OrderID;
let OBJCreate = new Update_Objects();
var ReadFromXL = new ExcelReader();
var DataDictLib = new DataDictionary();
var DataDictLib1 = new DataDictionary();
let reuse = new ReusableFunctions();
var ExcelDataSourceForConf = require('../CommonFiles/ReadFromXL');
var PushAndPullDataDictLib = require('../DataFiles/DictionaryData');
var optiondots = element.all(by.id("btn-showPopOver"));
var errorlink = element(by.xpath("//div[@class='caption']//a[@id='a-ruleExcep-desc']"));
var errorlinkname = element(by.css("[id='preferedName']"));
var errorlinkCmnt = element(by.css("[id='overRideCmtTxt']"));
//errordropDown=element(by.xpath("//p[text()='Reason']//following::select")).element(by.cssContainingText('option','EDI Tender Will Time-Out')); 
var errorDropdownClick = element(by.xpath("//div[@class='ui-select-container dropdown open']"))
var errordropDown = element(by.xpath("//a[@class='dropdown-item']//following::div[text()='EDI Tender Will Time-Out']"))
var OverideErrorButton = element(by.buttonText("Override"));
var CreateButtonOverview = element(by.xpath("//button[@id='btn-create' and  @type='button']"));
var Overideall = element(by.xpath("//div[@class='caption']//a[@id='a-overRideAll']"));
var errorparent = element.all(by.xpath("//div[@class='caption']//ul[@class='list-group mar-bot0']//li"));
var AllInRate = element(by.xpath("//div[text()='All In Rate ']//following::div[2]"));
var FuelSurcharge = element(by.xpath("//div[text()='Fuel Surcharge']//following::div[2]"));
var ShippingFlowMenu = element(by.css("[id='btn-append-to-body']"));
var CreateWithoutrTE = element(by.css("[id='a-createWithoutRate']"));
var RateReason = element(by.xpath("//p[text()='No Rates Available.']//following::select")).element(by.cssContainingText('option', 'Pending Manual Quote From Pricing Manager'));
//RateOptions
var create_btn = element(by.id("btnCreate"));
var createrate_btn = element(by.xpath("//*[text()='Rate Overview']//following::button[@id='btn-create'][1]"))
var overall_hdr = element(by.xpath("//*[text()='OVERALL']"));
var chckbox = element(by.id("checkx"));
var level = element(by.css("[formcontrolname=\"chargeLevelTypeCode\"]"));
var amntfield = element(by.id("amountField"));
var offerapproval = element(by.id("offerApprovalMsg"))
var comment_box = element(by.id("qrcomments"))


var errorDropdownClick=element(by.xpath("//div[@class='ui-select-container dropdown open']"))
var errordropDown=element(by.xpath("//a[@class='dropdown-item']//following::div[text()='EDI Tender Will Time-Out']"))
var OverideErrorButton=element(by.buttonText("Override"));
var CreateButtonOverview=element(by.xpath("//button[@id='btn-create' and  @type='button']"));
var Overideall=element(by.xpath("//div[@class='caption']//a[@id='a-overRideAll']"));
var errorparent=element.all(by.xpath("//div[@class='caption']//ul[@class='list-group mar-bot0']//li"));
var AllInRate=element(by.xpath("//div[text()='All In Rate ']//following::div[2]"));
var FuelSurcharge=element(by.xpath("//div[text()='Fuel Surcharge']//following::div[2]"));
var ShippingFlowMenu=element(by.xpath("//*[@id='btn-append-to-body']/span"));
var CreateWithoutrTE=element(by.css("[id='a-createWithoutRate']"));
var RateReason=element(by.xpath("//p[text()='No Rates Available.']//following::ng-select[1]")) 
var link_ShippingOption=element(by.xpath("//a[@id='a-shipngOptns']"))  //*[@class='modal-content']//h4[contains(text(),'Appointment')]
var dia_appointment=element(by.xpath("//*[@class='modal-content']//h4[contains(text(),'Appointment')]"))
export class ShippingOptionFunctions{
  /*********************************************************************
	 * 
	* MethodName:  ClickRateoption
	* Description: To click the rate option from the shipping option page
	* Parameter (if any):  NIL
	* Return type:  Void
	 ********************************************************************/
 async  ClickRateoption(Testcasename: string,Rownumber:number) {
    var TcRow=ReadFromXL.FindRowNum(Testcasename,"CreateOrder");
    DataDictLib.pushToDictionaryWithSheet(TcRow,"CreateOrder");
    // DataDictLib.pushToDictionaryWithSheet(TcRow,"StopDetails");
    // var createOption =DataDictLib.getFromDictionary('CreateRateFromShipping');
    var rownumbervalue =DataDictLib.getFromDictionary('Rateoption');
    var TcRow1=ReadFromXL.FindRowNum(Testcasename,"StopDetails");
    // DataDictLib1.pushToDictionaryWithSheet(TcRow,"StopDetails");
    // var createOption =DataDictLib1.getFromDictionary('CreateRateFromShipping');
    try{
    link_ShippingOption.isPresent().then((elem)=>{ 
      if(elem===true){
    browser.sleep(5000);
   browser.executeScript("window.scrollTo(0,500)");
    var EC = protractor.ExpectedConditions;
    
    
    browser.executeScript("window.scrollTo(0,-500)");
    browser.sleep(2000);
    this.RateSelection(Testcasename);
    browser.sleep(3000);
       browser.executeScript("window.scrollTo(0,500)");
  
       var val=(CreateButtonOverview).isDisplayed().then((elem)=>{ 
        if (elem===true){
          browser.sleep(2000)
         CreateButtonOverview.click();       
         console.log("Create button is clicked for the available rate"); 
         }
         else{
          console.log("Create button is not clicked for the available rate");
                   }
        }); 
        (dia_appointment).isDisplayed().then(async(elem)=>{ 
          if (elem===true){
reuse.ClickButtonwithText("Got It");
//this.quic
browser.sleep(20000)
          }
          else
          {
            browser.sleep(15000)
            var SuccessMessage=await reuse.ValidationMessage();
            if(SuccessMessage ==="Order Accepted Successfully")
            {
           console.log("Orderis accepted and moved to view order page")

            }
            else{   

    var index = 0;
    (errorparent).isDisplayed().then((element) => {
      if (element === true) {
        var val = (Overideall).isDisplayed().then((elem) => {
          if (elem === true) {
            // element(by.id("billtoaccount")).sendKeys("CACAB9")
            browser.sleep(3000);
            browser.executeScript("window.scrollTo(0,-500)");
            browser.sleep(2000);
            browser.actions().mouseMove(Overideall)
            reuse.ClickElement(Overideall, "Click overide all warning message")
            browser.sleep(2000);
            console.log("Warnings are overidden successfully");
          }
          else {
            console.log("Create opportunity is not displayed in the shipping options Flow menu");
          }
        });
    errorparent.count().then(function (total) {
      errorparent.each(function (item) {
        index++;
        if (total >= index) {
         
          (errorparent).get(0).isDisplayed().then((element) => {
            if (element === true) {
              var EC = protractor.ExpectedConditions;
              browser.wait(EC.visibilityOf(errorlink), 3000).then(function (elem) {
                if(elem==true)
                {
                errorlink.click();
                (errorDropdownClick).isPresent().then(function (bool) {
                  if (bool === true) {
                    reuse.ClickElement(errorDropdownClick, "Click Error drop down ")
                    reuse.ClickElement(errordropDown, "Click Value from error list")
                    reuse.ClickElement(OverideErrorButton, "Click Override button")
                    browser.sleep(2000);
                    // errorlinkname.sendKeys(protractor.Key.ENTER);
                  }
                });
                (errorlinkname).isPresent().then(function (bool) {
                  if (bool === true) {
                    errorlinkname.sendKeys("Keerthana Selvaraj");
                    browser.sleep(2000);
                    errorlinkname.sendKeys(protractor.Key.ENTER);
                  }
                });
                (errorlinkCmnt).isPresent().then(function (bool) {
                  if (bool === true) {
                    reuse.EnterValue(errorlinkCmnt, "Test", "Enter comment value")
                    reuse.ClickElement(OverideErrorButton, "Click Override button")
                    browser.sleep(2000);
                    console.log("The errors and warnings are overriden successfully");
                  }
                });
              }
              });
            
            }
          });
        } else
          console.log("No errors are available")
      });
    });
  }
});
    browser.executeScript("window.scrollTo(0,500)");
    browser.sleep(3000);  
    // if(createOption==="NULL"){
    // reuse.ClickButtonwithText("Create");  
    // }
    // else{
    //   console.log("Create option is not selected after overriding errors in Create overview")
    // }
  }
}
}); 
  }
}); 
    }
    catch{
console.log("Order is accepted")

    }
  }
  /*********************************************************************
     * 
    * MethodName:  ValidateRateOption
    * Description: To validate if the charges are available in the rate option Overview
    * Parameter (if any):  NIL
    * Return type:  Void
     ********************************************************************/
  ValidateRateOption() {
    browser.sleep(10000);
    browser.executeScript("window.scrollTo(0,-500)");
    var EC = protractor.ExpectedConditions;
    browser.wait(EC.visibilityOf(optiondots.get(0)), 20000).then(function () {
      reuse.ClickElement((optiondots.get(0)), "Click SO Drop down")
      browser.sleep(3000);
    });
    browser.executeScript("window.scrollTo(0,500)");
    AllInRate.isPresent().then((elem) => {
      if (elem === true) {
        var value = 0;
        {
          var Disp = AllInRate.getText().then((text) => {
            if (text.trim() != "0") {
              console.log("All In Rate is available in the rate overview popup");
            }
          })
        }
      }
    });
    FuelSurcharge.isPresent().then((elem) => {
      if (elem === true) {
        var value = 0;
        {
          var Disp = FuelSurcharge.getText().then((text) => {

            if (text.trim() != "0") {
              console.log("Fuel Surcharge is available in the rate overview popup");
            }
          })
        }
      }
    });
    reuse.ClickElement((optiondots.get(0)), "Click SO Drop down")
  }
  /*********************************************************************
	 * 
	* MethodName:  CreateWithoutRate
	* Description: To Create rate by selecting Createwithoutrate option
	* Parameter (if any):  NIL
	* Return type:  Void
	 ********************************************************************/
 async CreateWithoutRate() {

    reuse.ClickElement(ShippingFlowMenu, "Click on the overflow menu")
    var val = (CreateWithoutrTE).isDisplayed().then((elem) => {
      if (elem === true) {
        // element(by.id("billtoaccount")).sendKeys("CACAB9")
        reuse.ClickElement(CreateWithoutrTE, "Click CreateWithoutrTE")
        console.log("Create without Rate is clicked from the dropdown");
      }
      else {
        console.log("Create without Rate is not displayed in the shipping options Flow menu");
      }
    });
    reuse.ClickElement(RateReason, "Click RateReason")
    reuse.EnterValue(RateReason, "Pending", "Enter reason for no rate")
    RateReason.sendKeys(protractor.Key.ENTER);
    reuse.ClickButtonwithText("Create");
    browser.sleep(3000);
    var index = 0;
    (errorparent).isDisplayed().then((element) => {
      if (element === true) {
        var val = (Overideall).isDisplayed().then((elem) => {
          if (elem === true) {
            // element(by.id("billtoaccount")).sendKeys("CACAB9")
            browser.sleep(3000);
            browser.executeScript("window.scrollTo(0,-500)");
            browser.sleep(2000);
            browser.actions().mouseMove(Overideall)
            reuse.ClickElement(Overideall, "Click overide all warning message")
            browser.sleep(2000);
            console.log("Warnings are overidden successfully");
          }
          else {
            console.log("Create opportunity is not displayed in the shipping options Flow menu");
          }
        });
    errorparent.count().then(function (total) {
      errorparent.each(function (item) {
        index++;
        if (total >= index) {
         
          (errorparent).get(0).isDisplayed().then((element) => {
            if (element === true) {
              var EC = protractor.ExpectedConditions;
              browser.wait(EC.visibilityOf(errorlink), 3000).then(function (elem) {
                if(elem==true)
                {
                errorlink.click();
                (errorDropdownClick).isPresent().then(function (bool) {
                  if (bool === true) {
                    reuse.ClickElement(errorDropdownClick, "Click Error drop down ")
                    reuse.ClickElement(errordropDown, "Click Value from error list")
                    reuse.ClickElement(OverideErrorButton, "Click Override button")
                    browser.sleep(2000);
                    // errorlinkname.sendKeys(protractor.Key.ENTER);
                  }
                });
                (errorlinkname).isPresent().then(function (bool) {
                  if (bool === true) {
                    errorlinkname.sendKeys("Keerthana Selvaraj");
                    browser.sleep(2000);
                    errorlinkname.sendKeys(protractor.Key.ENTER);
                  }
                });
                (errorlinkCmnt).isPresent().then(function (bool) {
                  if (bool === true) {
                    reuse.EnterValue(errorlinkCmnt, "Test", "Enter comment value")
                    reuse.ClickElement(OverideErrorButton, "Click Override button")
                    browser.sleep(2000);
                    console.log("The errors and warnings are overriden successfully");
                  }
                });
              }
              });
            
            }
          });
        } else
          console.log("No errors are available")
      });
    });
  }
});
    browser.sleep(15000);
    var SuccessMessage=await reuse.ValidationMessage();
    if(SuccessMessage ==="Order Accepted Successfully")
    {
   console.log("Orderis accepted and moved to view order page")

    }
  }
  /*********************************************************************
     * 
    * MethodName:  RateSelection
    * Description: To Create rate by selecting Create from shipping option
    * Parameter (if any):  NIL
    * Return type:  Void
     ********************************************************************/
  RateSelection(Testcasename) {

    var TcRow = ReadFromXL.FindRowNum(Testcasename, "CreateOrder");

    DataDictLib.pushToDictionaryWithSheet(TcRow, "CreateOrder");
    var RateOption = DataDictLib.getFromDictionary('Rate');
    //var RateOption = 'Published'

    var Disp = element.all(by.xpath("//*[@class='visible']//following::span[contains(text(),'" + RateOption + "')]//following::span[1]")).get(0)
    Disp.getText().then((elem) => {
      //reuse.ClickElement(Disp,"Rate is selected")
      if (elem !== "$0.00") {
        browser.sleep(5000);
        //browser.executeScript("window.scrollTo(0,500)");

        //var rateclick = element.all(by.xpath("//*[@class='visible']//following::span[@id='span-3dots']//preceding::span[text()='" + RateOption + "']"));
        var rateclick = element.all(by.xpath("//*[@class='visible']//following::span[contains(text(),'" + RateOption + "')]//following::span[@id='span-3dots']")).get(0);
        reuse.ClickElement(rateclick, "Rate is selected")
        browser.sleep(5000);
        //browser.executeScript("window.scrollTo(0,-500)");


      }
      else {
        console.log("The" + RateOption + "does not contain any rate");
        this.CreateWithoutRate();
      }
    })
  }
  /*********************************************************************
	 * 
	* MethodName:  QuickRateSheet
	* Description: To Create Quick rate by selecting market rate
	* Parameter (if any):  NIL
	* Return type:  Void
	 ********************************************************************/
  QuickRateSheet() {
    browser.sleep(10000);
    //browser.executeScript("window.scrollTo(0,200)");


    offerapproval.sendKeys("Document");
    comment_box.click();
    browser.sleep(2000);

    create_btn.click();


    browser.sleep(5000);
    // chckbox.click();
    // level.click()
    // level.sendKeys("O");
    // level.sendKeys(protractor.Key.ENTER);
    // amntfield.sendKeys("")
  }
}






























