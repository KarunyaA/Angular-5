import { ElementFinder, browser, by, element, By } from "protractor";
import { protractor } from "protractor/built/ptor";
import { Update_Objects } from "../ObjectRepository/Objects_Order"
import { Key, WebElement } from "selenium-webdriver";

import { ExcelReader } from "../CommonFiles/ReadFromXL"
import { CreateOrderFunctions} from "../PageFiles/OM_CreateOrder";
let ORDRegression  = new  CreateOrderFunctions;

import { DataDictionary } from "../DataFiles/DictionaryData"
import  { ReusableFunctions }  from  "../FunctionalLibrary/ReusableFunctions"
import { CommonFunctions } from "../FunctionalLibrary/CommonFunctions"
import { throws } from "assert";
var common = new CommonFunctions()
var  DictBU_OM  =  new  DataDictionary();
var  DictBU_EOM  =  new  DataDictionary();
var OrderID;
let  OBJCreate  = new Update_Objects();
var ReadFromXL = new ExcelReader();
var DataDictLib = new DataDictionary();
var DataDictLib1 = new DataDictionary();
let reuse = new ReusableFunctions();
var ExcelDataSourceForConf = require('../CommonFiles/ReadFromXL');
var PushAndPullDataDictLib = require('../DataFiles/DictionaryData');
//#region Order History
////:::Order History:::////
var hstrybtn = element(by.xpath("//*[text()='Order History']"));
var hstrytable = element(by.xpath("//*[@class='datatable-body']"));
var cnt = element.all(by.xpath("//*[@class='datatable-row-center datatable-row-group']"))
var WarningsOveridden = element(by.xpath("//span[text()='Warnings Override:']//following::a[1]"));
var AcceptanceRulepass = element(by.xpath("//span[text()='Acceptance Rules:']//following::span[text()='Pass']"));
var Orderstatus = element(by.xpath("//span[text()='Order Status Change']//following::span[text()='Accepted']"));
var apnmt_ordovrview = element(by.xpath("//div[text()='Scheduled Appointment ']//following::span[1]/span[1]"));
var apnmt_stop = element(by.xpath("//span[text()='Origin']//following::span[@class='pad0 font-styles'][1]"));
var PickDateorderOverview = element(by.xpath("//div[text()='Scheduled Appointment']//following::span[1]"));
var DelidateorderOverview = element(by.xpath("//div[text()='Scheduled Appointment']//following::span[2]"));
var originstopedit = element(by.xpath("//span[text()='Origin']//following::span[@id='span-ritArr'][1]"));
var pickupstopedit = element(by.xpath("//span[text()='Origin']//following::span[@id='span-ritArr'][2]"));
var editbtn = element(by.id("span-jbhedit"));
var requestedservices = element(by.xpath("//h3[text()='Requested Service(s)']//following::input[@role='combobox'][1]"));
var miles = element(by.xpath("//button[@id='btn-info']//following::div[@class='col-md-1']/span"));
var TotalMiles = element(by.xpath("//span[text()='Total Miles']//following::span[1]"));
var SelectFirstorder = element.all(by.xpath("//div[@class='datatable-row-center datatable-row-group']//following::div[@class='GridRowSpanStyle']//h6"));
var Destin = element(by.css("[placeholder='Destination Marketing Area']"));

var Rulename = element(by.xpath("//*[text()='Rule Name']"));
var filter_clk = element(by.css('[id="span-jbhFilt"]'));
var template_filter = element(by.css('[id="span-filter"]'));
var association_clk = element(by.xpath("//div[@class='panel-heading']//h5[span[text()='Association Level ']]"));
var status_clk = element(by.xpath("//div[@class='panel-heading']//h5[span[text()='Status ']]"));
var ratesheet = element(by.xpath("//h4[text()='Rate Sheet']"));
var rate_level = element(by.xpath("//*[text()='Rate Information']//following::span[span][2]"));
var rate_edit = element(by.xpath("//*[text()='Rate Information']//following::span[span][2]"));
var Routeplan = element(by.xpath("//h4[text()='Route Plan']"))
var OrderFlowMenu = element(by.xpath("//h1[@class='alignHeading']//following::div[1]"));
//a[text()='Reject Order']
var RejectOrder = element(by.xpath("//a[text()='Reject Order']"));
var RejectReason = element(by.xpath("//ng-select[@formcontrolname='rejectOption']"));
var RejectComments = element(by.xpath("//textarea[@formcontrolname='rejectComments']"));
var username =  element(by.id("j_username"));
var password =  element(by.id("j_password"));
var loginbutton = element(by.xpath("//input[@value='login']"));
var Savebuttonreject = element.all(by.xpath("//button[@id='btn-save' and text()='Save']"));
var load = element(by.xpath("//p[contains(text(),'Active Load')]//span[1]"));
//#endregion
//#region backfill objects

////////////////////////////////////////////////////backfill//////////////////////////////////////////

//BUval = element(by.xpath("//*[text()='Business Unit']//following::p[1]"));
var BUval = element(by.xpath("//span[text()='Service Offering']//following::span[1]"));
var Servicelvl = element(by.xpath("//span[text()='Service Level']//following::span"));
var TrailerNum = element(by.xpath("//p[text()='Trailer']//following::p[1]"));
var Billtoval = element(by.xpath("//strong[text()='Bill to Account']//following::div[1]/div[1]"));
var ShipperVal = element(by.xpath("//h4[text()='Origin ']//following::div[1]/div[1]"));
var RecieverVal = element(by.xpath("//h4[text()='Destination ']//following::div[1]/div[1]"));
var totalmiles = element(by.xpath("//*[text()='Total Miles']//following::span[1]"));
//#endregion
//#region EOM
/////EOM
var Loadid = element(by.id("eomSearchMain:baseSearchVal"));
var loadlink = element(by.id("frmOrderListing:lOrderListing:0:optxtOrderNumberActionFocusLink"));
var loaddetail = element(by.id("eomOrderDetail:orderDetailminimizer"));
var stopdetails = element(by.id("eomOrderDetail:nonStopsminimizer"));
var BUdivision = element(by.xpath("//*[@id='eomOrderDetail:divisionlist']/option[@selected='selected']"));
var Billtovaleom = element(by.id("eomOrderDetail:billto"));
var mileeom = element(by.id("eomOrderDetail:ttlMiles"));
//#endregion
//#region MapView
//MapView:
var icon_mapview = element(by.id("span-map"));
var img_map = element(by.id("map"));
var img_infoIcon = element.all(by.id("span-soliInfo"));
//#endregion
//#region update Party details
//update Party details
var icon_editparty = element(by.xpath("//*[text()='Accounts and Contacts']//following::div[@class='icon-jbh_edit icon-edit'][1]"));
var txt_SolicitorDD = element(by.css("[formcontrolname='solicitorCodeContact']"));
var icon_addparty = element(by.xpath("//span[@id='span-addAdntParty']//i"));
var txt_Accountname = element(by.id("additionalparty"));
var txt_Accountrole = element(by.css("[formcontrolname='accountRole']"));
var btn_saveparty = element(by.xpath("//*[text()='Edit Accounts']//following::button[text()='Save'][1]"));
var icon_edit = element(By.className("icon-jbh_edit icon-edit"))
var txt_ServiceOffering = element.all(by.xpath("//span[text()='Service Offering']//following::strong"));
var icon_orderBack = element(By.className("icon-jbh_back font40 cursor-pointer"));
var link_shippingOption = element(by.xpath("//h4[text()='View Selected Shipping Options'][1]"));
var clickoptions = element(by.xpath("//*[@class='pull-right icon-jbh_three-dots mar-top20 mar-left10 font24 cursor-pointer']"));
var makecopy = element(by.xpath("//*[contains(text(),'Make Copy')]"));
//#endregion 
//#region Rate Sheet
//Rate Sheet
var txt_RateInfo = element(by.xpath("//*[text()='Rate Information']"));
var dot_rateFlow = element(by.id("btn-append-to-body"));
var btn_FlatRate = element(By.className("btn btn-default btn-group-primary active"));
var Chargelevel = element(by.css('[formcontrolname="chargeLevelTypeCode"]'))
var chargecode = element(by.id("chargeDescriptionTxt"));
var chargeamount = element(by.id("chargeRateAmount"));
var chargequantity = element(by.id("chargeQuantity"));
var chargecomments = element(by.id("chargeComments"));
var authno = element(by.id("customerAuthorizationNumber"));
var authby = element(by.id("customerAuthorizationFirstName"));
var originstopedit = element(by.xpath("//span[text()='Origin']//following::span[@id='span-ritArr'][1]"));
var pickupstopedit = element(by.xpath("//span[text()='Origin']//following::span[@id='span-ritArr'][2]"));
var editbtn = element(by.id("span-jbhedit"));
var requestedservices = element(by.xpath("//h3[text()='Requested Service(s)']//following::input[@role='combobox'][1]"));
var miles = element(by.xpath("//button[@id='btn-info']//following::div[@class='col-md-1']/span"));
var TotalMiles = element(by.xpath("//span[text()='Total Miles']//following::span[1]"));
var btn_saveCharge = element.all(by.xpath("//button[text()='Save']"));
var txt_RateType = element(by.xpath("//span[text()='Type']//following::span[1]"))
//#endregion
//#region Quick rate
//Create Quick rate
var link_CreateQuickRate = element(by.xpath("//h4[text()='Create a Quick Rate']"));
var updateBUSO_btn = element(by.xpath("//*[text()='Service Offering']//following::div[@class='icon-jbh_edit icon-edit pull-right']"));
var BU_update = element(by.css("[formcontrolname=\"financeBusinessUnitCode\"]"));
var BU_updateclck = element(by.xpath("//*[text()='Edit Service Offering']//following::input[@class='form-control ui-select-search'][1]"));
var SO_update               =element(by.xpath("//*[@formcontrolname='serviceOfferingCode']"));
//var SO_update = element(by.xpath("//*[@id='serviceOfferingCode']//i[@class='caret pull-right']"));
var SO_updateclck = element(by.xpath("//*[text()='Edit Service Offering']//following::input[@class='form-control ui-select-search'][1]"));
var validateBU = element(by.xpath("//*[text()='Business Unit']//following::p[1]"));
var validateSO = element(by.xpath("//*[text()='Business Unit']//following::p[text()='Service Offering']//following::p[1]"));
//#endregion
//#region Update
//update
var icon_OriginArrow = element.all(by.id("span-ritArr"));
var dd_unitQuantity = element(by.css("[formcontrolname='itemHandlingTypeQuantity']"))
var icon_OriginEdit = element(by.id("span-jbhedit"));
var dd_serviceLevel = element(by.css("[formcontrolname='serviceLevelTypeCode']"))
//#endregion
//Electronic Transfer
var link_Electronictransfer = element(by.xpath("//h4[text()='Electronic Transfer']"));
var txt_ucrdata = element.all(by.xpath("//*[@class='datatable-row-wrapper']//*[@class='datatable-body-cell sort-active']//span[text()='Pending']"));
var txt_ucrdetails = element(by.xpath("//h3[text()='Transaction Details']"));

//Equipment Details
var edit_equipment      =element(by.xpath("//h3[text()='Equipment']//following::div[@class='icon-jbh_edit icon-edit']"));
var equip_category      =element(by.xpath("//*[@id='equipmentCategory']//span//i[@class='caret pull-right']"));   
var equipinput           =element(by.xpath("//ng-select[@placeholder='Equipment Category']"));
var equipsave_Btn        =element(by.xpath("//*[@class='btn btn-primary col-md-3 btns']//button[text()='Save']"));
var save_BUSO            =element(by.xpath("//*[text()='Edit Service Offering']//following::button[text()='Save'][1]"));
//threedot             =element(by.xpath("//h1[@class='alignHeading']//following::*[@placement='bottom'][1]"));
//reconsign          =element(by.xpath("//*[text()='Reconsignment']"));
var reconsign            =element(by.id("a-reconsgmt"));
var reason_btn           =element(by.xpath("//*[@formcontrolname='reasonCode']"));
//Location
var txt_Location= element(by.css("[formcontrolname='locationID']"));
var txt_emergencyResponsePhoneNumber= element(by.css("[formcontrolname='emergencyResponsePhoneNumber']")); 
var dd_packingGroup = element(by.css("[formcontrolname='packaginggroup']"));
var icon_placardSlider= element(by.xpath("//*[text()='Placard Required']/..//*[@class='slider']"));
var btn_SaveOriginStop=element.all(by.xpath("//*[@class='btn link-icon-secondary requested_apnt'][1]//following::*[text()='Save'][1]"));

//AOU
var Servicelevel = element(by.xpath("//div[div[contains(text(),'Service Level')]]//span//i[@class='caret pull-right']")) ;
 var Serviceleveldrpdwn = element(by.xpath("//div[div[contains(text(),'Service Level')]]//ul//li//div//a//div[text()='Premium']"));
 var ordervalue =element(by.id("order-value"));
 var bondhldrle = element(by.xpath("//div[div[contains(text(),'Bond Holder Role')]]//span//i[@class='caret pull-right']"));
 var bondhldparty = element(by.xpath("//div[div[contains(text(),'Bond Holder Party')]]//span//i[@class='caret pull-right']"));
 var bondhldtype = element(by.xpath("//div[div[contains(text(),' Bond Holder Type')]]//span//i[@class='caret pull-right']"));
 var bondhldidentf = element(by.id("bond-holder-identifier"));
 var entryno = element(by.id("entry-number"));
 var portofexit = element(by.xpath("//div[div[contains(text(),'Port of Exit')]]//span//i[@class='caret pull-right']"));
 var portofentry = element(by.xpath("//div[div[contains(text(),'Port of Entry')]]//span//i[@class='caret pull-right']"));
 var internationalservice = element(by.xpath("//div[div[contains(text(),'International Service')]]//i[@class='caret']"));
 
 var Aousavebtn = element(by.xpath("//h4[text()='Edit Shipment Information']//following::button[@id='btn-save'][1]"));
 var Aousavbtnso =element(by.className("btn btn-primary mar-left10 minHeight40"));

 var addinsurct = element(by.className('form-control pad-top10 ng-untouched ng-pristine ng-invalid'));
 var addinsurctdrpdwn = element.all(by.xpath("//div[div[contains(text(),'Tags')]]//div//span//i[@class='caret pull-right']"));
 var shipmentid = element(by.id("shipment-identification"));
 var closeshipreq = element(by.xpath(" //span[span[text()='International Shipment']]//a[@class='close icon-jbh_close font24']"));
 var shipmentreq = element(by.xpath("//div[div[contains(text(),'Shipment Requirements')]]//i[@class='caret']"));
 var vesselnumber = element(by.id("vessel-number"));
 var voyagenumber = element(by.id("voyage-number"));
 //Emergency Contact
 var icon_OriginArrow = element.all(by.id("span-ritArr"));
 var icon_OriginEdit = element(by.id("span-jbhedit"));
 var dd_itemChar = element(by.css("[formcontrolname='itemCharacteristics']"));
 var txt_EmergencyResponseContact = element(by.css("[formcontrolname='providerContractNumber']"));
 var txt_emergencyResponsePhoneNumber= element(by.css("[formcontrolname='emergencyResponsePhoneNumber']")); 
 var dd_packingGroup = element(by.css("[formcontrolname='packaginggroup']"));
 var icon_placardSlider= element(by.xpath("//*[text()='Placard Required']/..//*[@class='slider']"));
 //Equip Number
 var txt_TrailerNumber = element(by.css("[formcontrolname='trailerNumber']"));
 var btn_SaveEquipment=element(by.xpath("//label[text()='Chasis Prefix']//following::*[text()='Save'][1]"));
 var txt_TrailerPrefix = element(by.css("[formcontrolname='trailerPrefix']"));
//Item details
var txt_HandlingUnitWeight = element(by.css("[formcontrolname='itemHandlingUnitWeight']"));
var dd_HandlingUnit = element(by.css("[formcontrolname='itemHandlingTypeCode']"));
var txt_itemQty = element(by.css("[formcontrolname='packagingUnitTypeQuantity']"));
var txt_itemWeight = element(by.css("[formcontrolname='itemWeight']"));
 //edit icon

 var Editshipment = element(by.className("icon-jbh_edit cursor-pointer"));
var editserviceoff = element(by.className("icon-jbh_edit icon-edit pull-right"));
 //AOU
 var Servicelevel = element(by.xpath("//div[div[contains(text(),'Service Level')]]//span//i[@class='caret pull-right']")) ;
 var Serviceleveldrpdwn = element(by.xpath("//div[div[contains(text(),'Service Level')]]//ul//li//div//a//div[text()='Premium']"));
 var ordervalue =element(by.id("order-value"));
 var bondhldrle = element(by.xpath("//div[div[contains(text(),'Bond Holder Role')]]//span//i[@class='caret pull-right']"));
 var bondhldparty = element(by.xpath("//div[div[contains(text(),'Bond Holder Party')]]//span//i[@class='caret pull-right']"));
 var bondhldtype = element(by.xpath("//div[div[contains(text(),' Bond Holder Type')]]//span//i[@class='caret pull-right']"));
 var bondhldidentf = element(by.id("bond-holder-identifier"));
 var entryno = element(by.id("entry-number"));
 var portofexit = element(by.xpath("//div[div[contains(text(),'Port of Exit')]]//span//i[@class='caret pull-right']"));
 var portofentry = element(by.xpath("//div[div[contains(text(),'Port of Entry')]]//span//i[@class='caret pull-right']"));
 var internationalservice = element(by.xpath("//div[div[contains(text(),'International Service')]]//i[@class='caret']"));
 
  var Aousavebtn = element(by.xpath("//h4[text()='Edit Shipment Information']//following::button[@id='btn-save'][1]"));
 var Aousavbtnso =element(by.className("btn btn-primary mar-left10 minHeight40"));
 
 var addinsurct = element(by.className('form-control pad-top10 ng-untouched ng-pristine ng-invalid'));
 var addinsurctdrpdwn = element.all(by.xpath("//div[div[contains(text(),'Tags')]]//div//span//i[@class='caret pull-right']"));
 var shipmentid = element(by.id("shipment-identification"));
 var closeshipreq = element(by.xpath(" //span[span[text()='International Shipment']]//a[@class='close icon-jbh_close font24']"));
 var shipmentreq = element(by.xpath("//div[div[contains(text(),'Shipment Requirements')]]//i[@class='caret']"));
 var vesselnumber = element(by.id("vessel-number"));
 var voyagenumber = element(by.id("voyage-number"));
 
 //edit icon
 
 var Editshipment = element(by.className("icon-jbh_edit cursor-pointer"));
   var editserviceoff = element(by.className("icon-jbh_edit icon-edit pull-right"));
 var Accountcntedit = element(by.xpath("//div[div[h3[text()='Accounts and Contacts']]]//div[@class='icon-jbh_edit icon-edit']"));

 export class ViewOrderFunctions {
  /*****************************************************************************************
     * 
    * MethodName:  OrderHistory
    * Description: To verify the order history details.
    * Parameter (if any):  AppointmnetDatepickup,appointmentdateDelivery
    * Return type:  Void
 ***************************************************************************************/
  OrderHistory() {
    var EC = protractor.ExpectedConditions;
    browser.wait(EC.visibilityOf(hstrybtn), 30000).then(function () {
      browser.executeScript("window.scrollTo(0,2000)");
      reuse.ClickElement(hstrybtn, "Click on history link")
      browser.sleep(5000);
    });
    var val = (hstrytable).isPresent().then((elem) => {
      if (elem === true) {
        console.log("Order History is  available");
        cnt;
        cnt.count().then((intcnt) => {
          if (intcnt > 0) {
            console.log("Records count is available" + intcnt);
          }
          else {
            console.log("Records count are not found")
          }

          AcceptanceRulepass.isPresent().then((elem) => {
            if (elem === true) { console.log("Acceptance rule is passed"); }
            else
              console.log("Acceptance rule is not passed");
          });
          Orderstatus.isPresent().then((elem) => {
            if (elem === true) { console.log("order status is changed from pending to accepted"); }
            else
              console.log("order status is not changed from pending to accepted");
          });
        })
      }

      else {
        console.log("Order History is not available")
      }
    })
  }
  /*****************************************************************************************
	 * 
	* MethodName:  AppointmentValidation
	* Description: To validate the appointmetn details of the order
	* Parameter (if any):  NIL
	* Return type:  Void
	 ***************************************************************************************/
  MakeCopy() {

    clickoptions.click();
    browser.sleep(2000);
    makecopy.click();

  }


  /*****************************************************************************************
     * 
    * MethodName:  AppointmentValidation
    * Description: To validate the appointmetn details of the order
    * Parameter (if any):  NIL
    * Return type:  Void
     ***************************************************************************************/

  AppointmentValidation() {
    this.ElementValidation(apnmt_ordovrview);
    this.ElementValidation(apnmt_stop);
  }
  /*****************************************************************************************
     * 
    * MethodName:  ElementValidation
    * Description: To validate the element details of the order
    * Parameter (if any):  Scheduled,pickupdate,Ordername
    * Return type:  Void
     ***************************************************************************************/
  ElementValidation(Objelement): void {

    Objelement.isPresent().then((elem) => {
      if (elem == true) {
        Objelement.getText().then((text) => {
          console.log(text);
          console.log("Appointment details is present in order overview" + text);
        })
      }
    })
  };
  /*****************************************************************************************
      * 
     * MethodName:  DateValidationCreateOrderOverview
     * Description: To validate the date details in order overview
     * Parameter (if any):  AppointmnetDatepickup,appointmentdateDelivery
     * Return type:  Void
  ***************************************************************************************/

  DateValidationCreateOrderOverview(AppointmnetDatepickup, appointmentdateDelivery): void {

    PickDateorderOverview.isPresent().then((elem) => {
      if (elem == true) {
        PickDateorderOverview.getText().then((text) => {
          var date = text.split(" ");
          var PickupDate = date[0];
          var pickupTime = date[1];
          if (PickupDate == AppointmnetDatepickup) {
            console.log("Pickup Appointment details and Time zone in Order overview  is same as the appointment date while creating the order " + text);
          }
        })
      }
    });
    DelidateorderOverview.isPresent().then((elem) => {
      if (elem == true) {
        DelidateorderOverview.getText().then((text) => {
          var date = text.split(" ");
          var Deliverydate = date[0];
          var DeliveryTime = date[1];
          if (Deliverydate == appointmentdateDelivery) {
            console.log("Delivery Appointment details and Time Zone in Order overview is same as the appointment date while creating the order " + text);
          }
        })
      }
    });
  }
  /*****************************************************************************************
    * 
   * MethodName:  DateValidationCreateOrderOverview
   * Description: To validate the date details in order overview
   * Parameter (if any):  AppointmnetDatepickup,appointmentdateDelivery
   * Return type:  Void
***************************************************************************************/

  EditStops() {
    reuse.ClickElement(originstopedit, "Click origin Edit stops")
    reuse.ClickElement(editbtn, "Click on edit button")
    reuse.ClickElement(requestedservices, "Click E=requested services")
    reuse.EnterValue(requestedservices, "Pickup Trailer", "Enter requested Services")
    requestedservices.sendKeys(protractor.Key.ENTER);
  }
  /*****************************************************************************************
     * 
    * MethodName:  TotalMilesCreateOrderOverview
    * Description: To validate the total miles in the order overview
    * Parameter (if any): OBJElement
    * Return type:  Void
     ***************************************************************************************/
  TotalMilesCreateOrderOverview(OBJElement) {
    OBJElement.isPresent().then((elem) => {
      var  value = 0;
      {
        var  Disp =  OBJElement.getText().then((text ) => {
          if (text.trim() != "0") {
            console.log("Total miles is displayed for the order " +  text);
          }
        })
      }
    });
  }
  /*****************************************************************************************
  * 
 * MethodName:  OrderHistoryWarningsoverride
 * Description: To OrderHistoryWarningsoverride in order overview
 * Parameter (if any):  
 * Return type:  Void
***************************************************************************************/

  OrderHistoryWarningsoverride() {

    reuse.ClickElement(hstrybtn, "Click History button")
    browser.sleep(5000);
    var  val = (hstrytable).isPresent().then((elem) => {
      if  (elem === true) {
        console.log("Order History is  available");
        cnt;
        cnt.count().then((intcnt) => {
          if (intcnt > 0) {
            console.log("Records count is available" + intcnt);
          }
          else {
            console.log("Records count are not found")
          }

          WarningsOveridden.isPresent().then((elem) => {
            if  (elem === true) { console.log("Credit Check Failure warning is displayed"); }
            else
              console.log("Credit Check Failure warning is not displayed");
          });

        })
      }

      else {
        console.log("Order History is not available")
      }
    })


  }

  /*****************************************************************************************
    * 
   * MethodName:  SelectFirstorder
   * Description: To Select the first order from the list of orders displaye din Advanced search results
   * Parameter (if any):  Scheduled,pickupdate,Ordername
   * Return type:  Void
    ***************************************************************************************/
  SelectFirstorder() {
    SelectFirstorder.isPresent().then((elem) => {
      if (elem === true) {
        reuse.ClickElement((SelectFirstorder.get(0)), "Click the firstorder from the results list ")
        browser.sleep(4000);
        var viewpage = element(by.xpath("//span[text()='Order']"));
        // this.ElementWait(true,viewpage);
      }
    });
  }
  /*****************************************************************************************
       * 
      * MethodName:  RateSheet
      * Description: To validate the Rate details in view  order overview
      * Parameter (if any):  AppointmnetDatepickup,appointmentdateDelivery
      * Return type:  Void
   ***************************************************************************************/
  RateSheet() {

    common.ElementWait(true, Rulename);
    browser.executeScript("window.scrollTo(0,200)");
    browser.sleep(5000)
    reuse.ClickElement(ratesheet, "Click rate sheet")
    common.ElementWait(true, rate_level);
    rate_edit.isPresent().then((elem: any) => {
      if (elem === true) {
        console.log("edit button is present");
        reuse.ClickElement(rate_edit, "Click Edit rate")
      }
      else {
        console.log("edit button is not present");

      }
    });
  }
  /*****************************************************************************************
 * 
* MethodName:  RejectOrder
* Description: To reject an order from view order screen
* Parameter (if any):  
* Return type:  Void
***************************************************************************************/
  RejectOrder() {
    reuse.ClickElement(OrderFlowMenu, "Click order overflow menu")
    reuse.ClickElement(RejectOrder, "Click Reject option")
    browser.sleep(2000);
    reuse.ClickElement(RejectReason, "Click reject reason")
    reuse.EnterValue(RejectReason, "No Capacity", " Enterreject reason")
    RejectReason.sendKeys(protractor.Key.ENTER);
    reuse.EnterValue(RejectComments, "Test", "Enter Reject comments")
    browser.sleep(2000);
    //this.ClickButtonwithText("Save");
    reuse.ClickElement((Savebuttonreject.get(3)), "Click Save button")
    browser.sleep(3000);
  }
  /*****************************************************************************************
      * 
     * MethodName:  RoutePlan
     * Description: To validate the route plan details in order overview
     * Parameter (if any):  AppointmnetDatepickup,appointmentdateDelivery
     * Return type:  Void
  ***************************************************************************************/
  async RoutePlan(Testcasename)  {
    browser.sleep(5000)
    browser.executeScript("window.scrollTo(0,-200)");
    browser.sleep(3000)
    var EC = protractor.ExpectedConditions;
    //browser.wait(EC.visibilityOf(optiondots.get(Rownumber)), 20000).then(function() {
    //reuse.ClickElement(Routeplan, "Click route plan ")
    browser.executeScript("window.scrollTo(0,-200)");
    try {
      var LoadNumber
      browser.wait(EC.visibilityOf(load), 5000).then(async ()=> {

        await load.getText().then((elem: any) => {
          if (elem != "")
            console.log("Load id is generated for the order" + elem);
            var LoadNumber = elem
        });
        return LoadNumber
      });
     
    }
    
    catch{

      console.log("Load id is not generated for the order");

    }

  }
  /*****************************************************************************************
       * 
      * MethodName:  FetchDatafromOM
      * Description: To FetchDatafromOM
      * Parameter (if any): 
      * Return type:  Void
   ***************************************************************************************/
  async FetchDatafromOM() {

    var BUnitvalue;
    var BUval1;
    var BUFinal
    var billto;
    var totalmile;
    // var DictServicelvl_OM= new DataDictionary();
    // var DictTotalmile=new DataDictionary();

    // BUval1 = await reuse.getTextValueFromElement(BUval)

    await reuse.getTextValueFromElement(BUval).then((text) => {
      BUnitvalue = text
      BUFinal = BUnitvalue.replace(" -", "");
    });
    //BUFinal= BUnitvalue.replace(" -","");
    //console.log(BUFinal);

    await reuse.getTextValueFromElement(Billtoval).then((text) => {
      billto = text

    });



    var firstsplit = billto.split('(')



    var billtocode = firstsplit[1];


    var secondsplit = billtocode.split(')');
    var BillTo = secondsplit[0];


    //console.log(BillTo);
    await reuse.getTextValueFromElement(totalmiles).then((text) => {
      totalmile = text
    });
    //console.log(totalmile);



    DictBU_OM["BusUnit"] = BUval1;
    DictBU_OM["Billto"] = BillTo;
    DictBU_OM["totalmile"] = totalmile;


    return DictBU_OM;

  }

  async FetchDatafromEOM() {


    var BU;
    var BillTO;
    var mile;

    await reuse.getTextValueFromElement(BUdivision).then((text) => {
      BU = text
    });
    console.log("Inside function" + BU);

    // await reuse.getTextValueFromElement(Billtovaleom).then((text)=>{
    //   Billto = text 
    // }) ;

    await Billtovaleom.getAttribute("value").then((text) => {
      BillTO = text
    });

    console.log("Inside function" + BillTO);

    await reuse.getTextValueFromElement(mileeom).then((text) => {
      mile = text
    });
    console.log("Inside function" + mile);

    DictBU_EOM["BusUnit"] = BU;
    DictBU_EOM["Billto"] = BillTO;
    DictBU_EOM["totalmile"] = mile;

    return DictBU_EOM

  }
  /*****************************************************************************************
       * 
      * MethodName:  NavigateEOM
      * Description: To NavigateEOM
      * Parameter (if any):  y
      * Return type:  Void
   ***************************************************************************************/
  NavigateEOM() {

    reuse.ClickElement(Loadid, "Click SO Drop down")
    reuse.EnterValue(Loadid, "KJ13693", "SO to value")
    Loadid.sendKeys(protractor.Key.ENTER);
    browser.sleep(3000);
    reuse.ClickElement(loadlink, "Click SO Drop down")
    browser.sleep(3000);

    reuse.ClickElement(loaddetail, "Click SO Drop down")
    browser.sleep(3000);
    reuse.ClickElement(stopdetails, "Click SO Drop down")
    browser.sleep(3000);



  }

  /*****************************************************************************************
      * 
     * MethodName:  DateValidationCreateOrderOverview
     * Description: To validate the date details in order overview
     * Parameter (if any):  AppointmnetDatepickup,appointmentdateDelivery
     * Return type:  Void
  ***************************************************************************************/
  CompareValues(Testcasename, DictBU_OM: DataDictionary, DictBU_EOM: DataDictionary) {

    var OMvals = DataDictLib.getFromDictionary('OMvalues');
    var i = 0;

    console.log("excel values" + OMvals);
    var OMpagevalues: string[] = OMvals.split(',');

    //   var highvalue= Math.max(OMvals);
    //   console.log(highvalue);

    for (i = 0; i < OMpagevalues.length; i++) {
      if (OMpagevalues[i] == "BusUnit") {
        console.log("Entering into Businees Value Comparison")


        var BUnit = DictBU_OM[OMpagevalues[i]];
        console.log(BUnit);
        var TcRow = ReadFromXL.FindRowNum(Testcasename, "CreateOrder");

        var fleetcode = DataDictLib.getFromDictionary(BUnit + "_fleetcode");
        console.log(fleetcode);

        if (fleetcode == DictBU_EOM[OMpagevalues[i]]) {
          console.log("Business unit is same")
        }
        else {
          console.log("Business unit is not matching" + DictBU_EOM[BUnit])
        }


      }

      else if (DictBU_OM[OMpagevalues[i]] == DictBU_EOM[OMpagevalues[i]]) {
        console.log('Values are same')


      }
      else {

        console.log("Comparison is failed" + DictBU_EOM[OMpagevalues[i]])
      }

    }
  }
  /*****************************************************************************************
     * 
    * MethodName:  MapView
    * Description: To validate if the Map view is displaying the map for the stops
    * Parameter (if any):  
    * Return type:  Void
 ***************************************************************************************/

  MapView() {

    icon_mapview.isPresent().then((elem) => {
      if (elem === true) {
        reuse.ClickElement((img_infoIcon.get(0)), "Click on map info icon")
        browser.waitForAngular();
        browser.sleep(2000)
        reuse.ClickElement(icon_mapview, "Click on map view icon")
        browser.waitForAngular();
        browser.sleep(2000)
        reuse.checkElementIsPresent(img_map, "Map Image")
      }
    });
  }
  /*****************************************************************************************
    * 
   * MethodName:  MapView
   * Description: To validate if the Map view is displaying the map for the stops
   * Parameter (if any):  
   * Return type:  Void
***************************************************************************************/

  ViewElectronicTransactions() {

    reuse.ClickElement((link_Electronictransfer), "Click on View electronic Transfer")
    browser.waitForAngular();
    browser.sleep(6000);
    (txt_ucrdata.get(0)).click();
    // reuse.ClickElement((txt_ucrdata.get(0)),"Click on the UCR details of the the Transactions")
    browser.waitForAngular();
    browser.sleep(2000)
    reuse.checkElementIsPresent(txt_ucrdetails, "Transaction details")

  }
  /*****************************************************************************************
    * 
   * MethodName:  UpdatePartyDetails
   * Description: To update the partyname,address and solicitor contact in Edit accounts
   * Parameter (if any):  
   * Return type:  Void
***************************************************************************************/
  UpdatePartyDetails(Testcase) {
    var TcRow = ReadFromXL.FindRowNum(Testcase, "CreateOrder");
    DataDictLib.pushToDictionaryWithSheet(TcRow, "CreateOrder");
    var Accountname = DataDictLib.getFromDictionary('Accountname');
    var Accountrole = DataDictLib.getFromDictionary('Accountrole');

    reuse.ClickElement(icon_editparty, "Click Edit icon for acounts and Contacts");
    reuse.ClickElement(txt_SolicitorDD, "Click SolicitorContact drop down for acounts and Contacts");
    txt_SolicitorDD.sendKeys(protractor.Key.ENTER);
    reuse.ClickElement(icon_addparty, "Click Add Additional parties icon for acounts and Contacts");
    reuse.EnterValue(txt_Accountname, "Amse95", "Account name ")
    browser.sleep(2000);
    txt_Accountname.sendKeys(protractor.Key.ENTER);
    browser.sleep(3000);
    reuse.ClickElement(txt_Accountrole, "Click Account role deop down for acounts and Contacts");
    reuse.EnterValue(txt_Accountrole, "Freight", "Account Role")
    txt_Accountrole.sendKeys(protractor.Key.ENTER);
    browser.sleep(2000);
    reuse.ClickElement(btn_saveparty, "Click save button for acounts and Contacts");
    browser.sleep(2000);
  }
  /*****************************************************************************************
    * 
   * MethodName:  VerifyEditEnabled
   * Description: To verify if the Edit icon is enabled in View order page
   * Parameter (if any):  
   * Return type:  Void
***************************************************************************************/

  VerifyEditEnabled() {
    icon_edit.isPresent().then((elem) => {
      if (elem === true) {
        console.log("Edit icon for view order page is enabled")
      }
      else {
        console.log("Edit icon for view order page is disabled")
      }
    });
  }
  /*****************************************************************************************
     * 
    * MethodName:  VerifyEditEnabled
    * Description: To verify if the Edit icon is enabled in View order page
    * Parameter (if any):  
    * Return type:  Void
 ***************************************************************************************/

  async VerifyTextisPresent(BUValue: string, SOValue: string) {

    var BU = await reuse.getTextValueFromElement(txt_ServiceOffering.get(0));
    var BUval = BU.split("-");
    expect((BUval[0].trim())).toEqual(BUValue)
    var SO = await reuse.getTextValueFromElement(txt_ServiceOffering.get(1));
    var SOval = SO.split("-");
    expect((BUval[0].trim())).toEqual(SOValue)
  }
  /*****************************************************************************************
    * 
   * MethodName:  ClickBackOrder
   * Description: To click the back arrow in view order page so that we land in advanced search
   * Parameter (if any):  
   * Return type:  Void
***************************************************************************************/

  ClickBackOrder() {
    reuse.ClickElement(icon_orderBack, "Click on the back arrow to land on advances search")
    browser.sleep(2000);
  }

  /*****************************************************************************************
      * 
     * MethodName:  ClickBackOrder
     * Description: To click the back arrow in view order page so that we land in advanced search
     * Parameter (if any):  
     * Return type:  Void
  ***************************************************************************************/

  VerifyShippingOption() {
    var text_selectedShipping = element(by.xpath("//span[text()='Selected Shipping Option']"))
    reuse.ClickElement(link_shippingOption, "Click on the view shipping option link in view order page")
    browser.sleep(3000);
    reuse.checkElementIsPresent(text_selectedShipping, "Selected shipping option")

  }

  /*****************************************************************************************
       * 
      * MethodName:  AddRateInRateSheet
      * Description: To add charge on Rate Sheet From view  order page
      * Parameter (if any):  AppointmnetDatepickup,appointmentdateDelivery
      * Return type:  Void
   ***************************************************************************************/
  AddRateInRateSheet() {
    //reuse.ClickElement(ratesheet,"Click rate sheet")
    common.ElementWait(true, rate_level);
    rate_edit.isPresent().then((elem: any) => {
      if (elem === true) {
        console.log("edit button is present");
        reuse.ClickElement(dot_rateFlow, "Click Edit rate")
        reuse.Clickwithtag("Add Charge")
        reuse.ClickElement(Chargelevel, "Click on the charge level")
        browser.sleep(2000);
        chargeamount.clear();
        reuse.EnterValue(chargeamount, "10", "Charge Amount value")
        chargequantity.clear();
        reuse.EnterValue(chargequantity, "15", "Charge quantity value")
        reuse.EnterValue(chargecode, "DETENTIONP", "Charge code valueS")
        //chargecode.sendKeys(protractor.Key.SPACE);
        // chargecode.sendKeys(protractor.Key.BACK_SPACE);
        // chargecode.sendKeys(protractor.Key.BACK_SPACE);
        // browser.sleep(2000);
        // reuse.EnterValue(chargecode, "A", "Charge code value")
        // browser.sleep(2000);
        chargecode.sendKeys(protractor.Key.ENTER);
        browser.sleep(2000);
        reuse.EnterValue(authno, "12369", "authorization number")
        reuse.EnterValue(authby, "keerthana", "Authorized by")
        reuse.EnterValue(chargecomments, "Test", "Authorized by")
        authby.sendKeys(protractor.Key.TAB);
        reuse.ClickElement((btn_saveCharge.get(2)), "Click on the Savebuttoncharge")
        browser.sleep(2000);

      }
      else {
        console.log("edit button is not present");

      }
    });
  }

  /*****************************************************************************************
       * 
      * MethodName:  ClickBackOrder
      * Description: To click the back arrow in view order page so that we land in advanced search
      * Parameter (if any):  
      * Return type:  Void
   ***************************************************************************************/

  async VerifyRateTypeInRateSheet(RateTypecalue: string) {
    var Ratetype = await reuse.getTextValueFromElement(txt_RateType)
    expect(Ratetype).toEqual(RateTypecalue)
    if (Ratetype === RateTypecalue) {
      console.log("The " + Ratetype + " rate is attached to the order")
    }
    else {
      console.log("The " + Ratetype + " rate is not attached to the order")
    }
  }
  /*****************************************************************************************
       * 
      * MethodName:  CreateQuickRate
      * Description: To create quivk rate in view  order overview
      * Parameter (if any):  AppointmnetDatepickup,appointmentdateDelivery
      * Return type:  Void
   ***************************************************************************************/
  CreateQuickRate() {
    browser.executeScript("window.scrollTo(0,200)");
    browser.sleep(5000)
    reuse.ClickElement(link_CreateQuickRate, "Click rate sheet")
    common.ElementWait(true, rate_level);
    rate_edit.isPresent().then((elem: any) => {
      if (elem === true) {
        console.log("edit button is present");
        reuse.ClickElement(rate_edit, "Click Edit rate")
      }
      else {
        console.log("edit button is not present");

      }
    });
  }
  /*****************************************************************************************
       * 
      * MethodName:  UPDATEBUSO
      * Description: To UPDATE BU-SO view  order overview
      * Parameter (if any):  AppointmnetDatepickup,appointmentdateDelivery
      * Return type:  Void
   ***************************************************************************************/


  UPDATEBUSO(Testcase) {
    var TcRow = ReadFromXL.FindRowNum(Testcase, "CreateOrder");
    DataDictLib.pushToDictionaryWithSheet(TcRow, "CreateOrder");

    var str_BU = DataDictLib.getFromDictionary("BUUpdate");
    var str_SO = DataDictLib.getFromDictionary("SOUpdate");
    var strequip = DataDictLib.getFromDictionary("Equipment");
    var BUvalidate = element(by.xpath("//*[text()='DCS']"));
    var save_BUSO = element(by.xpath("//*[text()='Edit Service Offering']//following::button[text()='Save'][1]"));
    reuse.ClickElement(updateBUSO_btn, "Update icon is clicked ");
    browser.waitForAngularEnabled();
    //browser.sleep(2000);

    reuse.ClickElement(BU_update, "BU icon is clicked ");
    BU_update.sendKeys(str_BU);
    browser.sleep(2000);
    BU_update.sendKeys(protractor.Key.ENTER)
    browser.sleep(3000);
    BU_update.sendKeys(protractor.Key.TAB)
    //reuse.SAClickElement(SO_update, "SO icon is clicked ")
    SO_update.sendKeys(str_SO);
    browser.sleep(2000);
    SO_update.sendKeys(protractor.Key.ENTER)
    browser.sleep(2000);
    browser.executeScript("window.scrollTo(0,200)");
    reuse.ClickElement(save_BUSO, "SO icon is clicked ");
    browser.sleep(25000);



  }

  ValidateUpdatedBUSO(Testcase) {
    var TcRow = ReadFromXL.FindRowNum(Testcase, "CreateOrder");
    DataDictLib.pushToDictionaryWithSheet(TcRow, "CreateOrder");

    var str_BU = DataDictLib.getFromDictionary("BUUpdate");
    var str_SO = DataDictLib.getFromDictionary("SOUpdate");
    var strequip = DataDictLib.getFromDictionary("Equipment");
    var BUvalidate = element(by.xpath("//*[text()='DCS']"));
    var save_BUSO = element(by.xpath("//*[text()='Edit Service Offering']//following::button[text()='Save'][1]"));
    reuse.ClickElement(updateBUSO_btn, "Update icon is clicked ");
    browser.waitForAngularEnabled();
    //browser.sleep(2000);

    
    var str_validateBU = validateBU;
    str_validateBU.getText().then(function (text) {
      console.log(text);
      if (text == str_BU) {
        console.log("Business Unit updated")
      }
    });
    browser.sleep(2000);
    var str_validateSO = validateSO
    str_validateSO.getText().then(function (text) {
      console.log(text);
      if (text == str_BU) {
        console.log("Service Offering Updated")
      }
    });

  }











  /* MethodName:  CreateQuickRate
  * Description: To create quivk rate in view  order overview
  * Parameter (if any):  AppointmnetDatepickup,appointmentdateDelivery
  * Return type:  Void
***************************************************************************************/
  UpdateStopService() {
    var icon_OriginArrow = element.all(by.id("span-ritArr"));
    var icon_OriginEdit = element(by.id("span-jbhedit"));
    var dd_serviceLevel = element(by.css("[formcontrolname='serviceLevelTypeCode']"))
    browser.sleep(5000)
    browser.executeScript("window.scrollTo(0,150)");

    browser.executeScript("window.scrollTo(0,-50)");
    browser.sleep(5000)


    reuse.ClickElement((icon_OriginArrow.get(0)), "Click origin arrow for stop edit")
    browser.sleep(5000)
    icon_OriginEdit.isPresent().then((elem: any) => {
      try {
        if (elem === true) {
          console.log("edit button is present");
          reuse.ClickElement(icon_OriginEdit, "Click Edit icon of origin stop")
          browser.sleep(5000)
          //browser.executeScript("window.scrollTo(0,200)");
          reuse.ClickElement(dd_serviceLevel, "Click Service level drop down of origin stop")
          reuse.EnterValue(dd_serviceLevel, "Pickup", "Pickup value")
          dd_serviceLevel.sendKeys(protractor.Key.ENTER);
          //browser.executeScript("window.scrollTo(0,200)");
          reuse.ClickButtonwithText("Save")
        }
        else {
          console.log("edit button is not present");

        }
      } catch{
        console.log("Edit button is not dispalyed")

      }

    });
  }

  /*****************************************************************************************
       * 
      * MethodName:  CreateQuickRate
      * Description: To create quivk rate in view  order overview
      * Parameter (if any):  AppointmnetDatepickup,appointmentdateDelivery
      * Return type:  Void
   ***************************************************************************************/
  ClickStopDetails(Stop: string) {

var StopsDetails=element(by.xpath("//h3[contains(text(),'Stops')]"))
var MapView=element(by.id("span-map"))
var ThreeDots=element(by.id("span-3dots"))
 var StopInfo=element(by.xpath("//*[@id='span-soliInfo']"))
    browser.sleep(5000)
    browser.executeScript("window.scrollTo(0,100)");
   // browser.executeScript("window.scrollTo(0,-50)");
  //  reuse.SAClickElement(StopsDetails, "Click origin arrow for stop edit")
  //  StopsDetails.sendKeys(protractor.Key.TAB);
  //  MapView.sendKeys(protractor.Key.TAB);
  //  ThreeDots.sendKeys(protractor.Key.TAB);
  //  reuse .SAClickElement(StopInfo, "Click origin arrow for stop edit")
  //   browser.sleep(5000)
    if (Stop === "Origin") {
      reuse.SAClickElement((icon_OriginArrow.get(0)), "Click origin arrow for stop edit")
      browser.sleep(5000)
    }
    else {
      reuse.ClickElement((icon_OriginArrow.get(1)), "Click origin arrow for stop edit")
      browser.sleep(5000)
    }
    editbtn.isPresent().then((elem: any) => {
      try {
        if (elem === true) {
          console.log("edit button is present");
          reuse.SAClickElement(editbtn, "Click Edit icon of origin stop")
          browser.sleep(5000)
        }
        else {
          console.log("edit button is not present");
        }
      } catch{
        console.log("Edit button is not dispalyed")
      }

    });
  }
  /*****************************************************************************************
       * 
      * MethodName:  CreateQuickRate
      * Description: To create quivk rate in view  order overview
      * Parameter (if any):  AppointmnetDatepickup,appointmentdateDelivery
      * Return type:  Void
   ***************************************************************************************/
  async UpdateDeliveryItemUnitQuantity() {
    var txt_deliveryUnit = element(by.xpath("//b[text()='Handling Unit']//following::span[1]"))
    this.ClickStopDetails("Origin")
    browser.sleep(10000);
    dd_unitQuantity.isPresent().then(async (elem: any) => {
      try {
        if (elem === true) {
          //reuse.ClickElement(dd_serviceLevel,"Click Service level drop down of origin stop")
          var EC = protractor.ExpectedConditions;
          browser.wait(EC.visibilityOf(dd_unitQuantity), 10000).then(function () {
            reuse.EnterValue(dd_unitQuantity, "250", "Pickup value")
            browser.sleep(5000);
          });
          reuse.ClickButtonwithText("Save")
          browser.sleep(8000);
          reuse.ClickElement((icon_OriginArrow.get(1)), "Click origin arrow for stop edit")
          browser.sleep(5000);
          var handlingunitValue = await reuse.getTextValueFromElement(txt_deliveryUnit)
          console.log(handlingunitValue)
          expect(handlingunitValue).toContain("250");
        }
        else {
          console.log("Service level drop down of origin stop is not clicked");

        }
      } catch{
        console.log("Service level drop down of origin stop is not clicked")

      }

    });
  }
  /*****************************************************************************************
     * 
    * MethodName:  CreateQuickRate
    * Description: To create quivk rate in view  order overview
    * Parameter (if any):  AppointmnetDatepickup,appointmentdateDelivery
    * Return type:  Void
 ***************************************************************************************/
  async AddStopinViewOrderPage() {
    var icon_flowmenuOrigin = element(by.xpath("//span[text()='Origin']//following::*[@id='span-3dots'][1]"))
    var link_Addstop = element(by.xpath("//span[text()='Origin']//following::*[@id='span-3dots'][1]"))
    var StopReason = element(by.id("stopReason"));
    var StopReasonText = element(by.xpath("//li/div/a/div[text()='Pickup']"));
    var BillToValue = DataDictLib.getFromDictionary('BillTO');
    var MultiplePalletChckBX = element.all(by.xpath("//a[@class='list-group-item']//following::input[@type='checkbox']"));;
    this.ClickStopDetails("Origin")
    browser.sleep(10000);
    icon_flowmenuOrigin.isPresent().then(async (elem: any) => {
      try {
        if (elem === true) {
          reuse.ClickElement(icon_flowmenuOrigin, "Click flow menu to add stops from origin")
          reuse.Clickwithtag("Add Stop")
          common.EnterTextBox("locationID", "LMWA23");
          browser.sleep(3000);
          BillToValue.click();
          browser.sleep(4000);
          reuse.ClickElement(StopReason, "Click stopreason drop down")
          reuse.ClickElement(StopReasonText, "Click the reason from drop down")
          browser.sleep(3000);
          browser.sleep(3000)
          common.EnterTextBox("itemHandlingTypeQuantity", "10")
          browser.sleep(2000);
          common.EnterTextBox("itemHandlingUnitWeight", "120");
          browser.sleep(2000);
          var Handlingunit = element(by.css("[formcontrolname=\"itemHandlingUnitHeight\"]"));
          Handlingunit.sendKeys(protractor.Key.TAB);
          browser.sleep(5000);

          common.EnterTextBox("packagingUnitTypeQuantity", "10");
          common.EnterTextBox("itemWeight", "100");
          browser.sleep(5000);
          var itemunit = element(by.css("[formcontrolname=\"itemHeight\"]"));
          itemunit.sendKeys(protractor.Key.TAB);
          browser.sleep(12000);
          common.EnterTextBox("itemDescription", "Silicon")
          browser.sleep(5000);
          var tagname = element(by.css("[formcontrolname=\"itemDescription\"]"));
          reuse.ClickElement(Savebuttonreject.get(3), "Click ")
        }
        else {
          console.log("Service level drop down of origin stop is not clicked");

        }
      } catch{
        console.log("Service level drop down of origin stop is not clicked")

      }
      this.ClickStopDetails("Delivery");

      reuse.ClickElement((MultiplePalletChckBX.get(1)), "Click Multiple pallet checkbox")

      reuse.ClickElement(Savebuttonreject.get(3), "Click ")
      browser.sleep(20000);

    });
  }
  Reconsign() {
    var edit_equipment = element(by.xpath("//h3[text()='Equipments']//following::div[@class='icon-jbh_edit icon-edit']"));
    var equip_category = element(by.id("equipmentCategory"));
    var equipinput = element(by.xpath("//input[@placeholder='Equipment Category']"));
    var equipsave_Btn = element(by.xpath("//*[@class='btn btn-primary col-md-3 btns']//button[text()='Save']"));
    var save_BUSO = element(by.xpath("//*[text()='Edit Service Offering']//following::button[text()='Save'][1]"));
    //threedot             =element(by.xpath("//h1[@class='alignHeading']//following::*[@placement='bottom'][1]"));
    //reconsign          =element(by.xpath("//*[text()='Reconsignment']"));
    var reconsign = element(by.id("a-reconsgmt"));
    var reason_btn = element(by.xpath("//*[@formcontrolname='reasonCode']"));

    var reasoncomnts = element(by.css("[formcontrolname=\"reconComments\"]"));
    //submit = element(by.csscontainigtext("[@id='btn-submit']","Submit"));
    var createrate_btn = element(by.xpath("//*[text()='Rate Overview']//following::button[@id='btn-create'][1]"));
    var overall_hdr = element(by.xpath("//*[text()='OVERALL']"));
    var chckbox = element(by.id("checkx"));
    var level = element(by.css("[formcontrolname=\"chargeLevelTypeCode\"]"));
    var amntfield = element(by.id("amountField"));


    reconsign.click();
    browser.sleep(10000);
    reason_btn.click();
    reason_btn.sendKeys("Product Damaged");
    reason_btn.sendKeys(protractor.Key.ENTER)
    reasoncomnts.click();
    reasoncomnts.sendKeys("Arun");


  }
  UpdateEquip(){
    //var strequip=DataDictLib.getFromDictionary("Equipment");
    var strequip = "Flatbed"
    edit_equipment.click();
    browser.executeScript("window.scrollTo(0,200)");

    //ObjORD.edit_equipment.click();
    browser.sleep(5000);
    equip_category.click();
    //ObjORD.equip_category.click();
    browser.sleep(2000);
    equipinput.sendKeys(strequip);
    browser.sleep(2000);
    equipinput.sendKeys(protractor.Key.ENTER)
    browser.sleep(2000);
    equipsave_Btn.click();


}
/***************************************************************************************/
/* MethodName:  UpdateStopAppointmentdetails
  * Description: To update Appointment number,appointment instructions
  * Parameter (if any):  AppointmnetDatepickup,appointmentdateDelivery
  * Return type:  Void
***************************************************************************************/
async UpdateStopAppointmentdetails() {
  var icon_OriginArrow = element.all(by.id("span-ritArr"));
  var icon_OriginEdit = element(by.id("span-jbhedit"));
  var txt_AppntNumber = element(by.css("[formcontrolname='appointmentConfirmationNumber']"))
  var dd_AppntInstructions = element(by.css("[formcontrolname='appointmentInstruction']"))
  var btn_SaveOriginStop=element(by.xpath("//*[@class='btn link-icon-secondary requested_apnt'][1]//following::*[text()='Save'][1]"));
  browser.sleep(5000)
  browser.executeScript("window.scrollTo(0,100)");
 // browser.executeScript("window.scrollTo(0,-50)");
 this.ClickStopDetails("Origin")
  browser.sleep(5000)  
    try {
        //browser.executeScript("window.scrollTo(0,200)");
        reuse.EnterValue(txt_AppntNumber,"12345","Enter the Appointment number")
        reuse.SAClickElement(dd_AppntInstructions, "Click Additional instructions drop down")
        dd_AppntInstructions.sendKeys(protractor.Key.ENTER);
        browser.sleep(2000)
        browser.executeScript("window.scrollTo(0,3000)");
          reuse.SAClickElement(btn_SaveOriginStop, "Click Additional instructions drop down")
          browser.sleep(3000)
        browser.sleep(8000);
            } catch{
      console.log("Edit button is not dispalyed")
    }
}

/***************************************************************************************/
/* MethodName:  UpdateStopAppointmentdetails
  * Description: To update Appointment number,appointment instructions
  * Parameter (if any):  AppointmnetDatepickup,appointmentdateDelivery
  * Return type:  Void
***************************************************************************************/
async UpdateStopItem() {
  var icon_OriginArrow = element.all(by.id("span-ritArr"));
  var icon_OriginEdit = element(by.id("span-jbhedit"));  
  var txt_handlingQty = element(by.css("[formcontrolname='itemHandlingTypeQuantity']"));
  var txt_HandlingUnitWeight = element(by.css("[formcontrolname='itemHandlingUnitWeight']"));
  var dd_HandlingUnit = element(by.css("[formcontrolname='itemHandlingTypeCode']"));
  var txt_itemQty = element(by.css("[formcontrolname='packagingUnitTypeQuantity']"));
  var txt_itemWeight = element(by.css("[formcontrolname='itemWeight']"));
  var txt_itemLength = element(by.css("[formcontrolname='itemLength']"));
  var txt_itemWidth = element(by.css("[formcontrolname='itemWidth']"));
  var txt_itemHeight= element(by.css("[formcontrolname='itemHeight']")); 
  var dd_itemChar = element(by.css("[formcontrolname='itemCharacteristics']"));
  var icon_SKUinfo = element(by.xpath("//label[text()='Item Description or NMFC Number']//following::*[@class='icon-jbh_solid-info btn-icon']")); 
  var btn_EditDetails = element(by.id("btn-editDet")); 
  var txt_SKUNumber = element(by.css("[formcontrolname='skuNumber']"));
  var txt_SSKUNumber= element(by.css("[formcontrolname='supplierSKU']")); 
  var icon_SKUSave = element.all(by.xpath("//label[text()='Classification']//following::*[@class='btn btn-primary']")); 
  var btn_SaveOriginStop=element.all(by.xpath("//*[@class='btn link-icon-secondary requested_apnt'][1]//following::*[text()='Save'][1]"));
  var txt_ItemDescription= element(by.css("[formcontrolname='itemDescription']")); 
  browser.sleep(5000)
  browser.executeScript("window.scrollTo(0,100)");
  this.ClickStopDetails("Origin")
    try {
              console.log("edit button is present");
       
        browser.executeScript("window.scrollTo(0,100)");      
      
       // reuse.SAClickElement(dd_HandlingUnit, "Click Handling unit Packing unit")
       // browser.sleep(2000)
       // reuse.EnterValue(dd_HandlingUnit,"Bag","Handling unit Packing unit")
       // dd_HandlingUnit.sendKeys(protractor.Key.ENTER);
       // browser.sleep(2000)
        txt_handlingQty.clear();
        reuse.EnterValue(txt_handlingQty,"50","Enter the Handling unit quantity")
        txt_HandlingUnitWeight.clear();
        reuse.EnterValue(txt_HandlingUnitWeight,"150","Enter the Handling unit quantity")


        txt_itemQty.clear();
        reuse.EnterValue(txt_itemQty,"20","Enter the Handling unit quantity")
        txt_itemWeight.clear();
        reuse.EnterValue(txt_itemWeight,"100","Enter the Handling unit quantity")
        txt_itemLength.clear();
        reuse.EnterValue(txt_itemLength,"10","Enter the Handling unit quantity")

        txt_itemWidth.clear();
        reuse.EnterValue(txt_itemWidth,"20","Enter the Handling unit quantity")
        txt_itemHeight.clear();
        reuse.EnterValue(txt_itemHeight,"15","Enter the Handling unit quantity")

        reuse.SAClickElement(dd_itemChar, "Click Handling unit Packing unit")
        browser.sleep(2000)
        reuse.EnterValue(dd_itemChar,"Stackable","Handling unit Packing unit")
        dd_itemChar.sendKeys(protractor.Key.ENTER);
        browser.sleep(2000)
        reuse.SAClickElement(icon_SKUinfo, "Click Info icon of origin stop")
        browser.sleep(5000)
        reuse.ClickElement(btn_EditDetails,"Edit details")
        reuse.EnterValue(txt_SKUNumber,"12365","SKUNumber")
        reuse.EnterValue(txt_SSKUNumber,"56954","SupplierSKUNumber")
          reuse.ClickElement((icon_SKUSave.get(0)),"Save in SKU")
          browser.sleep(2000);
          txt_ItemDescription.sendKeys(protractor.Key.TAB);
        browser.sleep(5000);
        reuse.ClickElement((btn_SaveOriginStop.get(1)),"Certified Driver Required slider icon");
        browser.sleep(8000);
        
    } catch{
      console.log("Edit button is not dispalyed")
    }
  
}

/***************************************************************************************/

async UpdateItemDetails(Testcase) {
  var TcRow=ReadFromXL.FindRowNum(Testcase,"CreateOrder");
  DataDictLib.pushToDictionaryWithSheet(TcRow,"CreateOrder");
var Item = DataDictLib.getFromDictionary('HAZMAT')
var UNNA = DataDictLib.getFromDictionary('UNNA');
var UNNAval = DataDictLib.getFromDictionary('UNNAval');
var properShippingname = DataDictLib.getFromDictionary('ProperShippingName');
  browser.sleep(5000)
  var itemcharname = element.all(by.css("[formcontrolname='itemCharacteristics']"));
  var itemchar_type = element(by.xpath("//div[text()='"+Item+"']"));
  var unnacode = element(by.xpath("//*[@id='unnaCode']"));  
  var shippingname = element(by.css("[formcontrolname='propershippingname']"));
  var primary = element(by.css("[formcontrolname='hazmatclasscodes']"));
  var secondary = element(by.css("[formcontrolname='sechazmatclasscodes']"));
//var shippingname = DataDictLib.getFromDictionary('Hazmatshippingname');

console.log("Entered Hazmat")
// this.ElementWait(true,stopbox);
//this.hazmatdropdowns("Item Characteristics","Hazmat")
browser.sleep(6000);
itemcharname.isPresent().then((elem) => {
if (elem === true) {
  reuse.ClickElement(itemcharname, "Click Item char name");
  browser.sleep(3000);
  itemchar_type.click();
  browser.sleep(3000);

  reuse.ClickElement(unnacode, "Click Unna code")
  reuse.EnterValue(unnacode, UNNAval, "Enter the UNNA Code")
  browser.sleep(2000);
  unnacode.sendKeys(protractor.Key.ENTER);
  browser.sleep(2000);
  //this.hazmatdropdowns("Proper Shipping Name","-Butyl chloroformate")
  reuse.ClickElement(shippingname, "Click shippingname")
  //reuse.EnterValue(shippingname, properShippingname, "Enter the Shipping name")
  shippingname.sendKeys(protractor.Key.ENTER);
  reuse.ClickElement(primary, "Click primary value")
  primary.sendKeys(protractor.Key.TAB);
  primary.sendKeys(protractor.Key.ENTER);


  //this.hazmatdropdowns("Secondary Hazard Class","");
  reuse.ClickElement(secondary, "Click secondary value")
  //secondary.sendKeys(protractor.Key.TAB);
  secondary.sendKeys(protractor.Key.ENTER);
  reuse.ClickElement(btn_SaveOriginStop,"Save button in edit stops origin");
  // reuse.ClickButtonwithText("Save")
   browser.sleep(8000); 
}
});
  
}

async UpdateStopAppDate() {
 
  browser.sleep(5000)
  browser.executeScript("window.scrollTo(0,100)");
  this.ClickStopDetails("Origin")
    try {
              console.log("edit button is present");
       
        browser.executeScript("window.scrollTo(0,500)");
        var AppDetails=element(by.xpath("//h3[contains(text(),'Scheduled Appointment(s)')]"))
        reuse.SAClickElement(AppDetails, "Click AppDetails")
        browser.sleep(1000);
        common.Selectcalendericon("28/Mar/2018", 3); 
        browser.sleep(2000);
        common.SelectTime("08:00", 3);
        browser.sleep(2000);
        common.Selectcalendericon("27/Mar/2018", 2);
        browser.sleep(2000);
        common.SelectTime("06:00", 2);
      
        browser.sleep(2000);
        var Save_Buttn = element(by.xpath("//div[@class='button-section']//div//button[text()='Save']"));
       reuse.SAClickElement(Save_Buttn,"Save");
        browser.sleep(5000);

        var SuccessMessage=await reuse.ValidationMessage();
        if(SuccessMessage ==="Order Accepted Successfully")
        {
       console.log("Orderis accepted and moved to view order page")

        }
      
      else {
        console.log("Order Not Accepted");
      }
    } catch{
      console.log("Edit button is not dispalyed")
    }
  
}
/***************************************************************************************/


/***************************************************************************************/


/* MethodName:  EditAccount
  * Description: To update Account Details
  * Parameter (if any):  NIL
  * Return type:  Void
***************************************************************************************/
EditAccount(){

var editacc = element(by.xpath("//h4[contains(text(),'Edit Accounts')]//following::div[@class='icon-jbh_edit cursor-pointer']"));
var editaccountcontact = element(by.xpath("//*[@formcontrolname='contactTypeCode']//i[@class='caret pull-right']"));
var addnew = element(by.xpath("//*[@class='icon-jbh_add']"));
var name = element(by.id("firstname"));
var lastname = element(by.id("lastname"));
var contactmethod = element(by.xpath("//div[label[contains(text(),'Preferred Contact Method')]]//i[@class='caret pull-right']"))
var solicitor = element(by.xpath("//*[@formcontrolname='solicitorCodeContact']"));
var type =




reuse.ClickElement(editacc,"Click editbutton")
browser.sleep(2000);
reuse.ClickElement(editaccountcontact,"Click editaccountcontact")
browser.sleep(3000);
reuse.ClickElement(addnew,"Click the new contact")

reuse.EnterValue(name,"Arun","First name is filled");
reuse.EnterValue(lastname,"Sundar","last Name");
reuse.ClickElement(contactmethod,"Contact methos is clicked");
reuse.EnterValue(type,"Email","Email is typed")





}
async UpdateUNNumber() {
  var icon_OriginArrow = element.all(by.id("span-ritArr"));
  var icon_OriginEdit = element(by.id("span-jbhedit"));
  var dd_itemChar = element(by.css("[formcontrolname='itemCharacteristics']"));
  var txt_UnnaNo = element(by.css("[formcontrolname='unnaCode']"));
  var txt_itemHeight= element(by.css("[formcontrolname='itemHeight']")); 
  var dd_packingGroup = element(by.css("[formcontrolname='packaginggroup']"));
  var icon_driverSlider= element(by.xpath("//*[text()='Certified Driver Required']/..//*[@class='slider']"));
  var btn_SaveOriginStop=element(by.xpath("//*[@class='btn link-icon-secondary requested_apnt'][1]//following::*[text()='Save'][1]"));
  var btn_SaveOriginStop=element(by.xpath("//*[@class='btn link-icon-secondary requested_apnt'][1]//following::*[text()='Save'][1]"));
  
  browser.sleep(5000)
  browser.executeScript("window.scrollTo(0,100)");
  this.ClickStopDetails("Origin")
    try {
        console.log("edit button is present");
       
        browser.executeScript("window.scrollTo(0,1000)");       
        reuse.SAClickElement(dd_itemChar, "Click Handling unit Packing unit")
        browser.sleep(2000)
        reuse.EnterValue(dd_itemChar,"Hazmat","Handling unit Packing unit")
        dd_itemChar.sendKeys(protractor.Key.ENTER);
        browser.sleep(2000)

        reuse.EnterValue(txt_UnnaNo,"NA0","Handling unit Packing unit")
        browser.sleep(2000)
        txt_UnnaNo.sendKeys(protractor.Key.ENTER);
        browser.sleep(3000)
        reuse.SAClickElement(dd_packingGroup,"Packing group")
        browser.sleep(2000)
        dd_packingGroup.sendKeys(protractor.Key.ENTER);
        reuse.ClickElement(icon_driverSlider,"Certified Driver Required slider icon");
        browser.sleep(2000)
           reuse.ClickElement(btn_SaveOriginStop,"Certified Driver Required slider icon");
       // reuse.ClickButtonwithText("Save")
        browser.sleep(8000); 
        var SuccessMessage=await reuse.ValidationMessage();
        if(SuccessMessage ==="Order Accepted Successfully")
        {
       console.log("Orderis accepted and moved to view order page")
        }
        else {
        console.log("edit button is not present");
      }      
      }      
     catch{
      console.log("Edit button is not dispalyed")
    }
  
}
/***************************************************************************************/
/* MethodName:  UpdatEmergencyNo
  * Description: To update the Hazmat emergency numbers
  * Parameter (if any):  
  * Return type:  Void
***************************************************************************************/
async UpdatEmergencyNo() {
 
  browser.sleep(5000)
  browser.executeScript("window.scrollTo(0,100)");
  this.ClickStopDetails("Origin")
    try {
        console.log("edit button is present");       
        browser.sleep(5000)
        browser.executeScript("window.scrollTo(0,2000)");       
        reuse.SAClickElement(dd_itemChar, "Item characteristics drop down")
        browser.sleep(2000)
        reuse.EnterValue(dd_itemChar,"Hazmat","Item characteristics")
        dd_itemChar.sendKeys(protractor.Key.ENTER);
        browser.sleep(2000)

        reuse.EnterValue(txt_EmergencyResponseContact,"5695658965","Emergency Response contact number")
        browser.sleep(1000)
        reuse.EnterValue(txt_emergencyResponsePhoneNumber,"4154441","Emergency Response contact")
        browser.sleep(1000)
         reuse.SAClickElement(dd_packingGroup,"Packing group")
        browser.sleep(2000)
        dd_packingGroup.sendKeys(protractor.Key.ENTER);
        reuse.ClickElement(icon_placardSlider,"Placard Required slider icon");
        browser.sleep(2000)         
        reuse.ClickElement(btn_SaveOriginStop,"Certified Driver Required slider icon");
       
         browser.sleep(8000); 
        var SuccessMessage=await reuse.ValidationMessage();
        if(SuccessMessage ==="Order Accepted Successfully")
        {
       console.log("Orderis accepted and moved to view order page")
        }
        else {
        console.log("Order Accepted Message is not displayed");
      }      
      }      
     catch{
      console.log("Edit button is not dispalyed")
    }
  
}
/***************************************************************************************/
/* MethodName:  UpdateLocation
  * Description: To update location of the stop origin
  * Parameter (if any): 
  * Return type:  Void
***************************************************************************************/
async UpdateLocation() {
 
  browser.sleep(5000)
  //browser.executeScript("window.scrollTo(0,100)");
  this.ClickStopDetails("Origin")
    try {
      txt_Location.clear();
        browser.sleep(5000)
        reuse.EnterValue(txt_Location,"PJSI4","Stop Location")
        txt_Location.sendKeys(protractor.Key.BACK_SPACE);
        browser.sleep(2000)  
        txt_Location.sendKeys(protractor.Key.ENTER);
        browser.sleep(2000)  
        browser.executeScript("window.scrollTo(0,3000)");
        reuse.ClickElement(btn_SaveOriginStop.get(0),"Save button for Stops origin Edit")    
       browser.sleep(5000); 
       var SuccessMessage=await reuse.ValidationMessage();
       if(SuccessMessage ==="Order Accepted Successfully")
       {
      console.log("Orderis accepted and moved to view order page")
       }
       else {
       console.log("edit button is not present");
     }      
      }      
     catch{
      console.log("Edit button is not dispalyed")
    }
  
}
/***************************************************************************************/
/* MethodName:  UpdateOrderWeight
  * Description: To update order weight whicjh is sum of item and handlin weight
  * Parameter (if any): 
  * Return type:  Void
***************************************************************************************/
async UpdateOrderWeight() {
 
   browser.sleep(5000)
   //browser.executeScript("window.scrollTo(0,100)");
   this.ClickStopDetails("Origin")
     try {
      
       browser.executeScript("window.scrollTo(0,100)");
      // reuse.SAClickElement(dd_HandlingUnit, "Click Handling unit Packing unit")
      // browser.sleep(2000)
      // reuse.EnterValue(dd_HandlingUnit,"Bag","Handling unit Packing unit")
      // dd_HandlingUnit.sendKeys(protractor.Key.ENTER);
      // browser.sleep(2000)
       txt_HandlingUnitWeight.clear();
       reuse.EnterValue(txt_HandlingUnitWeight,"150","Enter the Handling unit quantity")
       txt_itemWeight.clear();
       reuse.EnterValue(txt_itemWeight,"100","Enter the Handling unit quantity")
       browser.executeScript("window.scrollTo(0,3000)");    
       reuse.ClickElement((btn_SaveOriginStop.get(0)),"Certified Driver Required slider icon");
       browser.sleep(8000);
       }      
      catch{
       console.log("Edit button is not dispalyed")
     }
   
 }
 /***************************************************************************************/
/* MethodName:  UpdateEquipmentNumber
  * Description: To update Equipment trailer number
  * Parameter (if any):  
  * Return type:  Void
***************************************************************************************/
async UpdateEquipmentNumber() {
 
  
     try {
     
       reuse.ClickElement(edit_equipment,"Edit button for Equipment Edit") 
       reuse.ClickButtonwithText("Trailer Number");  
         reuse.EnterValue(txt_TrailerNumber,"0000000105","Trailer number")
         txt_TrailerNumber.sendKeys(protractor.Key.TAB);
         browser.sleep(2000)  
         txt_TrailerPrefix.sendKeys(protractor.Key.ENTER);
         txt_TrailerPrefix.sendKeys(protractor.Key.ENTER);
         browser.sleep(2000)  
         
         reuse.SAClickElement(btn_SaveEquipment,"Save button for Stops origin Edit")    
        browser.sleep(5000); 
        var SuccessMessage=await reuse.ValidationMessage();
        if(SuccessMessage ==="Order Accepted Successfully")
        {
       console.log("Orderis accepted and moved to view order page")
        }
        else {
        console.log("edit button is not present");
      }      
       }      
      catch{
       console.log("Edit button is not dispalyed")
     }
   
    }

/***************************************************************************************/
/* MethodName:  UpdateServiceoffering in View order details
  * Description: To update SO, Customer order number, Order value,Additional instruction,Order service
  * Parameter (if any):  
  * Return type:  Void
***************************************************************************************/
Serviceoffupdate(Testcase){

  var TcRow=ReadFromXL.FindRowNum(Testcase,"AOU");
  DataDictLib.pushToDictionaryWithSheet(TcRow,"AOU");
  var ServiceLeveldata =DataDictLib.getFromDictionary('SERVICELEVEL');
  var CUSTOMERORDERNUMBERdata=DataDictLib.getFromDictionary('CUSTOMERORDERNUMBER');
  var ORDERVALUEdata=DataDictLib.getFromDictionary('ORDERVALUE');
  var InternationalServicedata=DataDictLib.getFromDictionary('InternationalService');
  var internationalservicedrpdwn = element(by.xpath("//div[div[contains(text(),'International Service')]]//ul//li//div//a//div[text()='"+InternationalServicedata+"']"));

  reuse.ClickElement(editserviceoff, "Click on edit SO icon");
  browser.sleep(5000);

  reuse.ClickElement(Servicelevel, "Click on Servicelevel dropdown");
  browser.sleep(2000);

  reuse.ClickElement(Serviceleveldrpdwn, "Click on Servicelevel dropdown value");
  browser.sleep(2000);

  reuse.ClickElement(Aousavbtnso, "Click on Servicelevel save button");
  browser.sleep(5000);

  reuse.ClickElement(Editshipment, "Click on edit shipment icon");
  browser.sleep(2000);

  reuse.ClickElement(shipmentid, "Click on edit shipment id");
  browser.sleep(2000);

  reuse.EnterValue(shipmentid,CUSTOMERORDERNUMBERdata,"Enter shipment id value");
  browser.sleep(2000);

  reuse.ClickElement(ordervalue, "Click on edit shipment id");
  browser.sleep(2000);

  reuse.EnterValue(ordervalue,ORDERVALUEdata,"Enter shipment id value");
  browser.sleep(2000);

  reuse.ClickElement(internationalservice, "Click on edit shipment id");
  browser.sleep(4000);

  reuse.ClickElement(internationalservicedrpdwn, "Click on edit shipment id");
  browser.sleep(4000);

  reuse.ClickElement(Aousavebtn, "Click on Save button");
  browser.sleep(2000);


  }

  /***************************************************************************************/
/* MethodName:  Update High value in View order details
  * Description: To update High value
  * Parameter (if any):  
  * Return type:  Void
***************************************************************************************/

  async Updatehighvalue(Testcase){

    var TcRow=ReadFromXL.FindRowNum(Testcase,"AOU");
    DataDictLib.pushToDictionaryWithSheet(TcRow,"AOU");
    var RemoveShipmentReq =DataDictLib.getFromDictionary('RemoveShipmentReq');
    var AddShipmentReq=DataDictLib.getFromDictionary('AddShipmentReq');
    var closeshipreq = element(by.xpath("//span[span[text()='"+RemoveShipmentReq+"']]//a[@class='close icon-jbh_close font24']"));
    var Closebtn = element.all(by.xpath("//div[div[contains(text(),'Shipment Requirements')]]//a[@class='close icon-jbh_close font24'] "));
    var Closebtncount = element(by.xpath("//div[div[contains(text(),'Shipment Requirements')]]//a[@class='close icon-jbh_close font24'] "));
    var shipmentreqdrpdwn = element(by.xpath("//div[div[contains(text(),'Shipment Requirements')]]//ul//li//div//a//div[text()='"+AddShipmentReq+"']"));
    //var internationalservicedrpdwn = element(by.xpath("//div[div[contains(text(),'"+AddShipmentReq+"')]]//ul//li//div//a//div[text()='Rail Intact Service']"));
    
    
    reuse.ClickElement(Editshipment, "Click on edit shipment icon");
    browser.sleep(2000);
    browser.executeScript("window.scrollTo(0,100)");
   
    if(Closebtn){ 
    Closebtn.each(function(){
        reuse.ClickElement(Closebtncount, "Remove selected shipment");
        browser.sleep(5000);


      });
    }

    reuse.ClickElement(shipmentreq, "Click on shipment dropdown");
    browser.sleep(4000);
    reuse.ClickElement(shipmentreqdrpdwn, "Click on dropdown value");
    browser.sleep(4000);
    reuse.ClickElement(Aousavebtn, "Click on Save button");
    browser.sleep(2000);

    var SuccessMessage=await reuse.ValidationMessage();
    if(SuccessMessage ==="Order Updated Successfully")
      {
     console.log("Accepted order is updated");

      }
      else{

        console.log("Accepted order is not updated Successfully");

      }


    }

      /***************************************************************************************/
/* MethodName:  Update vessel in View order details
  * Description: To update vessel
  * Parameter (if any):  
  * Return type:  Void
***************************************************************************************/



    async Vesselupdate(Testcase){

      var TcRow=ReadFromXL.FindRowNum(Testcase,"AOU");
      DataDictLib.pushToDictionaryWithSheet(TcRow,"AOU");
      var VesselNumberdata =DataDictLib.getFromDictionary('VesselNumber');
      var VoyageNumberdata=DataDictLib.getFromDictionary('VoyageNumber');

      reuse.ClickElement(Editshipment, "Click on edit shipment icon");
      browser.sleep(2000);
     
      reuse.ClickElement(vesselnumber, "Click on vessel textbox");
      browser.sleep(2000);

      reuse.EnterValue(vesselnumber,VesselNumberdata,"Enter vessel number" );
        browser.sleep(5000);

      reuse.ClickElement(voyagenumber, "Click on voyage textbox");
      browser.sleep(4000);

      reuse.EnterValue(voyagenumber,VoyageNumberdata,"Enter voyage number" );
      browser.sleep(6000);

      reuse.ClickElement(Aousavebtn, "Click on Save button");
      browser.sleep(7000);

      var SuccessMessage=await reuse.ValidationMessage();
    if(SuccessMessage ==="Order Updated Successfully")
      {
     console.log("Accepted order is updated");

      }
      else{

        console.log("Accepted order is not updated Successfully");

      }
      }

          /***************************************************************************************/
/* MethodName:  Update Bond holder details in View order details
  * Description: To update Bond holder details
  * Parameter (if any):  
  * Return type:  Void
***************************************************************************************/

      internationalorderupdate(Testcase)
        {
          var TcRow=ReadFromXL.FindRowNum(Testcase,"AOU");
        DataDictLib.pushToDictionaryWithSheet(TcRow,"AOU");
        var Bondholderdata =DataDictLib.getFromDictionary('Bondholder');
        var Bondholderpartydata =DataDictLib.getFromDictionary('Bondholderparty');
        var bondhldidentfdata =DataDictLib.getFromDictionary('Bondholderidentification');
        var bondhldtypedata =DataDictLib.getFromDictionary('Bondholdertype');
        var entrynodata =DataDictLib.getFromDictionary('Entrynumber');
        var portofentrydata =DataDictLib.getFromDictionary('PortofEntry');
        var portofexitdata =DataDictLib.getFromDictionary('PortofExit');
        var InternationalServicedata=DataDictLib.getFromDictionary('InternationalService');
        var bondhldrledrpdwn = element(by.xpath("//div[div[contains(text(),'Bond Holder Role')]]//ul//li//div//a//div[text()='"+Bondholderdata+"']"));
        var bondhldpartydrpdwn = element(by.xpath("//div[div[contains(text(),'Bond Holder Party')]]//ul//li//div//a//div[text()='"+Bondholderpartydata+"']"));
        var bondhldtypedrpdwn = element(by.xpath("//div[div[contains(text(),' Bond Holder Type')]]//ul//li//div//a//div[text()='"+bondhldtypedata+"']"));
        var portofentrydrpdwn = element(by.xpath("//div[div[contains(text(),'Port of Entry')]]//ul//li//div//a//div[text()='"+portofentrydata+"']"));
        var portofexitdrpdwn = element(by.xpath("//div[div[contains(text(),'Port of Exit')]]//ul//li//div//a//div[text()='"+portofexitdata+"']"));
        var internationalservicedrpdwn = element(by.xpath("//div[div[contains(text(),'International Service')]]//ul//li//div//a//div[text()='"+InternationalServicedata+"']"));


        reuse.ClickElement(bondhldrle, "Click on bond holder dropdown");
        browser.sleep(2000);

        reuse.ClickElement(bondhldrledrpdwn, "select on bond holder dropdown value");
        browser.sleep(2000);

        reuse.ClickElement(bondhldparty, "Click on bond holder party dropdown");
        browser.sleep(2000);

        reuse.ClickElement(bondhldpartydrpdwn, "select on bond holder dropdown party value");
        browser.sleep(2000);

        reuse.ClickElement(bondhldidentf, "Click on bond holder identification textbox");
        browser.sleep(2000);

        reuse.EnterValue(bondhldidentf,bondhldidentfdata,"Enter bond holder identification");
        browser.sleep(2000);

        reuse.ClickElement(bondhldtype, "Click on bond holder type dropdown");
        browser.sleep(2000);

        reuse.ClickElement(bondhldtypedrpdwn, "select on bond holder type dropdown value");
        browser.sleep(2000);

        reuse.ClickElement(entryno, "Click on Entry number textbox");
        browser.sleep(2000);

        reuse.EnterValue(entryno,entrynodata,"Enter the entry number");
        browser.sleep(2000);

        reuse.ClickElement(portofentry, "Click on Port of Entry dropdown");
        browser.sleep(2000);

        reuse.ClickElement(portofentrydrpdwn, "select on Port of Entry dropdown value");
        browser.sleep(2000);

        reuse.ClickElement(portofexit, "Click on Port of Exit dropdown");
        browser.sleep(2000);

        reuse.ClickElement(portofexitdrpdwn, "select on Port of Exit dropdown value");
        browser.sleep(2000);

        reuse.ClickElement(Aousavebtn, "Click on Save button");
        browser.sleep(2000);




        }
  
/***************************************************************************************/
/* MethodName:  UpdateDetailsinOrder
  * Description: To update service level,party code time,and many details in View order page
  * Parameter (if any):  null
  * Return type:  Void
***************************************************************************************/
async UpdateDetailsinOrder() {
  
  
   this.ClickStopDetails("Origin")
     try {
      browser.executeScript("window.scrollTo(0,500)");
      var AppDetails=element(by.xpath("//h3[contains(text(),'Scheduled Appointment(s)')]"))
      reuse.SAClickElement(AppDetails, "Click AppDetails")
      browser.sleep(1000);     
      common.SelectTime("08:00", 3);
      browser.sleep(2000);
      var Save_Buttn = element(by.xpath("//div[@class='button-section']//div//button[text()='Save']"));
      reuse.SAClickElement(Save_Buttn,"Save");
       browser.sleep(5000);
       reuse.ClickElement(editserviceoff, "Click on edit SO icon");
       browser.sleep(5000);
      reuse.ClickElement(Servicelevel, "Click on Servicelevel dropdown");
      browser.sleep(2000);  
      reuse.ClickElement(Aousavebtn, "Click on Save button");
      browser.sleep(2000); 
      reuse.ClickElement(icon_editparty, "Click Edit icon for acounts and Contacts");
      reuse.ClickElement(icon_addparty, "Click Add Additional parties icon for acounts and Contacts");
      reuse.EnterValue(txt_Accountname, "Amse95", "Account name ")
      browser.sleep(2000);
      txt_Accountname.sendKeys(protractor.Key.ENTER);
      browser.sleep(3000); 
      reuse.ClickElement(btn_saveparty, "Click save button for acounts and Contacts");
      browser.sleep(2000);
      this.UpdateEquipmentNumber();
      this.UpdatEmergencyNo()
      
       }      
      catch{
       console.log("Edit button is not dispalyed")
     }
   
 }
 Accountcntediticon(){
  
            
            reuse.ClickElement(Accountcntedit, "Click on edit SO icon");
            browser.sleep(5000);
  
          }
          async Contactupdate(Testcase){
            
                      var TcRow=ReadFromXL.FindRowNum(Testcase,"AOU");
                      DataDictLib.pushToDictionaryWithSheet(TcRow,"AOU");
                      var addnewcntdrpdwndata =DataDictLib.getFromDictionary('Add a new contact');
                      var cntfrstnmedata =DataDictLib.getFromDictionary('Firstname');
                      var cntlastnmedata =DataDictLib.getFromDictionary('Lastname');
                      var cntphonenodata =DataDictLib.getFromDictionary('Phonenumber');
                      var cntmethoddrpdwnvaldata =DataDictLib.getFromDictionary('PreferredContactMathod');
            
                      
                      //Bill to add new contact
            
                      var addnewcntdrpdwn = element(by.xpath("//div[div[span[text()='Bill to Account']]]//div//div//i[@class='caret pull-right']"));
                      var addnewcntdrpdwnval = element(by.xpath("//div[text()='"+addnewcntdrpdwndata+"']"));
                      
                      //Add contact popup
                      var cntfrstnme = element(by.id("firstname"));
                      var cntlastnme = element(by.id("lastname"));
                      var cntmethoddrpdwn = element(by.xpath("//div[div[label[text()='Preferred Contact Method']]]//i[@class='caret pull-right']"));
                      var cntmethoddrpdwnval = element(by.xpath("//div[@class='ui-select-choices-row active']//a//div[text()='"+cntmethoddrpdwnvaldata+"']"));
                      var cntphoneno = element(by.id("phonenumber"));
                      var addcntbtn = element(by.id("btn-add"));
            
                      //edit operational service
                      var operservicedrpdwn = element(by.xpath("//div[div[contains(text(),'Operational Service(s)')]]//i[@class='caret']"));
                      var operservicedrpdwnval = element(by.xpath("//div[contains(text(),'Destination Customer Dray')]"));
            
                      reuse.ClickElement(addnewcntdrpdwn, "Click on Bill to Account contact");
                      browser.sleep(2000);
            
                      //browser.executeScript("window.scrollTo(0,-100)");
                      browser.actions().mouseMove(addnewcntdrpdwnval).perform();
            
                      reuse.ClickElement(addnewcntdrpdwnval, "Click on Add new contact");
                      browser.sleep(4000);
            
                      reuse.ClickElement(cntfrstnme, "Click on contact first name");
                      browser.sleep(4000);
            
                      reuse.EnterValue(cntfrstnme,cntfrstnmedata,"Enter the contact first name");
                      browser.sleep(4000);
            
                      reuse.ClickElement(cntlastnme, "Click on contact last name");
                      browser.sleep(4000);
            
                      reuse.EnterValue(cntlastnme,cntlastnmedata,"Enter the contact last name");
                      browser.sleep(4000);
            
                      reuse.ClickElement(cntmethoddrpdwn, "Click on Contact method dropdown");
                      browser.sleep(4000);
            
                      reuse.ClickElement(cntmethoddrpdwnval, "Click on Contact method dropdown value");
                      browser.sleep(2000);
            
                      reuse.ClickElement(cntphoneno, "Click on phone number");
                      browser.sleep(2000);
            
                      reuse.EnterValue(cntphoneno,cntphonenodata,"Enter the phone number");
                      browser.sleep(2000);
            
                      reuse.ClickElement(addcntbtn, "Click on Save button");
                      browser.sleep(10000);
            
                      reuse.ClickElement(Aousavebtn, "Click on Save button");
                      browser.sleep(2000);
            
                      reuse.ClickElement(editserviceoff, "Click on edit SO icon");
                      browser.sleep(5000);
            
                      reuse.ClickElement(operservicedrpdwn, "Click on edit SO icon");
                      browser.sleep(5000);
            
                      reuse.ClickElement(operservicedrpdwnval, "Click on edit SO icon");
                      browser.sleep(5000);
            
                      reuse.ClickElement(Aousavbtnso, "Click on Servicelevel save button");
                      browser.sleep(5000);
            
                      var SuccessMessage=await reuse.ValidationMessage();
                      if(SuccessMessage ==="Order Updated Successfully")
                       {
                      console.log("Accepted order is updated");
            
                          }
                        else{
            
                    console.log("Accepted order is not updated Successfully");
            
                  }
                }
 /***************************************************************************************/
/* MethodName:  UpdateDetailsinOrder
  * Description: To update service level,party code time,and many details in View order page
  * Parameter (if any):  null
  * Return type:  Void
***************************************************************************************/
async UpdateBilltoParty(Testcase) {
  var TcRow = ReadFromXL.FindRowNum(Testcase, "CreateOrder");
  DataDictLib.pushToDictionaryWithSheet(TcRow, "CreateOrder");
  var Accountname = DataDictLib.getFromDictionary('Accountname');
  var Accountrole = DataDictLib.getFromDictionary('Accountrole');
  var Billto=element(by.css("[formcontrolname='billToCode']"))
try{
  reuse.ClickElement(icon_editparty, "Click Edit icon for acounts and Contacts");
  browser.sleep(2000);
  Billto.clear();
  reuse.EnterValue(Billto, "Haspaw", "Account name ")
  browser.sleep(2000);
  Billto.sendKeys(protractor.Key.ENTER);
  browser.sleep(2000);
  reuse.ClickElement(icon_addparty, "Click Add Additional parties icon for acounts and Contacts");
  reuse.EnterValue(txt_Accountname, "Amse95", "Account name ")
  browser.sleep(2000);
  txt_Accountname.sendKeys(protractor.Key.ENTER);
  browser.sleep(3000);
  reuse.ClickElement(txt_Accountrole, "Click Account role deop down for acounts and Contacts");
  reuse.EnterValue(txt_Accountrole, "Freight", "Account Role")
  txt_Accountrole.sendKeys(protractor.Key.ENTER);
  browser.sleep(2000);
  reuse.SAClickElement(btn_saveparty, "Click save button for acounts and Contacts");
  browser.sleep(2000);
      
       }      
      catch{
       console.log("Edit button is not dispalyed")
     }
   
 }             
              
              }
