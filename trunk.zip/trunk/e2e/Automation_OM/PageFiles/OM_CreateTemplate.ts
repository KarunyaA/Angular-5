import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";
import {Update_Objects} from "../ObjectRepository/Objects_Order"
import { Key, WebElement } from "selenium-webdriver";

import {ExcelReader} from "../CommonFiles/ReadFromXL"

import {DataDictionary} from "../DataFiles/DictionaryData"
import {ReusableFunctions} from "../FunctionalLibrary/ReusableFunctions" 
import {CommonFunctions} from "../FunctionalLibrary/CommonFunctions"
var common= new CommonFunctions() 
var DictBU_OM = new DataDictionary();
var DictBU_EOM = new DataDictionary(); 
var OrderID;
let OBJCreate = new Update_Objects();
var ReadFromXL = new ExcelReader();
var DataDictLib = new DataDictionary();
var DataDictLib1 = new DataDictionary();
let reuse= new ReusableFunctions();
var ExcelDataSourceForConf = require('../CommonFiles/ReadFromXL');
var PushAndPullDataDictLib = require('../DataFiles/DictionaryData');
var icon_loading=element(by.xpath("//*[@class='spinner' and @role='progressbar']"));
////////////////////////////////////////// Create Order Page ///////////////////////////////////////////////////////////////////////////////

var BillTo=element(by.css("[id=\"billtoaccount\"]"));
var BillToValue=element(by.xpath("//ul[@class=\"dropdown-menu\"]//li[@class=\"active\"]//a"));
var BTContact=element(by.css("[placeholder=\"Bill To Account Contact\"]"));
var ContactValue=element(by.xpath("//ul[@class=\"ui-select-choices dropdown-menu\"]//li//div[@class=\"ui-select-choices-row active\"]//a"));
var BU=element(by.xpath("//*[@formcontrolname='financeBusinessUnitCode']//i[2]"));
var BUclick=element(by.xpath("//input[@placeholder='Business Unit']"));
var BUValue=element(by.xpath("//*[@id='financeBusinessUnitCode']//ul//a/div"));
var SO=element(by.xpath("//ng-select[@formcontrolname='serviceOfferingCode']//i[2]"));
var SOclick=element(by.xpath("//input[@placeholder='Service Offering']"));
var SOValue=element(by.xpath("//ul[@class=\"ui-select-choices dropdown-menu\"]//li//a[contains(text(),'OTR')]/ancestor::a"));
var OPOwner=element(by.css("[id=\"operationalOwner\"]"));
var OPValue=element(by.xpath("//ul[@class=\"dropdown-menu\"]//li[@class=\"active\"]//a"));
var NextButton=element(by.buttonText("Next"));
var Tradingpartner=element(by.css("[formcontrolname='tradingPartnerCode']"));


//ADD Stop objects:
var Location=element(by.css("[formcontrolname='locationID']"));
var LocationContact=element(by.css("[placeholder='Contact']"));
var DestinationTab=element(by.xpath("//i[@class='glyphicon accordianIcon icon-jbh_expand']"));
var TemplateDestinationTab=element(by.xpath("//i[@class='glyphicon accordianIconCustomize textBold icon-jbh_expand']"));
var AddStopDestinationTab=element.all(by.xpath("//i[@class='glyphicon accordianIcon icon-jbh_expand']"));
var TemplateAddStopDestinationTab=element.all(by.xpath("//i[@class='glyphicon accordianIconCustomize textBold icon-jbh_expand']"));
var PalletChckBX=element(by.xpath("//a[@class='list-group-item']//following::input[@type='checkbox']"));;
var MultiplePalletChckBX=element.all(by.xpath("//a[@class='list-group-item']//following::input[@type='checkbox']"));;
var TemplatePalletChckBX=element(by.xpath("//a[@class='list-group-item']//following::input[@type='checkbox']"));;
var SaveButton=element(by.buttonText("Save"));
var Savebuttonreject=element.all(by.xpath("//button[@id='btn-save' and text()='Save']"));
var ItmdescDD=element(by.xpath("//ul[@class='dropdown-menu']//li[@class='active']//a//h5"));
var scac       =    element(by.xpath("//*[@placeholder='SCAC']"));
var scacsearch =    element(by.xpath("//span[text()='SCAC ']"));
var scactext    =   element(by.xpath("//div[@class='panel-heading']//span[text()='SCAC ']//following::input[1]"))
var scacenter   =   element(by.xpath("//div[@class='panel-heading']//span[text()='SCAC ']//following::span[1]"))
var three_dotOtr    =   element.all(by.xpath("//span[text()='OTR']//following::button[@id='btn-popOver']"));
var three_dotInter    =   element.all(by.xpath("//span[text()='Intermodal']//following::button[@id='btn-popOver']"));
var three_dotLTL   =   element.all(by.xpath("//span[text()='LTL']//following::button[@id='btn-popOver']"));
var ViewTemplate = element(by.xpath("//a[text()='View Template']"));
var copy_view   =   element.all(by.xpath("//span[text()='OTR']//following::button[@id='btn-popOver']//following::div/ul/li/a']"));
var threedot_temp   =element(by.xpath("//button[@id='btn-popOver']"));
var tempdrop        =element.all(by.xpath("//button[@id='btn-popOver']//following::div/ul/li/a[text()='Create Order']"));
var apnmt_ordovrview    =element(by.xpath("//div[text()='Scheduled Appointment ']//following::span[1]/span[1]"));
var apnmt_stop          =element(by.xpath("//span[text()='Origin']//following::span[@class='pad0 font-styles'][1]"));
 //Template search
 var Billtosearch=element(by.id("billToVal"));
 var OriginSearch=element(by.id("originVal"));
 var DestinationSearch=element(by.id("destinationVal"));
 var SearchIcon=element(by.id("span-search"));
 var TempalteDots=element(by.id("btn-popOver"));
 var trailernobutton=element(by.buttonText("Trailer Number"));
 var Trailernumber=element(by.xpath("//input[@placeholder='Trailer Number']"));
 var Trailerprefix=element(by.xpath("//span[text()='Trailer Prefix']"));
 var TrailerPrefixText=element(by.xpath("//input[@placeholder='Trailer Prefix']"));
 var ShipmentIdentificationNo=element(by.xpath("//input[@placeholder='Shipment Identification']"));
 var shipsecndarytype=element(by.id("orderSubTypeCode"));
 var shipsecndarytypetext=element(by.xpath("//input[@placeholder='Secondary Order Type']"));
 var ordervalue=element(by.id("order-value"));
 var fleetcode=element(by.id("fleetCode"));
 var ordernumber = element(by.className("ordernumber"));
 var freightcharges=element(by.id("freightChargeTermTypeCode"));
 var freightchargestext=element(by.xpath("//input[@placeholder='Freight Charge Terms']"));
 var AddappointmentIcon=element.all(by.xpath("//a[@class='link-icon-secondary']//i")); 
 var AddappointmentIconschedule=element(by.xpath("//p[text()='Primary Appointment']//following::h3[text()='Scheduled Appointments']//following::i[1]"));
 var tagname=element.all(by.css("[formcontrolname='packagingUnitTypeQuantity']"));
 var tagname1=element.all(by.css("[formcontrolname='itemWeight']"));
 var tagname2=element.all(by.css("[formcontrolname='itemDescription']"));
 var itemunit=element.all(by.css("[formcontrolname=\"itemHeight\"]"));
 var itemchar=element.all(by.css("[formcontrolname='itemCharacteristics']"));
 var itemcharname=element.all(by.css("[formcontrolname='itemCharacteristics']"));
 var NMFCNumber=element.all(by.css("[formcontrolname='freightClassCode']"));
 var StopReason=element(by.id("stopReason"));
 var StopReasonText=element(by.xpath("//li/div/a/div[text()='Pickup']"));
 var shipmentreq=element(by.id("shipment-requirement"));
 var shipmentreqText=element(by.xpath("//*[@id='shipment-requirement']//span[@class='ui-select-match']//following::input[1]"));
 var interservice=element(by.id("serviceType"));
 var interservicetext=element(by.xpath("//*[@id='serviceType']//span[@class='ui-select-match']//following::input[1]"));
 var inbondToggle=element(by.xpath("//*[@for='inbond-freight' and @class='jbh-toggle-label']"));
 var PickDateorderOverview=element(by.xpath("//div[text()='Scheduled Appointment']//following::span[1]"));
 var DelidateorderOverview=element(by.xpath("//div[text()='Scheduled Appointment']//following::span[2]"));
 var template_filter=element(by.css('[id="span-filter"]'));
 var itemchar_type=element(by.xpath("//*[@placeholder='Item Characteristics']"));
 var unnacode=element(by.xpath("//*[@id='unnaCode']"));
 var shippingname=element(by.xpath("//span[text()='Proper Shipping Name']"));
 var stopbox=element(by.css('[formcontrolname="locationID"]'));
 var primary=element(by.xpath("//span[text()='Primary Hazard Class']"));
 var secondary=element(by.xpath("//span[text()='Secondary Hazard Class']"));
export class CreateTemplateFunctions{
   /*********************************************************************
	 * 
	* MethodName:  SearchTemplate
	* Description: To search a template with BILLTo 
	* Parameter (if any):  NIL
	* Return type:  void
	 ********************************************************************/
  SearchTemplate(Billto:string):void { 
    
  reuse.EnterValue(Billtosearch,Billto,"Enter Bill to value") 
   browser.sleep(3000);
   Billtosearch.sendKeys(protractor.Key.ENTER);
    browser.sleep(3000);
    reuse.ClickElement(SearchIcon,"Click Search icon")
    browser.sleep(4000);
    //this.ElementWait(true,TempalteDots);                                                                                                                
     }

 /*********************************************************************
	 * 
	* MethodName:  Enteringdata
	* Description: To Enter the values in the First page of Order Creation
	* Parameter (if any):  NIL
	* Return type:  string
	 ********************************************************************/

  async Enteringdata(Testcasename:string) { 
    var TcRow=ReadFromXL.FindRowNum(Testcasename,"CreateOrder");
    
    DataDictLib.pushToDictionaryWithSheet(TcRow,"CreateOrder");
    var BUValue =DataDictLib.getFromDictionary('BU');
    var SOValue =DataDictLib.getFromDictionary('SO');
    var BillToValue =DataDictLib.getFromDictionary('BillTO');
    var OpOwner =DataDictLib.getFromDictionary('OpOwner');
    var TitleCreate =DataDictLib.getFromDictionary('CreateTitle');
    var Trailernumber =DataDictLib.getFromDictionary('Trailernumber');
    var TrailerPrefix =DataDictLib.getFromDictionary('TrailerPrefix');
    //var Scac =DataDictLib.getFromDictionary('scac');
   var Scac:string="HJBTVAN";
   reuse.EnterValue(BillTo,BillToValue,"Bill to value")  
    browser.sleep(2000); 
    BillTo.sendKeys(protractor.Key.ENTER);
  
    icon_loading.isPresent().then((elem)=>{
      if(elem==true){
                        console.log("Loading icon is present")
      }
      browser.sleep(2000);
    })
    browser.sleep(5000);
    //reuse.ClickElement(BTContact,"Contact for Bil to")
   //browser.sleep(2000)
   //BTContact.sendKeys(protractor.Key.ENTER); 
   browser.executeScript("window.scrollTo(0,100)");
   reuse.ClickElement(BU,"Click BU Drop down")
   reuse.EnterValue(BUclick,BUValue,"SO to value")  
   browser.sleep(2000)
   BUclick.sendKeys(protractor.Key.ENTER);
    browser.sleep(2000);
    reuse.ClickElement(SO,"Click SO Drop down")
    reuse.EnterValue(SOclick,SOValue,"SO to value")  
   // browser.sleep(2000)
    SOclick.sendKeys(protractor.Key.ENTER);
    browser.sleep(3000);
    if(Scac!="Null"){
  scac.isPresent().then((elem)=>{ 
          if (elem===true){          
            Tradingpartner.click();
            browser.sleep(1000);
            for (let i:number = 0; i < Scac.length; i++) {
              reuse.ClickElement(scac,"Click SCAC value");
             // (scac).clear();
             (scac).sendKeys(Scac.charAt(i));
            // scac.se(Scac);
              browser.sleep(3000);
             // element.sendKeys(string.charAt(i));
            }
          }
          })
        }
    if(TrailerPrefix!="NULL"){
   this.Trailer("0000000105",TrailerPrefix)
    } 
   if (TitleCreate === "Create New Order") {
     reuse.EnterValue(OPOwner,OpOwner,"Operational owner")  
    browser.sleep(2000)
    OPOwner.sendKeys(protractor.Key.ENTER);
   
   } else {
    console.log("Create new template do not contain this field"); 
   }
   if (TitleCreate === "Create New Order") {
   await reuse.getTextValueFromElement(ordernumber).then((text)=>{ 
    OrderID = text 
    }) ;
    console.log("base order "+OrderID);
    return OrderID 
  }
   } 
   
  /*********************************************************************
     * 
    * MethodName:  Trailer Name   
    * Description: To Add the Trailer Name if specified in the test case
    * Parameter (if any):  NIL
    * Return type:  Void
     ********************************************************************/
  
   Trailer(Trailerno:string,Trailervalue:string):void { 
    trailernobutton.isPresent().then((elem)=>{ 
      if (elem===true){ 
        reuse.ClickElement(trailernobutton,"Click Trailer button");
        reuse.EnterValue(Trailernumber,Trailerno,"Trailer number")  
        browser.sleep(2000);
        Trailernumber.sendKeys(protractor.Key.TAB);
        browser.sleep(3000);
        reuse.EnterValue(TrailerPrefixText,Trailervalue,"Trailer number")
        reuse.ClickElement(Trailerprefix,"Click trialer Prefix drop down");
        reuse.EnterValue(Trailernumber,Trailerno,"Trailer number")  
        TrailerPrefixText.sendKeys(protractor.Key.ENTER); 
        browser.sleep(2000)
      }
    });
        }
    /*********************************************************************
     * 
    * MethodName:  Freight Charges
    * Description: To Enter the values in Freight charges 
    * Parameter (if any):  charge value
    * Return type:  Void
     ********************************************************************/
   Freightcharges(charge:string):void { 
    freightcharges.isPresent().then((elem)=>{ 
      if (elem===true){      
        reuse.ClickElement(freightcharges,"Click Freight charges");
        reuse.EnterValue(freightchargestext,charge,"Freight charge value")  
      freightchargestext.sendKeys(protractor.Key.ENTER);
      } 
    });
    }
   /*********************************************************************
     * 
    * MethodName:  Shipmentdetails
    * Description: To Enter the shipment values in the First page of Order Creation
    * Parameter (if any):  charge,ordervalue,fleetcode
    * Return type:  Void
     ********************************************************************/
      Shipmentdetails(charge:string,ordervaluetext:string,fleetcode:string):void { 
        ShipmentIdentificationNo.isPresent().then((elem)=>{ 
          if (elem===true){ 
     reuse.EnterValue(ShipmentIdentificationNo,charge,"Shipment identification number") 
    reuse.ClickElement(shipsecndarytype,"Click Shipment secondary type");
         reuse.EnterValue(shipsecndarytypetext,"Will","Shipment secondary type value") 
        shipsecndarytypetext.sendKeys(protractor.Key.ENTER);
         reuse.EnterValue(ordervalue,ordervaluetext,"Order value") 
        }
      });
      }
   /*************************************************************************************
     * 
    * MethodName:  AddstopsOrigin
    * Description: To Enter the origin details in the Add Stops page of Order Creation
    * Parameter (if any):  NIL
    * Return type:  Void
     ************************************************************************************/
        AddstopsOrigin(Testcasename:string,Scheduled:string,Requested:string,pickupdate:string):void
        { 
         
          reuse.ClickElement(NextButton,"Next Button")
          //this.ClickButtonwithText("Next");
          browser.sleep(3000);
          var TcRow=ReadFromXL.FindRowNum(Testcasename,"StopDetails");
          
          DataDictLib.pushToDictionaryWithSheet(TcRow,"StopDetails");
          var Pickup =DataDictLib.getFromDictionary('Pickup');
          var Delivery =DataDictLib.getFromDictionary('Delivery');
          var ItemQty =DataDictLib.getFromDictionary('ItemQty');
          var ItemWt =DataDictLib.getFromDictionary('ItemWt');
          var ItemChar =DataDictLib.getFromDictionary('ItemChar');
          var TitleCreate =DataDictLib.getFromDictionary('CreateTitle');
         
          var NoOfAppoint =DataDictLib.getFromDictionary('NoOfAppoint');
          var NoOfItem =DataDictLib.getFromDictionary('NoOfitems');
          var NoOfStop =DataDictLib.getFromDictionary('Noofstops');
          common.EnterTextBox("locationID",Pickup);
          browser.sleep(5000);
          reuse.ClickElement(BillToValue,"BillTo value")
           browser.sleep(4000);
           common.SelectDRopdownValue("Contact");
           browser.sleep(2000);
           if(Requested=="Requested"){
            if(NoOfAppoint==1){
           common.Selectcalendericon(pickupdate,0);
           browser.sleep(2000);
           common.SelectTime("08:00",0);
           browser.sleep(2000);
           common.Selectcalendericon(pickupdate,1);
           browser.sleep(2000);
           common.SelectTime("09:00",1);
           //common.SelectTime("09:00",1);
          browser.sleep(2000);
            }
            if(NoOfAppoint>1){
  for(var i=2;i<NoOfAppoint;i++){
  console.log(NoOfAppoint+2)
  common.Selectcalendericon(pickupdate,i);
  browser.sleep(2000);
  common.SelectTime("08:00",i);
  // browser.sleep(2000);
  common.Selectcalendericon(pickupdate,i+1);
  browser.sleep(2000);
  common.SelectTime("09:00",i+1);
  //common.SelectTime("09:00",1);
  browser.sleep(2000);
  }
  
            } 
                
           }
           if(Scheduled=="Scheduled"){
            if(NoOfAppoint==1){
          AddappointmentIcon.get(1).click();
          if (TitleCreate === "Create New Order") {
            AddappointmentIcon.get(1).click();
            common.Selectcalendericon(pickupdate,2);
            browser.sleep(2000);
            common.SelectTime("08:30",2);
            browser.sleep(2000);
            common.Selectcalendericon(pickupdate,3);
           browser.sleep(2000);
            common.SelectTime("09:30",3);
           browser.sleep(2000);}
           if (TitleCreate === "Create New Template") {
            AddappointmentIcon.get(0).click();
            common.Selectcalendericon(pickupdate,0);
            browser.sleep(2000);
            common.SelectTime("08:30",0);
            browser.sleep(2000);
            common.Selectcalendericon(pickupdate,1);
           browser.sleep(2000);
            common.SelectTime("09:30",1);
           browser.sleep(2000);}
          }
           if(NoOfAppoint>1){
            for(var i=4;i<=4;i++){
              console.log(NoOfAppoint+2)
              AddappointmentIcon.get(1).click();
              common.Selectcalendericon(pickupdate,2);
              browser.sleep(2000);
              common.SelectTime("08:00",2);
             // browser.sleep(2000);
              common.Selectcalendericon(pickupdate,3);
             browser.sleep(2000);
              common.SelectTime("09:00",3);
              browser.sleep(4000);
              browser.executeScript("window.scrollTo(0,-100)"); 
              AddappointmentIcon.get(0).click();
              browser.sleep(4000);
              AddappointmentIconschedule.click();
              common.Selectcalendericon(pickupdate,i);
              browser.sleep(2000);
              common.SelectTime("09:00",i);
             // browser.sleep(2000);
              common.Selectcalendericon(pickupdate,i+1);
             browser.sleep(2000);
              common.SelectTime("10:00",i+1);
             browser.sleep(2000);
            }
           }
          }
           browser.sleep(6000)
           this.HandlingUnit(Testcasename);
           browser.sleep(3000)
          this.Itemdetails(Testcasename);
           
          var tagname=element(by.css("[formcontrolname=\"itemDescription\"]"));
          tagname.sendKeys(protractor.Key.ENTER);
      
          browser.sleep(5000);
        }
  /*****************************************************************************************
     * 
    * MethodName:  AppointmentOrigin
    * Description: To add appointment details when an order is created from a saved template
    * Parameter (if any):  Scheduled,pickupdate,Ordername
    * Return type:  Void
     ***************************************************************************************/
        AppointmentOrigin(Testcasename:string,Scheduled:string,pickupdate:string,Ordername:string):void{
          var TcRow=ReadFromXL.FindRowNum(Testcasename,"StopDetails");        
          DataDictLib.pushToDictionaryWithSheet(TcRow,"StopDetails");
        var NoOfAppoint =DataDictLib.getFromDictionary('NoOfAppoint');
          var NoOfItem =DataDictLib.getFromDictionary('NoOfitems');
          var NoOfStop =DataDictLib.getFromDictionary('Noofstops');
           if(Scheduled=="Scheduled"){
            if(NoOfAppoint==1){
          AddappointmentIcon.get(1).click();
          if (Ordername === "Create New Order") {
            AddappointmentIcon.get(1).click();
            common.Selectcalendericon(pickupdate,2);
            browser.sleep(2000);
            common.SelectTime("08:30",2);
            browser.sleep(2000);
            common.Selectcalendericon(pickupdate,3);
           browser.sleep(2000);
            common.SelectTime("09:30",3);
           browser.sleep(2000);}
           if (Ordername === "Create New Template") {
            AddappointmentIcon.get(0).click();
            common.Selectcalendericon(pickupdate,0);
            browser.sleep(2000);
            common.SelectTime("08:30",0);
            browser.sleep(2000);
            common.Selectcalendericon(pickupdate,1);
           browser.sleep(2000);
            common.SelectTime("09:30",1);
           browser.sleep(2000);}
          }        
          }      }
  /*****************************************************************************************
     * 
    * MethodName:  AppointmentOrigin
    * Description: To add appointment details in origin when an order is created from a saved template
    * Parameter (if any):  Scheduled,pickupdate,Ordername
    * Return type:  Void
     ***************************************************************************************/
  AppiontmentDestination(Testcasename:string,Scheduled:string,DeliveryDate:string,Ordername:string,Index:number){
    var TcRow=ReadFromXL.FindRowNum(Testcasename,"StopDetails");        
    DataDictLib.pushToDictionaryWithSheet(TcRow,"StopDetails");
  var NoOfAppoint =DataDictLib.getFromDictionary('NoOfAppoint');
    var NoOfItem =DataDictLib.getFromDictionary('NoOfitems');
    var NoOfStop =DataDictLib.getFromDictionary('Noofstops');
  
    
    if(Scheduled=="Scheduled"){
      
        if (Ordername === "Create New Order") {
          AddappointmentIcon.get(1).click();
       common.Selectcalendericon(DeliveryDate,Index);
       browser.sleep(2000);
       common.SelectTime("08:30",Index);
      // browser.sleep(2000);
       common.Selectcalendericon(DeliveryDate,(Index+1));
      browser.sleep(2000);
       common.SelectTime("09:30",(Index+1));
      browser.sleep(2000);
      }
      if (Ordername === "Create New Template") {
        AddappointmentIcon.get(0).click();
        common.Selectcalendericon(DeliveryDate,0);
        browser.sleep(2000);
        common.SelectTime("08:30",0);
        browser.sleep(2000);
        common.Selectcalendericon(DeliveryDate,1);
       browser.sleep(2000);
        common.SelectTime("09:30",1);
       browser.sleep(2000);
      }
  
  
    }
  }
  /*****************************************************************************************
     * 
    * MethodName:  AppointmentDestination
    * Description: To add appointment details in Dest when an order is created from a saved template
    * Parameter (if any):  Scheduled,pickupdate,Ordername
    * Return type:  Void
     ***************************************************************************************/
  
        HandlingUnit(Testcasename){
          var TcRow=ReadFromXL.FindRowNum(Testcasename,"StopDetails");
          
          DataDictLib.pushToDictionaryWithSheet(TcRow,"StopDetails");
  var ItemQty =DataDictLib.getFromDictionary('ItemQty');
  var ItemWt =DataDictLib.getFromDictionary('ItemWt');
  //dropdownopt.click();
  common.EnterTextBox("itemHandlingTypeQuantity",ItemQty)
  browser.sleep(2000);
  common.EnterTextBox("itemHandlingUnitWeight",ItemWt);
  browser.sleep(2000);       
  
  var Handlingunit=element(by.css("[formcontrolname=\"itemHandlingUnitHeight\"]"));
  Handlingunit.sendKeys(protractor.Key.TAB);            
  browser.sleep(5000);
  
  }
  /*****************************************************************************************
     * 
    * MethodName:  Itemdetails
    * Description: To item details in origin when an order is created 
    * Parameter (if any):  Scheduled,pickupdate,Ordername
    * Return type:  Void
     ***************************************************************************************/
  Itemdetails(Testcasename:string){
    var TcRow=ReadFromXL.FindRowNum(Testcasename,"StopDetails");
    
    DataDictLib.pushToDictionaryWithSheet(TcRow,"StopDetails");
  var ItemQty =DataDictLib.getFromDictionary('ItemQty');
  var ItemWt =DataDictLib.getFromDictionary('ItemWt');
  var ItemChar =DataDictLib.getFromDictionary('ItemChar');
  var NoOfItem =DataDictLib.getFromDictionary('NoOfitems');
  if(NoOfItem==0){
    common.EnterTextBox("packagingUnitTypeQuantity",ItemQty);
    common.EnterTextBox("itemWeight",ItemWt);
  
  browser.sleep(5000);
  var itemunit=element(by.css("[formcontrolname=\"itemHeight\"]"));
  itemunit.sendKeys(protractor.Key.TAB);
  browser.sleep(12000);
  common.EnterTextBox("itemDescription",ItemChar)
  browser.sleep(5000);
  var tagname=element(by.css("[formcontrolname=\"itemDescription\"]"));
  }
  if(NoOfItem>=1){
    common.EnterTextBox("packagingUnitTypeQuantity",ItemQty);
    common.EnterTextBox("itemWeight",ItemWt);
  
  browser.sleep(5000);
  var itemunit=element(by.css("[formcontrolname=\"itemHeight\"]"));
  itemunit.sendKeys(protractor.Key.TAB);
  browser.sleep(12000);
  
  common.EnterTextBox("itemDescription",ItemChar)
  browser.sleep(6000);
  var tagname=element(by.css("[formcontrolname=\"itemDescription\"]"));
  tagname.sendKeys(protractor.Key.ENTER);
  browser.sleep(5000);
  (AddappointmentIcon.get(5)).click();
  reuse.ClickElement((AddappointmentIcon.get(5)),"Apointment Add icon click")
  browser.sleep(5000);
  for(var i=1;i<=NoOfItem;i++)
  {
    var j =5;
  
    var AddItem=((j+=2));
  console.log((j+=2));
  console.log("Console value for j is ",j);
  var ItemQtyvalue=(tagname.get(i));
  var ItemWeightValue=(tagname1.get(i));
  var itemunitvalue=(itemunit.get(i));
  var ItemWeightValue=(tagname1.get(i));
  var ItemCharName=(tagname2.get(i));
  
  var ItemCharFreezeName=(itemchar.get(i));
  var NMFCNumber=(NMFCNumber.get(i));
  ItemQtyvalue.clear();
  reuse.EnterValue(ItemQtyvalue,ItemQty,"Item Qauntity value") 
  
  ItemWeightValue.clear();
  reuse.EnterValue(ItemWeightValue,ItemWt,"Item Weight value") 
  browser.sleep(5000);  
  itemunit.sendKeys(protractor.Key.TAB);
  browser.sleep(5000);
  reuse.ClickElement(ItemCharName,"Click SO Drop down")
  ItemCharName.sendKeys(protractor.Key.TAB);
  NMFCNumber.sendKeys(protractor.Key.TAB);
  //ItemCharFreezeName.click();
  browser.sleep(3000);
  ItemCharName.clear();
  reuse.EnterValue(ItemCharName,ItemChar,"Item Characteristics name") 
  browser.sleep(5000);
  ItemCharName.sendKeys(protractor.Key.ENTER);
  browser.sleep(5000);
  //var tagname=element(by.css("[formcontrolname=\"itemDescription\"]"));
  //ItemCharName.sendKeys(protractor.Key.ENTER);
  //browser.sleep(5000);
  reuse.ClickElement((AddappointmentIcon.get(AddItem)),"Apointment Add icon click")
  browser.sleep(5000);
  }  
  }
  }
  /*****************************************************************************************
     * 
    * MethodName:  AddstopsDestination
    * Description: To add Destination stop details when an order is created 
    * Parameter (if any):  Scheduled,Requested,DeliveryDate
    * Return type:  Void
     ***************************************************************************************/
  AddstopsDestination(Testcasename:string,Scheduled:string,Requested:string,DeliveryDate):void {
          var TitleCreate =DataDictLib.getFromDictionary('CreateTitle');
          var Delivery =DataDictLib.getFromDictionary('Delivery');
          var pickupdate =DataDictLib.getFromDictionary('Pickup');
          var deliverdate =DataDictLib.getFromDictionary('Delivery');
          var StartTime =DataDictLib.getFromDictionary('PickupDate');
          var endTime =DataDictLib.getFromDictionary('Deliverydate');
                       if (TitleCreate === "Create New Order") {
            reuse.ClickElement(DestinationTab,"Click Destination Tab")
            browser.sleep(4000);
                          
                       } else {
                             TemplateDestinationTab.click(); reuse.ClickElement(SO,"Click SO Drop down")
            browser.sleep(7000);
                       }
           common.EnterTextBox("locationID",Delivery);
          browser.sleep(5000);
         reuse.ClickElement(BillToValue,"Click destination from drop down")
          browser.sleep(2000);
          common.SelectDRopdownValue("Contact");
          browser.sleep(2000);
          if(Requested=="Requested"){
            common.Selectcalendericon(DeliveryDate,0);
            browser.sleep(2000);
            common.SelectTime("08:00",0);
           // browser.sleep(2000);
            common.Selectcalendericon(DeliveryDate,1);
            browser.sleep(2000);
            common.SelectTime("09:00",1);
            //common.SelectTime("09:00",1);
           browser.sleep(2000);
            }
            if(Scheduled=="Scheduled"){
            
              if (TitleCreate === "Create New Order") {
                AddappointmentIcon.get(1).click();
             common.Selectcalendericon(DeliveryDate,2);
             browser.sleep(2000);
             common.SelectTime("08:30",2);
            // browser.sleep(2000);
             common.Selectcalendericon(DeliveryDate,3);
            browser.sleep(2000);
             common.SelectTime("09:30",3);
            browser.sleep(2000);
            }
            if (TitleCreate === "Create New Template") {
              AddappointmentIcon.get(0).click();
              common.Selectcalendericon(pickupdate,0);
              browser.sleep(2000);
              common.SelectTime("08:30",0);
              browser.sleep(2000);
              common.Selectcalendericon(pickupdate,1);
             browser.sleep(2000);
              common.SelectTime("09:30",1);
             browser.sleep(2000);
            }
          
          }
            browser.sleep(3000); 
           // this.DateValidationCreateOrderOverview("01/04/2018","01/05/2018");
  
                       if (TitleCreate === "Create New Order") {
            PalletChckBX.isPresent().then((elem)=>{
            reuse.ClickElement(PalletChckBX,"Click Pallet checkbox")
            browser.sleep(2000);})
            //NextButton.click();
                       } else {
                       PalletChckBX.isPresent().then((elem)=>{
                           reuse.ClickElement(TemplatePalletChckBX,"Click Template Pallet check box")
                            browser.sleep(3000);})
                       }
              
          browser.sleep(4000);
         console.log("End of destination function");
            }
  /*****************************************************************************************
     * 
    * MethodName:  MultiplePalletCheckbox
    * Description: To select multiple pallet checkbox when multiple stops are added
    * Parameter (if any):  Title
    * Return type:  Void
     ***************************************************************************************/
          MultiplePalletCheckbox(Testcasename,Title):void{
            var DataDictLib1 = new DataDictionary();
            var DataDictLib2 = new DataDictionary();
            var TcRow1=ReadFromXL.FindRowNum(Testcasename,"CreateOrder")
            DataDictLib2.pushToDictionaryWithSheet(TcRow1,"CreateOrder")
            var TcRow=ReadFromXL.FindRowNum(Testcasename,"StopDetails")
           DataDictLib1.pushToDictionaryWithSheet(TcRow,"StopDetails");
           var Stopnumber =DataDictLib1.getFromDictionary('StopNumber'); 
            var TitleCreate =DataDictLib2.getFromDictionary('CreateTitle')
          
            if (TitleCreate === "Create New Order") {
              reuse.ClickElement((AddStopDestinationTab.get(Stopnumber)),"Click Destination tab")
              browser.sleep(3000);            
              browser.executeScript("window.scrollTo(0,500)");           
              if(Stopnumber>=1)
              {            
                browser.sleep(3000);
                for(var i=1;i<=Stopnumber;i++)
                {             
      browser.executeScript("window.scrollTo(0,500)");
               reuse.ClickElement((MultiplePalletChckBX.get(i)),"Click Multiple pallet checkbox")
                  browser.sleep(6000);
                 }}             
                 }  
          //        else (TitleCreate === "Create New Template") 
          //        {
          //                    TemplateAddStopDestinationTab.get((Stopnumber)).click();
          //         browser.sleep(3000); 
          //         browser.executeScript("window.scrollTo(0,500)");               
          //         if(Stopnumber>=1)
          //         {
          //           browser.sleep(3000);
          //           for(var i=1;i<=Stopnumber;i++)
          //           {
          // browser.executeScript("window.scrollTo(0,500)");
          //         (MultiplePalletChckBX.get(i)).click();
          //             browser.sleep(6000);
          //            }}                      
          // }
        }
  /*****************************************************************************************
     * 
    * MethodName:  AddIntermediateStopDetails
    * Description: To add intermediate stops(multiple stops) while creating an order
    * Parameter (if any):  Requested,Pickupdate,StopNumber
    * Return type:  Void
     ***************************************************************************************/
            AddIntermediateStopDetails(Testcasename:string,Requested:string,Pickupdate:string,StopNumber:number):void
            { 
             // NextButton.click();
              //this.ClickButtonwithText("Next")            ;
              browser.sleep(5000);
              var DataDictLibStop = new DataDictionary();
              var TcRow=ReadFromXL.FindRowNum(Testcasename,"InterStops")
              DataDictLib.pushToDictionaryWithSheet(TcRow,"InterStops")
              var Location =DataDictLib.getFromDictionary('Stop'+StopNumber);
              //var Delivery =DataDictLib.getFromDictionary('Delivery');
              console.log("ItemQty"+StopNumber)
              var ItemQty =DataDictLib.getFromDictionary('ItemQty'+StopNumber);
              var ItemWt =DataDictLib.getFromDictionary('ItemWt'+StopNumber);
              var ItemChar =DataDictLib.getFromDictionary('ItemChar'+StopNumber);
              var TitleCreate =DataDictLib.getFromDictionary('CreateTitle');
              console.log("Console values are as below "+Location,+ItemQty,+ItemWt);
            
              var NoOfAppoint =DataDictLib.getFromDictionary('NoOfAppoint');
              var NoOfItem =DataDictLib.getFromDictionary('NoOfitems');
              var NoOfStop =DataDictLib.getFromDictionary('Noofstops');
              common.EnterTextBox("locationID",Location);
              browser.sleep(3000);
               BillToValue.click();
               browser.sleep(4000);
               reuse.ClickElement(StopReason,"Click stopreason drop down")
              reuse.ClickElement(StopReasonText,"Click the reason from drop down")
               browser.sleep(3000);
               common.SelectDRopdownValue("Contact");
               browser.sleep(4000);
               if(Requested=="Requested"){
                if(NoOfAppoint==1){
               common.Selectcalendericon(Pickupdate,0);
               browser.sleep(2000);
               common.SelectTime("08:00",0);
              // browser.sleep(2000);
               common.Selectcalendericon(Pickupdate,1);
               browser.sleep(2000);
               common.SelectTime("09:00",1);
               //common.SelectTime("09:00",1);
              browser.sleep(2000);
                }
                if(NoOfAppoint>1){
            for(var i=2;i<NoOfAppoint;i++){
            console.log(NoOfAppoint+2)
            common.Selectcalendericon(Pickupdate,i);
            browser.sleep(2000);
            common.SelectTime("08:00",i);
            // browser.sleep(2000);
            common.Selectcalendericon(Pickupdate,i+1);
            browser.sleep(2000);
            common.SelectTime("09:00",i+1);
            //common.SelectTime("09:00",1);
            browser.sleep(2000);
            }
            
                } 
                    
               }
               if(Requested=="Scheduled"){
                if(NoOfAppoint==1){
              reuse.ClickElement((AddappointmentIcon.get(1)),"Click add appointment icon")
                common.Selectcalendericon(Pickupdate,2);
                browser.sleep(2000);
                common.SelectTime("08:00",2);
               // browser.sleep(2000);
                common.Selectcalendericon(Pickupdate,3);
               browser.sleep(2000);
                common.SelectTime("09:00",3);
               browser.sleep(2000);}
               if(NoOfAppoint>1){
                for(var i=4;i<=4;i++){
                  console.log(NoOfAppoint+2)
                  reuse.ClickElement((AddappointmentIcon.get(1)),"Click add appointment icon")
                  common.Selectcalendericon(Pickupdate,2);
                  browser.sleep(2000);
                  common.SelectTime("08:00",2);
                 // browser.sleep(2000);
                  common.Selectcalendericon(Pickupdate,3);
                 browser.sleep(2000);
                  common.SelectTime("09:00",3);
                  browser.sleep(4000);
                  browser.executeScript("window.scrollTo(0,-100)"); 
                  reuse.ClickElement((AddappointmentIcon.get(0)),"Click add appointment icon")
                  browser.sleep(4000);
                  AddappointmentIconschedule.click();
                  common.Selectcalendericon(Pickupdate,i);
                  browser.sleep(2000);
                  common.SelectTime("09:00",i);
                 // browser.sleep(2000);
                  common.Selectcalendericon(Pickupdate,i+1);
                 browser.sleep(2000);
                  common.SelectTime("10:00",i+1);
                 browser.sleep(2000);
                }
               }
              }
               browser.sleep(3000)
               this.HandlingUnit(Testcasename);
               browser.sleep(3000)
              this.Itemdetails(Testcasename);
               
              var tagname=element(by.css("[formcontrolname=\"itemDescription\"]"));
              tagname.sendKeys(protractor.Key.ENTER);
            
              browser.sleep(15000);
            }
   /*****************************************************************************************
     * 
    * MethodName:  AppointmentOrigin
    * Description: To add InternationalShipment details when an order is created 
    * Parameter (if any):  NIL
    * Return type:  Void
     ***************************************************************************************/ 
    
  
   InternationalShipment():void {  
    shipmentreq.isPresent().then((elem)=>{ 
      if (elem===true){                                                                        
     reuse.ClickElement(shipmentreq,"Click Shipment Requirements")
   reuse.EnterValue(shipmentreqText,"Inter","Shipment Requirements text")
    shipmentreqText.sendKeys(protractor.Key.ENTER);  
    reuse.ClickElement(interservice,"Select International service")
    reuse.EnterValue(interservicetext,"door","Select International service value")
    interservicetext.sendKeys(protractor.Key.ENTER);
    //inbondToggle.click();
    //  bondholder.click();
   //  bondholdertext.sendKeys("Door");
   //  bondholdertext.sendKeys(protractor.Key.ENTER);
   //  bondholderparty.click();
   //  bondholderpartytext.sendKeys("Door");
   //  bondholderpartytext.sendKeys(protractor.Key.ENTER);
   // bondholderpartytype.click();
   // bondholderpartytypetext.sendKeys("Immediate Export");
    //bondholderpartytypetext.sendKeys(protractor.Key.ENTER);
      }
      });
    
  } 

/*****************************************************************************************
	 * 
	* MethodName:  AppointmentValidation
	* Description: To validate the appointmetn details of the order
	* Parameter (if any):  NIL
	* Return type:  Void
	 ***************************************************************************************/

  AppointmentValidation(){
    this.ElementValidation(apnmt_ordovrview);
    this.ElementValidation(apnmt_stop);
  }
  /*****************************************************************************************
     * 
    * MethodName:  ElementValidation
    * Description: To validate the element details of the order
    * Parameter (if any):  Scheduled,pickupdate,Ordername
    * Return type:  Void
     ***************************************************************************************/
  ElementValidation(Objelement):void{
    
          Objelement.isPresent().then((elem)=>{
            if(elem==true)
            {
              Objelement.getText().then((text )=>{
                console.log(text);
                console.log("Appointment details is present in order overview"+ text);
              })
            }
         })};
         /*****************************************************************************************
     * 
    * MethodName:  DateValidationCreateOrderOverview
    * Description: To validate the date details in order overview
    * Parameter (if any):  AppointmnetDatepickup,appointmentdateDelivery
    * Return type:  Void
     ***************************************************************************************/
  
              DateValidationCreateOrderOverview(AppointmnetDatepickup,appointmentdateDelivery):void{
                
                PickDateorderOverview.isPresent().then((elem)=>{
                        if(elem==true)
                        {
                          PickDateorderOverview.getText().then((text )=>{
                          var date=text.split(" ");
                          var PickupDate=date[0];
                          var pickupTime=date[1];
                           if(PickupDate==AppointmnetDatepickup){
                            console.log("Pickup Appointment details and Time zone in Order overview  is same as the appointment date while creating the order "+ text);
                           }
                                                        })
                        }
                      });
                     DelidateorderOverview.isPresent().then((elem)=>{
                      if(elem==true)
                      {
                        DelidateorderOverview.getText().then((text )=>{
                          var date=text.split(" ");
                          var Deliverydate=date[0];
                          var DeliveryTime=date[1];
                         if(Deliverydate==appointmentdateDelivery){
                          console.log("Delivery Appointment details and Time Zone in Order overview is same as the appointment date while creating the order "+ text);
                         }
                                                      })
                      }
                   });
                    }
 /*****************************************************************************************
	 * 
	* MethodName:  TemplateSearch
	* Description: To Search and select the first order by SCAC and SO
	* Parameter (if any):  NIL
	* Return type:  Void
	 ***************************************************************************************/
async TemplateSearch(Testcasename:string){
  var TcRow=ReadFromXL.FindRowNum(Testcasename,"Template");
  DataDictLib.pushToDictionaryWithSheet(TcRow,"Template");
  var scac =DataDictLib.getFromDictionary('SCACTemp');
     var sO =DataDictLib.getFromDictionary('SO');
         reuse.ClickElement(template_filter,"Click Template filter icon")
        reuse.ClickElement(scacsearch,"Click Scac search")
        reuse.ClickElement(scactext,"Click Scac value from the list")
       browser.sleep(2000);
       scactext.sendKeys(scac);
            browser.sleep(5000);
        reuse.ClickElement(scacenter,"Click SO Drop down")
        browser.sleep(5000);
      //  scactext.sendKeys(protractor.Key.ENTER)y
       browser.executeScript("window.scrollBy(0,-500)")
       if(sO==="OTR"){
        reuse.ClickElement((three_dotOtr.get(0)),"Click SO Drop down")
        browser.sleep(3000);
       }
       if(sO==="Intermodal")
       {
       
       reuse.ClickElement((three_dotOtr.get(0)),"Click SO Drop down")
       browser.sleep(5000);
       }
       if(sO==="LTL")
       {
        browser.sleep(5000);
        reuse.ClickElement((three_dotOtr.get(0)),"Click SO Drop down")
        browser.sleep(5000);
       }
       
       reuse.Clickwithtag("View Template")
      // reuse.ClickElement(ViewTemplate,"Click View template from the template")
       //this.dropdown(copy_view,"View Template");
       browser.sleep(8000);
       reuse.ClickElement(threedot_temp,"click three dot")
        reuse.ClickElement(tempdrop,"Click tempdrop")
       // this.dropdown(tempdrop,"Create Order");
        browser.sleep(25000);
       //common.ElementWait(true,ordernumber);
   
     await reuse.getTextValueFromElement(ordernumber).then((text)=>{ 
      OrderID = text 
      }) ;
      console.log("base order "+OrderID);
      return OrderID 

 }
 
 async TemplateSCACSearch(Testcasename:string){
  
  var TcRow=ReadFromXL.FindRowNum(Testcasename,"Template");
  DataDictLib.pushToDictionaryWithSheet(TcRow,"Template");
  var SCACValue =DataDictLib.getFromDictionary('SCAC');
  reuse.ClickElement(template_filter,"Template_Filter");
  reuse.ClickElement(scacsearch,"scacsearch");
  reuse.ClickElement(scactext,"scactext");
  browser.sleep(1000);
  reuse.EnterValue(scactext,SCACValue,"scac value")  
  browser.sleep(1000);
  reuse.ClickElement(scacenter,"scacenter");
  browser.executeScript("window.scrollBy(0,-500)")

    
    
}

Checkboxselect(){
      
  var ChckBX=element.all(by.xpath("//div[@class='datatable-checkbox checkbox checkbox-body']//following::input[@type='checkbox']"));
  var index=0;
  ChckBX.count().then(function(total) 
  {
    ChckBX.each(function (item) 
    {
      
      if(total > index)
      { index ++;
        if(index <3)
        {
        reuse.ClickElement(item,"Checkbox");
        }
      }
    })
  });
}


 Editselect(){
  
  var btnedit = element(by.id("btn-edit"));
  reuse.ClickElement(btnedit,"btnedit");
  browser.sleep(1000);
  
}

async Update_Func(message:string)
{
var btnupdate = element(by.id("btn-update"));
reuse.ClickElement(btnupdate,"OPService");
browser.sleep(3000);
var str_PopUp_Msg =await this.ValidationMessage();    

        if(str_PopUp_Msg.indexOf('Warning')!== -1)
      {
        console.log("A Warning pop up displayed to the user");
          //console.log(str_PopUp_Msg);              
      }
      else if(str_PopUp_Msg.indexOf('Success')!== -1)
      {
        console.log("A Success pop up displayed to the user");
         // console.log(str_PopUp_Msg);              
      } 
      else{ 
          console.log("A pop up not displayed to the user");
          console.log(str_PopUp_Msg);
      } 
      if(str_PopUp_Msg.indexOf(message)!== -1)
      {
        console.log("A pop up '"+message+"' displayed to the user");
      //  console.log(str_PopUp_Msg);
      }else{
        console.log("wrong pop up displayed to the user");
        //console.log(str_PopUp_Msg);
      } 

    }

AddInst(){
  var addInst = element(by.id("lnk-addAdtnlInst"));
  reuse.ClickElement(addInst,"addField");
}


AddField(){
  var addField = element(by.id("a-addField"));
  reuse.ClickElement(addField,"addField");
}


AddLink(){
  var addLink = element(by.id("lnk-add"));
  reuse.ClickElement(addLink,"addField");
  var addText = element(by.id("aditionalparty"));
  addText.sendKeys("ADD");
  browser.sleep(1000);
  addText.sendKeys(protractor.Key.ENTER);
  browser.sleep(1000);
  var Type_Role = element(by.id("accountRole"));
  reuse.ClickElement(Type_Role,"addRule");
  browser.sleep(1000);
  var Customs_Broker = element(by.cssContainingText('.dropdown-item', 'Customs Broker'));
  Customs_Broker.click();
}


AddComment(){
  var addComment = element(by.id("insdesc"));
  reuse.ClickElement(addComment,"addField");
  addComment.sendKeys("ADDADDADDADDADDADDADDADDADDADDADDADDADDADDADDADDADDADD");

}



TypeSelect_Func(type_Text:string):void 
{

var TypeSelect = element(by.xpath("//span[@class='btn btn-default btn-tag form-control ui-select-toggle']"));

reuse.ClickElement(TypeSelect,"TypeSelect");

element(by.cssContainingText('.ui-select-choices-row',type_Text)).click();
}

async ValidationMessage(){
  var txt_CreateCityError=element(by.xpath("//div[@class='jbh-notifications']/simple-notifications//simple-notification"));
  var str_Ui_PopUpTxt= await reuse.getTextValueFromElement(txt_CreateCityError);    
  return str_Ui_PopUpTxt;
}

async validatestatus()
{
var txt_Status = element(by.xpath("//datatable-body-cell[@class='datatable-body-cell sort-active'][4]/div/div/div[@class='cell_ellipsis pad-left20 pad-top10']"));
var str_Ui_StatusTxt= await reuse.getTextValueFromElement(txt_Status);
if(str_Ui_StatusTxt !=="Completed")
{
browser.refresh();
}
reuse.CompareValues("Completed",str_Ui_StatusTxt);
  
}

Go_back(){
var Butn_goBack=element(by.xpath("//a[@class='gobackarrow text-gray']"));
Butn_goBack.click();

}


    /*****************************************************************************************
	 * 
	* MethodName:  HazmatDetails
	* Description: To add appointment details when an order is created from a saved template
	* Parameter (if any):  Scheduled,pickupdate,Ordername
	* Return type:  Void
	 ***************************************************************************************/
  HazmatDetails(){
    var Item =DataDictLib.getFromDictionary('HAZMAT')
    var UNNA=DataDictLib.getFromDictionary('UNNA');
    var UNNAval=DataDictLib.getFromDictionary('UNNAval');
    var shippingname =DataDictLib.getFromDictionary('Hazmatshippingname');
   console.log("Entered Hazmat")
   // this.ElementWait(true,stopbox);
   //this.hazmatdropdowns("Item Characteristics","Haazmat")
   browser.sleep(6000);
   itemcharname.isPresent().then((elem)=>{ 
     if (elem===true){      
    reuse.ClickElement(itemcharname,"Click Item char name");      
   browser.sleep(3000);
   reuse.EnterValue(itemchar_type,Item,"Enter the Item Characteristic type")  
   itemchar_type.sendKeys(protractor.Key.SPACE);
   itemchar_type.sendKeys(protractor.Key.ENTER);
   browser.sleep(3000);
   
    reuse.ClickElement(unnacode,"Click Unna code")
   reuse.EnterValue(unnacode,UNNAval,"Enter the UNNA Code")  
   unnacode.sendKeys(protractor.Key.ENTER);
   //this.hazmatdropdowns("Proper Shipping Name","-Butyl chloroformate")
    reuse.ClickElement(shippingname,"Click shippingname")
   reuse.EnterValue(shippingname,shippingname,"Enter the Shipping name")  
   shippingname.sendKeys(protractor.Key.ENTER);
   reuse.ClickElement(primary,"Click primary value")
   primary.sendKeys(protractor.Key.TAB);
   primary.sendKeys(protractor.Key.ENTER);
 
 
   //this.hazmatdropdowns("Secondary Hazard Class","");
    reuse.ClickElement(secondary,"Click secondary value")
   secondary.sendKeys(protractor.Key.TAB);
   secondary.sendKeys(protractor.Key.ENTER);
     }
   });
  }

 
  
    
     

                         
                             
                            
                                
                                 

}
      
      
      
      
      

 
      
























