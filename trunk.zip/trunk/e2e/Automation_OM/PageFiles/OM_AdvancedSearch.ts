import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";
import {Update_Objects} from "../ObjectRepository/Objects_Order"
import { Key, WebElement } from "selenium-webdriver";

import {ExcelReader} from "../CommonFiles/ReadFromXL"

import {DataDictionary} from "../DataFiles/DictionaryData"
import {ReusableFunctions} from "../FunctionalLibrary/ReusableFunctions" 
import {CommonFunctions} from "../FunctionalLibrary/CommonFunctions"

var common= new CommonFunctions() 
var DictBU_OM = new DataDictionary();
var DictBU_EOM = new DataDictionary(); 
var OrderID;
let OBJCreate = new Update_Objects();
var ReadFromXL = new ExcelReader();
var DataDictLib = new DataDictionary();
var DataDictLib1 = new DataDictionary();
let reuse= new ReusableFunctions();

var ExcelDataSourceForConf = require('../CommonFiles/ReadFromXL');
var PushAndPullDataDictLib = require('../DataFiles/DictionaryData');
var allOptions =element.all(by.xpath("//*[@class='inline']//ng-select[@placeholder='Type'][1]")) 
var txt_OrderNumber=element(by.id("orderNumberSearch"));  
var Statuschange=element(by.xpath("//*[@formcontrolname='orderSearchStatus']//following::input"));
var acceptclose=element(by.xpath("//*[@formcontrolname='orderSearchStatus']//following::a")); 
var orderno=element.all(by.xpath("//*[@placeholder='Name']")); 
var apnmt_ordovrview    =element(by.xpath("//div[text()='Scheduled Appointment ']//following::span[1]/span[1]"));
var apnmt_stop          =element(by.xpath("//span[text()='Origin']//following::span[@class='pad0 font-styles'][1]"));
var ApntdatepickupAdvanced=element(by.xpath("//datatable-body-cell[@class='datatable-body-cell sort-active'][4]/div/h6/p[1]"));
var ApntdatedeliveryAdvanced=element(by.xpath("//datatable-body-cell[@class='datatable-body-cell sort-active'][5]/div/h6/p[1]"));
var PickDateorderOverview=element(by.xpath("//div[text()='Scheduled Appointment']//following::span[1]"));
var DelidateorderOverview=element(by.xpath("//div[text()='Scheduled Appointment']//following::span[2]"));
var Showmore=element(by.css("[id='orderSearchShowMore']"));
//var Destin =element(by.css("[formcontrolname='DestinationMarkettingArea']")); 

var Destin =element(by.xpath("//*[@formcontrolname='DestinationMarkettingArea']//input ")); 
var BUSelector =element(by.xpath("//span[contains(text(),'Business Unit')]"));  

var SOSelector =element(by.xpath("//span[contains(text(),'Service Offering')]"));  
var SearchButton=element(by.buttonText("Search"));       
var SelectFirstorder=element.all(by.xpath("//div[@class='datatable-row-center datatable-row-group']//following::div[@class='GridRowSpanStyle']//h6"));
var txt_orderStatus=element(by.css("//*[@formcontrolname='orderSearchStatus']"));
//var dd_bu=element(by.xpath("//*[@formcontrolname='orderSearchBusinessUnit']"));
//var dd_so=element(by.xpath("//*[@formcontrolname='orderSearchServiceOffering']"));
var dd_bu=element(by.css("[formcontrolname='orderSearchBusinessUnit']"));
var dd_BUValue=element(by.xpath("[placeholder='Business Unit']"));
var dd_so=element(by.css("[formcontrolname='orderSearchServiceOffering']"));
var dd_Destin=element(by.xpath("[formcontrolname='orderSearchBusinessUnit']"));
export class AdvancedSearchFunctions{
   /*********************************************************************
	 * 
	* MethodName:  AddContact
	* Description: To Add the Bill TO Contact
	* Parameter (if any):  NIL
	* Return type:  Void
	 ********************************************************************/
 AdvancedSearchwithdate(Pickupdate:string,DeliveryDate:string,CreatedDate:string):void {  
  // this.NavigatefromDashboard("Advanced Search");     
 // browser.sleep(3000);
  common.ElementWait(true,allOptions);
   // var allOptions =element.all(by.xpath("//*[@class='inline']//ng-select[@placeholder='Type'][1]"))
   allOptions.isPresent().then((elem)=>{ 
    if (elem===true){   
     reuse.ClickElement(acceptclose,"Click the close icon fro already available status")   
    common.Selectcalendericon(Pickupdate,0);
 browser.sleep(2000);
 common.Selectcalendericon(Pickupdate,1);
 browser.sleep(2000);
 common.Selectcalendericon(DeliveryDate,2);
 browser.sleep(2000);
 common.Selectcalendericon(DeliveryDate,3);
 browser.sleep(2000);
 common.Selectcalendericon(CreatedDate,4);
 browser.sleep(2000);
 common.Selectcalendericon(CreatedDate,5);
 browser.sleep(2000);
    }
});
                       
}

 /*****************************************************************************************
	 * 
	* MethodName:  AppointmentValidation
	* Description: To validate the appointmetn details of the order
	* Parameter (if any):  NIL
	* Return type:  Void
	 ***************************************************************************************/

AppointmentValidation(){
  this.ElementValidation(apnmt_ordovrview);
  this.ElementValidation(apnmt_stop);
}
/*****************************************************************************************
	 * 
	* MethodName:  ElementValidation
	* Description: To validate the element details of the order
	* Parameter (if any):  Scheduled,pickupdate,Ordername
	* Return type:  Void
	 ***************************************************************************************/
ElementValidation(Objelement):void{
  
        Objelement.isPresent().then((elem)=>{
          if(elem==true)
          {
            Objelement.getText().then((text )=>{
              console.log(text);
              console.log("Appointment details is present in order overview"+ text);
            })
          }
       })};

 /*********************************************************************
	 * 
	* MethodName:  ElementValidationAdvancedsearch
	* Description: To validate the element details of the order
	* Parameter (if any):  AppointmnetDatepickup,appointmentdateDelivery
	* Return type:  Void
	 ********************************************************************/
       ElementValidationAdvancedsearch(AppointmnetDatepickup,appointmentdateDelivery){
        
          ApntdatepickupAdvanced.isPresent().then((elem)=>{
                if(elem==true)
                {
                    ApntdatepickupAdvanced.getText().then((text )=>{
                    var date=text.split(" ");
                    var PickupDate=date[0];
                    var pickupTime=date[1];
                   if(PickupDate==AppointmnetDatepickup){
                    console.log("Pickup Appointment details in advanced search is same as the appointment date while creating the order "+ text);
                   }
                                                })
                }
             });
               ApntdatedeliveryAdvanced.isPresent().then((elem)=>{
              if(elem==true)
              {
                  ApntdatedeliveryAdvanced.getText().then((text )=>{
                  var date=text.split(" ");
                  var PickupDate=date[0];
                  var pickupTime=date[1];
                 if(PickupDate==appointmentdateDelivery){
                  console.log("Delivery Appointment details in advanced search is same as the appointment date while creating the order "+ text);
                 }
                                              })
              }
           });
            }
      /*****************************************************************************************
	 * 
	* MethodName:  DateValidationCreateOrderOverview
	* Description: To validate the date details in order overview
	* Parameter (if any):  AppointmnetDatepickup,appointmentdateDelivery
	* Return type:  Void
	 ***************************************************************************************/

  DateValidationCreateOrderOverview(AppointmnetDatepickup,appointmentdateDelivery):void{
              
    PickDateorderOverview.isPresent().then((elem)=>{
            if(elem==true)
            {
              PickDateorderOverview.getText().then((text )=>{
              var date=text.split(" ");
              var PickupDate=date[0];
              var pickupTime=date[1];
               if(PickupDate==AppointmnetDatepickup){
                console.log("Pickup Appointment details and Time zone in Order overview  is same as the appointment date while creating the order "+ text);
               }
                                            })
            }
          });
         DelidateorderOverview.isPresent().then((elem)=>{
          if(elem==true)
          {
            DelidateorderOverview.getText().then((text )=>{
              var date=text.split(" ");
              var Deliverydate=date[0];
              var DeliveryTime=date[1];
             if(Deliverydate==appointmentdateDelivery){
              console.log("Delivery Appointment details and Time Zone in Order overview is same as the appointment date while creating the order "+ text);
             }
                                          })
          }
       });
        }
  /*********************************************************************
	 * 
	* MethodName:  AddContact
	* Description: To Add the Bill TO Contact
	* Parameter (if any):  NIL
	* Return type:  Void
	 ********************************************************************/                 
   AdvancedSearchforOrder(OrderNo:number,PickupDate,Deliverydate,OrderStatus:string) {  
    // this.NavigatefromDashboard("Advanced Search");     
   // browser.sleep(3000);
   //common.ElementWait(true,allOptions);
   // var allOptions =element.all(by.xpath("//*[@class='inline']//ng-select[@placeholder='Type'][1]"))
   allOptions.isPresent().then((elem)=>{ 
    if (elem===true){   
      reuse.ClickElement(acceptclose,"Click the close icon fro already available status")   
      reuse.EnterValue(txt_OrderNumber,OrderNo,"Order Number of the created order")
      browser.executeScript("window.scrollTo(0,-200)");   
  //  reuse.ClickElement(Showmore,"Click on more button")   
  //   browser.executeScript("window.scrollTo(0,-200)");        
  //   browser.sleep(3000);
  //   //  Statuschange.sendKeys(OrderStatus);
  //   //  Statuschange.sendKeys(protractor.Key.ENTER);
  //         browser.executeScript("window.scrollTo(0,300)");           
  //         // reuse.ClickElement(Destin,"Click on Destin ") 
  //            // reuse.ClickElement(dd_bu,"Click on Destin ") 
  //            // dd_bu.sendKeys(protractor.Key.TAB);
  //            var a1= element(by.xpath("//div[@class='panel panel-default searchFilterPanel parentContainerHeight']"))
  //           // reuse.ClickElement(Showmore,"Click Showmore");
  //            browser.executeScript("window.scrollTo(0,-2000)"); 
  //            browser.sleep(3000);
  //            reuse.ClickElement(a1,"Click a1");
  //            for(var i=0; i<18; i++)
  //            {
  //             a1.sendKeys(protractor.Key.ARROW_DOWN);
  //            }
          
  //            browser.sleep(3000);
  //           // reuse.ClickElement(BUSelector,"Click BUSelector");
          
  //  //   ordertype.click();
  //  // browser.executeScript("window.scrollTo(0,200)"); 
  //  browser.sleep(4000);
          reuse.ClickElement((allOptions.get(2)),"Click on Destin ") 
  //        browser.sleep(2000); 
  //       var ind=0
  //         allOptions.count().then(function(total) {      
  //         allOptions.each(function (item) {    
  //       ind++
  //      if(ind==2) { 
  //        console.log("index no is"+ind)         
  //          item.sendKeys("order number");
  //          browser.sleep(4000); 
  //          item.sendKeys(protractor.Key.TAB);
  //          item.sendKeys(protractor.Key.TAB);
  //          item.sendKeys(protractor.Key.TAB);
  //          item.sendKeys(protractor.Key.ENTER);        
           
  //      }else 
  //        console.log("View drop down is not available with the values");
  //      });
      
  //    });
  
  //   var ind1=0
  //   browser.sleep(3000);

  //     orderno.count().then(function(total) {            
  //       orderno.each(function (item) {  
  //       console.log(ind1) 
  //       ind1++      
  //      if(ind1==3) {          
  //          item.sendKeys(OrderNo);
  //          browser.sleep(3000);            
  //      }else 
  //        console.log("View drop down is not available with the values");
  //      });
  //    });
     reuse.ClickElement(SearchButton,"Click on SearchButton ")   
    browser.executeScript("window.scrollTo(0,-200)");
    this.ElementValidationAdvancedsearch(PickupDate,Deliverydate);
     reuse.ClickElement( (SelectFirstorder.get(0)),"Click on SelectFirstorder ") 
     browser.sleep(3000);  
    //var viewpage=element(by.xpath("//span[text()='Order']"));
//common.ElementWait(true,viewpage);
    }
  });
  }
 /*****************************************************************************************
	 * 
	* MethodName:  SelectFirstorder
	* Description: To Select the first order from the list of orders displaye din Advanced search results
	* Parameter (if any):  Scheduled,pickupdate,Ordername
	* Return type:  Void
	 ***************************************************************************************/   
    
    
  SelectFirstorder(){
    SelectFirstorder.isPresent().then((elem)=>{ 
      if (elem===true){ 
      reuse.ClickElement((SelectFirstorder.get(0)),"Click the firstorder from the results list ") 
      browser.sleep(4000);
    var viewpage=element(by.xpath("//span[text()='Order']"));
   // this.ElementWait(true,viewpage);
    }
  });
}
/***************************************************************************************************
	* MethodName:  AdvancedSearchByOrderStatus
	* Description: To Search an order by selecting the order status(Accepted,Pending,etc.)
	* Parameter (if any):  NIL
	* Return type:  Void
	 *************************************************************************************************/                 
  AdvancedSearchByOrderStatus(Testcasename) {  
    var TcRow=ReadFromXL.FindRowNum(Testcasename,"CreateOrder");
    DataDictLib.pushToDictionaryWithSheet(TcRow,"CreateOrder");
    var orderStatus =DataDictLib.getFromDictionary('OrderStatus');

   common.ElementWait(true,allOptions);   
   allOptions.isPresent().then((elem)=>{ 
    if (elem===true){   
      reuse.ClickElement(acceptclose,"Click the close icon fro already available status")      
   reuse.ClickElement(txt_orderStatus,"Click on Orderstatus drop down")  
   reuse.EnterValue(txt_orderStatus,orderStatus,"orderStatus value")   
    browser.executeScript("window.scrollTo(0,-200)");        
    browser.sleep(2000);
  } 
   });
  }
 

AdvancedSearchOrder(OrderStatus,BU,SO:string) {  
  common.NavigatefromDashboard("Advanced Search");     
  
   common.ElementWait(true,  allOptions);
   reuse.ClickElement(acceptclose,"Click acceptclose");
   reuse.EnterValue(Statuschange,"I","Statuschange value") 
   Statuschange.sendKeys(protractor.Key.ENTER);
   
   var a1= element(by.xpath("//div[@class='panel panel-default searchFilterPanel parentContainerHeight']"))
   reuse.ClickElement(Showmore,"Click Showmore");
   browser.executeScript("window.scrollTo(0,-2000)"); 
   browser.sleep(3000);
   reuse.ClickElement(a1,"Click a1");
   for(var i=0; i<18; i++)
   {
    a1.sendKeys(protractor.Key.ARROW_DOWN);
   }

   browser.sleep(3000);
   reuse.ClickElement(BUSelector,"Click BUSelector");
         
         browser.sleep(3000);
          var BUID =element(by.xpath("//div[contains(text(),'Business Unit')]//following::ul//li//div//a//div[contains(text(),'"+BU+"')]"));  
          browser.sleep(3000);
          reuse.ClickElement(BUID,"Click BUID");
          browser.sleep(3000);
          reuse.ClickElement(SOSelector,"Click SOSelector");
          browser.sleep(3000);
          var SOID =element(by.xpath("//div[contains(text(),'Service Offering')]//following::ul//li//div//a//div[contains(text(),'"+SO+"')]"));
          browser.sleep(3000);
          reuse.ClickElement(SOID,"Click SOID");
          browser.sleep(3000);
          
 
     SearchButton.click();  
     reuse.ClickElement(SOID,"Click SOID");  
     browser.executeScript("window.scrollTo(0,-200)");
     SelectFirstorder.get(0).click(); 
    var viewpage=element(by.xpath("//span[text()='Order']"));
    common.ElementWait(true,viewpage);
 }
        
/***************************************************************************************************
	* MethodName:  AdvancedSearchByOrderStatus
	* Description: To Search an order by selecting the order status(Accepted,Pending,etc.)
	* Parameter (if any):  NIL
	* Return type:  Void
	 *************************************************************************************************/                 
  AdvancedSearchByBUSO(Testcasename,BU:string,SO:string) {  
    var TcRow=ReadFromXL.FindRowNum(Testcasename,"CreateOrder");
    DataDictLib.pushToDictionaryWithSheet(TcRow,"CreateOrder");
    //var BU =DataDictLib.getFromDictionary('BU');
   //common.ElementWait(true,allOptions);   
   //allOptions.isPresent().then((elem)=>{ 
    //if (elem===true){   
      reuse.ClickElement(acceptclose,"Click the close icon fro already available status")      
      reuse.ClickElement(Showmore,"Click on more button")   
       browser.executeScript("window.scrollTo(0,-200)");        
       browser.sleep(2000);
             browser.executeScript("window.scrollTo(0,200)"); 
             var a1= element(by.xpath("//div[@class='panel panel-default searchFilterPanel parentContainerHeight']"))
                       // reuse.ClickElement(Showmore,"Click Showmore");
                        browser.executeScript("window.scrollTo(0,-2000)"); 
                        browser.sleep(3000);
                        reuse.ClickElement(a1,"Click a1");
                        for(var i=0; i<18; i++)
                        {
                         a1.sendKeys(protractor.Key.ARROW_DOWN);
                        }                     
                        browser.sleep(3000);
                        reuse.ClickElement(dd_bu,"Click BUSelector");
                        browser.sleep(1000);      
                      //reuse.ClickElement(dd_bu,"Click BUSelector");
                      dd_BUValue.sendKeys("JBT")
            // reuse.EnterValue(dd_bu,"JBT","Enter requested Services") 
             dd_bu.sendKeys(protractor.Key.ENTER);
             browser.sleep(2000)
             dd_bu.sendKeys(protractor.Key.TAB);
             dd_so.sendKeys(protractor.Key.ENTER);
             browser.sleep(1000); 
            // reuse.ClickElement(dd_so,"Click Service Offering drop down")
             reuse.EnterValue(dd_so,"OTR","Enter requested Services") 
             dd_so.sendKeys(protractor.Key.ENTER);
  } 
//   else{

// console.log("Advanced search page is not displayed as expected")

//   }
//    });
//   } 
  

    
                           

}
      
      
      
      
      

 
      
























