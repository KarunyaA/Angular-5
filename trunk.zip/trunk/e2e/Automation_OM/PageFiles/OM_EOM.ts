import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";
import {Update_Objects} from "../ObjectRepository/Objects_Order"
import { Key, WebElement } from "selenium-webdriver";

import {ExcelReader} from "../CommonFiles/ReadFromXL"

import {DataDictionary} from "../DataFiles/DictionaryData"

import {CommonFunctions} from "../FunctionalLibrary/CommonFunctions"
import {ReusableFunctions} from "../FunctionalLibrary/ReusableFunctions" 
let reuse= new ReusableFunctions();
var Loadid =    element(by.id("eomSearchMain:baseSearchVal"));
//var loadlink= element(by.id("frmOrderListing:lOrderListing:0:optxtOrderNumberActionFocusLink"));
var loaddetail=element(by.id("eomOrderDetail:orderDetailminimizer"));
var stopdetails=element(by.id("eomOrderDetail:nonStopsminimizer"));
var BUdivision=element(by.xpath("//*[@id='eomOrderDetail:divisionlist']/option[@selected='selected']"));
var Billtovaleom = element(by.id("eomOrderDetail:billto"));
var mileeom = element(by.id("eomOrderDetail:ttlMiles"));
var DictBU_OM = new DataDictionary();
var DictBU_EOM = new DataDictionary(); 

export class EOMFunctions {



async FetchDatafromEOM(){
    
          
          var BU;
           var BillTO;
          var mile;
    
          await reuse.getTextValueFromElement(BUdivision).then((text)=>{          
            BU = text 
          }) ;
          console.log("Inside function" + BU);
    
         await  Billtovaleom.getAttribute("value").then((text)=>{          
            BillTO = text 
         }) ;
         
          console.log("Inside function" + BillTO);
          
          await reuse.getTextValueFromElement(mileeom).then((text)=>{
            mile = text  
          }) ;
          console.log("Inside function" + mile);
    
          DictBU_EOM["BusUnit"] = BU;
          DictBU_EOM["Billto"] = BillTO;
          DictBU_EOM["totalmile"] = mile;
    
          return DictBU_EOM
    
         }
    
         NavigateEOM(LoadID){
          
               // Loadid.click();
                 Loadid.sendKeys("LS44436");
                 Loadid.sendKeys(protractor.Key.ENTER);
                browser.sleep(5000);
                //var visor = element(by.xpath("//*[@id='loadingCover2']"))
                // visor.isPresent().then((elem)=>{
                //   if (elem == true)
                //   {
                //     console.log("This is shit")
                //     browser.sleep(20000)
                //     loadlink.click();


                //   }
                //   else {
                //     loadlink.click();
                //   }
                  

                // })
                browser.sleep(1000);
                var loadlink = element(by.xpath("//td[@class='listTdClass']//span//a[text()='LS44436']"));
                 //loadlink.click();
               //  reuse.SACElement(loader,"loader");
               reuse.SACElement(loadlink,"loadlink")
                
                 //loadlink.click();
                browser.sleep(3000);
          
                 
                 reuse.SACElement(loaddetail,"loaddetail")
                browser.sleep(3000);
                 
                 reuse.SACElement(stopdetails,"stopdetails")
                browser.sleep(3000);
          
              
          
               }
            }