import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";
import { Update_Objects } from "../ObjectRepository/Objects_Order"
import { Key, WebElement, WebDriver } from "selenium-webdriver";

import { ExcelReader } from "../CommonFiles/ReadFromXL"

import { DataDictionary } from "../DataFiles/DictionaryData"
import  { ReusableFunctions }  from  "../FunctionalLibrary/ReusableFunctions"


var  DictBU_OM  =  new  DataDictionary();
var  DictBU_EOM  =  new  DataDictionary();
var OrderID;
let  OBJCreate  = new Update_Objects();
var ReadFromXL = new ExcelReader();
var DataDictLib = new DataDictionary();
var DataDictLib1 = new DataDictionary();
let reuse = new ReusableFunctions();
var ExcelDataSourceForConf = require('../CommonFiles/ReadFromXL');
var PushAndPullDataDictLib = require('../DataFiles/DictionaryData');

export class MonitoringFunctions{

   
    MonitoringException() { 
        var EC = protractor.ExpectedConditions; 
       
       
      OBJCreate.UserNameExpandicon.click();
                          
        OBJCreate.Searchname.sendKeys("Sri Ragavi");
         browser.sleep(2000);
         OBJCreate.Searchname.sendKeys(protractor.Key.ENTER);
        OBJCreate.Searchname.sendKeys("Jyothi Asipu");
         browser.sleep(5000);
         OBJCreate.Searchname.sendKeys(protractor.Key.ENTER);
         browser.sleep(2000);
          OBJCreate.MonitoringDropdown.click();
          
         browser.sleep(5000);
         browser.wait(EC.invisibilityOf(OBJCreate.Excepdata), 5000).then(function() {
          (OBJCreate.ExpandIcon.get(0)).isPresent().then(function(bool){
          if(bool === true){
        console.log("Exceptions are available in the Exceptions screen")
        // browser.executeScript("window.scrollBy(-2000,0)");
        //OBJCreate.ExpandIcon.get(0).click();
        //browser.sleep(3000);
        // OBJCreate.VieworderIcon.click();
        //browser.sleep(3000);
        }
        });
        });
                                              //console.log(OBJCreate.MonitoringDropdown.count())
                                              //  var index=0;
                                              // OBJCreate.MonitoringDropdown.count().then(function(total) {
                                              //   OBJCreate.MonitoringDropdown.each(function (item) {
                                              //      index++;
                                              //      if(total > index) {
                                              //       item.getText().then((elem)=>{
                                                      
                                              //         if (elem===monitoringOption)
                                              //         {
                                              //           item.click();
                                              //          browser.sleep(5000);
                                              //         }
                                              //         });
                                                    
                                              //      }else 
                                              //       console.log("Page is not loaded properly")
                                              //      });
                                              //    });
                                                                                      
       }

       
       Task_Select(Testcasename){
        var TcRow = ReadFromXL.FindRowNum(Testcasename, "CommonData");
        DataDictLib.pushToDictionaryWithSheet(TcRow, "CommonData");
        var taskValue =DataDictLib.getFromDictionary('CreateTitle');
        var  Task_Dropdown=element(by.xpath("//select[@class='dropdown mar-bot10']//following::option[@value='"+taskValue+"']"));
        Task_Dropdown.click();
       }

      SelectFirstorder() {
        var SelectFirstorder = element.all(by.xpath("//*[@class='datatable-row-wrapper'][1]"));


        SelectFirstorder.isPresent().then((elem) => {
          if (elem === true) {
            reuse.ClickElement((SelectFirstorder.get(0)), "Click the firstorder from the results list ")
            browser.sleep(3000);

          }

          
        });
      }

      Scroll_Down(){
      browser.executeScript("window.scrollBy(0,500)");
      }
      Scroll_Upp(scroll_value:number){
        browser.executeScript("window.scrollBy(0,-"+scroll_value+")");
        }
        Scroll_Up(){
          browser.executeScript("window.scrollBy(0,-2000)");
          }

     
        Filter_Search(Order_ID:string){
          var IDOrd = Order_ID;
          var template_filter=element(by.id("spn-filter"));
          var order_filter=element(by.xpath("//div[@class='panel panel-default panelshadow']//span[text()='Order Number ']"));
          var order_Search=element(by.xpath("//div[@class='panel panel-default panelshadow']//span[text()='Order Number ']//following::input[@id='fltSearchTxt'][1]"));
          var icon_Search=element(by.xpath("//div[@class='panel panel-default panelshadow']//span[text()='Order Number ']//following::input[@id='fltSearchTxt'][1]//following::a[@id='a-searchCallonClick']"));
          
          browser.sleep(1000);
          

                reuse.ClickElement(template_filter,"Click Template filter icon");
                browser.sleep(1000);
                reuse.SAClickElement(order_filter,"Click order_Search from the list");
                reuse.ClickElement(order_Search,"Click order_Search from the list");
                order_Search.sendKeys(Order_ID);
                reuse.ClickElement(icon_Search,"Click icon_Search");
                this.Scroll_Up();

                
                reuse.ClickElement((template_filter), "Click the template_filter ")
                
         }

         Error_Overide()
         {
          var errorparent=element.all(by.xpath("//div[@class='errorContainer col-md-10 mar-top20']//div[@class='message-container']//ul//li"));
          var index = 0;
          var save_btn= element(by.id("btn-contine"));
          var errorlink = element(by.xpath("//div[@class='message-container']//span[@id='span-3dots']"));
          var errorlinkname = element(by.css("[id='preferedName']"));
          var OverideErrorButton = element(by.buttonText("Override"));
          var Overideall=element(by.xpath("//a[@id='a-overRideAll']"));
          errorparent.isPresent().then((element) => {
            if (element === true) {
              errorparent.count().then(function (total) {
                errorparent.each(function (item) {
                  index++;
                  if (total >= index) {
                   
                    (errorparent).get(0).isDisplayed().then((element) => {
                      if (element === true) {
                        
                        
                        errorparent.isPresent().then((element) => {
                          if (element === true) 
                          {
                          errorlink.click();
                          (errorlinkname).isPresent().then(function (bool) {
                            if (bool === true) {
                              errorlinkname.sendKeys("Keerthana Selvaraj");
                              browser.sleep(2000);
                              errorlinkname.sendKeys(protractor.Key.ENTER);
                              reuse.SAClickElement(OverideErrorButton, "Click Override button");
                            }
                          });
                          
            }
          });
        }
        });
        }
        });
      });
    }
    else
      console.log("No errors are available")
  });
  Overideall.isPresent().then((element) => {
    if (element === true) 
    {
  reuse.ClickElement(Overideall,"Overideall");
  reuse.SAClickElement(save_btn,"Click save_btn")
    }
    else
    console.log("No Overideall are available")
  });

}


      SelectFirstinstance(Order_ID:string) {
        
        var SelectFirstorder = element(by.xpath("//*[@class='datatable-row-wrapper']//preceding::span[contains(@title,'"+Order_ID+"')]//.."));
       
        browser.sleep(3000);

        SelectFirstorder.isPresent().then((elem) => {

         
          if (elem === true) {
            browser.sleep(10000);
            reuse.ClickElement((SelectFirstorder), "Click the First instance from the results list ")
            
            browser.sleep(3000);
          }
          if (elem === false) {
            browser.driver.navigate().refresh();
          
          }
          });
      }

      // check()
      // {
      //   // By loadingImage = By.id("loading image ID");

      //   // WebDriverWait wait = new WebDriverWait(driver, timeOutInSeconds);

      //   // wait.until(ExpectedConditions.invisibilityOfElementLocated(loadingImage));

      //   // var loadingImage = by.id("");
      //   // browser.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(7);
      // }
    
      iscroll(n:number)
      {
        var tablecontent = element(by.xpath("//div[@class='tab-content']"));
                   browser.executeScript("window.scrollTo(0,-2000)"); 
                   browser.sleep(3000);
                   reuse.ClickElement(tablecontent,"Click tablecontent");
                   for(var i=0; i<n; i++)
                   {
                    tablecontent.sendKeys(protractor.Key.ARROW_DOWN);
                   }
          
        
 
      }
      radio_Click(Contact_Type:string){
        browser.sleep(5000);
        var tableradio = element.all(by.xpath("//td[text()[contains(.,'"+Contact_Type+"')]]/..//input"));

        tableradio.get(0).isPresent().then((elem) => {
          if (elem === true) {
            browser.sleep(1000);
            reuse.ClickElement(tableradio.get(0), "Click the firstradio from the results list ")
            browser.sleep(1000);
            var Main1 = element(by.xpath("//div[@class='main']"));
            reuse.ClickElement(Main1, "Click the Main1 ")

      }

        });

      }
      SetAppnt(){
        var SetAppnt_Link = element(by.xpath("//li[@class='nav-item']//span[text()='Set Appointment']"));

        SetAppnt_Link.isPresent().then((elem) => {
          if (elem === true) {
            reuse.ClickElement(SetAppnt_Link, "SetAppnt_Link")
            browser.sleep(3000);
          }

        });

      }
      Email_Click(){
        var Email_Butn = element(by.id("btn-email"));

        Email_Butn.isPresent().then((elem) => {
          if (elem === true) {
            reuse.ClickElement(Email_Butn, "EmailButton")
            browser.sleep(3000);

      }

        });

      }

      appoinment_MailFun()
      {
       var ReasonCateg = element.all(by.xpath("//*[@id='appntReasonCateg']"));
       var ReasonSetting = element(by.xpath("//*[@id='appntReasonSetting' or @id='appointmentReasonCode' ]"));
       var mailTo = element(by.xpath("//*[@id='sel-mailTo']"));
       reuse.ClickElement(ReasonCateg.get(1), "Click the ReasonCateg")
       ReasonCateg.get(1).sendKeys("Amazon");
       ReasonCateg.get(1).sendKeys(protractor.Key.ENTER);
       browser.sleep(5000);
       reuse.ClickElement(ReasonSetting, "Click the ReasonSetting")
       ReasonSetting.sendKeys("Nc-Shipment Delayed-Unable To Locate");
       ReasonSetting.sendKeys(protractor.Key.ENTER);
       browser.sleep(1000);
       reuse.ClickElement(mailTo, "Click the mailTo")
       mailTo.sendKeys(protractor.Key.TAB);
       mailTo.sendKeys(protractor.Key.ENTER);
      //  var mailTo_Id = element.all(by.xpath("//*[@class='dropdown-item']"));
      //  reuse.ClickElement(mailTo_Id.get(1), "Click the mailTo_Id")
       browser.executeScript("window.scrollBy(0,500)");
       browser.sleep(3000);
      //  ReasonSetting.sendKeys("Nc-Shipment Delayed-Unable To Locate");
      //  ReasonSetting.sendKeys(protractor.Key.ENTER);
      reuse.ClickButtonwithText("Send");
       

      }

      appoinment_Fun()
      {
       var ReasonCateg = element(by.xpath("//*[@id='appntReasonCateg']"));
       var ReasonSetting = element(by.xpath("//*[@id='appointmentReasonCode']"));
       var save_btn= element(by.id("btn-contine"));
       
       reuse.ClickElement(ReasonCateg, "Click the ReasonCateg")
       ReasonCateg.sendKeys("Amazon");
       ReasonCateg.sendKeys(protractor.Key.ENTER);
       browser.sleep(5000);
       reuse.ClickElement(ReasonSetting, "Click the ReasonSetting")
       ReasonSetting.sendKeys("Nc-Shipment Delayed-Unable To Locate");
       ReasonSetting.sendKeys(protractor.Key.ENTER);
       browser.sleep(1000);
       
      reuse.SAClickElement(save_btn,"Click save_btn")
      }


    }