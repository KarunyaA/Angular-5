import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";
import { Update_Objects } from "../ObjectRepository/Objects_Order"
import { Key, WebElement } from "selenium-webdriver";
import { ExcelReader } from "../CommonFiles/ReadFromXL"
import { DataDictionary } from "../DataFiles/DictionaryData"
import { ReusableFunctions } from "../FunctionalLibrary/ReusableFunctions"
import { CommonFunctions } from "../FunctionalLibrary/CommonFunctions"
var common = new CommonFunctions()
var DictBU_OM = new DataDictionary();
var DictBU_EOM = new DataDictionary();
var OrderID;
let OBJCreate = new Update_Objects();
var ReadFromXL = new ExcelReader();
var DataDictLib = new DataDictionary();
var DataDictLib1 = new DataDictionary();
let reuse = new ReusableFunctions();
var ExcelDataSourceForConf = require('../CommonFiles/ReadFromXL');
var PushAndPullDataDictLib = require('../DataFiles/DictionaryData');

var overflowmenu = element(by.xpath("//*[@class='pull-right icon-jbh_three-dots mar-top20 mar-left10 font24 cursor-pointer']"));
//var tonunavigation = element(by.xpath("//*[@class='popover in popover-bottom']//following::span[text()='Process Truck Order Not Used']"));
var tonunavigation = element(by.linkText("Process Truck Order Not Used"));
var KeepOrderActivetab = element(by.id("a-keepOrder"));
var CompleteOrdertab = element(by.id("a-compltOrdr"));
var Standardradiobutton = element(by.id("ipRadioStdContractRate"));
var Negotitated = element(by.id("ipRadioNegotiatedFee"));
var Waive = element(by.id("ipRadioWaiveFee"));
var Chargetxt = element(by.id("txtAmountinDollar"));
var SetnewAppt = element(by.id("ipRadioSetNewAppointment"));
var ContinuewithoutNewAppointment = element(by.id("ipRadioContinueNewAppointment"));
var Apptreasoncatedrpdwn = element(by.xpath("//span[text()='Appointment Reason Category']"));
var RsnforApptdrpdwn = element(by.xpath("//span[text()='Reason for Setting this Appointment']"));
var Tonucomments = element(by.id("txtAreaComment"));
var processbtn = element(by.id("btn-tonuProcess"));
var startdate = element.all(by.xpath("//*[@class='mydpicon icon-mydpcalendar']"));
var selectstartdate = element(by.xpath("//div[@class='datevalue currmonth']//span[text()='16']"));
var starttimehrs = element(by.xpath("//*[@formcontrolname ='tonuChangeAppointmentStartTime']//tr[2]//td[1]"));
var selectenddate = element(by.xpath("//div[@class='datevalue currmonth']//span[text()='17']"));
var tonusuccessmsg = element(by.xpath("//*[contains(text(),'Process Truck Order Not Used Charges Complete!')]"));
var Gotitsucessmsfbtn = element(by.id("btn-gotIt"));
var failtoqlfymsg = element(by.xpath("//*[text()='Failed to Qualify']"));
var gotitfailqlfy = element.all(by.xpath("//*[@id='btn-confirm']"));
var cancelfailqlfy = element.all(by.xpath("//*[@id='btn-goBack']"));
var withoutnewappt = element(by.id("ipRadioContinueNewAppointment"));

export class TonuReconsign{






TonuKeepOrderActivestd(Testcase){
    
          var TcRow=ReadFromXL.FindRowNum(Testcase,"TONU");
          DataDictLib.pushToDictionaryWithSheet(TcRow,"TONU");
          var OptionalCmts =DataDictLib.getFromDictionary('Comments');
    
          reuse.ClickElement(withoutnewappt, "Click on withoutnewappt radio button");
            browser.sleep(1000);
    
            reuse.EnterValue(Tonucomments,OptionalCmts,"Comments" );
            browser.sleep(1000);
    
            reuse.ClickElement(processbtn, "Click on Process button in Tonu screen");
            browser.sleep(5000);
         
    
        }
    
        TonuKeepOrderActiveWaive(Testcase){
    
          var TcRow=ReadFromXL.FindRowNum(Testcase,"TONU");
          DataDictLib.pushToDictionaryWithSheet(TcRow,"TONU");
          var AppointmentReasonCategory=DataDictLib.getFromDictionary('AppointmentReasonCategory');
          var ReasonsettingforAppt =DataDictLib.getFromDictionary('ReasonsettingforAppt');
          var OptionalCmts =DataDictLib.getFromDictionary('Comments');
          var Apptreasoncatedrpdwnvalue = element(by.xpath("//div[contains(text(),'"+AppointmentReasonCategory+"')]"));
          var RsnforApptdrpdwnval = element(by.xpath("//div[contains(text(),'"+ReasonsettingforAppt+"')]"));
    
          reuse.ClickElement(KeepOrderActivetab, "Click on Keep order Active");
          browser.sleep(4000);
    
         // reuse.ClickElement(CompleteOrdertab, "Click on Complete order tab");
         // browser.sleep(2000);
          
         reuse.ClickElement(Waive, "Click on waive radio button");
         browser.sleep(1000);
    
          reuse.ClickElement(SetnewAppt, "Click on set new Appt radio button");
          browser.sleep(2000);
    
          //Calender
          //start Date and Time
          common.Selectcalendericon("17/Mar/2018",0);
          //common.SelectTime("08:00", 0);
          
          //End Date and Time
          common.Selectcalendericon("18/Mar/2018",1);
          
          reuse.ClickElement(Apptreasoncatedrpdwn, "Click on Appt reason category dropdown button");
          browser.sleep(2000);
    
          reuse.ClickElement(Apptreasoncatedrpdwnvalue, "Click on Appt reason category dropdown value");
          browser.sleep(2000);
    
          reuse.ClickElement(RsnforApptdrpdwn, "Click on Reason for Setting this Appointment dropdown");
          browser.sleep(4000);
    
          reuse.ClickElement(RsnforApptdrpdwnval, "Click on Reason for Setting this Appointment dropdown value");
          browser.sleep(2000);
    
          reuse.ClickElement(Tonucomments, "Click on Reason for Setting this Appointment dropdown value");
          browser.sleep(2000);
    
          reuse.EnterValue(Tonucomments,OptionalCmts,"Comments" );
          browser.sleep(1000);
    
          reuse.ClickElement(processbtn, "Click on Process button in Tonu screen");
          browser.sleep(5000);
    
        }
    
        TonuKeepOrderActiveNeg0(Testcase){
    
          var TcRow=ReadFromXL.FindRowNum(Testcase,"TONU");
          DataDictLib.pushToDictionaryWithSheet(TcRow,"TONU");
          var AppointmentReasonCategory=DataDictLib.getFromDictionary('AppointmentReasonCategory');
          var ReasonsettingforAppt =DataDictLib.getFromDictionary('ReasonsettingforAppt');
          var OptionalCmts =DataDictLib.getFromDictionary('Comments');
          var Apptreasoncatedrpdwnvalue = element(by.xpath("//div[contains(text(),'"+AppointmentReasonCategory+"')]"));
          var RsnforApptdrpdwnval = element(by.xpath("//div[contains(text(),'"+ReasonsettingforAppt+"')]"));
    
          reuse.ClickElement(KeepOrderActivetab, "Click on Keep order Active");
          browser.sleep(4000);
    
         // reuse.ClickElement(CompleteOrdertab, "Click on Complete order tab");
         // browser.sleep(2000);
          
         reuse.ClickElement(Negotitated, "Click on waive radio button");
         browser.sleep(1000);
    
          reuse.ClickElement(SetnewAppt, "Click on set new Appt radio button");
          browser.sleep(2000);
    
          //Calender
          //start Date and Time
          common.Selectcalendericon("17/Mar/2018",0);
          //common.SelectTime("08:00", 0);
          
          //End Date and Time
          common.Selectcalendericon("18/Mar/2018",1);
          
          reuse.ClickElement(Apptreasoncatedrpdwn, "Click on Appt reason category dropdown button");
          browser.sleep(2000);
    
          reuse.ClickElement(Apptreasoncatedrpdwnvalue, "Click on Appt reason category dropdown value");
          browser.sleep(2000);
    
          reuse.ClickElement(RsnforApptdrpdwn, "Click on Reason for Setting this Appointment dropdown");
          browser.sleep(4000);
    
          reuse.ClickElement(RsnforApptdrpdwnval, "Click on Reason for Setting this Appointment dropdown value");
          browser.sleep(2000);
    
          reuse.ClickElement(Tonucomments, "Click on Reason for Setting this Appointment dropdown value");
          browser.sleep(2000);
    
          reuse.EnterValue(Tonucomments,OptionalCmts,"Comments" );
          browser.sleep(1000);
    
          reuse.ClickElement(processbtn, "Click on Process button in Tonu screen");
          browser.sleep(5000);
    
        }
    
        TonucompleteOrderstd(Testcase){
    
          var TcRow=ReadFromXL.FindRowNum(Testcase,"TONU");
          DataDictLib.pushToDictionaryWithSheet(TcRow,"TONU");
          var OptionalCmts =DataDictLib.getFromDictionary('Comments');
          
         reuse.ClickElement(CompleteOrdertab, "Click on Complete order tab");
         browser.sleep(2000);
          
          reuse.ClickElement(Standardradiobutton, "Click on Standard radio button");
          browser.sleep(2000);
    
          reuse.ClickElement(Tonucomments, "Click on Reason for Setting this Appointment dropdown value");
          browser.sleep(2000);
    
          reuse.EnterValue(Tonucomments,OptionalCmts,"Comments" );
          browser.sleep(1000);
    
          reuse.ClickElement(processbtn, "Click on Process button in Tonu screen");
          browser.sleep(6000);
    
          
          }
    
          TonucompleteOrderwaive(Testcase){
    
            var TcRow=ReadFromXL.FindRowNum(Testcase,"TONU");
            DataDictLib.pushToDictionaryWithSheet(TcRow,"TONU");
            var OptionalCmts =DataDictLib.getFromDictionary('Comments');
            
           reuse.ClickElement(CompleteOrdertab, "Click on Complete order tab");
           browser.sleep(2000);
            
            reuse.ClickElement(Waive, "Click on Standard radio button");
            browser.sleep(2000);
      
            reuse.ClickElement(Tonucomments, "Click on Reason for Setting this Appointment dropdown value");
            browser.sleep(2000);
      
            reuse.EnterValue(Tonucomments,OptionalCmts,"Comments" );
            browser.sleep(1000);
      
            reuse.ClickElement(processbtn, "Click on Process button in Tonu screen");
            browser.sleep(6000);
      
      
            
            }
    
            TonucompleteOrdernego(Testcase){
    
              var TcRow=ReadFromXL.FindRowNum(Testcase,"TONU");
              DataDictLib.pushToDictionaryWithSheet(TcRow,"TONU");
              var OptionalCmts =DataDictLib.getFromDictionary('Comments');
              
             reuse.ClickElement(CompleteOrdertab, "Click on Complete order tab");
             browser.sleep(2000);
              
              reuse.ClickElement(Negotitated, "Click on Standard radio button");
              browser.sleep(2000);
        
              reuse.ClickElement(Tonucomments, "Click on Reason for Setting this Appointment dropdown value");
              browser.sleep(2000);
        
              reuse.EnterValue(Tonucomments,OptionalCmts,"Comments" );
              browser.sleep(1000);
        
              reuse.ClickElement(processbtn, "Click on Process button in Tonu screen");
              browser.sleep(6000);
        
        
              
              }
        
      
    
    
    
          Processbtnaction(){
            console.log("Entering into Function")
    
            if(failtoqlfymsg.isPresent)
            {
              console.log("fail to QLF");
              //reuse.ClickElement(gotitfailqlfy.get(1), "Click on got it button from fail to QLF popup");
              //ORDShipping.CreateWithoutRate();
            }
            else if(tonusuccessmsg.isPresent)
            {
              console.log("Success to QLF");
             reuse.ClickElement(Gotitsucessmsfbtn.get(1), "Click on got it button from TONU completed popup");
    
            }
          }
          NavigateTonu(){
            
                  reuse.ClickElement(overflowmenu, "Click overflow menu view order detail");
                  browser.sleep(5000);
                  reuse.ClickElement(tonunavigation, "Click on TONU");
                  browser.sleep(20000);
            
                 }
            
        }