import { ElementFinder, browser, by, element } from "protractor";
//import { protractor } from "protractor/built/ptor";
import {Update_Objects} from "../ObjectRepository/Objects_Order"
import { Key, WebElement } from "selenium-webdriver";
import * as protractor from 'protractor'; 
import {ExcelReader} from "../CommonFiles/ReadFromXL"

import {DataDictionary} from "../DataFiles/DictionaryData"
import {ReusableFunctions} from "../FunctionalLibrary/ReusableFunctions" 
import {CommonFunctions} from "../FunctionalLibrary/CommonFunctions"
var common= new CommonFunctions() 
var DictBU_OM = new DataDictionary();
var DictBU_EOM = new DataDictionary(); 
var OrderID;
let OBJCreate = new Update_Objects();
var ReadFromXL = new ExcelReader();
var DataDictLib = new DataDictionary();
var DataDictLib1 = new DataDictionary();
let reuse= new ReusableFunctions();
var ExcelDataSourceForConf = require('../CommonFiles/ReadFromXL');
var PushAndPullDataDictLib = require('../DataFiles/DictionaryData');
var allOptions =element.all(by.xpath("//*[@class='inline']//ng-select[@placeholder='Type'][1]")) 
var Statuschange=element(by.xpath("//*[@formcontrolname='orderSearchStatus']//following::input"));
var acceptclose=element(by.xpath("//*[@formcontrolname='orderSearchStatus']//following::a")); 
var orderno=element.all(by.xpath("//*[@placeholder='Name']")); 
var apnmt_ordovrview    =element(by.xpath("//div[text()='Scheduled Appointment ']//following::span[1]/span[1]"));
var apnmt_stop          =element(by.xpath("//span[text()='Origin']//following::span[@class='pad0 font-styles'][1]"));
var ApntdatepickupAdvanced=element(by.xpath("//datatable-body-cell[@class='datatable-body-cell sort-active'][4]/div/h6/p[1]"));
var ApntdatedeliveryAdvanced=element(by.xpath("//datatable-body-cell[@class='datatable-body-cell sort-active'][5]/div/h6/p[1]"));
var PickDateorderOverview=element(by.xpath("//div[text()='Scheduled Appointment']//following::span[1]"));
var DelidateorderOverview=element(by.xpath("//div[text()='Scheduled Appointment']//following::span[2]"));
var Showmore=element(by.css("[id='orderSearchShowMore']"));
var Destin =element(by.css("[placeholder='Destination Marketing Area']"));  
var SearchButton=element(by.buttonText("Search"));       
var SelectFirstorder=element.all(by.xpath("//div[@class='datatable-row-center datatable-row-group']//following::div[@class='GridRowSpanStyle']//h6"));
//FM2 Rail Manager
var txt_railManager=element(by.xpath("//div[text()='Rail Manager']"));
var txt_callType=element(by.id("form:newCallType"));
var txt_eqpType=element(by.id("form:newEqpType"));
var txt_eqpStatus=element(by.id("form:newEqpStatus"));
var txt_trlrPrefix=element(by.id("form:newTrirPrefix"));
var txt_trlrNumber=element(by.id("form:newTrirNbr"));
var txt_chasisPrefix=element(by.id("form:newChassisPrefix"));
var txt_chasisNumber=element(by.id("form:newChassisNbr"));
var txt_orderNumber=element(by.id("form:newOrderNbr"));
var txt_railCarrierNumber=element(by.id("form:newRailCarrier"));
var txt_wayBillNumber=element(by.id("form:newWaybillNbr"));
var txt_trainNumber=element(by.id("form:newTrainNbr"));
var txt_tractorPrefix=element(by.id("form:newTractorPrefix"));
var txt_tractorNumber=element(by.id("form:newTractorNbr"));
var txt_originRamp=element(by.id("form:newOrigRamp"));
var txt_destRamp=element(by.id("form:newDestRamp"));
var txt_evntLocation=element(by.id("form:eventLocation"));
var txt_evntDate=element(by.id("form:eventDate"));
var txt_evntTime=element(by.id("form:eventTime"));
var txt_evntTimeZone=element(by.id("form:eventTZ"));
var txt_FleetCodecheck=element(by.css("[value='JBC SENET2']"));
var txt_FleetCodes=element(by.id("form:j_id5096"));
var tag_tr=element(by.id("form:results")).element(by.className("iceDatTblRow1 iceRowSel"));
var span_order=element(by.xpath("//*[@class='iceCmdLnk  iceCmdLnk ordLink']//span[1]/span[3]"));
var span_Tractor=element(by.xpath("//*[@id='form:results:3']//*[@class='iceCmdLnk'][1]/span"));
//////FM2
var txt_loadNumber = element(by.id("form:orderNumber"));
var btn_Search = element(by.id("form:j_id1262"));
var radio_tractor = element(by.id("form:j_id1298:_2"));
var link_powerDriver = element(by.className("iceOutLnk fmLabel50"));
var txt_span=element(by.xpath("//span[text()='Status']"));
var txt_id=element(by.id("form:j_id3586"));
var txt_tractorNo=element(by.id("form:tractorUi"));
var txt_tractorNoCheckCall=element(by.id("form:truckNum"));
 var txt_tractorNoCheckCall = element(by.className("iceInpTxt fmNum6"));
var txt_DriverMenu=element(by.xpath("//span[text()='Driver']"));
//var checkbox_Preplan = element.all(by.xpath("[class='iceGphImg']"));
var Checkbox_pplan1=element(by.xpath("//*[@id='form:segments:0:j_id1439:0:j_id1444']"));
var Checkbox_pplan2=element(by.xpath("//*[@id='form:segments:0:j_id1439:1:j_id1444']"));
var btn_createPPLN=element(by.xpath("//button[text()='Create Preplan']"));
var btn_update=element(by.xpath("//button[text()='Update']"));
var txt_statusMenu=element(by.xpath("//span[text()='Status']"));
var txt_Arrivaldate=element(by.id("ccCrD:arrivalDate"));
var txt_Loadeddate=element(by.id("ccCrD:j_id1674"));
var txt_Arrivaltime=element(by.id("ccCrD:j_id1670"));
var txt_Loadedtime=element(by.id("ccCrD:j_id1675"));
var txt_BOLNr=element(by.id("ccCrD:j_id1711"));
var txt_Quantity=element(by.id("ccCrD:j_id1713"));
var txt_weight=element(by.id("ccCrD:j_id1715"));
var txt_Seal=element(by.id("ccCrD:j_id1717"));
var txt_UnLoadeddate=element(by.id("ccCrD:j_id1829"));
var txt_unloadArrivaltime=element(by.id("ccCrD:j_id1825"));
var txt_UnLoadedtime=element(by.id("ccCrD:j_id1830"));
var txt_BOLNrUnloadCall=element(by.id("ccCrD:j_id1868"));
var txt_EndHub=element(by.id("ccCrD:j_id1794"));

export class FM2Functions{
 

ElementValidation(Objelement){
  
        Objelement.isPresent().then((elem)=>{
          if(elem==true)
          {
            Objelement.getText().then((text )=>{
              console.log(text);
              console.log("Appointment details is present in order overview"+ text);
            })
          }
       })};

       RailProcessing(){
  
        txt_railManager.isPresent().then((elem)=>{
          if(elem==true)
          {
            reuse.EnterValue(txt_callType,"I","Call Type value");
            reuse.EnterValue(txt_eqpType,"CC","Call Type value");
            reuse.EnterValue(txt_eqpStatus,"L","Call Type value");
            reuse.EnterValue(txt_trlrPrefix,"JBHU","Call Type value");
            reuse.EnterValue(txt_trlrNumber,"287620","Call Type value");
            reuse.EnterValue(txt_chasisPrefix,"JBHZ","Call Type value");
            reuse.EnterValue(txt_chasisNumber,"146709","Call Type value");
            reuse.EnterValue(txt_orderNumber,"CN96490","Call Type value");
            reuse.EnterValue(txt_railCarrierNumber,"BNSF","Call Type value");
            reuse.EnterValue(txt_wayBillNumber,"1111111","Call Type value");
            reuse.EnterValue(txt_trainNumber,"TEST12345","Call Type value");
            reuse.EnterValue(txt_tractorPrefix,"HJBT","Call Type value");
            reuse.EnterValue(txt_tractorNumber,"318766","Call Type value");
            reuse.EnterValue(txt_originRamp,"SR","Call Type value");           
            reuse.EnterValue(txt_destRamp,"R","Call Type value");
             reuse.EnterValue(txt_evntLocation,"SB CA","Call Type value");
             reuse.EnterValue(txt_evntDate,"03052018","Call Type value");
             reuse.EnterValue(txt_evntTime,"0810","Call Type value");
             reuse.EnterValue(txt_evntTimeZone,"PT","Call Type value");          
          }
       })};
      
      async SelectTractorNumber(Objelement){
  
        txt_FleetCodecheck.isPresent().then((elem)=>{
          if(elem==true)
          {
          reuse.ClickButtonwithText("Search");
          span_order.count().then(function(total) {
            for(var i;i<total;i++)
            {        
            if(total>0) {
            var Disp=(span_order[i]).getText().then((elem)=>{ 
            if (elem === null)
            {
              var Disp=(span_order[i+1]).getText().then((elem)=>{ 
                if (elem === null)
                {
                  var j=i+1
var TractorNumber = "[id='form:results:"+j+"']";
var tr_results=element.all(by.xpath("//*[id='form:results:"+j+"']//*[@class='iceCmdLnk'][1]/span"));;
 //await reuse.getTextValueFromElement(tr_results.get(1)).then((text)=>{ 
 // TractorNumber = text 
   //           });           
          }
            });
            }
          });
           
          }
        }
      });
    }
          else{
           reuse.EnterValue(txt_FleetCodes,"JBC SENET2","Fleet code values")
          }
            });
          }
         
          PreplanLoad(){
            
              txt_loadNumber.isPresent().then((elem)=>{ 
                if (elem===true)
                {
                  reuse.EnterValue(txt_loadNumber,"LS44426","Load Number");
                  reuse.ClickElement(btn_Search,"Search button")
                  reuse.ClickElement(radio_tractor,"Tractor Radio button")
                  reuse.EnterValue(txt_tractorNo,"328368","Tractor No");
                  browser.sleep(2000)
                  reuse.ClickElement(Checkbox_pplan1,"Tractor Checkbox1")
                 reuse.ClickElement(Checkbox_pplan2,"Tractor Checkbox2")
                  reuse.ClickElement(btn_createPPLN,"Create preplan button")
                   browser.sleep(3000)     
                  reuse.ClickElement(link_powerDriver,"Click power Driver link")
                  browser.sleep(5000);
                  this.switchToWindow();
                }
                else
                console.log("Power Driver link is not opened");
                });
            }
             switchToWindow(): protractor.promise.Promise<void> {
              return browser.getAllWindowHandles()
                  .then((handles: any) => browser.switchTo().window(handles[handles.length-1]));
            }
            
            //Switch to previous window and next window with index. 
             switchToPreviousWindow(windowNumber: number): protractor.promise.Promise<void> {
              return browser.getAllWindowHandles().then((handles: any) => {
                  browser.switchTo().window(handles[windowNumber]);
              });
            }    
            async LoadStatus(loadstatus){
              reuse.EnterValue(txt_loadNumber,"LS44426","Load Number");
              reuse.ClickElement(btn_Search,"Search button")
              reuse.ClickElement(radio_tractor,"Tractor Radio button")
              reuse.ClickElement(link_powerDriver,"Click power Driver link")
              browser.sleep(5000);
              this.switchToWindow();
              txt_statusMenu.isPresent().then((elem)=>{ 
                  if (elem===true)
                  {
                    browser.sleep(2000)
                    browser.actions().mouseMove(txt_statusMenu).click().perform();
                    reuse.ClickwithText("Status");
                    
                     switch(loadstatus) { 
                      case "Dispatch": { 
                        reuse.ClickwithText("Dispatch *");
                        browser.sleep(2000);
                        reuse.ClickElement(btn_update,"Click update button")
                        browser.sleep(2000);  
                        this.EmptyLoadConfigure();
                         break; 
                      } 
                      case "Arrival": { 
                       this.ArrivalStatusConfigure();
                       this.EmptyLoadConfigure();
                         break; 
                      } 
                      case "Arrival/Loaded": { 
                        this.ArrivalLoadedConfigure();
                        this.EmptyLoadConfigure();
                        break; 
                     } 
                      default: { 
                         //statements; 
                         break; 
                      } 
                   } 
            
                    
                  }
                  else
                  console.log("Acceptance rule is not passed");
                  });
              }
            async  secondWindow()
            {
              await browser.getAllWindowHandles().then(function (handles) {
                var   newWindowHandle = handles[1];
                console.log("Window entry")
                console.log(handles.length)
                      var popUpWindow= handles[1];
                      browser.switchTo().window(popUpWindow);
                      console.log("Switch to window 1")
                      txt_id.sendKeys("23")
                      return browser.getAllWindowHandles()
                      .then((handles: any) => browser.switchTo().window(handles[handles]));
                  
              });
             
            }   
            ArrivalStatusConfigure(){
              
              txt_statusMenu.isPresent().then((elem)=>{ 
                  if (elem===true)
                  {
                    reuse.ClickwithText("Dispatch *");
                    browser.sleep(2000);
                    reuse.ClickElement(btn_update,"Click update button")
                    browser.sleep(2000);  
                    reuse.ClickwithText("Arrival");
                    browser.sleep(2000);            
                    reuse.EnterValue(txt_Arrivaldate,"03192018","Arrival date")
                    browser.sleep(2000);
                    reuse.ClickElement(btn_update,"Click update button")
                  }
                  else
                  console.log("Power Driver link is not opened");
                  });
              }
   
              ArrivalLoadedConfigure(){
                
                txt_statusMenu.isPresent().then((elem)=>{ 
                    if (elem===true)
                    {
                    //  reuse.ClickwithText("Dispatch *");
                     // browser.sleep(2000);
                     // reuse.ClickElement(btn_update,"Click update button")
                      browser.sleep(2000);  
                      reuse.ClickwithText("Arrival/Loaded");
                      browser.sleep(2000);                        
                      reuse.EnterValue(txt_Arrivaldate,"03192018","Arrival date")
                      reuse.EnterValue(txt_Arrivaltime,"0800","Arrival time")
                      reuse.EnterValue(txt_Loadeddate,"03192018","Arrival date")
                      reuse.EnterValue(txt_Loadedtime,"0830","Arrival time")
                      reuse.EnterValue(txt_BOLNr,"2564","BOL number")
                      reuse.EnterValue(txt_Quantity,"5","Quantity value")
                      reuse.EnterValue(txt_weight,"100","Weight value")
                      reuse.EnterValue(txt_Seal,"6","Seal value")        
                      browser.sleep(2000);
                      reuse.ClickElement(btn_update,"Click update button")
                    }
                    else
                    console.log("Power Driver link is not opened");
                    });
                }
  
                UnloadConfigure(){
                  
                  txt_statusMenu.isPresent().then((elem)=>{ 
                      if (elem===true)
                      {
                        reuse.ClickwithText("Arrival/Unloaded");
                        browser.sleep(2000); 
                        reuse.EnterValue(txt_Arrivaldate,"03022018","Arrival date")
                        reuse.EnterValue(txt_unloadArrivaltime,"0800","Arrival time")
                        reuse.EnterValue(txt_UnLoadeddate,"03022018","Arrival date")
                        reuse.EnterValue(txt_UnLoadedtime,"0900","Arrival time")
                        reuse.EnterValue(txt_BOLNrUnloadCall,"2564","BOL number")
                        reuse.EnterValue(txt_EndHub,"341800","End hub number value")                           
                        browser.sleep(2000);
                        reuse.ClickElement(btn_update,"Click update button")
                      }
                      else
                      console.log("Power Driver link is not opened");
                      });
                  }
               async   EmptyLoadConfigure(){  
                    
                    var txt_statusFirst=element.all(by.xpath("//*[@class='iceMnuBarSubMenu'][1]//span"));                 
                    txt_statusMenu.isPresent().then(async(elem)=>{ 
                        if (elem===true)
                        {
                        var firstStatus=await reuse.getTextValueFromElement(txt_statusFirst.get(0))
                        if(firstStatus==="Dispatch *")
                        {
                          reuse.ClickwithText("Dispatch *");
                          browser.sleep(2000);
                          reuse.ClickElement(btn_update,"Click update button")
                          browser.sleep(2000);                  
this.ArrivalStatusConfigure();
this.ArrivalLoadedConfigure();
this.UnloadConfigure();                   
 }
 if(firstStatus==="Arrival")
 {
  this.ArrivalStatusConfigure();
this.ArrivalLoadedConfigure();
this.UnloadConfigure();                   
}
if(firstStatus==="Loaded")
{
this.ArrivalLoadedConfigure();
this.UnloadConfigure();                   
}
                         
                        }
                        else
                        console.log("Power Driver link is not opened");
                        });
                    }       

}
      
      
      
      
      

 
      
























