// import { ElementFinder, browser, by, element } from "protractor";
// import { protractor } from "protractor/built/ptor";

// import { CreateOrderFunctions} from "../PageFiles/OM_CreateOrder";
// let ORDRegression  = new  CreateOrderFunctions;
// import {ShippingOptionFunctions} from "../PageFiles/OM_ShippingOption";
// let ORDShipping  = new ShippingOptionFunctions;
// import {ViewOrderFunctions} from "../PageFiles/OM_ViewOrderDetails";
// let ORDViewOrder = new ViewOrderFunctions;

// import {Update_Objects} from "../ObjectRepository/Objects_Order"
// import { async } from "q";
// import {CommonFunctions} from "../FunctionalLibrary/CommonFunctions"
// var common= new CommonFunctions() 
// import {ReusableFunctions} from "../FunctionalLibrary/ReusableFunctions" 
// let reuse= new ReusableFunctions();
// let ORDRegobject=new Update_Objects();
// import {ExcelReader} from "../CommonFiles/ReadFromXL"
// var ReadFromXL = new ExcelReader();
// import {DataDictionary} from "../DataFiles/DictionaryData";

// var DataDictLib = new DataDictionary();
// var path = require('path'); 
// var filename = path.basename(__filename);
// var Testcase=path.parse(filename).name
// var TcRow=ReadFromXL.FindRowNum(Testcase,"CreateOrder");
// DataDictLib.pushToDictionaryWithSheet(TcRow,"CreateOrder");
// var NavIdValue =DataDictLib.getFromDictionary('NavIdValue');
// var rownumber =DataDictLib.getFromDictionary('Rateoption');
// var Navigationvalue =DataDictLib.getFromDictionary('CreateTitle');
// describe("OM_R1ST_Other BU-SO_MOC-QLF-CONF_DCS_Dedicated_TC048", () => { // suite in Jasmine
//   it("Create an Account in CCI Application",() => {
    
//     var CCiRow=ReadFromXL.FindRowNum(Testcase,"CCI_Details");
//     DataDictLibforCCI.pushToDictionaryWithSheet(CCiRow,"CCI_Details");


//     CA_Run.invokeApplication();                
//     CA_Run.ApplicationLogin(Testcase); 
//     browser.sleep(3000);           
//    CA_Run.Navigation_Process(); 
//     CA_Run.CreateAccount(Testcase);  
//   });
    
//   it("Navigate to Create order page",async() => {
    
//     ORDRegression.Get_url(Testcase);
//     ORDRegression.SignIn(Testcase);
//     browser.sleep(4000);
//     ORDRegression.NavigationFunction(Navigationvalue,Testcase);
//     browser.sleep(4000);
//    }),
//   it("Adding create page details",async() => {
//     OrderNumber=await ORDRegression.Enteringdata(Testcase);    
//     ORDRegression.Freightcharges("3rd");

//     ORDRegression.Shipmentdetails("94345","12589","FL741");
//     ORDRegression.InternationalShipment();
//     ORDRegression.Equipment();
//     browser.sleep(4000);
//   }),
//     it("Adding origin stops details",() => {
//      ORDRegression.AddstopsOrigin(Testcase,"","NULL","");
//     }),
//     it("Adding destination stops details",() => {
//      ORDRegression.AddstopsDestination(Testcase,"","NUll","");
//      ORDRegression.ClickButtonwithText("Next")
//      browser.sleep(7000);         
//      browser.executeScript("window.scrollTo(0,-1000)");
//      ORDRegression.Overrideall();     
//      browser.sleep(80000);
//     }),
//     it("Searching the Order in Advanced search",() => {
    
//      ORDRegression.NavigateWhenToggleActive("Advanced Search");
//      ORDRegression.AdvancedSearchforOrder(OrderNumber,"","","Accepted");
//      browser.sleep(6000);
//      ORDRegression.OrderHistoryWarningsoverride();
//     }),
//     it("Changing the Credit status in CCI Application",() => {
//      ORDRegression.Get_url("https://account-tst.jbhunt.com/account/accounts/manageaccounts");
//      CA_Run.SearchAccount(Testcase);
//      ORDRegression.CCI_AccountSearch("Denied");
//     }),
//     it("Searching the Order in Advanced search",() => {
//       ORDRegression.Get_url(Testcase);
//      ORDRegression.NavigatefromDashboard("Advanced Search");
//      ORDRegression.AdvancedSearchforOrder(3020567,"","","pending");
//           ORDRegression.OrderHistoryWarningsoverride();
//     }),
//     it("Reject the order with rejected credit status",() => {
//      ORDRegression.RejectOrder();
  
// });  
    
// })



