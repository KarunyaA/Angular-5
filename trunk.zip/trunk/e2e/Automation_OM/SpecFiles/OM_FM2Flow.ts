import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";
import { async } from "q";
import {CommonFunctions} from "../FunctionalLibrary/CommonFunctions"
var common= new CommonFunctions() 
import {ReusableFunctions} from "../FunctionalLibrary/ReusableFunctions" 
let reuse= new ReusableFunctions();
import {ExcelReader} from "../CommonFiles/ReadFromXL"
var ReadFromXL = new ExcelReader();
import {DataDictionary} from "../DataFiles/DictionaryData";
var DataDictLib = new DataDictionary();
import {CreateOrderFunctions} from "../PageFiles/OM_CreateOrder";
let ORDCreate  = new CreateOrderFunctions;
import {ShippingOptionFunctions} from "../PageFiles/OM_ShippingOption";
let ORDShipping  = new ShippingOptionFunctions;
import {ViewOrderFunctions} from "../PageFiles/OM_ViewOrderDetails";
let ORDViewOrder  = new ViewOrderFunctions;
import {FM2Functions} from "../PageFiles/OM_FM2";
let ORDFM2  = new FM2Functions;
var path = require('path'); 
var filename = path.basename(__filename);
var Testcase=path.parse(filename).name

var TcRow=ReadFromXL.FindRowNum(Testcase,"CommonData");
DataDictLib.pushToDictionaryWithSheet(TcRow,"CommonData");
var NavIdValue =DataDictLib.getFromDictionary('NavIdValue');
var rownumber =DataDictLib.getFromDictionary('Rateoption');
var Navigationvalue =DataDictLib.getFromDictionary('CreateTitle');


describe("OM_FM2Flow", () => { // suite in Jasmine
  it("Navigate to Create order page",() => {
  
    common.Get_url(Testcase);
    common.SignIn(Testcase);
    browser.sleep(7000);    
  })
 
  it("Clicking on the load link",() => {
   // ORDFM2.PreplanLoad();    
    ORDFM2.LoadStatus("Arrival/Loaded")//Enter the status which is to configured
  })
 

    
})



