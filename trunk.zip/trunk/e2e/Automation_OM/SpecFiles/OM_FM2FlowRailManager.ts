import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";

import { CreateOrderFunctions} from "../PageFiles/OM_CreateOrder";
let ORDRegression  = new  CreateOrderFunctions;
import {Update_Objects} from "../ObjectRepository/Objects_Order"
import { async } from "q";
import {CommonFunctions} from "../FunctionalLibrary/CommonFunctions"
var common= new CommonFunctions() 
import {ReusableFunctions} from "../FunctionalLibrary/ReusableFunctions" 
let reuse= new ReusableFunctions();
let ORDRegobject=new Update_Objects();
import {ExcelReader} from "../CommonFiles/ReadFromXL"
var ReadFromXL = new ExcelReader();
import {DataDictionary} from "../DataFiles/DictionaryData";

import  {FM2Functions} from "../PageFiles/OM_FM2";
let ORDReg  = new FM2Functions;
import {ViewOrderFunctions} from "../PageFiles/OM_ViewOrderDetails";
let ORDR = new ViewOrderFunctions;
var DataDictLib = new DataDictionary();
var path = require('path'); 
var filename = path.basename(__filename);
var Testcase=path.parse(filename).name
var TcRow=ReadFromXL.FindRowNum(Testcase,"CreateOrder");
DataDictLib.pushToDictionaryWithSheet(TcRow,"CreateOrder");
var NavIdValue =DataDictLib.getFromDictionary('NavIdValue');
var rownumber =DataDictLib.getFromDictionary('Rateoption');
var Navigationvalue =DataDictLib.getFromDictionary('CreateTitle');


describe("OM_R1ST_MOC_TC014", () => { // suite in Jasmine
  it("Navigate to Create order page",() => {
   
    common.Get_url(Testcase);
    common.SignIn(Testcase);
    browser.sleep(5000);
    //common.NavigationFunction("Create New Order",Testcase);
  })
 
  it("Adding origin stop details",() => {
    ORDReg.RailProcessing();
  })
 

    
})



