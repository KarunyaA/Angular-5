import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";
import { CreateOrderFunctions} from "../PageFiles/OM_CreateOrder";
let ORDRegression  = new  CreateOrderFunctions;
import {ShippingOptionFunctions} from "../PageFiles/OM_ShippingOption";
let ORDShipping  = new ShippingOptionFunctions;
import {Update_Objects} from "../ObjectRepository/Objects_Order"
import { async } from "q";
import {CommonFunctions} from "../FunctionalLibrary/CommonFunctions"
var common= new CommonFunctions() 
import {ReusableFunctions} from "../FunctionalLibrary/ReusableFunctions" 
let reuse= new ReusableFunctions();
import {AdvancedSearchFunctions} from "../PageFiles/OM_AdvancedSearch";
let AdvancedSearch  = new AdvancedSearchFunctions;
let ORDRegobject=new Update_Objects();
import {ExcelReader} from "../CommonFiles/ReadFromXL"
var ReadFromXL = new ExcelReader();
import {DataDictionary} from "../DataFiles/DictionaryData";
import {CreateTemplateFunctions} from "../PageFiles/OM_CreateTemplate";
let CreateTemplateFunc  = new CreateTemplateFunctions;

var DataDictLib = new DataDictionary();
var path = require('path'); 
var filename = path.basename(__filename);
var Testcase=path.parse(filename).name

var NavIdValue =DataDictLib.getFromDictionary('NavIdValue');
var rownumber =DataDictLib.getFromDictionary('Rateoption');
var Navigationvalue =DataDictLib.getFromDictionary('CreateTitle');
describe("OM_R1.1_ST_Temp_TC007", () => { // suite in Jasmine
    it("Update Party Code,Party Role values in the Mass Templates Fields Screen  for all active and inactive templates",() => {
      
      
      common.Get_url(Testcase);
      browser.sleep(3000);
      common.SignIn(Testcase);
      browser.sleep(1000);
      CreateTemplateFunc.TemplateSCACSearch(Testcase);
      browser.sleep(1000);
      common.OverFlowFunction("Edit Fields for Multiple Templates",Testcase);
      browser.sleep(1000);
      CreateTemplateFunc.Checkboxselect();
      CreateTemplateFunc.Editselect();
      browser.sleep(1000);
      CreateTemplateFunc.AddField();
      CreateTemplateFunc.TypeSelect_Func("ADDITIONAL PARTY");
      CreateTemplateFunc.AddLink();
      browser.sleep(1000);
      
      CreateTemplateFunc.Update_Func("Mass update request initiated. Refer to the MASS UPDATE TEMPLATE HISTORY SCREEN for status.");
      browser.sleep(6000);
      common.OverFlowFunction("Mass Update Template History",Testcase);
      CreateTemplateFunc.validatestatus();
      CreateTemplateFunc.Go_back();
      CreateTemplateFunc.TemplateSearch(Testcase);
      browser.sleep(3000);
     
      ORDRegression.Shipmentdetails(Testcase); 
      browser.sleep(3000);
      ORDRegression.AddstopsOrigin(Testcase,"NULL","NULL","27/Feb/2018");
      browser.sleep(5000);
      ORDRegression.AddstopsDestination(Testcase,"NULL","Null","28/Feb/2018");
      reuse.ClickButtonwithText("Next");
      browser.sleep(60000);
      browser.executeScript("window.scrollTo(0,-500)");
      ORDShipping.ClickRateoption(Testcase,rownumber);
      reuse.ClickButtonwithText("Create")
      browser.sleep(30000);
      browser.executeScript("window.scrollTo(0,2000)"); 
    });
      
    });

    