import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";
import { async } from "q";
import {CommonFunctions} from "../FunctionalLibrary/CommonFunctions"
var common= new CommonFunctions() 
import {ReusableFunctions} from "../FunctionalLibrary/ReusableFunctions" 
let reuse= new ReusableFunctions();
import {ExcelReader} from "../CommonFiles/ReadFromXL"
var ReadFromXL = new ExcelReader();
import {DataDictionary} from "../DataFiles/DictionaryData";
var DataDictLib = new DataDictionary();
import {CreateOrderFunctions} from "../PageFiles/OM_CreateOrder";
let ORDCreate  = new CreateOrderFunctions;
import {ShippingOptionFunctions} from "../PageFiles/OM_ShippingOption";
let ORDShipping  = new ShippingOptionFunctions;
import {ViewOrderFunctions} from "../PageFiles/OM_ViewOrderDetails";
let ORDViewOrder  = new ViewOrderFunctions;
import {CreateTemplateFunctions} from "../PageFiles/OM_CreateTemplate";
let ORDCreateTemplate  = new CreateTemplateFunctions;
var path = require('path'); 
var filename = path.basename(__filename);
var Testcase=path.parse(filename).name

var TcRow=ReadFromXL.FindRowNum(Testcase,"CreateOrder");
DataDictLib.pushToDictionaryWithSheet(TcRow,"CreateOrder");
var NavIdValue =DataDictLib.getFromDictionary('NavIdValue');
var rownumber =DataDictLib.getFromDictionary('Rateoption');
var Navigationvalue =DataDictLib.getFromDictionary('CreateTitle');
var icon_loading=element(by.xpath("//*[@class='spinner' and @role='progressbar']"));

describe("OM_R1.1_ST_USP-144--->To verify whether the OM Create/Update  , is able  to Update the Party Role, Party Address and Solicitor Address data elements in the View/Edit Screen screen when the load is in the Dispatched stage during in Transit status ", () => { // suite in Jasmine
  it("Navigate to Create order page",() => {
   
    common.Get_url(Testcase);
    common.SignIn(Testcase);    
    browser.waitForAngular();
    browser.sleep(8000);
    browser.waitForAngular();
    ORDViewOrder.UpdatePartyDetails(Testcase)  
  })
})




