import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";

import { CreateOrderFunctions} from "../PageFiles/OM_CreateOrder";
let ORDRegression  = new  CreateOrderFunctions;
import {ShippingOptionFunctions} from "../PageFiles/OM_ShippingOption";
let ORDShipping  = new ShippingOptionFunctions;
import {ViewOrderFunctions} from "../PageFiles/OM_ViewOrderDetails";
let ORDViewOrder = new ViewOrderFunctions;

import {Update_Objects} from "../ObjectRepository/Objects_Order"
import { async } from "q";
import {CommonFunctions} from "../FunctionalLibrary/CommonFunctions"
var common= new CommonFunctions() 
import {ReusableFunctions} from "../FunctionalLibrary/ReusableFunctions" 
let reuse= new ReusableFunctions();
import {EOMFunctions} from "../PageFiles/OM_EOM";
let ORDEOM = new EOMFunctions
let ORDRegobject=new Update_Objects();
import {ExcelReader} from "../CommonFiles/ReadFromXL"
var ReadFromXL = new ExcelReader();
import {DataDictionary} from "../DataFiles/DictionaryData";
import {AdvancedSearchFunctions} from "../PageFiles/OM_AdvancedSearch";
let ORDAdvance = new AdvancedSearchFunctions;

var DataDictLib = new DataDictionary();
var path = require('path'); 
var filename = path.basename(__filename);
var Testcase=path.parse(filename).name
var TcRow=ReadFromXL.FindRowNum(Testcase,"CreateOrder");
DataDictLib.pushToDictionaryWithSheet(TcRow,"CreateOrder");
var NavIdValue =DataDictLib.getFromDictionary('NavIdValue');
var rownumber =DataDictLib.getFromDictionary('Rateoption');
var Navigationvalue =DataDictLib.getFromDictionary('CreateTitle');
var DictOM = new DataDictionary();
var DictEOM = new DataDictionary();
var Dictconsolidate =new DataDictionary();
var DataDictLib = new DataDictionary();
var path = require('path'); 
var filename = path.basename(__filename);
var Testcase=path.parse(filename).name;
var OMvals =DataDictLib.getFromDictionary('OMvalues');
var OrderNumber
var LoadID


describe("JBH_OM_R1ST_Backfill_TC041", () => { // suite in Jasmine
    it("Should Have a Title To be Verified",async () => {
        var TcRow=ReadFromXL.FindRowNum(Testcase,"CreateOrder");
        
        DataDictLib.pushToDictionaryWithSheet(TcRow,"CreateOrder");

        var NavIdValue =DataDictLib.getFromDictionary('NavIdValue');
        var rownumber =DataDictLib.getFromDictionary('NavIdValue');
        var urlName =DataDictLib.getFromDictionary('UrlName');
        var Navigationvalue =DataDictLib.getFromDictionary('CreateTitle');
     
        common.Get_url(Testcase);
        browser.sleep(5000);
        common.SignIn(Testcase);        
        common.NavigationFunction(Navigationvalue,Testcase);
              
        
        OrderNumber=await ORDRegression.Enteringdata(Testcase);
        //ORDRegression.ClickButtonwithText("Next");
        browser.sleep(5000);
        ORDRegression.AddstopsOrigin(Testcase,"Scheduled","Requested","19/Jan/2018");
        ORDRegression.AddstopsDestination(Testcase,"Scheduled","Requested","20/Jan/2018");
        ORDRegression.addmultiplestops(Testcase,"Pickup","","");
         // //ORDRegression.DateValidationCreateOrderOverview("12/27/2017","12/28/2017");
        ORDRegression.MultiplePalletCheckbox(Testcase,"Create New Template");
        reuse.ClickButtonwithText("Save");
        browser.sleep(5000);
        reuse.ClickButtonwithText("Next");
        browser.sleep(80000); 
        ORDRegression.Overrideall();
        browser.sleep(60000);
        ORDShipping.ValidateRateOption();
        ORDShipping.ClickRateoption(Testcase,rownumber);
        browser.sleep(15000); 
        ORDShipping.CreateWithoutRate();
        browser.sleep(8000);  
        common.NavigateWhenToggleActive("Advanced Search");
        browser.sleep(8000);    
       
      
        ORDAdvance.AdvancedSearchforOrder(OrderNumber,"01/19/2018","01/20/2018","Acccepted");    
         browser.sleep(20000);
         ORDViewOrder.FetchDatafromOM();
        browser.sleep(5000);
        
        
        await  ORDViewOrder.FetchDatafromOM().then((text)=>{          
            DictOM = text 
          }) ;
        
         
      console.log(DictOM["BusUnit"]);

        browser.get("http://eom-dev.jbhunt.com/eom/search/eomSearch.face");

        common.SignIn(Testcase);
        browser.get("http://eom-dev.jbhunt.com/eom/search/eomSearch.face");
        ORDEOM.NavigateEOM(LoadID);

        ORDEOM.FetchDatafromEOM();
        browser.sleep(5000);
          await ORDEOM.FetchDatafromEOM().then((text)=>{
            DictEOM = text 
        });


      console.log(DictEOM["BusUnit_EOM"]);

      ORDViewOrder.CompareValues(Testcase,DictOM,DictEOM);

      
        
   



    });
    
       
        
    });
