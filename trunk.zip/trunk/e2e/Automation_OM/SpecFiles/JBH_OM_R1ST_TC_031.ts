import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";

import { CreateOrderFunctions} from "../PageFiles/OM_CreateOrder";
let ORDRegression  = new  CreateOrderFunctions;
import {ShippingOptionFunctions} from "../PageFiles/OM_ShippingOption";
let ORDShipping  = new ShippingOptionFunctions;
import {ViewOrderFunctions} from "../PageFiles/OM_ViewOrderDetails";
let ORDViewOrder = new ViewOrderFunctions;
import {AdvancedSearchFunctions} from "../PageFiles/OM_AdvancedSearch";
let ORDAdvance = new AdvancedSearchFunctions;

import {Update_Objects} from "../ObjectRepository/Objects_Order"
import { async } from "q";
import {CommonFunctions} from "../FunctionalLibrary/CommonFunctions"
var common= new CommonFunctions() 
import {ReusableFunctions} from "../FunctionalLibrary/ReusableFunctions" 
let reuse= new ReusableFunctions();
let ORDRegobject=new Update_Objects();
import {ExcelReader} from "../CommonFiles/ReadFromXL"
var ReadFromXL = new ExcelReader();
import {DataDictionary} from "../DataFiles/DictionaryData";
var DataDictLib1 = new DataDictionary();
var DataDictLib = new DataDictionary();
var path = require('path'); 
var filename = path.basename(__filename);
var Testcase=path.parse(filename).name
var TcRow=ReadFromXL.FindRowNum(Testcase,"CreateOrder");
DataDictLib.pushToDictionaryWithSheet(TcRow,"CreateOrder");
var NavIdValue =DataDictLib.getFromDictionary('NavIdValue');
var rownumber =DataDictLib.getFromDictionary('Rateoption');
//var Navigationvalue =DataDictLib.getFromDictionary('CreateTitle');
var TcRow1=ReadFromXL.FindRowNum(Testcase,"CommonData");
DataDictLib1.pushToDictionaryWithSheet(TcRow,"CommonData");
var Navigationvalue =DataDictLib.getFromDictionary('CreateTitle');

describe("JBH_OM_R1ST_TC_031", () => { // suite in Jasmine
    it("Should Have a Title To be Verified",async () => {
        var TcRow=ReadFromXL.FindRowNum(Testcase,"CreateOrder");
        
        DataDictLib.pushToDictionaryWithSheet(TcRow,"CreateOrder");
        var NavIdValue =DataDictLib.getFromDictionary('NavIdValue');
        var rownumber =DataDictLib.getFromDictionary('NavIdValue');
        var urlName =DataDictLib.getFromDictionary('UrlName');
        var Navigationvalue =DataDictLib.getFromDictionary('CreateTitle');
     
        common.Get_url(Testcase);     
        common.SignIn(Testcase); 
        browser.sleep(6000);     
        common.NavigationFunction(Navigationvalue,Testcase);      
        var OrderNumber = await ORDRegression.Enteringdata(Testcase);
        browser.sleep(3000);
       // ORDRegression.Equipment(Testcase);
       // browser.sleep(3000);
        ORDRegression.utilities("Reference","Add");
        browser.sleep(3000);
       // ORDRegobject.NextButton.click();
        ORDRegression.AddstopsOrigin(Testcase,"Null","","18/Jan/2018"); 
        ORDRegression.AddstopsDestination(Testcase,"Null","","19/Jan/2018");
        ORDRegression.TotalMilesCreateOrderOverview(ORDRegobject.TotalMiles);    /////Total Miles
        browser.executeScript("window.scrollTo(0,200)");
        reuse.ClickButtonwithText("Back");
        browser.sleep(3000);
        browser.executeScript("window.scrollTo(0,-500)");
        
        reuse.ClickButtonwithText("Go Back");
        browser.sleep(5000);
        ORDRegression.utilities("Reference","Edit");
        browser.executeScript("window.scrollTo(0,200)");
        ORDRegobject.NextButton.click();
        browser.sleep(10000);
        ORDRegression.Overrideall();    
        browser.sleep(20000);
       // ORDShipping.ValidateRateOption();
       // ORDShipping.ClickRateoption(Testcase,rownumber);
       // reuse.ClickButtonwithText("Create")
        browser.sleep(5000); 
        ORDShipping.CreateWithoutRate();
        browser.sleep(10000); 
       // common.NavigationFunction(Navigationvalue,Testcase);
        ORDAdvance.AdvancedSearchforOrder(OrderNumber,"01/18/2018","01/18/2018","Acccepted");  
     

    });
    
       
        
    });