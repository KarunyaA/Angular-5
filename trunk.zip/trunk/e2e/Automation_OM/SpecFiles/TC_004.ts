import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";
import {CommonFunctions} from "../FunctionalLibrary/CommonFunctions"
var common= new CommonFunctions() 
import {ExcelReader} from "../CommonFiles/ReadFromXL"
var ReadFromXL = new ExcelReader();
import {DataDictionary} from "../DataFiles/DictionaryData";
var DataDictLib = new DataDictionary();
var path = require('path'); 
var filename = path.basename(__filename);
var Testcase=path.parse(filename).name;
import {Update_Objects} from "../ObjectRepository/Objects_Order"
let ORDRegobject  = new Update_Objects; 
import { CreateOrderFunctions} from "../PageFiles/OM_CreateOrder";
let ORDRegression  = new  CreateOrderFunctions;

describe("TemplatesTC004", () => { // suite in Jasmine
    it("Create template and then create a order from it",async () => {
        var TcRow=ReadFromXL.FindRowNum(Testcase,"CreateOrder");
        
        DataDictLib.pushToDictionaryWithSheet(TcRow,"CreateOrder");
        var NavIdValue =DataDictLib.getFromDictionary('NavIdValue');
        var rownumber =DataDictLib.getFromDictionary('Rateoption');
        var urlName =DataDictLib.getFromDictionary('UrlName');
        var Navigationvalue =DataDictLib.getFromDictionary('CreateTitle');
        var OrderNumber;
        common.Get_url(Testcase);
        browser.sleep(5000);
        common.SignIn(Testcase);
     browser.sleep(3000);
      //ORDRegression.NavigatefromDashboard("Create Order");
       //ORDRegression.NavigationFunction(Navigationvalue,Testcase);
         ORDRegression.Enteringdata(Testcase);
        //ORDRegression.Shipmentdetails();
        ORDRegression.AddstopsOrigin(Testcase,"Scheduled","","9/Jan/2018");
        ORDRegression.AddstopsDestination(Testcase,"Scheduled","","10/Jan/2018");
      //  ORDRegression.ClickButtonwithText("Save");
       // ORDRegression.ClickButtonwithText("Save");
        browser.sleep(25000); 
        // ORDRegression.NavigateWhenToggleActive("Create Order");
        // browser.sleep(5000);
        // OrderNumber=await ORDRegression.TemplateSearch(Testcase);
        // browser.sleep(12000);
        // ORDRegobject.NextButton.click();
        // browser.sleep(4000);
        // ORDRegression.AppointmentOrigin(Testcase,"Scheduled","10/Jan/2018","Create New Order");
        // browser.sleep(5000);
        // ORDRegobject.DestinationTab.click();
        // browser.sleep(2000);
        // ORDRegression.AppiontmentDestination(Testcase,"Scheduled","11/Jan/2018","Create New Order",4);
        // browser.sleep(5000);
        // ORDRegobject.NextButton.click();
        // browser.sleep(50000);      
        // ORDRegression.DateValidationCreateOrderOverview("01/09/2018","01/09/2018")
        // ORDRegression.NavigateWhenToggleActive("Advanced Search");
        // browser.sleep(8000);
        // ORDRegression.AdvancedSearchforOrder(OrderNumber,"01/09/2018","01/09/2018","Acccepted");        
        // browser.sleep(3000);
        //  ORDRegression.ElementValidationAdvancedsearch("01/09/2018","01/09/2018");
        //  browser.sleep(8000);
        //  ORDRegression.AppointmentValidation();
        //  browser.sleep(5000);
    });
    
       
        
    });

    