import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";

import { CreateOrderFunctions} from "../PageFiles/OM_CreateOrder";
let ORDRegression  = new  CreateOrderFunctions;
import {ShippingOptionFunctions} from "../PageFiles/OM_ShippingOption";
let ORDShipping  = new ShippingOptionFunctions;
import {ViewOrderFunctions} from "../PageFiles/OM_ViewOrderDetails";
let ORDViewOrder = new ViewOrderFunctions;

import {Update_Objects} from "../ObjectRepository/Objects_Order"
import { async } from "q";
import {CommonFunctions} from "../FunctionalLibrary/CommonFunctions"
var common= new CommonFunctions() 
import {ReusableFunctions} from "../FunctionalLibrary/ReusableFunctions" 
let reuse= new ReusableFunctions();
let ORDRegobject=new Update_Objects();
import {ExcelReader} from "../CommonFiles/ReadFromXL"
var ReadFromXL = new ExcelReader();
import {DataDictionary} from "../DataFiles/DictionaryData";
import {CreateTemplateFunctions} from "../PageFiles/OM_CreateTemplate"
let TempFunctions = new CreateTemplateFunctions
import {AdvancedSearchFunctions} from "../PageFiles/OM_AdvancedSearch";
let ORDAdvance = new AdvancedSearchFunctions;

var DataDictLib = new DataDictionary();
var path = require('path'); 
var filename = path.basename(__filename);
var Testcase=path.parse(filename).name
var TcRow=ReadFromXL.FindRowNum(Testcase,"CreateOrder");
DataDictLib.pushToDictionaryWithSheet(TcRow,"CreateOrder");
var NavIdValue =DataDictLib.getFromDictionary('NavIdValue');
var rownumber =DataDictLib.getFromDictionary('Rateoption');
var Navigationvalue =DataDictLib.getFromDictionary('CreateTitle');
var OrderNumber

describe("JBH_OM_R1ST_TC_003", () => { // suite in Jasmine
    it("Navigate to create order page",async () => {
        var TcRow=ReadFromXL.FindRowNum(Testcase,"CreateOrder");
        
        DataDictLib.pushToDictionaryWithSheet(TcRow,"CreateOrder");
        var NavIdValue =DataDictLib.getFromDictionary('NavIdValue');
        var rownumber =DataDictLib.getFromDictionary('NavIdValue');
        var urlName =DataDictLib.getFromDictionary('UrlName');
        var Navigationvalue =DataDictLib.getFromDictionary('CreateTitle');
        var OrderNumber;
        common.Get_url(Testcase);        
        common.SignIn(Testcase);
        browser.sleep(8000);        
        common.NavigationFunction("Create New Template",Testcase);
    //})
    //it(" Adding stop details",async () => {
         ORDRegression.Enteringdata(Testcase);
         //ORDRegression.Shipmentdetails("","","");
        ORDRegression.AddstopsOrigin(Testcase,"Null","","9/Jan/2018");
        browser.sleep(3000);
        ORDRegression.AddstopsDestination(Testcase,"Null","","10/Jan/2018");
        reuse.ClickButtonwithText("Save");     
        browser.sleep(25000); 
    
        browser.executeScript("window.scrollTo(0,-500)");
        common.NavigateWhenToggleActive("Create Order");
        browser.sleep(5000);
        OrderNumber=await TempFunctions.TemplateSearch(Testcase);
        browser.sleep(12000);
        browser.executeScript("window.scrollTo(0,-500)");
        ORDRegobject.NextButton.click();
       browser.sleep(7000);
       // ORDRegression.Equipment(Testcase);
       // browser.sleep(5000);
       // ORDRegression.HazmatDetails();
        ORDRegobject.NextButton.click();
        browser.sleep(40000);
    })
    // it("Searching the order from Advanced search and Validating the appointment details",async () => {
       
    //     ORDRegression.DateValidationCreateOrderOverview("01/09/2018","01/09/2018")
    //     common.NavigateWhenToggleActive("Advanced Search");
    //     browser.sleep(8000);
    //     ORDAdvance.AdvancedSearchforOrder(OrderNumber,"01/09/2018","01/09/2018","Acccepted");        
    //     browser.sleep(3000);
    //     ORDAdvance.ElementValidationAdvancedsearch("01/09/2018","01/09/2018");
        
    // });

    })
    
       
   

    