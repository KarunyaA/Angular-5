import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";

import { CreateOrderFunctions} from "../PageFiles/OM_CreateOrder";
let ORDRegression  = new  CreateOrderFunctions;
import {ShippingOptionFunctions} from "../PageFiles/OM_ShippingOption";
let ORDShipping  = new ShippingOptionFunctions;
import {ViewOrderFunctions} from "../PageFiles/OM_ViewOrderDetails";
let ORDViewOrder = new ViewOrderFunctions;

import {Update_Objects} from "../ObjectRepository/Objects_Order"
import { async } from "q";
import {CommonFunctions} from "../FunctionalLibrary/CommonFunctions"
var common= new CommonFunctions() 
import {ReusableFunctions} from "../FunctionalLibrary/ReusableFunctions" 
let reuse= new ReusableFunctions();
let ORDRegobject=new Update_Objects();
import {ExcelReader} from "../CommonFiles/ReadFromXL"
var ReadFromXL = new ExcelReader();
import {DataDictionary} from "../DataFiles/DictionaryData";
import {CreateTemplateFunctions} from "../PageFiles/OM_CreateTemplate"
let TempFunctions = new CreateTemplateFunctions

var DataDictLib = new DataDictionary();
var path = require('path'); 
var filename = path.basename(__filename);
var Testcase=path.parse(filename).name
var TcRow=ReadFromXL.FindRowNum(Testcase,"CreateOrder");
DataDictLib.pushToDictionaryWithSheet(TcRow,"CreateOrder");
var NavIdValue =DataDictLib.getFromDictionary('NavIdValue');
var rownumber =DataDictLib.getFromDictionary('Rateoption');
var Navigationvalue =DataDictLib.getFromDictionary('CreateTitle');

describe("OM_R1_Templates(Exceptional Flow)-MOC-QLF-CONF_ST Flow_TC012", () => { // suite in Jasmine
  it("Navigate to Create Template page",() => {  
    common.Get_url(Testcase);
    browser.sleep(5000);
    common.SignIn(Testcase);        
    common.NavigationFunction(Navigationvalue,Testcase);
    ORDRegression.Enteringdata(Testcase);
    ORDRegression.Shipmentdetails(Testcase);
    ORDRegression.AddstopsOrigin(Testcase,"Null","Null","9/Jan/2018");
    ORDRegression.AddstopsDestination(Testcase,"Null","Null","10/Jan/2018");
    ORDRegression.addmultiplestops(Testcase,"Pickup","","");
    ORDRegression.DateValidationCreateOrderOverview("12/27/2017","12/28/2017");
    ORDRegression.MultiplePalletCheckbox(Testcase,"Create New Template");
    reuse.ClickButtonwithText("Save");
    browser.sleep(5000);
    TempFunctions.SearchTemplate("INBRBW");
    browser.sleep(5000);
    TempFunctions.TemplateSearch(Testcase);
    ORDRegression.utilities("Charge","Edit");
    ORDRegobject.NextButton.click();
    browser.sleep(4000);
    ORDRegression.AppointmentOrigin(Testcase,"Scheduled","10/Jan/2018","Create New Order");
    browser.sleep(5000);
    ORDRegobject.DestinationTab.click();
    browser.sleep(2000);
    ORDRegression.AppiontmentDestination(Testcase,"Scheduled","11/Jan/2018","Create New Order",2);
    browser.sleep(5000);
    ORDRegobject.NextButton.click();
    browser.sleep(2000);  
    reuse.ClickButtonwithText("Back")
    browser.sleep(3000);
    browser.executeScript("window.scrollTo(0,-500)");    
    reuse.ClickButtonwithText("Go Back");
    browser.sleep(3000);
    ORDRegression.Shipmentdetails(Testcase); 
    ORDRegobject.NextButton.click();
    browser.sleep(2000);
    ORDRegobject.NextButton.click();
    browser.sleep(50000);
    ORDShipping.ClickRateoption(Testcase,rownumber);
    ORDViewOrder.OrderHistory();  
});  
    
})



