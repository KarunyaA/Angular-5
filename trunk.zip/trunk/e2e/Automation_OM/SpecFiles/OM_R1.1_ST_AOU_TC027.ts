import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";

import { CreateOrderFunctions} from "../PageFiles/OM_CreateOrder";
let ORDRegression  = new  CreateOrderFunctions;
import {ShippingOptionFunctions} from "../PageFiles/OM_ShippingOption";
let ORDShipping  = new ShippingOptionFunctions;
import {ViewOrderFunctions} from "../PageFiles/OM_ViewOrderDetails";
let ORDViewOrder = new ViewOrderFunctions;

import {Update_Objects} from "../ObjectRepository/Objects_Order"
import { async } from "q";
import {CommonFunctions} from "../FunctionalLibrary/CommonFunctions"
var common= new CommonFunctions() 
import {ReusableFunctions} from "../FunctionalLibrary/ReusableFunctions" 
let reuse= new ReusableFunctions();
let ORDRegobject=new Update_Objects();
import {ExcelReader} from "../CommonFiles/ReadFromXL"
var ReadFromXL = new ExcelReader();
import {DataDictionary} from "../DataFiles/DictionaryData";

var DataDictLib = new DataDictionary();
var path = require('path'); 
var filename = path.basename(__filename);
var Testcase=path.parse(filename).name
var TcRow=ReadFromXL.FindRowNum(Testcase,"CommonData");
DataDictLib.pushToDictionaryWithSheet(TcRow,"CommonData");
var NavIdValue =DataDictLib.getFromDictionary('NavIdValue');
var rownumber =DataDictLib.getFromDictionary('Rateoption');
var Navigationvalue =DataDictLib.getFromDictionary('CreateTitle');

var Navigationvalue =DataDictLib.getFromDictionary('CreateTitle');


describe("OM_R1.1_ST_AOU_TC027", () => { // suite in Jasmine
    it("Accept order update",() => {
    
      common.Get_url(Testcase);
      browser.sleep(20000);
     // common.SignIn(Testcase);        
      //common.NavigationFunction(Navigationvalue,Testcase);
    })
    it("Accept order update",() => {

       // ORDViewOrder.Updatehighvalue(Testcase);
       ORDViewOrder.Vesselupdate(Testcase);

      

       
        
      })

})