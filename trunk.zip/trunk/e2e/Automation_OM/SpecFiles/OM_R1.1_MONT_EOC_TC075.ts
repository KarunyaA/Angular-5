import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";
import {  CreateOrderFunctions } from "../PageFiles/OM_CreateOrder";
import { ShippingOptionFunctions } from "../PageFiles/OM_ShippingOption";
import { ViewOrderFunctions } from "../PageFiles/OM_ViewOrderDetails";
import { MonitoringFunctions } from "../PageFiles/OM_Sanity_Monitoring";
import { Update_Objects } from "../ObjectRepository/Objects_Order"
import { async } from "q";
import { CommonFunctions } from "../FunctionalLibrary/CommonFunctions"
import  { ReusableFunctions }  from  "../FunctionalLibrary/ReusableFunctions"
import { ExcelReader } from "../CommonFiles/ReadFromXL"
import { DataDictionary } from "../DataFiles/DictionaryData";
import { EOMFunctions } from "../PageFiles/OM_EOM";
let ORDEOM = new EOMFunctions
let ORDRegression = new CreateOrderFunctions;
let ORDShipping = new ShippingOptionFunctions;
let ORDViewOrder = new ViewOrderFunctions;
let MonitoringFunc = new MonitoringFunctions;
var common = new CommonFunctions()
let reuse = new ReusableFunctions();
let ORDRegobject = new Update_Objects();
var ReadFromXL = new ExcelReader();
var DataDictLib = new DataDictionary();
var DataDictLib = new DataDictionary();
var  path  =  require('path');
var  filename  =  path.basename(__filename);
var  Testcase = path.parse(filename).name



describe("OM_R1.1_MONT_EOC_TC071", () => { // suite in Jasmine
  it("Navigate to Create order page", async () => {
    var TcRow = ReadFromXL.FindRowNum(Testcase, "CommonData");
    DataDictLib.pushToDictionaryWithSheet(TcRow, "CommonData");
    var NavIdValue = DataDictLib.getFromDictionary('NavIdValue');
    var rownumber = DataDictLib.getFromDictionary('NavIdValue');
    var urlName = DataDictLib.getFromDictionary('UrlName');
    var Navigationvalue = DataDictLib.getFromDictionary('CreateTitle');
    var LoadID;
    common.Get_url(Testcase);
    // browser.sleep(2000);
    common.SignIn(Testcase);
    browser.sleep(8000);
    //   common.NavigationFunction("Create New Order",Testcase);
    //   OrderNumber=await ORDRegression.Enteringdata(Testcase);
    //   //ORDRegression.ClickButtonwithText("Next");
    //   //ORDRegression.Enteringdata(Testcase);
    //   ORDRegression.AddstopsOrigin(Testcase,"NULL","NULL","30/Mar/2018");
    //   ORDRegression.AddstopsDestination(Testcase,"NULL","Null","31/Mar/2018");
    //   reuse.ClickButtonwithText("Next");
    //   browser.sleep(50000);
    //  //browser.executeScript("window.scrollTo(0,-500)");
    //   ORDShipping.ClickRateoption(Testcase,rownumber);   
    //   browser.sleep(15000);
    //   browser.executeScript("window.scrollTo(0,2000)"); 
    //   common.NavigateWhenToggleActive("Advanced Search");
    //   browser.sleep(8000);    
    //   ORDAdvance.AdvancedSearchforOrder(OrderNumber,"03/30/2018","03/31/2018","Acccepted");
    //   browser.sleep(20000);

    // ORDViewOrder.FetchDatafromOM();
    // browser.sleep(5000);  
    // browser.executeScript("window.scrollTo(0,-500)");   
    // browser.sleep(5000);  
    // browser.executeScript("window.scrollTo(0,700)");         
    //LoadID = await ORDViewOrder.RoutePlan(Testcase);

    // browser.get("http://eom-dev.jbhunt.com/eom/search/eomSearch.face");
    //common.AlternateLogin();
    //browser.sleep(5000);
    ////browser.get("http://eom-dev.jbhunt.com/eom/search/eomSearch.face");
    //ORDEOM.NavigateEOM("LS45473");

   // ORDEOM.CreatePPnote("OVRAL")
    // common.Get_url(Testcase);
    // common.SignIn(Testcase);
     browser.sleep(15000);
    //ORDViewOrder.RoutePlan(Testcase)
    common.NavigatefromDashboard("Tasks")
    browser.sleep(4000);
    MonitoringFunc.Task_Select(Testcase);
    browser.sleep(2000);
    MonitoringFunc.Filter_Search("1000195"); //OrderNumber
    browser.sleep(5000);
    MonitoringFunc.SelectFirstinstance("1000195");//OrderNumber
    browser.sleep(3000);
    MonitoringFunc.iscroll(6);
    browser.sleep(3000);
    MonitoringFunc.SelectMonitoringFunctionality("Snooze");
    MonitoringFunc.SelectCancel("No");
    reuse.ClickButtonwithText("Snooze");
    browser.executeScript("window.scrollTo(0,1000)");
    MonitoringFunc.SelectCancel("Yes");
    MonitoringFunc.Filter_Search("1000195"); //OrderNumber
  })
})