import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";

import { CreateOrderFunctions} from "../PageFiles/OM_CreateOrder";
let ORDRegression  = new  CreateOrderFunctions;
import {ShippingOptionFunctions} from "../PageFiles/OM_ShippingOption";
let ORDShipping  = new ShippingOptionFunctions;
import {ViewOrderFunctions} from "../PageFiles/OM_ViewOrderDetails";
let ORDViewOrder = new ViewOrderFunctions;

import {Update_Objects} from "../ObjectRepository/Objects_Order"
import { async } from "q";
import {CommonFunctions} from "../FunctionalLibrary/CommonFunctions"
var common= new CommonFunctions() 
import {ReusableFunctions} from "../FunctionalLibrary/ReusableFunctions" 
let reuse= new ReusableFunctions();
let ORDRegobject=new Update_Objects();
import {ExcelReader} from "../CommonFiles/ReadFromXL"
var ReadFromXL = new ExcelReader();
import {DataDictionary} from "../DataFiles/DictionaryData";
var DataDictLib1 = new DataDictionary();
var DataDictLib = new DataDictionary();
var path = require('path'); 
var filename = path.basename(__filename);
var Testcase=path.parse(filename).name
var TcRow=ReadFromXL.FindRowNum(Testcase,"CreateOrder");
DataDictLib.pushToDictionaryWithSheet(TcRow,"CreateOrder");
var NavIdValue =DataDictLib.getFromDictionary('NavIdValue');
var rownumber =DataDictLib.getFromDictionary('Rateoption');
var TcRow1=ReadFromXL.FindRowNum(Testcase,"CommonData");
DataDictLib1.pushToDictionaryWithSheet(TcRow,"CommonData");
var Navigationvalue =DataDictLib.getFromDictionary('CreateTitle');

describe("OM_R1ST_MOCQLF_TC008", () => { // suite in Jasmine
  it("Navigating to Create order page",() => {
  
    common.Get_url(Testcase);    
    common.SignIn(Testcase); 
    browser.sleep(5000);       
    common.NavigationFunction(Navigationvalue,Testcase); 
    ORDRegression.Enteringdata(Testcase);    
    ORDRegression.Freightcharges("3rd");
    ORDRegression.Shipmentdetails(Testcase);
    ORDRegression.Equipment(Testcase);
    browser.sleep(4000);
    ORDRegression.utilities("Comment","Delete");
    ORDRegression.utilities("Reference","Add");
    browser.sleep(3000);   
   //ORDRegression.utilities("Charge","Delete");
     ORDRegression.AddstopsOrigin(Testcase,"","NULL","18/Jan/2018");
     //ORDRegression.utilities("Reference","Delete");  
    ORDRegression.AddstopsDestination(Testcase,"","NULL","19/Jan/2018");
    reuse.ClickButtonwithText("Next");
    browser.sleep(45000);  

    //ORDRegression.ElementWait(true,ORDRegobject.Shippingpage); 
    ORDShipping.ClickRateoption(Testcase,rownumber);
    //reuse.ClickButtonwithText("Create")
    browser.sleep(20000);  
    browser.executeScript("window.scrollTo(0,2000)"); 
    ORDViewOrder.OrderHistory();  
});      
})



