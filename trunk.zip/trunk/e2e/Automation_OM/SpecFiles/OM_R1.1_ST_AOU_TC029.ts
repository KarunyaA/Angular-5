import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";

import { CreateOrderFunctions} from "../PageFiles/OM_CreateOrder";
let ORDRegression  = new  CreateOrderFunctions;
import {ShippingOptionFunctions} from "../PageFiles/OM_ShippingOption";
let ORDShipping  = new ShippingOptionFunctions;
import {ViewOrderFunctions} from "../PageFiles/OM_ViewOrderDetails";
let ORDViewOrder = new ViewOrderFunctions;

import {Update_Objects} from "../ObjectRepository/Objects_Order"
import { async } from "q";
import {CommonFunctions} from "../FunctionalLibrary/CommonFunctions"
var common= new CommonFunctions() 
import {ReusableFunctions} from "../FunctionalLibrary/ReusableFunctions" 
let reuse= new ReusableFunctions();
let ORDRegobject=new Update_Objects();
import {ExcelReader} from "../CommonFiles/ReadFromXL"
var ReadFromXL = new ExcelReader();
import {DataDictionary} from "../DataFiles/DictionaryData";

var DataDictLib = new DataDictionary();
var path = require('path'); 
var filename = path.basename(__filename);
var Testcase=path.parse(filename).name
var TcRow=ReadFromXL.FindRowNum(Testcase,"CreateOrder");
DataDictLib.pushToDictionaryWithSheet(TcRow,"CreateOrder");
var NavIdValue =DataDictLib.getFromDictionary('NavIdValue');
var rownumber =DataDictLib.getFromDictionary('Rateoption');
var Navigationvalue =DataDictLib.getFromDictionary('CreateTitle');
describe("OM_R1.1_ST_AOU_TC029", () => { // suite in Jasmine
    it("Navigate to Create order page",() => {

        common.Get_url(Testcase);
        // browser.sleep(2000);
         common.SignIn(Testcase); 
         browser.sleep(10000);       
        //  common.NavigationFunction("Create New Order",Testcase);
        //  ORDRegression.Enteringdata(Testcase);
        //  ORDRegression.AddstopsOrigin(Testcase,"Scheduled","NULL","19/Mar/2018");
        // ORDRegression.AddstopsDestination(Testcase,"Scheduled","Null","20/Mar/2018");
        //  reuse.ClickButtonwithText("Next");
        // browser.sleep(50000);
        // //browser.executeScript("window.scrollTo(0,-500)");
        // ORDShipping.ClickRateoption(Testcase,rownumber);   
        //  browser.sleep(15000);
        //  browser.executeScript("window.scrollTo(0,2000)");
        ORDViewOrder.UpdateEquip();


    })})