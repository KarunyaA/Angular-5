import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";

import { CreateOrderFunctions } from "../PageFiles/OM_CreateOrder";
let ORDRegression = new CreateOrderFunctions;
import { ShippingOptionFunctions } from "../PageFiles/OM_ShippingOption";
let ORDShipping = new ShippingOptionFunctions;
import { Update_Objects } from "../ObjectRepository/Objects_Order"
import { async } from "q";
import { CommonFunctions } from "../FunctionalLibrary/CommonFunctions"
var common = new CommonFunctions()
import { ReusableFunctions } from "../FunctionalLibrary/ReusableFunctions"
let reuse = new ReusableFunctions();
import {TonuReconsign} from "../PageFiles/OM_TONU&Reconsignment"
let ORDTR = new TonuReconsign
let ORDRegobject = new Update_Objects();
import { ExcelReader } from "../CommonFiles/ReadFromXL"
var ReadFromXL = new ExcelReader();
import { DataDictionary } from "../DataFiles/DictionaryData";
import {CreateTemplateFunctions} from "../PageFiles/OM_CreateTemplate"
let TempFunctions = new CreateTemplateFunctions
var DataDictLib = new DataDictionary();
var path = require('path');
var filename = path.basename(__filename);
var Testcase = path.parse(filename).name
var TcRow = ReadFromXL.FindRowNum(Testcase, "CreateOrder");
DataDictLib.pushToDictionaryWithSheet(TcRow, "CreateOrder");
var NavIdValue = DataDictLib.getFromDictionary('NavIdValue');
var rownumber = DataDictLib.getFromDictionary('Rateoption');
var Navigationvalue = DataDictLib.getFromDictionary('CreateTitle');
var OrderNumber
describe("OM_R1.1_ST_TONU_TC009", () => { // suite in Jasmine
    it("Navigate to Create order page", async () => {
        common.Get_url(Testcase);
        browser.sleep(2000);
        common.SignIn(Testcase);
        browser.sleep(5000);
        common.NavigationFunction(Navigationvalue, Testcase);
        ORDRegression.Enteringdata(Testcase);
        ORDRegression.Shipmentdetails(Testcase);
        ORDRegression.AddstopsOrigin(Testcase, "Scheduled", "NULL", "19/Mar/2018");
        ORDRegression.AddstopsDestination(Testcase, "Scheduled", "NULL", "20/Mar/2018");
        reuse.ClickButtonwithText("Save");
        browser.sleep(25000);
        common.NavigateWhenToggleActive("Create Order");
        browser.sleep(2000);
        OrderNumber = await TempFunctions.TemplateSearch(Testcase);
        browser.sleep(12000);
        ORDRegobject.NextButton.click();
        browser.sleep(4000);                
        
        
        ORDRegobject.NextButton.click();
        browser.sleep(50000);
        ORDShipping.ClickRateoption(Testcase, rownumber);
        reuse.ClickButtonwithText("Create");
        browser.sleep(60000);
        browser.executeScript("window.scrollTo(0,-500)");
        ORDTR.TonuKeepOrderActiveNeg0(Testcase);
        ORDShipping.CreateWithoutRate();




    })


})