import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";

import { CreateOrderFunctions} from "../PageFiles/OM_CreateOrder";
let ORDRegression  = new  CreateOrderFunctions;
import {ShippingOptionFunctions} from "../PageFiles/OM_ShippingOption";
let ORDShipping  = new ShippingOptionFunctions;
import {ViewOrderFunctions} from "../PageFiles/OM_ViewOrderDetails";
let ORDViewOrder = new ViewOrderFunctions;

import {Update_Objects} from "../ObjectRepository/Objects_Order"
import { async } from "q";
import {CommonFunctions} from "../FunctionalLibrary/CommonFunctions"
var common= new CommonFunctions() 
import {ReusableFunctions} from "../FunctionalLibrary/ReusableFunctions" 
let reuse= new ReusableFunctions();
let ORDRegobject=new Update_Objects();
import {ExcelReader} from "../CommonFiles/ReadFromXL"
var ReadFromXL = new ExcelReader();
import {DataDictionary} from "../DataFiles/DictionaryData";

import {MonitoringFunctions} from "../PageFiles/OM_Sanity_Monitoring";
let MonitoringFunc = new MonitoringFunctions;

var DataDictLib = new DataDictionary();
var path = require('path'); 
var filename = path.basename(__filename);
var Testcase=path.parse(filename).name
import {AdvancedSearchFunctions} from "../PageFiles/OM_AdvancedSearch";
let ORDAdvance = new AdvancedSearchFunctions;
var TcRow=ReadFromXL.FindRowNum(Testcase,"CreateOrder");
DataDictLib.pushToDictionaryWithSheet(TcRow,"CreateOrder");
var NavIdValue =DataDictLib.getFromDictionary('NavIdValue');
var rownumber =DataDictLib.getFromDictionary('Rateoption');
var Navigationvalue =DataDictLib.getFromDictionary('CreateTitle');
var OrderNumber


describe("JBH_OM_Sanity_ServSet", () => { // suite in Jasmine
    it("Slashed Load- Set Appointment",async() => {

        //ExcepCreate
        // common.Get_url(Testcase);
        // browser.sleep(2000);
        // common.SignIn(Testcase); 
        // browser.sleep(8000);       
        // common.NavigationFunction("Create New Order",Testcase);
        // OrderNumber=await ORDRegression.Enteringdata(Testcase);
        // ORDRegression.AddstopsOrigin(Testcase,"NULL","NULL","19/Mar/2018");
        // ORDRegression.AddstopsDestination(Testcase,"Null","Null","20/Mar/2018");
        // reuse.ClickButtonwithText("Next");
        // browser.sleep(50000);
        // //browser.executeScript("window.scrollTo(0,-500)");
        // ORDShipping.ClickRateoption(Testcase,rownumber);   
        // browser.sleep(15000);


        //Launch the url
        common.Get_url(Testcase);
        common.SignIn(Testcase);
        browser.sleep(2000);
        MonitoringFunc.Task_Select(Testcase);
        browser.sleep(2000);
        MonitoringFunc.Filter_Search("402158");
        browser.sleep(10000);
        MonitoringFunc.SelectFirstinstance("402158");
        browser.sleep(5000);
        MonitoringFunc.SetAppnt();
        browser.sleep(1000); 
        browser.executeScript("window.scrollBy(0,500)");
        common.Selectcalendericon("24/Mar/2018", 0);
        browser.sleep(2000);
        common.SelectTime("06:00", 0);
        browser.sleep(2000);
        common.Selectcalendericon("25/Mar/2018", 1); 
        browser.sleep(2000);
        common.SelectTime("08:00", 1);
        browser.sleep(2000);
        MonitoringFunc.appoinment_Fun();
        browser.sleep(20000);
        MonitoringFunc.Error_Overide();

      })
    })