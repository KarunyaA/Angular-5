import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";

import {  CreateOrderFunctions } from "../PageFiles/OM_CreateOrder";
let ORDRegression = new CreateOrderFunctions;
import { ShippingOptionFunctions } from "../PageFiles/OM_ShippingOption";
let ORDShipping = new ShippingOptionFunctions;
import { ViewOrderFunctions } from "../PageFiles/OM_ViewOrderDetails";
let ORDViewOrder = new ViewOrderFunctions;

import { Update_Objects } from "../ObjectRepository/Objects_Order"
import { async } from "q";
import { CommonFunctions } from "../FunctionalLibrary/CommonFunctions"
var common = new CommonFunctions()
import  { ReusableFunctions }  from  "../FunctionalLibrary/ReusableFunctions"
let reuse = new ReusableFunctions();
let ORDRegobject = new Update_Objects();
import { ExcelReader } from "../CommonFiles/ReadFromXL"
var ReadFromXL = new ExcelReader();
import { DataDictionary } from "../DataFiles/DictionaryData";
import  { EOMFunctions }  from  "../PageFiles/OM_EOM";
let ORDEOM = new EOMFunctions
import { AdvancedSearchFunctions } from "../PageFiles/OM_AdvancedSearch";
let ORDAdvance = new AdvancedSearchFunctions;

var DataDictLib = new DataDictionary();
var  path  =  require('path');
var  filename  =  path.basename(__filename);
var  Testcase = path.parse(filename).name
var TcRow = ReadFromXL.FindRowNum(Testcase, "CreateOrder");
DataDictLib.pushToDictionaryWithSheet(TcRow, "CreateOrder");
var NavIdValue = DataDictLib.getFromDictionary('NavIdValue');
var rownumber = DataDictLib.getFromDictionary('Rateoption');
var Navigationvalue = DataDictLib.getFromDictionary('CreateTitle');
var DictOM = new DataDictionary();
var DictEOM = new DataDictionary();
var Dictconsolidate = new DataDictionary();
var DataDictLib = new DataDictionary();
var  path  =  require('path');
var  filename  =  path.basename(__filename);
var  Testcase = path.parse(filename).name;
var OMvals = DataDictLib.getFromDictionary('OMvalues');
var OrderNumber
var LoadID

describe("JBH_OM_R1ST_Backfill_TC007", () => { // suite in Jasmine
    it("Should Have a Title To be Verified", async () => {
        var TcRow = ReadFromXL.FindRowNum(Testcase, "CommonData");
        DataDictLib.pushToDictionaryWithSheet(TcRow, "CommonData");
        var NavIdValue = DataDictLib.getFromDictionary('NavIdValue');
        var rownumber = DataDictLib.getFromDictionary('NavIdValue');
        var urlName = DataDictLib.getFromDictionary('UrlName');
        var Navigationvalue = DataDictLib.getFromDictionary('CreateTitle');
        common.Get_url(Testcase);
        // browser.sleep(2000);
        common.SignIn(Testcase); 
        browser.sleep(8000);       
      //   common.NavigationFunction("Create New Order",Testcase);
      //   OrderNumber=await ORDRegression.Enteringdata(Testcase);
      //   //ORDRegression.ClickButtonwithText("Next");
      //   //ORDRegression.Enteringdata(Testcase);
       ORDRegression.AddstopsOrigin(Testcase,"NULL","NULL","30/Mar/2018");
      //   ORDRegression.AddstopsDestination(Testcase,"NULL","Null","31/Mar/2018");
      //   reuse.ClickButtonwithText("Next");
      //   browser.sleep(50000);
      //  //browser.executeScript("window.scrollTo(0,-500)");
      //   ORDShipping.ClickRateoption(Testcase,rownumber);   
      //   browser.sleep(15000);
      //   browser.executeScript("window.scrollTo(0,2000)"); 
      //   common.NavigateWhenToggleActive("Advanced Search");
      //   browser.sleep(8000);    
      //   ORDAdvance.AdvancedSearchforOrder(OrderNumber,"03/30/2018","03/31/2018","Acccepted");
      //   browser.sleep(20000);

        ORDViewOrder.FetchDatafromOM();
        browser.sleep(5000);  
        browser.executeScript("window.scrollTo(0,-500)");
        await  ORDViewOrder.FetchDatafromOM().then((text)=>{          
          DictOM = text 
        }) ;
        browser.sleep(5000);  
        browser.executeScript("window.scrollTo(0,700)");         
        LoadID = await ORDViewOrder.RoutePlan(Testcase);
        console.log(LoadID)
        console.log(DictOM["BusUnit"]);
        console.log(DictOM["Billto"]);
        console.log(DictOM["totalmile"])
        browser.get("http://eom-dev.jbhunt.com/eom/search/eomSearch.face");
        common.AlternateLogin();
        browser.sleep(5000);
        ////browser.get("http://eom-dev.jbhunt.com/eom/search/eomSearch.face");
        ORDEOM.NavigateEOM(LoadID);
        ORDEOM.FetchDatafromEOM();
        browser.sleep(5000);
        await ORDEOM.FetchDatafromEOM().then((text)=>{
        DictEOM = text 
        });
        // console.log(DictEOM["BusUnit_EOM"]);
          
        

         ORDViewOrder.CompareValues(Testcase,DictOM,DictEOM);

    });
});

