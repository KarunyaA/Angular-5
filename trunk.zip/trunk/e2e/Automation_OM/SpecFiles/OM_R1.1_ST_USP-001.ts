import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";
import { async } from "q";
import {CommonFunctions} from "../FunctionalLibrary/CommonFunctions"
var common= new CommonFunctions() 
import {ReusableFunctions} from "../FunctionalLibrary/ReusableFunctions" 
let reuse= new ReusableFunctions();
import {ExcelReader} from "../CommonFiles/ReadFromXL"
var ReadFromXL = new ExcelReader();
import {DataDictionary} from "../DataFiles/DictionaryData";
var DataDictLib = new DataDictionary();
import {CreateOrderFunctions} from "../PageFiles/OM_CreateOrder";
let ORDCreate  = new CreateOrderFunctions;
import {ShippingOptionFunctions} from "../PageFiles/OM_ShippingOption";
let ORDShipping  = new ShippingOptionFunctions;
import {ViewOrderFunctions} from "../PageFiles/OM_ViewOrderDetails";
let ORDViewOrder  = new ViewOrderFunctions;
import {CreateTemplateFunctions} from "../PageFiles/OM_CreateTemplate";
let ORDCreateTemplate  = new CreateTemplateFunctions;
import {AdvancedSearchFunctions} from "../PageFiles/OM_AdvancedSearch";
let ORDAdvSearch  = new AdvancedSearchFunctions;
var path = require('path'); 
var filename = path.basename(__filename);
var Testcase=path.parse(filename).name

var TcRow=ReadFromXL.FindRowNum(Testcase,"CreateOrder");
DataDictLib.pushToDictionaryWithSheet(TcRow,"CreateOrder");
var NavIdValue =DataDictLib.getFromDictionary('NavIdValue');
var rownumber =DataDictLib.getFromDictionary('Rateoption');
var Navigationvalue =DataDictLib.getFromDictionary('CreateTitle');
var icon_loading=element(by.xpath("//*[@class='spinner' and @role='progressbar']"));

describe("OM_R1.1_ST_USP-001--->", () => { // suite in Jasmine
  it("Navigate to Create order page",() => {
   
    common.Get_url(Testcase);
    common.SignIn(Testcase);    
    browser.waitForAngular();
    //browser.sleep(8000);
    common.NavigatefromDashboard("Advanced Search");
    browser.waitForAngular();
    browser.sleep(5000);
    ORDAdvSearch.AdvancedSearchByBUSO(Testcase,"JBT","OTR");
    // browser.sleep(5000)
    // ORDViewOrder.VerifyTextisPresent("JBT","OTR")
    // ORDViewOrder.VerifyEditEnabled();
    // ORDViewOrder.ClickBackOrder()
    // ORDAdvSearch.AdvancedSearchByBUSO(Testcase,"JBI","Backhaul");
    // browser.sleep(5000)
    // ORDViewOrder.VerifyTextisPresent("JBI","Backhaul")
    // ORDViewOrder.VerifyEditEnabled();
    // ORDViewOrder.ClickBackOrder()
    // ORDAdvSearch.AdvancedSearchByBUSO(Testcase,"JBI","Intermodal");
    // browser.sleep(5000)
    // ORDViewOrder.VerifyTextisPresent("JBI","Intermodal")
    // ORDViewOrder.VerifyEditEnabled();
    // ORDViewOrder.ClickBackOrder()
    // ORDAdvSearch.AdvancedSearchByBUSO(Testcase,"DCS","Backhaul");
    // browser.sleep(5000)
    // ORDViewOrder.VerifyTextisPresent("DCS","Backhaul")
    // ORDViewOrder.VerifyEditEnabled();
    // ORDViewOrder.ClickBackOrder()
    // ORDAdvSearch.AdvancedSearchByBUSO(Testcase,"DCS","Backhaul");
    // browser.sleep(5000)
    // ORDViewOrder.VerifyTextisPresent("DCS","Dedicated")
    // ORDViewOrder.VerifyEditEnabled();
    // ORDViewOrder.ClickBackOrder()
    // ORDAdvSearch.AdvancedSearchByBUSO(Testcase,"DCS","Dedicated");
    // browser.sleep(5000)
    // ORDViewOrder.VerifyTextisPresent("DCS","Backhaul")
    // ORDViewOrder.VerifyEditEnabled();
    // ORDViewOrder.ClickBackOrder()
    // ORDAdvSearch.AdvancedSearchByBUSO(Testcase,"ICS","Brokerage");
    // browser.sleep(5000)
    // ORDViewOrder.VerifyTextisPresent("ICS","Brokerage")
    // ORDViewOrder.VerifyEditEnabled();
    // ORDViewOrder.ClickBackOrder()
    // ORDAdvSearch.AdvancedSearchByBUSO(Testcase,"ICS","Reefer");
    // browser.sleep(5000)
    // ORDViewOrder.VerifyTextisPresent("ICS","Reefer")
    // ORDViewOrder.VerifyEditEnabled();
    // ORDViewOrder.ClickBackOrder()
    // ORDAdvSearch.AdvancedSearchByBUSO(Testcase,"ICS","Maritime");
    // browser.sleep(5000)
    // ORDViewOrder.VerifyTextisPresent("ICS","Maritime")
    // ORDViewOrder.VerifyEditEnabled();
    // ORDViewOrder.ClickBackOrder()
    // ORDAdvSearch.AdvancedSearchByBUSO(Testcase,"ICS","Flatbed");
    // browser.sleep(5000)
    // ORDViewOrder.VerifyTextisPresent("ICS","Flatbed")
    // ORDViewOrder.VerifyEditEnabled();
    // ORDViewOrder.ClickBackOrder()
    // ORDAdvSearch.AdvancedSearchByBUSO(Testcase,"ICS","LTL");
    // browser.sleep(5000)
    // ORDViewOrder.VerifyTextisPresent("ICS","LTL")
    // ORDViewOrder.VerifyEditEnabled();
    // ORDViewOrder.ClickBackOrder()
})

})

