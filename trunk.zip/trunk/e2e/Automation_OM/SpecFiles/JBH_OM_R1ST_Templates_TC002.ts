import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";

import { CreateOrderFunctions} from "../PageFiles/OM_CreateOrder";
let ORDRegression  = new  CreateOrderFunctions;
import {ShippingOptionFunctions} from "../PageFiles/OM_ShippingOption";
let ORDShipping  = new ShippingOptionFunctions;
import {ViewOrderFunctions} from "../PageFiles/OM_ViewOrderDetails";
let ORDViewOrder = new ViewOrderFunctions;

import {Update_Objects} from "../ObjectRepository/Objects_Order"
import { async } from "q";
import {CommonFunctions} from "../FunctionalLibrary/CommonFunctions"
var common= new CommonFunctions() 
import {ReusableFunctions} from "../FunctionalLibrary/ReusableFunctions" 
let reuse= new ReusableFunctions();
let ORDRegobject=new Update_Objects();
import {ExcelReader} from "../CommonFiles/ReadFromXL"
var ReadFromXL = new ExcelReader();
import {DataDictionary} from "../DataFiles/DictionaryData";
import {CreateTemplateFunctions} from "../PageFiles/OM_CreateTemplate"
let TempFunctions = new CreateTemplateFunctions
var DataDictLib1 = new DataDictionary();
var DataDictLib = new DataDictionary();
var path = require('path'); 
var filename = path.basename(__filename);
var Testcase=path.parse(filename).name
var TcRow=ReadFromXL.FindRowNum(Testcase,"CreateOrder");
DataDictLib.pushToDictionaryWithSheet(TcRow,"CreateOrder");
var NavIdValue =DataDictLib.getFromDictionary('NavIdValue');
var rownumber =DataDictLib.getFromDictionary('Rateoption');
var TcRow1=ReadFromXL.FindRowNum(Testcase,"CommonData");
DataDictLib1.pushToDictionaryWithSheet(TcRow1,"CommonData");
var Navigationvalue =DataDictLib.getFromDictionary('CreateTitle');


describe("JBH_OM_R1ST_Templates_TC002", () => { // suite in Jasmine
    it("Template Creation",() => {
        common.Get_url(Testcase);
        browser.sleep(5000);
        common.SignIn(Testcase);
        common.NavigationFunction(Navigationvalue,Testcase);
        ORDRegression.Enteringdata(Testcase);
        // ORDRegression.AddstopsOrigin(Testcase,"","Null","26/Mar/2017");
        // ORDRegression.AddstopsDestination(Testcase,"","Null","27/Mar/2017");
        // reuse.ClickButtonwithText("Save");
        // browser.sleep(20000);       
        common.NavigateWhenToggleActive("Create Order");
        browser.sleep(5000);
        TempFunctions.TemplateSearch(Testcase);
       //reuse.ClickButtonwithText("Trailing Equipment");
       browser.sleep(5000);  
       browser.executeScript("window.scrollTo(0,200)");
        ORDRegression.Equipment(Testcase);
        ORDRegobject.NextButton.click();
        browser.sleep(3000);
       // ORDRegression.HazmatDetails();
       browser.executeScript("window.scrollTo(0,200)");
        reuse.ClickButtonwithText("Save");
        browser.sleep(8000);
        browser.executeScript("window.scrollTo(0,-500)");
        ORDRegression.Overrideall();
        browser.sleep(60000);
        ORDShipping.ValidateRateOption();
        ORDShipping.ClickRateoption(Testcase,rownumber);
        browser.sleep(15000); 
        ORDShipping.CreateWithoutRate();
        browser.executeScript("window.scrollTo(0,2000)"); 
        ORDViewOrder.OrderHistory();



    });
    
       
        
    });

    