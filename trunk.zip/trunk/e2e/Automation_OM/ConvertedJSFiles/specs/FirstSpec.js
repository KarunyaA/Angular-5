"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/* tslint:disable */
const protractor_1 = require("protractor");
describe("Account Creation and Search ", () => {
    it("Should Have a Title To be Verified", () => {
        // console.log((<any>data).SearchAccountDetails);
        // browser.get(page.Call_url());
        protractor_1.browser.get("http://account-tst.jbhunt.com/account/");
    });
    it("Should Navigate To Account Page", () => {
        //console.log(page.btn_navtoggle);
        //element(by.css(page.obj_NavigationToggle())).click();
        // element(by.css(page.obj_NavigationToggle())).click();
        protractor_1.element(protractor_1.by.css("[class=\"fa fa-circle-o\"]")).click();
        protractor_1.element(protractor_1.by.className(""));
        protractor_1.browser.executeScript("window.scrollBy(-2000, 0)");
        //page.lst_NavigationList.click();
        //element.all(by.cssContainingText(".routeDisplayText","Account")).click();
    });
});
//# sourceMappingURL=FirstSpec.js.map