"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const protractor_1 = require("protractor");
const ptor_1 = require("protractor/built/ptor");
const Objects_Order_1 = require("../ObjectRepository/Objects_Order");
const ViewOrder_1 = require("../PageFiles/ViewOrder");
//import {LaunchUrl} from "../ObjectRepository/Objects_Order"
let ObjRul = new Objects_Order_1.Update_Objects();
let ObjORD = new ViewOrder_1.Ord_Func;
// var ExcelDataSourceForConf = require('../CommonFiles/ReadFromXL');
// var ReadFromXL = new ExcelDataSourceForConf();
// var PushAndPullDataDictLib = require('../DataFiles/DictionaryData');
// var DataDictLib = new PushAndPullDataDictLib();
const ReadFromXL_1 = require("../CommonFiles/ReadFromXL");
var ReadFromXL = new ReadFromXL_1.ExcelReader();
const DictionaryData_1 = require("../DataFiles/DictionaryData");
var DataDictLib = new DictionaryData_1.DataDictionary();
var TcRow = ReadFromXL.FindRowNum("TC003");
console.log("TC row: " + TcRow);
DataDictLib.pushToDictionary(TcRow);
var str_BU = DataDictLib.getFromDictionary("BU");
class Rul_Func {
    //     Launch_Url(){
    //         browser.get(ObjRul.url);
    //         //this.SignIn("TC003");
    //         ObjRul.togglefield.click();
    //          ObjRul.dbOption.click();
    //          ObjRul.searchoption.click();
    //          this.ElementWait(true,ObjRul.adv_title);
    //          this.AdvancedSearch();
    //         //browser.sleep(2000);
    //         //this.AdvancedSearchDatevieworder();
    // }
    Activate() {
        this.ElementWait(true, ObjRul.Rulename);
        ObjRul.filter_clk.click();
        protractor_1.browser.sleep(2000);
        protractor_1.browser.executeScript("window.scrollTo(0,200)");
        ObjRul.status_clk.click();
        protractor_1.browser.sleep(2000);
        ObjRul.active_cb.click();
        protractor_1.browser.sleep(2000);
        protractor_1.browser.executeScript("window.scrollTo(0,-200)");
        ObjRul.association_clk.click();
        ObjRul.BU_cb.click();
        protractor_1.browser.sleep(3000);
        ObjRul.active_cb.click();
        protractor_1.browser.sleep(2000);
        protractor_1.browser.executeScript("window.scrollTo(0,-200)");
        ObjRul.threedot_btn.first().click();
        protractor_1.browser.sleep(2000);
        ObjRul.copyrule.click();
        //ObjRul.view_btn.click();
        //ObjRul.view_btn.click();
        protractor_1.browser.sleep(5000);
        protractor_1.browser.executeScript("window.scrollTo(0,-200)");
        // browser.sleep(5000);
        protractor_1.browser.waitForAngularEnabled();
        ObjRul.BU_btn.click();
        ObjRul.BU_btn.click();
        protractor_1.browser.sleep(5000);
        this.dropdown(ObjRul.BU_list, str_BU);
        //browser.sleep(10000);
        // browser.executeScript("window.scrollTo(0,500)");
        protractor_1.browser.sleep(5000);
        // ObjRul.Save_Btn.click();
        // ObjRul.Save_Btn.click();
        protractor_1.browser.waitForAngularEnabled();
    }
    Inactivate() {
        ObjORD;
        ObjRul.filter_clk.click();
        protractor_1.browser.sleep(2000);
        protractor_1.browser.executeScript("window.scrollTo(0,200)");
        ObjRul.status_clk.click();
        ObjRul.active_cb.click();
        protractor_1.browser.sleep(5000);
        protractor_1.browser.executeScript("window.scrollTo(0,-200)");
        ObjRul.association_clk.click();
        ObjRul.BU_cb.click();
        protractor_1.browser.sleep(5000);
        ObjRul.active_cb.click();
        protractor_1.browser.sleep(2000);
        protractor_1.browser.executeScript("window.scrollTo(0,-200)");
        ObjRul.threedot_btn1.click();
        protractor_1.browser.waitForAngularEnabled();
        ObjRul.Inactivate_btn.click();
        protractor_1.browser.waitForAngularEnabled();
        //ObjRul.BU_btn.sendKeys("DCS-Dedicated");
        //  ObjRul.BU_btn.sendKeys(protractor.Key.ENTER);
    }
    AdvancedSearch() {
        //this.NavigatefromDashboard("Advanced Search");
        protractor_1.browser.sleep(3000);
        var allOptions = protractor_1.element.all(protractor_1.by.xpath("//*[@class='inline']//ng-select[@placeholder='Type'][1]"));
        allOptions.get(0).click();
        protractor_1.browser.sleep(2000);
        allOptions.sendKeys(ptor_1.protractor.Key.ENTER);
        //ObjRul.accountname.sendKeys("Pipelife");
        protractor_1.browser.sleep(3000);
        // ObjRul.accountnameselect.click();
        //ObjRul.accountname.sendKeys(protractor.Key.ENTER);
        protractor_1.browser.sleep(3000);
        //if(ObjRul.Status.isElementPresent.then(found => expect(found).toBe(false)))
        ObjRul.Showmore.click();
        protractor_1.browser.sleep(3000);
        protractor_1.browser.executeScript("window.scrollTo(0,-200)");
        protractor_1.browser.sleep(2000);
        //ObjRul.Statuschange.sendKeys("Peending");
        //ObjRul.Statuschange.sendKeys(protractor.Key.ENTER);
        protractor_1.browser.executeScript("window.scrollTo(0,200)");
        ObjRul.Destin.click();
        allOptions.get(2).click();
        ObjRul.OrdersearchBU.click();
        //ObjRul.busearch.sendKeys("JBT");       
        //ObjRul.BUclick.sendKeys(protractor.Key.ENTER);
        //this.ElementWait(true,ObjRul.OrderSearchSO);
        //ObjRul.OrderSearchSO.click();       
        //ObjRul.Sosearch.sendKeys("OTR");        
        //ObjRul.SOclick.sendKeys(protractor.Key.ENTER);
        ObjRul.SearchButton.click();
        protractor_1.browser.executeScript("window.scrollTo(0,-200)");
        ObjRul.SelectFirstorder.get(0).click();
        //this.ElementWait(true,ObjRul.Viewpage);
    }
    RoutePlan() {
        protractor_1.browser.executeScript("window.scrollTo(0,200)");
        protractor_1.browser.sleep(5000);
        ObjRul.routeplan.click();
        protractor_1.browser.executeScript("window.scrollTo(0,-200)");
        ObjRul.load.getText().then((elem) => {
            if (elem != "")
                console.log("Load id is generated for the order" + elem);
        });
    }
    RateSheet() {
        this.ElementWait(true, ObjRul.Rulename);
        protractor_1.browser.executeScript("window.scrollTo(0,200)");
        protractor_1.browser.sleep(5000);
        ObjRul.ratesheet.click();
        this.ElementWait(true, ObjRul.rate_level);
        ObjRul.rate_edit.isPresent().then((elem) => {
            if (elem === true) {
                console.log("edit button is present");
                ObjRul.rate_edit.click();
            }
            else {
                console.log("edit button is not present");
            }
        });
    }
    SignIn(Testcasename) {
        console.log(Testcasename);
        var TcRow = ReadFromXL.FindRowNum(Testcasename);
        DataDictLib.pushToDictionary(TcRow);
        var username = DataDictLib.getFromDictionary('Username');
        var Password = DataDictLib.getFromDictionary('Password');
        ObjRul.SignIn.isDisplayed().then((elem) => {
            if (elem === true)
                ObjRul.SignInUser.sendKeys(username);
            ObjRul.SignInPwd.sendKeys(Password);
            ObjRul.SignInSubmit.click();
            protractor_1.browser.sleep(2000);
        });
    }
    ElementWait(elemValCheck, OBJelem) {
        return __awaiter(this, void 0, void 0, function* () {
            var cntr = 0;
            var displayvalue = false;
            var textvalue = "";
            var value = false;
            while (value === false) {
                protractor_1.browser.sleep(3000);
                yield OBJelem.isPresent().then((elem) => {
                    console.log(cntr + "th time");
                    displayvalue = elem;
                    console.log("1st scope" + displayvalue);
                });
                protractor_1.browser.sleep(3000);
                if (elemValCheck == true && displayvalue.valueOf() === true) {
                    console.log(" entering into text validation");
                    yield OBJelem.getText().then((elem1) => {
                        console.log(cntr + "th time");
                        textvalue = elem1;
                        console.log("2nd scope" + textvalue);
                    });
                }
                if (cntr > 12) {
                    break;
                }
                if (elemValCheck == true) {
                    if (textvalue !== "")
                        value = displayvalue;
                    else
                        value = false;
                }
                else
                    value = displayvalue;
                console.log(value);
                cntr++;
            }
        });
    }
    dropdown(Objelement, strval) {
        //var value = BU
        Objelement.count().then(function (total) {
            Objelement.each(function (item) {
                var index = 0;
                if (total > index) {
                    var Disp = item.getText().then((elem) => {
                        if (elem.trim() === strval) {
                            item.click();
                            protractor_1.browser.sleep(10000);
                            ObjRul.Save_Btn.click();
                            protractor_1.browser.sleep(10000);
                        }
                        else {
                            console.log("View drop down is not available with the values");
                        }
                    });
                }
            });
        });
    }
}
exports.Rul_Func = Rul_Func;
//# sourceMappingURL=RulePage.js.map