"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const protractor_1 = require("protractor");
const ptor_1 = require("protractor/built/ptor");
const Objects_Order_1 = require("../ObjectRepository/Objects_Order");
//import {Rul_Func} from "../PageFiles/RulePage"
// declare var ActiveXObject: (type: string) => void;
let ObjORD = new Objects_Order_1.Update_Objects();
//let RUL = new Rul_Func();
// var ExcelDataSourceForConf = require('../CommonFiles/ReadFromXL');
// var ReadFromXL = new ExcelDataSourceForConf();
const ReadFromXL_1 = require("../CommonFiles/ReadFromXL");
var ReadFromXL = new ReadFromXL_1.ExcelReader();
const DictionaryData_1 = require("../DataFiles/DictionaryData");
var DataDictLib = new DictionaryData_1.DataDictionary();
var PushAndPullDataDictLib = require('../DataFiles/DictionaryData');
//readvaluesfromexcel
//     var TcRow = ReadFromXL.FindRowNum("TC001");
//     console.log("TC row: "+TcRow);
//     DataDictLib.pushToDictionary(TcRow); 
var str_BU = DataDictLib.getFromDictionary("BU");
var str_SO = DataDictLib.getFromDictionary("SO");
var strequip = DataDictLib.getFromDictionary("Equipment");
var BUvalidate = protractor_1.element(protractor_1.by.xpath("//*[text()='DCS']"));
var str_Access = DataDictLib.getFromDictionary("Access");
class Ord_Func {
    // launch URL
    //  Launch_Url(){
    //             browser.get(ObjORD.url);
    //             browser.sleep(3000);
    //             this.SignIn("TC001");
    //             browser.sleep(10000);
    //     }
    UpdateOrder(Testcasename) {
        var TcRow = ReadFromXL.FindRowNum(Testcasename);
        DataDictLib.pushToDictionary(TcRow);
        var str_Access = DataDictLib.getFromDictionary('Access');
        if (str_Access === "Yes") {
            var val = (ObjORD.updateBUSO_btn).isPresent().then((elem) => {
                if (elem === true) {
                    this.ElementWait(true, ObjORD.orderid);
                    this.UPDATEBUSO();
                    protractor_1.browser.sleep(5000);
                    //this.UpdateEquip();
                    console.log("The Create update access is available for the user");
                }
                else {
                    console.log("Update access is denied for the user");
                }
            });
        }
        else if (str_Access == "No") {
            console.log("going in");
            var val = (ObjORD.updateBUSO_btn).isPresent().then((elem) => {
                if (elem == true) {
                    console.log("Fail-Update Option is available");
                }
                else {
                    console.log("Pass-Access is denied as expected");
                }
            });
        }
    }
    Reconsignment(Testcasename) {
        var TcRow = ReadFromXL.FindRowNum(Testcasename);
        DataDictLib.pushToDictionary(TcRow);
        var str_Access = DataDictLib.getFromDictionary('Access');
        ObjORD.threedot.click();
        protractor_1.browser.sleep(5000);
        if (str_Access === "Yes") {
            var val = (ObjORD.updateBUSO_btn).isPresent().then((elem) => {
                var val = (ObjORD.reconsign).isPresent().then((elem) => {
                    if (elem === true) {
                        this.Reconsign();
                        protractor_1.browser.sleep(5000);
                        //this.UpdateEquip();
                        console.log("The Create update access is available for the user");
                    }
                    else {
                        console.log("Update access is denied for the user");
                    }
                });
            });
        }
        else if (str_Access == "No") {
            var val = (ObjORD.reconsign).isPresent().then((elem) => {
                if (elem == true) {
                    console.log("Fail-Update Option is available");
                }
                else {
                    console.log("Pass-Access is denied as expected");
                }
            });
        }
    }
    UPDATEBUSO() {
        ObjORD.updateBUSO_btn.click();
        protractor_1.browser.waitForAngularEnabled();
        //browser.sleep(2000);
        ObjORD.BU_update.click();
        ObjORD.BU_updateclck.sendKeys(str_BU);
        protractor_1.browser.sleep(2000);
        ObjORD.BU_updateclck.sendKeys(ptor_1.protractor.Key.ENTER);
        protractor_1.browser.sleep(2000);
        ObjORD.SO_update.click();
        ObjORD.SO_updateclck.sendKeys(str_SO);
        protractor_1.browser.sleep(5000);
        ObjORD.SO_updateclck.sendKeys(ptor_1.protractor.Key.ENTER);
        protractor_1.browser.sleep(2000);
        ObjORD.save_BUSO.click();
        protractor_1.browser.sleep(20000);
        //var validateBU =element(by.xpath("//*[text()='"+str_BU+"']"));
        var str_validateBU = ObjORD.validateBU;
        str_validateBU.getText().then(function (text) {
            console.log(text);
            if (text == str_BU) {
                console.log("Business Unit updated");
            }
        });
        protractor_1.browser.sleep(2000);
        var str_validateSO = ObjORD.validateSO;
        str_validateSO.getText().then(function (text) {
            console.log(text);
            if (text == str_SO) {
                console.log("Service Offering Updated");
            }
        });
    }
    UpdateEquip() {
        ObjORD.edit_equipment.click();
        //ObjORD.edit_equipment.click();
        protractor_1.browser.sleep(2000);
        ObjORD.equip_category.click();
        //ObjORD.equip_category.click();
        protractor_1.browser.sleep(2000);
        ObjORD.equipinput.sendKeys(strequip);
        protractor_1.browser.sleep(2000);
        ObjORD.equipinput.sendKeys(ptor_1.protractor.Key.ENTER);
        protractor_1.browser.sleep(2000);
        ObjORD.equipsave_Btn.click();
    }
    Reconsign() {
        ObjORD.threedot.click();
        ObjORD.threedot.click();
        protractor_1.browser.sleep(10000);
        ObjORD.reconsign.click();
        //ObjORD.reconsign.click();
        protractor_1.browser.sleep(10000);
        ObjORD.reason_btn.click();
        ObjORD.reason_btn.sendKeys("Product Damaged");
        ObjORD.reason_btn.sendKeys(ptor_1.protractor.Key.ENTER);
        ObjORD.reasoncomnts.click();
        ObjORD.reasoncomnts.sendKeys("Arun");
        //ObjORD.submit.click();
    }
    OrderHistory() {
        ObjORD.hstrybtn.click();
        protractor_1.browser.sleep(5000);
        // ObjORD.hstrytable.isPresent();
        var val = (ObjORD.hstrytable).isPresent().then((elem) => {
            if (elem === true) {
                console.log("Order History is  available");
                ObjORD.cnt;
                ObjORD.cnt.count().then((intcnt) => {
                    if (intcnt > 0) {
                        console.log("Records count is available" + intcnt);
                    }
                    else {
                        console.log("Records count are not found");
                    }
                });
            }
            else {
                console.log("Order History is not available");
            }
        });
    }
    ElementWait(elemValCheck, OBJelem) {
        return __awaiter(this, void 0, void 0, function* () {
            var cntr = 0;
            var displayvalue = false;
            var textvalue = "";
            var value = false;
            while (value === false) {
                protractor_1.browser.sleep(3000);
                yield OBJelem.isPresent().then((elem) => {
                    console.log(cntr + "th time");
                    displayvalue = elem;
                    console.log("1st scope" + displayvalue);
                });
                protractor_1.browser.sleep(3000);
                if (elemValCheck == true && displayvalue.valueOf() === true) {
                    console.log(" entering into text validation");
                    yield OBJelem.getText().then((elem1) => {
                        console.log(cntr + "th time");
                        textvalue = elem1;
                        console.log("2nd scope" + textvalue);
                    });
                }
                if (cntr > 12) {
                    break;
                }
                if (elemValCheck == true) {
                    if (textvalue !== "")
                        value = displayvalue;
                    else
                        value = false;
                }
                else
                    value = displayvalue;
                console.log(value);
                cntr++;
            }
        });
    }
    Database() {
        var sql = require("mssql");
        var connectionstring = "Data Source=OrderManagement_TST;Initial Catalog=OrderManagement_TST; Trusted_Connection=True;";
        var connection = new sql.Connection(connectionstring);
        connection.connect(function (err) {
            console.log(err);
        });
        // var connection = new ActiveXObject("ADODB.Connection");
        var request = new sql.Request(connection);
        request.query("SELECT TOP 1 * From(select Top 3 * from [OrderManagement4_TST].[ORD].[Order] where OrderStatusCode='Accepted' ORDER BY OrderID DESC) xORDER BY OrderID", function (err, recordeset) {
            var res = recordeset;
            console.log(res);
        });
        //        connection.Open(connectionstring);
        //        var rs = new ActiveXObject("ADODB.Recordset");
        //        rs.Open("SELECT TOP 1 * From(select Top 3 * from [OrderManagement4_TST].[ORD].[Order] where OrderStatusCode='Accepted' ORDER BY OrderID DESC) xORDER BY OrderID ", connection);
        //        console.log(rs)
    }
    RateSelection() {
        //        {
        //                 var index = 0;
        //                element.all(by.css('ul.menu li')).count().then(function(total) {
        //                  element.all(by.css('ul.menu li')).each(function (item) {
        //                    index++;
        //                    if(total === index) {
        //                      item.click();
        //                    }else 
        //                      item.click();
        //                    }
        //                  });
        //                }
        //              } 
        // }
        var Disp = protractor_1.element(protractor_1.by.xpath("//*[@class='visible']//following::span[text()='Market Rate'][last()]//following::span[1]")).getText().then((elem) => {
            if (elem !== "$0.00") {
                protractor_1.browser.sleep(5000);
                protractor_1.browser.executeScript("window.scrollTo(0,500)");
                protractor_1.element(protractor_1.by.xpath("//*[@class='visible']//following::span[text()='Market Rate'][last()]//following::span[@id='span-3dots']")).click();
                protractor_1.browser.sleep(5000);
                //browser.executeScript("window.scrollTo(0,-500)");
                protractor_1.browser.sleep(10000);
                //browser.executeScript("window.scrollTo(0,200)");
                protractor_1.browser.actions().mouseMove(ObjORD.createrate_btn);
                ObjORD.overall_hdr.click();
                ObjORD.createrate_btn.click();
                ObjORD.createrate_btn.click();
                protractor_1.browser.sleep(5000);
                ObjORD.chckbox.click();
                ObjORD.level.click();
                ObjORD.level.sendKeys("O");
                ObjORD.level.sendKeys(ptor_1.protractor.Key.ENTER);
                ObjORD.amntfield.sendKeys("");
            }
        });
    }
    SignIn(Testcasename) {
        console.log(Testcasename);
        var TcRow = ReadFromXL.FindRowNum(Testcasename);
        DataDictLib.pushToDictionary(TcRow);
        var username = DataDictLib.getFromDictionary('Username');
        var Password = DataDictLib.getFromDictionary('Password');
        ObjORD.SignIn.isDisplayed().then((elem) => {
            if (elem === true)
                ObjORD.SignInUser.sendKeys(username);
            ObjORD.SignInPwd.sendKeys(Password);
            ObjORD.SignInSubmit.click();
            protractor_1.browser.sleep(2000);
        });
    }
}
exports.Ord_Func = Ord_Func;
//Clicking the Edit Shipment 
//  EditShipment(){
//         expect(ObjORD.edit_shipment.isEnabled()).toBe(false)
//             ObjORD.edit_shipment.click();            
//         browser.sleep(10000);
// //Clicking the subtype 
//         ObjORD.subtype_clk.click();
//         ObjORD.subtype_val.click();
// //Clicking Autorate
//         ObjORD.autorate_clk.click();
// // Enter OrderValue
//         ObjORD.ordval.sendKeys("200");
//         browser.sleep(2000);
// // Clicking the ShipmentRequirement
//         ObjORD.shipmentreq_clk.click();
//         ObjORD.shipmentreq_clk.click();
//         ObjORD.shipmentreq_val.click();
// // Save
//         ObjORD.Save_Btn.click();
//         ObjORD.Save_Btn.click();
//         browser.sleep(10000)
//         var valueedit=element(by.css("[class='price-tag']"));
//         valueedit.getText().then(function(text) {
//         console.log(text);
//         if(text=="$200200"){
//                 console.log("updated")
//         }
//         }); 
//         var updtsubtype=element(by.cssContainingText("[class='price-value nopadding']","Sub Type"));
//         updtsubtype.getText().then(function(text){
//                 console.log(text);
//                 if(text=="Non-Managed"){
//                                 console.log("subtypeupdated")
//                                 }
//         });
// }
// // Editing the Equipment Details
// EditEquipment(){
//         ObjORD.edit_equipment.click();
//         //ObjORD.edit_equipment.click();
//         browser.sleep(2000);
//         ObjORD.equip_category.click();
//         ObjORD.equip_category.click();
//         browser.sleep(2000);
//         ObjORD.equip_ctgrytype.click();
//         browser.sleep(5000);
//         ObjORD.equip_type.click();
//         browser.sleep(2000);
//         //ObjORD.equip_type.click();
//         ObjORD.equip_types.click();
//         browser.sleep(2000);
//         //ObjORD.equip_length.click();
//         //ObjORD.equip_length.click();
//         //ObjORD.equip_size.click();
//         //ObjORD.equipsave_Btn.click();
//     }
// //Editing BU-SO
// EditBUSO(){
// ObjORD.updateBUSO.click();
// ObjORD.updateBUSO.click();
// browser.sleep(8000);
// ObjORD.edit_BU.click();
// ObjORD.enter_BU.click();
// browser.sleep(5000);
// ObjORD.edit_SO.click();
// ObjORD.enter_SO.click();
// browser.sleep(5000);
// ObjORD.save_BUSO.click();
// browser.sleep(5000);
// }
// ObjORD.updateBUSO.isEnabled().then((elem)=>{ 
//         if (elem===true){
//         this.UpdateBUSO();
//         this.UpdateEquip();
//         }
//         else{
//         }
//         });
// this.UpdateBUSO();
// this.UpdateEquip(); 
//# sourceMappingURL=ViewOrder.js.map