"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const protractor_1 = require("protractor");
const ptor_1 = require("protractor/built/ptor");
const Regressionobjects_1 = require("../ObjectRepository/Regressionobjects");
const ReadFromXL_1 = require("../CommonFiles/ReadFromXL");
const DictionaryData_1 = require("../DataFiles/DictionaryData");
//let ObjAP = new LaunchUrl(); 
let OBJCreate = new Regressionobjects_1.Update_Objects();
var ReadFromXL = new ReadFromXL_1.ExcelReader();
var DataDictLib = new DictionaryData_1.DataDictionary();
let ObjORD = new Regressionobjects_1.Update_Objects();
var ExcelDataSourceForConf = require('../CommonFiles/ReadFromXL');
var PushAndPullDataDictLib = require('../DataFiles/DictionaryData');
class ReusableFunctions {
    Get_url(Testcasename) {
        console.log(Testcasename);
        var TcRow = ReadFromXL.FindRowNum(Testcasename, "data");
        DataDictLib.pushToDictionaryWithSheet(TcRow, "data");
        var urlName = DataDictLib.getFromDictionary('UrlName');
        console.log(urlName);
        protractor_1.browser.get(urlName); //overrides baseURL      
    }
    SignIn(Testcasename) {
        console.log(Testcasename);
        var TcRow = ReadFromXL.FindRowNum(Testcasename, "data");
        DataDictLib.pushToDictionaryWithSheet(TcRow, "data");
        var username = DataDictLib.getFromDictionary('Username');
        var Password = DataDictLib.getFromDictionary('Password');
        OBJCreate.SignIn.isDisplayed().then((elem) => {
            if (elem === true)
                OBJCreate.SignInUser.sendKeys(username);
            OBJCreate.SignInPwd.sendKeys(Password);
            OBJCreate.SignInSubmit.click();
            protractor_1.browser.sleep(2000);
        });
    }
    EnterTextBox(IdValue, Value) {
        var tagname = protractor_1.element(protractor_1.by.css("[formcontrolname=\"" + IdValue + "\"]"));
        tagname.clear();
        tagname.sendKeys(Value);
    }
    SelectDRopdownValue(IdValue) {
        var tagname = protractor_1.element(protractor_1.by.css("[placeholder=\"" + IdValue + "\"]"));
        tagname.click();
        protractor_1.browser.sleep(2000);
        tagname.sendKeys(ptor_1.protractor.Key.ENTER);
        //OBJCreate.ContactValue.click();
    }
    NavigatefromDashboard(Pagename) {
        OBJCreate.togglefield.click();
        var dbOption = protractor_1.element(protractor_1.by.cssContainingText(".routeDisplayText", "" + Pagename + ""));
        dbOption.click();
        protractor_1.browser.sleep(3000);
    }
    NavigateWhenToggleActive(Pagename) {
        //OBJCreate.togglefield.click();
        var dbOption = protractor_1.element(protractor_1.by.cssContainingText(".routeDisplayText", "" + Pagename + ""));
        dbOption.click();
        protractor_1.browser.sleep(3000);
    }
    NavigationFunction(Flowvalue, Testcasename) {
        var TcRow = ReadFromXL.FindRowNum(Testcasename, "data");
        DataDictLib.pushToDictionaryWithSheet(TcRow, "data");
        var NavIdValue = DataDictLib.getFromDictionary('NavIdValue');
        // var NavIdValue =DataDictLib.getFromDictionary('NavIdValue');
        protractor_1.browser.sleep(2000);
        this.NavigatefromDashboard(NavIdValue);
        protractor_1.browser.executeScript("window.scrollBy(-2000, 0)");
        protractor_1.browser.sleep(4000);
        var Neworder = protractor_1.element(protractor_1.by.xpath("//span[@class=\"btn-group open\"]//ul[@class=\"dropdown-menu dropdown-menu-right\"]//li//a[text()=\"" + Flowvalue + "\"]"));
        OBJCreate.Flowmenu.click();
        Neworder.click();
        protractor_1.browser.sleep(6000);
    }
    SelectDropDown(IdValue, BU, Testcasename) {
        var TcRow = ReadFromXL.FindRowNum(Testcasename, "data");
        DataDictLib.pushToDictionaryWithSheet(TcRow, "data");
        var BUValue = DataDictLib.getFromDictionary('BU');
        var allOptions = protractor_1.element.all(protractor_1.by.xpath("//*[@id='financeBusinessUnitCode']//ul//a/div"));
        console.log(allOptions.count());
        allOptions.filter(function (elem) {
            return elem.getText().then(function (text) {
                console.log(text);
                return text === BUValue;
            });
        }).click();
    }
    Enteringdata(Testcasename) {
        var TcRow = ReadFromXL.FindRowNum(Testcasename, "data");
        DataDictLib.pushToDictionaryWithSheet(TcRow, "data");
        var BUValue = DataDictLib.getFromDictionary('BU');
        var SOValue = DataDictLib.getFromDictionary('SO');
        var BillToValue = DataDictLib.getFromDictionary('BillTO');
        var OpOwner = DataDictLib.getFromDictionary('OpOwner');
        var TitleCreate = DataDictLib.getFromDictionary('CreateTitle');
        var Trailernumber = DataDictLib.getFromDictionary('Trailernumber');
        var TrailerPrefix = DataDictLib.getFromDictionary('TrailerPrefix');
        var Scac = DataDictLib.getFromDictionary('Scac');
        OBJCreate.BillTo.sendKeys(BillToValue);
        protractor_1.browser.sleep(5000);
        OBJCreate.BillTo.sendKeys(ptor_1.protractor.Key.ENTER);
        protractor_1.browser.sleep(5000);
        OBJCreate.BTContact.click();
        protractor_1.browser.sleep(2000);
        OBJCreate.BTContact.sendKeys(ptor_1.protractor.Key.ENTER);
        OBJCreate.BU.click();
        OBJCreate.BUclick.sendKeys(BUValue);
        protractor_1.browser.sleep(2000);
        OBJCreate.BUclick.sendKeys(ptor_1.protractor.Key.ENTER);
        protractor_1.browser.sleep(5000);
        OBJCreate.SO.click();
        OBJCreate.SOclick.sendKeys(SOValue);
        protractor_1.browser.sleep(2000);
        OBJCreate.SOclick.sendKeys(ptor_1.protractor.Key.ENTER);
        protractor_1.browser.sleep(3000);
        if (TitleCreate === "Create New Order") {
            OBJCreate.OPOwner.sendKeys(OpOwner);
            protractor_1.browser.sleep(2000);
            OBJCreate.OPOwner.sendKeys(ptor_1.protractor.Key.ENTER);
        }
        else {
            console.log("Create new template do not contain this field");
        }
        OBJCreate.scac.isPresent().then((elem) => {
            if (elem === true) {
                OBJCreate.scac.click();
                OBJCreate.scac.sendKeys(Scac);
                protractor_1.browser.sleep(3000);
            }
        });
        if (TrailerPrefix != "NULL") {
            this.Trailer("0000000105", TrailerPrefix);
        }
    }
    Trailer(Trailerno, Trailerprefix) {
        OBJCreate.trailernobutton.click();
        OBJCreate.Trailernumber.sendKeys(Trailerno);
        protractor_1.browser.sleep(2000);
        OBJCreate.Trailernumber.sendKeys(ptor_1.protractor.Key.TAB);
        protractor_1.browser.sleep(3000);
        OBJCreate.Trailerprefix.click();
        OBJCreate.TrailerPrefixText.sendKeys(Trailerprefix);
        OBJCreate.TrailerPrefixText.sendKeys(ptor_1.protractor.Key.ENTER);
        protractor_1.browser.sleep(2000);
    }
    Freightcharges(charge) {
        protractor_1.browser.executeScript("window.scrollTo(0,-150)");
        OBJCreate.freightcharges.click();
        protractor_1.browser.sleep(2000);
        OBJCreate.freightchargestext.sendKeys(charge);
        OBJCreate.freightchargestext.sendKeys(ptor_1.protractor.Key.ENTER);
        protractor_1.browser.sleep(2000);
    }
    Shipmentdetails(charge, ordervalue, fleetcode) {
        OBJCreate.ShipmentIdentificationNo.sendKeys(charge);
        OBJCreate.shipsecndarytype.click();
        OBJCreate.shipsecndarytypetext.sendKeys("Will");
        OBJCreate.shipsecndarytypetext.sendKeys(ptor_1.protractor.Key.ENTER);
        protractor_1.browser.sleep(3000);
        OBJCreate.ordervalue.sendKeys(ordervalue);
        protractor_1.browser.sleep(2000);
        // OBJCreate.fleetcode.sendkeys(fleetcode);
        //browser.sleep(3000);
    }
    Equipment() {
        this.dropdown(OBJCreate.equipcategory, "Hopper");
        this.dropdown(OBJCreate.equiptypecode, "Grain");
        this.dropdown(OBJCreate.equiplength, "53 Feet In Length");
        // OBJCreate.equipmentOptions.click();
        // OBJCreate.equipmentOptionstext.sendkeys("Duct Floor");
        // OBJCreate.freightSecurement.click();
        // OBJCreate.freightSecurementtext.sendkeys("Freeze Protect");
        // OBJCreate.protectionMaterialHandling.click();
        // OBJCreate.protectionMaterialHandlingtext.sendkeys("Flares");
    }
    dropdown(Objelement, strval) {
        //var value = BU
        Objelement.count().then(function (total) {
            Objelement.each(function (item) {
                var index = 0;
                if (total > index) {
                    var Disp = item.getText().then((elem) => {
                        if (elem.trim() === strval) {
                            item.click();
                            protractor_1.browser.sleep(3000);
                            // ObjRul.Save_Btn.click();
                            // browser.sleep(10000);
                        }
                        else {
                            console.log("View drop down is not available with the values");
                        }
                    });
                }
            });
        });
    }
    utilities(utilityoption, option) {
        protractor_1.browser.executeScript("window.scrollTo(0,-500)");
        OBJCreate.Utilitiesicon.click();
        protractor_1.browser.sleep(2000);
        switch (utilityoption) {
            case "Comment": {
                //OBJCreate.Utilitiesicon.click();
                //OBJCreate.Utilitiesicon.click();
                OBJCreate.toollist.get(0).click();
                OBJCreate.addComment.click();
                OBJCreate.addCommenttext.sendKeys(ptor_1.protractor.Key.ENTER);
                protractor_1.browser.sleep(2000);
                OBJCreate.addCommenttext.sendKeys("Ap");
                OBJCreate.addCommenttext.sendKeys(ptor_1.protractor.Key.ENTER);
                protractor_1.browser.sleep(2000);
                OBJCreate.templateType.click();
                //OBJCreate.templatetypetext.sendKeys("Apppoin");
                OBJCreate.templatetypetext.sendKeys(ptor_1.protractor.Key.ENTER);
                OBJCreate.Commenttext.clear();
                OBJCreate.Commenttext.sendKeys("Test");
                OBJCreate.Savebutton.get(1).click();
                protractor_1.browser.sleep(2000);
                OBJCreate.addedutilityref.click();
                var EC = ptor_1.protractor.ExpectedConditions;
                protractor_1.browser.wait(EC.visibilityOf(OBJCreate.apntEditcmnt), 5000).then(function () {
                    console.log("Edit or Delete option is available ");
                    if (option == "Edit") {
                        OBJCreate.utilityedit.click();
                    }
                    if (option == "Delete") {
                        OBJCreate.utilityDelete.click();
                    }
                });
                OBJCreate.Utilitiesicon.click();
                break;
            }
            case "Documents": {
                OBJCreate.toollist.get(1).click();
                break;
            }
            case "Reference": {
                //OBJCreate.Utilitiesicon.click();
                // OBJCreate.Utilitiesicon.click();
                OBJCreate.toollist.get(2).click();
                OBJCreate.ReferenceType.click();
                OBJCreate.Refercmnt.sendKeys("Test");
                OBJCreate.Addbutton.click();
                OBJCreate.apntEditRef.click();
                protractor_1.browser.executeScript("window.scrollBy(0,-3000)");
                //browser.executeScript("window.scrollTo(0,-500)"); 
                OBJCreate.toollist.get(2).click();
                var EC = ptor_1.protractor.ExpectedConditions;
                protractor_1.browser.wait(EC.visibilityOf(OBJCreate.apntEditRef), 5000).then(function () {
                    console.log("Edit or Delete option is available ");
                    if (option == "Edit") {
                        OBJCreate.utilityedit.click();
                    }
                    if (option == "Delete") {
                        OBJCreate.utilityDelete.click();
                    }
                });
                OBJCreate.Utilitiesicon.click();
                break;
            }
            case "Instruction": {
                OBJCreate.toollist.get(3).click();
                break;
            }
            case "Charge": {
                OBJCreate.toollist.get(4).click();
                OBJCreate.Chargelevel.click();
                protractor_1.browser.sleep(2000);
                OBJCreate.chargeamount.clear();
                OBJCreate.chargeamount.sendKeys("10");
                OBJCreate.chargequantity.clear();
                OBJCreate.chargequantity.sendKeys("15");
                OBJCreate.authno.sendKeys("12369");
                OBJCreate.authby.sendKeys("keerthana");
                OBJCreate.chargecode.sendKeys("DEAD");
                //OBJCreate.chargecode.sendKeys(protractor.Key.SPACE);
                OBJCreate.chargecode.sendKeys(ptor_1.protractor.Key.BACK_SPACE);
                OBJCreate.chargecode.sendKeys(ptor_1.protractor.Key.BACK_SPACE);
                protractor_1.browser.sleep(2000);
                OBJCreate.chargecode.sendKeys("A");
                protractor_1.browser.sleep(2000);
                OBJCreate.BillToValue.click();
                protractor_1.browser.sleep(2000);
                //  browser.executeScript("window.scrollTo(0,50)");
                //OBJCreate.chargecode.sendKeys(protractor.Key.ENTER);
                OBJCreate.Addbuttoncharge.get(2).click();
                OBJCreate.Utilitiesicon.click();
                break;
            }
        }
    }
    AddstopsOrigin(Testcasename, Requested, pickupdate) {
        OBJCreate.NextButton.click();
        //this.ClickButtonwithText("Next");
        protractor_1.browser.sleep(8000);
        var TcRow = ReadFromXL.FindRowNum(Testcasename, "data");
        DataDictLib.pushToDictionaryWithSheet(TcRow, "data");
        var Pickup = DataDictLib.getFromDictionary('Pickup');
        var Delivery = DataDictLib.getFromDictionary('Delivery');
        var ItemQty = DataDictLib.getFromDictionary('ItemQty');
        var ItemWt = DataDictLib.getFromDictionary('ItemWt');
        var ItemChar = DataDictLib.getFromDictionary('ItemChar');
        var TitleCreate = DataDictLib.getFromDictionary('CreateTitle');
        var NoOfAppoint = DataDictLib.getFromDictionary('NoOfAppoint');
        var NoOfItem = DataDictLib.getFromDictionary('NoOfitems');
        var NoOfStop = DataDictLib.getFromDictionary('Noofstops');
        this.EnterTextBox("locationID", Pickup);
        protractor_1.browser.sleep(2000);
        OBJCreate.BillToValue.click();
        protractor_1.browser.sleep(4000);
        this.SelectDRopdownValue("Contact");
        protractor_1.browser.sleep(4000);
        if (Requested == "Requested") {
            if (NoOfAppoint == 1) {
                this.Selectcalendericon(pickupdate, 0);
                protractor_1.browser.sleep(2000);
                this.SelectTime("08:00", 0);
                // browser.sleep(2000);
                this.Selectcalendericon(pickupdate, 1);
                protractor_1.browser.sleep(2000);
                this.SelectTime("09:00", 1);
                //this.SelectTime("09:00",1);
                protractor_1.browser.sleep(2000);
            }
            if (NoOfAppoint > 1) {
                for (var i = 2; i < NoOfAppoint; i++) {
                    console.log(NoOfAppoint + 2);
                    this.Selectcalendericon(pickupdate, i);
                    protractor_1.browser.sleep(2000);
                    this.SelectTime("08:00", i);
                    // browser.sleep(2000);
                    this.Selectcalendericon(pickupdate, i + 1);
                    protractor_1.browser.sleep(2000);
                    this.SelectTime("09:00", i + 1);
                    //this.SelectTime("09:00",1);
                    protractor_1.browser.sleep(2000);
                }
            }
        }
        if (Requested == "Scheduled") {
            if (NoOfAppoint == 1) {
                OBJCreate.AddappointmentIcon.get(1).click();
                this.Selectcalendericon(pickupdate, 2);
                protractor_1.browser.sleep(2000);
                this.SelectTime("08:00", 2);
                // browser.sleep(2000);
                this.Selectcalendericon(pickupdate, 3);
                protractor_1.browser.sleep(2000);
                this.SelectTime("09:00", 3);
                protractor_1.browser.sleep(2000);
            }
            if (NoOfAppoint > 1) {
                for (var i = 4; i <= 4; i++) {
                    console.log(NoOfAppoint + 2);
                    OBJCreate.AddappointmentIcon.get(1).click();
                    this.Selectcalendericon(pickupdate, 2);
                    protractor_1.browser.sleep(2000);
                    this.SelectTime("08:00", 2);
                    // browser.sleep(2000);
                    this.Selectcalendericon(pickupdate, 3);
                    protractor_1.browser.sleep(2000);
                    this.SelectTime("09:00", 3);
                    protractor_1.browser.sleep(4000);
                    protractor_1.browser.executeScript("window.scrollTo(0,-100)");
                    OBJCreate.AddappointmentIcon.get(0).click();
                    protractor_1.browser.sleep(4000);
                    OBJCreate.AddappointmentIconschedule.click();
                    this.Selectcalendericon(pickupdate, i);
                    protractor_1.browser.sleep(2000);
                    this.SelectTime("09:00", i);
                    // browser.sleep(2000);
                    this.Selectcalendericon(pickupdate, i + 1);
                    protractor_1.browser.sleep(2000);
                    this.SelectTime("10:00", i + 1);
                    protractor_1.browser.sleep(2000);
                }
            }
        }
        protractor_1.browser.sleep(3000);
        this.HandlingUnit();
        protractor_1.browser.sleep(3000);
        this.Itemdetails();
        var tagname = protractor_1.element(protractor_1.by.css("[formcontrolname=\"itemDescription\"]"));
        tagname.sendKeys(ptor_1.protractor.Key.ENTER);
        protractor_1.browser.sleep(15000);
    }
    HandlingUnit() {
        var ItemQty = DataDictLib.getFromDictionary('ItemQty');
        var ItemWt = DataDictLib.getFromDictionary('ItemWt');
        OBJCreate.dropdownopt.click();
        this.EnterTextBox("itemHandlingTypeQuantity", ItemQty);
        protractor_1.browser.sleep(2000);
        this.EnterTextBox("itemHandlingUnitWeight", ItemWt);
        protractor_1.browser.sleep(2000);
        var Handlingunit = protractor_1.element(protractor_1.by.css("[formcontrolname=\"itemHandlingUnitHeight\"]"));
        Handlingunit.sendKeys(ptor_1.protractor.Key.TAB);
        protractor_1.browser.sleep(5000);
    }
    Itemdetails() {
        var ItemQty = DataDictLib.getFromDictionary('ItemQty');
        var ItemWt = DataDictLib.getFromDictionary('ItemWt');
        var ItemChar = DataDictLib.getFromDictionary('ItemChar');
        var NoOfItem = DataDictLib.getFromDictionary('NoOfitems');
        if (NoOfItem == 1) {
            this.EnterTextBox("packagingUnitTypeQuantity", ItemQty);
            this.EnterTextBox("itemWeight", ItemWt);
            protractor_1.browser.sleep(5000);
            var itemunit = protractor_1.element(protractor_1.by.css("[formcontrolname=\"itemHeight\"]"));
            itemunit.sendKeys(ptor_1.protractor.Key.TAB);
            protractor_1.browser.sleep(12000);
            this.EnterTextBox("itemDescription", ItemChar);
            protractor_1.browser.sleep(5000);
            var tagname = protractor_1.element(protractor_1.by.css("[formcontrolname=\"itemDescription\"]"));
        }
        if (NoOfItem > 1) {
            this.EnterTextBox("packagingUnitTypeQuantity", ItemQty);
            this.EnterTextBox("itemWeight", ItemWt);
            protractor_1.browser.sleep(5000);
            var itemunit = protractor_1.element(protractor_1.by.css("[formcontrolname=\"itemHeight\"]"));
            itemunit.sendKeys(ptor_1.protractor.Key.TAB);
            protractor_1.browser.sleep(12000);
            this.EnterTextBox("itemDescription", ItemChar);
            protractor_1.browser.sleep(6000);
            var tagname = protractor_1.element(protractor_1.by.css("[formcontrolname=\"itemDescription\"]"));
            tagname.sendKeys(ptor_1.protractor.Key.ENTER);
            protractor_1.browser.sleep(5000);
            (OBJCreate.AddappointmentIcon.get(5)).click();
            protractor_1.browser.sleep(5000);
            for (var i = 1; i <= NoOfItem; i++) {
                var j = 5;
                var AddItem = ((j += 2));
                console.log((j += 2));
                console.log("Console value for j is ", j);
                var ItemQtyvalue = (OBJCreate.tagname.get(i));
                var ItemWeightValue = (OBJCreate.tagname1.get(i));
                var itemunit = (OBJCreate.itemunit.get(i));
                var ItemWeightValue = (OBJCreate.tagname1.get(i));
                var ItemCharName = (OBJCreate.tagname2.get(i));
                var ItemCharFreezeName = (OBJCreate.itemchar.get(i));
                var NMFCNumber = (OBJCreate.NMFCNumber.get(i));
                ItemQtyvalue.clear();
                ItemQtyvalue.sendKeys(ItemQty);
                ItemWeightValue.clear();
                ItemWeightValue.sendKeys(ItemWt);
                protractor_1.browser.sleep(5000);
                itemunit.sendKeys(ptor_1.protractor.Key.TAB);
                protractor_1.browser.sleep(5000);
                ItemCharName.click();
                ItemCharName.sendKeys(ptor_1.protractor.Key.TAB);
                NMFCNumber.sendKeys(ptor_1.protractor.Key.TAB);
                //ItemCharFreezeName.click();
                protractor_1.browser.sleep(3000);
                ItemCharName.clear();
                ItemCharName.sendKeys(ItemChar);
                ItemCharName.sendKeys(ptor_1.protractor.Key.ENTER);
                protractor_1.browser.sleep(5000);
                var tagname = protractor_1.element(protractor_1.by.css("[formcontrolname=\"itemDescription\"]"));
                tagname.sendKeys(ptor_1.protractor.Key.ENTER);
                protractor_1.browser.sleep(5000);
                (OBJCreate.AddappointmentIcon.get(AddItem)).click();
                protractor_1.browser.sleep(5000);
            }
        }
    }
    AddstopsDestination(Testcasename, Requested, DeliveryDate) {
        var TitleCreate = DataDictLib.getFromDictionary('CreateTitle');
        var Delivery = DataDictLib.getFromDictionary('Delivery');
        var pickupdate = DataDictLib.getFromDictionary('Pickup');
        var deliverdate = DataDictLib.getFromDictionary('Delivery');
        var StartTime = DataDictLib.getFromDictionary('PickupDate');
        var endTime = DataDictLib.getFromDictionary('Deliverydate');
        if (TitleCreate === "Create New Order") {
            OBJCreate.DestinationTab.click();
            protractor_1.browser.sleep(7000);
        }
        else {
            OBJCreate.TemplateDestinationTab.click();
            protractor_1.browser.sleep(7000);
        }
        this.EnterTextBox("locationID", Delivery);
        protractor_1.browser.sleep(4000);
        OBJCreate.BillToValue.click();
        protractor_1.browser.sleep(2000);
        this.SelectDRopdownValue("Contact");
        protractor_1.browser.sleep(3000);
        if (Requested == "Requested") {
            this.Selectcalendericon(DeliveryDate, 0);
            protractor_1.browser.sleep(2000);
            this.SelectTime("08:00", 0);
            // browser.sleep(2000);
            this.Selectcalendericon(DeliveryDate, 1);
            protractor_1.browser.sleep(2000);
            this.SelectTime("09:00", 1);
            //this.SelectTime("09:00",1);
            protractor_1.browser.sleep(2000);
        }
        if (Requested == "Scheduled") {
            OBJCreate.AddappointmentIcon.get(1).click();
            this.Selectcalendericon(DeliveryDate, 2);
            protractor_1.browser.sleep(2000);
            this.SelectTime("08:00", 2);
            // browser.sleep(2000);
            this.Selectcalendericon(DeliveryDate, 3);
            protractor_1.browser.sleep(2000);
            this.SelectTime("09:00", 3);
            protractor_1.browser.sleep(2000);
        }
        protractor_1.browser.sleep(5000);
        this.DateValidationCreateOrderOverview("01/04/2018", "01/05/2018");
        if (TitleCreate === "Create New Order") {
            OBJCreate.PalletChckBX.isPresent().then((elem) => {
                OBJCreate.PalletChckBX.click();
                protractor_1.browser.sleep(6000);
            });
            //OBJCreate.NextButton.click();
        }
        else {
            OBJCreate.PalletChckBX.isPresent().then((elem) => {
                OBJCreate.TemplatePalletChckBX.click();
                protractor_1.browser.sleep(6000);
            });
        }
        protractor_1.browser.sleep(8000);
        console.log("End of destination function");
    }
    No_of_Appointment() {
        var AppointmentNo;
        switch (AppointmentNo) {
            case AppointmentNo == 1: {
                OBJCreate.toollist.get(1).click();
                break;
            }
        }
    }
    AddIntermediateStopDetails(Testcasename, Requested, Pickupdate, StopNumber) {
        // OBJCreate.NextButton.click();
        //this.ClickButtonwithText("Next")            ;
        protractor_1.browser.sleep(5000);
        OBJCreate.StopReason.click();
        OBJCreate.StopReasonText.click();
        protractor_1.browser.sleep(3000);
        var DataDictLibStop = new DictionaryData_1.DataDictionary();
        var TcRow = ReadFromXL.FindRowNum(Testcasename, "InterStops");
        DataDictLib.pushToDictionaryWithSheet(TcRow, "InterStops");
        var Location = DataDictLib.getFromDictionary('Stop' + StopNumber);
        //var Delivery =DataDictLib.getFromDictionary('Delivery');
        console.log("ItemQty" + StopNumber);
        var ItemQty = DataDictLib.getFromDictionary('ItemQty' + StopNumber);
        var ItemWt = DataDictLib.getFromDictionary('ItemWt' + StopNumber);
        var ItemChar = DataDictLib.getFromDictionary('ItemChar' + StopNumber);
        var TitleCreate = DataDictLib.getFromDictionary('CreateTitle');
        console.log("Console values are as below " + Location, +ItemQty, +ItemWt);
        var NoOfAppoint = DataDictLib.getFromDictionary('NoOfAppoint');
        var NoOfItem = DataDictLib.getFromDictionary('NoOfitems');
        var NoOfStop = DataDictLib.getFromDictionary('Noofstops');
        this.EnterTextBox("locationID", Location);
        protractor_1.browser.sleep(3000);
        OBJCreate.BillToValue.click();
        protractor_1.browser.sleep(4000);
        this.SelectDRopdownValue("Contact");
        protractor_1.browser.sleep(4000);
        if (Requested == "Requested") {
            if (NoOfAppoint == 1) {
                this.Selectcalendericon(Pickupdate, 0);
                protractor_1.browser.sleep(2000);
                this.SelectTime("08:00", 0);
                // browser.sleep(2000);
                this.Selectcalendericon(Pickupdate, 1);
                protractor_1.browser.sleep(2000);
                this.SelectTime("09:00", 1);
                //this.SelectTime("09:00",1);
                protractor_1.browser.sleep(2000);
            }
            if (NoOfAppoint > 1) {
                for (var i = 2; i < NoOfAppoint; i++) {
                    console.log(NoOfAppoint + 2);
                    this.Selectcalendericon(Pickupdate, i);
                    protractor_1.browser.sleep(2000);
                    this.SelectTime("08:00", i);
                    // browser.sleep(2000);
                    this.Selectcalendericon(Pickupdate, i + 1);
                    protractor_1.browser.sleep(2000);
                    this.SelectTime("09:00", i + 1);
                    //this.SelectTime("09:00",1);
                    protractor_1.browser.sleep(2000);
                }
            }
        }
        if (Requested == "Scheduled") {
            if (NoOfAppoint == 1) {
                OBJCreate.AddappointmentIcon.get(1).click();
                this.Selectcalendericon(Pickupdate, 2);
                protractor_1.browser.sleep(2000);
                this.SelectTime("08:00", 2);
                // browser.sleep(2000);
                this.Selectcalendericon(Pickupdate, 3);
                protractor_1.browser.sleep(2000);
                this.SelectTime("09:00", 3);
                protractor_1.browser.sleep(2000);
            }
            if (NoOfAppoint > 1) {
                for (var i = 4; i <= 4; i++) {
                    console.log(NoOfAppoint + 2);
                    OBJCreate.AddappointmentIcon.get(1).click();
                    this.Selectcalendericon(Pickupdate, 2);
                    protractor_1.browser.sleep(2000);
                    this.SelectTime("08:00", 2);
                    // browser.sleep(2000);
                    this.Selectcalendericon(Pickupdate, 3);
                    protractor_1.browser.sleep(2000);
                    this.SelectTime("09:00", 3);
                    protractor_1.browser.sleep(4000);
                    protractor_1.browser.executeScript("window.scrollTo(0,-100)");
                    OBJCreate.AddappointmentIcon.get(0).click();
                    protractor_1.browser.sleep(4000);
                    OBJCreate.AddappointmentIconschedule.click();
                    this.Selectcalendericon(Pickupdate, i);
                    protractor_1.browser.sleep(2000);
                    this.SelectTime("09:00", i);
                    // browser.sleep(2000);
                    this.Selectcalendericon(Pickupdate, i + 1);
                    protractor_1.browser.sleep(2000);
                    this.SelectTime("10:00", i + 1);
                    protractor_1.browser.sleep(2000);
                }
            }
        }
        protractor_1.browser.sleep(3000);
        this.HandlingUnit();
        protractor_1.browser.sleep(3000);
        this.Itemdetails();
        var tagname = protractor_1.element(protractor_1.by.css("[formcontrolname=\"itemDescription\"]"));
        tagname.sendKeys(ptor_1.protractor.Key.ENTER);
        protractor_1.browser.sleep(15000);
    }
    InternationalShipment() {
        OBJCreate.shipmentreq.click();
        OBJCreate.shipmentreqText.sendKeys("Inter");
        OBJCreate.shipmentreqText.sendKeys(ptor_1.protractor.Key.ENTER);
        OBJCreate.interservice.click();
        OBJCreate.interservicetext.sendKeys("door");
        OBJCreate.interservicetext.sendKeys(ptor_1.protractor.Key.ENTER);
        //OBJCreate.inbondToggle.click();
        //  OBJCreate.bondholder.click();
        //  OBJCreate.bondholdertext.sendKeys("Door");
        //  OBJCreate.bondholdertext.sendKeys(protractor.Key.ENTER);
        //  OBJCreate.bondholderparty.click();
        //  OBJCreate.bondholderpartytext.sendKeys("Door");
        //  OBJCreate.bondholderpartytext.sendKeys(protractor.Key.ENTER);
        // OBJCreate.bondholderpartytype.click();
        // OBJCreate.bondholderpartytypetext.sendKeys("Immediate Export");
        //OBJCreate.bondholderpartytypetext.sendKeys(protractor.Key.ENTER);
    }
    Selectcalendericon(ApntmntDate, calendarvalue) {
        var datevalue = ApntmntDate.split('/');
        var date = datevalue[0];
        var month = datevalue[1];
        var year = datevalue[2];
        console.log(date);
        console.log(month);
        console.log(year);
        var val = (OBJCreate.Calendaricon.get(calendarvalue)).isPresent().then((elem) => {
            if (elem === true) {
                protractor_1.browser.sleep(3000);
                var icon = OBJCreate.Calendaricon.get(calendarvalue);
                protractor_1.browser.sleep(4000);
                icon.click();
                protractor_1.browser.sleep(4000);
                var value = null;
                let dateval = value;
                let MonthInput = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                console.log(MonthInput.length);
                var j;
                for (var i = 0; i < MonthInput.length; i++) {
                    //console.log(MonthInput[i]);
                    if (month === (MonthInput[i])) {
                        j = i + 1;
                    }
                }
                console.log(j);
                var monthvalue = protractor_1.element(protractor_1.by.css("[class=\"headerlabelbtn monthlabel\"]"));
                var yearvalue = protractor_1.element(protractor_1.by.css("[class=\"headerlabelbtn yearlabel\"]"));
                var viewContainer = protractor_1.element(protractor_1.by.css("[class=\"headerlabelbtn monthlabel\"]")).getText();
                viewContainer.then(console.log);
                if ((monthvalue.getText().then(function (text) { console.log(text); return text === month; })) && (yearvalue.getText().then(function (text) { console.log(text); return text === year; }))) {
                    protractor_1.browser.sleep(3000);
                    var allOptions = protractor_1.element.all(protractor_1.by.xpath("//table[@class='caltable']//tbody//tr//td//div[contains(@class,'datevalue currmonth')]//span"));
                    allOptions.filter(function (elem) {
                        return elem.getText().then(function (text) {
                            return text === date;
                        });
                    }).first().click();
                    protractor_1.browser.sleep(4000);
                }
                console.log("Clicking on the calendar icon");
            }
            else {
                console.log("Calendar icon is not available");
            }
        });
    }
    SelectTime(ApntmntTime, calendarvalue) {
        var datevalue = ApntmntTime.split(':');
        var hour = datevalue[0];
        var min = datevalue[1];
        OBJCreate.apnmntHR.get(calendarvalue).sendKeys(hour);
        protractor_1.browser.sleep(2000);
        OBJCreate.apnmntMIN.get(calendarvalue).sendKeys(min);
    }
    ValidateRateOption() {
        protractor_1.browser.sleep(5000);
        protractor_1.browser.executeScript("window.scrollTo(0,-500)");
        var EC = ptor_1.protractor.ExpectedConditions;
        protractor_1.browser.wait(EC.visibilityOf(OBJCreate.optiondots.get(0)), 10000).then(function () {
            OBJCreate.optiondots.get(0).click();
            protractor_1.browser.sleep(3000);
        });
        protractor_1.browser.executeScript("window.scrollTo(0,500)");
        OBJCreate.AllInRate.isPresent().then((elem) => {
            var value = 0;
            {
                var Disp = OBJCreate.AllInRate.getText().then((text) => {
                    if (text.trim() != "0") {
                        console.log("All In Rate is available in the rate overview popup");
                    }
                });
            }
        });
        OBJCreate.FuelSurcharge.isPresent().then((elem) => {
            var value = 0;
            {
                var Disp = OBJCreate.FuelSurcharge.getText().then((text) => {
                    if (text.trim() != "0") {
                        console.log("Fuel Surcharge is available in the rate overview popup");
                    }
                });
            }
        });
    }
    ClickRateoption(Testcasename, Rownumber) {
        console.log("rATE FUNCTION function");
        protractor_1.browser.sleep(5000);
        protractor_1.browser.executeScript("window.scrollTo(0,-500)");
        var EC = ptor_1.protractor.ExpectedConditions;
        protractor_1.browser.wait(EC.visibilityOf(OBJCreate.optiondots.get(Rownumber)), 10000).then(function () {
            console.log("Click on the rate dot");
            OBJCreate.optiondots.get(Rownumber).click();
        });
        protractor_1.browser.executeScript("window.scrollTo(0,500)");
        var val = (OBJCreate.CreateButtonOverview).isPresent().then((elem) => {
            if (elem === true) {
                protractor_1.browser.sleep(3000);
                OBJCreate.CreateButtonOverview.click();
                console.log("Opportunity is clicked from the dropdown");
            }
            else {
                console.log("Create opportunity is not displayed in the shipping options Flow menu");
            }
        });
        var val = (OBJCreate.Overideall).isPresent().then((elem) => {
            if (elem === true) {
                // element(by.id("billtoaccount")).sendKeys("CACAB9")
                protractor_1.browser.sleep(4000);
                protractor_1.browser.executeScript("window.scrollTo(0,-500)");
                protractor_1.browser.sleep(3000);
                protractor_1.browser.actions().mouseMove(OBJCreate.Overideall);
                OBJCreate.Overideall.click();
                protractor_1.browser.sleep(4000);
                console.log("Warnings are overidden successfully");
            }
            else {
                console.log("Create opportunity is not displayed in the shipping options Flow menu");
            }
        });
        var index = 0;
        OBJCreate.errorparent.count().then(function (total) {
            OBJCreate.errorparent.each(function (item) {
                index++;
                if (total >= index) {
                    (OBJCreate.errorparent).get(0).isPresent().then((element) => {
                        if (element === true) {
                            var EC = ptor_1.protractor.ExpectedConditions;
                            protractor_1.browser.wait(EC.visibilityOf(OBJCreate.errorlink), 5000).then(function () {
                                OBJCreate.errorlink.click();
                                (OBJCreate.errordropDown).isPresent().then(function (bool) {
                                    if (bool === true) {
                                        OBJCreate.errordropDown.click();
                                        OBJCreate.OverideErrorButton.click();
                                        protractor_1.browser.sleep(2000);
                                        // OBJCreate.errorlinkname.sendKeys(protractor.Key.ENTER);
                                    }
                                });
                                (OBJCreate.errorlinkname).isPresent().then(function (bool) {
                                    if (bool === true) {
                                        OBJCreate.errorlinkname.sendKeys("Keerthana Selvaraj");
                                        protractor_1.browser.sleep(2000);
                                        OBJCreate.errorlinkname.sendKeys(ptor_1.protractor.Key.ENTER);
                                    }
                                });
                                (OBJCreate.errorlinkCmnt).isPresent().then(function (bool) {
                                    if (bool === true) {
                                        OBJCreate.errorlinkCmnt.sendKeys("Test");
                                        OBJCreate.OverideErrorButton.click();
                                        protractor_1.browser.sleep(2000);
                                        console.log("The errors and warnings are overriden successfully");
                                    }
                                });
                            });
                        }
                    });
                }
                else
                    console.log("No errors are available");
            });
        });
        protractor_1.browser.executeScript("window.scrollTo(0,500)");
        protractor_1.browser.sleep(3000);
    }
    OrderHistory() {
        ObjORD.hstrybtn.click();
        protractor_1.browser.sleep(5000);
        var val = (ObjORD.hstrytable).isPresent().then((elem) => {
            if (elem === true) {
                console.log("Order History is  available");
                ObjORD.cnt;
                ObjORD.cnt.count().then((intcnt) => {
                    if (intcnt > 0) {
                        console.log("Records count is available" + intcnt);
                    }
                    else {
                        console.log("Records count are not found");
                    }
                    ObjORD.AcceptanceRulepass.isPresent().then((elem) => {
                        if (elem === true) {
                            console.log("Acceptance rule is passed");
                        }
                        else
                            console.log("Acceptance rule is not passed");
                    });
                    ObjORD.Orderstatus.isPresent().then((elem) => {
                        if (elem === true) {
                            console.log("order status is changed from pending to accepted");
                        }
                        else
                            console.log("order status is not changed from pending to accepted");
                    });
                });
            }
            else {
                console.log("Order History is not available");
            }
        });
    }
    OrderHistoryWarningsoverride() {
        ObjORD.hstrybtn.click();
        protractor_1.browser.sleep(5000);
        var val = (ObjORD.hstrytable).isPresent().then((elem) => {
            if (elem === true) {
                console.log("Order History is  available");
                ObjORD.cnt;
                ObjORD.cnt.count().then((intcnt) => {
                    if (intcnt > 0) {
                        console.log("Records count is available" + intcnt);
                    }
                    else {
                        console.log("Records count are not found");
                    }
                    ObjORD.WarningsOveridden.isPresent().then((elem) => {
                        if (elem === true) {
                            console.log("Credit Check Failure warning is displayed");
                        }
                        else
                            console.log("Credit Check Failure warning is not displayed");
                    });
                });
            }
            else {
                console.log("Order History is not available");
            }
        });
    }
    ElementWait(elemValCheck, OBJelem) {
        return __awaiter(this, void 0, void 0, function* () {
            var cntr = 0;
            var displayvalue = false;
            var textvalue = "";
            var value = false;
            while (value === false) {
                protractor_1.browser.sleep(3000);
                yield OBJelem.isPresent().then((elem) => {
                    console.log(cntr + "th time");
                    displayvalue = elem;
                    console.log("1st scope" + displayvalue);
                });
                protractor_1.browser.sleep(3000);
                if (elemValCheck == true && displayvalue.valueOf() === true) {
                    console.log(" entering into text validation");
                    yield OBJelem.getText().then((elem1) => {
                        console.log(cntr + "th time");
                        textvalue = elem1;
                        console.log("2nd scope" + textvalue);
                    });
                }
                if (cntr > 12) {
                    break;
                }
                if (elemValCheck == true) {
                    if (textvalue !== "")
                        value = displayvalue;
                    else
                        value = false;
                }
                else
                    value = displayvalue;
                console.log(value);
                cntr++;
            }
        });
    }
    AppointmentValidation() {
        this.ElementValidation(OBJCreate.apnmt_ordovrview);
        this.ElementValidation(OBJCreate.apnmt_stop);
    }
    ElementValidation(Objelement) {
        Objelement.isPresent().then((elem) => {
            if (elem == true) {
                Objelement.getText().then((text) => {
                    console.log(text);
                    console.log("Appointment details is present in order overview" + text);
                });
            }
        });
    }
    ;
    ElementValidationAdvancedsearch(AppointmnetDatepickup, appointmentdateDelivery) {
        OBJCreate.ApntdatepickupAdvanced.isPresent().then((elem) => {
            if (elem == true) {
                OBJCreate.ApntdatepickupAdvanced.getText().then((text) => {
                    var date = text.split(" ");
                    var PickupDate = date[0];
                    var pickupTime = date[1];
                    if (PickupDate == AppointmnetDatepickup) {
                        console.log("Pickup Appointment details in advanced search is same as the appointment date while creating the order " + text);
                    }
                });
            }
        });
        OBJCreate.ApntdatedeliveryAdvanced.isPresent().then((elem) => {
            if (elem == true) {
                OBJCreate.ApntdatedeliveryAdvanced.getText().then((text) => {
                    var date = text.split(" ");
                    var PickupDate = date[0];
                    var pickupTime = date[1];
                    if (PickupDate == appointmentdateDelivery) {
                        console.log("Delivery Appointment details in advanced search is same as the appointment date while creating the order " + text);
                    }
                });
            }
        });
    }
    DateValidationCreateOrderOverview(AppointmnetDatepickup, appointmentdateDelivery) {
        OBJCreate.PickDateorderOverview.isPresent().then((elem) => {
            if (elem == true) {
                OBJCreate.PickDateorderOverview.getText().then((text) => {
                    var date = text.split(" ");
                    var PickupDate = date[0];
                    var pickupTime = date[1];
                    if (PickupDate == AppointmnetDatepickup) {
                        console.log("Pickup Appointment details and Time zone in Order overview  is same as the appointment date while creating the order " + text);
                    }
                });
            }
        });
        OBJCreate.DelidateorderOverview.isPresent().then((elem) => {
            if (elem == true) {
                OBJCreate.DelidateorderOverview.getText().then((text) => {
                    var date = text.split(" ");
                    var Deliverydate = date[0];
                    var DeliveryTime = date[1];
                    if (Deliverydate == appointmentdateDelivery) {
                        console.log("Delivery Appointment details and Time Zone in Order overview is same as the appointment date while creating the order " + text);
                    }
                });
            }
        });
    }
    totalMilesCreateOrderOverview(OBJElement) {
        OBJElement.isPresent().then((elem) => {
            var value = 0;
            {
                var Disp = OBJElement.getText().then((text) => {
                    if (text.trim() != "0") {
                        console.log("Delivery Appointment details and Time Zone in Order overview is same as the appointment date while creating the order " + text);
                    }
                });
            }
        });
    }
    AdvancedSearchforOrder(OrderNo) {
        // this.NavigatefromDashboard("Advanced Search");     
        // browser.sleep(3000);
        this.ElementWait(true, OBJCreate.allOptions);
        // var allOptions =element.all(by.xpath("//*[@class='inline']//ng-select[@placeholder='Type'][1]"))
        OBJCreate.acceptclose.click();
        OBJCreate.Showmore.click();
        protractor_1.browser.executeScript("window.scrollTo(0,-200)");
        protractor_1.browser.sleep(2000);
        OBJCreate.Statuschange.sendKeys("Accepted");
        OBJCreate.Statuschange.sendKeys(ptor_1.protractor.Key.ENTER);
        protractor_1.browser.executeScript("window.scrollTo(0,200)");
        OBJCreate.Destin.click();
        // OBJCreate.ordertype.click();
        // browser.executeScript("window.scrollTo(0,200)"); 
        OBJCreate.allOptions.get(2).click();
        var ind = 0;
        OBJCreate.allOptions.count().then(function (total) {
            OBJCreate.allOptions.each(function (item) {
                ind++;
                if (ind == 2) {
                    console.log("index no is" + ind);
                    item.sendKeys("order number");
                    protractor_1.browser.sleep(2000);
                    item.sendKeys(ptor_1.protractor.Key.TAB);
                    item.sendKeys(ptor_1.protractor.Key.TAB);
                    item.sendKeys(ptor_1.protractor.Key.TAB);
                    item.sendKeys(ptor_1.protractor.Key.ENTER);
                }
                else
                    console.log("View drop down is not available with the values");
            });
        });
        var ind1 = 0;
        protractor_1.browser.sleep(2000);
        OBJCreate.orderno.count().then(function (total) {
            OBJCreate.orderno.each(function (item) {
                console.log(ind1);
                ind1++;
                if (ind1 == 3) {
                    item.sendKeys(OrderNo);
                    protractor_1.browser.sleep(2000);
                }
                else
                    console.log("View drop down is not available with the values");
            });
        });
        OBJCreate.SearchButton.click();
        protractor_1.browser.executeScript("window.scrollTo(0,-200)");
        this.ElementValidationAdvancedsearch("", "");
        this.SelectFirstorder();
    }
    SelectFirstorder() {
        OBJCreate.SelectFirstorder.get(0).click();
        protractor_1.browser.sleep(4000);
        var viewpage = protractor_1.element(protractor_1.by.xpath("//span[text()='Order']"));
        this.ElementWait(true, viewpage);
    }
    ClickButtonwithText(buttonText) {
        OBJCreate.Buttontext.count().then(function (total) {
            OBJCreate.Buttontext.each(function (item) {
                var index = 0;
                index++;
                if (total > index) {
                    var Disp = item.getText().then((elem) => {
                        if (elem.trim() === buttonText) {
                            item.click();
                            protractor_1.browser.sleep(3000);
                        }
                    });
                }
            });
        });
    }
    AdvancedSearchwithdate(Pickupdate, DeliveryDate, CreatedDate) {
        // this.NavigatefromDashboard("Advanced Search");     
        // browser.sleep(3000);
        this.ElementWait(true, OBJCreate.allOptions);
        // var allOptions =element.all(by.xpath("//*[@class='inline']//ng-select[@placeholder='Type'][1]"))
        OBJCreate.acceptclose.click();
        this.Selectcalendericon(Pickupdate, 0);
        protractor_1.browser.sleep(2000);
        this.Selectcalendericon(Pickupdate, 1);
        protractor_1.browser.sleep(2000);
        this.Selectcalendericon(DeliveryDate, 2);
        protractor_1.browser.sleep(2000);
        this.Selectcalendericon(DeliveryDate, 3);
        protractor_1.browser.sleep(2000);
        this.Selectcalendericon(CreatedDate, 4);
        protractor_1.browser.sleep(2000);
        this.Selectcalendericon(CreatedDate, 5);
        protractor_1.browser.sleep(2000);
    }
    RoutePlan(ViewValue) {
        protractor_1.browser.sleep(5000);
        protractor_1.browser.executeScript("window.scrollTo(0,200)");
        protractor_1.browser.sleep(5000);
        var EC = ptor_1.protractor.ExpectedConditions;
        //browser.wait(EC.visibilityOf(OBJCreate.optiondots.get(Rownumber)), 20000).then(function() {
        OBJCreate.Routeplan.click();
        protractor_1.browser.executeScript("window.scrollTo(0,-200)");
        try {
            protractor_1.browser.wait(EC.visibilityOf(OBJCreate.load), 5000).then(function () {
                OBJCreate.load.getText().then((elem) => {
                    if (elem != "")
                        console.log("Load id is generated for the order" + elem);
                });
            });
        }
        catch (_a) {
            console.log("Load id is not generated for the order");
        }
    }
    TemplateSearch(Testcasename) {
        var scac = DataDictLib.getFromDictionary('scac');
        OBJCreate.template_filter.click();
        OBJCreate.scacsearch.click();
        OBJCreate.scactext.click();
        protractor_1.browser.sleep(2000);
        OBJCreate.scactext.sendKeys(scac);
        protractor_1.browser.sleep(5000);
        OBJCreate.scacenter.click();
        //  OBJCreate.scactext.sendKeys(protractor.Key.ENTER)
        protractor_1.browser.executeScript("window.scrollBy(0,-500)");
        OBJCreate.three_dot.click();
        this.dropdown(OBJCreate.copy_view, "View Template");
        OBJCreate.threedot_temp.click();
        this.dropdown(OBJCreate.tempdrop, "Create Order");
        //this.ElementWait(true,OBJCreate.ordernumber);
    }
    addmultiplestops(Testcasename, stopreason) {
        var TcRow = ReadFromXL.FindRowNum(Testcasename, "data");
        DataDictLib.pushToDictionaryWithSheet(TcRow, "data");
        var Pickup = DataDictLib.getFromDictionary('Pickup');
        var Stopnumber = DataDictLib.getFromDictionary('StopNumber');
        protractor_1.browser.executeScript("window.scrollTo(0,-500)");
        // if(Stopnumber==1) 
        //  {                                                                    
        // OBJCreate.stopdots.click();
        // OBJCreate.addstop.click();
        // browser.sleep(2000);
        // // OBJCreate.expandicon.get(0).click();
        // // browser.sleep(4000);
        // // OBJCreate.stopdots.click();
        // // OBJCreate.addstop.click();
        //  OBJCreate.expandicon.get(1).click();
        // this.AddstopsOrigin(Testcasename,"Scheduled","28/Dec/2017");
        // }
        if (Stopnumber >= 1) {
            // OBJCreate.stopdots.click();
            // OBJCreate.addstop.click();
            protractor_1.browser.sleep(3000);
            for (var i = 0; i < Stopnumber; i++) {
                console.log(i);
                //console.log(Stopnumber)
                protractor_1.browser.executeScript("window.scrollTo(0,-500)");
                OBJCreate.expandicon.get(0).click();
                protractor_1.browser.sleep(5000);
                OBJCreate.stopdots.click();
                OBJCreate.addstop.click();
                protractor_1.browser.sleep(5000);
                protractor_1.browser.sleep(5000);
                this.AddIntermediateStopDetails(Testcasename, "NULL", "29/Dec/2017", i);
                protractor_1.browser.sleep(7000);
            }
            //     for(var i=2;i<=Stopnumber;i++)
            // {
            //   (OBJCreate.stopstitle.get(i)).click();
            //   browser.sleep(6000);
            //   this.AddIntermediateStopDetails(Testcasename,"NULL","29/Dec/2017",i);
            //   }
        }
    }
    RateSheet() {
        this.ElementWait(true, OBJCreate.Rulename);
        protractor_1.browser.executeScript("window.scrollTo(0,200)");
        protractor_1.browser.sleep(5000);
        OBJCreate.ratesheet.click();
        this.ElementWait(true, OBJCreate.rate_level);
        OBJCreate.rate_edit.isPresent().then((elem) => {
            if (elem === true) {
                console.log("edit button is present");
                OBJCreate.rate_edit.click();
            }
            else {
                console.log("edit button is not present");
            }
        });
    }
    CreateWithoutRate() {
        OBJCreate.ShippingFlowMenu.click();
        var val = (OBJCreate.CreateWithoutrTE).isDisplayed().then((elem) => {
            if (elem === true) {
                // element(by.id("billtoaccount")).sendKeys("CACAB9")
                OBJCreate.CreateWithoutrTE.click();
                console.log("Create without Rate is clicked from the dropdown");
            }
            else {
                console.log("Create without Rate is not displayed in the shipping options Flow menu");
            }
        });
        OBJCreate.RateReason.click();
        this.ClickButtonwithText("Create");
        protractor_1.browser.sleep(12000);
    }
    Overrideall() {
        OBJCreate.warningMsg.isPresent().then((elem) => {
            var value = 0;
            {
                var Disp = OBJCreate.warningMsg.getText().then((text) => {
                    if (text.trim() == "Customer credit status is CREDIT HLD.") {
                        console.log("Credit check failure is displayed as warning " + text);
                    }
                });
            }
        });
        OBJCreate.Overidewarning.isPresent().then((elem) => {
            OBJCreate.Overidewarning.click();
            protractor_1.browser.sleep(45000);
        });
    }
    CCI_AccountSearch(CreditStatus) {
        OBJCreate.CCi_Search.sendKeys("WABE10 ");
        OBJCreate.CCi_Search.sendKeys(ptor_1.protractor.Key.ENTER);
        OBJCreate.SelectFirstResult.click();
        OBJCreate.Credittab.click();
        OBJCreate.CreditStatusEditIcon.click();
        OBJCreate.CreditSelectClick.click();
        OBJCreate.CreditStatusEditIcon.click();
        OBJCreate.CreditSelectClick.click();
        if (CreditStatus == "Approved") {
            OBJCreate.CreditApproved.click();
        }
        if (CreditStatus == "Denied") {
            OBJCreate.CreditDenied.click();
        }
        OBJCreate.CreditScore.sendKeys("45");
        this.ClickButtonwithText("Save");
    }
    RejectOrder() {
        OBJCreate.OrderFlowMenu.click();
        OBJCreate.RejectOrder.click();
        OBJCreate.RejectReason.click();
        OBJCreate.RejectComments.sendKeys("Test");
        this.ClickButtonwithText("Save");
    }
    AlternateLogin() {
        OBJCreate.username.click();
        OBJCreate.username.sendKeys("rcon996");
        OBJCreate.password.click();
        OBJCreate.password.sendKeys("jb8462");
        OBJCreate.loginbutton.click();
        protractor_1.browser.sleep(5000);
    }
}
exports.ReusableFunctions = ReusableFunctions;
//# sourceMappingURL=RegressionCreatePage.js.map