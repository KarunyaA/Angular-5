'use strict';
var Homepage = /** @class */ (function () {
    function Homepage() {
    }
    //constructor() {}
    Homepage.prototype.Call_url = function () {
        var url = "http://account-tst.jbhunt.com/account/";
        return url;
    };
    Homepage.prototype.obj_NavigationToggle = function () {
        var url = "[class=\"fa fa-circle-o\"]";
        return url;
    };
    return Homepage;
}());
module.exports = Homepage;
