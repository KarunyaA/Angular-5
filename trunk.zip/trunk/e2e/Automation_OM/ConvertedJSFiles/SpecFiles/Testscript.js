"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/* tslint:disable */
var protractor_1 = require("protractor");
//var prot = require("protractor");
//import data = require("C:\\Users\\rcon875\\Documents\\MyProtractor_WS\\ProtractorTS\\DataFiles\\Account.json");
//import  data from '../DataFiles/Account.json';
var AngularPage = require("../PageFiles/AccountPOM");
var page = new AngularPage();
var ExcelDataSourceForConf = require('../CommonFiles/ReadFromXL');
var ReadFromXL = new ExcelDataSourceForConf();
// tslint:disable-next-line:typedef
describe("Account Creation and Search ", function () {
    it("Should Have a Title To be Verified", function () {
        //console.log((<any>data).SearchAccountDetails);
        // browser.get(page.Call_url());
        protractor_1.browser.get("http://account-tst.jbhunt.com/account/");
    });
    it("Should Navigate To Account Page", function () {
        //console.log(page.btn_navtoggle);
        //page.obj_fun_NavigationToggle();
        protractor_1.element(protractor_1.by.css(page.obj_NavigationToggle())).click();
        protractor_1.element(protractor_1.by.css(page.obj_NavigationToggle())).click();
        //element(by.css("[class=\"fa fa-circle-o\"]")).click();
        window.close();
        protractor_1.browser.executeScript("window.scrollBy(-2000, 0)");
        //page.lst_NavigationList.click();
        protractor_1.element.all(protractor_1.by.cssContainingText(".routeDisplayText", "Account")).click();
    });
    //it("Should Create An Account",() => {
    //  //  page.lst_NavigationList.click();
    //   element(by.xpath("//ul[@class=\"nav nav-sidebar\"]//li//span[text()=\"Create New Account\"]")).click();
    //    browser.executeScript("window.scrollBy(-2000, 0)");
    //  element(by.css("#addressField")).sendKeys("117 E MCELHANY AVE");
    //   element(by.css("#cityField")).sendKeys("SANTA MARIA");
    //   element(by.xpath("//*[@id='stateRef']/div")).click();
    //   element(by.xpath("//input[@class=\"form-control ui-select-search\"]")).sendKeys("CA");
    //    element(by.xpath("//input[@class=\"form-control ui-select-search\"]")).sendKeys(protractor.Key.ENTER);
    //    element(by.css("#postalCode")).sendKeys("934543137");
    //    element(by.css("#accountNameField")).sendKeys("walmart");
    //    element(by.css("#createButton")).click();
    //    browser.sleep(8000);
    //    element(by.xpath("//*[@placeholder=\"Role\"]/descendant::span")).click();
    //    browser.sleep(3000);
    //     element(by.xpath("//ul[@class=\"ui-select-choices dropdown-menu\"]//li[2]")).click();
    //    element(by.buttonText("Create")).click();
    //    element(by.buttonText('OK')).click();
    //   // tslint:disable-next-line:typedef
    //   element(by.xpath("//simple-notifications//div")).getText().then(function(text) {
    //       console.log(text);
    //   });
    //});
});
