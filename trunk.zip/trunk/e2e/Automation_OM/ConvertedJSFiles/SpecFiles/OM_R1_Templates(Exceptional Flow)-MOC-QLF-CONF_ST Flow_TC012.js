"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const protractor_1 = require("protractor");
const Regression_1 = require("../PageFiles/Regression");
let ORDRegression = new Regression_1.commonFunctions;
const Objects_Order_1 = require("../ObjectRepository/Objects_Order");
//let path="C:\\Users\\rcon996\\AppData\\Roaming\\npm";
let ORDRegobject = new Objects_Order_1.Update_Objects();
const ReadFromXL_1 = require("../CommonFiles/ReadFromXL");
var ReadFromXL = new ReadFromXL_1.ExcelReader();
const DictionaryData_1 = require("../DataFiles/DictionaryData");
var DataDictLib = new DictionaryData_1.DataDictionary();
var path = require('path');
var filename = path.basename(__filename);
var Testcase = path.parse(filename).name;
var TcRow = ReadFromXL.FindRowNum(Testcase, "CreateOrder");
DataDictLib.pushToDictionaryWithSheet(TcRow, "CreateOrder");
var NavIdValue = DataDictLib.getFromDictionary('NavIdValue');
var rownumber = DataDictLib.getFromDictionary('NavIdValue');
var urlName = DataDictLib.getFromDictionary('UrlName');
var Navigationvalue = DataDictLib.getFromDictionary('CreateTitle');
describe("OM_R1_Templates(Exceptional Flow)-MOC-QLF-CONF_ST Flow_TC012", () => {
    it("Navigate to Create Template page", () => {
        ORDRegression.Get_url(Testcase);
        protractor_1.browser.sleep(3000);
        ORDRegression.SignIn(Testcase);
        protractor_1.browser.sleep(5000);
        ORDRegression.NavigatefromDashboard("Create Order");
        //ORDRegression.NavigationFunction(Navigationvalue,Testcase);
    }),
        // it("Adding create page details",() => {
        //   ORDRegression.Enteringdata(Testcase);
        //   //ORDRegression.Shipmentdetails();
        // }),
        // it("Adding origin stop details",() => {
        //   ORDRegression.AddstopsOrigin(Testcase,"Null","Null","9/Jan/2018");
        // }),
        // it("Adding Destination stop details",() => {
        //   ORDRegression.AddstopsDestination(Testcase,"Null","Null","10/Jan/2018");
        //   ORDRegression.addmultiplestops(Testcase,"Pickup");
        //   // //ORDRegression.DateValidationCreateOrderOverview("12/27/2017","12/28/2017");
        //    ORDRegression.MultiplePalletCheckbox(Testcase,"Create New Template");
        //   ORDRegression.ClickButtonwithText("Save");
        //   browser.sleep(5000);
        //}),
        it("Searching template with bill to and scac setails", () => {
            //ORDRegression.SearchTemplate("INBRBW");
            protractor_1.browser.sleep(5000);
            ORDRegression.TemplateSearch(Testcase);
            protractor_1.browser.sleep(4000);
        }),
        it("Adding utilities in Create order from View template", () => {
            ORDRegression.utilities("Charge", "Edit");
            ORDRegobject.NextButton.click();
            protractor_1.browser.sleep(4000);
        }),
        it("Adding appointment details in origin stop", () => {
            ORDRegression.AppointmentOrigin(Testcase, "Scheduled", "10/Jan/2018", "Create New Order");
            protractor_1.browser.sleep(5000);
            ORDRegobject.DestinationTab.click();
            protractor_1.browser.sleep(2000);
        }),
        it("Adding appointment details in destination stop", () => {
            ORDRegression.AppiontmentDestination(Testcase, "Scheduled", "11/Jan/2018", "Create New Order", 2);
            protractor_1.browser.sleep(5000);
            ORDRegobject.NextButton.click();
            protractor_1.browser.sleep(2000);
            ORDRegression.ClickButtonwithText("Back");
            ORDRegression.Shipmentdetails("94345", "12589", "FL741");
            ORDRegobject.NextButton.click();
            protractor_1.browser.sleep(2000);
            ORDRegobject.NextButton.click();
            protractor_1.browser.sleep(50000);
        }),
        it("Navigate to accepted order", () => {
            ORDRegression.ClickRateoption(Testcase, rownumber);
            ORDRegression.OrderHistory();
        });
});
//# sourceMappingURL=OM_R1_Templates(Exceptional Flow)-MOC-QLF-CONF_ST Flow_TC012.js.map