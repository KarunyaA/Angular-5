"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const protractor_1 = require("protractor");
const CCI_CreateAccount_1 = require("../PageFiles/CCI_CreateAccount");
let CA_Run = new CCI_CreateAccount_1.CreateAccount();
var path = require('path');
var filename = path.basename(__filename);
var Testcase = path.parse(filename).name;
describe("JBH_CCI_AccountCreationTC023 -->Verify that system allows user to create Account with Freight Broker role type", () => {
    it("Should Able to Login and Navigate to Create Account Page", () => {
        CA_Run.invokeApplication();
        CA_Run.ApplicationLogin(Testcase);
        protractor_1.browser.sleep(3000);
        CA_Run.Navigation_Process();
    });
    it("Should Create an Account with valid details and verify suggestion Details", () => {
        CA_Run.CreateAccount(Testcase);
        CA_Run.VerifyAccountSuggestionDetails();
        CA_Run.CreateAccWithRoletype(Testcase);
    });
    it("Should verify account is created", () => {
        CA_Run.verifyAccountCreatedwithRoletype();
    });
});
//# sourceMappingURL=JBH_CCI_AccountCreationTC023.js.map