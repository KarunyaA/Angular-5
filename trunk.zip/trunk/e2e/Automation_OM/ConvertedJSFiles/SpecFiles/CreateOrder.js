"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ViewOrder_1 = require("../PageFiles/ViewOrder");
var ORDFunction = new ViewOrder_1.Ord_Func();
describe("View order", function () {
    it("Should Have a Title To be Verified", function () {
        ORDFunction.Launch_Url();
        //ORDFunction.EditShipment();
        //ORDFunction.EditEquipment();
        ORDFunction.EditBUSO();
    });
});
// var allOptions = element.all(by.xpath("//*[@id='orderSubTypeCode']//div//a//div"));
// var t:any = allOptions.filter(function (elem) {
//     return elem.getText().then(function (text) {
//         return text === 'Non-Managed';
//     });
// }).click(); 
