"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const protractor_1 = require("protractor");
const Regression_1 = require("../PageFiles/Regression");
const Objects_Order_1 = require("../ObjectRepository/Objects_Order");
let ORDRegression = new Regression_1.commonFunctions();
//let path="C:\\Users\\rcon996\\AppData\\Roaming\\npm";
let ORDRegobject = new Objects_Order_1.Update_Objects();
const ReadFromXL_1 = require("../CommonFiles/ReadFromXL");
var ReadFromXL = new ReadFromXL_1.ExcelReader();
const DictionaryData_1 = require("../DataFiles/DictionaryData");
var DataDictLib = new DictionaryData_1.DataDictionary();
var path = require('path');
var filename = path.basename(__filename);
var Testcase = path.parse(filename).name;
var TcRow = ReadFromXL.FindRowNum(Testcase, "CreateOrder");
DataDictLib.pushToDictionaryWithSheet(TcRow, "CreateOrder");
var NavIdValue = DataDictLib.getFromDictionary('NavIdValue');
var rownumber = DataDictLib.getFromDictionary('Rateoption');
var urlName = DataDictLib.getFromDictionary('UrlName');
var Navigationvalue = DataDictLib.getFromDictionary('CreateTitle');
var OrderNumber;
describe("TC_007", () => {
    it("navigate to Create template page", () => {
        ORDRegression.Get_url(Testcase);
        protractor_1.browser.sleep(3000);
        ORDRegression.SignIn(Testcase);
        protractor_1.browser.sleep(5000);
        ORDRegression.NavigatefromDashboard("Create Order");
        // ORDRegression.NavigationFunction(Navigationvalue,Testcase);
    }),
        it("Adding create page details", () => {
            // ORDRegression.Enteringdata(Testcase);        
            // browser.sleep(5000);
        }),
        it("Adding origin stop details ", () => {
            // ORDRegression.AddstopsOrigin(Testcase,"Scheduled","","18/Jan/2018");
        }),
        it("Adding Destination stop details", () => {
            // ORDRegression.AddstopsDestination(Testcase,"Scheduled","","19/Jan/2018");
            ORDRegression.addmultiplestops(Testcase, "Pickup");
            // //ORDRegression.DateValidationCreateOrderOverview("12/27/2017","12/28/2017");
            ORDRegression.MultiplePalletCheckbox(Testcase, "Create New Template");
            // browser.sleep(6000); 
            // ORDRegression.ClickButtonwithText("Save")
            // browser.sleep(8000);
        }),
        it("Searching Tempalte in template search", () => __awaiter(this, void 0, void 0, function* () {
            ORDRegression.NavigateWhenToggleActive("Create Order");
            // browser.sleep(5000);
            OrderNumber = yield ORDRegression.TemplateSearch(Testcase);
            protractor_1.browser.sleep(4000);
            // ORDRegression.Enteringdata(Testcase); 
            ORDRegobject.NextButton.click();
            protractor_1.browser.sleep(6000);
        })),
        it("Creating order from template search", () => {
            // ORDRegobject.DestinationTab.click();
            // ORDRegression.addmultiplestops(Testcase,"Pickup");
            ORDRegression.Itemdetails(Testcase);
            protractor_1.browser.sleep(4000);
            ORDRegression.MultiplePalletCheckbox(Testcase, "Create New Order");
            ORDRegobject.NextButton.click();
            protractor_1.browser.sleep(80000);
        }),
        it("Validation in 1-6 days tab", () => {
            ORDRegression.ClickButtonwithText("1-6 Days");
            protractor_1.browser.sleep(25000);
            ORDRegression.DateValidationCreateOrderOverview("01/18/2018", "01/19/2018");
            protractor_1.browser.sleep(3000);
            ORDRegression.TotalMilesCreateOrderOverview(ORDRegobject.TotalMiles);
            protractor_1.browser.sleep(5000);
        }),
        it("Navigating to accpeted order", () => {
            ORDRegression.ClickRateoption(Testcase, rownumber);
            ORDRegression.ClickButtonwithText("Create");
            protractor_1.browser.sleep(12000);
        }),
        it("Searching order in Advanced search", () => {
            //ORDRegression.NavigateWhenToggleActive("Advanced Search");
            //browser.sleep(8000);         
            // ORDRegression.AdvancedSearchforOrder(OrderNumber,"01/18/2018","19/10/2018","Pending"); 
        }),
        it("Checking for rates in Rate sheet", () => {
            ORDRegression.RateSheet();
        });
});
//# sourceMappingURL=TC_007.js.map