"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const protractor_1 = require("protractor");
const Regression_1 = require("../PageFiles/Regression");
let ORDRegression = new Regression_1.commonFunctions;
const ReadFromXL_1 = require("../CommonFiles/ReadFromXL");
var ReadFromXL = new ReadFromXL_1.ExcelReader();
const DictionaryData_1 = require("../DataFiles/DictionaryData");
const Objects_Order_1 = require("../ObjectRepository/Objects_Order");
let ORDRegobject = new Objects_Order_1.Update_Objects;
var DataDictLib = new DictionaryData_1.DataDictionary();
var path = require('path');
var filename = path.basename(__filename);
var Testcase = path.parse(filename).name;
var OrderNumber;
describe("TC_003", () => {
    it("Should Have a Title To be Verified", () => __awaiter(this, void 0, void 0, function* () {
        var TcRow = ReadFromXL.FindRowNum(Testcase, "CreateOrder");
        DataDictLib.pushToDictionaryWithSheet(TcRow, "CreateOrder");
        var NavIdValue = DataDictLib.getFromDictionary('NavIdValue');
        var rownumber = DataDictLib.getFromDictionary('NavIdValue');
        var urlName = DataDictLib.getFromDictionary('UrlName');
        var Navigationvalue = DataDictLib.getFromDictionary('CreateTitle');
        var OrderNumber;
        ORDRegression.Get_url(Testcase);
        protractor_1.browser.sleep(5000);
        ORDRegression.SignIn(Testcase);
        protractor_1.browser.sleep(5000);
        ORDRegression.NavigatefromDashboard("Create Order");
        //    ORDRegression.NavigationFunction(Navigationvalue,Testcase);
        //      ORDRegression.Enteringdata(Testcase);
        //     //ORDRegression.Shipmentdetails();
        //     ORDRegression.AddstopsOrigin(Testcase,"Scheduled","","9/Jan/2018");
        //     ORDRegression.AddstopsDestination(Testcase,"Scheduled","","10/Jan/2018");
        //     ORDRegression.ClickButtonwithText("Save");
        //    // ORDRegression.ClickButtonwithText("Save");
        //     browser.sleep(25000); 
        //     browser.executeScript("window.scrollTo(0,-500)");
        //     ORDRegression.NavigateWhenToggleActive("Create Order");
        protractor_1.browser.sleep(5000);
        OrderNumber = yield ORDRegression.TemplateSearch(Testcase);
        protractor_1.browser.sleep(12000);
        protractor_1.browser.executeScript("window.scrollTo(0,-500)");
        //browser.sleep(7000);
        ORDRegression.Equipment();
        ORDRegobject.NextButton.click();
        protractor_1.browser.sleep(5000);
        ORDRegression.HazmatDetails();
        ORDRegobject.NextButton.click();
        protractor_1.browser.sleep(60000);
        ORDRegression.DateValidationCreateOrderOverview("01/09/2018", "01/09/2018");
        ORDRegression.NavigateWhenToggleActive("Advanced Search");
        protractor_1.browser.sleep(8000);
        ORDRegression.AdvancedSearchforOrder(OrderNumber, "01/09/2018", "01/09/2018", "Acccepted");
        protractor_1.browser.sleep(3000);
        ORDRegression.ElementValidationAdvancedsearch("01/09/2018", "01/09/2018");
    }));
});
//# sourceMappingURL=TC_003.js.map