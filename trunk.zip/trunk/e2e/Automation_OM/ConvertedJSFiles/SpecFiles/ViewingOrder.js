"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ViewOrder_1 = require("../PageFiles/ViewOrder");
const RulePage_1 = require("../PageFiles/RulePage");
const Createpage_1 = require("../PageFiles/Createpage");
const Objects_Order_1 = require("../ObjectRepository/Objects_Order");
let ORDFunction = new ViewOrder_1.Ord_Func();
let RULFunction = new RulePage_1.Rul_Func();
let OBJCreate = new Createpage_1.commonFunctions;
let ObjORD = new Objects_Order_1.Update_Objects;
// var ExcelDataSourceForConf = require('../CommonFiles/ReadFromXL');
// var ReadFromXL = new ExcelDataSourceForConf();
// var PushAndPullDataDictLib = require('../DataFiles/DictionaryData');
// var DataDictLib = new PushAndPullDataDictLib();
const ReadFromXL_1 = require("../CommonFiles/ReadFromXL");
var ReadFromXL = new ReadFromXL_1.ExcelReader();
const DictionaryData_1 = require("../DataFiles/DictionaryData");
var DataDictLib = new DictionaryData_1.DataDictionary();
//var Access=DataDictLib.getFromDictionary("Access");
describe("View order", () => {
    it("Should Have a Title To be Verified", () => {
        // OBJCreate.Get_url("TC011");
        // OBJCreate.NavigatefromDashboard("Advanced Search");
        // //RULFunction.AdvancedSearch();
        // browser.sleep(5000);
        // //ORDFunction.ElementWait(true,ObjORD.Rulename);
        // OBJCreate.AdvancedSearchforOrder();
        // browser.sleep(5000);
        // ORDFunction.UpdateOrder("TC001");
        OBJCreate.CreateOrderFunction("TC001", "YES");
    });
});
//# sourceMappingURL=ViewingOrder.js.map