"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const protractor_1 = require("protractor");
const Regression_1 = require("../PageFiles/Regression");
let ORDRegression = new Regression_1.commonFunctions;
const ReadFromXL_1 = require("../CommonFiles/ReadFromXL");
var ReadFromXL = new ReadFromXL_1.ExcelReader();
const DictionaryData_1 = require("../DataFiles/DictionaryData");
var DataDictLib = new DictionaryData_1.DataDictionary();
var path = require('path');
var filename = path.basename(__filename);
var Testcase = path.parse(filename).name;
describe("Templates_TC012", () => {
    it("Should Have a Title To be Verified", () => {
        var TcRow = ReadFromXL.FindRowNum(Testcase, "CreateOrder");
        DataDictLib.pushToDictionaryWithSheet(TcRow, "CreateOrder");
        var NavIdValue = DataDictLib.getFromDictionary('NavIdValue');
        var rownumber = DataDictLib.getFromDictionary('NavIdValue');
        var urlName = DataDictLib.getFromDictionary('UrlName');
        var Navigationvalue = DataDictLib.getFromDictionary('CreateTitle');
        ORDRegression.Get_url(Testcase);
        protractor_1.browser.sleep(5000);
        ORDRegression.SignIn(Testcase);
        ORDRegression.NavigationFunction(Navigationvalue, Testcase);
        ORDRegression.Enteringdata(Testcase);
        //ORDRegression.Shipmentdetails();
        ORDRegression.AddstopsOrigin(Testcase, "", "", "");
        ORDRegression.AddstopsDestination(Testcase, "", "", "");
        protractor_1.browser.sleep(60000);
        //ORDRegression.TemplateSearch(Testcase);
        // ORDRegression.Equipment();
        //        Function for Next button
        //ORDRegression.OrderHistory();
    });
});
//# sourceMappingURL=Templates_TC012.js.map