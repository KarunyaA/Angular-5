"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const RulePage_1 = require("../PageFiles/RulePage");
let RULFunction = new RulePage_1.Rul_Func();
describe("Auto Rules", () => {
    // it("Should Have a Title To be Verified", () =>{
    //       RULFunction.Launch_Url();
    //       browser.sleep(5000);
    //            RULFunction.Filter();
    //            browser.sleep(10000);
    //           //RULFunction.RoutePlan(); 
    //          })
    it("Should Have a Title To be Verified", () => {
        //RULFunction.Launch_Url();
        // RULFunction.Inactivate(); 
        RULFunction.RateSheet();
    });
});
//# sourceMappingURL=AutoRules.js.map