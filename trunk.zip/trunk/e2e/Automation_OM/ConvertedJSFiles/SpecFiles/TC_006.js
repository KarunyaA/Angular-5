"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const protractor_1 = require("protractor");
const Regression_1 = require("../PageFiles/Regression");
let ORDRegression = new Regression_1.commonFunctions;
//let path="C:\\Users\\rcon996\\AppData\\Roaming\\npm";
//let ORDRegobject=new Objects_Order();
const ReadFromXL_1 = require("../CommonFiles/ReadFromXL");
var ReadFromXL = new ReadFromXL_1.ExcelReader();
const DictionaryData_1 = require("../DataFiles/DictionaryData");
var DataDictLib = new DictionaryData_1.DataDictionary();
var path = require('path');
var filename = path.basename(__filename);
var Testcase = path.parse(filename).name;
var DataDictLibStop = new DictionaryData_1.DataDictionary();
const Objects_Order_1 = require("../ObjectRepository/Objects_Order");
let ORDRegobject = new Objects_Order_1.Update_Objects();
var TcRow = ReadFromXL.FindRowNum(Testcase, "CreateOrder");
DataDictLib.pushToDictionaryWithSheet(TcRow, "CreateOrder");
var NavIdValue = DataDictLib.getFromDictionary('NavIdValue');
var rownumber = DataDictLib.getFromDictionary('Rateoption');
var urlName = DataDictLib.getFromDictionary('UrlName');
var TitleCreate = DataDictLib.getFromDictionary('CreateTitle');
var OrderNumber;
describe("TC_006", () => {
    it("Navigate to Create order page", () => {
        ORDRegression.Get_url(Testcase);
        ORDRegression.SignIn(Testcase);
        protractor_1.browser.sleep(5000);
        ORDRegression.NavigationFunction(TitleCreate, Testcase);
    }),
        it("Adding create page details", () => __awaiter(this, void 0, void 0, function* () {
            OrderNumber = yield ORDRegression.Enteringdata(Testcase);
            ORDRegression.AddstopsOrigin(Testcase, "NULL", "", "30/Jan/2018");
            // ORDRegression.ClickButtonwithText("Next")
            // }),
            // it("Adding origin stop details",() => {
            // }),
            // it("Adding Destination stop details",() => {
            ORDRegression.AddstopsDestination(Testcase, "NULL", "", "31/Jan/2018");
            ORDRegression.addmultiplestops(Testcase, "Pickup");
            ORDRegression.MultiplePalletCheckbox(Testcase, "Create New Order");
            protractor_1.browser.sleep(7000);
            // ORDRegression.DateValidationCreateOrderOverview("01/30/2018","01/31/2018");
            //   ORDRegression.ClickButtonwithText("Next")
            //   //browser.sleep(7000);
            //          browser.sleep(50000); 
        }));
    // it("Validation in shipping page",() => {
    //     ORDRegression.DateValidationCreateOrderOverview("01/30/2018","01/31/2018");
    //     ORDRegression.TotalMilesCreateOrderOverview(ORDRegobject.TotalMiles);
    //     browser.sleep(3000);
    //     ORDRegobject.dayTab; 
    //     browser.sleep(15000);  
    //    ORDRegression.ValidateRateOption();
    // }),
    // it("Searching order in advanced search",() => {        
    //    // ORDRegression.ClickRateoption(Testcase,rownumber);
    //    // ORDRegression.ClickButtonwithText("Create")
    //    browser.sleep(8000);         
    //    ORDRegression.AdvancedSearchforOrder(OrderNumber,"01/30/2018","19/31/2018","Pending");       
    //    browser.sleep(8000);  
    // }),
    // it("Checking the Rate Sheet for the rates",() => {   
    //     ORDRegression.AppointmentValidation();
    //     ORDRegression.RateSheet();
});
//# sourceMappingURL=TC_006.js.map