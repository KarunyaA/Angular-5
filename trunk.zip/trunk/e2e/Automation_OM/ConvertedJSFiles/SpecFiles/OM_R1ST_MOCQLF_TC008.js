"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const protractor_1 = require("protractor");
const Regression_1 = require("../PageFiles/Regression");
let ORDRegression = new Regression_1.commonFunctions;
const Objects_Order_1 = require("../ObjectRepository/Objects_Order");
//let path="C:\\Users\\rcon996\\AppData\\Roaming\\npm";
let ORDRegobject = new Objects_Order_1.Update_Objects();
const ReadFromXL_1 = require("../CommonFiles/ReadFromXL");
var ReadFromXL = new ReadFromXL_1.ExcelReader();
const DictionaryData_1 = require("../DataFiles/DictionaryData");
var DataDictLib = new DictionaryData_1.DataDictionary();
var path = require('path');
var filename = path.basename(__filename);
var Testcase = path.parse(filename).name;
var TcRow = ReadFromXL.FindRowNum(Testcase, "CreateOrder");
DataDictLib.pushToDictionaryWithSheet(TcRow, "CreateOrder");
var NavIdValue = DataDictLib.getFromDictionary('NavIdValue');
var rownumber = DataDictLib.getFromDictionary('Rateoption');
var urlName = DataDictLib.getFromDictionary('UrlName');
var Navigationvalue = DataDictLib.getFromDictionary('CreateTitle');
describe("OM_R1ST_MOCQLF_TC008", () => {
    it("Navigating to Create order page", () => {
        ORDRegression.Get_url(Testcase);
        protractor_1.browser.sleep(3000);
        //ORDRegression.SignIn(Testcase);
        //browser.sleep(5000);
        ORDRegression.NavigationFunction(Navigationvalue, Testcase);
    }),
        it("Adding create page details", () => {
            ORDRegression.Enteringdata(Testcase);
            // ORDRegression.Shipmentdetails("94345","12589","FL741");
            ORDRegression.Equipment();
            ORDRegression.Shipmentdetails("9426", "12589", "FL741");
            protractor_1.browser.sleep(5000);
            ORDRegression.utilities("Comment", "Delete");
            protractor_1.browser.sleep(2000);
            ORDRegression.utilities("Reference", "Delete");
            protractor_1.browser.sleep(3000);
            //ORDRegression.Equipment();
            //browser.sleep(5000); 
            ORDRegression.utilities("Charge", "Delete");
            protractor_1.browser.sleep(3000);
            ORDRegression.AddstopsOrigin(Testcase, "NULL", "NULL", "22/Jan/2018");
            ORDRegression.AddstopsDestination(Testcase, "NULL", "NULL", "23/Jan/2018");
            ORDRegression.ClickButtonwithText("Next");
            ORDRegression.Overrideall();
            protractor_1.browser.sleep(70000);
        }),
        // it("Adding Origin Stop details",() => {
        // }),
        // it("Adding destination stops details",() => {
        // }),
        it("Navigate to accepted  order", () => {
            // ORDRegression.ElementWait(true,ORDRegobject.Shippingpage); 
            ORDRegression.ClickRateoption(Testcase, rownumber);
            ORDRegression.ClickButtonwithText("Create");
            protractor_1.browser.sleep(15000);
        }),
        it("Checking order history details", () => {
            protractor_1.browser.executeScript("window.scrollTo(0,2000)");
            ORDRegression.OrderHistory();
        });
});
//# sourceMappingURL=OM_R1ST_MOCQLF_TC008.js.map