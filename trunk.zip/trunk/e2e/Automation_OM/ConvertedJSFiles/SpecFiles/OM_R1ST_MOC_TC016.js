"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const protractor_1 = require("protractor");
const Regression_1 = require("../PageFiles/Regression");
let ORDRegression = new Regression_1.commonFunctions;
const Objects_Order_1 = require("../ObjectRepository/Objects_Order");
let ORDRegobject = new Objects_Order_1.Update_Objects();
const ReadFromXL_1 = require("../CommonFiles/ReadFromXL");
var ReadFromXL = new ReadFromXL_1.ExcelReader();
const DictionaryData_1 = require("../DataFiles/DictionaryData");
var DataDictLib = new DictionaryData_1.DataDictionary();
var path = require('path');
var filename = path.basename(__filename);
var Testcase = path.parse(filename).name;
var TcRow = ReadFromXL.FindRowNum(Testcase, "CreateOrder");
DataDictLib.pushToDictionaryWithSheet(TcRow, "CreateOrder");
var TitleCreate = DataDictLib.getFromDictionary('CreateTitle');
var NavIdValue = DataDictLib.getFromDictionary('NavIdValue');
var rownumber = DataDictLib.getFromDictionary('Rateoption');
describe("OM_R1ST_MOC_TC016", () => {
    it("Navigate to Create order page", () => {
        var TcRow = ReadFromXL.FindRowNum(Testcase, "CreateOrder");
        DataDictLib.pushToDictionaryWithSheet(TcRow, "CreateOrder");
        var TitleCreate = DataDictLib.getFromDictionary('CreateTitle');
        var NavIdValue = DataDictLib.getFromDictionary('NavIdValue');
        var rownumber = DataDictLib.getFromDictionary('Rateoption');
        ORDRegression.Get_url(Testcase);
        ORDRegression.SignIn(Testcase);
        protractor_1.browser.sleep(5000);
        ORDRegression.NavigationFunction(TitleCreate, Testcase);
    }),
        it("Adding create page details", () => {
            ORDRegression.Enteringdata(Testcase);
            // ORDRegression.ClickButtonwithText("Next")
        }),
        it("Adding origin stop details", () => {
            ORDRegression.AddstopsOrigin(Testcase, "NULL", "", "24/Jan/2018");
        }),
        it("Adding Destination stop details", () => {
            ORDRegression.AddstopsDestination(Testcase, "Null", "", "25/Jan/2018");
            ORDRegression.addmultiplestops(Testcase, "Pickup");
            ORDRegression.MultiplePalletCheckbox(Testcase, "");
            ORDRegression.ClickButtonwithText("Next");
            protractor_1.browser.sleep(7000);
            protractor_1.browser.executeScript("window.scrollTo(0,-1000)");
            ORDRegression.Overrideall();
            protractor_1.browser.sleep(80000);
        }),
        //it("Adding multiple stops and create an order",() => {  
        //}),
        it("Navigate to accepted order", () => {
            // ORDRegression.ValidateRateOption();
            ORDRegression.ClickRateoption(Testcase, rownumber);
            //ORDRegression.ClickButtonwithText("Create")
            protractor_1.browser.sleep(15000);
        }),
        it("Navigate to accepted order with create without rate", () => {
            ORDRegression.CreateWithoutRate();
            protractor_1.browser.executeScript("window.scrollTo(0,2000)");
        }),
        it("Check for order History details", () => {
            ORDRegression.OrderHistory();
        });
});
//# sourceMappingURL=OM_R1ST_MOC_TC016.js.map