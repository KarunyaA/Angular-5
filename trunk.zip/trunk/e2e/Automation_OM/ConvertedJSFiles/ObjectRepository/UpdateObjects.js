"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const protractor_1 = require("protractor");
var ExcelDataSourceForConf = require('../CommonFiles/ReadFromXL');
class Update_Objects {
    constructor() {
        this.url = "https://order-tst-prof4.jbhunt.com/order/createorders/";
        this.orderid = protractor_1.element(protractor_1.by.xpath("//*[text()='Order Overview']//following::span[strong][1]"));
        this.updateBUSO = protractor_1.element(protractor_1.by.xpath("//*[text()='Service Offering']//following::div[@class='icon-jbh_edit icon-edit pull-right']"));
        this.BU = protractor_1.element(protractor_1.by.css("[formcontrolname=\"financeBusinessUnitCode\"]"));
        this.BUclick = protractor_1.element(protractor_1.by.xpath("//*[text()='Edit Service Offering']//following::input[@class='form-control ui-select-search'][1]"));
        this.SO = protractor_1.element(protractor_1.by.css("[formcontrolname=\"serviceOfferingCode\"]"));
        this.SOclick = protractor_1.element(protractor_1.by.xpath("//*[text()='Edit Service Offering']//following::input[@class='form-control ui-select-search'][1]"));
        this.validateBU = protractor_1.element(protractor_1.by.xpath("//*[text()='Business Unit']//following::p[1]"));
        this.validateSO = protractor_1.element(protractor_1.by.xpath("//*[text()='Business Unit']//following::p[text()='Service Offering']//following::p[1]"));
        this.edit_equipment = protractor_1.element(protractor_1.by.xpath("//h3[text()='Equipments']//following::div[@class='icon-jbh_edit icon-edit']"));
        this.equip_category = protractor_1.element(protractor_1.by.id("equipmentCategory"));
        this.equipinput = protractor_1.element(protractor_1.by.xpath("//input[@placeholder='Equipment Category']"));
        this.equipsave_Btn = protractor_1.element(protractor_1.by.xpath("//*[@class='btn btn-primary col-md-3 btns']//button[text()='Save']"));
        this.save_BUSO = protractor_1.element(protractor_1.by.xpath("//*[text()='Edit Service Offering']//following::button[text()='Save'][1]"));
        this.threedot = protractor_1.element(protractor_1.by.xpath("//h1[@class='alignHeading']//following::*[@placement='bottom'][1]"));
        //reconsign          =element(by.xpath("//*[text()='Reconsignment']"));
        this.reconsign = protractor_1.element(protractor_1.by.id("a-reconsgmt"));
        this.reason_btn = protractor_1.element(protractor_1.by.xpath("//*[@formcontrolname='reasonCode']"));
        this.reasoncomnts = protractor_1.element(protractor_1.by.css("[formcontrolname=\"reconComments\"]"));
        //submit = element(by.csscontainigtext("[@id='btn-submit']","Submit"));
        this.createrate_btn = protractor_1.element(protractor_1.by.xpath("//*[text()='Rate Overview']//following::button[@id='btn-create'][1]"));
        this.overall_hdr = protractor_1.element(protractor_1.by.xpath("//*[text()='OVERALL']"));
        this.chckbox = protractor_1.element(protractor_1.by.id("checkx"));
        this.level = protractor_1.element(protractor_1.by.css("[formcontrolname=\"chargeLevelTypeCode\"]"));
        this.amntfield = protractor_1.element(protractor_1.by.id("amountField"));
        this.SignIn = protractor_1.element(protractor_1.by.id("heading1"));
        this.SignInUser = protractor_1.element(protractor_1.by.css("[placeholder='Email or Username']"));
        this.SignInPwd = protractor_1.element(protractor_1.by.css("[placeholder='Password']"));
        this.SignInSubmit = protractor_1.element(protractor_1.by.css("[name='submit']"));
        this.hstrybtn = protractor_1.element(protractor_1.by.xpath("//*[text()='Order History']"));
        this.hstrytable = protractor_1.element(protractor_1.by.xpath("//*[@class='datatable-body']"));
        this.cnt = protractor_1.element.all(protractor_1.by.xpath("//*[@class='datatable-row-center datatable-row-group']"));
    }
}
exports.Update_Objects = Update_Objects;
//# sourceMappingURL=UpdateObjects.js.map