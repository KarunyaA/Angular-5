"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const protractor_1 = require("protractor");
class CCI_AccCreateObjects {
    constructor() {
        this.username = protractor_1.element(protractor_1.by.id("j_username"));
        this.password = protractor_1.element(protractor_1.by.id("j_password"));
        this.login_btn = protractor_1.element(protractor_1.by.className("btn-submit"));
        this.str_url = "https://account-tst.jbhunt.com/account/";
        this.txt_UsrName = protractor_1.element(protractor_1.by.css("[id='username']"));
        this.txt_Pswd = protractor_1.element(protractor_1.by.css("[id='password']"));
        this.btn_SignIn = protractor_1.element(protractor_1.by.css("[name='submit']"));
        this.btn_toggle = protractor_1.element(protractor_1.by.css("[class=\"fa fa-circle-o\"]"));
        this.tab_Account = protractor_1.element(protractor_1.by.cssContainingText(".routeDisplayText", 'Account'));
        this.subTab_AccountSearch = protractor_1.element(protractor_1.by.xpath("//span[text()='Account Search']"));
        this.icon_OverflowMenu = protractor_1.element(protractor_1.by.css("[title='overflow-menu']"));
        this.btn_createAcc = protractor_1.element(protractor_1.by.css("[class='dropdown-item new_account']"));
        //Form Create new Account
        this.txt_Address = protractor_1.element(protractor_1.by.css("[placeholder='Address']"));
        this.txt_City = protractor_1.element(protractor_1.by.css("[placeholder='City']"));
        this.txt_postCode = protractor_1.element(protractor_1.by.css("[placeholder='Postal Code']"));
        this.btncmb_State = protractor_1.element(protractor_1.by.xpath("//*[text()='State']//following::i[@class='caret pull-right'][1]"));
        this.txt_State = protractor_1.element.all(protractor_1.by.css("[placeholder='State']")).first();
        this.btncmb_Country = protractor_1.element(protractor_1.by.xpath("//*[contains(text(),'Country')]//following::i[@class='caret pull-right']"));
        this.txt_Country = protractor_1.element(protractor_1.by.css("[placeholder='Country']"));
        this.txt_AccName = protractor_1.element(protractor_1.by.css("[placeholder='Account Name']"));
        this.txt_PhNum = protractor_1.element(protractor_1.by.css("[placeholder='Phone Number']"));
        this.btn_create = protractor_1.element(protractor_1.by.css("[id='createButton']"));
        this.btn_update = protractor_1.element(protractor_1.by.css("[id='updateButton']"));
        this.str_suggestionAcc = protractor_1.element(protractor_1.by.xpath("//*[text()='Suggested Accounts']"));
        this.valRow_SuggestAcc = protractor_1.element(protractor_1.by.xpath("//datatable-row-wrapper[1]//datatable-body-row"));
        this.cmb_role = protractor_1.element(protractor_1.by.xpath("//datatable-row-wrapper[1]//datatable-body-row//datatable-body-cell[4]//span//i[@class='caret pull-right']"));
        this.str_businessId = protractor_1.element(protractor_1.by.xpath("//datatable-row-wrapper[1]//datatable-body-row//datatable-body-cell[2]//span"));
        this.btn_createArrow = protractor_1.element(protractor_1.by.xpath("//datatable-row-wrapper[1]//datatable-body-row//span[@class='icon-jbh_right_arrow navigateArrow col-3 col-md-3']"));
        this.cmb_roledrpdownNew = protractor_1.element(protractor_1.by.xpath("//*[text()='Create New']//following::i[@class='caret pull-right']"));
        this.txt_roleCreateNew = protractor_1.element(protractor_1.by.css("[placeholder='Role']"));
        this.btn_pendCreate = protractor_1.element(protractor_1.by.css("[id='pendingCreateAccount']"));
        this.txt_AccountSearch = protractor_1.element(protractor_1.by.css("[placeholder='Search by Address, Account Name, Phone Number or Business Identifier']"));
        this.btn_search = protractor_1.element(protractor_1.by.xpath("//i[@class='icon-jbh_search form-control-feedback font18']"));
        this.val_resultrow = protractor_1.element(protractor_1.by.xpath("//datatable-row-wrapper/datatable-body-row"));
        this.str_invalidTxt = protractor_1.element(protractor_1.by.xpath("//tbody//tr[@class='invalidBtn']/td"));
        this.str_errPopup = protractor_1.element(protractor_1.by.xpath("//div[@class='modal-body']/h5[1]"));
        this.btn_errOK = protractor_1.element(protractor_1.by.xpath("//div[@class='modal-content']//button[1]"));
        this.str_AccName = protractor_1.element(protractor_1.by.xpath("//datatable-row-wrapper[1]//datatable-body-cell[1]//span[1]"));
        this.str_Name = protractor_1.element(protractor_1.by.xpath("//div[@class='page-header']/h1"));
    }
}
exports.CCI_AccCreateObjects = CCI_AccCreateObjects;
//# sourceMappingURL=AccountCreateObjects.js.map