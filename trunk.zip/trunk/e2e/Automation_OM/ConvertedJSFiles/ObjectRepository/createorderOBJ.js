"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const protractor_1 = require("protractor");
'use strict';
//module.exports = {  
class LaunchUrl {
    constructor() {
        this.togglefield = protractor_1.element(protractor_1.by.css("[class=\"fa fa-circle-o\"]"));
        this.dbOption = protractor_1.element(protractor_1.by.cssContainingText('.routeDisplayText', 'Create Order'));
        this.Flowmenu = protractor_1.element(protractor_1.by.css("[id=\"btn-append-to-body\"]"));
        this.Neworder = protractor_1.element(protractor_1.by.xpath("//span[@class=\"btn-group open\"]//ul[@class=\"dropdown-menu dropdown-menu-right\"]//li//a[text()=\"Create New Order\"]"));
        this.Newtemplate = protractor_1.element(protractor_1.by.xpath("//span[@class=\"btn-group open\"]//ul[@class=\"dropdown-menu dropdown-menu-right\"]//li//a[text()=\"Create New Template\"]"));
    }
}
exports.LaunchUrl = LaunchUrl;
class CreatePage {
    constructor() {
        this.BillTo = protractor_1.element(protractor_1.by.css("[id=\"billtoaccount\"]"));
        this.BillToValue = protractor_1.element(protractor_1.by.xpath("//ul[@class=\"dropdown-menu\"]//li[@class=\"active\"]//a"));
        //BTContact=element.all(by.cssContainingText(".ui-select-placeholder text-muted","Bill to Account Contact"));
        this.BTContact = protractor_1.element(protractor_1.by.css("[placeholder=\"Bill To Account Contact\"]"));
        //BTContact=element(by.css('[formcontrolname="contactTypeCode"]'));
        //span[text()="Bill To Account Contact"]
        //BTContact=element(by.xpath("//ng-select[@placeholder=\"Bill to Account Contact\"]//div[@class=\"ui-select-container dropdown open\"]"));
        this.ContactValue = protractor_1.element(protractor_1.by.xpath("//ul[@class=\"ui-select-choices dropdown-menu\"]//li//div[@class=\"ui-select-choices-row active\"]//a"));
        this.BU = protractor_1.element(protractor_1.by.css("[formcontrolname=\"financeBusinessUnitCode\"]"));
        this.BUclick = protractor_1.element(protractor_1.by.xpath("//input[@placeholder='Business Unit']"));
        this.BUValue = protractor_1.element(protractor_1.by.xpath("//*[@id='financeBusinessUnitCode']//ul//a/div"));
        //BUValue=element(by.xpath("//ul[@class=\"ui-select-choices dropdown-menu\"]//li//a//div[contains(text(),'JBT')]/ancestor::a"));
        this.SO = protractor_1.element(protractor_1.by.css("[formcontrolname=\"serviceOfferingCode\"]"));
        this.SOclick = protractor_1.element(protractor_1.by.xpath("//input[@placeholder='Service Offering']"));
        this.SOValue = protractor_1.element(protractor_1.by.xpath("//ul[@class=\"ui-select-choices dropdown-menu\"]//li//a[contains(text(),'OTR')]/ancestor::a"));
        this.OPOwner = protractor_1.element(protractor_1.by.css("[id=\"operationalOwner\"]"));
        this.OPValue = protractor_1.element(protractor_1.by.xpath("//ul[@class=\"dropdown-menu\"]//li[@class=\"active\"]//a"));
        this.NextButton = protractor_1.element(protractor_1.by.buttonText("Next"));
        //element(by.css('[formcontrolname="contactTypeCode"]')).element(by.cssContainingText('option','BUCKETS')).click(); 
        //    var allOptions = element.all(by.xpath("///table[@class='caltable']//tbody//tr//td//div[contains(@class,'datevalue currmonth')]"))
        //    allOptions.filter(function (elem) {
        //    return elem.getText().then(function (text) {
        //    return text === '20';
        //    });
        //    }).first().click(); 
        //ADD Stop objects:
        this.Location = protractor_1.element(protractor_1.by.css("[formcontrolname='locationID']"));
        this.LocationContact = protractor_1.element(protractor_1.by.css("[placeholder='Contact']"));
        this.DestinationTab = protractor_1.element(protractor_1.by.xpath("//i[@class='glyphicon accordianIcon icon-jbh_expand']"));
        this.TemplateDestinationTab = protractor_1.element(protractor_1.by.xpath("//i[@class='glyphicon accordianIconCustomize textBold icon-jbh_expand']"));
        //DestinationTab=element(by.xpath("//span[contains(text(),'Destination')]"));
        this.PalletChckBX = protractor_1.element(protractor_1.by.xpath("//input[@id='handlingUnit2']"));
        this.TemplatePalletChckBX = protractor_1.element(protractor_1.by.xpath("//input[@id='remainHandUnits2']"));
        this.SaveButton = protractor_1.element(protractor_1.by.buttonText("Save"));
        this.ItmdescDD = protractor_1.element(protractor_1.by.xpath("//ul[@class='dropdown-menu']//li[@class='active']//a//h5"));
        this.dropdownopt = protractor_1.element(protractor_1.by.css('[formcontrolname="itemHandlingTypeCode"]')).element(protractor_1.by.cssContainingText('option', 'Bag'));
        //Advanced search page
        this.TypeDD = protractor_1.element.all(protractor_1.by.xpath("//ng-select[@placeholder='Type']"));
        //*[@placeholder='Name'][1]
        this.accountname = protractor_1.element(protractor_1.by.xpath("//*[@placeholder='Name'][1]"));
        this.SearchButton = protractor_1.element(protractor_1.by.buttonText("Search"));
        this.Status = protractor_1.element(protractor_1.by.xpath("//ng-select[@id='tagIpOrderSearchStatus']//span//a"));
        this.Showmore = protractor_1.element(protractor_1.by.css("[id='orderSearchShowMore']"));
        //OrdersearchBU=element(by.css("[formcontrolname=\"orderSearchBusinessUnit\"]"));
        this.OrdersearchBU = protractor_1.element(protractor_1.by.xpath("//*[@id='ngSelOrderSearchBusinessUnit']//span[text()='Business Unit']"));
        //OrderSearchSO=element(by.css("[formcontrolname=\"orderSearchServiceOffering\"]"));
        this.OrderSearchSO = protractor_1.element(protractor_1.by.xpath("//*[@id='ngSelOrderSearchServiceOffering']//span[text()='Service Offering']"));
        this.busearch = protractor_1.element(protractor_1.by.css("[formcontrolname=\"orderSearchBusinessUnit\"]")).element(protractor_1.by.xpath("//input[@placeholder='Business Unit']"));
        this.Sosearch = protractor_1.element(protractor_1.by.css("[formcontrolname=\"orderSearchServiceOffering\"]")).element(protractor_1.by.xpath("//input[@placeholder='Service Offering']"));
        //Calendar icon:
        //Calendaricon=element.all(by.xpath("//my-date-picker[@formcontrolname='appointmentStartDate']//span[@class='mydpicon icon-mydpcalendar']"));
        this.Calendaricon = protractor_1.element.all(protractor_1.by.xpath("//button[@class='btnpicker btnpickerenabled btnleftborder']"));
        this.calListdiv = protractor_1.element(protractor_1.by.css("[class=\"selector selectorarrow selectorarrowleft\"]"));
        this.calListtable = protractor_1.element.all(protractor_1.by.xpath("//table[@class='caltable']//tbody//tr"));
        //Shipping option page:
        this.shippingRowparent = protractor_1.element(protractor_1.by.css("[class='datatable-scroll']"));
        this.shippingRowdivs = protractor_1.element.all(protractor_1.by.xpath("//datatable-row-wrapper[@class='datatable-row-wrapper']"));
        this.ShippingFlowMenu = protractor_1.element(protractor_1.by.css("[id='btn-append-to-body']"));
        this.FlowMenuAlternate = protractor_1.element(protractor_1.by.css("[id='a-viewAllShippingOptions']"));
        this.BUSOParent = protractor_1.element.all(protractor_1.by.xpath("//div[@class='datatable-row-center datatable-row-group']//datatable-body-cell[@class='datatable-body-cell sort-active'][1]"));
        this.rightArrow = protractor_1.element(protractor_1.by.css("[class='icon icon-jbh_right_arrow']"));
        //ShippingFlowMenu=element(by.id("btn-append-to-body"));a-createOpport
        this.FlowMenuOppurtunity = protractor_1.element(protractor_1.by.css("[id='a-createOpport']"));
        this.CreateButton = protractor_1.element(protractor_1.by.buttonText("Create"));
        this.optiondots = protractor_1.element.all(protractor_1.by.id("btn-showPopOver"));
        this.Overideall = protractor_1.element(protractor_1.by.xpath("//div[@class='caption']//a[@id='a-overRideAll']"));
        //Overideall=element(by.xpath("//div[div[text()='Warning']]/parent::div/parent::div//a[@id='a-overRideAll' and @class='nodecor']"));
        //div[div[text()='Warning']]/parent::div/parent::div//a[@id='a-overRideAll' and @class='nodecor']
        //Overideall=element(by.linkText("Override All"))
        this.errorparent = protractor_1.element.all(protractor_1.by.xpath("//div[@class='caption']//ul[@class='list-group mar-bot0']//li"));
        this.errorlink = protractor_1.element(protractor_1.by.xpath("//div[@class='caption']//a[@id='a-ruleExcep-desc']"));
        this.errorlinkname = protractor_1.element(protractor_1.by.css("[id='preferedName']"));
        this.errorlinkCmnt = protractor_1.element(protractor_1.by.css("[id='overRideCmtTxt']"));
        this.errordropDown = protractor_1.element(protractor_1.by.xpath("//p[text()='Reason']//following::select")).element(protractor_1.by.cssContainingText('option', 'EDI Tender Will Time-Out'));
        this.OverideErrorButton = protractor_1.element(protractor_1.by.buttonText("Override"));
        this.CreateButtonOverview = protractor_1.element(protractor_1.by.xpath("//button[@id='btn-create' and  @type='button']"));
        //View order page
        //FlowmenuDots=element(by.css("[class='pull-right icon-jbh_three-dots mar-top20 mar-left10 font24 cursor-pointer']"));
        this.threedot = protractor_1.element(protractor_1.by.xpath("//h1[@class='alignHeading']//following::*[@placement='bottom'][1]"));
        this.FlowmenuDots = protractor_1.element(protractor_1.by.xpath("//div[contains(@class,'pull-right icon-jbh_three-dots')]"));
        this.SelectOption = protractor_1.element(protractor_1.by.id("a-processTruck"));
        this.sETapptmntRadio = protractor_1.element(protractor_1.by.id("ipRadioSetNewAppointment"));
        this.WithoutapptmntRadio = protractor_1.element(protractor_1.by.id("ipRadioContinueNewAppointment"));
        this.StndRateRadio = protractor_1.element(protractor_1.by.id("ipRadioStdContractRate"));
        this.NegoRateRadio = protractor_1.element(protractor_1.by.id("ipRadioNegotiatedFee"));
        this.WaivefeeRadio = protractor_1.element(protractor_1.by.id("ipRadioWaiveFee"));
        this.Comment = protractor_1.element(protractor_1.by.id("txtAreaComment"));
        this.Processbutton = protractor_1.element(protractor_1.by.id("btn-tonuProcess"));
        //GotItbutton=element(by.id("btn-gotIt"));
        //button[@id='btn-gotIt' and @class='btn btn-primary btn-custom']
        this.GotItbutton = protractor_1.element(protractor_1.by.buttonText("Got It"));
        //View order sub option
        this.BelowOptions = protractor_1.element.all(protractor_1.by.xpath("//h4[@class='panel-title pull-left']"));
        //LoadIds=element(by.xpath("//div[@class='overview ']//div[@class='loads pull-right']//a[contains(text(),'Load')]"));
        //LoadIds=element(by.xpath("///div[@class='associateloads details pull-left']//following::div[1]"));
        //LoadIds=element(by.xpath("//div[@class='overview ']/div[3]/div/div[2]/p/a"));
        //LoadIds=element(by.xpath("//div[@class='associateloads details pull-left']//following::div[1]"));
        this.LoadIds = protractor_1.element(protractor_1.by.xpath("//div[text()='AssociateLoads']//following::div[@class='loads pull-right']"));
        //LoadIds=element(by.xpath("//div[@class='router-container']//div[@class='overview ']/div[3]/div/div[2]"));
        this.loadcomment = protractor_1.element(protractor_1.by.id("prePlanCmt"));
        //Monitoring page:::
        this.UserNameExpandicon = protractor_1.element(protractor_1.by.id("btn-expand"));
        //Searchname=element(by.css("[formcontrolname=\"myUserName\"]"))
        this.Searchname = protractor_1.element(protractor_1.by.xpath("//div[text()='Sri Ragavi Rajasekar']"));
        //MonitoringDropdown=element.all(by.xpath("//div[@class='jbh-data-table']//select//option"))
        //MonitoringDropdown=element(by.xpath("//div[@class='jbh-data-table']//select")).element(by.css("[value='pending']"));
        this.MonitoringDropdown = protractor_1.element(protractor_1.by.xpath("//select[@class='dropdown mar-bot10']")).element(protractor_1.by.css("[value='pending']"));
        //MonitoringDropdown=element(by.xpath("//select[contains(@class,'dropdown')")).element(by.cssContainingText('option','Pending'));
        this.Excepdata = protractor_1.element(protractor_1.by.css("[class='empty-row']"));
        this.ExpandIcon = protractor_1.element.all(protractor_1.by.xpath("//*[@class='pull-right expanded-arrow']"));
        this.VieworderIcon = protractor_1.element(protractor_1.by.id("btn-pageKeyStrk"));
        this.ViewExpandIcon = protractor_1.element(protractor_1.by.id("btn-expand2"));
        this.ParentDivManageView = protractor_1.element.all(protractor_1.by.xpath("//div[@class='manageColumnstask modal-dialog modal-lg']//ul//li"));
        //FlowMenuoption=element.all(by.xpath("//span[@title='dropdown menu']//ul//li"));
        this.FlowMenuoption = protractor_1.element(protractor_1.by.xpath("//span[@title='dropdown menu']//following::button[text()='Configure Rule Attribute']"));
        //RuleList=element.all(by.xpath("//*[@class='datatable-row-center datatable-row-group']//div//span"));
        //RuleList=element(by.xpath("//datatable-scroller[@class='datatable-scroll']/datatable-row-wrapper[1]/datatable-body-row/div[2]/datatable-body-cell/div/span[@title='Appointment Expired']"));
        this.RuleList = protractor_1.element(protractor_1.by.xpath("//div[@class='datatable-row-center datatable-row-group'][1]//following::span[@title='Appointment Expired']"));
        //RuleList=element(by.xpath("//datatable-body-cell[@class='datatable-body-cell sort-active']//span[@title='Appointment Expired']"));
        //RuleList=element(by.xpath("//span[@title='Appointment Expired']"));
        this.BuDropdown = protractor_1.element(protractor_1.by.xpath("//div[@class='business-group-tag']//following::input[1]"));
        this.BuText = protractor_1.element(protractor_1.by.xpath("//input[@class='form-control ui-select-search']"));
        this.Threedots = protractor_1.element.all(protractor_1.by.css("[id='btn-append-to-body']"));
        this.EditRuleparent = protractor_1.element.all(protractor_1.by.xpath("//ul[@class='dropdown-menu dropdown-menu-right']//li[@class='manageEdit']//a"));
        this.viewName = protractor_1.element(protractor_1.by.css("[placeholder=\"Enter View Name\"]"));
        //BilltoSelect=element.all(by.xpath("//*[@class='form-control isNotSelect ng-pristine ng-valid ng-touched']"));
        this.BilltoSelect = protractor_1.element(protractor_1.by.xpath("//*[@class='modal-body']/div/div[2]/div[2]/div/select")).element(protractor_1.by.cssContainingText('option', 'Is'));
        this.Selectvalue = protractor_1.element.all(protractor_1.by.css("[placeholder='select']"));
        this.Select = protractor_1.element(protractor_1.by.xpath("//*[@class='modal-body']/div/div[2]/div[2]/div[2]/ng-select/div/input[@role='combobox']"));
        this.savebuttoninRule = protractor_1.element(protractor_1.by.xpath("//*[@class='modal-footer']//following::button[text()='Save']"));
        this.SignIn = protractor_1.element(protractor_1.by.id("heading1"));
        this.SignInUser = protractor_1.element(protractor_1.by.css("[placeholder='Email or Username']"));
        this.SignInPwd = protractor_1.element(protractor_1.by.css("[placeholder='Password']"));
        this.SignInSubmit = protractor_1.element(protractor_1.by.css("[name='submit']"));
    }
    ;
    ;
}
exports.CreatePage = CreatePage;
//# sourceMappingURL=createorderOBJ.js.map