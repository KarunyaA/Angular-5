"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const protractor_1 = require("protractor");
const ptor_1 = require("protractor/built/ptor");
const Objects_Order_1 = require("../ObjectRepository/Objects_Order");
const ReadFromXL_1 = require("../CommonFiles/ReadFromXL");
const DictionaryData_1 = require("../DataFiles/DictionaryData");
const ReusableFunctions_1 = require("../PageFiles/ReusableFunctions");
var DictBU_OM = new DictionaryData_1.DataDictionary();
var DictBU_EOM = new DictionaryData_1.DataDictionary();
var OrderID;
let OBJCreate = new Objects_Order_1.Update_Objects();
var ReadFromXL = new ReadFromXL_1.ExcelReader();
var DataDictLib = new DictionaryData_1.DataDictionary();
var DataDictLib1 = new DictionaryData_1.DataDictionary();
let reuse = new ReusableFunctions_1.ReusableFunctions();
var ExcelDataSourceForConf = require('../CommonFiles/ReadFromXL');
var PushAndPullDataDictLib = require('../DataFiles/DictionaryData');
class commonFunctions {
    Get_url(Testcasename) {
        console.log(Testcasename);
        var TcRow = ReadFromXL.FindRowNum(Testcasename, "CreateOrder");
        DataDictLib.pushToDictionaryWithSheet(TcRow, "CreateOrder");
        var urlName = DataDictLib.getFromDictionary('UrlName');
        console.log(urlName);
        protractor_1.browser.get(urlName); //overrides baseURL  
    }
    EnterTextBox(IdValue, Value) {
        var tagname = protractor_1.element(protractor_1.by.css("[formcontrolname=\"" + IdValue + "\"]"));
        tagname.clear();
        tagname.sendKeys(Value);
    }
    SignIn(Testcasename) {
        console.log(Testcasename);
        var TcRow = ReadFromXL.FindRowNum(Testcasename, "CreateOrder");
        DataDictLib.pushToDictionaryWithSheet(TcRow, "CreateOrder");
        var username = DataDictLib.getFromDictionary('Username');
        var Password = DataDictLib.getFromDictionary('Password');
        OBJCreate.SignIn.isDisplayed().then((elem) => {
            if (elem === true)
                OBJCreate.SignInUser.sendKeys(username);
            OBJCreate.SignInPwd.sendKeys(Password);
            reuse.ClickElement(OBJCreate.SignInSubmit, "SignInbutton");
            // OBJCreate.SignInSubmit.click();
            protractor_1.browser.sleep(2000);
        });
    }
    SelectDRopdownValue(IdValue) {
        var tagname = protractor_1.element(protractor_1.by.css("[placeholder=\"" + IdValue + "\"]"));
        tagname.click();
        protractor_1.browser.sleep(2000);
        tagname.sendKeys(ptor_1.protractor.Key.ENTER);
    }
    NavigatefromDashboard(Pagename) {
        OBJCreate.togglefield.click();
        protractor_1.browser.sleep(2000);
        var dbOption = protractor_1.element(protractor_1.by.cssContainingText(".routeDisplayText", "" + Pagename + ""));
        dbOption.click();
        protractor_1.browser.sleep(3000);
    }
    NavigateWhenToggleActive(Pagename) {
        var dbOption = protractor_1.element(protractor_1.by.cssContainingText(".routeDisplayText", "" + Pagename + ""));
        dbOption.click();
        protractor_1.browser.sleep(3000);
    }
    NavigationFunction(Flowvalue, Testcasename) {
        var TcRow = ReadFromXL.FindRowNum(Testcasename, "CreateOrder");
        DataDictLib.pushToDictionaryWithSheet(TcRow, "CreateOrder");
        var NavIdValue = DataDictLib.getFromDictionary('NavIdValue');
        this.NavigatefromDashboard(NavIdValue);
        protractor_1.browser.executeScript("window.scrollBy(-2000, 0)");
        protractor_1.browser.sleep(4000);
        var Neworder = protractor_1.element(protractor_1.by.xpath("//span[@class=\"btn-group open\"]//ul[@class=\"dropdown-menu dropdown-menu-right\"]//li//a[text()=\"" + Flowvalue + "\"]"));
        OBJCreate.Flowmenu.click();
        Neworder.click();
        protractor_1.browser.sleep(6000);
    }
    Equipment() {
        this.dropdown(OBJCreate.equipcategory, "Flatbed");
        this.dropdown(OBJCreate.equiptypecode, "Hot Shot");
        this.dropdown(OBJCreate.equiplength, "40 Feet In Length");
    }
    dropdown(Objelement, strval) {
        Objelement.count().then(function (total) {
            Objelement.each(function (item) {
                var index = 0;
                if (total > index) {
                    var Disp = item.getText().then((elem) => {
                        if (elem.trim() === strval) {
                            item.click();
                            protractor_1.browser.sleep(3000);
                        }
                        else {
                            console.log("View drop down is not available with the values");
                        }
                    });
                }
            });
        });
    }
    Enteringdata(Testcasename) {
        return __awaiter(this, void 0, void 0, function* () {
            var TcRow = ReadFromXL.FindRowNum(Testcasename, "CreateOrder");
            DataDictLib.pushToDictionaryWithSheet(TcRow, "CreateOrder");
            var BUValue = DataDictLib.getFromDictionary('BU');
            var SOValue = DataDictLib.getFromDictionary('SO');
            var BillToValue = DataDictLib.getFromDictionary('BillTO');
            var OpOwner = DataDictLib.getFromDictionary('OpOwner');
            var TitleCreate = DataDictLib.getFromDictionary('CreateTitle');
            var Trailernumber = DataDictLib.getFromDictionary('Trailernumber');
            var TrailerPrefix = DataDictLib.getFromDictionary('TrailerPrefix');
            var Scac = DataDictLib.getFromDictionary('scac');
            OBJCreate.BillTo.sendKeys(BillToValue);
            protractor_1.browser.sleep(5000);
            OBJCreate.BillTo.sendKeys(ptor_1.protractor.Key.ENTER);
            protractor_1.browser.sleep(5000);
            OBJCreate.BTContact.click();
            protractor_1.browser.sleep(2000);
            OBJCreate.BTContact.sendKeys(ptor_1.protractor.Key.ENTER);
            OBJCreate.BU.click();
            OBJCreate.BUclick.sendKeys(BUValue);
            protractor_1.browser.sleep(2000);
            OBJCreate.BUclick.sendKeys(ptor_1.protractor.Key.ENTER);
            protractor_1.browser.sleep(5000);
            OBJCreate.SO.click();
            OBJCreate.SOclick.sendKeys(SOValue);
            protractor_1.browser.sleep(2000);
            OBJCreate.SOclick.sendKeys(ptor_1.protractor.Key.ENTER);
            protractor_1.browser.sleep(3000);
            if (Scac != "Null") {
                OBJCreate.scac.isPresent().then((elem) => {
                    if (elem === true) {
                        OBJCreate.Tradingpartner.click();
                        protractor_1.browser.sleep(1000);
                        OBJCreate.scac.sendKeys(Scac);
                        protractor_1.browser.sleep(3000);
                    }
                });
            }
            if (TrailerPrefix != "NULL") {
                this.Trailer("0000000105", TrailerPrefix);
            }
            if (TitleCreate === "Create New Order") {
                OBJCreate.OPOwner.sendKeys(OpOwner);
                protractor_1.browser.sleep(2000);
                OBJCreate.OPOwner.sendKeys(ptor_1.protractor.Key.ENTER);
            }
            else {
                console.log("Create new template do not contain this field");
            }
            if (TitleCreate === "Create New Order") {
                yield reuse.getTextValueFromElement(OBJCreate.ordernumber).then((text) => {
                    OrderID = text;
                });
                console.log("base order " + OrderID);
                return OrderID;
            }
        });
    }
    Trailer(Trailerno, Trailerprefix) {
        OBJCreate.trailernobutton.click();
        OBJCreate.Trailernumber.sendKeys(Trailerno);
        protractor_1.browser.sleep(2000);
        OBJCreate.Trailernumber.sendKeys(ptor_1.protractor.Key.TAB);
        protractor_1.browser.sleep(3000);
        OBJCreate.Trailerprefix.click();
        OBJCreate.TrailerPrefixText.sendKeys(Trailerprefix);
        OBJCreate.TrailerPrefixText.sendKeys(ptor_1.protractor.Key.ENTER);
        protractor_1.browser.sleep(2000);
    }
    Freightcharges(charge) {
        OBJCreate.freightcharges.click();
        OBJCreate.freightchargestext.sendKeys(charge);
        OBJCreate.freightchargestext.sendKeys(ptor_1.protractor.Key.ENTER);
    }
    Shipmentdetails(charge, ordervalue, fleetcode) {
        OBJCreate.ShipmentIdentificationNo.sendKeys(charge);
        OBJCreate.shipsecndarytype.click();
        OBJCreate.shipsecndarytypetext.sendKeys("Will");
        OBJCreate.ordervalue.sendKeys(ordervalue);
        OBJCreate.fleetcode.sendkeys(fleetcode);
    }
    AddstopsOrigin(Testcasename, Scheduled, Requested, pickupdate) {
        OBJCreate.NextButton.click();
        protractor_1.browser.sleep(8000);
        var TcRow = ReadFromXL.FindRowNum(Testcasename, "StopDetails");
        DataDictLib.pushToDictionaryWithSheet(TcRow, "StopDetails");
        var Pickup = DataDictLib.getFromDictionary('Pickup');
        var Delivery = DataDictLib.getFromDictionary('Delivery');
        var ItemQty = DataDictLib.getFromDictionary('ItemQty');
        var ItemWt = DataDictLib.getFromDictionary('ItemWt');
        var ItemChar = DataDictLib.getFromDictionary('ItemChar');
        var TitleCreate = DataDictLib.getFromDictionary('CreateTitle');
        var NoOfAppoint = DataDictLib.getFromDictionary('NoOfAppoint');
        var NoOfItem = DataDictLib.getFromDictionary('NoOfitems');
        var NoOfStop = DataDictLib.getFromDictionary('Noofstops');
        this.EnterTextBox("locationID", Pickup);
        protractor_1.browser.sleep(2000);
        OBJCreate.BillToValue.click();
        protractor_1.browser.sleep(4000);
        this.SelectDRopdownValue("Contact");
        protractor_1.browser.sleep(4000);
        if (Requested == "Requested") {
            if (NoOfAppoint == 1) {
                this.Selectcalendericon(pickupdate, 0);
                protractor_1.browser.sleep(2000);
                this.SelectTime("08:00", 0);
                protractor_1.browser.sleep(2000);
                this.Selectcalendericon(pickupdate, 1);
                protractor_1.browser.sleep(2000);
                this.SelectTime("09:00", 1);
                protractor_1.browser.sleep(2000);
            }
            if (NoOfAppoint > 1) {
                for (var i = 2; i < NoOfAppoint; i++) {
                    console.log(NoOfAppoint + 2);
                    this.Selectcalendericon(pickupdate, i);
                    protractor_1.browser.sleep(2000);
                    this.SelectTime("08:00", i);
                    this.Selectcalendericon(pickupdate, i + 1);
                    protractor_1.browser.sleep(2000);
                    this.SelectTime("09:00", i + 1);
                    protractor_1.browser.sleep(2000);
                }
            }
        }
        if (Scheduled == "Scheduled") {
            if (NoOfAppoint == 1) {
                OBJCreate.AddappointmentIcon.get(1).click();
                if (TitleCreate === "Create New Order") {
                    OBJCreate.AddappointmentIcon.get(1).click();
                    this.Selectcalendericon(pickupdate, 2);
                    protractor_1.browser.sleep(2000);
                    this.SelectTime("08:30", 2);
                    protractor_1.browser.sleep(2000);
                    this.Selectcalendericon(pickupdate, 3);
                    protractor_1.browser.sleep(2000);
                    this.SelectTime("09:30", 3);
                    protractor_1.browser.sleep(2000);
                }
                if (TitleCreate === "Create New Template") {
                    OBJCreate.AddappointmentIcon.get(0).click();
                    this.Selectcalendericon(pickupdate, 0);
                    protractor_1.browser.sleep(2000);
                    this.SelectTime("08:30", 0);
                    protractor_1.browser.sleep(2000);
                    this.Selectcalendericon(pickupdate, 1);
                    protractor_1.browser.sleep(2000);
                    this.SelectTime("09:30", 1);
                    protractor_1.browser.sleep(2000);
                }
            }
            if (NoOfAppoint > 1) {
                for (var i = 4; i <= 4; i++) {
                    console.log(NoOfAppoint + 2);
                    OBJCreate.AddappointmentIcon.get(1).click();
                    this.Selectcalendericon(pickupdate, 2);
                    protractor_1.browser.sleep(2000);
                    this.SelectTime("08:00", 2);
                    // browser.sleep(2000);
                    this.Selectcalendericon(pickupdate, 3);
                    protractor_1.browser.sleep(2000);
                    this.SelectTime("09:00", 3);
                    protractor_1.browser.sleep(4000);
                    protractor_1.browser.executeScript("window.scrollTo(0,-100)");
                    OBJCreate.AddappointmentIcon.get(0).click();
                    protractor_1.browser.sleep(4000);
                    OBJCreate.AddappointmentIconschedule.click();
                    this.Selectcalendericon(pickupdate, i);
                    protractor_1.browser.sleep(2000);
                    this.SelectTime("09:00", i);
                    this.Selectcalendericon(pickupdate, i + 1);
                    protractor_1.browser.sleep(2000);
                    this.SelectTime("10:00", i + 1);
                    protractor_1.browser.sleep(2000);
                }
            }
        }
        protractor_1.browser.sleep(3000);
        this.HandlingUnit(Testcasename);
        protractor_1.browser.sleep(3000);
        this.Itemdetails(Testcasename);
        var tagname = protractor_1.element(protractor_1.by.css("[formcontrolname=\"itemDescription\"]"));
        tagname.sendKeys(ptor_1.protractor.Key.ENTER);
        protractor_1.browser.sleep(15000);
    }
    AppointmentOrigin(Testcasename, Scheduled, pickupdate, Ordername) {
        var TcRow = ReadFromXL.FindRowNum(Testcasename, "StopDetails");
        DataDictLib.pushToDictionaryWithSheet(TcRow, "StopDetails");
        var NoOfAppoint = DataDictLib.getFromDictionary('NoOfAppoint');
        var NoOfItem = DataDictLib.getFromDictionary('NoOfitems');
        var NoOfStop = DataDictLib.getFromDictionary('Noofstops');
        if (Scheduled == "Scheduled") {
            if (NoOfAppoint == 1) {
                OBJCreate.AddappointmentIcon.get(1).click();
                if (Ordername === "Create New Order") {
                    OBJCreate.AddappointmentIcon.get(1).click();
                    this.Selectcalendericon(pickupdate, 2);
                    protractor_1.browser.sleep(2000);
                    this.SelectTime("08:30", 2);
                    protractor_1.browser.sleep(2000);
                    this.Selectcalendericon(pickupdate, 3);
                    protractor_1.browser.sleep(2000);
                    this.SelectTime("09:30", 3);
                    protractor_1.browser.sleep(2000);
                }
                if (Ordername === "Create New Template") {
                    OBJCreate.AddappointmentIcon.get(0).click();
                    this.Selectcalendericon(pickupdate, 0);
                    protractor_1.browser.sleep(2000);
                    this.SelectTime("08:30", 0);
                    protractor_1.browser.sleep(2000);
                    this.Selectcalendericon(pickupdate, 1);
                    protractor_1.browser.sleep(2000);
                    this.SelectTime("09:30", 1);
                    protractor_1.browser.sleep(2000);
                }
            }
        }
    }
    AppiontmentDestination(Testcasename, Scheduled, DeliveryDate, Ordername, Index) {
        var TcRow = ReadFromXL.FindRowNum(Testcasename, "StopDetails");
        DataDictLib.pushToDictionaryWithSheet(TcRow, "StopDetails");
        var NoOfAppoint = DataDictLib.getFromDictionary('NoOfAppoint');
        var NoOfItem = DataDictLib.getFromDictionary('NoOfitems');
        var NoOfStop = DataDictLib.getFromDictionary('Noofstops');
        if (Scheduled == "Scheduled") {
            if (Ordername === "Create New Order") {
                OBJCreate.AddappointmentIcon.get(1).click();
                this.Selectcalendericon(DeliveryDate, Index);
                protractor_1.browser.sleep(2000);
                this.SelectTime("08:30", Index);
                this.Selectcalendericon(DeliveryDate, (Index + 1));
                protractor_1.browser.sleep(2000);
                this.SelectTime("09:30", (Index + 1));
                protractor_1.browser.sleep(2000);
            }
            if (Ordername === "Create New Template") {
                OBJCreate.AddappointmentIcon.get(0).click();
                this.Selectcalendericon(DeliveryDate, 0);
                protractor_1.browser.sleep(2000);
                this.SelectTime("08:30", 0);
                protractor_1.browser.sleep(2000);
                this.Selectcalendericon(DeliveryDate, 1);
                protractor_1.browser.sleep(2000);
                this.SelectTime("09:30", 1);
                protractor_1.browser.sleep(2000);
            }
        }
    }
    HandlingUnit(Testcasename) {
        var TcRow = ReadFromXL.FindRowNum(Testcasename, "StopDetails");
        DataDictLib.pushToDictionaryWithSheet(TcRow, "StopDetails");
        var ItemQty = DataDictLib.getFromDictionary('ItemQty');
        var ItemWt = DataDictLib.getFromDictionary('ItemWt');
        this.EnterTextBox("itemHandlingTypeQuantity", ItemQty);
        protractor_1.browser.sleep(2000);
        this.EnterTextBox("itemHandlingUnitWeight", ItemWt);
        protractor_1.browser.sleep(2000);
        var Handlingunit = protractor_1.element(protractor_1.by.css("[formcontrolname=\"itemHandlingUnitHeight\"]"));
        Handlingunit.sendKeys(ptor_1.protractor.Key.TAB);
        protractor_1.browser.sleep(5000);
    }
    Itemdetails(Testcasename) {
        var TcRow = ReadFromXL.FindRowNum(Testcasename, "StopDetails");
        DataDictLib.pushToDictionaryWithSheet(TcRow, "StopDetails");
        var ItemQty = DataDictLib.getFromDictionary('ItemQty');
        var ItemWt = DataDictLib.getFromDictionary('ItemWt');
        var ItemChar = DataDictLib.getFromDictionary('ItemChar');
        var NoOfItem = DataDictLib.getFromDictionary('NoOfitems');
        if (NoOfItem == 0) {
            this.EnterTextBox("packagingUnitTypeQuantity", ItemQty);
            this.EnterTextBox("itemWeight", ItemWt);
            protractor_1.browser.sleep(5000);
            var itemunit = protractor_1.element(protractor_1.by.css("[formcontrolname=\"itemHeight\"]"));
            itemunit.sendKeys(ptor_1.protractor.Key.TAB);
            protractor_1.browser.sleep(12000);
            this.EnterTextBox("itemDescription", ItemChar);
            protractor_1.browser.sleep(5000);
            var tagname = protractor_1.element(protractor_1.by.css("[formcontrolname=\"itemDescription\"]"));
        }
        if (NoOfItem >= 1) {
            this.EnterTextBox("packagingUnitTypeQuantity", ItemQty);
            this.EnterTextBox("itemWeight", ItemWt);
            protractor_1.browser.sleep(5000);
            var itemunit = protractor_1.element(protractor_1.by.css("[formcontrolname=\"itemHeight\"]"));
            itemunit.sendKeys(ptor_1.protractor.Key.TAB);
            protractor_1.browser.sleep(12000);
            this.EnterTextBox("itemDescription", ItemChar);
            protractor_1.browser.sleep(6000);
            var tagname = protractor_1.element(protractor_1.by.css("[formcontrolname=\"itemDescription\"]"));
            tagname.sendKeys(ptor_1.protractor.Key.ENTER);
            protractor_1.browser.sleep(5000);
            (OBJCreate.AddappointmentIcon.get(5)).click();
            protractor_1.browser.sleep(5000);
            for (var i = 1; i <= NoOfItem; i++) {
                var j = 5;
                var AddItem = ((j += 2));
                console.log((j += 2));
                console.log("Console value for j is ", j);
                var ItemQtyvalue = (OBJCreate.tagname.get(i));
                var ItemWeightValue = (OBJCreate.tagname1.get(i));
                var itemunit = (OBJCreate.itemunit.get(i));
                var ItemWeightValue = (OBJCreate.tagname1.get(i));
                var ItemCharName = (OBJCreate.tagname2.get(i));
                var ItemCharFreezeName = (OBJCreate.itemchar.get(i));
                var NMFCNumber = (OBJCreate.NMFCNumber.get(i));
                ItemQtyvalue.clear();
                ItemQtyvalue.sendKeys(ItemQty);
                ItemWeightValue.clear();
                ItemWeightValue.sendKeys(ItemWt);
                protractor_1.browser.sleep(5000);
                itemunit.sendKeys(ptor_1.protractor.Key.TAB);
                protractor_1.browser.sleep(5000);
                ItemCharName.click();
                ItemCharName.sendKeys(ptor_1.protractor.Key.TAB);
                NMFCNumber.sendKeys(ptor_1.protractor.Key.TAB);
                protractor_1.browser.sleep(3000);
                ItemCharName.clear();
                ItemCharName.sendKeys(ItemChar);
                protractor_1.browser.sleep(5000);
                ItemCharName.sendKeys(ptor_1.protractor.Key.ENTER);
                protractor_1.browser.sleep(5000);
                (OBJCreate.AddappointmentIcon.get(AddItem)).click();
                protractor_1.browser.sleep(5000);
            }
        }
    }
    AddstopsDestination(Testcasename, Scheduled, Requested, DeliveryDate) {
        var TitleCreate = DataDictLib.getFromDictionary('CreateTitle');
        var Delivery = DataDictLib.getFromDictionary('Delivery');
        var pickupdate = DataDictLib.getFromDictionary('Pickup');
        var deliverdate = DataDictLib.getFromDictionary('Delivery');
        var StartTime = DataDictLib.getFromDictionary('PickupDate');
        var endTime = DataDictLib.getFromDictionary('Deliverydate');
        if (TitleCreate === "Create New Order") {
            OBJCreate.DestinationTab.click();
            protractor_1.browser.sleep(7000);
        }
        else {
            OBJCreate.TemplateDestinationTab.click();
            protractor_1.browser.sleep(7000);
        }
        this.EnterTextBox("locationID", Delivery);
        protractor_1.browser.sleep(4000);
        OBJCreate.BillToValue.click();
        protractor_1.browser.sleep(2000);
        this.SelectDRopdownValue("Contact");
        protractor_1.browser.sleep(3000);
        if (Requested == "Requested") {
            this.Selectcalendericon(DeliveryDate, 0);
            protractor_1.browser.sleep(2000);
            this.SelectTime("08:00", 0);
            this.Selectcalendericon(DeliveryDate, 1);
            protractor_1.browser.sleep(2000);
            this.SelectTime("09:00", 1);
            protractor_1.browser.sleep(2000);
        }
        if (Scheduled == "Scheduled") {
            if (TitleCreate === "Create New Order") {
                OBJCreate.AddappointmentIcon.get(1).click();
                this.Selectcalendericon(DeliveryDate, 2);
                protractor_1.browser.sleep(2000);
                this.SelectTime("08:30", 2);
                protractor_1.browser.sleep(2000);
                this.Selectcalendericon(DeliveryDate, 3);
                protractor_1.browser.sleep(2000);
                this.SelectTime("09:30", 3);
                protractor_1.browser.sleep(2000);
            }
            if (TitleCreate === "Create New Template") {
                OBJCreate.AddappointmentIcon.get(0).click();
                this.Selectcalendericon(pickupdate, 0);
                protractor_1.browser.sleep(2000);
                this.SelectTime("08:30", 0);
                protractor_1.browser.sleep(2000);
                this.Selectcalendericon(pickupdate, 1);
                protractor_1.browser.sleep(2000);
                this.SelectTime("09:30", 1);
                protractor_1.browser.sleep(2000);
            }
        }
        protractor_1.browser.sleep(5000);
        this.DateValidationCreateOrderOverview("01/04/2018", "01/05/2018");
        if (TitleCreate === "Create New Order") {
            OBJCreate.PalletChckBX.isPresent().then((elem) => {
                OBJCreate.PalletChckBX.click();
                protractor_1.browser.sleep(6000);
            });
        }
        else {
            OBJCreate.PalletChckBX.isPresent().then((elem) => {
                OBJCreate.TemplatePalletChckBX.click();
                protractor_1.browser.sleep(6000);
            });
        }
        protractor_1.browser.sleep(8000);
        console.log("End of destination function");
    }
    MultiplePalletCheckbox(Testcasename, TitleCreate) {
        var DataDictLib1 = new DictionaryData_1.DataDictionary();
        var DataDictLib2 = new DictionaryData_1.DataDictionary();
        var TcRow1 = ReadFromXL.FindRowNum(Testcasename, "CreateOrder");
        DataDictLib2.pushToDictionaryWithSheet(TcRow1, "CreateOrder");
        var TcRow = ReadFromXL.FindRowNum(Testcasename, "StopDetails");
        DataDictLib1.pushToDictionaryWithSheet(TcRow, "StopDetails");
        var Stopnumber = DataDictLib1.getFromDictionary('StopNumber');
        if (TitleCreate === "Create New Order") {
            OBJCreate.AddStopDestinationTab.get(Stopnumber).click();
            protractor_1.browser.sleep(3000);
            protractor_1.browser.executeScript("window.scrollTo(0,500)");
            if (Stopnumber >= 1) {
                protractor_1.browser.sleep(3000);
                for (var i = 1; i <= Stopnumber; i++) {
                    protractor_1.browser.executeScript("window.scrollTo(0,500)");
                    (OBJCreate.MultiplePalletChckBX.get(i)).click();
                    protractor_1.browser.sleep(6000);
                }
            }
        }
        else {
            OBJCreate.TemplateAddStopDestinationTab.get((Stopnumber)).click();
            protractor_1.browser.sleep(3000);
            protractor_1.browser.executeScript("window.scrollTo(0,500)");
            if (Stopnumber >= 1) {
                protractor_1.browser.sleep(3000);
                for (var i = 1; i <= Stopnumber; i++) {
                    protractor_1.browser.executeScript("window.scrollTo(0,500)");
                    (OBJCreate.MultiplePalletChckBX.get(i)).click();
                    protractor_1.browser.sleep(6000);
                }
            }
        }
    }
    AddIntermediateStopDetails(Testcasename, Requested, Pickupdate, StopNumber) {
        protractor_1.browser.sleep(5000);
        OBJCreate.StopReason.click();
        OBJCreate.StopReasonText.click();
        protractor_1.browser.sleep(3000);
        var DataDictLibStop = new DictionaryData_1.DataDictionary();
        var TcRow = ReadFromXL.FindRowNum(Testcasename, "InterStops");
        DataDictLib.pushToDictionaryWithSheet(TcRow, "InterStops");
        var Location = DataDictLib.getFromDictionary('Stop' + StopNumber);
        //var Delivery =DataDictLib.getFromDictionary('Delivery');
        console.log("ItemQty" + StopNumber);
        var ItemQty = DataDictLib.getFromDictionary('ItemQty' + StopNumber);
        var ItemWt = DataDictLib.getFromDictionary('ItemWt' + StopNumber);
        var ItemChar = DataDictLib.getFromDictionary('ItemChar' + StopNumber);
        var TitleCreate = DataDictLib.getFromDictionary('CreateTitle');
        console.log("Console values are as below " + Location, +ItemQty, +ItemWt);
        var NoOfAppoint = DataDictLib.getFromDictionary('NoOfAppoint');
        var NoOfItem = DataDictLib.getFromDictionary('NoOfitems');
        var NoOfStop = DataDictLib.getFromDictionary('Noofstops');
        this.EnterTextBox("locationID", Location);
        protractor_1.browser.sleep(3000);
        OBJCreate.BillToValue.click();
        protractor_1.browser.sleep(4000);
        this.SelectDRopdownValue("Contact");
        protractor_1.browser.sleep(4000);
        if (Requested == "Requested") {
            if (NoOfAppoint == 1) {
                this.Selectcalendericon(Pickupdate, 0);
                protractor_1.browser.sleep(2000);
                this.SelectTime("08:00", 0);
                protractor_1.browser.sleep(2000);
                this.Selectcalendericon(Pickupdate, 1);
                protractor_1.browser.sleep(2000);
                this.SelectTime("09:00", 1);
                protractor_1.browser.sleep(2000);
            }
            if (NoOfAppoint > 1) {
                for (var i = 2; i < NoOfAppoint; i++) {
                    console.log(NoOfAppoint + 2);
                    this.Selectcalendericon(Pickupdate, i);
                    protractor_1.browser.sleep(2000);
                    this.SelectTime("08:00", i);
                    this.Selectcalendericon(Pickupdate, i + 1);
                    protractor_1.browser.sleep(2000);
                    this.SelectTime("09:00", i + 1);
                    protractor_1.browser.sleep(2000);
                }
            }
        }
        if (Requested == "Scheduled") {
            if (NoOfAppoint == 1) {
                OBJCreate.AddappointmentIcon.get(1).click();
                this.Selectcalendericon(Pickupdate, 2);
                protractor_1.browser.sleep(2000);
                this.SelectTime("08:00", 2);
                this.Selectcalendericon(Pickupdate, 3);
                protractor_1.browser.sleep(2000);
                this.SelectTime("09:00", 3);
                protractor_1.browser.sleep(2000);
            }
            if (NoOfAppoint > 1) {
                for (var i = 4; i <= 4; i++) {
                    console.log(NoOfAppoint + 2);
                    OBJCreate.AddappointmentIcon.get(1).click();
                    this.Selectcalendericon(Pickupdate, 2);
                    protractor_1.browser.sleep(2000);
                    this.SelectTime("08:00", 2);
                    this.Selectcalendericon(Pickupdate, 3);
                    protractor_1.browser.sleep(2000);
                    this.SelectTime("09:00", 3);
                    protractor_1.browser.sleep(4000);
                    protractor_1.browser.executeScript("window.scrollTo(0,-100)");
                    OBJCreate.AddappointmentIcon.get(0).click();
                    protractor_1.browser.sleep(4000);
                    OBJCreate.AddappointmentIconschedule.click();
                    this.Selectcalendericon(Pickupdate, i);
                    protractor_1.browser.sleep(2000);
                    this.SelectTime("09:00", i);
                    this.Selectcalendericon(Pickupdate, i + 1);
                    protractor_1.browser.sleep(2000);
                    this.SelectTime("10:00", i + 1);
                    protractor_1.browser.sleep(2000);
                }
            }
        }
        protractor_1.browser.sleep(3000);
        this.HandlingUnit(Testcasename);
        protractor_1.browser.sleep(3000);
        this.Itemdetails(Testcasename);
        var tagname = protractor_1.element(protractor_1.by.css("[formcontrolname=\"itemDescription\"]"));
        tagname.sendKeys(ptor_1.protractor.Key.ENTER);
        protractor_1.browser.sleep(15000);
    }
    Selectcalendericon(ApntmntDate, calendarvalue) {
        var datevalue = ApntmntDate.split('/');
        var date = datevalue[0];
        var month = datevalue[1];
        var year = datevalue[2];
        console.log(year);
        var val = (OBJCreate.Calendaricon.get(calendarvalue)).isPresent().then((elem) => {
            if (elem === true) {
                protractor_1.browser.sleep(3000);
                var icon = OBJCreate.Calendaricon.get(calendarvalue);
                protractor_1.browser.sleep(4000);
                icon.click();
                protractor_1.browser.sleep(4000);
                var value = null;
                let dateval = value;
                let MonthInput = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                console.log(MonthInput.length);
                var j;
                for (var i = 0; i < MonthInput.length; i++) {
                    if (month === (MonthInput[i])) {
                        j = i + 1;
                    }
                }
                console.log(j);
                var monthvalue = protractor_1.element(protractor_1.by.css("[class=\"headerlabelbtn monthlabel\"]"));
                var yearvalue = protractor_1.element(protractor_1.by.css("[class=\"headerlabelbtn yearlabel\"]"));
                var viewContainer = protractor_1.element(protractor_1.by.css("[class=\"headerlabelbtn monthlabel\"]")).getText();
                viewContainer.then(console.log);
                if ((monthvalue.getText().then(function (text) { console.log(text); return text === month; })) && (yearvalue.getText().then(function (text) { console.log(text); return text === year; }))) {
                    protractor_1.browser.sleep(3000);
                    var allOptions = protractor_1.element.all(protractor_1.by.xpath("//table[@class='caltable']//tbody//tr//td//div[contains(@class,'datevalue currmonth')]//span"));
                    allOptions.filter(function (elem) {
                        return elem.getText().then(function (text) {
                            return text === date;
                        });
                    }).first().click();
                    protractor_1.browser.sleep(4000);
                }
                console.log("Clicking on the calendar icon");
            }
            else {
                console.log("Calendar icon is not available");
            }
        });
    }
    SelectTime(ApntmntTime, calendarvalue) {
        var datevalue = ApntmntTime.split(':');
        var hour = datevalue[0];
        var min = datevalue[1];
        OBJCreate.apnmntHR.get(calendarvalue).sendKeys(hour);
        OBJCreate.apnmntMIN.get(calendarvalue).sendKeys(min);
    }
    InternationalShipment() {
        OBJCreate.shipmentreq.click();
        OBJCreate.shipmentreqText.sendKeys("Inter");
        OBJCreate.shipmentreqText.sendKeys(ptor_1.protractor.Key.ENTER);
        OBJCreate.interservice.click();
        OBJCreate.interservicetext.sendKeys("door");
        OBJCreate.interservicetext.sendKeys(ptor_1.protractor.Key.ENTER);
    }
    OrderHistory() {
        var EC = ptor_1.protractor.ExpectedConditions;
        protractor_1.browser.wait(EC.visibilityOf(OBJCreate.hstrybtn), 10000).then(function () {
            protractor_1.browser.executeScript("window.scrollTo(0,2000)");
            OBJCreate.hstrybtn.click();
            protractor_1.browser.sleep(5000);
        });
        var val = (OBJCreate.hstrytable).isPresent().then((elem) => {
            if (elem === true) {
                console.log("Order History is  available");
                OBJCreate.cnt;
                OBJCreate.cnt.count().then((intcnt) => {
                    if (intcnt > 0) {
                        console.log("Records count is available" + intcnt);
                    }
                    else {
                        console.log("Records count are not found");
                    }
                    OBJCreate.AcceptanceRulepass.isPresent().then((elem) => {
                        if (elem === true) {
                            console.log("Acceptance rule is passed");
                        }
                        else
                            console.log("Acceptance rule is not passed");
                    });
                    OBJCreate.Orderstatus.isPresent().then((elem) => {
                        if (elem === true) {
                            console.log("order status is changed from pending to accepted");
                        }
                        else
                            console.log("order status is not changed from pending to accepted");
                    });
                });
            }
            else {
                console.log("Order History is not available");
            }
        });
    }
    AdvancedSearchwithdate(Pickupdate, DeliveryDate, CreatedDate) {
        this.ElementWait(true, OBJCreate.allOptions);
        OBJCreate.acceptclose.click();
        this.Selectcalendericon(Pickupdate, 0);
        protractor_1.browser.sleep(2000);
        this.Selectcalendericon(Pickupdate, 1);
        protractor_1.browser.sleep(2000);
        this.Selectcalendericon(DeliveryDate, 2);
        protractor_1.browser.sleep(2000);
        this.Selectcalendericon(DeliveryDate, 3);
        protractor_1.browser.sleep(2000);
        this.Selectcalendericon(CreatedDate, 4);
        protractor_1.browser.sleep(2000);
        this.Selectcalendericon(CreatedDate, 5);
        protractor_1.browser.sleep(2000);
    }
    ValidateRateOption() {
        protractor_1.browser.sleep(5000);
        protractor_1.browser.executeScript("window.scrollTo(0,-500)");
        var EC = ptor_1.protractor.ExpectedConditions;
        protractor_1.browser.wait(EC.visibilityOf(OBJCreate.optiondots.get(0)), 10000).then(function () {
            OBJCreate.optiondots.get(0).click();
            protractor_1.browser.sleep(3000);
        });
        protractor_1.browser.executeScript("window.scrollTo(0,500)");
        OBJCreate.AllInRate.isPresent().then((elem) => {
            var value = 0;
            {
                var Disp = OBJCreate.AllInRate.getText().then((text) => {
                    if (text.trim() != "0") {
                        console.log("All In Rate is available in the rate overview popup");
                    }
                });
            }
        });
        OBJCreate.FuelSurcharge.isPresent().then((elem) => {
            var value = 0;
            {
                var Disp = OBJCreate.FuelSurcharge.getText().then((text) => {
                    if (text.trim() != "0") {
                        console.log("Fuel Surcharge is available in the rate overview popup");
                    }
                });
            }
            OBJCreate.optiondots.get(0).click();
        });
    }
    AppointmentValidation() {
        this.ElementValidation(OBJCreate.apnmt_ordovrview);
        this.ElementValidation(OBJCreate.apnmt_stop);
    }
    ElementValidation(Objelement) {
        Objelement.isPresent().then((elem) => {
            if (elem == true) {
                Objelement.getText().then((text) => {
                    console.log(text);
                    console.log("Appointment details is present in order overview" + text);
                });
            }
        });
    }
    ;
    ElementValidationAdvancedsearch(AppointmnetDatepickup, appointmentdateDelivery) {
        OBJCreate.ApntdatepickupAdvanced.isPresent().then((elem) => {
            if (elem == true) {
                OBJCreate.ApntdatepickupAdvanced.getText().then((text) => {
                    var date = text.split(" ");
                    var PickupDate = date[0];
                    var pickupTime = date[1];
                    if (PickupDate == AppointmnetDatepickup) {
                        console.log("Pickup Appointment details in advanced search is same as the appointment date while creating the order " + text);
                    }
                });
            }
        });
        OBJCreate.ApntdatedeliveryAdvanced.isPresent().then((elem) => {
            if (elem == true) {
                OBJCreate.ApntdatedeliveryAdvanced.getText().then((text) => {
                    var date = text.split(" ");
                    var PickupDate = date[0];
                    var pickupTime = date[1];
                    if (PickupDate == appointmentdateDelivery) {
                        console.log("Delivery Appointment details in advanced search is same as the appointment date while creating the order " + text);
                    }
                });
            }
        });
    }
    DateValidationCreateOrderOverview(AppointmnetDatepickup, appointmentdateDelivery) {
        OBJCreate.PickDateorderOverview.isPresent().then((elem) => {
            if (elem == true) {
                OBJCreate.PickDateorderOverview.getText().then((text) => {
                    var date = text.split(" ");
                    var PickupDate = date[0];
                    var pickupTime = date[1];
                    if (PickupDate == AppointmnetDatepickup) {
                        console.log("Pickup Appointment details and Time zone in Order overview  is same as the appointment date while creating the order " + text);
                    }
                });
            }
        });
        OBJCreate.DelidateorderOverview.isPresent().then((elem) => {
            if (elem == true) {
                OBJCreate.DelidateorderOverview.getText().then((text) => {
                    var date = text.split(" ");
                    var Deliverydate = date[0];
                    var DeliveryTime = date[1];
                    if (Deliverydate == appointmentdateDelivery) {
                        console.log("Delivery Appointment details and Time Zone in Order overview is same as the appointment date while creating the order " + text);
                    }
                });
            }
        });
    }
    TemplateSearch(Testcasename) {
        return __awaiter(this, void 0, void 0, function* () {
            var scac = DataDictLib.getFromDictionary('scac');
            OBJCreate.template_filter.click();
            OBJCreate.scacsearch.click();
            OBJCreate.scactext.click();
            protractor_1.browser.sleep(2000);
            OBJCreate.scactext.sendKeys(scac);
            protractor_1.browser.sleep(5000);
            OBJCreate.scacenter.click();
            protractor_1.browser.executeScript("window.scrollBy(0,-500)");
            OBJCreate.three_dot.get(0).click();
            OBJCreate.ViewTemplate.click();
            protractor_1.browser.sleep(6000);
            OBJCreate.threedot_temp.click();
            OBJCreate.tempdrop.click();
            protractor_1.browser.sleep(25000);
            this.ElementWait(true, OBJCreate.ordernumber);
            yield reuse.getTextValueFromElement(OBJCreate.ordernumber).then((text) => {
                OrderID = text;
            });
            console.log("base order " + OrderID);
            return OrderID;
        });
    }
    ElementWait(elemValCheck, OBJelem) {
        return __awaiter(this, void 0, void 0, function* () {
            var cntr = 0;
            var displayvalue = false;
            var textvalue = "";
            var value = false;
            while (value === false) {
                protractor_1.browser.sleep(3000);
                yield OBJelem.isPresent().then((elem) => {
                    console.log(cntr + "th time");
                    displayvalue = elem;
                    console.log("1st scope" + displayvalue);
                });
                protractor_1.browser.sleep(3000);
                if (elemValCheck == true && displayvalue.valueOf() === true) {
                    console.log(" entering into text validation");
                    yield OBJelem.getText().then((elem1) => {
                        console.log(cntr + "th time");
                        textvalue = elem1;
                        console.log("2nd scope" + textvalue);
                    });
                }
                if (cntr > 12) {
                    break;
                }
                if (elemValCheck == true) {
                    if (textvalue !== "")
                        value = displayvalue;
                    else
                        value = false;
                }
                else
                    value = displayvalue;
                console.log(value);
                cntr++;
            }
        });
    }
    HazmatDetails() {
        var Item = DataDictLib.getFromDictionary('HAZMAT');
        var UNNA = DataDictLib.getFromDictionary('UNNA');
        var UNNAval = DataDictLib.getFromDictionary('UNNAval');
        var shippingname = DataDictLib.getFromDictionary('Hazmatshippingname');
        console.log("Entered Hazmat");
        protractor_1.browser.sleep(6000);
        OBJCreate.itemcharname.click();
        protractor_1.browser.sleep(3000);
        OBJCreate.itemchar_type.sendKeys(Item);
        OBJCreate.itemchar_type.sendKeys(ptor_1.protractor.Key.SPACE);
        OBJCreate.itemchar_type.sendKeys(ptor_1.protractor.Key.ENTER);
        protractor_1.browser.sleep(3000);
        OBJCreate.unnacode.click();
        OBJCreate.unnacode.sendKeys(UNNAval);
        OBJCreate.unnacode.sendKeys(ptor_1.protractor.Key.ENTER);
        OBJCreate.shippingname.click();
        OBJCreate.shippingname.sendKeys(shippingname);
        OBJCreate.shippingname.sendKeys(ptor_1.protractor.Key.ENTER);
        OBJCreate.primary.click();
        OBJCreate.primary.sendKeys(ptor_1.protractor.Key.TAB);
        OBJCreate.primary.sendKeys(ptor_1.protractor.Key.ENTER);
        OBJCreate.secondary.click();
        OBJCreate.secondary.sendKeys(ptor_1.protractor.Key.TAB);
        OBJCreate.secondary.sendKeys(ptor_1.protractor.Key.ENTER);
    }
    ClickRateoption(Testcasename, Rownumber) {
        protractor_1.browser.sleep(5000);
        protractor_1.browser.executeScript("window.scrollTo(0,200)");
        var EC = ptor_1.protractor.ExpectedConditions;
        protractor_1.browser.wait(EC.visibilityOf(OBJCreate.optiondots.get(Rownumber)), 20000).then(function () {
            protractor_1.browser.executeScript("window.scrollTo(0,-500)");
            protractor_1.browser.sleep(3000);
            OBJCreate.optiondots.get(Rownumber).click();
            protractor_1.browser.sleep(5000);
        });
        protractor_1.browser.executeScript("window.scrollTo(0,500)");
        var val = (OBJCreate.CreateButtonOverview).isDisplayed().then((elem) => {
            if (elem === true) {
                protractor_1.browser.sleep(3000);
                OBJCreate.CreateButtonOverview.click();
                console.log("Create button is clicked for the available rate");
            }
            else {
                console.log("Create button is not clicked for the available rate");
            }
        });
        var val = (OBJCreate.Overideall).isDisplayed().then((elem) => {
            if (elem === true) {
                protractor_1.browser.sleep(4000);
                protractor_1.browser.executeScript("window.scrollTo(0,-500)");
                protractor_1.browser.sleep(3000);
                protractor_1.browser.actions().mouseMove(OBJCreate.Overideall);
                OBJCreate.Overideall.click();
                protractor_1.browser.sleep(4000);
                console.log("Warnings are overidden successfully");
            }
            else {
                console.log("Create opportunity is not displayed in the shipping options Flow menu");
            }
        });
        var index = 0;
        OBJCreate.errorparent.count().then(function (total) {
            OBJCreate.errorparent.each(function (item) {
                index++;
                if (total >= index) {
                    (OBJCreate.errorparent).get(0).isDisplayed().then((element) => {
                        if (element === true) {
                            var EC = ptor_1.protractor.ExpectedConditions;
                            protractor_1.browser.wait(EC.visibilityOf(OBJCreate.errorlink), 5000).then(function () {
                                OBJCreate.errorlink.click();
                                (OBJCreate.errordropDown).isPresent().then(function (bool) {
                                    if (bool === true) {
                                        OBJCreate.errordropDown.click();
                                        OBJCreate.OverideErrorButton.click();
                                        protractor_1.browser.sleep(2000);
                                    }
                                });
                                (OBJCreate.errorlinkname).isPresent().then(function (bool) {
                                    if (bool === true) {
                                        OBJCreate.errorlinkname.sendKeys("Keerthana Selvaraj");
                                        protractor_1.browser.sleep(2000);
                                        OBJCreate.errorlinkname.sendKeys(ptor_1.protractor.Key.ENTER);
                                    }
                                });
                                (OBJCreate.errorlinkCmnt).isPresent().then(function (bool) {
                                    if (bool === true) {
                                        OBJCreate.errorlinkCmnt.sendKeys("Test");
                                        OBJCreate.OverideErrorButton.click();
                                        protractor_1.browser.sleep(2000);
                                        console.log("The errors and warnings are overriden successfully");
                                    }
                                });
                            });
                        }
                    });
                }
                else
                    console.log("No errors are available");
            });
        });
        protractor_1.browser.executeScript("window.scrollTo(0,500)");
        protractor_1.browser.sleep(3000);
    }
    AdvancedSearchforOrder(OrderNo, PickupDate, Deliverydate, OrderStatus) {
        this.ElementWait(true, OBJCreate.allOptions);
        OBJCreate.acceptclose.click();
        OBJCreate.Showmore.click();
        protractor_1.browser.executeScript("window.scrollTo(0,-200)");
        protractor_1.browser.sleep(2000);
        protractor_1.browser.executeScript("window.scrollTo(0,200)");
        OBJCreate.Destin.click();
        OBJCreate.allOptions.get(2).click();
        var ind = 0;
        OBJCreate.allOptions.count().then(function (total) {
            OBJCreate.allOptions.each(function (item) {
                ind++;
                if (ind == 2) {
                    console.log("index no is" + ind);
                    item.sendKeys("order number");
                    protractor_1.browser.sleep(2000);
                    item.sendKeys(ptor_1.protractor.Key.TAB);
                    item.sendKeys(ptor_1.protractor.Key.TAB);
                    item.sendKeys(ptor_1.protractor.Key.TAB);
                    item.sendKeys(ptor_1.protractor.Key.ENTER);
                }
                else
                    console.log("View drop down is not available with the values");
            });
        });
        var ind1 = 0;
        protractor_1.browser.sleep(2000);
        OBJCreate.orderno.count().then(function (total) {
            OBJCreate.orderno.each(function (item) {
                console.log(ind1);
                ind1++;
                if (ind1 == 3) {
                    item.sendKeys(OrderNo);
                    protractor_1.browser.sleep(2000);
                }
                else
                    console.log("View drop down is not available with the values");
            });
        });
        OBJCreate.SearchButton.click();
        protractor_1.browser.executeScript("window.scrollTo(0,-200)");
        this.ElementValidationAdvancedsearch(PickupDate, Deliverydate);
        OBJCreate.SelectFirstorder.get(0).click();
        var viewpage = protractor_1.element(protractor_1.by.xpath("//span[text()='Order']"));
        this.ElementWait(true, viewpage);
    }
    utilities(utilityoption, option) {
        protractor_1.browser.executeScript("window.scrollTo(0,-500)");
        OBJCreate.Utilitiesicon.click();
        protractor_1.browser.sleep(2000);
        switch (utilityoption) {
            case "Comment": {
                OBJCreate.toollist.get(0).click();
                OBJCreate.addComment.click();
                OBJCreate.addCommenttext.sendKeys(ptor_1.protractor.Key.ENTER);
                protractor_1.browser.sleep(2000);
                OBJCreate.addCommenttext.sendKeys("Ap");
                OBJCreate.addCommenttext.sendKeys(ptor_1.protractor.Key.ENTER);
                protractor_1.browser.sleep(2000);
                OBJCreate.templateType.click();
                OBJCreate.templatetypetext.sendKeys(ptor_1.protractor.Key.ENTER);
                OBJCreate.Commenttext.clear();
                OBJCreate.Commenttext.sendKeys("Test");
                OBJCreate.Savebutton.get(1).click();
                protractor_1.browser.sleep(2000);
                OBJCreate.addedutilityref.click();
                var EC = ptor_1.protractor.ExpectedConditions;
                protractor_1.browser.wait(EC.visibilityOf(OBJCreate.apntEditcmnt), 5000).then(function () {
                    console.log("Edit or Delete option is available ");
                    if (option == "Edit") {
                        OBJCreate.utilityedit.click();
                    }
                    if (option == "Delete") {
                        OBJCreate.utilityDelete.click();
                    }
                });
                OBJCreate.Utilitiesicon.click();
                break;
            }
            case "Documents": {
                OBJCreate.toollist.get(1).click();
                break;
            }
            case "Reference": {
                OBJCreate.toollist.get(2).click();
                OBJCreate.ReferenceType.click();
                OBJCreate.Refercmnt.sendKeys("Test");
                OBJCreate.Addbutton.click();
                OBJCreate.apntEditRef.click();
                protractor_1.browser.executeScript("window.scrollBy(0,-3000)");
                OBJCreate.toollist.get(2).click();
                var EC = ptor_1.protractor.ExpectedConditions;
                protractor_1.browser.wait(EC.visibilityOf(OBJCreate.apntEditRef), 5000).then(function () {
                    console.log("Edit or Delete option is available ");
                    if (option == "Edit") {
                        OBJCreate.utilityedit.click();
                    }
                    if (option == "Delete") {
                        OBJCreate.utilityDelete.click();
                    }
                });
                OBJCreate.Utilitiesicon.click();
                break;
            }
            case "Instruction": {
                OBJCreate.toollist.get(3).click();
                break;
            }
            case "Charge": {
                OBJCreate.toollist.get(4).click();
                OBJCreate.Chargelevel.click();
                protractor_1.browser.sleep(2000);
                OBJCreate.chargeamount.clear();
                OBJCreate.chargeamount.sendKeys("10");
                OBJCreate.chargequantity.clear();
                OBJCreate.chargequantity.sendKeys("15");
                OBJCreate.authno.sendKeys("12369");
                OBJCreate.authby.sendKeys("keerthana");
                OBJCreate.chargecode.sendKeys("DEAD");
                OBJCreate.chargecode.sendKeys(ptor_1.protractor.Key.BACK_SPACE);
                OBJCreate.chargecode.sendKeys(ptor_1.protractor.Key.BACK_SPACE);
                protractor_1.browser.sleep(2000);
                OBJCreate.chargecode.sendKeys("A");
                protractor_1.browser.sleep(2000);
                OBJCreate.BillToValue.click();
                protractor_1.browser.sleep(2000);
                OBJCreate.Addbuttoncharge.get(2).click();
                OBJCreate.Utilitiesicon.click();
                break;
            }
        }
    }
    ClickButtonwithText(buttonText) {
        OBJCreate.Buttontext.count().then(function (total) {
            OBJCreate.Buttontext.each(function (item) {
                var index = 0;
                index++;
                if (total > index) {
                    var Disp = item.getText().then((elem) => {
                        if (elem.trim() === buttonText) {
                            item.click();
                            protractor_1.browser.sleep(3000);
                        }
                    });
                }
            });
        });
    }
    EditStops() {
        OBJCreate.originstopedit.click();
        OBJCreate.editbtn.click();
        OBJCreate.requestedservices.click();
        OBJCreate.requestedservices.sendKeys("Pickup Trailer");
        OBJCreate.requestedservices.sendKeys(ptor_1.protractor.Key.ENTER);
    }
    TotalMilesCreateOrderOverview(OBJElement) {
        OBJElement.isPresent().then((elem) => {
            var value = 0;
            {
                var Disp = OBJElement.getText().then((text) => {
                    if (text.trim() != "0") {
                        console.log("Delivery Appointment details and Time Zone in Order overview is same as the appointment date while creating the order " + text);
                    }
                });
            }
        });
    }
    addmultiplestops(Testcasename, stopreason) {
        var TcRow = ReadFromXL.FindRowNum(Testcasename, "StopDetails");
        DataDictLib.pushToDictionaryWithSheet(TcRow, "StopDetails");
        var TcRow = ReadFromXL.FindRowNum(Testcasename, "CreateOrder");
        DataDictLib1.pushToDictionaryWithSheet(TcRow, "CreateOrder");
        var Pickup = DataDictLib.getFromDictionary('Pickup');
        var Stopnumber = DataDictLib.getFromDictionary('StopNumber');
        var TitleCreate = DataDictLib1.getFromDictionary('CreateTitle');
        protractor_1.browser.executeScript("window.scrollTo(0,-500)");
        if (Stopnumber >= 1) {
            protractor_1.browser.sleep(3000);
            for (var i = 1; i <= Stopnumber; i++) {
                protractor_1.browser.executeScript("window.scrollTo(0,-500)");
                if (TitleCreate == "Create New order") {
                    OBJCreate.expandicon.get(0).click();
                    protractor_1.browser.sleep(5000);
                    OBJCreate.stopdots.click();
                    OBJCreate.addstop.click();
                    protractor_1.browser.sleep(5000);
                }
                else
                    (TitleCreate == "Create New Template");
                {
                    OBJCreate.expandiconTemplate.get(0).click();
                    protractor_1.browser.sleep(5000);
                    OBJCreate.stopdotstemplate.click();
                    OBJCreate.addstop.click();
                    protractor_1.browser.sleep(5000);
                    OBJCreate.expandiconTemplate.get(1).click();
                    protractor_1.browser.sleep(5000);
                }
                this.AddIntermediateStopDetails(Testcasename, "NULL", "29/Dec/2017", i);
                protractor_1.browser.sleep(7000);
            }
        }
    }
    OrderHistoryWarningsoverride() {
        OBJCreate.hstrybtn.click();
        protractor_1.browser.sleep(5000);
        var val = (OBJCreate.hstrytable).isPresent().then((elem) => {
            if (elem === true) {
                console.log("Order History is  available");
                OBJCreate.cnt;
                OBJCreate.cnt.count().then((intcnt) => {
                    if (intcnt > 0) {
                        console.log("Records count is available" + intcnt);
                    }
                    else {
                        console.log("Records count are not found");
                    }
                    OBJCreate.WarningsOveridden.isPresent().then((elem) => {
                        if (elem === true) {
                            console.log("Credit Check Failure warning is displayed");
                        }
                        else
                            console.log("Credit Check Failure warning is not displayed");
                    });
                });
            }
            else {
                console.log("Order History is not available");
            }
        });
    }
    SelectFirstorder() {
        OBJCreate.SelectFirstorder.get(0).click();
        protractor_1.browser.sleep(4000);
        var viewpage = protractor_1.element(protractor_1.by.xpath("//span[text()='Order']"));
    }
    RateSheet() {
        this.ElementWait(true, OBJCreate.Rulename);
        protractor_1.browser.executeScript("window.scrollTo(0,200)");
        protractor_1.browser.sleep(5000);
        OBJCreate.ratesheet.click();
        this.ElementWait(true, OBJCreate.rate_level);
        OBJCreate.rate_edit.isPresent().then((elem) => {
            if (elem === true) {
                console.log("edit button is present");
                OBJCreate.rate_edit.click();
            }
            else {
                console.log("edit button is not present");
            }
        });
    }
    CreateWithoutRate() {
        OBJCreate.ShippingFlowMenu.click();
        var val = (OBJCreate.CreateWithoutrTE).isDisplayed().then((elem) => {
            if (elem === true) {
                OBJCreate.CreateWithoutrTE.click();
                console.log("Create without Rate is clicked from the dropdown");
            }
            else {
                console.log("Create without Rate is not displayed in the shipping options Flow menu");
            }
        });
        OBJCreate.RateReason.click();
        this.ClickButtonwithText("Create");
        protractor_1.browser.sleep(12000);
    }
    Overrideall() {
        OBJCreate.warningMsg.isPresent().then((elem) => {
            var value = 0;
            {
                var Disp = OBJCreate.warningMsg.getText().then((text) => {
                    if (text.trim() == "Customer credit status is CREDIT HLD.") {
                        console.log("Credit check failure is displayed as warning " + text);
                    }
                });
            }
        });
        OBJCreate.Overidewarning.isPresent().then((elem) => {
            OBJCreate.Overidewarning.click();
            protractor_1.browser.sleep(20000);
        });
    }
    CCI_AccountSearch(CreditStatus) {
        OBJCreate.CCi_Search.sendKeys("WABE10 ");
        OBJCreate.CCi_Search.sendKeys(ptor_1.protractor.Key.ENTER);
        OBJCreate.SelectFirstResult.click();
        OBJCreate.Credittab.click();
        OBJCreate.CreditStatusEditIcon.click();
        OBJCreate.CreditSelectClick.click();
        OBJCreate.CreditStatusEditIcon.click();
        OBJCreate.CreditSelectClick.click();
        if (CreditStatus == "Approved") {
            OBJCreate.CreditApproved.click();
        }
        if (CreditStatus == "Denied") {
            OBJCreate.CreditDenied.click();
        }
        OBJCreate.CreditScore.sendKeys("45");
        this.ClickButtonwithText("Save");
    }
    RejectOrder() {
        OBJCreate.OrderFlowMenu.click();
        OBJCreate.RejectOrder.click();
        OBJCreate.RejectReason.click();
        OBJCreate.RejectComments.sendKeys("Test");
        this.ClickButtonwithText("Save");
    }
    AlternateLogin() {
        OBJCreate.username.click();
        OBJCreate.username.sendKeys("rcon996");
        OBJCreate.password.click();
        OBJCreate.password.sendKeys("jb8462");
        OBJCreate.loginbutton.click();
        protractor_1.browser.sleep(5000);
    }
    RoutePlan(ViewValue) {
        protractor_1.browser.sleep(5000);
        protractor_1.browser.executeScript("window.scrollTo(0,200)");
        protractor_1.browser.sleep(5000);
        var EC = ptor_1.protractor.ExpectedConditions;
        OBJCreate.Routeplan.click();
        protractor_1.browser.executeScript("window.scrollTo(0,-200)");
        try {
            protractor_1.browser.wait(EC.visibilityOf(OBJCreate.load), 5000).then(function () {
                OBJCreate.load.getText().then((elem) => {
                    if (elem != "")
                        console.log("Load id is generated for the order" + elem);
                });
            });
        }
        catch (_a) {
            console.log("Load id is not generated for the order");
        }
    }
    FetchDatafromOM() {
        return __awaiter(this, void 0, void 0, function* () {
            var BUval;
            var billto;
            var totalmile;
            yield reuse.getTextValueFromElement(OBJCreate.BUval).then((text) => {
                BUval = text;
                BUval = BUval.replace(" -", "");
            });
            yield reuse.getTextValueFromElement(OBJCreate.Billtoval).then((text) => {
                billto = text;
            });
            billto.split('(');
            var billtocode = billto[1];
            billtocode.split(')');
            var BillTo = billtocode[0];
            yield reuse.getTextValueFromElement(OBJCreate.totalmiles).then((text) => {
                totalmile = text;
            });
            DictBU_OM["BusUnit"] = BUval;
            DictBU_OM["Billto"] = BillTo;
            DictBU_OM["totalmile"] = totalmile;
            return DictBU_OM;
        });
    }
    FetchDatafromEOM() {
        return __awaiter(this, void 0, void 0, function* () {
            var BU;
            var BillTO;
            var mile;
            yield reuse.getTextValueFromElement(OBJCreate.BUdivision).then((text) => {
                BU = text;
            });
            console.log("Inside function" + BU);
            yield OBJCreate.Billtovaleom.getAttribute("value").then((text) => {
                BillTO = text;
            });
            console.log("Inside function" + BillTO);
            yield reuse.getTextValueFromElement(OBJCreate.mileeom).then((text) => {
                mile = text;
            });
            console.log("Inside function" + mile);
            DictBU_EOM["BusUnit"] = BU;
            DictBU_EOM["Billto"] = BillTO;
            DictBU_EOM["totalmile"] = mile;
            return DictBU_EOM;
        });
    }
    NavigateEOM() {
        OBJCreate.Loadid.click();
        OBJCreate.Loadid.sendKeys("KJ13693");
        OBJCreate.Loadid.sendKeys(ptor_1.protractor.Key.ENTER);
        protractor_1.browser.sleep(3000);
        OBJCreate.loadlink.click();
        protractor_1.browser.sleep(3000);
        OBJCreate.loaddetail.click();
        protractor_1.browser.sleep(3000);
        OBJCreate.stopdetails.click();
        protractor_1.browser.sleep(3000);
    }
    CompareValues(Testcasename, DictBU_OM, DictBU_EOM) {
        var OMvals = DataDictLib.getFromDictionary('OMvalues');
        var i = 0;
        console.log("excel values" + OMvals);
        var OMpagevalues = OMvals.split(',');
        for (i = 0; i < OMpagevalues.length; i++) {
            if (OMpagevalues[i] == "BusUnit") {
                console.log("Entering into Businees Value Comparison");
                var BUnit = DictBU_OM[OMpagevalues[i]];
                console.log(BUnit);
                var TcRow = ReadFromXL.FindRowNum(Testcasename, "CreateOrder");
                var fleetcode = DataDictLib.getFromDictionary(BUnit + "_fleetcode");
                console.log(fleetcode);
                if (fleetcode == DictBU_EOM[OMpagevalues[i]]) {
                    console.log("Business unit is same");
                }
                else {
                    console.log("Business unit is not matching" + DictBU_EOM[BUnit]);
                }
            }
            else if (DictBU_OM[OMpagevalues[i]] == DictBU_EOM[OMpagevalues[i]]) {
                console.log('Values are same');
            }
            else {
                console.log("Comparison is failed" + DictBU_EOM[OMpagevalues[i]]);
            }
        }
    }
    SearchTemplate(Billto) {
        OBJCreate.Billtosearch.sendKeys(Billto);
        protractor_1.browser.sleep(3000);
        OBJCreate.Billtosearch.sendKeys(ptor_1.protractor.Key.ENTER);
        protractor_1.browser.sleep(3000);
        OBJCreate.SearchIcon.click();
        protractor_1.browser.sleep(4000);
    }
}
exports.commonFunctions = commonFunctions;
//# sourceMappingURL=Regression.js.map