"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ReadFromXL_1 = require("../CommonFiles/ReadFromXL");
var objExcelRead = new ReadFromXL_1.ExcelReader();
var cellIdForDataPushHdr, cellIdForDataPushVar, tempDataHdr, tempDataVal;
var val, temp;
var DataDict = {};
class DataDictionary {
    pushToDictionaryWithSheet(rowId, datasheet) {
        var k = 1;
        while (k > 0) {
            tempDataHdr = "";
            tempDataVal = "";
            cellIdForDataPushHdr = this.columnToLetter(k) + 1;
            cellIdForDataPushVar = this.columnToLetter(k) + rowId;
            try {
                tempDataHdr = objExcelRead.cellFromXLS(datasheet, cellIdForDataPushHdr);
                tempDataVal = objExcelRead.cellFromXLS(datasheet, cellIdForDataPushVar);
            }
            catch (_a) {
                if (tempDataHdr === "") {
                    console.log("Data Read is Completed");
                    break;
                }
            }
            if (tempDataHdr.toString() != "") {
                //console.log("empty-"+tempDataHdr)
                DataDict[tempDataHdr] = tempDataVal;
                //console.log("K Value"+k)
            }
            k++;
        }
        //console.log(DataDict);
    }
    getFromDictionary(key) {
        val = DataDict[key];
        //console.log("Key:"+key+", Value:"+val)
        return val;
    }
    columnToLetter(column) {
        var letter = '';
        while (column > 0) {
            temp = (column - 1) % 26;
            letter = String.fromCharCode(temp + 65) + letter;
            column = (column - temp - 1) / 26;
        }
        val = letter;
        return val;
    }
}
exports.DataDictionary = DataDictionary;
//# sourceMappingURL=DictionaryData.js.map