"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// /* tslint:disable */
// import * as XLSX from "ts-xlsx"
// import Excel from "exceljs";
// export class ExRead
// {
// Getdata(TestCase,Columnvalue):any{
// 	var fs = require("c:\\Users\\rcon388\\Documents\\Protractor_TS\\node_modules\\fs-extra");
// 	var read_xlsx = require("c:\\Users\\rcon388\\Documents\\Protractor_TS\\node_modules\\read_xlsx");
// 	var excelBuffer = fs.readFileSync("./TestData.xlsx");
// 	 var tc ="ApprovedPayment";
// 	 let result:string;
// 	 var rowLen 
// 	 var cellLen
// 	 let TCidrow ;
// 	read_xlsx.getWorkbook(excelBuffer).then(function(workbook):any{
// 	  var sheetNames = workbook.getSheetNames();
// 	  //console.log(sheetNames);
// 	  workbook.getSheet("data").then(function(sheet){
// 		 rowLen = sheet.getRows();
// 		 cellLen = sheet.getColumns();
// 		for(var i=0; i<rowLen; i++) {
// 		  for(var k=0; k<cellLen; k++) {
// 			if(sheet.getCell(i,0).getContents()===TestCase)
// 			{
// 			  TCidrow =i;
// 			  //console.log(sheet.getCell(TCidrow,0).getContents())
// 			  break;
// 			}
// 		  }
// 		}
// 		  for(var k=0; k<cellLen; k++) {
// 			var cell = sheet.getCell(i,k);
// 			  if(sheet.getCell(0,k).getContents()===Columnvalue)
// 			  {
// 				//console.log("Value of "+ tc + " is "+sheet.getCell(TCidrow,k).getContents())
// 				result= sheet.getCell(TCidrow,k).getContents()
// 				console.log(result)
// 				break ;
// 			  }
// 			   //console.log("Value of "+ tc + "is "+sheet.getCell(i,k).getContents())
// 			// }
// 		}
// 		//console.log(result)
// 		return result
// 	})["catch"](function(err) {
// 		console.error(err.stack);
// 		});
// 	 	});
// //	console.log(TCidrow)
// 	//console.log(result)
// //	return result 
// }
// }
// module.exports = XLDataSource;
// export class ReadExcel
// {
// 	 Getdata(TestCase,Columnvalue){
// 		var fs = require("c:\\Users\\rcon388\\Documents\\Protractor_TS\\node_modules\\fs-extra");
// 		var read_xlsx = require("c:\\Users\\rcon388\\Documents\\Protractor_TS\\node_modules\\read_xlsx");
// 		var xlsx = require("c:\\Users\\rcon388\\Documents\\Protractor_TS\\node_modules\\xlsx");
// 		var excelBuffer = fs.readFileSync("./TestData.xlsx");
// 		 var tc ="ApprovedPayment";
// 		 let result:string="";
// 		 var rowLen 
// 		 var cellLen
// 		 let TCidrow ;
// 		 var names=read_xlsx.getWorkbook(excelBuffer)
// 		read_xlsx.getWorkbook(excelBuffer).then(function(workbook):any{
// 			var sheetNames = workbook.getSheetNames();
// 			//console.log(sheetNames);
// 			workbook.getSheet("data").then(function(sheet){
// 			 rowLen = sheet.getRows();
// 			 cellLen = sheet.getColumns();
// 			for(var i=0; i<rowLen; i++) {
// 				for(var k=0; k<cellLen; k++) {
// 				if(sheet.getCell(i,0).getContents()===TestCase)
// 				{
// 					TCidrow =i;
// 					//console.log(sheet.getCell(TCidrow,0).getContents())
// 					break;
// 				}
// 				}
// 			}
// 				for(var k=0; k<cellLen; k++) {
// 				var cell = sheet.getCell(i,k);
// 					if(sheet.getCell(0,k).getContents()===Columnvalue)
// 					{
// 					//console.log("Value of "+ tc + " is "+sheet.getCell(TCidrow,k).getContents())
// 					result= sheet.getCell(TCidrow,k).getContents()
// 					//console.log(result)
// 					break ;
// 					}
// 					 //console.log("Value of "+ tc + "is "+sheet.getCell(i,k).getContents())
// 				// }
// 			}
// 			//console.log(result)
// 			return result
// 		});
// 	});
// }
// 	}
//ar DataDict = {};
/*============================= Correct code for reading Excel=========================*/
//var XLDataSource = function () {};
class ExcelReader {
    FindRowNum(TcName, SheetName) {
        var TCrow;
        var XLS, i;
        var val;
        i = 1;
        if (typeof require !== 'undefined') {
            XLS = require('xlsx');
        }
        //Working with workbook
        var workbook = XLS.readFile('TestData.xlsx');
        //var sheetNamelist = workbook.SheetNames;
        //var value = workbook.Sheets[sheetNamelist[sheetNumber]][cellId].v;
        while (i > 0) {
            val = workbook.Sheets[SheetName]["A" + i].v;
            if (val.toString() === TcName.toString()) {
                TCrow = i;
                console.log(TCrow);
                break;
            }
            //console.log(typeof(val))
            //console.log(typeof(TcName))
            i++;
        }
        //console.log(wb.cell(2,2))
        return TCrow;
    }
    GetSpecNames() {
        var XLS, i;
        var val;
        var Spec, Exec, SpecNames;
        SpecNames = "";
        var specCons = "./specs/**/";
        i = 2;
        if (typeof require !== 'undefined') {
            XLS = require('xlsx');
        }
        //Working with workbook
        var workbook = XLS.readFile('TestData.xlsx');
        while (i > 0) {
            try {
                Spec = workbook.Sheets["RunManager"]["A" + i].v;
                Exec = workbook.Sheets["RunManager"]["B" + i].v;
            }
            catch (_a) {
                console.log("Data read is completed");
                break;
            }
            if (Exec.toLowerCase() === "yes") {
                Spec = specCons + Spec + ".js";
                if (i == 2)
                    SpecNames += "" + Spec + "";
                else
                    SpecNames += "," + Spec + "";
            }
            i++;
        }
        return SpecNames;
    }
    GetColLetter(WsName, columnName) {
        var XLS, i;
        var val;
        var specCons = "./specs/**/";
        i = 1;
        if (typeof require !== 'undefined') {
            XLS = require('xlsx');
        }
        //Working with workbook
        var workbook = XLS.readFile('TestData.xlsx');
        while (i > 0) {
            var colId = this.columnToLetter(i);
            var colName = this.GetValue(workbook, WsName, colId + "1");
            if (colName.toString() === columnName.toString()) {
                break;
            }
            i++;
        }
        return colId;
    }
    GetValue(Wrb, WSName, cellID) {
        var cellVal;
        try {
            cellVal = Wrb.Sheets[WSName][cellID].v;
        }
        catch (_a) {
            cellVal = null;
        }
        return cellVal;
    }
    columnToLetter(column) {
        var letter = '';
        var val, temp;
        while (column > 0) {
            temp = (column - 1) % 26;
            letter = String.fromCharCode(temp + 65) + letter;
            column = (column - temp - 1) / 26;
        }
        val = letter;
        return val;
    }
    cellFromXLS(shtName, cellId) {
        //Define sheetNumber
        var TCrow;
        // if (shtName == 'conf') {sheetNumber = 0;}
        // if (shtName == 'spec') {sheetNumber = 1;}
        //NodeJs read file
        var XLS, i;
        i = 1;
        if (typeof require !== 'undefined') {
            XLS = require('xlsx');
        }
        //Working with workbook
        var workbook = XLS.readFile('TestData.xlsx');
        //var sheetNamelist = workbook.SheetNames;
        var value = workbook.Sheets[shtName][cellId].v;
        //console.log(wb.cell(2,2))
        return value;
    }
}
exports.ExcelReader = ExcelReader;
//# sourceMappingURL=ReadFromXL.js.map