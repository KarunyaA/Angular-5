/* tslint:disable */
import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";
import {ExcelReader} from "../CommonFiles/ReadFromXL"
var ReadFromXL= new ExcelReader()
import {DataDictionary} from "../DataFiles/DictionaryData"
//var sql = require('mssql');
// export class dbConnection{
//   ConnectDB() {
//     return new Promise(function (fulfill, reject) {
//         var config = {
//             user: 'rcon992',
//             password: 'jb8140',
//             DataSource : 'OrderManagement_TST' ,
//             InitialCatalog:'PartyAndLocationMDM_TST',
//             Trusted_Connection:'True'     
//         };
//         var connection = new sql.Connection(config);
//         connection.connect(function (err) {
//             reject(err);
//         });

//         var request = new sql.Request(connection);
//         request.query('select * from Config where [Key] like \'HidePreop%\'', function (err, recordeset) {
//             if (err) reject(err);
//             else fulfill(recordeset);
//         });
//     });
// }}

var path = require("path");
var sql = require("mssql");
var config = require(path.resolve("./config.json"));

let db1;
export class dbConnection{

       
    //    const connect = () => {
    //        return new Promise((resolve, reject) => {
    //            db1 = new sql.ConnectionPool(config.db, err => {
    //                if (err) {
    //                    console.error("Connection failed.", err);
    //                    reject(err);
    //                } else {
    //                    console.log("Database pool #1 connected.");
    //                    resolve();
    //                }
    //            });
    //        });
    //    };
       ConnectDB(TCName){
    
    var config = {
        user: 'rcon992',
        password: 'jb8140',
        server: 'localhost', 
        database: 'PartyAndLocationMDM_TST' 
    };

// const config = require(path.resolve("./config.js"));

    // const connect = () => {
    //     return new Promise((resolve, reject) => {
    //         db1 = new sql.ConnectionPool(config.database, err => {
    //             if (err) {
    //                 console.error("Connection failed.", err);
    //                 reject(err);
    //             } else {
    //                 console.log("Database pool #1 connected.");
    //                 resolve();
    //             }
    //         });
    //     });
    // };
    sql.connect(config, function (err){
      
    var  SelectQuery = async (TCName) => {
        var DataDictLib= new DataDictionary()

        var TcRow=ReadFromXL.FindRowNum(TCName,"Geo_Data")
        DataDictLib.pushToDictionaryWithSheet(TcRow,"Geo_Data")

      
        var stringSelectQuery = DataDictLib.getFromDictionary('Select Query') 
        console.log(stringSelectQuery)
           var query = stringSelectQuery;
           var request = new sql.Request(db1);
           var result = await request.query(query);
           var DBResult = result.recordset
           return DBResult;
       };
    //    module.exports = {
    //     ConnectDB,
    //     //insertSignup,
    //     SelectQuery
    // };
  
       
    
} )
}

// SelectingQuery = async (Testcase) => {
//     const query = "select [CountryCode] from GEO.PostalCode where PostalCodeID='17659'";
//     const request = new sql.Request(db1);
//     const result = await request.query(query);
//     return result.recordset;
// };




}





// connect to your database
    // sql.connect(config, function (err) {
    
    //     if (err) console.log(err);
    
    //     // create Request object
    //     var request = new sql.Request();
    
    //     // query to the database and get the records
    //     request.query('select * from Student', function (err, recordset) {
    
    //         if (err) console.log(err)
    
    //         // send records as a response
    //     var  res;
    //    var result=res.send(recordset);
    
    //     });
    // }); 
//         return new Promise(function (fulfill, reject) {
    //             var config = {
    //                 user: 'rcon992',
    //                 password: 'jb8140',
    //                 server: 'LOCALHOST/SQLEXPRESS',
    //                 database: "PartyAndLocationMDM_TST",
    //                // "port": "52519"
    //                 //DataSource : 'OrderManagement_TST' ,
    //                // InitialCatalog:'PartyAndLocationMDM_TST',
    //                 Trusted_Connection:'True'  ,
    //                 name: "default",
    //                 pool: {
    //                     max: 10,
    //                     min: 4,
    //                     idleTimeoutMillis: 30000,
    //                   },   
    //             };
               
    //             var connection = new sql.Connection(config);
    //             connection.connect(function (err) {
    //                 reject(err);
    //             });
    //         })
    //     }
    //    const insertSignup = async (name, email, tracking) => {
    //        const query = `
    //            INSERT INTO Entries ([Name],[Email],[Tracking])
    //            values (@name, @email, @tracking);`;
       
    //        const request = new sql.Request(db1);
    //        const result = await request
    //            .input("name", name)
    //            .input("email", email)
    //            .input("tracking", tracking)
    //            .query(query);
       
    //        return result.rowsAffected === 1;
    //    };