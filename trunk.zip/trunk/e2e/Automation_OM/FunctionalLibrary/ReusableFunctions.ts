/* tslint:disable */
import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";
import { Browser } from "selenium-webdriver";
var  Buttontext=element.all(by.tagName("button"));
export class ReusableFunctions{   

    ClickElement(wElement,value){
        try{	
            wElement.isPresent().then(function(result) {               
                if ( result ) {
                    wElement.click()
                    browser.logger.info(value +' is clicked')
                } else {
                    browser.logger.error(value +' is not found') 
                }
            });
        }catch (err)
         {
            browser.logger.error(value +' has Found '+err) 
         }
    }
       

    

                SACElement(wElement,value){
                    try{	

                        wElement.getLocation().then(function (navDivLocation) { var initTop = (navDivLocation.y - 150) > 0 ? navDivLocation.y - 150 : 1; // it is my approach and you can don't change it is value var 
                        var initLeft = navDivLocation.x; 
                        browser.executeScript('window.scrollTo(' + initLeft + ',' + initTop + ');'); });


                        wElement.isPresent().then(function(result) {               
                            if ( result ) {
                                wElement.getWebElement().then(function(elm){ return browser.executeScript("$(arguments[0]).click();", elm)});
                                
                                browser.logger.info(value +' is clicked')
                            } else {
                                browser.logger.error(value +' is not found') 
                            }
                        });
                    }catch (err)
                     {
                        browser.logger.error(value +' has Found '+err) 
                     }
                }
               

                SAClickElement(wElement,value){
                    try{	

                        wElement.getLocation().then(function (navDivLocation) { var initTop = (navDivLocation.y - 150) > 0 ? navDivLocation.y - 150 : 1; // it is my approach and you can don't change it is value var 
                        var initLeft = navDivLocation.x; 
                        browser.executeScript('window.scrollTo(' + initLeft + ',' + initTop + ');'); });


                        wElement.isPresent().then(function(result) {               
                            if ( result ) {
                                wElement.click();
                                
                                browser.logger.info(value +' is clicked')
                            } else {
                                browser.logger.error(value +' is not found') 
                            }
                        });
                    }catch (err)
                     {
                        browser.logger.error(value +' has Found '+err) 
                     }
                }

                ScrollElement(wElement,value){
                    try{	

                        wElement.getLocation().then(function (navDivLocation) { var initTop = (navDivLocation.y - 150) > 0 ? navDivLocation.y - 150 : 1; // it is my approach and you can don't change it is value var 
                        var initLeft = navDivLocation.x; 
                        browser.executeScript('window.scrollTo(' + initLeft + ',' + initTop + ');'); });
                   
                    }catch (err)
                     {
                        browser.logger.error(value +' has Found '+err) 
                     }
                }

        EnterValue(wElement,text,value){
            try{	
                wElement.isPresent().then(function(result) {
                    if ( result ) {
                        wElement.sendKeys(text)
                        browser.logger.info(value +" of "+text+' is Entered')
                    } else {
                        browser.logger.error(value +' is not found')
                    }
                });
            }catch (err)
             {
                browser.logger.error(value +' has Found '+err) 
             }
        }
        
          async getTextValueFromElement(wElement)
        {
        var uiText
        
         await wElement.getText().then((text)=>{          
                uiText = text 
        })
        return uiText
 
        }
    
        checkElementIsPresent(wElement,value)
        {
            try{	
                wElement.isPresent().then(function(result) {
                    if ( result ) {
                        browser.logger.info("Verification of "+value+"  is Present")
                    } else {
                        browser.logger.error("Verification of "+value+" is not Present")
                    }
                });
            }catch (err)
             {
                browser.logger.error(value +' has Found '+err) 
             }
        }

        
        
  async verifyTextFromList(wElement,value){
    var flag
     await wElement.isPresent().then(function(result){
    if(result==true){
    wElement.count().then(function(total){
    wElement.each(function (item) {
    var index=0
    if(total > index) {
     item.getText().then((elem)=>{
    if(elem.search(value)==0){   
     //expect(value).toContain(elem)
       flag = "pass"
    }
    })
    }
        })
    }) 
    }
     })
     return flag
 } 
   CompareValues(Expected,actual)
   { 
     if(Expected===actual)
     {
        browser.logger.info(Expected+" Value is Matched with "+actual)
     }
     else{
        browser.logger.error(Expected+" Value is Not Matched with "+actual)
     }
   }
   ClickButtonwithText(buttonText) 
   {
    var btn_Text=element(by.xpath("//button[text()='"+buttonText+"']"));
    btn_Text.isPresent().then((res)=>{
        if(res==true){
            btn_Text.click();
            console.log("The "+buttonText+"is clicked")
        
        }
        else
        {
         console.log("The "+buttonText+" link is not clicked") 
        }
    })
         
       }
       ClickwithText(Textvalue) 
       {
           var tag_span=element(by.xpath("//span[text()='"+Textvalue+"']"));
           tag_span.isPresent().then((res)=>{
               if(res==true){
                   tag_span.click();
                   console.log("The "+Textvalue+"is clicked")
               
               }
           })
             
           }
           Clickwithtag(Textvalue) 
           {
               var tag_a=element(by.xpath("//a[text()='"+Textvalue+"']"));
               tag_a.isPresent().then((res)=>{
                   if(res==true){
                       tag_a.click();
                       console.log("The "+Textvalue+"is clicked")
                   
                   }
                   else
                   {
                    console.log("The "+Textvalue+" link is not clicked") 
                   }
               })
                 
               }
               async ValidationMessage(){
                var txt_CreateCityError=element(by.xpath("//div[@class='jbh-notifications']/simple-notifications//simple-notification"));
                var str_Ui_PopUpTxt= await this.getTextValueFromElement(txt_CreateCityError);    
                console.log("The "+str_Ui_PopUpTxt+" PopUp Message") 
                return str_Ui_PopUpTxt;
              }
  
}
