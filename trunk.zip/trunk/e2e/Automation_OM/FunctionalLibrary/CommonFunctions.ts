/* tslint:disable */
import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";


import {ExcelReader} from "../CommonFiles/ReadFromXL"
var ReadFromXL= new ExcelReader()
import {DataDictionary} from "../DataFiles/DictionaryData"
import { Browser } from "selenium-webdriver";
var DataDictLib= new DataDictionary()
import {ReusableFunctions} from "../FunctionalLibrary/ReusableFunctions"
var reuse= new ReusableFunctions()

////////////////////////////////////////// Launch URL Page ///////////////////////////////////////////////////////////////////////////////
var url="";
var btn_toggle=element(by.css("[class=\"fa fa-circle-o\"]"))
var togglefield=element(by.css("[class='fa fa-circle-o']")); 
var dbOption=element(by.cssContainingText('.routeDisplayText','Create Order')); 
var Flowmenu=element(by.css("[id=\"btn-append-to-body\"]"));
var Neworder=element(by.xpath("//span[@class=\"btn-group open\"]//ul[@class=\"dropdown-menu dropdown-menu-right\"]//li//a[text()=\"Create New Order\"]"))  ;
var Newtemplate=element(by.xpath("//span[@class=\"btn-group open\"]//ul[@class=\"dropdown-menu dropdown-menu-right\"]//li//a[text()=\"Create New Template\"]"))  ;
var icon_loading=element(by.xpath("//*[@class='spinner' and @role='progressbar']"));
 ////////////////////////////////////////// SignIN ///////////////////////////////////////////////////////////////////////////////////:::SignIn:::////
 var SignIn=element(by.id("heading1"));
 var SignInUser=element(by.css("[placeholder='Email or Username']"));
 var SignInPwd=element(by.css("[placeholder='Password']"));
 var SignInSubmit=element(by.css("[name='submit']"));
 var username= element(by.id("j_username"));
 var password= element(by.id("j_password")); 
 var loginbutton=element(by.xpath("//input[@value='Login']"));

//Calendar icon:
var Calendaricon=element.all(by.xpath("//button[@class='btnpicker btnpickerenabled']"));
var calListdiv=element(by.css("[class=\"selector selectorarrow selectorarrowleft\"]"));
var calListtable=element.all(by.xpath("//table[@class='caltable']//tbody//tr"));
var AddappointmentIcon=element.all(by.xpath("//a[@class='link-icon-secondary']//i")); 
var AddappointmentIconschedule=element(by.xpath("//p[text()='Primary Appointment']//following::h3[text()='Scheduled Appointments']//following::i[1]")); 
var apnmntHR=element.all(by.id("hours"));
var apnmntMIN=  element.all(by.id("minutes"));

export class CommonFunctions{

/*********************************************************************************
	* MethodName:  invokeApplication
	* Description: To Invoke Url 
	* Parameter (if any):  
	* Return type:  Void
************************************************************************/
    invokeApplication() { 
        browser.get(url).then(function () {
        });
    
        }
/*************************************************************************** 
	* MethodName:  NavigationOptions
	* Description: Navigation To Account Search Screen
	* Parameter (if any):  
	* Return type:  Void
***************************************************************************/
NavigationOptions(TCName) {
    var TcRow=ReadFromXL.FindRowNum(TCName,"CommonData")
    DataDictLib.pushToDictionaryWithSheet(TcRow,"CommonData")
    var mainTab = DataDictLib.getFromDictionary('MainTab')
    var subTAb = DataDictLib.getFromDictionary('SubTAb')
    var ele_MainTab =element.all(by.cssContainingText('.routeDisplayText',mainTab))
    reuse.ClickElement(btn_toggle,"Toggle Button")
    reuse.ClickElement(ele_MainTab,mainTab+" Tab")
    var ele_SubTab=element(by.xpath("//span[text()='"+subTAb+"']"))
    reuse.ClickElement(ele_SubTab,subTAb+" Tab")
 }


 Get_url(Testcasename:string):void { 
    console.log(Testcasename);
    var TcRow=ReadFromXL.FindRowNum(Testcasename,"CommonData");
    
    DataDictLib.pushToDictionaryWithSheet(TcRow,"CommonData");
    var urlName =DataDictLib.getFromDictionary('UrlName');
    browser.get(urlName); //overrides baseURL  
   }
   EnterTextBox(IdValue:string,Value:string):void { 
    var tagname=element(by.css("[formcontrolname=\""+IdValue+"\"]"));
    tagname.clear();
    tagname.sendKeys(Value);
 }
 SignIn(Testcasename:string):void { 
    console.log(Testcasename);
    var TcRow=ReadFromXL.FindRowNum(Testcasename,"CommonData");
    
    DataDictLib.pushToDictionaryWithSheet(TcRow,"CommonData");
    var username =DataDictLib.getFromDictionary('Username');
    var Password =DataDictLib.getFromDictionary('Password');
   SignIn.isDisplayed().then((elem)=>{ 
      if (elem===true)
     SignInUser.sendKeys(username);
     SignInPwd.sendKeys(Password);
      //reuse.ClickElement(( SignInSubmit),"SignInbutton");
     SignInSubmit.click();
      //browser.logger.info('SignInbutton is clicked');
      browser.sleep(2000);
    });
    
   }
  SelectDRopdownValue(IdValue:string):void { 
      var tagname=element(by.css("[placeholder=\""+IdValue+"\"]"));
      tagname.click();
      browser.sleep(2000);
      tagname.sendKeys(protractor.Key.ENTER);
      // ContactValue.click();
   }
   
  NavigatefromDashboard(Pagename:string):void { 
   
      togglefield.click();
     // browser.sleep(2000);
      var dbOption=element(by.cssContainingText(".routeDisplayText",""+Pagename+"")); 
      dbOption.click();
      browser.sleep(2000);
   }
   NavigateWhenToggleActive(Pagename:string):void { 
    
      
       var dbOption=element(by.cssContainingText(".routeDisplayText",""+Pagename+"")); 
       dbOption.click();
       browser.sleep(3000);
    }
    
  NavigationFunction(Flowvalue:string,Testcasename:string) { 
    var TcRow=ReadFromXL.FindRowNum(Testcasename,"CommonData");
    
    DataDictLib.pushToDictionaryWithSheet(TcRow,"CommonData");
        var NavIdValue =DataDictLib.getFromDictionary('NavIdValue');
        console.log(NavIdValue)
        // let co =element(by.xpath("//*[text()='Create Order']"))
        // reuse.ClickElement(co,"create order")
        
        var CreateTitle =DataDictLib.getFromDictionary('CreateTitle');
      this.NavigatefromDashboard(NavIdValue);
      browser.executeScript("window.scrollBy(-2000, 0)");
      //browser.sleep(4000);
      var Neworder=element(by.xpath("//span[@class=\"btn-group open\"]//ul[@class=\"dropdown-menu dropdown-menu-right\"]//li//a[text()=\""+CreateTitle+"\"]"))  ;
     Flowmenu.click();
     var EC = protractor.ExpectedConditions;
        browser.wait(EC.visibilityOf(Neworder), 5000);
        browser.executeScript("arguments[0].scrollIntoView();", Neworder.getWebElement());
      Neworder.click();
      browser.sleep(4000);
   
   }
   LoadingComponent(IdValue:string,Value:string):void { 
    icon_loading.isPresent().then(function(result){
      if(result==true){
          console.log("Update button is displayed");
      }else{
          console.log("Update button is not displayed");
      }
  });
  }
  async ElementWait(elemValCheck:boolean, OBJelem) 
  {
    
    
     
    var cntr:number = 0
    var displayvalue:boolean=false;
    var textvalue:any="";
    var value:boolean = false ;
    while(value === false)
    {
      browser.sleep(3000);
  
      await OBJelem.isPresent().then((elem)=>{
        console.log(cntr+"th time");
        displayvalue = elem;
        console.log("1st scope" + displayvalue);
      });
      browser.sleep(3000);
      if (elemValCheck==true && displayvalue.valueOf()=== true){
        console.log(" entering into text validation")
      await OBJelem.getText().then((elem1)=>{
  console.log(cntr+"th time");
  
  textvalue = elem1 ;
  console.log("2nd scope" + textvalue);
  });}
  
  if(cntr>12){
   break;
   }
   if (elemValCheck==true)
   {
     if(textvalue !== "")
       value = displayvalue
     else
       value = false
   }
  
   else
     value = displayvalue;
  
   console.log(value);
   cntr++;
  
        }
      }
      AlternateLogin(){
        
       username.click()
        username.sendKeys("rcon388");
         password.click();
         password.sendKeys("jbhunt123");
         loginbutton.click();
        browser.sleep(5000);
        } 
        Selectcalendericon(ApntmntDate:string,calendarvalue:number):void { 
          var datevalue=ApntmntDate.split('/')
         
            var date = datevalue[0];
              var month = datevalue[1];
             var year = datevalue[2];
            // console.log(year);
             var val=(Calendaricon.get(calendarvalue)).isPresent().then((elem)=>{ 
               if (elem===true){
          browser.sleep(3000)
          var icon=Calendaricon.get(calendarvalue);
          browser.sleep(4000); 
          icon.click();
           browser.sleep(4000);
          var value=null;
             let dateval: String = value;          
           let MonthInput:string[] = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"] ;         
         var j;
              for (var i = 0; i < MonthInput.length; i++) {
             if(month === (MonthInput[i]))
          {
           j=i+1;
           }
              }
            var monthvalue:any=element(by.css("[class=\"headerlabelbtn monthlabel\"]"));
             var yearvalue=element(by.css("[class=\"headerlabelbtn yearlabel\"]"));
               var viewContainer = element(by.css("[class=\"headerlabelbtn monthlabel\"]")).getText();   
             if((monthvalue.getText().then(function(text) {console.log(text); return text === month;}))&&(yearvalue.getText().then(function(text) { console.log(text);return text === year;})))
              {
               browser.sleep(3000);
               var allOptions = element.all(by.xpath("//table[@class='caltable']//tbody//tr//td//div[contains(@class,'datevalue currmonth')]//span"));
         allOptions.filter(function (elem) {
          return elem.getText().then(function (text) {
           return text === date;
             });
              }).first().click(); 
            browser.sleep(4000);
           }
         console.log("Clicking on the calendar icon");
         }
         else{
          console.log("Calendar icon is not available");
            }
               }); 
         }
        
        
        SelectTime(ApntmntTime:string,calendarvalue:number):void { 
         var datevalue=ApntmntTime.split(':')
         var hour = datevalue[0];
         var min = datevalue[1];
        apnmntHR.get(calendarvalue).sendKeys(hour);
         apnmntMIN.get(calendarvalue).sendKeys(min);   
           
         }
         OverFlowFunction(Flowvalue:string,Testcasename:string) { 
          browser.executeScript("window.scrollBy(-2000, 0)");
          //browser.sleep(4000);
          var Neworder=element(by.xpath("//span[@class=\"btn-group open\"]//ul[@class=\"dropdown-menu dropdown-menu-right\"]//li//a[text()=\""+Flowvalue+"\"]"))  ;
         
          reuse.ClickElement(Flowmenu,"Flowmenu");
          reuse.ClickElement(Neworder,"Neworder");
          browser.sleep(1000);
       
       }
}