/* tslint:disable */
import { ProtractorBrowser, Config } from "protractor";
import { exec } from "child_process";
var AllureReporter: any = require('jasmine-allure-reporter');
var PrettyReporter = require('protractor-pretty-html-reporter').Reporter;
const now = new Date();
var fs = require('fs')
var path = require("path");
var report_name = 'Report-' + now.getFullYear() + "-" + (now.getMonth() + 1) + "-" + now.getDate() + "-" + now.getHours() + "-" + now.getMinutes() + "-" + now.getSeconds();
var logfile_name = 'results-' + now.getFullYear() + "-" + (now.getMonth() + 1) + "-" + now.getDate() + "-" + now.getHours() + "-" + now.getMinutes() + "-" + now.getSeconds();
var chromeDriverPath = process.platform === 'win32' ? 'node_modules/chromedriver/lib/chromedriver/chromedriver.exe' : 'node_modules/chromedriver/bin/chromedriver'
var targetfolder = path.resolve("./") + '\\' + 'Target' + '\\'
var resultpath = path.resolve("./") + '\\' + 'Target' + '\\' + report_name + '\\' + logfile_name + '\\'
var dir = path.resolve("./") + '\\' + 'Target' + '\\' + 'Html' + '\\' + report_name
var log4js = require('log4js');
var logpath = path.resolve("./") + '\\' + 'Target' + '\\' + 'logs' + '\\' + report_name
var mkdirp = require('mkdirp');
console.log(dir)
const mkdirSync = function (dir) {
  try {
    fs.mkdirSync(dir)
  } catch (err) {
    if (err.code !== 'EEXIST') throw err
  }
}
var prettyReporter = new PrettyReporter({

  path: dir,
  screenshotOnPassed: true
});
export let config: Config = {
  // seleniumAddress: 'http://localhost:4444/wd/hub',
  // capabilities: {
  //   "browserName": "internet explorer",
  // },
  capabilities: {
    'browserName': 'chrome',
  'directConnect': true,
    'chromeOptions': {
          'prefs': {
              'credentials_enable_service': false,
              'profile': {
                  'password_manager_enabled': false
              }
          }
      }
  },

  // Framework to use. Jasmine is recommended.
  framework: 'jasmine',

  
  specs: ["./SpecFiles/JBH_OM_R1ST_MOC_TC014.js"],
  jasmineNodeOpts: {
    defaultTimeoutInterval: 2000000,
    //showColors: true
  },
  beforeLaunch() {
    prettyReporter.startReporter(); 
    if (fs.existsSync(logpath)) {
      fs.unlink(logpath)
    }
    console.log(logpath)
    log4js.configure({
      appenders: {
        fileLog: { type: 'file', filename: logpath + '\\' + 'ExecutionLog.log' },
        console: { type: 'log4js-protractor-appender' }
      },
      categories: {
        file: { appenders: ['fileLog'], level: 'error' },
        another: { appenders: ['console'], level: 'trace' },
        default: { appenders: ['console', 'fileLog'], level: 'trace' }
      }
    });
  },
  onPrepare: () => {
    let globals = require("protractor");
    let browser = globals.browser;
    browser.ignoreSynchronization = true;
    browser.manage().window().maximize();
    browser.manage().timeouts().implicitlyWait(5000);
    browser.logger = log4js.getLogger('protractorLog4js');
    jasmine.getEnv().addReporter(prettyReporter);
    var AllureReporter = require("jasmine-allure-reporter");
    jasmine.getEnv().addReporter(new AllureReporter({
      resultsDir: targetfolder + report_name + '\\' + logfile_name
    }));
    jasmine.getEnv().afterEach(() => (done) => {
      browser.takeScreenshot().then(function (png) {
        AllureReporter.createAttachment('Screenshot', function () {
          return new Buffer(png, 'base64')
        }, 'image/png')()
        done();
      });
    });
  },
  onComplete: () => {
    var convert = require('xml-js');
    var xmlfile = fs.readdirSync(resultpath)[0]
    var xml = fs.readFileSync(resultpath + xmlfile).toString();
    var convertedjson = convert.xml2json(xml, { compact: true, spaces: 4 });
    fs.writeFileSync(`${resultpath}/convertedjson.json`, convertedjson.toString());
    var data = require(`${resultpath}/convertedjson.json`);
    const opn = require('opn');
    opn(dir + '\\' + 'report.html');
    var process = require('process');
    const exec = require('child_process').execSync;
    process.chdir(targetfolder + report_name);
    // exec('taskkill /F /IM chromedriver_2.36.exe', (error, stdout, stderr) => {
    //  console.log('standard output',stdout);
    //  });
    // exec('taskkill /F /IM IEDriverServer3.11.1.exe', (error, stdout, stderr) => {
    //   console.log('standard output', stdout);
    // });
    exec('allure generate ' + logfile_name, (error, stdout, stderr) => {
      console.log('standard output', stdout);
    });
    exec('allure report open', (error, stdout, stderr) => {
      console.log("standard output", stdout);
      console.log("log file", logfile_name);
      console.log("report file", report_name);
    });
    






  }
};
