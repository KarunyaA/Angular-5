import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";

export class CCI_AccCreateObjects{    
    username=   element(by.id("j_username"));    
    password=   element(by.id("j_password"));
    login_btn=  element(by.className("btn-submit"));

    str_url="https://account-tst.jbhunt.com/account/";
    txt_UsrName=element(by.css("[id='username']"));
    txt_Pswd=element(by.css("[id='password']"));
    btn_SignIn = element(by.css("[name='submit']"));
    btn_toggle= element(by.css("[class=\"fa fa-circle-o\"]")); 
    tab_Account = element(by.cssContainingText(".routeDisplayText",'Account'));
    subTab_AccountSearch =element(by.xpath("//span[text()='Account Search']"));
    icon_OverflowMenu = element(by.css("[title='overflow-menu']"));
    btn_createAcc = element(by.css("[class='dropdown-item new_account']"));

    //Form Create new Account
    txt_Address = element(by.css("[placeholder='Address']"));
    txt_City = element(by.css("[placeholder='City']"));    
    txt_postCode= element(by.css("[placeholder='Postal Code']"));
    btncmb_State = element(by.xpath("//*[text()='State']//following::i[@class='caret pull-right'][1]"));    
    txt_State=element.all(by.css("[placeholder='State']")).first();
    btncmb_Country = element(by.xpath("//*[contains(text(),'Country')]//following::i[@class='caret pull-right']"));    
    txt_Country=element(by.css("[placeholder='Country']"));
    txt_AccName = element(by.css("[placeholder='Account Name']"));
    txt_PhNum=element(by.css("[placeholder='Phone Number']"));
    btn_create= element(by.css("[id='createButton']"));
    btn_update = element(by.css("[id='updateButton']"));
    str_suggestionAcc= element(by.xpath("//*[text()='Suggested Accounts']"));
    valRow_SuggestAcc = element(by.xpath("//datatable-row-wrapper[1]//datatable-body-row"));
    cmb_role = element(by.xpath("//datatable-row-wrapper[1]//datatable-body-row//datatable-body-cell[4]//span//i[@class='caret pull-right']"));
    str_businessId = element(by.xpath("//datatable-row-wrapper[1]//datatable-body-row//datatable-body-cell[2]//span"));
    btn_createArrow= element(by.xpath("//datatable-row-wrapper[1]//datatable-body-row//span[@class='icon-jbh_right_arrow navigateArrow col-3 col-md-3']"));
    cmb_roledrpdownNew = element(by.xpath("//*[text()='Create New']//following::i[@class='caret pull-right']"));
    txt_roleCreateNew = element(by.css("[placeholder='Role']"));
    btn_pendCreate = element(by.css("[id='pendingCreateAccount']"));
    txt_AccountSearch=element(by.css("[placeholder='Search by Address, Account Name, Phone Number or Business Identifier']"));
    btn_search = element(by.xpath("//i[@class='icon-jbh_search form-control-feedback font18']"));
    val_resultrow = element(by.xpath("//datatable-row-wrapper/datatable-body-row"));
    str_invalidTxt= element(by.xpath("//tbody//tr[@class='invalidBtn']/td"));
    str_errPopup = element(by.xpath("//div[@class='modal-body']/h5[1]"));
    btn_errOK = element(by.xpath("//div[@class='modal-content']//button[1]"));
    str_AccName = element(by.xpath("//datatable-row-wrapper[1]//datatable-body-cell[1]//span[1]"));
    str_Name= element(by.xpath("//div[@class='page-header']/h1"))
}