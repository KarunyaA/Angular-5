import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditInboundLocationComponent } from './edit-inbound-location.component';

describe('EditInboundLocationComponent', () => {
  let component: EditInboundLocationComponent;
  let fixture: ComponentFixture<EditInboundLocationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditInboundLocationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditInboundLocationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
