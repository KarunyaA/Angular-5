export class InboundAreaLocListModel {
  areaParamsList = {
    'query': {
      'bool': {
        'must': [{
          'match': {
            'bu_type': ''
          }
        }]
      }
    },
    'sort': {
      'capacity_area': {
        'order': 'asc'
      }
    },
    'from': 0,
    'size': 10000
  };
  locParamsList = {
    'query': {
      'bool': {
        'must': [{
          'match': {
            'bu_type': ''
          }
        }]
      }
    },
    'sort': {
      'cust_location_name': {
        'order': 'asc'
      }
    },
    'from': 0,
    'size': 10000
  };
  areaSearchParams = {
    'size': 10000,
    'from': 0,
    'query': {
      'bool': {
        'must': [{
          'query_string': {
            'query': '**'
          }
        }, {
          'match': {
            'bu_type': ''
          }
        }]
      }
    }
  };
  locSearchParams = {
    'size': 10000,
    'from': 0,
    'query': {
      'bool': {
        'must': [{
          'query_string': {
            'query': '**'
          }
        }, {
          'match': {
            'bu_type': ''
          }
        }]
      }
    }
  };
}
