import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inbound-area-list',
  templateUrl: './inbound-area-list.component.html',
  styleUrls: ['./inbound-area-list.component.scss']
})
export class InboundAreaListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
