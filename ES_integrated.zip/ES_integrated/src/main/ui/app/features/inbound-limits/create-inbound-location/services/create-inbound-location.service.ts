import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/toPromise';
import { JBHGlobals } from '../../../../app.service';
@Injectable()
export class CreateInboundLocationService {
  constructor(private jbhGlobals: JBHGlobals, private http: HttpClient) {}

  getServiceOffering(bu: string) {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    let url = this.jbhGlobals.endpoints.inboundlimits.serviceofferring;
    url += '?financeBusinessUnitCode=' + bu + '&projection=viewserviceofferingbusinessunittransitmode';
    return this.http.get < any > (url, {
      headers
    });
  }
  getFleetType(bu: string, so: string) {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    let url = this.jbhGlobals.endpoints.inboundlimits.fleettype;
    url += '?financeBusinessUnitCode=' + bu + '&serviceOffering=' + so + ';';
    return this.http.get < any > (url, {
      headers
    });
  }
  getLocationDTO(queryParam) {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const url = this.jbhGlobals.endpoints.inboundlimits.inboundlocation;
    return this.http.post < any > (url, queryParam)
      .toPromise()
      .then(data => data);
  }
  saveInboundArea(requestParam: object): Observable < any > {
    return this.jbhGlobals.apiService.addData(this.jbhGlobals.endpoints.inboundlimits.saveinboundlimits, requestParam, true);
  }
}

