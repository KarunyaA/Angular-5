export class ViewInboundAreaModel {
}
