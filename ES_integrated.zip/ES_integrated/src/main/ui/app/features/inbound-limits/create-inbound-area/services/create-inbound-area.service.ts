import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/toPromise';
import { JBHGlobals } from '../../../../app.service';
@Injectable()
export class CreateInboundAreaService {
  constructor(private jbhGlobals: JBHGlobals, private http: HttpClient) {}
  getCapacityArea(query, bu: string) {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    let url = this.jbhGlobals.endpoints.inboundlimits.capacityarea;
    url += '?areaName=' + query + '&businessUnit=' + bu;

    return this.http.get < any > (url)
      .toPromise()
      .then(data => {
        return data;
      });
  }

  getServiceOffering(bu: string) {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    let url = this.jbhGlobals.endpoints.inboundlimits.serviceofferring;
    url += '?financeBusinessUnitCode=' + bu + '&projection=viewserviceofferingbusinessunittransitmode';

    return this.http.get < any > (url, {
      headers
    });
  }

  getFleetType(bu: string, so: string) {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    let url = this.jbhGlobals.endpoints.inboundlimits.fleettype;
    url += '?financeBusinessUnitCode=' + bu + '&serviceOffering=' + so;
    return this.http.get < any > (url, {
      headers
    });
  }
  saveInboundArea(requestParam: object): Observable < any > {
    return this.jbhGlobals.apiService.addData(this.jbhGlobals.endpoints.inboundlimits.saveinboundlimits, requestParam, true);
  }
}
