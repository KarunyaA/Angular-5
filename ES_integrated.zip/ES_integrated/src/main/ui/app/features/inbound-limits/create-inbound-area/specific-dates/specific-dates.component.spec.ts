import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SpecificDatesComponent } from './specific-dates.component';

describe('SpecificDatesComponent', () => {
  let component: SpecificDatesComponent;
  let fixture: ComponentFixture<SpecificDatesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SpecificDatesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SpecificDatesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
