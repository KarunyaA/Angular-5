import { Component, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-view-inbound-area',
  templateUrl: './view-inbound-area.component.html',
  styleUrls: ['./view-inbound-area.component.scss']
})
export class ViewInboundAreaComponent implements OnInit {



  ngOnInit() {
  }


}
