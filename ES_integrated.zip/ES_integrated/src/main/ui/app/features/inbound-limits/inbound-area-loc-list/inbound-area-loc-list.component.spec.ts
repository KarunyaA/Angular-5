import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InboundAreaLocListComponent } from './inbound-area-loc-list.component';

describe('InboundAreaLocListComponent', () => {
  let component: InboundAreaLocListComponent;
  let fixture: ComponentFixture<InboundAreaLocListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InboundAreaLocListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InboundAreaLocListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
