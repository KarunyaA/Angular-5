import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { InboundLimitComponent } from './inbound-limit/inbound-limit.component';
const routes: Routes = [ {
    path: '',
    component : InboundLimitComponent
  }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class InboundLimitsRoutingModule { }
