import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-inbound-location',
  templateUrl: './edit-inbound-location.component.html',
  styleUrls: ['./edit-inbound-location.component.scss']
})
export class EditInboundLocationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
