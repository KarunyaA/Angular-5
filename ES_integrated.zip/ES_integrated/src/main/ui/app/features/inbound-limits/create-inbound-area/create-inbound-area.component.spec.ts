import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateInboundAreaComponent } from './create-inbound-area.component';

describe('CreateInboundAreaComponent', () => {
  let component: CreateInboundAreaComponent;
  let fixture: ComponentFixture<CreateInboundAreaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateInboundAreaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateInboundAreaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
