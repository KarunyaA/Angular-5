import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InboundAreaListComponent } from './inbound-area-list.component';

describe('InboundAreaListComponent', () => {
  let component: InboundAreaListComponent;
  let fixture: ComponentFixture<InboundAreaListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InboundAreaListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InboundAreaListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
