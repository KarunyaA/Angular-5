import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators, FormArray } from '@angular/forms';

import { CreateInboundLocationService } from './services/create-inbound-location.service';
import { InboundLocation } from './models/create-inbound-location-model';
import { JBHGlobals } from '../../../app.service';

@Component({
  selector: 'app-create-inbound-location',
  templateUrl: './create-inbound-location.component.html',
  styleUrls: ['./create-inbound-location.component.scss'],
  providers: [CreateInboundLocationService],
})

export class CreateInboundLocationComponent implements OnInit {
    @Input() buType: any;
    @Output() splitClose = new EventEmitter();
    inboundLocation: InboundLocation;
    myForm: FormGroup;
    errorDiv = false;
    specificDateError = false;
    msgs: any[] = [];

    constructor(private jbhGlobals: JBHGlobals,
        private createInboundLocationService: CreateInboundLocationService, private formBuilder: FormBuilder) {
        this.inboundLocation = new InboundLocation();
    }

    ngOnInit() {
        this.inboundLocation.formValid1 = false;
        this.inboundLocation.formValid2 = false;
        this.inboundLocation.formValid3 = false;
        this.inboundLocation.businessUnit = this.buType;
        this.getServiceOffering();
        this.addFormLocation();
    }
    addFormLocation(): void {
        this.myForm = this.formBuilder.group({
            'capacityLocation': ['', Validators.required],
            'fleetType': ['', Validators.required],
            'serviceOffering': ['', Validators.required],
            'sunday': new FormControl(''),
            'monday': new FormControl(''),
            'tuesday': new FormControl(''),
            'wednesday': new FormControl(''),
            'thursday': new FormControl(''),
            'friday': new FormControl(''),
            'saturday': new FormControl(''),
            date: this.formBuilder.array([]),
        });
    }

    getForm(myForm): any {
        return myForm.controls.date.controls;
    }
    formControl(myForm, i): any {
        return myForm.controls.date.controls[i];
    }

    // date function
    initDate(): any {
        return this.formBuilder.group({
            specificDate: [''],
            specificDateLimit: ['']
        });
    }

    // adding specific date
    addNewDate(): void {
        const control = < FormArray > (this.myForm.controls['date']);
        const addCtrl = this.initDate();
        addCtrl.valueChanges.subscribe(checkDates => {
            this.checkDuplicate(checkDates, control);
        });
        control.push(addCtrl);
    }

    // duplicate date check
    checkDuplicate(date: any, formArray: FormArray): void {
        const newDate = date;
        const dateArray = formArray.controls;
        const duplicateVal = [];
        this.errorDiv = false;
        if (formArray.controls.length > 1) {
            formArray.controls.forEach(element => {
                if (element.value.specificDate !== '') {
                    if (element.value.specificDate.indexOf(newDate.specificDate) !== -1) {
                        this.inboundLocation.checkDuplicate.push(newDate.specificDate);
                        if (this.inboundLocation.checkDuplicate.length > 1) {
                            this.errorDiv = true;
                        }
                    }
                }
            });
            this.inboundLocation.checkDuplicate = [];
        } else {
            this.errorDiv = false;
        }
    }
    //  to remove specific date
    removeDate(i: number): void {
        const control = < FormArray > this.myForm.controls['date'];
        control.removeAt(i);
        const newControl = < FormArray > this.myForm.controls['date'];
        if (newControl.controls.length > 1) {
            this.customGroupValidation(newControl);
        } else {
            this.inboundLocation.errorDiv = false;
        }
    }

    // date validation
    customGroupValidation(formArray: any): void {
        const uniqueNames = [];
        if (formArray.controls.length > 1) {
            this.inboundLocation.errorDiv = false;
            for (let i = 0; i < formArray.controls.length; i++) {
                if (uniqueNames.indexOf(formArray.controls[i].value.specificDate) === -1) {
                    this.inboundLocation.errorDiv = false;
                    uniqueNames.push(formArray.controls[i].value.specificDate);
                } else {
                    this.inboundLocation.errorDiv = true;
                }
            }
        }
    }

    //  to fetch service offering
    getServiceOffering(): void {
        this.createInboundLocationService.getServiceOffering(this.inboundLocation.businessUnit).subscribe(data => {
            if (data && data['_embedded'] && data['_embedded']['serviceOfferingBusinessUnitTransitModeAssociations']) {
                const listData = data['_embedded']['serviceOfferingBusinessUnitTransitModeAssociations'];
                const listValues = [];
                listData.forEach(element => {
                    const obj = {
                        name: element['serviceOfferingCode'],
                        code: element['serviceOfferingCode']
                    };
                    listValues.push(obj);
                });
                this.inboundLocation.serviceOfferingList = listValues;
            }
        });
    }

    // to fetch fleet code type
    onSelectType(event: any): void {
        /*if (event) {
    this.createInboundLocationService.getFleetType(this.inboundLocation.businessUnit, event['code']).subscribe(data => {
      if (data && data['_embedded'] && data['_embedded']['serviceOfferingBusinessUnitTransitModeAssociations']) {
        const listData = data['_embedded']['serviceOfferingBusinessUnitTransitModeAssociations'];
        const listValues = [];
        listData.forEach(element => {
          if (element) {
            const obj = {
              code: element['freightShippingType']['freightShippingTypeCode'],
              name: element['freightShippingType']['freightShippingTypeDescription']
            };
            listValues.push(obj);
          }
        });
        this.inboundLocation.fleetTypeList = listValues;
      }
    });
  }*/
        if (this.buType === 'JBI') {
            this.inboundLocation.fleetTypeList = this.inboundLocation.jbiFleetype;
        }
        if (this.buType === 'JBT') {
            this.inboundLocation.fleetTypeList = this.inboundLocation.jbtFleetype;
        }
        if (this.buType === 'DCS') {
            this.inboundLocation.fleetTypeList = this.inboundLocation.dcsFleetype;
        }
        if (this.buType === 'ICS') {
            this.inboundLocation.fleetTypeList = this.inboundLocation.icsFleetype;
        }
    }

    // to fetch capacity location
    getCapacityLocation(event: any): void {
        const queryParam = this.inboundLocation.getLocationDTO;
        queryParam['query']['bool']['must'][0]['query_string']['query'] = event.query + '*';
        this.createInboundLocationService.getLocationDTO(queryParam).then(areas => {
            if (areas && areas['hits'] && areas['hits']['hits']) {
                const locations = areas['hits']['hits'];
                const arrayList = [];
                locations.forEach(locationObj => {
                    if (locationObj) {
                        arrayList.push({
                            id: locationObj['_id'],
                            address: locationObj['_source']['Address']['AddressLine1'],
                            name: locationObj['_source']['LocationName'],
                            code: locationObj['_source']['LocationCode'],
                        });
                    }
                });
                this.inboundLocation.locationList = arrayList;
            }
        });
    }

    // to save a inbound location limit
    onSave(): void {
        const dailyLimitEntered = [];
        this.inboundLocation.test = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
        for (let j = 0; j < this.inboundLocation.test.length; j++) {
            if (this.inboundLocation[this.inboundLocation.test[j]]) {
                dailyLimitEntered.push({
                    'weekDayCode': this.inboundLocation.test[j],
                    'inboundLoadCapacityLimitCount': this.inboundLocation[this.inboundLocation.test[j]]
                });
            }
        }
        const dates = this.myForm.value['date'];
        const arrayList = [];
        dates.forEach(dateObj => {
            const dateSeperated = dateObj['specificDate'].split('/');
            const dateArray = [parseInt(dateSeperated[2], 10),
                parseInt(dateSeperated[0], 10), parseInt(dateSeperated[1], 10)
            ];
            arrayList.push({
                inboundCapacityLimitDate: dateArray,
                inboundLoadCapacityDateLimitCount: dateObj['specificDateLimit'],
            });
        });
        this.inboundLocation.specificDates = arrayList;
        const reqJson = {
            'customerLocationID': this.myForm.value['capacityLocation']['id'],
            'customerLocationCode': this.myForm.value['capacityLocation']['code'],
            'customerLocationName': this.myForm.value['capacityLocation']['name'],
            'customerLocationAddress': this.myForm.value['capacityLocation']['address'],
            'financeBusinessUnitCode': this.inboundLocation.businessUnit,
            'serviceOfferingCode': this.myForm.value['serviceOffering']['code'],
            'fleetTypeCode': this.myForm.value['fleetType']['code'],
            'specificDates': this.inboundLocation.specificDates,
            'dailyLimit': dailyLimitEntered,
        };
        for (let n = 0; n < this.myForm.controls.date['controls']['length']; n++) {
            if (this.myForm.controls.date['controls'][n].value.specificDate &&
                this.myForm.controls.date['controls'][n].value.specificDateLimit === '') {
                this.specificDateError = true;
            } else {
                this.specificDateError = false;
            }
        }
        if (this.myForm.valid) {
            if (this.myForm.valid && this.errorDiv === false &&
                this.specificDateError === false && (this.myForm.controls.sunday.value ||
                    this.myForm.controls.monday.value || this.myForm.controls.tuesday.value ||
                    this.myForm.controls.wednesday.value || this.myForm.controls.thursday.value ||
                    this.myForm.controls.friday.value || this.myForm.controls.saturday.value)) {
                this.createInboundLocationService.saveInboundArea(reqJson).subscribe(data => {
                    if (data['error']) {
                        if (data['error']['errorMessage'] === 'DUPLICATE_INBOUND_LOCAITON_EXISTS') {
                            this.jbhGlobals.notifications.add({
                                severity: 'error',
                                summary: 'Duplicate Inbound Limit',
                                detail: 'An active inbound limit already exists, ' +
                                    'please create new inbound limit or edit existing' +
                                    ' inbound limits54321125 RowsJBI INBOUND LIMITSLoadsCapacity Settings'
                            });
                        }
                        if (data['error']['errorMessage'] === 'INBOUND_CAPACITY_AREA_ID_OR_LOCATION_ID_NOT_FOUND') {
                            this.jbhGlobals.notifications.add({
                                severity: 'error',
                                summary: 'Error',
                                detail: 'Error'
                            });
                        }
                    } else {
                        this.splitClose.emit(false);
                        this.jbhGlobals.notifications.add({
                            severity: 'success',
                            summary: 'Save Inbound Limit',
                            detail: 'Inbound Limit for ' + this.myForm.value['capacityLocation']['name'] + 'has been successfully added'
                        });
                    }
                    this.myForm.reset();
                    this.onCancel();
                });
            } else {
                this.jbhGlobals.notifications.add({
                    severity: 'Save',
                    summary: 'Daily Limit',
                    detail: 'Add atleast one daily limit'
                });
            }
        } else {
            this.inboundLocation.formValid1 = !this.myForm.controls.capacityLocation.valid;
            this.inboundLocation.formValid2 = !this.myForm.controls.serviceOffering.valid;
            this.inboundLocation.formValid3 = !this.myForm.controls.fleetType.valid;
        }
    }
    onCancel(): void {
        this.splitClose.emit(false);
        this.myForm.reset();
    }
}
