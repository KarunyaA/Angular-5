import { Component,  OnInit } from '@angular/core';

import { InboundLimitModel } from '../inbound-limit/models/inbound-limit-model';

@Component({
  selector: 'app-inbound-limit',
  templateUrl: './inbound-limit.component.html',
  styleUrls: ['./inbound-limit.component.scss'],
  providers: [InboundLimitModel]
})

export class InboundLimitComponent {
  inboundLimitModel: InboundLimitModel;
  constructor() {
    this.inboundLimitModel = new InboundLimitModel();
  }
}
