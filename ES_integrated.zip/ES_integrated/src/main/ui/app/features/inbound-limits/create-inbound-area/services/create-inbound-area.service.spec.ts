import { TestBed, inject } from '@angular/core/testing';

import { CreateInboundAreaService } from './create-inbound-area.service';

describe('CreateInboundAreaService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CreateInboundAreaService]
    });
  });

  it('should be created', inject([CreateInboundAreaService], (service: CreateInboundAreaService) => {
    expect(service).toBeTruthy();
  }));
});
