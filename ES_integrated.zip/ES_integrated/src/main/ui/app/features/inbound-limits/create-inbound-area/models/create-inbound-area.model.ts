export class InboundAreaModel {
  serviceOfferingList: object[];
  msgs: any[] = [];
  businessUnit: string;
  serviceOffering: string;
  fleetType: string;
  specificDates: any;
  filteredCountriesSingle: Array<object>;
  fleetTypeList: object[];
  filteredArea: object[];
  duplicateArray: any[] = [];
  test: any[] = [];
  Sunday: number;
  Monday: number;
  Tuesday: number;
  Wednesday: number;
  Thursday: number;
  Friday: number;
  Saturday: number;
  formValid1: boolean;
  formValid2: boolean;
  formValid3: boolean;
  icsFleetype = [{name: 'Alternative', code: 'Alternative'}];
  jbiFleetype = [{name: 'Intermodal', code: 'Intermodal'}];
  jbtFleetype = [{name: 'OTR', code: 'OTR'}, {name: 'Regional', code: 'Regional'}, {name: 'Van Engineered', code: 'VanEngineered'}];
  dcsFleetype = [{name: 'DCS Backhaul', code: 'DCSBackhaul'}];
}

