import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateInboundLocationComponent } from './create-inbound-location.component';

describe('CreateInboundLocationComponent', () => {
  let component: CreateInboundLocationComponent;
  let fixture: ComponentFixture<CreateInboundLocationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateInboundLocationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateInboundLocationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
