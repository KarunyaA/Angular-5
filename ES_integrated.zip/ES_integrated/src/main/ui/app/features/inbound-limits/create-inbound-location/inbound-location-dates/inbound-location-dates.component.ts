import { Component, OnInit, Input } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators, FormArray } from '@angular/forms';

@Component({
  selector: 'app-inbound-location-dates',
  templateUrl: './inbound-location-dates.component.html',
  styleUrls: ['./inbound-location-dates.component.scss']
})
export class InboundLocationDatesComponent implements OnInit {
  @Input() group: any;
  @Input() myFormObj: any;
  specdateForm: FormGroup;
  specificDateForm: FormGroup;
  newDateArray: any[];
  constructor() { }
  date = new Date();
  today = new Date();
  ngOnInit() {
    this.today.setDate =  this.date.getDate;
    this.today.setMonth = this.date.getMonth;
    this.today.setFullYear = this.date.getFullYear;

  }
  getDate(value) {
    if (value !== undefined) {
        this.newDateArray.push(value);
    }
}
}
