export class InboundLocation {
  Sunday: number;
  Monday: number;
  Tuesday: number;
  Wednesday: number;
  Thursday: number;
  Friday: number;
  Saturday: number;
  test: any[];
  inboundCapacityLimitDate: any;
  inboundLoadCapacityDateLimitCount: number;
  weekDayCode: String;
  inboundLoadCapacityLimitCount: number;
  duplicateArray: any;
  checkDuplicate: any[] = [];
  businessUnit: any;
  locationList: object[];
  serviceOfferingList: any;
  fleetType: any;
  serviceOffering: any;
  locationDetail: any;
  fleetTypeList: any;
  errorDiv: any;
  specificDates: any;
  limi: any;
  formValid1: boolean;
  formValid2: boolean;
  formValid3: boolean;
  icsFleetype: object[] = [{
    name: 'Alternative',
    code: 'Alternative'
  }];
  jbiFleetype: object[] = [{
    name: 'Intermodal',
    code: 'Intermodal'
  }];
  jbtFleetype: object[] = [{
    name: 'OTR',
    code: 'OTR'
  }, {
    name: 'Regional',
    code: 'Regional'
  }, {
    name: 'Van Engineered',
    code: 'VanEngineered'
  }];
  dcsFleetype: object[] = [{
    name: 'DCS Backhaul',
    code: 'DCSBackhaul'
  }];


  getLocationDTO: object = {
    'size': 5,
    '_source': ['LocationName', 'LocationCode', 'Address.AddressLine1', 'Address.AddressLine2',
      'Address.CityName', 'Address.StateName', 'Address.StateCode', 'Address.CountryName',
      'Address.PostalCode', 'TelephoneID', 'TelephoneNumber', 'Address.AddressID', 'OrganizationName',
      'BusinessIdentificationNumber'
    ],
    'query': {
      'bool': {
        'must': [{
          'query_string': {
            'fields': ['LocationName', 'LocationCode', 'Address.AddressLine1',
              'Address.AddressLine2', 'Address.CityName', 'Address.StateName', 'Address.StateCode',
              'Address.CountryName', 'Address.PostalCode', 'TelephoneNumber',
              'TelephoneNumber.merged', 'BusinessIdentificationNumber'
            ],
            'query': '',
            'default_operator': 'and'
          }
        }, {
          'nested': {
            'path': 'locationroles',
            'query': {
              'query_string': {
                'fields': ['locationroles.LocationRoleTypeDescription'],
                'query': '*',
                'split_on_whitespace': false
              }
            },
            'inner_hits': {
              'size': 2,
              '_source': {
                'includes': ['locationroles.LocationRoleTypeDescription']
              }
            }
          }
        }, {
          'nested': {
            'path': 'locationtypes',
            'query': {
              'query_string': {
                'fields': ['locationtypes.LocationTypeDescription'],
                'query': '*',
                'split_on_whitespace': false
              }
            },
            'inner_hits': {
              'size': 2,
              '_source': {
                'includes': ['locationtypes.LocationTypeDescription']
              }
            }
          }
        }]
      }
    }
  };
}
