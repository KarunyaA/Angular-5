import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Http, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { JBHGlobals } from '../../../../app.service';
@Injectable()
export class LocalDistributionService {
  baseUrl = '';
  constructor(private jbhGlobals: JBHGlobals, private http: HttpClient) {}

  getLocalCenters(): Observable<Response[]> {

    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const url = '/loads/masterdata-location-details/location_info/_search';
    return this.http.get(url)
      .map((res: Response) => {
        const responseJson: any = res;
        return responseJson;
      });
  }

  getDailyRouteCapacity(locationID: number): Observable<Response[]> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    let url = '/loads/capacityldccapacity/localdistributioncentercapacityrepositories/';
    url += 'search/findByLocalDistributionCenterLocationID?locationId=' + locationID;
    return this.jbhGlobals.apiService.getData(url, null, true);
    /*return this.http.get(url)
      .map((res: Response) => {
        const responseJson: any = res;
        return responseJson;
      });*/
  }
  getUserSearch(): Observable<Response[]> {

    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const userId = 'jcnt311';
    const url = '/loads/capacityuserutility/usersavedsearch/search/usersavedsearch?userID=' + userId;
    return this.http.get(url)
      .map((res: Response) => {
        const responseJson: any = res;
        return responseJson;
      });
  }
  getUserInfo(): Observable<Response[]> {

    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const url = 'mock/esaorder.json';
    return this.http.get(url)
      .map((res: Response) => {
        const responseJson: any = res;
        return responseJson;
      });
  }
  saveUserSearch(param): Observable<Response[]> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const url = '/loads/capacityuserutility/usersavedsearch';
    return this.http.post(url, param)
      .map((res: Response) => {
        const responseJson: any = res;
        return responseJson;
      });
  }
   getLocationDTO(queryParam) {
     const headers = new HttpHeaders().set('Content-Type', 'application/json');
     const url = '/loads/masterdata-location-details/location_info/_search';
     return this.http.post < any > (url, queryParam)
       .toPromise()
       .then(data => data);
   }

}
