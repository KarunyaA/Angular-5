import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-specific-date',
  templateUrl: './specific-date.component.html',
  styleUrls: ['./specific-date.component.scss']
})
export class SpecificDateComponent implements OnInit {
  @Input() group: FormGroup;
  localDistributionCenterCapacityDate: FormControl;
  @Output() specificDateFormGroup: EventEmitter<any> = new EventEmitter();
  @Output() showEmptyDateErrorFlag: EventEmitter<any> = new EventEmitter();
  public dateForm: FormGroup;
  newDateArray: any[];
  date = new Date();
  today = new Date();
  showEmptyDateError = false;

  constructor(private _fb: FormBuilder) { }

  ngOnInit() {
    this.today.setDate = this.date.getDate;
    this.today.setMonth = this.date.getMonth;
    this.today.setFullYear = this.date.getFullYear;
    this.dateForm = this._fb.group({
      localDistributionCenterCapacityDate: [0, Validators.required],
      localDistributionCenterRouteCapacityCount: [0, Validators.required]
    });
    this.dateForm['valueChanges'].
      subscribe(form => {
        console.log(form);
        this.specificDateFormGroup.emit(this.dateForm);
      });
  }
  checkEmptyDates() {
    if (this.dateForm.value.localDistributionCenterCapacityDate === 0) {
      this.showEmptyDateError = true;
    } else {
      this.showEmptyDateError = false;
    }
    this.showEmptyDateErrorFlag.emit(this.showEmptyDateError);
  }

  selectDate() {
    if (this.group.value.localDistributionCenterCapacityDate) {
    this.showEmptyDateError = false;
    } else {
      this.showEmptyDateError = true;
    }
    this.showEmptyDateErrorFlag.emit(this.showEmptyDateError);
  }
}
