import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Http, RequestOptions } from '@angular/http';

@Injectable()
export class UpdateLdcService {

  constructor(private http: HttpClient) { }

  addLDC(data: Object): Observable<Response[]> {

    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const url = '/loads/capacityldccapacity/ldccapacity';
    return this.http.post(url, data)
      .map((res: Response) => {
        const responseJson: any = res;
        return responseJson;
      });
  }

  updateLDC(data: Object, capacityid: number) {

    const capacityID = capacityid;
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const url = '/loads/capacityldccapacity/ldccapacity/ldccapacity/' + capacityID;
    return this.http.patch(url, data)
      .map((res: Response) => {
        const responseJson: any = res;
        return responseJson;
      });

  }
}
