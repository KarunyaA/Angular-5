import { Component, OnInit, OnDestroy, ViewChild, ElementRef } from '@angular/core';
import { FormGroup, FormArray, FormBuilder, Validators, FormControl } from '@angular/forms';
import { MenuItem } from 'primeng/api';
import { LocalDistributionService } from './service/local-distribution.service';
import { ViewModel } from './model/view-model';
import { Index } from '../ldcenum/index.enum';
import { ConfirmationService } from 'primeng/api';
import { Message } from 'primeng/components/common/api';
import { GrowlModule } from 'primeng/growl';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import * as _ from 'lodash';

@Component({
  selector: 'app-view-ldc',
  templateUrl: './view-ldc.component.html',
  styleUrls: ['./view-ldc.component.scss'],
  providers: [ConfirmationService]
})
export class ViewLdcComponent implements OnInit, OnDestroy {


  /**Variable declarations */
capacityID: number;
dailyRouteCapacity: Array<Object>;
eventName: any;
filteredLocationCenter: any;
ldcDailyRouteObject: any;
ldcData: Array<Object>;
ldcIndex = Index;
ldcLocationID: Object;
ldcViewData: Object;
locationName: any;
msgs: Message[] = [];
myForm: FormGroup;
myValue = new FormControl([]);
selectedIndex = 0;
specificDates: Array<Object>;
userId: any;
utils: any;
viewModel: ViewModel;
  constructor(private _fb: FormBuilder, private ldcService: LocalDistributionService, private confirmationService: ConfirmationService) {
    this.utils = _;
  }

  ngOnInit() {
    this.viewModel = new ViewModel();
    this.viewModel.userRole = 'LDCManager';
    this.ldcForm();
    this.getALLocationInfo();
  }

  ngOnDestroy() {
    this.viewModel.dailyRouteObservable.unsubscribe();
  }
  ldcForm() {
    this.myForm = this._fb.group({
      ldcName: [0, Validators.required],
      ldcDate: [0, Validators.required],
      ldcLimit: [0, Validators.required]
    });
}

  getALLocationInfo(): void {
    this.ldcData = [];
    this.viewModel.dailyRouteObservable = this.ldcService.getLocalCenters().subscribe((locations: any) => {
      if (!this.utils.isEmpty(locations)) {
        const locationArray = locations['hits']['hits'];
        if (!this.utils.isEmpty(locationArray)) {
          let locationObj;
          locationArray.forEach(element => {
            locationObj = {
              locationname: element['_source']['LocationName'],
              locationID: element['_source']['LocationID'],
              locationCode: element['_source']['LocationCode']
            };
            this.ldcData.push(locationObj);
          });
          this.filteredLocationCenter = this.ldcData.sort();
          const filterIndex = this.ldcIndex.indexZero;
          this.myForm.controls['ldcName'].patchValue({
            name: ` ${this.
              filteredLocationCenter[filterIndex]['locationname']} ${this.filteredLocationCenter[filterIndex]['locationCode']}`
          });
          this.getLDCDailyRoutesCapacity(this.filteredLocationCenter[filterIndex]['locationID']);
        }
this.locationName = this.filteredLocationCenter[this.ldcIndex.indexZero]['locationname'];
      }
    });

  }

  filterLocationCenter(localCenter: any): void {
    const queryParam = this.viewModel.getLocationID;
    queryParam['query']['bool']['must'][0]['query_string']['query'] = localCenter.query + '*';
    this.ldcService.getLocationDTO(queryParam).then(areas => {
      if (areas && areas['hits'] && areas['hits']['hits']) {
        const locations = areas['hits']['hits'];
        const arrayList = [];
        locations.forEach(locationObj => {
          if (locationObj) {
            arrayList.push({
              id: locationObj['_id'],
              address: locationObj['_source']['Address']['AddressLine1'],
              name: locationObj['_source']['LocationName'],
              code: locationObj['_source']['LocationCode'],
            });
          }
        });
        this.filteredLocationCenter  = arrayList;
      }
    });

    //  this.filteredLocationCenter = this.filterLocations(this.ldcData);
  }

  getLDCDailyRoutesCapacity(locationID: number): void {
    this.viewModel.dailyRouteObservable = this.ldcService.getDailyRouteCapacity(locationID).subscribe((dailyRoutes: any) => {
      this.ldcViewData = {};
      if (!this.utils.isEmpty(dailyRoutes)) {
        if (dailyRoutes['localDistributionCenterCapacityID']) {
          this.capacityID = dailyRoutes['localDistributionCenterCapacityID'];
        }
        const dailyRouteArray = dailyRoutes['localDistributionCenterDayOfWeekCapacities'];
        const speicificArray = dailyRoutes['localDistributionCenterDateCapacities'];
        const dailyLimitData = [];
        const specificDatesData = [];
        let dailyObj = {};
        dailyRouteArray.forEach(element => {
          dailyObj = {
            ldcday: element['weekDayCode'],
            ldclimit: element['localDistributionCenterRouteCapacityCount'],
            ldcrouteid: element['localDistributionCenterDayOfWeekCapacityID']
          };
          dailyLimitData.push(dailyObj);
        });
        this.dailyRouteCapacity = dailyLimitData;
        let specificObj = {};
        speicificArray.forEach(element => {
          specificObj = {
            specificCount: element['localDistributionCenterRouteCapacityCount'],
            specificDate: element['localDistributionCenterCapacityDate'],
            specificID: element['localDistributionCenterDateCapacityID']
          };
          specificDatesData.push(specificObj);
        });

        this.specificDates = specificDatesData;
        if (this.capacityID) {
          this.ldcViewData = {
            'locationId': locationID,
            'loc': this.locationName,
              'capacityID': this.capacityID,
            'dailyRoute': this.dailyRouteCapacity,
            'specificDates': this.specificDates
          };
        } else {
          this.ldcViewData = {
            'locationId': locationID,
            'loc': this.locationName,
            'dailyRoute': this.dailyRouteCapacity,
            'specificDates': this.specificDates
          };
        }
      }
    }, (error: Error) => {
      this.ldcViewData = {
        'locationId': locationID,
        'loc': this.locationName,
        'capacityID': '',
        'dailyRoute': [],
        'specificDates': []
      };
    });

  }

  filterLocations(locations: any): Object {
    const filtered = [];
    for (let i = 0; i < locations.length; i++) {
      const location = locations[i];
      if (location.locationname) {
        filtered.push({ 'name': location.locationname + location.locationCode, 'id': location.locationID });
      }
    }
    return filtered;
  }

  onLDCSelect(localID: Object): void {
    const locID = localID['id'];
    this.eventName = localID['name'];
    this.locationName = localID['name'];
    this.ldcLocationID = {
      'locID': locID,
      'loc': this.eventName
    };
    this.getLDCDailyRoutesCapacity(locID);
  }

  onChange(tabIndex: any): void {
    this.selectedIndex = tabIndex.index;
    this.getALLocationInfo();

if (tabIndex.index !== 0) {
      this.onBlurMethod();
      // this.viewModel.selectedTabFlag = false;
    }
  }

  getUserSearch() {
    this.ldcService.getUserInfo().subscribe((userInfo: any) => {
      this.userId = userInfo.userId;
    });
    this.ldcService.getUserSearch().subscribe((userSavedSearches: any) => {
      if (userSavedSearches) {
        const userSavedSearch = userSavedSearches['_embedded']['userSavedSearches'];
        this.viewModel.userSavedSearchID = userSavedSearch[0]['userSavedSearchID'];
      }
      const userSearchCriteria = { 'locationDistributionCenter': this.eventName };
      if (this.viewModel.userSavedSearchID) {
        this.viewModel.userSavedData = {
          userSavedSearchID: this.viewModel.userSavedSearchID,
          personID: this.userId,
          applicationSearchFunctionCode: 'CAP001',
          userSearchName: 'LdcCapacitySearch',
          userSearchDefaultIndicator: 'N',
          userSearchCriteriaContent: JSON.stringify(userSearchCriteria)
        };
      } else {
        this.viewModel.userSavedData = {
          personID: this.userId,
          applicationSearchFunctionCode: 'CAP001',
          userSearchName: 'LdcCapacitySearch',
          userSearchDefaultIndicator: 'N',
          userSearchCriteriaContent: JSON.stringify(userSearchCriteria)
        };
      }

      this.ldcService.saveUserSearch(this.viewModel.userSavedData).subscribe((saveUser: any) => {
        // TODO
      });
    });

  }
  onBlurMethod() {
    console.log(this.viewModel.spinnerFormGroup);
    if (
      ((typeof (this.myForm) !== 'undefined' && this.myForm.dirty) ||
        (typeof (this.viewModel.spinnerFormGroup) !== 'undefined' && this.viewModel.spinnerFormGroup.dirty) ||
        (typeof (this.viewModel.specificDateFormGroupFromUpdate) !== 'undefined' && this.viewModel.specificDateFormGroupFromUpdate.dirty))
    ) {
      // this.viewModel.selectedTabFlag = false;
      this.confirmationService.confirm({
        message: 'You are about to lose all the changes. Do you want to proceed?',
        header: 'Confirmation',
        reject: () => {
          this.selectedIndex = 0;
          // this.getUserSearch();
        },
        accept: () => {
          this.getALLocationInfo();
        },
      });
    }

  }

  spinnerFormGroup(spinnerFormGroup): void {
    this.viewModel.spinnerFormGroup = spinnerFormGroup;
  }

  specificDateFormGroupFromUpdate(specificDateFormGroupFromUpdate): void {
    this.viewModel.specificDateFormGroupFromUpdate = specificDateFormGroupFromUpdate;
  }
}
