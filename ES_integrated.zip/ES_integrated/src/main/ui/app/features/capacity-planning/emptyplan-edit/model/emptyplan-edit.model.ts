export class EmptyplanEditModel {

}
