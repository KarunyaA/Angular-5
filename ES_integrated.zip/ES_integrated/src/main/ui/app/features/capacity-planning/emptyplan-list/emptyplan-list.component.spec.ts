import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmptyplanListComponent } from './emptyplan-list.component';

describe('EmptyplanListComponent', () => {
  let component: EmptyplanListComponent;
  let fixture: ComponentFixture<EmptyplanListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmptyplanListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmptyplanListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

});
