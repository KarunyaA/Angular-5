export class EmptyplanCreateQuery {
  queryOrigin: object;
  queryDestination: object;
  queryOriginPopulate: object;
  queryDestinationPopulate: object;
  searchQuery: object;
  querySearch: object;

  // Typing Origin
  getOriginQuery(param: any): any {
    this.queryOrigin = {
      query: {
        query_string: {
          fields: [
            'OriginRampGroup'
          ],
          query: `${param.input}`
        }
      },
      _source: [
        'OriginRampGroup'
      ]
    };
    return this.queryOrigin;
  }

  // Typing Destination
  getDestinationQuery(param: any): any {
    this.queryDestination = {
      query: {
        query_string: {
          fields: [
            'DestinationRampGroup'
          ],
          query: `${param.input}`
        }
      },
      _source: [
        'DestinationRampGroup'
      ]
    };
    return this.queryDestination;
  }

  // Auto Populate Origin
  getOriginPopulateQuery(param: any): any {
    this.queryOriginPopulate = {
      query: {
        match: {
          DestinationRampGroup: `${param.input}`
        }
      },
      _source: [
        'OriginRampGroup'
      ]
    };
    return this.queryOriginPopulate;
  }

  // Auto Populate Destination
  getDestinationPopulateQuery(param: any): any {
    this.queryDestinationPopulate = {
      query: {
        match: {
          OriginRampGroup: `${param.input}`
        }
      },
      _source: [
        'DestinationRampGroup'
      ]
    };
    return this.queryDestinationPopulate;
  }

  // Search Origin Destination
  getSearchValue(param: any): any {
    this.querySearch = {
      query: {
        bool: {
          must: [
            {
              query_string: {
                fields: [
                  'OriginRampGroup'
                ],
                query: `${param.origin}`
              }
            },
            {
              query_string: {
                fields: [
                  'DestinationRampGroup'
                ],
                query: `${param.destination}`
              }
            },
            {
              range: {
                StartDate: {
                  gte: '04-20-2018'
                }
              }
            },
            {
              range: {
                EndDate: {
                  lte: '04-30-2018'
                }
              }
            }
          ]
        }
      }
    };
    return this.querySearch;
  }
}
