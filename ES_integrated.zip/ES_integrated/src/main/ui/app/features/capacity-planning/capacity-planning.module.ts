import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { TabViewModule } from 'primeng/tabview';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { ButtonModule } from 'primeng/button';

import { CapacityPlanningRoutingModule } from './capacity-planning-routing.module';
import { CapacityPlanningComponent } from './capacity-planning/capacity-planning.component';
import { EmptyplanListComponent } from './emptyplan-list/emptyplan-list.component';
import { EmptyplanEditComponent } from './emptyplan-edit/emptyplan-edit.component';
import { EmptyplanCreateComponent } from './emptyplan-create/emptyplan-create.component';

@NgModule({
  imports: [
    CommonModule,
    CapacityPlanningRoutingModule,
    TabViewModule,
    AutoCompleteModule,
    FormsModule,
    ReactiveFormsModule,
    ButtonModule
  ],
  declarations: [CapacityPlanningComponent, EmptyplanListComponent, EmptyplanEditComponent, EmptyplanCreateComponent]
})

export class CapacityPlanningModule { }
