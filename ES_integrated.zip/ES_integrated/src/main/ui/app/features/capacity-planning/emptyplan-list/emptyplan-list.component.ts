import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emptyplan-list',
  templateUrl: './emptyplan-list.component.html',
  styleUrls: ['./emptyplan-list.component.scss']
})
export class EmptyplanListComponent implements OnInit {
  formFlag = 1;
  constructor() { }

  ngOnInit() {
  }


}
