import { TestBed, inject } from '@angular/core/testing';

import { EmptyplanEditService } from './emptyplan-edit.service';

describe('EmptyplanEditService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [EmptyplanEditService]
    });
  });

  it('should be created', inject([EmptyplanEditService], (service: EmptyplanEditService) => {
    expect(service).toBeTruthy();
  }));

});
