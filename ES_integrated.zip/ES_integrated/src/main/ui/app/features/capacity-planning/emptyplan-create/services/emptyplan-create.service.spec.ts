import { TestBed, inject } from '@angular/core/testing';

import { EmptyplanCreateService } from './emptyplan-create.service';

describe('EmptyplanCreateService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [EmptyplanCreateService]
    });
  });

  it('should be created', inject([EmptyplanCreateService], (service: EmptyplanCreateService) => {
    expect(service).toBeTruthy();
  }));

});
