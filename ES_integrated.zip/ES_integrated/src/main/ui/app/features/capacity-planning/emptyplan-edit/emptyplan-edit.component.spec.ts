import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmptyplanEditComponent } from './emptyplan-edit.component';

describe('EmptyplanEditComponent', () => {
  let component: EmptyplanEditComponent;
  let fixture: ComponentFixture<EmptyplanEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmptyplanEditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmptyplanEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

});
