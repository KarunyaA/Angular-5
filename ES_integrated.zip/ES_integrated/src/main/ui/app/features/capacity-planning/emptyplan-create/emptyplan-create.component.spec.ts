import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmptyplanCreateComponent } from './emptyplan-create.component';

describe('EmptyplanCreateComponent', () => {
  let component: EmptyplanCreateComponent;
  let fixture: ComponentFixture<EmptyplanCreateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmptyplanCreateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmptyplanCreateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

});
