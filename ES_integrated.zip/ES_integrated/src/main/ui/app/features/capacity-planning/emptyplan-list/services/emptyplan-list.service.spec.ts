import { TestBed, inject } from '@angular/core/testing';

import { EmptyplanListService } from './emptyplan-list.service';

describe('EmptyplanListService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [EmptyplanListService]
    });
  });

  it('should be created', inject([EmptyplanListService], (service: EmptyplanListService) => {
    expect(service).toBeTruthy();
  }));

});
