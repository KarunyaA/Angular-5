import { FormGroup } from '@angular/forms';

export class EmptyplanCreateModel {
  searchForm: FormGroup;
  elasticOriginParam: any;
  elasticDestinationParam: any;
  elasticOriginSelectParam: any;
  elasticDestinationSelectParam: any;
  validFormOrigin: boolean;
  validFormDestination: boolean;
  originSuggession: any;
  destinationSuggession: any;
  searchParam: any;

  constructor() {
    this.validFormOrigin = false;
    this.validFormDestination = false;
  }
}
