import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';

import * as _ from 'lodash';

import { EmptyplanCreateService } from './services/emptyplan-create.service';
import { EmptyplanCreateModel } from './model/emptyplan-create.model';
import { EmptyplanCreateQuery } from './emptyplanCreate-query';
@Component({
  selector: 'app-emptyplan-create',
  templateUrl: './emptyplan-create.component.html',
  styleUrls: ['./emptyplan-create.component.scss'],
  providers: [EmptyplanCreateService, EmptyplanCreateQuery]

})
export class EmptyplanCreateComponent implements OnInit {

  createModel: EmptyplanCreateModel;


  constructor(private fb: FormBuilder, private query: EmptyplanCreateQuery, private service: EmptyplanCreateService) {
    this.createModel = new EmptyplanCreateModel();
  }

  ngOnInit() {
    this.searchGroup();
  }

  // Initializing The FromGroup
  searchGroup(): void {
    this.createModel.searchForm = this.fb.group({
      originRampGroup: ['', Validators.required],
      destinationRampGroup: ['', Validators.required]
    });
  }

  // Get Function Of Origin
  getOriginRampGroup(event: any): void {
    const originTypeaheadParams: object = {
      'input': `${event.query.replace(/[,!?^~=\/{}&&||<>()+*-]/g, ' ')}${'*'}`
    };
    this.createModel.elasticOriginParam = this.query.getOriginQuery(originTypeaheadParams);
    this.service.getOriginValue(this.createModel.elasticOriginParam).then(data => {
      if (data && data['hits'] && data['hits']['hits']) {
        const listData = data['hits']['hits'];
        const listValues = [];
        listData.forEach((element: any) => {
          listValues.push({
            id: element._source.OriginRampGroup,
            text: element._source.OriginRampGroup
          });
        });
        this.createModel.originSuggession = listValues;
      }
    });
  }

  // Get Function Of Destination
  getDestinationRampGroup(event): void {
    const destinationTypeaheadParams: object = {
      'input': `${event.query.replace(/[,!?^~=\/{}&&||<>()+*-]/g, ' ')}${'*'}`
    };
    this.createModel.elasticDestinationParam = this.query.getDestinationQuery(destinationTypeaheadParams);
    this.service.getOriginValue(this.createModel.elasticDestinationParam).then(data => {
      if (data && data['hits'] && data['hits']['hits']) {
        const listData = data['hits']['hits'];
        const listValues = [];
        listData.forEach((element: any) => {
          listValues.push({
            id: element._source.DestinationRampGroup,
            text: element._source.DestinationRampGroup
          });
        });
        this.createModel.destinationSuggession = listValues;
      }
    });
  }

  // Origin Select Destination Auto Populate
  originSelect(event): void {
    const selectOriginTypeaheadParams: object = {
      'input': event.id
    };
    this.createModel.elasticOriginSelectParam = this.query.getDestinationPopulateQuery(selectOriginTypeaheadParams);
    this.service.getOriginValue(this.createModel.elasticOriginSelectParam).then(data => {
      if (data && data['hits'] && data['hits']['hits']) {
        const listData = data['hits']['hits'];
        const listValues = [];
        listData.forEach((element: any) => {
          listValues.push({
            id: element._source.DestinationRampGroup,
            text: element._source.DestinationRampGroup
          });
        });
        this.createModel.destinationSuggession = listValues;
        console.log(this.createModel.destinationSuggession);
      }
    });
  }

  // Destination Select Origin Auto Populate
  destinationSelect(event): void {
    const selectDestinationTypeaheadParams: object = {
      'input': event.id
    };
    this.createModel.elasticDestinationSelectParam = this.query.getOriginPopulateQuery(selectDestinationTypeaheadParams);
    this.service.getOriginValue(this.createModel.elasticDestinationSelectParam).then(data => {
      if (data && data['hits'] && data['hits']['hits']) {
        const listData = data['hits']['hits'];
        const listValues = [];
        listData.forEach((element: any) => {
          listValues.push({
            id: element._source.OriginRampGroup,
            text: element._source.OriginRampGroup
          });
        });
        this.createModel.originSuggession = listValues;
        console.log(this.createModel.originSuggession);
      }
    });
  }

  // Search From
  onShowData(event): void {
    if (this.createModel.searchForm.controls.originRampGroup.valid && this.createModel.searchForm.controls.destinationRampGroup.valid) {
      const searchTypeaheadParams: object = {
        'origin': event.value.originRampGroup.id,
        'destination': event.value.destinationRampGroup.id
      };
      this.createModel.searchParam = this.query.getSearchValue(searchTypeaheadParams);
      this.service.getOriginValue(this.createModel.searchParam).then(data => {
        console.log(data);
      });
    } else {
      this.createModel.validFormOrigin = !this.createModel.searchForm.controls.originRampGroup.valid;
      this.createModel.validFormDestination = !this.createModel.searchForm.controls.destinationRampGroup.valid;
    }
  }

}
