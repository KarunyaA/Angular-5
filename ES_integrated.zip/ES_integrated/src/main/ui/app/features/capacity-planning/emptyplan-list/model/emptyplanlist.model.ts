export class EmptyplanlistModel {

}
