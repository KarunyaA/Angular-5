import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { JBHGlobals } from '../../../../app.service';

@Injectable()
export class EmptyplanCreateService {

  constructor(private jbhGlobals: JBHGlobals, private http: HttpClient) { }

  getOriginValue(query): any {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const url = this.jbhGlobals.endpoints.capacityPlanning.getOrigin;
    return this.http.post<any>(url, query)
      .toPromise()
      .then(data => {
        return data;
      });
  }

}
