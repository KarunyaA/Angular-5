import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HeaderModule } from 'app/core/header/header.module';
import { AsideModule } from 'app/core/aside/aside.module';

@NgModule({
  imports: [
    CommonModule
  ],
  exports: [
    AsideModule,
    HeaderModule
  ]
})
export class CoreModule { }
