import { Component, EventEmitter, Input, OnInit, Output} from '@angular/core';

@Component({
  selector: 'app-aside',
  templateUrl: './aside.component.html',
  styleUrls: ['./aside.component.scss']
})
export class AsideComponent {

  @Input() isOpen: boolean;
  @Input() isLocked: boolean;
  @Input() isChanging: boolean;
  @Output() asideToggleLock: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Output() asideToggleOpen: EventEmitter<boolean> = new EventEmitter<boolean>();

  showAppDrawer = false;

  constructor() {}

  onToggleSidebarLeft(): void {
    if (!this.isChanging) {
      if (!this.isLocked) {
        this.asideToggleOpen.emit(!this.isOpen);
      }
    }
    if (!this.isOpen) {
      this.showAppDrawer = false;
    }
  }

  onLockSidebarLeft(): void {
    this.asideToggleLock.emit(!this.isLocked);
  }

  getSidebarLockIcon(): any {
    return this.isLocked ? 'icon-Icon_Password' : 'icon-Icon_Circle_Empty';
  }

  isSidebarLocked() {
    return this.isLocked ? 'router-container sidebar-locked' : 'router-container';
  }

  onToggleAppDrawer(): void {
    this.showAppDrawer = !this.showAppDrawer;
  }
}
