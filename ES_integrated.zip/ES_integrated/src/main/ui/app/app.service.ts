import { Injectable } from '@angular/core';

import { MessageService } from 'primeng/components/common/messageservice';
import * as _ from 'lodash';

import { ApiClientService } from './shared/jbh-app-services/api-client.service';
import { LoggerService } from './shared/jbh-app-services/logger.service';
import { ShortcutkeyService } from './shared/jbh-app-services/shortcutkey.service';
import { AppSharedDataService } from './shared/jbh-app-services/app-shared-data.service';
import { MouseEventService } from './shared/jbh-app-services/mouseevent.service';
import { LocalStorageService } from './shared/jbh-app-services/local-storage.service';

import { AppConfig } from '../config/app.config';
import { AppLocalConfig } from '../config/app.local.config';
import { environment } from '../environments/environment';

@Injectable()
export class JBHGlobals {

    endpoints: any;
    apiService: ApiClientService;
    logger: LoggerService;
    notifications: MessageService;
    shortkeys: any;
    settings: any;
    commonDataService: any;
    utils: any;
    userDetails: any;
    mouseevents: any;
    environment: any;
    localStore: any;


    constructor(
        private apiClientService: ApiClientService,
        private log4js: LoggerService,
        private ns: MessageService,
        private shortcutkeyService: ShortcutkeyService,
        private appSharedDataService: AppSharedDataService,
        private localStorageService: LocalStorageService,
        private mouseevent: MouseEventService
    ) {
        const appConfig = (environment.envName === 'local') ? AppLocalConfig.getConfig() : AppConfig.getConfig();
        let logLevel = appConfig.system.logLevel;
        this.endpoints = appConfig.api;
        this.apiService = apiClientService;
        this.logger = log4js;
        this.notifications = ns;
        this.settings = appConfig.settings;
        this.utils = _;
        this.shortkeys = shortcutkeyService;
        this.commonDataService = appSharedDataService;
        this.localStore = localStorageService;
        this.mouseevents = mouseevent;
        this.environment = environment;
        if (this.environment.production) {
            logLevel = 0;
        }
        this.logger.init(Number(logLevel));
    }
}
