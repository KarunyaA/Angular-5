import { ErrorHandler, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ErrorHandlerService } from './error-handler.service';

@NgModule({
    declarations: [],
    exports: [],
    imports: [],
    providers: [
        { provide: ErrorHandler, useClass: ErrorHandlerService }
    ]
})
export class ErrorHandlerModule { }
