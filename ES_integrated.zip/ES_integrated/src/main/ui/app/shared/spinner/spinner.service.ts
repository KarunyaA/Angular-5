import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Observer } from 'rxjs/Observer';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/share';
@Injectable()
export class SpinnerService {
  private spinnerObserver: Observer<boolean>;
  spinnerObservable: Observable<boolean>;
  spinnerText: string;
  showStatus = false;

  constructor() {
    this.spinnerObservable = new Observable<boolean>(observer => {
      this.spinnerObserver = observer;
      this.spinnerText = 'Loading Page Components ...';
    }
    ).share();
  }

  show() {
    this.showStatus = true;
    if (this.spinnerObserver) {
      this.spinnerObserver.next(true);
    }
  }

  hide() {
    this.showStatus = false;
    if (this.spinnerObserver) {
      this.spinnerObserver.next(false);
    }
  }
}
