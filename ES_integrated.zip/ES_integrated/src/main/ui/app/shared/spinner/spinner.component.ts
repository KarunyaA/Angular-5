import { Component, ElementRef, Input, OnDestroy, OnInit } from '@angular/core';
import { SpinnerService } from './spinner.service';
import { Subscription } from 'rxjs/Subscription';

declare var Spinner: any;

@Component({
  selector: 'app-spinner',
  templateUrl: './spinner.component.html',
  styleUrls: ['./spinner.scss']
})

export class SpinnerComponent implements OnInit, OnDestroy {

  private spinner: any;
  show = false;
  private element: any = null;
  private subscription: Subscription = null;

  @Input() lines = 12; // The number of lines to draw
  @Input() length = 13; // The length of each line
  @Input() width = 12; // The line thickness
  @Input() radius = 26; // The radius of the inner circle
  @Input() scale = 0.50; // Scales overall size of the spinner
  @Input() corners = 0.1; // Corner roundness (0..1)
  @Input() color = '#000'; // #rgb or #rrggbb or array of colors
  @Input() opacity = 0.40; // Opacity of the lines
  @Input() rotate = 0; // The rotation offset
  @Input() direction = 1; // 1: clockwise, -1: counterclockwise
  @Input() speed = 0.8; // Rounds per second
  @Input() trail = 60; // Afterglow percentage
  @Input() fps = 20; // Frames per second when using setTimeout() as a fallback for CSS
  @Input() className = 'spinner'; // The CSS class to assign to the spinner
  @Input() top = '60%'; // Top position relative to parent
  @Input() left = '50%'; // Left position relative to parent
  @Input() shadow = false; // Whether to render a shadow
  @Input() hwaccel = true; // Whether to use hardware acceleration
  @Input() position = 'absolute'; // Element positioning

  constructor(private spinnerElement: ElementRef,
              private spinnerService: SpinnerService) {
    this.element = spinnerElement.nativeElement;
  }

  ngOnInit() {
    this.initSpinner();
    this.createServiceSubscription();
    this.createSpinnerTextDiv();
    this.createBackdrop();
  }

  private initSpinner() {
    const options = {
      lines: this.lines,
      length: this.length,
      width: this.width,
      radius: this.radius,
      scale: this.scale,
      corners: this.corners,
      color: this.color,
      opacity: this.opacity,
      rotate: this.rotate,
      direction: this.direction,
      speed: this.speed,
      trail: this.trail,
      fps: this.fps,
      zIndex: 2e9, // Artificially high z-index to keep on top
      className: this.className,
      top: this.top,
      left: this.left,
      shadow: this.shadow,
      hwaccel: this.hwaccel,
      position: this.position
    };
    console.log('Creating spinner with options:');
    console.log(JSON.stringify((options)));
    this.spinner = new Spinner(options);
  }

  private createServiceSubscription() {
    this.subscription = this.spinnerService.spinnerObservable.subscribe(show => {
      if (show) {
        this.startSpinner();
      } else {
        this.stopSpinner();
      }
    });
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  startSpinner() {
    this.show = true;
    this.spinner.spin(this.element.firstChild);
    this.disableScreen();
  }

  stopSpinner() {
    this.show = false;
    this.spinner.stop();
    this.activateScreen();
  }

  createBackdrop() {
    const div = document.createElement('div');
    div.id = 'backdrop';
    div.className = 'overlay-spinner-background';
    document.body.appendChild(div);
    this.activateScreen();
  }

  createSpinnerTextDiv() {
    const div = document.createElement('div');
    div.id = 'spinnerText';
    div.className = 'spinner-status-text';
    document.body.appendChild(div);
  }

  disableScreen() {
    const div = document.getElementById('backdrop');
    const textDiv = document.getElementById('spinnerText');
    textDiv.innerHTML = this.spinnerService.spinnerText;
    textDiv.style.display = 'block';
    div.style.display = 'block';
  }

  activateScreen() {
    const div = document.getElementById('backdrop');
    const textDiv = document.getElementById('spinnerText');
    textDiv.style.display = 'none';
    div.style.display = 'none';
  }
}
