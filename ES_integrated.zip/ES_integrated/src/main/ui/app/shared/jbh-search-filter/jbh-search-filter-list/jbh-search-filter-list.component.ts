import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-jbh-search-filter-list',
  templateUrl: './jbh-search-filter-list.component.html',
  styleUrls: ['./jbh-search-filter-list.component.scss']
})
export class JbhSearchFilterListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
