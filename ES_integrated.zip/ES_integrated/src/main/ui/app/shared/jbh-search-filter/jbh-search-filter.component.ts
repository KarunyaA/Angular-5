import {
    Component,
    EventEmitter,
    Input,
    Output,
    ViewChild,
    ViewChildren
} from '@angular/core';

@Component({
    selector: 'app-jbh-search-filter',
    templateUrl: './jbh-search-filter.component.html',
    styleUrls: ['./jbh-search-filter.component.scss']
})

export class JbhSearchFilterComponent {

    @ViewChild('filterPanel') filterBody;
    @ViewChildren('filterListCmp') filterCmps;
    @Input() filterList: any[];
    @Input() closeOthers: boolean;
    @Input() filterTitle: string;
    @Input() filterTabIndex: string;
    @Output() checkedEvent = new EventEmitter < any > ();
    @Output() searchEvent = new EventEmitter < any > ();
    @Output() clickEvent: EventEmitter < number > = new EventEmitter < number > ();
    @Output() typeaheadEvent = new EventEmitter < any > ();
    @Output() resetAllFields = new EventEmitter < any > ();

    constructor() {}

    changeEvent(object) {

        this.checkedEvent.emit(object);
    }

    searchCallOnClick(object) {
        this.searchEvent.emit(object);
    }
    /***************** OnReset Btn Click Reset all the checkbox ****************/
    resetCheckValue(eve) {
        //  this.count[eve] = '';
        this.clickEvent.emit(eve);
    }
    /***************** typeAhead search query  ****************/
    typeAheadSearchCall(eve) {
        this.typeaheadEvent.emit(eve);
    }
    checkedValues(event) {
        // this.dataList[event.index] = event.list;
    }
    onFilterResetAllClick(event): void {
        this.resetFilterValues();
        this.resetAllFields.emit();
    }
    resetFilterValues(): void {
        const parentNode = this.filterBody.nativeElement,
            searchInputFields = parentNode.querySelectorAll('#fltSearchTxt'),
            checkboxFields = parentNode.querySelectorAll('input[type=checkbox]');


        for (let i = 0; i < searchInputFields.length; i++) {
            searchInputFields[i].value = '';
        }
        for (let i = 0; i < checkboxFields.length; i++) {

            checkboxFields[i].binary = false;
            checkboxFields[i].checked = false;
            // debugger;
        }
    }
    resetFilter(): void {
        this.filterList.forEach(listItem => {
            if (listItem.searchValue) {
                listItem.searchValue = '';
            } else if (listItem.selectedValues) {
                listItem.selectedValues = [];
            }
            listItem.count = 0;
        });
        this.resetFilterValues();
    }

}
