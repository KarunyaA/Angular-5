import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { PanelModule } from 'primeng/panel';
import { AccordionModule } from 'primeng/accordion';
import { CheckboxModule } from 'primeng/checkbox';
import { RadioButtonModule } from 'primeng/radiobutton';

import { JbhSearchFilterComponent } from './jbh-search-filter.component';
import { JbhSearchFilterListComponent } from './jbh-search-filter-list/jbh-search-filter-list.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    PanelModule,
    CheckboxModule,
    RadioButtonModule,
    AccordionModule,
  ],
  declarations: [
    JbhSearchFilterComponent,
    JbhSearchFilterListComponent
  ],
  exports: [
    JbhSearchFilterComponent,
    JbhSearchFilterListComponent
  ]
})
export class JbhSearchFilterModule { }
