/* tslint:disable:max-line-length */
export class AppConfig {
    static getConfig() {
        return {
            'system': {
                'applicationName': 'Opex',
                'appId': 'opex',
                'logLevel': 4
            },
            'api': {
                'inboundlimits': {
                   'getinboundlocations': '/loads/capacity-inbound-location/location/_search',
                   'getinboundareas': '/loads/capacity-inbound-area/area/_search',
                   'saveinboundlimits': '/loads/capacityinboundlimits/inboundcapacitylimits',
                   'inboundlocation': '/loads/masterdata-location-details/location_info/_search',
                   'capacityarea': '/loads/masterdatageographyservices/areas/search/findbycapacityareaandbusinessunit',
                    'serviceofferring': '/loads/referencedataservices/serviceOfferingBusinessUnitTransitModeAssociations/search/findByFinanceBusinessUnitServiceOfferingAssociationFinanceBusinessUnitCode',
                    'fleettype': '/loads/referencedataservices/serviceOfferingBusinessUnitTransitModeAssociations/search/findByFinanceBusinessUnitServiceOfferingAssociationFinanceBusinessUnitCode'
                },
                'capacityPlanning': {
                    'getOrigin': '/loads/capacity-lanes/lane/_search'
                }
            },
            'settings': {
                'notificationsOptions': {
                    'timeOut': 5000,
                    'lastOnBottom': false,
                    'clickToClose': true,
                    'maxLength': 0,
                    'maxStack': 7,
                    'showProgressBar': false,
                    'pauseOnHover': true,
                    'preventDuplicates': false,
                    'preventLastDuplicates': 'visible',
                    'rtl': false,
                    'animate': 'fromLeft',
                    'position': ['top', 'right']
                },
                'debounce': 500
            }
        };
    }
}
