/* tslint:disable:max-line-length */
export class AppLocalConfig {
    static getConfig() {
        return {
            'system': {
                'applicationName': 'Opex',
                'appId': 'opex',
                'logLevel': 4
            },
            'api': {
                'inboundlimits': {
                    'getinboundlocations': '/capacity-inbound-location/location/_search',
                    'getinboundareas': '/capacity-inbound-area/area/_search',
                    'saveinboundlimits': '/capacityinboundlimits/inboundcapacitylimits',
                    'inboundlocation': '/masterdata-location-details/location_info/_search',
                    'capacityarea': '/masterdatageographyservices/areas/search/findbycapacityareaandbusinessunit',
                    'serviceofferring': '/referencedataservices/serviceOfferingBusinessUnitTransitModeAssociations/search/findByFinanceBusinessUnitServiceOfferingAssociationFinanceBusinessUnitCode',
                    'fleettype': '/referencedataservices/serviceOfferingBusinessUnitTransitModeAssociations/search/findByFinanceBusinessUnitServiceOfferingAssociationFinanceBusinessUnitCode'
                },
                'capacityPlanning': {
                    'getOrigin': '/test-capacity-lanes/lane/_search'
                }
            },
            'settings': {
                'notificationsOptions': {
                    'timeOut': 5000,
                    'lastOnBottom': false,
                    'clickToClose': true,
                    'maxLength': 0,
                    'maxStack': 7,
                    'showProgressBar': false,
                    'pauseOnHover': true,
                    'preventDuplicates': false,
                    'preventLastDuplicates': 'visible',
                    'rtl': false,
                    'animate': 'fromLeft',
                    'position': ['top', 'right']
                },
                'debounce': 500
            }
        };
    }
}
