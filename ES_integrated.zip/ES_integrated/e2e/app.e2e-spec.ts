import { AppPage } from './app.po';

describe('app-operationsexecution-loads App', () => {
  let page: AppPage;

  beforeEach(() => {
    page = new AppPage();
  });

  xit('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('WELCOME TO APP!');
  });
});
