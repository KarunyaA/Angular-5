import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { IMyOptions } from 'mydatepicker';
import * as moment from 'moment';

import { ApiClientService } from './../../jbh-core-services/api-client.service';

interface IFilterDetail {
    index: any;
    title: any;
    key: any;
    rootVal: any;
    componentType: any;
    url: any;
}
@Component({
    selector: 'jbh-search-filter-list',
    templateUrl: './jbh-search-filter-list.component.html',
    styleUrls: ['./jbh-search-filter-list.component.scss']
})

export class JbhSearchFilterListComponent implements OnInit {

    /***************** Variable Declaration ****************/
    @ViewChild('searchInput') searchInput: any;
    @ViewChild('containerdiv') containerdiv: any;
    @Input() filterDetail: IFilterDetail;
    @Input() filterTitleDetail: Object;
    @Input() filterListTabIndex: string;
    @Input() isDateRangeFlag: string;
    @Input() timePickerFlag: boolean;
    @Input()
    set clickResetAllEvent(prop: number) {
        this.resetFunction(this.dataList);
    }

    @Output() checkedEvent = new EventEmitter<any>();
    @Output() clickEvent: EventEmitter<number> = new EventEmitter<number>();
    @Output() searchEvent = new EventEmitter<any>();
    @Output() typeaheadEvent = new EventEmitter<any>();
    @Output() DatechangedEvent = new EventEmitter<any>();
    @Output() TimepickerchangedEvent = new EventEmitter<any>();
    @Output() keyEnterEvent = new EventEmitter<any>();
    @Output() freetextChangedEvent = new EventEmitter<any>();
    @ViewChild('totime') totime;
    @ViewChild('fromtime') fromtime;
    @ViewChild('todate') todate;
    selectedListOnCheck: Array<Object> = [];
    toTimedisable = true;
    fromTimedisable = true;
    myStartTime: any;
    myEndTime: any;
    apptStartTime: any;
    apptEndTime: any;
    startTimeMeridian: any;
    endTimeMeridian: any;
    inputRequired = false;
    fromNumValue: any;
    toNumValue: any;
    numCheckFlag: boolean;
    dttodate: any = '';
    typeAheadVal: any;
    selectedList: Array<Object> = [];

    // variables and datepicker options changes for CCI_UI
    dtfromdate: any = '';
    invalidFromDate: boolean;
    invalidToDate: boolean;

    myDatePickerOptions: IMyOptions = {
        showTodayBtn: true,
        todayBtnTxt: 'Today',
        indicateInvalidDate: false,
        dateFormat: 'mm/dd/yyyy',
        firstDayOfWeek: 'su',
        showClearDateBtn: false,
        editableDateField: true,
        sunHighlight: false,
        height: '34px',
        width: '120px',
        inline: false,
        // selectorHeight: '320px',
        selectionTxtFontSize: '12px',
        dayLabels: { su: 'S', mo: 'M', tu: 'T', we: 'W', th: 'T', fr: 'F', sa: 'S' },
        monthLabels: {
            1: 'January', 2: 'February', 3: 'March', 4: 'April', 5: 'May', 6: 'June',
            7: 'July', 8: 'August', 9: 'September', 10: 'October', 11: 'November', 12: 'December'
        },
        markCurrentDay: true
    };
    myDatePickerOptionsTodate: IMyOptions = {
        showTodayBtn: true,
        todayBtnTxt: 'Today',
        indicateInvalidDate: false,
        dateFormat: 'mm/dd/yyyy',
        firstDayOfWeek: 'su',
        showClearDateBtn: false,
        editableDateField: true,
        sunHighlight: false,
        height: '34px',
        width: '120px',
        inline: false,
        // selectorHeight: '320px',
        selectionTxtFontSize: '12px',
        dayLabels: { su: 'S', mo: 'M', tu: 'T', we: 'W', th: 'T', fr: 'F', sa: 'S' },
        monthLabels: {
            1: 'January', 2: 'February', 3: 'March', 4: 'April', 5: 'May', 6: 'June',
            7: 'July', 8: 'August', 9: 'September', 10: 'October', 11: 'November', 12: 'December'
        },
        markCurrentDay: true
        // todayBtnTxt: 'Today',
        // dateFormat: 'dd-mm-yyyy',
        // firstDayOfWeek: 'mo',
        // showClearDateBtn: false,
        // sunHighlight: true,
        // height: '34px',
        // width: '115px',
        // inline: false,
        // //  disableUntil: { year: this.currentYear, month: this.currentMonth, day: this.currentDay },
        // selectionTxtFontSize: '14px'
    };
    dataList: Array<Object> = [];
    dataCopyList: Object[];
    count = 0;
    countPage = 0;
    sizeLimit = 0;
    listExist = true;
    hideTypeAhead = true;
    filterListSearchTabIndex: any;
    filterListItemTabIndex: any;
    filterListResetTabIndex: any;

    fromDateOptions: IMyOptions = this.getCopyOfOptions();
    toDateOptions: IMyOptions = this.getCopyOfOptions();

    ratingList: Array<Object> = [{
        'val': 'Recommended(1-3)',
        'fullVal': 4
    }, {
        'val': 'Fair (4-7)',
        'fullVal': 8
    }, {
        'val': 'Not Recommended (8-10)',
        'fullVal': 11
    }, {
        'val': 'Do Not Use (13)',
        'fullVal': 13
    }, {
        'val': 'Missing Data (99)',
        'fullVal': 99
    }];

    /***************** System Provided Methods ****************/
    constructor(private apiService: ApiClientService) {

    }

    ngOnInit() {
        this.filterListSearchTabIndex = parseInt(this.filterListTabIndex, 10) + 0.1;
        this.filterListItemTabIndex = parseInt(this.filterListTabIndex, 10) + 0.2;
        this.filterListResetTabIndex = parseInt(this.filterListTabIndex, 10) + 0.3;
        this.hideTypeAhead = !this.filterDetail['hideTypeAhead'];
        this.serviceCall(this.filterDetail, this.filterDetail['params']);
        this.myStartTime = this.setInitialTime();
        this.myEndTime = this.setInitialTime();
        this.apptStartTime = moment(this.myStartTime).format('HH:mm');
        this.apptEndTime = moment(this.myEndTime).format('HH:mm');
        this.numCheckFlag = false;
    }

    /***************** Custom Methods ****************/

    /***************** Oncheck event emiting to parent ****************/
    changeEvent(eve, Obj) {
        if (this.filterDetail['count'] !== 0) {
            this.count = this.filterDetail['count'];
        }
        if (Obj.checked) {
            this.count++;
        } else {
            this.count--;
        }
        if (this.filterDetail['serviceFilter']) {
            if (Obj.checked) {
                this.selectedListOnCheck.push(Obj);
            } else {
                const index = this.findIndex(this.selectedListOnCheck, Obj, 'val');
                if (index !== -1) {
                    this.selectedListOnCheck.splice(index, 1);
                }
            }
        }
        const object = {
            'num': eve,
            'data': Obj,
            'count': this.count
        };
        this.checkedEvent.emit(object);
    }

    findIndex(arrList, selectObj, keyVal) {
        if (selectObj && arrList && arrList.length > 0) {
            const objFromList = arrList.find(x =>
                x[keyVal] === selectObj[keyVal]);
            return arrList.indexOf(objFromList);
        }
        return -1;
    }
    scrollEvent(eve) {
        if (this.containerdiv && this.containerdiv.elementRef.nativeElement.scrollHeight -
            this.containerdiv.elementRef.nativeElement.scrollTop === this.containerdiv.elementRef.nativeElement.clientHeight &&
            this.filterDetail['pagination'] && this.sizeLimit > this.dataList.length) {
            this.countPage++;
            // this.filterDetail['params']['page'] = this.countPage;
            this.paramsCreation(this.filterDetail['params'], this.countPage);
            this.serviceCall(this.filterDetail, this.filterDetail['params']);
        }
    }

    isIE() {
        const myNav = navigator.userAgent.toLowerCase();
        return (myNav.indexOf('msie') !== -1) ? parseInt(myNav.split('msie')[1], 10) : false;
    }

    paramsCreation(param, count) {
        if (param['page']) {
            this.filterDetail['params']['page'] = count;
        } else if (param['start'] !== undefined && param['end'] !== undefined) {
            this.filterDetail['params']['start'] = this.filterDetail['params']['end'] + 1;
            this.filterDetail['params']['end'] = this.filterDetail['params']['end'] + this.filterDetail['paginationSize'];
        } else if (param['from'] !== undefined && param['size']) {
            this.filterDetail['params']['from'] = count * param['size'];
        }
    }

    searchCallOnClick(eve, Index, searchField) {
        if (!searchField.value) {
            this.inputRequired = true;

        } else {
            this.inputRequired = false;

        }
        const me = this,
            object = {
                'event': eve,
                'num': Index,
                'data': searchField,
                'dataList': this.dataList,
                'setDatda': function (data) {
                    me.setDataList(data);
                }
            };
        this.searchEvent.emit(object);
    }

    /***************** Oncheck event emiting to parent ****************/
    resetCheckValue(eve) {
        if (eve === 13 && this.searchInput &&
            this.searchInput.nativeElement) {
            this.searchInput.nativeElement.checked = false;
        } else {
            this.resetFunction(this.dataList);
            if (this.searchInput && this.searchInput.nativeElement) {
                this.searchInput.nativeElement.value = '';
            }
        }
        this.count = 0;
        this.selectedListOnCheck = [];
        this.selectedList = [];
        this.listExist = true;
        this.inputRequired = false;
        this.filterDetail['noResult'] = false;
        this.dataList = this.dataCopyList ? this.dataCopyList : [];
        for (let i = 0; i < this.dataList.length; i++) {
            this.dataList[i]['checked'] = false;
        }
        if (this.filterDetail['SearchFilter'] && this.dataCopyList) {
            this.dataList = [];
        }
        this.clickEvent.emit(eve);
    }
    resetInput(eve) {

        const childNode = event.target['parentElement'].querySelectorAll('input');
        for (let i = 0; i < childNode.length; i++) {
            if (childNode[i].classList.contains('selection')) {
                childNode[i].value = '';
            }
        }
        this.count = 0;
        this.toTimedisable = true;
        this.fromTimedisable = true;
        this.endTimeMeridian = false;
        this.startTimeMeridian = false;
        this.myStartTime = this.setInitialTime();
        this.myEndTime = this.setInitialTime();
        this.apptStartTime = moment(this.myStartTime).format('HH:mm');
        this.apptEndTime = moment(this.myEndTime).format('HH:mm');

        // CCI_UI changes for resetting the calender view and input value
        const dateField = event.target['parentElement'].querySelectorAll('my-date-picker');
        if (dateField) {
            this.dtfromdate = null;
            this.dttodate = null;
            this.invalidFromDate = false;
            this.invalidToDate = false;
            const fromCopy = this.getCopyOfOptions();
            fromCopy.disableSince = { day: 0, year: 0, month: 0 };
            this.fromDateOptions = fromCopy;
            const toCopy = this.getCopyOfOptions();
            toCopy.disableUntil = { day: 0, year: 0, month: 0 };
            this.toDateOptions = toCopy;
        }

        this.clickEvent.emit(eve);
    }
    resetFunction(arr) {
        const length = arr.length;
        for (let i = 0; i < length; i++) {
            arr[i].checked = false;
        }
    }

    /***************** Service call for CheckBox On Init ****************/
    serviceCall(cmp, params) {
        if (cmp && cmp.url && cmp.componentType !== 'typeAhead' && cmp.SearchFilter !== true) {
            const me = this;
            let methodType = 'getData';
            if (cmp.methodType) {
                methodType = cmp.methodType;
            }
            me.apiService[methodType](cmp.url, params).subscribe(data => {
                if (data) {
                    const dataList = this.rootFormater(cmp.rootVal, data);
                    for (let i = 0; i < dataList['length']; i++) {
                        if (!cmp.key.includes('opportunity') && (!cmp.key.includes('admin'))) {
                            this.dataList.push(this.dataFormatter(dataList[i], cmp.title, data));
                        } else if (cmp.key.includes('admin')) {
                            this.dataList.push(this.dataFormatterAdmin(dataList[i], cmp.title, data));
                        } else {
                            this.dataList.push(this.dataFormatterOpportunity(dataList[i], cmp, data));
                        }
                    }
                    this.validateTotalLsit(me.dataList, me.selectedListOnCheck);
                    this.dataCopyList = me.dataList;
                }
                this.listExist = (this.dataList.length > 0);
            });
        } else if (cmp && cmp.data) {
            this.dataList = cmp.data;
            this.dataCopyList = this.dataList;
            this.listExist = (this.dataList.length > 0);
        }

    }

    // CCI_UI change to create the copy of date picker options
    getCopyOfOptions(): IMyOptions {
        return JSON.parse(JSON.stringify(this.myDatePickerOptions));
    }

    // CCI_UI changes for the input field of date picker to be editable in filter panel
    onInputFieldChanged(eve, type) {
        if (type === 'from') {
            this.invalidFromDate = eve.valid ? false : (eve.value !== '' ? true : false);
        } else {
            this.invalidToDate = eve.valid ? false : (eve.value !== '' ? true : false);
        }
    }

    rootFormater(arr, data) {
        const leng = arr.length;
        switch (leng) {
            case 1:
                return data[arr[0]];
            case 2:
                return data[arr[0]][arr[1]];
            case 3:
                return data[arr[0]][arr[1]][arr[2]];
            case 4:
                return data[arr[0]][arr[1]][arr[2]][arr[3]];
            case 5:
                return data[arr[0]][arr[1]][arr[2]][arr[3]][arr[4]];
            default:
                return data;
        }
    }

    /***************** Service JSON formatter ****************/

    dataFormatter(dataObj, list, fulldata) {
        let obj = {
            checked: false,
            val: null
        };
        if (this.filterDetail['checkSelectionKey'] && !this.filterDetail['deepNestFlag'] &&
            !this.filterDetail['framerMethod']) {
            obj.val = dataObj[this.filterDetail['checkSelectionKey']];
            obj['fullVal'] = dataObj;
            if (this.filterDetail['activeStatus'] && obj.val === this.filterDetail['statusKey']) {
                obj.checked = true;
            }
            this.sizeLimit = (fulldata['totalRecords']) ? fulldata['totalRecords'] : 8000;
            return obj;
        }
        if (this.filterDetail['framerMethod'] && this.filterDetail['myParentScope']) {
            const FramedVal = this.filterDetail['myParentScope'][this.filterDetail['framerMethod']];
            this.sizeLimit = (fulldata['totalRecords']) ? fulldata['totalRecords'] : 8000;
            return FramedVal(dataObj);
        }
        switch (list) {

            case 'Business Unit':
                obj.val = dataObj['financeBusinessUnitServiceOfferingAssociation']['financeBusinessUnitCode'];
                obj['fullVal'] = dataObj['financeBusinessUnitServiceOfferingAssociation'];
                break;
            case 'Template Status':
            /* For Commitments */
            case 'Corporate Account':
            case 'Bill to Account':
            case 'Origin':
            case 'Destination':
            case 'Shipper Location':
            case 'Type':
            case 'Schedule':
            case 'Status':
            case 'Sales Person':
            case 'Operations Team Leader':
            case 'Order Owner':
            case 'Pricing Identifier':
                obj.val = dataObj['val'];
                obj['fullVal'] = dataObj;
                break;
            default:
                obj = {
                    checked: false,
                    val: null
                };
        }
        return obj;
    }

    dataFormatterOpportunity(dataObj, list, fulldata) {
        let obj = {
            checked: false,
            val: null
        };
        // this.sizeLimit = (fulldata['totalRecords']) ? fulldata['totalRecords'] : 8000;
        switch (list.title) {
            // case 'Order Number':
            //     obj.val = dataObj;
            //     obj['fullVal'] = dataObj;
            //     this.sizeLimit = fulldata['totalRecords'];
            //     break;
            case 'Opportunity Creator':
                obj.val = dataObj['_source']['firstName'] + ' ' + dataObj['_source']['lastName'] + '(' + dataObj['_source']['emplid'] + ')';
                obj['fullVal'] = dataObj['_source']['firstName'];
                this.sizeLimit = fulldata['totalRecords'];
                break;
            case 'Origin':
                obj.val = dataObj['key'] + ',' + dataObj['topacc_hits']['hits']['hits'][0]['_source']['locations']['StateCode'];
                obj['fullVal'] = dataObj['key'];
                this.sizeLimit = fulldata['totalRecords'];
                // obj.val = dataObj['addressDTO']['city'] + ', ' + dataObj['addressDTO']['state'];
                // obj['fullVal'] = dataObj['addressDTO']['city'];
                // this.sizeLimit = fulldata['totalRecords'];
                break;
            case 'Destination':
                obj.val = dataObj['key'] + ',' + dataObj['topacc_hits']['hits']['hits'][0]['_source']['locations']['StateCode'];
                obj['fullVal'] = dataObj['key'];
                this.sizeLimit = fulldata['totalRecords'];
                // obj.val = dataObj['addressDTO']['city'] + ', ' + dataObj['addressDTO']['state'];
                // obj['fullVal'] = dataObj['addressDTO']['city'];
                // this.sizeLimit = fulldata['totalRecords'];
                break;
            case 'Bill To Account':
                const billValue = dataObj['_source']['CustomerCode'] == null ?
                    dataObj['_source']['OrganizationName'] : dataObj['_source']['OrganizationName']
                    + '(' + dataObj['_source']['CustomerCode']
                    + ')';
                obj.val = billValue;
                obj['fullVal'] = dataObj['_source']['OrganizationName'];
                this.sizeLimit = 5000;
                break;
            case 'Order Number':
                obj.val = dataObj['key'];
                obj['fullVal'] = dataObj['key'];
                this.sizeLimit = 5000;
                break;

            case 'Status':
                                if (list.key.split('-')[1] === 'opportunityStatusCode.keyword') {
                    if (list.preselection.length > 0) {
                        if (list.preselection.indexOf(dataObj['opportunityStatusCode']) !== -1) {
                            obj.checked = true;
                        }
                    }

                    obj.val = dataObj['opportunityStatusCode'];
                    // if (dataObj['opportunityStatusCode'].toLowerCase().slice(0, 8) === 'condacce') {
                    //     obj['fullVal'] = 'Conditio';
                    // } else {
                        obj['fullVal'] = dataObj['opportunityStatusCode'];
                  //  }

                    this.sizeLimit = fulldata['totalRecords'];
                } else {
                    if (list.preselection.length > 0) {
                        if (list.preselection.indexOf(dataObj['opportunityPostingStatusCode']) !== -1) {
                            obj.checked = true;
                        }
                    }

                    obj.val = dataObj['opportunityPostingStatusCode'];
                    // if (dataObj['opportunityPostingStatusCode'].toLowerCase().slice(0, 8) === 'condacce') {
                    //     obj['fullVal'] = 'Conditio';
                    // } else {
                        obj['fullVal'] = dataObj['opportunityPostingStatusCode'];
                   // }

                    this.sizeLimit = fulldata['totalRecords'];
                }
                break;

            case 'Order Owner':
                obj.val = dataObj['_source']['firstName'] + ' ' + dataObj['_source']['lastName'] + '(' + dataObj['_source']['emplid'] + ')';
                obj['fullVal'] = dataObj['_source']['firstName'];
                this.sizeLimit = fulldata['totalRecords'];
                break;
            default:
                obj = {
                    checked: false,
                    val: null
                };

        }
        return obj;
    }
    dataFormatterAdmin(dataObj, list, fulldata) {
        let obj = {
            checked: false,
            val: null
        };
        switch (list) {
            case 'Subscribed User (External)':
                if (dataObj['key'] !== undefined && dataObj['subscribedPersonLastName']['buckets'].length > 0
                    && dataObj['subscribedPersonLastName']['buckets'][0]['key'] !== undefined
                    && dataObj['subscribedPersonLastName']['buckets'][0]['key'] !== null
                    && dataObj['subscribedPersonLastName']['buckets'][0]['key'] !== '') {
                    obj.val = dataObj['key'] + ' ' + dataObj['subscribedPersonLastName']['buckets'][0]['key'];
                    obj['fullVal'] = dataObj['key'];
                } else {
                    obj.val = dataObj['key'];
                    obj['fullVal'] = dataObj['key'];
                }
                break;
            case 'Subscribed User (Internal)':
                if (dataObj['key'] !== undefined && dataObj['subscribedPersonLastName']['buckets'].length > 0
                    && dataObj['subscribedPersonLastName']['buckets'][0]['key'] !== undefined
                    && dataObj['subscribedPersonLastName']['buckets'][0]['key'] !== null
                    && dataObj['subscribedPersonLastName']['buckets'][0]['key'] !== '') {
                    obj.val = dataObj['key'] + ' ' + dataObj['subscribedPersonLastName']['buckets'][0]['key'];
                    obj['fullVal'] = dataObj['key'];
                } else {
                    obj.val = dataObj['key'];
                    obj['fullVal'] = dataObj['key'];
                }
                break;
            case 'Created By':
                if (dataObj['key'] !== undefined && dataObj['createdByLastName']['buckets'].length > 0
                    && dataObj['createdByLastName']['buckets'][0]['key'] !== undefined
                    && dataObj['createdByLastName']['buckets'][0]['key'] !== null
                    && dataObj['createdByLastName']['buckets'][0]['key'] !== '') {
                    obj.val = dataObj['key'] + ' ' + dataObj['createdByLastName']['buckets'][0]['key'];
                    obj['fullVal'] = dataObj;
                } else {
                    obj.val = dataObj['key'];
                    obj['fullVal'] = dataObj;
                }
                break;
            case 'Last Updated By':
                if (dataObj['key'] !== undefined && dataObj['lastUpdatedByLastName']['buckets'].length > 0
                    && dataObj['lastUpdatedByLastName']['buckets'][0]['key'] !== undefined
                    && dataObj['lastUpdatedByLastName']['buckets'][0]['key'] !== null
                    && dataObj['lastUpdatedByLastName']['buckets'][0]['key'] !== '') {
                    obj.val = dataObj['key'] + ' ' + dataObj['lastUpdatedByLastName']['buckets'][0]['key'];
                    obj['fullVal'] = dataObj;
                } else {
                    obj.val = dataObj['key'];
                    obj['fullVal'] = dataObj;
                }
                break;
            case 'Status':
                obj.val = dataObj;
                obj['fullVal'] = { [this.filterDetail['checkSelectionKey']]: dataObj };
                break;
            case 'Trading Partner':
                if (dataObj['key'] !== undefined && dataObj['key'] !== null && dataObj['key'] !== '') {
                    obj.val = dataObj['key'];
                    obj['fullVal'] = dataObj;
                } else {
                    obj.val = null;
                    obj['fullVal'] = null;
                }
                break;
            case 'Bill to Account':
                if (dataObj['key'] !== undefined && dataObj['key'] !== null && dataObj['key'] !== '') {
                    obj.val = dataObj['key'];
                    obj['fullVal'] = dataObj;
                } else {
                    obj.val = null;
                    obj['fullVal'] = null;
                }
                break;
            case 'National Account':
                if (dataObj['key'] !== undefined && dataObj['key'] !== null && dataObj['key'] !== '') {
                    obj.val = dataObj['key'];
                    obj['fullVal'] = dataObj;
                } else {
                    obj.val = null;
                    obj['fullVal'] = null;
                }
                break;
            default:
                obj = {
                    checked: false,
                    val: null
                };
        }
        return obj;
    }
    queryFilterList(eve, index) {
        if (!this.filterDetail['serviceFilter'] && this.dataCopyList && !this.filterDetail['SearchFilter']) {
            const val = eve.target.value;
            this.dataList = this.transform(this.dataCopyList, val);
        }
        const me = this,
            object = {
                'event': eve,
                'num': index,
                'val': eve.target.value,
                'data': this.dataList,
                'setDatda': function (data) {
                    me.setDataList(data);
                }
                //            'temp': me.setDataList([])
            };
        if (eve.code === 'Enter' || eve.code === 'NumpadEnter') {
            this.keyEnterEvent.emit(object);
        }
        this.typeaheadEvent.emit(object);
    }
    datechange(eve, type, index) {
        if (type === 'from') {
            this.fromTimedisable = false;
            this.toTimedisable = false;
            // this.fromtime.nativeElement.disabled = false;
            // this.fromtime.nativeElement.value = '00:00';
            // this.totime.nativeElement.value = '00:00';
            // this.totime.nativeElement.disabled = false;
            const ptoday = new Date(eve.jsdate);
            let pday;
            if (ptoday.getDate() === 1) {
                pday = ptoday.setHours(-1);
                pday = ptoday.getDate();
            } else {
                pday = ptoday.getDate() - 1;
            };
            const pyear = ptoday.getFullYear();
            const pmonth = ptoday.getMonth() + 1;
            const myDatePickerOptionsLocal: IMyOptions = {
                todayBtnTxt: 'Today',
                dateFormat: 'dd-mm-yyyy',
                firstDayOfWeek: 'mo',
                showClearDateBtn: false,
                editableDateField: false,
                sunHighlight: true,
                height: '34px',
                inline: false,
                disableUntil: { year: pyear, month: pmonth, day: pday },
                selectionTxtFontSize: '14px'
            };

            this.myDatePickerOptionsTodate = myDatePickerOptionsLocal;
            if (this.isDateRangeFlag !== undefined) {
                this.dttodate = eve;
            }
        } else {
            this.toTimedisable = false;
            // this.totime.nativeElement.disabled = false;
            // this.totime.nativeElement.value = '00:00';
        }
        // this.totime.nativeElement.disabled=true;
        eve.types = {};
        eve.types = type;
        eve.num = index;

        // CCI_UI changes to disable dates based on the selected date in the calendarview
        if (eve.types === 'from') {
            this.dtfromdate = eve.formatted;
            const copy = this.getCopyOfOptions();
            copy.disableUntil = eve.date;
            this.toDateOptions = copy;
        } else if (eve.types === 'to') {
            this.dttodate = eve;
            const copy = this.getCopyOfOptions();
            copy.disableSince = eve.date;
            this.fromDateOptions = copy;
        }

        this.DatechangedEvent.emit(eve);
    }
    timechanged(eve, type, index) {
        if (type === 'from') {
            this.startTimeMeridian = true;
            this.apptStartTime = moment(this.myStartTime).format('HH:mm');
            this.timeValidator(this.myStartTime, 'Start');
            eve.types = {};
            eve.time = {};
            eve.types = type;
            eve.num = index;
            eve.time = this.apptStartTime;
            this.TimepickerchangedEvent.emit(eve);
        } else {
            this.endTimeMeridian = true;
            this.apptEndTime = moment(this.myEndTime).format('HH:mm');
            this.timeValidator(this.myEndTime, 'End');
            eve.types = {};
            eve.types = type;
            eve.time = {};
            eve.time = this.apptEndTime;
            eve.num = index;
            this.TimepickerchangedEvent.emit(eve);
        }

    }
    timeValidator(time, key) {
        const hour = Number(moment(time).format('HH'));
        const minute = Number(moment(time).format('mm'));
        if ((hour === 0 && minute === 0)) {
            switch (key) {
                case 'Start':
                    this.myStartTime = this.setInitialTime();
                    break;
                case 'End':
                    this.myEndTime = this.setInitialTime();
                    break;
                default:
            }
        } else {
            this.conditonalValidator(time, key);
        }
    }
    conditonalValidator(myTime, key) {
        switch (key) {
            case 'Start':
                this.myStartTime = this.hoursMinsSetter(myTime);
                break;
            case 'End':
                this.myEndTime = this.hoursMinsSetter(myTime);
                break;
            default:
        }
    }
    hoursMinsSetter(time) {
        let hour = Number(moment(time).format('HH'));
        let minute = Number(moment(time).format('mm'));
        hour = hour !== 0 ? hour : 0;
        minute = minute !== 0 ? minute : 0;
        const setTime = new Date();
        setTime.setHours(hour);
        setTime.setMinutes(minute);
        return setTime;
    }
    setInitialTime() {
        const initialTime = new Date();
        initialTime.setHours(0);
        initialTime.setMinutes(0);
        return initialTime;
    }

    setDataList(data) {
        this.validateTotalLsit(data, this.selectedListOnCheck);
        this.dataList = data;
        this.listExist = (this.dataList.length > 0);
    }

    transform(items: any[], args: string): any {
        // filter items array, items which match and return true will be kept, false will be filtered out
        //return items.filter(item => item.val.toLowerCase().indexOf(args.toLowerCase()) !== -1 || item.checked === true);
        return items.filter(item => this.itemcheckValidate(item.val, args) || item.checked === true);
    }
    itemcheckValidate(val1, val2) {
        const cmpval1 = val1 + '';
        const cmpval2 = val2 + '';
        return (cmpval1.toLowerCase().indexOf(cmpval2.toLowerCase()) !== -1);
    }
    validateTotalLsit(totaList, selectedList) {
        if (selectedList && selectedList.length > 0 && totaList
            && totaList.length > 0) {
            for (let i = 0; i < selectedList.length; i++) {
                const indexVal = this.findIndex(totaList, selectedList[i], 'val');
                if (indexVal !== -1) {
                    totaList[indexVal].checked = true;
                } else {
                    totaList.splice(0, 0, selectedList[i]);
                }
            }
        }
    }
    onTypeaheadSelect(eve, index) {
        eve.item['checked'] = true;
        const fndIndex = this.findIndex(this.selectedList, eve.item, 'val');
        if (fndIndex === -1) {
            this.selectedList.push(eve.item);
            const object = {
                'num': index,
                'data': eve.item,
                'count': this.count
            };
            this.checkedEvent.emit(object);
        }
        this.typeAheadVal = '';
    }
    restrictNum(event: any): void {
        const pattern = /[0-9\.]/;
        const inputChar = String.fromCharCode(event.charCode);
        if (!pattern.test(inputChar)) {
            event.preventDefault();
        }
    }

    getEnteredValue(event, type, index): void {
        event.types = {};
        event.types = type;
        event.num = index;

        if (this.fromNumValue && this.toNumValue) {
            const startVal = Number(this.fromNumValue);
            const endVal = Number(this.toNumValue);
            if (startVal < endVal) {
                this.numCheckFlag = false;
                event.startValue = startVal;
                event.endValue = endVal;
                this.freetextChangedEvent.emit(event);
            } else {
                this.numCheckFlag = true;
            }
        }
    }

    resetTextboxVal(eve): void {
        this.fromNumValue = '';
        this.toNumValue = '';
        this.numCheckFlag = false;
        this.count = 0;
        this.clickEvent.emit(eve);
    }
}
