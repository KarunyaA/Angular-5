import { ModuleWithProviders, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TimepickerModule } from 'ngx-bootstrap';
import { RatingModule } from 'ngx-bootstrap/rating';
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { MyDatePickerModule } from 'mydatepicker';

import { JbhSearchFilterComponent } from './jbh-search-filter.component';
import { JbhSearchFilterListComponent } from './jbh-search-filter-list/jbh-search-filter-list.component';
import { TypeaheadModule } from '../jbh-typeahead/typeahead.module'

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    PerfectScrollbarModule,
    MyDatePickerModule,
    RatingModule.forRoot(),
    TypeaheadModule.forRoot(),
    TimepickerModule.forRoot()
  ],
  declarations: [
    JbhSearchFilterComponent,
    JbhSearchFilterListComponent
  ],
  exports: [
    JbhSearchFilterComponent,
    JbhSearchFilterListComponent
  ]
})
export class JbhSearchFilterModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: JbhSearchFilterModule,
      providers: []
    };
  }
}
