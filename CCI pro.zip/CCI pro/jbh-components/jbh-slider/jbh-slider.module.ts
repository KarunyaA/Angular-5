// Forked from angular2-slider
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { JBHSliderComponent } from './jbh-slider.component';
import {SlideAbleDirective, BoundingRectClass, IEventSlideAble} from './ng2-slideable-directive/slideable.directive';
import {Ng2StyledDirective, IStyledConfig, ISkinable} from './ng2-styled-directive/ng2-styled.directive';

@NgModule({
  imports: [
    CommonModule,
    FormsModule
  ],
  declarations: [
    JBHSliderComponent,
    SlideAbleDirective,
    Ng2StyledDirective
  ],
  exports: [
    JBHSliderComponent
  ]
})
export class JBHSliderModule { }
