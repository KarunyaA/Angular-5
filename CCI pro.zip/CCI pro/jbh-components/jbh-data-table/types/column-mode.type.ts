export enum ColumnMode {
  standard = 'standard' as any,
  flex = 'flex' as any,
  force = 'force' as any
}
