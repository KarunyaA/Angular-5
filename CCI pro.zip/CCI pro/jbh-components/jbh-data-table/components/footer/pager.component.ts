import {
  Component, Input, Output, EventEmitter, ChangeDetectionStrategy
} from '@angular/core';

@Component({
  selector: 'datatable-pager',
  templateUrl: './pager.component.html',
  host: {
    class: 'datatable-pager'
  },
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DataTablePagerComponent {

  @Input() pagerLeftArrowIcon: string;
  @Input() pagerRightArrowIcon: string;
  @Input() pagerPreviousIcon: string;
  @Input() pagerNextIcon: string;

  @Input()
  set size(val: number) {
    this._size = val;
    this.pages = this.calcPages();
  }

  get size(): number {
    return this._size;
  }

  @Input()
  set count(val: number) {
    this._count = val;
    this.pages = this.calcPages();
  }

  get count(): number {
    return this._count;
  }

  @Input()
  set page(val: number) {
    this._page = val;
    this.pages = this.calcPages();
  }

  get page(): number {
    return this._page;
  }

  get totalPages(): number {
    const count = this.size < 1 ? 1 : Math.ceil(this.count / this.size);
    return Math.max(count || 0, 1);
  }

  @Output() change: EventEmitter<any> = new EventEmitter();

  _count = 0;
  _page = 1;
  _size = 0;
  pages: any;
  limits = [10, 25, 50, 100];
  pagesmodten = [];
  maxSize = 3;
  pageDiff = 1;
  displayFirst = false;
  displayLast = false;

  constructor() {
    this.pageDiff = Math.floor(this.maxSize / 2);
  }

  canPrevious(): boolean {
    return this.page > 1;
  }

  canNext(): boolean {
    return this.page < this.totalPages;
  }

  prevPage(): void {
    this.selectPage(this.page - 1);
  }

  nextPage(): void {
    this.selectPage(this.page + 1);
  }

  selectPage(page: number): void {
    if (page > 0 && page <= this.totalPages && page !== this.page) {
      this.page = page;

      this.change.emit({
        'page': page,
        'type': 'page'
      });
    }
  }

  calcPages(page?: number): any[] {
    const pages = [];
    let startPage = 1;
    let endPage = this.totalPages;
    let pagesmodten = [];


    //show all the 10 page number when page count is less than 10
    if (this.totalPages < 10) {
      this.maxSize = this.totalPages;
    }
    else {
      this.maxSize = 3
    }

    const isMaxSized = this.maxSize < this.totalPages;

    page = page || this.page;

    if (isMaxSized) {
      //      startPage = ((Math.ceil(page / maxSize) - 1) * maxSize) + 1;
      //      endPage = Math.min(startPage + maxSize - 1, this.totalPages);
      startPage = ((page - this.pageDiff) <= 0) ? 1 : (page - this.pageDiff);
      endPage = Math.min(startPage + this.maxSize - 1, this.totalPages);
      startPage = ((endPage - startPage) < this.maxSize && startPage != 1) ? (endPage - (this.maxSize - 1)) : startPage;
    }

    for (let num = startPage; num <= endPage; num++) {
      pages.push({
        number: num,
        text: <string><any>num
      });
    }

    this.displayFirst = ((page >= (this.totalPages - this.pageDiff)) && isMaxSized);
    this.displayLast = (!this.displayFirst && isMaxSized);

    for (let i = 1; i <= Math.floor(this.totalPages / 10); i++) {
      pagesmodten.push(i * 10);
    }
    this.pagesmodten = pagesmodten;

    return pages;
  }

  pageSizeChange(val: number): void {
    console.log(val);
    this.size = val;
    this.page = 1;
    this.change.emit({
      'limit': val,
      'page': this.page,
      'type': 'limit'
    });
  }

}
