import { Component, OnInit } from '@angular/core';

import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-error-page',
  templateUrl: './error-page.component.html',
  styleUrls: ['./error-page.component.scss']
})
export class ErrorPageComponent implements OnInit {
  status: number;
  constructor(private route: ActivatedRoute) {
    this.status = 401;
  }

  ngOnInit() {
    this.status = this.route.snapshot.params.status;
    console.log("Status", this.status);
  }

}
