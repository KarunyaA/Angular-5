import { ModuleWithProviders, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { Error401Component } from './error401/error401.component';
import { Error404Component } from './error404/error404.component';
import { Error500Component } from './error500/error500.component';

import { ErrorPageComponent } from './error-page/error-page.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [
    Error401Component,
    Error404Component,
    Error500Component,
	ErrorPageComponent
  ],
  exports: [
    Error401Component,
    Error404Component,
    Error500Component,
	ErrorPageComponent
  ]
})
export class ErrorsModule {

  static forRoot(): ModuleWithProviders {
    return {
      ngModule: ErrorsModule,
      providers: []
    };
  }

}

