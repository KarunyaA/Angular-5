import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';
import * as _ from 'lodash';

import { UserService } from './user.service';

@Injectable()
export class BusinessUnitService {
  allowedBusinessUnits: any;
  sharingData: BehaviorSubject<any[]>;
  allBuData: any;
  constructor(
    public userService: UserService,
    public http: Http) {
    this.sharingData = <BehaviorSubject<any[]>>new BehaviorSubject([]);
    this.allowedBusinessUnits = {
      formData: {},
      data: {}
    };
  }

  loadBusinessUnit(url): void {
    this.http.get(url).map(res => res.json())
      .subscribe(data => {
        let allBus: any;
        this.allBuData = data._embedded;
        if (this.userService.hasPowerAccess()) {
          allBus = data._embedded.serviceOfferingBusinessUnitTransitModeAssociations;
        } else {
          allBus = this.getAllowedBusinessUnits(data);
        }
        this.allowedBusinessUnits = {
          formData: allBus,
          data: _.map(allBus, 'financeBusinessUnitServiceOfferingAssociation.financeBusinessUnitCode')
        };

        this.saveData(this.allowedBusinessUnits);
        console.log('business unit loaded', this.allowedBusinessUnits, this.allBuData, this.getServiceOffering('DCS'));
      });
  }

  saveData(units): void {
    this.sharingData.next(units);
  }

  getData() {
    return this.sharingData.asObservable();
  }

  getAllowedBusinessUnits(data) {
    const allowedBusniessUnits = [];
    const buData = data._embedded.serviceOfferingBusinessUnitTransitModeAssociations;
    if (this.userService.userDetails
      && !this.userService.userDetails.dataList) {
      return allowedBusniessUnits;
    }
    if (this.userService.userDetails.dataList &&
      this.userService.userDetails.dataList.ORDBUSUNT &&
      this.userService.userDetails.dataList.ORDBUSUNT.length < 1) {
      return allowedBusniessUnits;
    }
    for (let i = 0; i < buData.length; i++) {
      const bu = buData[i].financeBusinessUnitServiceOfferingAssociation.financeBusinessUnitCode;
      let esaBu = [];
      if (this.userService.userDetails.dataList && this.userService.userDetails.dataList.ORDBUSUNT) {
        esaBu = Object.keys(this.userService.userDetails.dataList.ORDBUSUNT);
      }
      esaBu.forEach((element: any) => {
        if (element.toLowerCase().indexOf(bu.toLowerCase()) !== -1) {
          allowedBusniessUnits.push(buData[i]);
        }
      });
    }
    const unique: any = _.uniqBy(allowedBusniessUnits, 'financeBusinessUnitServiceOfferingAssociation.financeBusinessUnitCode');
    return unique;
  }

  hasBusinessUnitAccess(businessUnit, operation) {
    /*if (this.userService.hasPowerAccess()) {
      return true;
    }*/
    let accessLevel: any;
    let status = false;
    if (this.userService.userDetails
      && this.userService.userDetails.dataList
      && this.userService.userDetails.dataList.ORDBUSUNT) {
      accessLevel = this.userService.userDetails.dataList.ORDBUSUNT[businessUnit];
      if (operation === 'R' && accessLevel >= 1) {
        status = true;
      } else if (operation === 'PU' && accessLevel >= 2) {
        status = true;
      } else if ((operation === 'FU' || operation === 'C'
        || operation === 'D') && accessLevel >= 3) {
        status = true;
      }
    }
    return status;
  }

  hasOMAccess(url, orderBusinessUnit, operation) {
    let status = false;
    if (this.userService.hasAccess(url, operation)) {
      status = true;
    }
    if (_.isEmpty(orderBusinessUnit) && operation === 'R') {
      return status;
    } else {
      // return status && this.hasBusinessUnitAccess(orderBusinessUnit, operation);
      return this.hasBusinessUnitAccess(orderBusinessUnit, operation);
    }
  }

  getServiceOffering(bu: string): any {
    const serviceOffering: any = _.filter(this.allBuData.serviceOfferingBusinessUnitTransitModeAssociations, function (o: any) {
      return o.financeBusinessUnitServiceOfferingAssociation.financeBusinessUnitCode.toLowerCase() === bu.toLocaleLowerCase();
    });
    return serviceOffering;
  }

}
