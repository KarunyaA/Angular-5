/* tslint:disable: max-classes-per-file */
import { ModuleWithProviders, NgModule } from '@angular/core';

/**
 * Import Components for Distribution
 */
import { SpinnerModule } from './spinner';
import { JbhEsaModule } from './jbh-esa';
import { ConfirmationPopupModule } from './confirmation-popup';
import { ErrorHandlerModule } from './error-handler';
import { ErrorsModule } from './errors';
import { TypeaheadModule } from './jbh-typeahead';
import { JbhCoreServicesModule } from './jbh-core-services';
import { JBHDataTableModule } from './jbh-data-table';
//import { JbhSearchFilterModule } from './jbh-search-filter';
//import { JbhTimePickerModule } from './jbh-time-picker';
import { JbhValidationModule } from './jbh-validation';
import { SafepipeModule } from './safepipe';
import { SelectModule } from './select';
import { RlTagInputModule } from './tag-input';

/**
 * EXPORTS
 */

export { SpinnerModule } from './spinner';
export { JbhEsaModule } from './jbh-esa';
export { ConfirmationPopupModule } from './confirmation-popup';
export { ErrorHandlerModule } from './error-handler';
export { ErrorsModule } from './errors';
export { TypeaheadModule } from './jbh-typeahead';
export { JbhCoreServicesModule } from './jbh-core-services';
export { JBHDataTableModule } from './jbh-data-table';
//export { JbhSearchFilterModule } from './jbh-search-filter';
//export { JbhTimePickerModule } from './jbh-time-picker';
export { JbhValidationModule } from './jbh-validation';
export { SafepipeModule } from './safepipe';
export { SelectModule } from './select';
export { RlTagInputModule } from './tag-input';


/**
 * JbhNgBsModule Modules Exports
 * @type {Array}
 */
const MODULES = [
  SpinnerModule,
  JbhEsaModule,
  ConfirmationPopupModule,
  ErrorHandlerModule,
  ErrorsModule,
  JbhCoreServicesModule,
  JBHDataTableModule,
  //JbhSearchFilterModule,
  //JbhTimePickerModule,
  TypeaheadModule,
  JbhValidationModule,
  SafepipeModule,
  SelectModule,
  RlTagInputModule
];

/**
 * [BsRootModule NgModule description]
 */
@NgModule({
  imports: [
    SpinnerModule.forRoot(),
    JbhEsaModule.forRoot(),
    ConfirmationPopupModule.forRoot(),
    ErrorHandlerModule.forRoot(),
    ErrorsModule.forRoot(),
    JbhCoreServicesModule.forRoot(),
    JBHDataTableModule,
    //JbhSearchFilterModule.forRoot(),
    //JbhTimePickerModule.forRoot(),
    TypeaheadModule.forRoot(),
    JbhValidationModule.forRoot(),
    SafepipeModule,
    SelectModule,
    RlTagInputModule
  ],
  exports: MODULES
})
export class BsRootModule {
}

@NgModule({ exports: MODULES })
export class JbhNgBsModule {
  public static forRoot(): ModuleWithProviders {
    return {
      ngModule: BsRootModule
    };
  }
}
