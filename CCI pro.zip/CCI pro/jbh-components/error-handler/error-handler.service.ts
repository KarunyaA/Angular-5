import { ErrorHandler, Injectable } from '@angular/core';
import { SpinnerService } from './../spinner';

import { NotificationsService } from 'angular2-notifications';

@Injectable()

export class ErrorHandlerService extends ErrorHandler {

    constructor(public spinnerService: SpinnerService,
        private notifications: NotificationsService) {
        super();
    }

    handleError(error) {
        console.log('Error Handler', error);
        if (!error.title) {
            this.spinnerService.hide();
        }
        if (!error.title) {
			console.log('UI Runtime Error', error);
            this.spinnerService.hide();
        }
    }
}
