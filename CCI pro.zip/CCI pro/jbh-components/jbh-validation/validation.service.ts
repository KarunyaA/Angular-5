export class ValidationService {
  static getValidatorErrorMessage(validatorName: string, validatorValue?:
    any) {
    const config = {
      'required': 'Required',
      'invalidCreditCard': 'Is invalid credit card number',
      'invalidEmailAddress': 'Please enter a valid email address',
      'invalid2decimalprecision': 'Please enter 2 decimal precision',
      'invalid4decimalprecision': 'Please enter 4 decimal precision',
      //  'invalid74decimalprecision': 'Invalid entry',
      'allowNull': '',
      'invalidPassword': 'Invalid password. Password must be at least 6 characters long, and contain a number.',
      'minlength': `Minimum length ${validatorValue.requiredLength}`,
      'maxlength': `You have reached the maximum character limit ${validatorValue.requiredLength}`,
      'shorterComment': 'Please enter a shorter comment',
      'invalidRate': 'Please enter a valid amount',
      'invalidName': 'Please enter a valid Name',
      'invalidTime': 'Please choose a valid time',
      'invalid24Time': 'Please enter a valid military time',
      'invalidNumber': 'Please enter a valid number',
      'invalidValue': 'Special Characters are not allowed',
      'invalidComment': 'Please enter a valid comment',
      'invalidPhoneNumber': 'Please enter Phone Number(XXX) XXX-XXX-XXXX',
      'invalidMassQuantity': 'Please enter a valid Quantity',
      'invalidMeasurementCode': 'Please enter a valid number ',
      'invalidTechnicalName': 'You have reached the maximum character limit of 80 characters',
      'maxminlength': 'Min 50 charcters Max 250 Characters',
      'invalidViewName': 'Please enter a valid Name',
      'mandatory': 'Please enter',
      'mandatorySelect': 'Please select',
      'maxUnitQuantity': 'Reached maximum limit of 20 digits',
      'validDate': 'Please choose a valid date',
	  'invalidAccount': 'Please choose a valid account',
	  'mandatoryChoose': 'Please Choose'
    };

    return config[validatorName];
  }

  static creditCardValidator(control) {
    // Visa, MasterCard, American Express, Diners Club, Discover, JCB
    // const pattern: RegExp = /^(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|6(?:011|5[0-9][0-9])
    // [0-9]{12}|3[47][0-9]{13}|3(?:0[0-5]|[68][0-9])[0-9]{11}|(?:2131|1800|35\d{3})\d{11})$/;
    /* if (control.value.match(pattern)) {
       return null;
     } else {
       return { 'invalidCreditCard': true };
     }*/
  }

  static emailValidator(control) {
    // RFC 2822 compliant regex
    // const pattern: RegExp = /[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?
    // ^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/;

    const pattern: RegExp = new RegExp(/\S+@\S+\.\S+/);
    if (control.value && control.value.match(pattern)) {
      // console.log('valid email');
      return null;
    } else {
      // console.log('Invalid Email');
      return {
        'invalidEmailAddress': true
      };
    }
  }

  static passwordValidator(control) {
    // {6,100}           - Assert password is between 6 and 100 characters
    // (?=.*[0-9])       - Assert a string has at least one number
    if (control.value.match(/^(?=.*[0-9])[a-zA-Z0-9!@#$%^&*]{6,100}$/)) {
      return null;
    } else {
      return {
        'invalidPassword': true
      };
    }
  }

  static phoneNumValidator(control) {
    const pattern: RegExp = /^([0-9]{10})$/;
    return pattern.test(control.value) ? null : {
      'invalidPhoneNumber': true
    };
  }

  static chargeRateQuantity(control) {
    /*
        Values allowed 0 - 99.99
    */
    const pattern: RegExp = /^(\d{1,4}|\d\.\d{1,2}|\d{1,2}\.\d{1,2})$/;
    return pattern.test(control.value) ? null : {
      'invalid2decimalprecision': true
    };
  }

  static chargeRateCalculationAmount(control) {
    /*
        Values allowed 0 - 9999.9999
    */
    const pattern: RegExp = /^(\d{1,4}|\d\.\d{1,4}|\d{1,4}\.\d{1,4})$/;
    return pattern.test(control.value) ? null : {
      'invalid4decimalprecision': true
    };
  }

  static stopMeasurement(control) {
    const pattern: RegExp = /^(\d{1,7}|\d\.\d{1,7}|\d{1,4}\.\d{1,4})$/;
    if (control.value && !pattern.test(control.value)) {
      return {
        'invalid74decimalprecision': true
      };
    }
  }
  static allowNull(control) {
    const pattern: RegExp = /[null]$/;
    if (pattern.test(control.value)) {
      return {
        'allowNull': true
      };
    }
  }

  static rateValidator(control) {
    const pattern: RegExp = /^\d+(?:\.\d{2})$/;
    return pattern.test(control.value) ? null : { 'invalidRate': true };
  }

  static timeValidator(control) {
    const pattern: RegExp = /^(0[1-9]|1[0-2])\:[0-5][0-9]\s*[ap]m$/i;
    return pattern.test(control.value) ? null : { 'invalidTime': true };
  }

  static validate24hrsTime(control) {
    const pattern: RegExp = /^([0-1]?[0-9]|2[0-3])(:[0-5][0-9])?$/;
    return pattern.test(control.value) ? null : { 'invalid24Time': true };
  }

  // static onlyNumber(control) {
  //   const pattern: RegExp = /^[0-9]{0,}$/i;
  //   if (control.value && !pattern.test(control.value)) {
  //     return {
  //       'invalidNumber': true
  //     };
  //   }
  // }

   static phoneNumberCheck(control) {
    const pattern: RegExp = /^[0-9]{0,10}$/g;
    if (control.value && !pattern.test(control.value)) {
      let value = '';
      if (control.value.length > 1) {
        value = control.value.substring(0, control.value.length - 1);
      }
      control.patchValue(value);
    }
  }

  static onlyNumber(control) {
    const pattern: RegExp = /^[0-9]{0,}$/g;
    if (control.value && !pattern.test(control.value)) {
      let value = '';
      if (control.value.length > 1) {
        value = control.value.substring(0, control.value.length - 1);
      }
      control.patchValue(value);
    }
  }

  static decimalNumber(control) {
    const pattern: RegExp = /^[0-9]{0,}(?:\.[0-9]{0,})?$/i;
    if (control.value && !pattern.test(control.value)) {
      let value = '';
      if (control.value.length > 1) {
        value = control.value.substring(0, control.value.length - 1);
      }
      control.patchValue(value);
    }
  }

    static decimalNumberUptoTwo(control) {
    const pattern: RegExp = /^[0-9]{0,}(?:\.[0-9]{0,2})?$/i;
    if (control.value && !pattern.test(control.value)) {
      let value = '';
      if (control.value.length > 1) {
        value = control.value.substring(0, control.value.length - 1);
      }
      control.patchValue(value);
    }
  }

    static decimalNumber11Pre4(control) {
    const pattern: RegExp = /^[0-9]{0,7}(?:\.[0-9]{0,4})?$/i;
    if (control.value && !pattern.test(control.value)) {
      let value = '';
      if (control.value.length > 1) {
        value = control.value.substring(0, control.value.length - 1);
      }
      control.patchValue(value);
    }
  }

    static decimalNumberUptoFour(control) {
    const pattern: RegExp = /^[0-9]{0,}(?:\.[0-9]{0,4})?$/i;
    if (control.value && !pattern.test(control.value)) {
      let value = '';
      if (control.value.length > 1) {
        value = control.value.substring(0, control.value.length - 1);
      }
      control.patchValue(value);
    }
  }

  static onlyAlpha(control) {
    const pattern: RegExp = /^[a-zA-Z,\s]+$/;
    return pattern.test(control.value) ? null : { 'invalidName': true };
  }

  static alphaNumeric(control) {
    const pattern: RegExp = /^[A-Za-z0-9]{0,}$/i;
    return pattern.test(control.value) ? null : { 'invalidValue': true };
  }

  static commentValidator(control) {

    const pattern: RegExp = /^[A-Za-z0-9.,\s]{0,}$/i;
    if (control.value && !pattern.test(control.value)) {
      return {
        'invalidComment': true
      };
    }
  }
  static maxLengthValidator(control) {

    const pattern: RegExp = /^[\s\S]{0,250}$/;
    if (control.value && !pattern.test(control.value)) {
      return {
        'maxlength': 250
      };
    }
  }

  static massQuantity(control) {

    const pattern: RegExp = /^(\d{0,11}\.\d{0,4}|\d{0,11}|\.\d{0,4})$/;

    if (control.value && !pattern.test(control.value)) {
      return {
        'invalidMassQuantity': true
      };
    }

  }

  static measurementCode(control) {

    const pattern: RegExp = /^[0-9]{0,}$/i;
    if (control.value && !pattern.test(control.value)) {
      return {
        'invalidMeasurementCode': true
      };
    }
  }

  static materialTechnicalName(control) {

    const pattern: RegExp = /^[\s\S]{0,80}$/;
    if (control.value && !pattern.test(control.value)) {
      return {
        'invalidTechnicalName': true
      };
    }
  }
  static viewNameValidator(control) {
    const pattern: RegExp = /^[A-Za-z\d\s]+$/;
    if (control.value && !pattern.test(control.value)) {
      return {
        'invalidViewName': true
      };
    }
  }

  static maxminLengthValidator(control) {

    const pattern: RegExp = /^[\s\S]{50,250}$/;
    if (control.value && !pattern.test(control.value)) {
      return {
        'maxminlength': true
      };
    }
  }
  static mandatory(control) {
	  let error;
	  if (typeof(control.value) === 'string') {
	  	error = control.value.trim() ? null : { 'mandatory': true };
	  } else {
	  	error = control.value ? null : { 'mandatory': true };
	  }
	  return error;
  }
  static mandatorySelect(control) {
    return (control.value && control.value.length !== 0) ? null : { 'mandatorySelect': true };
  }
   static validDate(control) {
    return control.value ? '' : { 'validDate': true };
  }
  static maxUnitQuantity(control) {

    const pattern: RegExp = /^[\d]{0,20}$/;
    if (control.value && !pattern.test(control.value)) {
      return {
        'maxUnitQuantity': true
      };
    }
  }
  static mandatoryChoose(control) {
    return (control.value && control.value.length !== 0) ? null : { 'mandatoryChoose': true };
  }
  alphaNumericForTypehead(keyInput): void {
    const pattern = /[A-Za-z0-9 ]/;
    const inputChar = String.fromCharCode(keyInput.keyCode);
    if (!pattern.test(inputChar)) {
      keyInput.preventDefault();
    }
  }
  alphaOnlyForNgSelect(keyInput): void {
    const pattern = /[A-Za-z ]/;
    const inputChar = String.fromCharCode(keyInput.charCode);
    if (!pattern.test(inputChar)) {
      keyInput.preventDefault();
    }
  }
  numOnlyForInput(keyInput, CompType): void {
    const pattern = /^[0-9]*$/;
    let inputChar = '';
    if (CompType === 'ngSelect') {
      inputChar = String.fromCharCode(keyInput.charCode);
    } else {
      inputChar = String.fromCharCode(keyInput.keyCode);
    }
    if (!pattern.test(inputChar)) {
      keyInput.preventDefault();
    }
  }
  static invalidAccount(control) {
	return { 'invalidAccount': true };
  }

}
