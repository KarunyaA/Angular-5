import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { JbhValidationComponent } from './jbh-validation.component';

describe('JbhValidationComponent', () => {
  let component: JbhValidationComponent;
  let fixture: ComponentFixture<JbhValidationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [JbhValidationComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JbhValidationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
