import { Injectable } from '@angular/core';
import {
    Http, Headers, RequestOptions, Response, ResponseContentType, URLSearchParams
} from '@angular/http';

import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { NotificationsService } from 'angular2-notifications';
import { SpinnerService } from './../spinner';
// import { HttpInterceptorService } from './http-interceptor.service';
import { LoggerService } from './logger.service';
import { LocalStorageService } from './local-storage.service';
import { UtilityFunctionsService } from './utility-functions.service';

@Injectable()
export class ApiClientService {
    requestCount: number;
    private params: URLSearchParams;
    private cacheKey: string;

    constructor(
        private http: Http,
        private spinnerService: SpinnerService,
        private logger: LoggerService,
        private notifications: NotificationsService,
        private localStore: LocalStorageService,
        private utilService: UtilityFunctionsService) {
        this.requestCount = 0;
    }

    getData(
        url: string, query?: Object, showLoader?: boolean,
        headers?: any, needResponseHeaders?: boolean, needToCacheResponse?: boolean): Observable<Response[]> {
        if (needToCacheResponse) {
            this.cacheKey = this.utilService.getUtilities().getHashKey(
                (this.utilService.getUtilities().objectToQuerystring(query, url).toLowerCase()));
            const cacheData: any = this.localStore.getItem('app', this.cacheKey, false);
            if (cacheData) {
                const cacheRes: any = Observable.create((observer: any) => {
                    observer.next(cacheData);
                    observer.complete();
                });
                return cacheRes;
            }
        }
        this.requestCount++;
        this.spinnerService.spinnerText = 'Processing Service Requests ...';
        let showLoaderFlag = true;
        this.params = null;
        this.params = new URLSearchParams();
        const defaultOptions = new RequestOptions({
            headers: this.addHeaders(headers)
        });
        if (showLoader === false) {
            showLoaderFlag = false;
        }

        if (query) {
            for (const key in query) {
                if (query.hasOwnProperty(key)) {
                    this.params.set(key.toString(), query[key]);
                }
            }
        }

        defaultOptions.search = this.params;
        if (showLoaderFlag === true && !this.spinnerService.showStatus) {
            this.spinnerService.show();
        }
        return this.http.get(url, defaultOptions)
            .map((res: Response) => {
                this.requestCount--;
                if (this.requestCount <= 0) {
                    this.requestCount = 0;
                    this.spinnerService.hide();
                }
                const resPonseJson: any = res.json();
                if (needToCacheResponse) {
                    const resCacheKey: any = this.utilService.getUtilities().getHashKey(
                        (this.utilService.getUtilities().getURLBasePath(res['url']).toLowerCase()));
                    this.localStore.setItem('app', resCacheKey, resPonseJson, false);
                }
                if (needResponseHeaders) {
                    const resEtag = res.headers.get('etag');
                    const resData = {
                        eTag: resEtag,
                        data: resPonseJson
                    };
                    return resData;
                }
                return resPonseJson;
            })
            /*.retryWhen((errors) => {
               return errors
                   .mergeMap((error) => (error.status === 429) ? Observable.throw(error) : Observable.of(error))
                   .delay(1000)
                   .take(2);
            })*/
            .catch((err: Response) => {
                this.requestCount--;
                const details = this.formatError(err);
                this.errorHandler(details);
                if (this.requestCount === 0) {
                    this.spinnerService.hide();
                }
                return Observable.throw(details);
            });

    }

    addData(url, body: Object, headers?: any, showLoader?: boolean): Observable<Response[]> {
        this.requestCount++;
        let showLoaderFlag = true;
        if (showLoader === false) {
            showLoaderFlag = false;
        }
        if (showLoaderFlag === true && !this.spinnerService.showStatus) {
            this.spinnerService.show();
        }
        const defaultOptions = new RequestOptions({
            headers: this.addHeaders(headers)
        });
        const bodyString = JSON.stringify(body);
        return this.http.post(url, bodyString, defaultOptions) // ...using post request
            .map((res: Response) => {
                this.requestCount--;
                if (this.requestCount <= 0) {
                    this.requestCount = 0;
                    this.spinnerService.hide();
                }
                if (res.status === 200 && !res['_body']) {
                    return {};
                } else {
                    return res.json();
                }
            })
            /*.retryWhen((errors) => {
               return errors
                   .mergeMap((error) => (error.status === 429) ? Observable.throw(error) : Observable.of(error))
                   .delay(1000)
                   .take(2);
            })*/
            .catch((err: Response) => {
                this.requestCount--;
                if (this.requestCount === 0) {
                    this.spinnerService.hide();
                }
                const details = this.formatError(err, headers);
                this.errorHandler(details);
                return Observable.throw(details);
            }); //
    }

    updateData(url: string, body: Object, headers?: any): Observable<
        Response[]> {
        this.spinnerService.show();
        const defaultOptions = new RequestOptions({
            headers: this.addHeaders(headers)
        });
        const bodyString = JSON.stringify(body);
        return this.http.put(`${url}`, bodyString, defaultOptions)
            .map((res: Response) => {
                this.requestCount--;
                if (this.requestCount <= 0) {
                    this.requestCount = 0;
                    this.spinnerService.hide();
                }
                return res.json();
            })
            /*.retryWhen((errors) => {
               return errors
                   .mergeMap((error) => (error.status === 429) ? Observable.throw(error) : Observable.of(error))
                   .delay(1000)
                   .take(2);
            })*/
            .catch((err: Response) => {
                this.requestCount--;
                if (this.requestCount <= 0) {
                    this.requestCount = 0;
                    this.spinnerService.hide();
                }
                const details = this.formatError(err, headers);
                this.errorHandler(details);
                return Observable.throw(details);
            });
    }

    patchData(url: string, body: Object, headers?: any, showLoader?: boolean): Observable<
        Response[]> {
        this.requestCount++;
        let showLoaderFlag = true;
        if (showLoader === false) {
            showLoaderFlag = false;
        }
        if (showLoaderFlag === true && !this.spinnerService.showStatus) {
            this.spinnerService.show();
        }
        const defaultOptions = new RequestOptions({
            headers: this.addHeaders(headers)
        });
        const bodyString = JSON.stringify(body); // Stringify payload
        return this.http.patch(`${url}`, bodyString, defaultOptions) // ...using put request
            .map((res: Response) => {
                this.requestCount--;
                if (this.requestCount <= 0) {
                    this.requestCount = 0;
                    this.spinnerService.hide();
                }
                return res.json();
            })
            /*.retryWhen((errors) => {
               return errors
                   .mergeMap((error) => (error.status === 429) ? Observable.throw(error) : Observable.of(error))
                   .delay(1000)
                   .take(2);
            })*/
            .catch((err: Response) => {
                this.requestCount--;
                if (this.requestCount === 0) {
                    this.spinnerService.hide();
                }
                const details = this.formatError(err, headers);
                this.errorHandler(details);
                return Observable.throw(details);
            });
    }

    removeData(url: string, headers?: any): Observable<Response[]> {
        const defaultOptions = new RequestOptions({
            headers: this.addHeaders(headers)
        });
        return this.http.delete(`${url}`, defaultOptions) // ...using put request
            .map((res: Response) => {
                this.spinnerService.hide();
                return res.json();
            })
            /*.retryWhen((errors) => {
               return errors
                   .mergeMap((error) => (error.status === 429) ? Observable.throw(error) : Observable.of(error))
                   .delay(1000)
                   .take(2);
            })*/
            .catch((err: Response) => {
                this.spinnerService.hide();
                const details = this.formatError(err, headers);
                this.errorHandler(details);
                return Observable.throw(details);
            });
    }

    /* CCI updates starts */
    postData(url, body: Object, headers?: any): Observable<Response[]> {
        this.spinnerService.show();
        const defaultOptions = new RequestOptions({
            headers: this.addHeaders(headers)
        });
        return this.http.post(url, body, defaultOptions) // ...using post request
            .map((res: Response) => {
                this.spinnerService.hide();
                return res.json();
            })
            .catch((err: Response) => {
                this.spinnerService.hide();
                const details = this.formatError(err);
                this.errorHandler(details);
                return Observable.throw(details);
            }); // ...errors if any
    }

    putData(url: string, body: Object, headers?: any): Observable<Response[]> {
        this.spinnerService.show();
        const defaultOptions = new RequestOptions({
            headers: this.addHeaders(headers)
        });
        return this.http.put(`${url}`, body, defaultOptions)
            .map((res: Response) => {
                this.spinnerService.hide();
                return res.json();
            })
            .catch((err: Response) => {
                this.spinnerService.hide();
                const details = this.formatError(err);
                this.errorHandler(details);
                return Observable.throw(details);
            }); // ...errors if any
    }

    fileNetDocument(url): Observable<Response[]> {
        this.spinnerService.show();
        const headers = new Headers();
        headers.append('Content-Type', 'application/json');
        headers.set('Accept', 'application/json');
        headers.append('Authorization', 'Basic ' + btoa(
            'your id' + ':' + 'your password'));
        const defaultOptions = new RequestOptions({
            headers: this.addHeaders(headers),
            responseType: ResponseContentType.Blob
        });
        return this.http.get(url)
            .map((res: Response) => {
                this.spinnerService.hide();
                return res;
            })
            .catch((err: Response) => {
                this.spinnerService.hide();
                const details = this.formatError(err);
                this.errorHandler(details);
                return Observable.throw(details);
            });
    }

    /* CCI updates ends */

    addHeaders(headerParams: any): any {
        const headers = new Headers({
            'Content-Type': 'application/json'
        });
        headers.append('Cache-Control', 'no-cache');
        headers.append('Pragma', 'no-cache');
        for (const i in headerParams) {
            if (i === 'errorCallback') {
                continue;
            }
            if (headerParams.hasOwnProperty(i)) {
                headers.append(i, headerParams[i]);
            }
        }
        return headers;
    }

    formatError(err: any, headers?: any): Object {
        let error = {};
        console.log(err);
        try {
            const errJson = err.json();
            if ((err.status === 400 || err.status === 403) && headers && headers.errorCallback) {
                return errJson.errors;
            } else if (err.status === 400 || err.status === 500) {
                return {
                    title: errJson.errors[0].errorType,
                    errorMessage: errJson.errors[0].errorMessage,
                    code: errJson.errors[0].code
                };
            }

        } catch (e) {

        }
        if (err.status === 0) {
            error = {
                hideModal: true,
                title: err.error ? err.error : 'Access Denied',
                errorMessage: err.message ? err.message : 'Unauthorized. Please contact administrator.'
            };
        } else if (err.status >= 500) {
            error = {
                hideModal: true,
                title: err.error ? err.error : 'Server Error',
                errorMessage: err.message ? err.message : 'Please contact administrator.'
            };
        } else if (err.status === 404) {
            const errJson = err.json();
            error = {
                hideModal: true,
                title: 'Resource not found',
                errorMessage: errJson.Result ? errJson.Result : 'Please contact administrator.'
            };
        } else if (typeof err === 'object' && !err.stack && typeof err._body === 'object' && err._body) {
            const resBody = JSON.parse(err._body);
            if (resBody && resBody.errors && resBody.errors[0]) {
                error = {
                    hideModal: true,
                    title: resBody.errors[0].errorType,
                    errorMessage: resBody.errors[0].errorMessage,
                    code: resBody.errors[0].code
                };
            } else if (resBody && resBody.error) {
                error = {
                    hideModal: true,
                    title: resBody.error,
                    errorMessage: resBody.message,
                    code: resBody.code
                };
            } else {
                error = {
                    hideModal: true,
                    title: err.statusText,
                    errorMessage: err._body
                };
            }

        } else {
            if (err.status === 403) {
                error = {
                    title: err.statusText ? err.statusText : 'Access Denied',
                    errorMessage: err._body ? err._body : 'Unauthorized. Please contact administrator.'
                };
            } else {
                error = {
                    hideModal: true,
                    title: err.statusText ? err.statusText : 'Unable to reach the server',
                    errorMessage: err._body ? err._body : 'Empty data returned.'
                };
            }
        }
        return error;
    }

    errorHandler(errorInfo: any): void {
        if (!errorInfo.hideModal) {
            this.notifications.error(errorInfo.title, errorInfo.errorMessage);
        }
    }

    uploadBulkFile(url, body): Observable<Response[]> {
        this.spinnerService.show();
        const headers = new Headers();
        // headers.append('Content-Type', 'multipart/form-data');
        // headers.set('Accept', 'application/json');
        const defaultOptions = new RequestOptions({
            headers: headers
        });
        return this.http.post(url, body, defaultOptions)
            .map((res: Response) => {
                this.spinnerService.hide();
                return res.json();
                // return Promise.resolve(res);
            })
            .catch((err: Response) => {
                this.spinnerService.hide();
                const details = this.formatError(err);
                this.errorHandler(details);
                return Observable.throw(details);
            });
    }
    downloadExcel(url, body): Observable<Response[]> {
        this.spinnerService.show();
        const headers = new Headers();
        headers.append('Content-Type', 'application/json');
        headers.set('Accept', 'application/json');
        const defaultOptions = new RequestOptions({
            headers: this.addHeaders(headers),

            responseType: ResponseContentType.Blob
        });
        const bodyString = JSON.stringify(body);
        return this.http.post(url, bodyString, defaultOptions)
            .map((res: Response) => {
                this.spinnerService.hide();
                return res;
            })
            .catch((err: Response) => {
                this.spinnerService.hide();
                const details = this.formatError(err);
                this.errorHandler(details);
                return Observable.throw(details);
            });
    }
    addDataCimplicity(url, body: Object): Observable<Response[]> {
        this.spinnerService.show();
        const headers = new Headers();
        headers.append('Content-Type', 'application/json');
        const defaultOptions = new RequestOptions({
            headers: headers,
            withCredentials: true
        });
        const bodyString = JSON.stringify(body);
        return this.http.post(url, bodyString, defaultOptions) // ...using post request
            .map((res: Response) => {
                this.spinnerService.hide();
                return res.json();
            })
            /*.retryWhen((errors) => {
               return errors
                   .mergeMap((error) => (error.status === 429) ? Observable.throw(error) : Observable.of(error))
                   .delay(1000)
                   .take(2);
            })*/
            .catch((err: Response) => {
                this.spinnerService.hide();
                const details = this.formatError(err);
                this.errorHandler(details);
                return Observable.throw(details);
            }); //
    }

    getPowerBiHeader(url, body: Object, headers?: any, showLoader?: boolean): Observable<Response[]> {
        this.requestCount++;
        let showLoaderFlag = true;
        if (showLoader === false) {
            showLoaderFlag = false;
        }
        if (showLoaderFlag === true && !this.spinnerService.showStatus) {
            this.spinnerService.show();
        }
        const header = new Headers({
            'Content-Type': 'application/x-www-form-urlencoded'
        });
        const defaultOptions = new RequestOptions({
            headers: header
        });
        const bodyString = body;
        return this.http.post(url, bodyString, defaultOptions) // ...using post request
            .map((res: Response) => {
                this.requestCount--;
                if (this.requestCount <= 0) {
                    this.requestCount = 0;
                    this.spinnerService.hide();
                }
                if (res.status === 200 && !res['_body']) {
                    return {};
                } else {
                    return res.json();
                }
            })
            /*.retryWhen((errors) => {
               return errors
                   .mergeMap((error) => (error.status === 429) ? Observable.throw(error) : Observable.of(error))
                   .delay(1000)
                   .take(2);
            })*/
            .catch((err: Response) => {
                this.requestCount--;
                if (this.requestCount === 0) {
                    this.spinnerService.hide();
                }
                const details = this.formatError(err, headers);
                this.errorHandler(details);
                return Observable.throw(details);
            }); //
    }
}
