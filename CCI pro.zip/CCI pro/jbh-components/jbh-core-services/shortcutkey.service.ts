import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Injectable()
export class ShortcutkeyService {
  private sharingData: BehaviorSubject<any[]>;
  constructor() {
    this.sharingData = <BehaviorSubject<any[]>>new BehaviorSubject([]);
  }

  saveData(data): void {
    this.sharingData.next(data);
    // console.log(this.sharingData);
  }

  getData() {
    return this.sharingData.asObservable();
  }

  getKeyCode(e): string {
    // console.log(e);
    let keycode = '';
    if (e.ctrlKey) {
      keycode = 'ctrl+' + e.key;
      if (e.shiftKey) {
         keycode = 'ctrl+shift+' + e.key;
      }
    } else if (e.shiftKey) {
      keycode = 'shift+' + e.key;
    } else if (e.altKey) {
      keycode = 'alt+' + e.key;
    } else {
      keycode = e.key;
    }
    return keycode;
  }
}
