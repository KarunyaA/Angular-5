import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Injectable()
export class MouseEventService {
  private sharingData: BehaviorSubject<any[]>;
  constructor() {
    this.sharingData = <BehaviorSubject<any[]>>new BehaviorSubject(
      []);
  }

  saveData(data): void {
    this.sharingData.next(data);
  }

  getData() {
    return this.sharingData.asObservable();
  }

  getTarget(e): any {
    return e.target ? e.target : e;
  }
}
