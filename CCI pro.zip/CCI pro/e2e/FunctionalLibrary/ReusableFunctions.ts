/* tslint:disable */
import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";
import { Browser } from "selenium-webdriver";
export class ReusableFunctions{   
    ClickElement(wElement,value){
        try{	
            wElement.isPresent().then(function(result) {
                if ( result ) {
                    wElement.click()
                    browser.logger.info(value +' is clicked')
                } else {
                    browser.logger.error(value +' is not found') 
                }
            });
        }catch (err)
         {
            browser.logger.error(value +' has Found '+err) 
         }
    }
       
        EnterValue(wElement,text,value){
            try{	
                wElement.isPresent().then(function(result) {
                    if ( result ) {
                        wElement.sendKeys(text)
                        browser.logger.info(value +" of "+text+' is Entered')
                    } else {
                        browser.logger.error(value +' is not found')
                    }
                });
            }catch (err)
             {
                browser.logger.error(value +' has Found '+err) 
             }
        }
        
        async  getTextValueFromElement(wElement)
        {
        var uiText
        await wElement.getText().then((text)=>{          
                uiText = text 
        })
        return uiText
        }
    
        checkElementIsPresent(wElement,value)
        {
            try{	
                wElement.isPresent().then(function(result) {
                    if ( result ) {
                        browser.logger.info("Verification of "+value+"  is Present")
                    } else {
                        browser.logger.error("Verification of "+value+" is not Present")
                    }
                });
            }catch (err)
             {
                browser.logger.error(value +' has Found '+err) 
             }
        }

        
        
  async verifyTextFromList(wElement,value){
    var flag
     await wElement.isPresent().then(function(result){
    if(result==true){
    wElement.count().then(function(total){
    wElement.each(function (item) {
    var index=0
    if(total > index) {
     item.getText().then((elem)=>{
    if(elem.search(value)==0){   
     //expect(value).toContain(elem)
       flag = "pass"
    }
    })
    }
        })
    }) 
    }
     })
     return flag
 } 
   CompareValues(Expected,actual)
   { 
     if(Expected===actual)
     {
        browser.logger.info(Expected+" Value is Matched with "+actual)
     }
     else{
        browser.logger.error(Expected+" Value is Not Matched with "+actual)
     }
   }
  
}
