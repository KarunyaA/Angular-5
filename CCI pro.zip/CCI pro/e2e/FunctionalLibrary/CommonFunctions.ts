/* tslint:disable */
import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";
import {CCI_Objects} from '../ObjectsRepository/AccountSearchObjects'
let ObjCCI = new CCI_Objects();
import {CommonObjects} from '../ObjectsRepository/CommonObjects'
let ObjCommon = new CommonObjects();
import {ExcelReader} from "../CommonFiles/ReadFromXL"
var ReadFromXL= new ExcelReader()
import {DataDictionary} from "../DataFiles/DictionaryData"
import { Browser } from "selenium-webdriver";
var DataDictLib= new DataDictionary()
import {ReusableFunctions} from "../FunctionalLibrary/ReusableFunctions"
var reuse= new ReusableFunctions()
export class CommonFunctions{

/*********************************************************************************
	* MethodName:  invokeApplication
	* Description: To Invoke Url 
	* Parameter (if any):  
	* Return type:  Void
************************************************************************/
    invokeApplication() { 
        browser.get(ObjCommon.url).then(function () {
        });
    
        }
/*************************************************************************** 
	* MethodName:  NavigationOptions
	* Description: Navigation To Account Search Screen
	* Parameter (if any):  
	* Return type:  Void
***************************************************************************/
NavigationOptions(TCName) {
    var TcRow=ReadFromXL.FindRowNum(TCName)
    DataDictLib.pushToDictionary(TcRow)
    var mainTab = DataDictLib.getFromDictionary('MainTab')
    var subTAb = DataDictLib.getFromDictionary('SubTAb')
    var ele_MainTab =element.all(by.cssContainingText('.routeDisplayText',mainTab))
    reuse.ClickElement(ObjCommon.btn_toggle,"Toggle Button")
    reuse.ClickElement(ele_MainTab,mainTab+" Tab")
    var ele_SubTab=element(by.xpath("//span[text()='"+subTAb+"']"))
    reuse.ClickElement(ele_SubTab,subTAb+" Tab")
 }
}