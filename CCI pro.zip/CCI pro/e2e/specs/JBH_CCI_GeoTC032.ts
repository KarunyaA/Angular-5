/* tslint:disable */
import  {GeographicalArea} from '../pages/CCI_GeographicalArea';
import {CommonFunctions} from '../FunctionalLibrary/CommonFunctions'
import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";
let Geo_Exe =new GeographicalArea();
//import { async } from 'q';
let Exe = new CommonFunctions()
let Run = new GeographicalArea();
var path = require('path');
var filename = path.basename(__filename);
var Testcase=path.parse(filename).name
import {dbConnection} from '../FunctionalLibrary/DatabaseConnection'
let db = new dbConnection()
import {ReusableFunctions} from "../FunctionalLibrary/ReusableFunctions"
var reuse= new ReusableFunctions()
describe("JBH_CCI_GeoTC032-->Verify that system throws error when user enters invalid postal code while creating a Geographical Area", () => { // suite in Jasmine

    it("Should Able to Login and Navigate to Geographical Areas Page", () => {
        Geo_Exe.invokeApplication();
        Geo_Exe.ApplicationLogin(Testcase);
        browser.sleep(3000);
        Exe.NavigationOptions(Testcase);
        Run.overflowmenu(Testcase);
        Run.enterdetails(Testcase,"03/29/2018","03/30/2018")
        Run.VerifyIfInvalid(Testcase);
        var create = element(by.xpath("//button[text()='Create']"))
        reuse.SAClickElement(create,"create")
       // Run.ClickButtonwithText("Create");
        browser.sleep(3000);
        //Run.ValidateErrorMessage(Testcase)
       });
});
