import  {GeographicalArea} from '../pages/CCI_GeographicalArea';
import {CommonFunctions} from '../FunctionalLibrary/CommonFunctions'
import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";
let Geo_Exe =new GeographicalArea();
//import { async } from 'q';
let Exe = new CommonFunctions()
let Run = new GeographicalArea();
var path = require('path');
var filename = path.basename(__filename);
var Testcase=path.parse(filename).name
import {dbConnection} from '../FunctionalLibrary/DatabaseConnection'
let db = new dbConnection()
describe("JBH_CCI_GeoTC021-->Verify that Data Steward can deactivate/activate a Geographical Area in Edit Geographical Area page", () => { // suite in Jasmine

    it("Should Able to Login and Navigate to Geographical Areas Page", () => {
        Geo_Exe.invokeApplication();
        Geo_Exe.ApplicationLogin(Testcase);

        //Exe.invokeApplication();
       // Exe.ApplicationLogin(Testcase);
        browser.sleep(3000);
        Exe.NavigationOptions(Testcase);
        Run.searchDetails(Testcase)
        browser.sleep(5000);
        Run.verifySearchDetails(Testcase)
        Run.ViewElement();
        Run.Editdetails();
       });
    });
