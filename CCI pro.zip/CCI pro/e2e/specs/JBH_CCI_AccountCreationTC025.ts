import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";

import {CreateAccount} from "../pages/create-account.po";
let CA_Run =new CreateAccount();
import {CommonFunctions} from '../FunctionalLibrary/CommonFunctions'
let Exe = new CommonFunctions();

var path = require('path');
var filename = path.basename(__filename);
var Testcase=path.parse(filename).name

describe("JBH_CCI_AccountCreationTC025-->Verify that system allows user to create Account with Pay Agent role type", () => { // suite in Jasmine

    it("Should Able to Login and Navigate to Create Account Page", () => {
        CA_Run.invokeApplication();
        CA_Run.ApplicationLogin(Testcase);
        browser.sleep(3000);
        Exe.NavigationOptions(Testcase);
        CA_Run.CreateAccount(Testcase);
        CA_Run.VerifyAccountSuggestionDetails();
        CA_Run.CreateAccWithRoletype(Testcase);
        CA_Run.verifyAccountCreatedwithRoletype();
       });
});
