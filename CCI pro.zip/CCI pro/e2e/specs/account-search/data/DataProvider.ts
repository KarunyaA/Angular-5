'use strict';
import { element, by, $ } from 'protractor';
import { ElementFinder, ElementArrayFinder } from 'protractor/built/index';
import { MatrixPage } from '../Pages';

export class DataProvider {

  static photographersPageSearch = {
    Phone: { countryQuery: 'bang' },
    Address: { countryQuery: 'bulg' },
    : { countryQuery: 'colomb' },
    Input_India_InSearchField: { countryQuery: 'indi' },
    Input_France_InSearchField: { countryQuery: 'fra' },
    Input_Kazakhstan_InSearchField: { countryQuery: 'kaza' },
    Input_Liberia_InSearchField: { countryQuery: 'libe' },
    Input_Mexico_InSearchField: { countryQuery: 'mexi' },
    Input_Turkey_InSearchField: { countryQuery: 'tur' }
  };


}
