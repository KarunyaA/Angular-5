import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";

import {LocationSearch} from "../pages/location-search.po";
let LS_Run =new LocationSearch();
import {CreateAccount} from "../pages/create-account.po";
let CA_Run =new CreateAccount();

var path = require('path');
var filename = path.basename(__filename);
var Testcase=path.parse(filename).name


describe("JBH_CCI_LocationSearchTC018-->Verify Location Search Results Grid by selecting Status from the filters",()=>{
    it("Should Able to Login and Navigate to Location Search Page",()=>{
     LS_Run.invokeApplication();
     CA_Run.ApplicationLogin(Testcase);
     browser.sleep(3000);
     LS_Run.Navigation_Process();
     LS_Run.SearchDetails(Testcase,"Complete Details");
     LS_Run.filterOption(Testcase);
     LS_Run.VerifyStatus(Testcase,"Complete Details");
    });
});
