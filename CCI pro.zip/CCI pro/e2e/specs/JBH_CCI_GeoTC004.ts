/* tslint:disable */
import  {GeographicalArea} from '../pages/CCI_GeographicalArea';
import {CommonFunctions} from '../FunctionalLibrary/CommonFunctions'
import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";
//import { async } from 'q';
let Exe = new CommonFunctions()
let Run = new GeographicalArea();
var path = require('path');
var filename = path.basename(__filename);
var Testcase=path.parse(filename).name
let Geo_Exe =new GeographicalArea();

import {dbConnection} from '../FunctionalLibrary/DatabaseConnection'
let db = new dbConnection()
describe("JBH_CCI_GeoTC004-->Verify that user is able to search Geographical Areas using 9 digit Postal Code", () => { // suite in Jasmine

    it("Should Able to Login and Navigate to Geographical Areas Page", () => {

        Geo_Exe.invokeApplication();
        Geo_Exe.ApplicationLogin(Testcase);
        browser.sleep(3000);
        Exe.NavigationOptions(Testcase);
        Run.searchDetails(Testcase)
        //         Run.SelectQuery(Testcase)
       });

})
