/* tslint:disable */
import  {AccountSearch} from '../pages/account-search.po';
import {CommonFunctions} from '../FunctionalLibrary/CommonFunctions'
import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";
import {CreateAccount} from "../pages/create-account.po";
let CA_Run =new CreateAccount();
//import { async } from 'q';
let Exe = new CommonFunctions()
let Run = new AccountSearch();
var path = require('path');
var filename = path.basename(__filename);
var Testcase=path.parse(filename).name
describe("JBH_CCI Automation_TC005-->Verify that user is able to search by using Account Address", () => { // suite in Jasmine
    it("Should Able to Search Account Name", () => {
        Exe.invokeApplication()
        CA_Run.ApplicationLogin(Testcase);
        browser.sleep(3000);
        Exe.NavigationOptions(Testcase)
        Run.SearchAccount(Testcase)

      // expect(firstPhogrName).toContain(photographerQuery);
      //
      // expect(await PhotographersPage.photographerName.isDisplayed()).toBeTruthy();
      // expect(await PhotographersPage.photographerPortrait.isDisplayed()).toBeTruthy();
      // expect(await PhotographersPage.homesIcon.isDisplayed()).toBeTruthy();
      // expect(await PhotographersPage.camerasIcon.isDisplayed()).toBeTruthy();


        Run.validateSearchDetails(Testcase)
        });
  });
