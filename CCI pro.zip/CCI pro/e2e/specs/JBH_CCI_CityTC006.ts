import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";

import {CityCongiguration} from "../pages/CCI_CityConfig";
let City_Run =new CityCongiguration();

import {CreateAccount} from "../pages/create-account.po";
let CA_Run =new CreateAccount();

import {ReusableFunctions} from "../FunctionalLibrary/ReusableFunctions"
var reuse= new ReusableFunctions()

import {CommonFunctions} from '../FunctionalLibrary/CommonFunctions'
let Exe = new CommonFunctions()

var path = require('path');
var filename = path.basename(__filename);
var Testcase=path.parse(filename).name

describe("TS_CCI_UC08.3.2City_006_Create_City_without_entering_value_TC006-->Verify that system does not allow user to create a city without entering any value(Leave all the fields blank)",()=>{
    it("Should Able to Login and Navigate to City Search Page",()=>{
        CA_Run.invokeApplication();
        CA_Run.ApplicationLogin(Testcase);
        browser.sleep(3000);
        Exe.NavigationOptions(Testcase);
        City_Run.CreateNewCity(Testcase);
        City_Run.addCityButton();
        browser.executeScript("window.scrollTo(0,-500)");
        City_Run.VerifyCityCreated();
    });
});
