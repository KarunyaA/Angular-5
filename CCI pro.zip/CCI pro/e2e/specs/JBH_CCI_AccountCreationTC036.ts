import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";

import {CreateAccount} from "../pages/create-account.po";
let CA_Run =new CreateAccount();
import {CommonFunctions} from '../FunctionalLibrary/CommonFunctions'
let Exe = new CommonFunctions();
var path = require('path');
var filename = path.basename(__filename);
var Testcase=path.parse(filename).name


describe("JBH_CCI_AccountCreationTC036-->Verify that on clicking Create Account button - Melissa call is made and user is prompted to enter valid address in Create New Account page, if status returned from Melissa is not ASO1", () => { // suite in Jasmine

    it("Should Able to Login and Navigate to Create Account Page", () => {
        CA_Run.invokeApplication();
        CA_Run.ApplicationLogin(Testcase);
        browser.sleep(3000);
        Exe.NavigationOptions(Testcase);
        CA_Run.SearchAccount(Testcase);
        CA_Run.VerifySearchDetails();
        CA_Run.CreateAccount(Testcase);
        CA_Run.VerifyAccountSuggestionDetails();
       });
});
