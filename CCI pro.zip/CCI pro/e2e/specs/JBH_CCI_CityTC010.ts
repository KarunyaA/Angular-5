import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";

import {CityCongiguration} from "../pages/CCI_CityConfig";
let City_Run =new CityCongiguration();

import {CreateAccount} from "../pages/create-account.po";
let CA_Run =new CreateAccount();

import {ReusableFunctions} from "../FunctionalLibrary/ReusableFunctions"
var reuse= new ReusableFunctions()

import {CommonFunctions} from '../FunctionalLibrary/CommonFunctions'
let Exe = new CommonFunctions()

var path = require('path');
var filename = path.basename(__filename);
var Testcase=path.parse(filename).name

describe("TS_CCI_UC08.3.2City_010_Edit_New_City_TC010-->Verify that the system allows the user to Edit and Save the City configuration",()=>{
    it("Should Able to Login and Navigate to City Search Page",()=>{
        CA_Run.invokeApplication();
        CA_Run.ApplicationLogin(Testcase);
        browser.sleep(3000);
        Exe.NavigationOptions(Testcase);
        City_Run.SearchbyValue(Testcase,"City");
        City_Run.EditCity(Testcase);
        City_Run.addCityButton();
        City_Run.VerifyCityAlias(Testcase,"City Alias");
    });
});
