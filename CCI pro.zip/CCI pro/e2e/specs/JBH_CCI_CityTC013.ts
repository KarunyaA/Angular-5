import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";

import {CityCongiguration} from "../pages/CCI_CityConfig";
let City_Run =new CityCongiguration();

import {CreateAccount} from "../pages/create-account.po";
let CA_Run =new CreateAccount();

import {ReusableFunctions} from "../FunctionalLibrary/ReusableFunctions"
var reuse= new ReusableFunctions()

import {CommonFunctions} from '../FunctionalLibrary/CommonFunctions'
let Exe = new CommonFunctions()

var path = require('path');
var filename = path.basename(__filename);
var Testcase=path.parse(filename).name

describe("TS_CCI_UC08.3.2City_013_View_City_Information_page_TC013-->Verify that the user is able to view the City Information Page",()=>{
    it("Should Able to Login and Navigate to City Search Page",()=>{
        CA_Run.invokeApplication();
        CA_Run.ApplicationLogin(Testcase);
        browser.sleep(3000);
        Exe.NavigationOptions(Testcase);
        City_Run.overflowViewClick();
        City_Run.VerifyReadonlyData();
    });
});
