import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";

import {LocationSearch} from "../pages/location-search.po";
let LS_Run =new LocationSearch();
import {CreateAccount} from "../pages/create-account.po";
let CA_Run =new CreateAccount();

var path = require('path');
var filename = path.basename(__filename);
var Testcase=path.parse(filename).name

describe("JBH_CCI_LocationSearchTC004-->Verify that user is able to search Location by entering Address", () => { // suite in Jasmine

    it("Should Able to Login and Navigate to Location Search Page", () => {
     LS_Run.invokeApplication();
     CA_Run.ApplicationLogin(Testcase);
     browser.sleep(3000);
     LS_Run.Navigation_Process();
     LS_Run.SearchDetails(Testcase,"Complete Details");

     LS_Run.VerifySearchAddress(Testcase,"Complete Details");
     browser.sleep(3000);
     LS_Run.SearchDetails(Testcase,"Semi Partial Details");

     LS_Run.VerifySearchAddress(Testcase,"Semi Partial Details");
     browser.sleep(3000);
     LS_Run.SearchDetails(Testcase,"Partial Details");

     LS_Run.VerifySearchAddress(Testcase,"Partial Details");
     browser.sleep(3000);
    });
});
