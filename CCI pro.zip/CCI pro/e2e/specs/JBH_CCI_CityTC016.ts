import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";

import {CityCongiguration} from "../pages/CCI_CityConfig";
let City_Run =new CityCongiguration();

import {CreateAccount} from "../pages/create-account.po";
let CA_Run =new CreateAccount();

import {ReusableFunctions} from "../FunctionalLibrary/ReusableFunctions"
var reuse= new ReusableFunctions()

import {CommonFunctions} from '../FunctionalLibrary/CommonFunctions'
let Exe = new CommonFunctions()

var path = require('path');
var filename = path.basename(__filename);
var Testcase=path.parse(filename).name

describe("TS_CCI_UC08.3.2City_015_City_mapping_existing postal code_TC016-->Verify that system doesn't allow Data Steward to assign a postal code which is already mapped to a existing active city to a New City",()=>{
    it("Should Able to Login and Navigate to City Search Page",()=>{
        CA_Run.invokeApplication();
        CA_Run.ApplicationLogin(Testcase);
        browser.sleep(3000);
        Exe.NavigationOptions(Testcase);
        City_Run.EditCity(Testcase);
        City_Run.addCityButton();
        City_Run.VerifyCityCreated();

    });
});
