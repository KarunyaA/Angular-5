import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";

import {CityCongiguration} from "../pages/CCI_CityConfig";
let City_Run =new CityCongiguration();

import {CreateAccount} from "../pages/create-account.po";
let CA_Run =new CreateAccount();

import {ReusableFunctions} from "../FunctionalLibrary/ReusableFunctions"
var reuse= new ReusableFunctions()

import {CommonFunctions} from '../FunctionalLibrary/CommonFunctions'
let Exe = new CommonFunctions()

var path = require('path');
var filename = path.basename(__filename);
var Testcase=path.parse(filename).name

describe("TS_CCI_UC08.3.2City_005_Add_City_TC005-->Verify that the user is able to Add a New City",()=>{
    it("Should Able to Login and Navigate to City Search Page",()=>{
        CA_Run.invokeApplication();
        CA_Run.ApplicationLogin(Testcase);
        browser.sleep(3000);
        Exe.NavigationOptions(Testcase);
        City_Run.CreateNewCity(Testcase);
        City_Run.addCityButton();
        City_Run.VerifyCityCreated();
        browser.executeScript("window.scrollTo(0,-500)");
        City_Run.SearchbyValue(Testcase,"City Name");
        City_Run.VerifyCityName(Testcase,"City Name");
    });
});
