import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";

import {CityCongiguration} from "../pages/CCI_CityConfig";
let City_Run =new CityCongiguration();

import {CreateAccount} from "../pages/create-account.po";
let CA_Run =new CreateAccount();

import {ReusableFunctions} from "../FunctionalLibrary/ReusableFunctions"
var reuse= new ReusableFunctions()

import {CommonFunctions} from '../FunctionalLibrary/CommonFunctions'
let Exe = new CommonFunctions()

var path = require('path');
var filename = path.basename(__filename);
var Testcase=path.parse(filename).name

describe("JBH_CCI_CityTC014-->Verify that the user is able to view the City Information Page",()=>{
    it("Should Able to Login and Navigate to City Search Page",()=>{
        CA_Run.invokeApplication();
        CA_Run.ApplicationLogin(Testcase);
        browser.sleep(3000);
        Exe.NavigationOptions(Testcase);
        City_Run.overflowViewClick();
        City_Run.ClicksendComments();
        City_Run.VerifyCommentsEntered();
        City_Run.EnterComments(Testcase,"InvalidComment");
        City_Run.ClicksendComments();
        City_Run.VerifyCommentsEntered();
        City_Run.EnterComments(Testcase,"Comments");
        City_Run.ClicksendComments();
    });


});
