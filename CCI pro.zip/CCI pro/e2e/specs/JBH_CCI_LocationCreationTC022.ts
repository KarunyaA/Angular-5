/* tslint:disable */
import  {LocationCreation} from '../pages/location-creation.po';
import {CommonFunctions} from '../FunctionalLibrary/CommonFunctions'
import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";
import {CreateAccount} from "../pages/create-account.po";
let CA_Run =new CreateAccount();
//import { async } from 'q';
let Exe = new CommonFunctions()
let Run_LC = new LocationCreation();
var path = require('path');
var filename = path.basename(__filename);
var Testcase=path.parse(filename).name
describe("JBH_CCI Automation_TC011-->Verify in create new Location page by entering Non existing Location", () => { // suite in Jasmine
        it("Should Able to Navigate to Location Search Page ", () => {
        Exe.invokeApplication()
        CA_Run.ApplicationLogin(Testcase);
        browser.sleep(3000);
        Exe.NavigationOptions(Testcase)
        Run_LC.createLocation(Testcase)
        Run_LC.createNewLocation(Testcase)
        });
  });
