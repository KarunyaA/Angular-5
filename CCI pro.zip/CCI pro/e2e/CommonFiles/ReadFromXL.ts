/* tslint:disable */
import { INSPECT_MAX_BYTES } from "buffer";
var path = require('path');
var filelocation =path.resolve("./") + '\\' + 'e2e'+'\\'+'TestData.xlsx'
export class ExcelReader
{
	
	FindRowNum(TcName:string){	
	  
		var TCrow;
	  	var XLS,i;
		var val:string;
		i=1
	    if (typeof require !== 'undefined') {
	        XLS = require('xlsx');
	    }
	    //Working with workbook
	    var workbook = XLS.readFile(filelocation);
	    //var sheetNamelist = workbook.SheetNames;
		//var value = workbook.Sheets[sheetNamelist[sheetNumber]][cellId].v;
		while(i>0)
		{
			val=workbook.Sheets["data"]["A"+i].v 

			if (val.toString()===TcName.toString())	
			{
				TCrow=i
				console.log(TCrow)
				break;	
			}
			//console.log(typeof(val))
			//console.log(typeof(TcName))
				i++
					
		}

		

		//console.log(wb.cell(2,2))
	    return TCrow;
		
	}
 GetSpecNames(){
	var XLS,i;
	var val:string;
	var Spec,Exec,SpecNames
	SpecNames=""
	var specCons="./specs/**/"
	i=2
	if (typeof require !== 'undefined') {
		XLS = require('xlsx');
	}
	//Working with workbook
	var workbook = XLS.readFile(filelocation);
	while(i>0)
	{
		
		try
		{
		 Spec = workbook.Sheets["RunManager"]["A"+i].v;
		 Exec = workbook.Sheets["RunManager"]["B"+i].v;
		 }
		catch(e)
		{
			console.log("Data read is completed")
			break;
		}
		if (Exec.toLowerCase()==="yes")
		{	
			Spec =specCons+Spec+".js"
			if (i==2)
				SpecNames+=""+Spec+""
			else
				SpecNames+=","+Spec+""
			
		}
		i++
		
		
		
	}
	
	return SpecNames
}

GetColLetter(WsName,columnName) {
	var XLS,i;
	var val:string;
	var specCons="./specs/**/"
	i=1
	if (typeof require !== 'undefined') {
		XLS = require('xlsx');
	}
	//Working with workbook
	
	var workbook = XLS.readFile(filelocation);
	while(i>0)
	{	var colId=this.columnToLetter(i)
		var colName = this.GetValue(workbook,WsName,colId+"1")
		if(colName.toString()===columnName.toString())
		{
			break;
		}
		i++
	}
	return colId
}
GetValue(Wrb,WSName,cellID){
	var cellVal
	try {  cellVal=Wrb.Sheets[WSName][cellID].v }
	catch(e){ cellVal=null}
	return cellVal
}

columnToLetter (column){	
	var letter = '';
	var val,temp;
	while (column > 0)
	{
	  temp = (column - 1) % 26;
	  letter = String.fromCharCode(temp + 65) + letter;
	  column = (column - temp - 1) / 26;
	}
	val=letter;
	return val;
  }
  
cellFromXLS(shtName:string,cellId){
	
	//Define sheetNumber
	var TCrow;
	// if (shtName == 'conf') {sheetNumber = 0;}
	// if (shtName == 'spec') {sheetNumber = 1;}
	
	//NodeJs read file
	var XLS,i;
	
	i=1
	if (typeof require !== 'undefined') {
		XLS = require('xlsx');
	}
	//Working with workbook
	var workbook = XLS.readFile(filelocation);
	//var sheetNamelist = workbook.SheetNames;
	var value = workbook.Sheets[shtName][cellId].v;


	
	//console.log(wb.cell(2,2))
	return value;
	
}
}
    


