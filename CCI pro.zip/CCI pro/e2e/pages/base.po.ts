/* tslint:disable */
import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";
import {CCI_Objects} from '../ObjectsRepository/AccountSearchObjects'
let ObjCCI = new CCI_Objects();
import {CommonObjects} from '../ObjectsRepository/CommonObjects'
let ObjCommon = new CommonObjects();
import {ExcelReader} from "../CommonFiles/ReadFromXL"
var ReadFromXL= new ExcelReader()
import {DataDictionary} from "../DataFiles/DictionaryData"
import { Browser } from "selenium-webdriver";
var DataDictLib= new DataDictionary()
import {ReusableFunctions} from "../FunctionalLibrary/ReusableFunctions"
var reuse= new ReusableFunctions()
export class BasePage{

  username=   element(by.id("j_username"));
  password=   element(by.id("j_password"));
  login_btn=  element(by.className("btn-submit"));

  str_url="http://account-tst-prof2.jbhunt.com/account/";
  txt_UsrName=element(by.css("[id='username']"));
  txt_Pswd=element(by.css("[id='password']"));
  btn_SignIn = element(by.css("[name='submit']"));
  btn_toggle= element(by.css("[class=\"fa fa-circle-o\"]"));

}
