/*tslint:disable*/
import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";

import {CCI_LocSearchObjects} from '../ObjectsRepository/LocationSearchObj'
let ObjCCI_LS = new CCI_LocSearchObjects();

import {ExcelReader} from "../CommonFiles/ReadFromXL"
var ReadFromXL= new ExcelReader()
import {DataDictionary} from "../DataFiles/DictionaryData"
import { Browser } from "selenium-webdriver";
var DataDictLib= new DataDictionary()
import {ReusableFunctions} from "../FunctionalLibrary/ReusableFunctions"
var reuse= new ReusableFunctions()

export class LocationSearch{
/*********************************************************************************
	* MethodName:  invokeApplication
	* Description: To Invoke Url 
	* Parameter (if any):  
	* Return type:  Void
************************************************************************/
invokeApplication() { 
    browser.refresh();
    browser.get(ObjCCI_LS.url); 
    browser.waitForAngular();
    }
/**==============================================================================
* 
* MethodName:  Navigation_Process
* Description: To Navigation To Location Search Page 
* Parameter (if any):  
* Return type:  Void
===============================================================================*/
Navigation_Process(){    
    browser.waitForAngular();    
    reuse.ClickElement(ObjCCI_LS.btn_toggle,"Toggle Button");
    reuse.ClickElement(ObjCCI_LS.tab_Location,"Location Tab");
    reuse.ClickElement(ObjCCI_LS.subTab_LocationSearch,"Location Search Tab")
}  

/**==============================================================================
* 
* MethodName:  SearchDetails
* Description: To Search the details in search textbox 
* Parameter (if any):  TCName,ColHeader
* Return type:  Void
===============================================================================*/
SearchDetails(TCName,ColHeader){
    var TcRow = ReadFromXL.FindRowNum(TCName);
    DataDictLib.pushToDictionary(TcRow);
    var str_value:string= DataDictLib.getFromDictionary(ColHeader);

    browser.waitForAngular(); 
    ObjCCI_LS.txt_LocSearch.isPresent().then(function (result){
        if(result==true){
        ObjCCI_LS.txt_LocSearch.clear();                        
        reuse.EnterValue(ObjCCI_LS.txt_LocSearch,str_value,"Details"); 
        ObjCCI_LS.txt_LocSearch.sendKeys(protractor.Key.TAB);
        browser.sleep(2000);
        reuse.ClickElement(ObjCCI_LS.icon_Search,"Search Icon");
        browser.sleep(6000);
    }}) 
}
/**==============================================================================
* 
* MethodName:  VerifySearchAddress
* Description: To Verify the address details displayed 
* Parameter (if any):  TCName,ColHeader
* Return type:  Void
===============================================================================*/
VerifySearchAddress(TCName,ColHeader){
    browser.waitForAngular();
    var TcRow = ReadFromXL.FindRowNum(TCName);
    DataDictLib.pushToDictionary(TcRow);
    var str_value:string= DataDictLib.getFromDictionary(ColHeader);
    
    ObjCCI_LS.List_address.isPresent().then(function(result){
        if(result==true){
            ObjCCI_LS.List_address.count().then(function(total){
                ObjCCI_LS.List_address.each(function (item) {
                    var index=0
                    if(total > index) {
                        var str_address=item.getText().then((elem)=>{
                            if(elem.search(str_value)==0){                                
                                console.log(elem);
                                console.log(str_value);
                                console.log("Address Found");                                                                                            
                            }
                        })
                    }
                })
            }) 
            
        }
    });
}
/**==============================================================================
* 
* MethodName:  VerifyLocationName
* Description: To Verify the Location Name displayed 
* Parameter (if any):  TCName,ColHeader
* Return type:  Void
===============================================================================*/
VerifyLocationName(TCName,ColHeader){
    browser.waitForAngular();
   
    var TcRow = ReadFromXL.FindRowNum(TCName);
    DataDictLib.pushToDictionary(TcRow);
    var str_value:string= DataDictLib.getFromDictionary(ColHeader);

    ObjCCI_LS.str_LocName.isPresent().then(function(result){
        if(result==true){
            ObjCCI_LS.str_LocName.getText().then((text)=>{
                if(text.search(str_value)==0){
                    console.log(text);
                    console.log(str_value);
                    console.log("Location Name Found");
                }else{
                    console.log("Location Name Not Found");
                }
            })
        }
    })
}
/**==============================================================================
* 
* MethodName:  VerifyPhoneNumber
* Description: To Verify the Phone Number displayed 
* Parameter (if any):  TCName,ColHeader
* Return type:  Void
===============================================================================*/
VerifyPhoneNumber(TCName,ColHeader){
    browser.waitForAngular();
    var TcRow = ReadFromXL.FindRowNum(TCName);
    DataDictLib.pushToDictionary(TcRow);
    var int_value:string= DataDictLib.getFromDictionary(ColHeader);

    ObjCCI_LS.int_PhNumcell.isPresent().then(function(result){
        if(result==true){
            ObjCCI_LS.int_PhNumcell.getText().then((text)=>{
                if(text.search(int_value)==0){
                    console.log(text);
                    console.log(int_value);
                    console.log("Phone Number Found");
                }else{
                    console.log("Phone Number Not Found");
                }
            })
        }
    })
}
/**==============================================================================
* 
* MethodName:  filterOption
* Description: Select a filter option 
* Parameter (if any):  TCNum
* Return type:  Void
===============================================================================*/
filterOption(TCNum){
    var TcRow = ReadFromXL.FindRowNum(TCNum);
    DataDictLib.pushToDictionary(TcRow);
    
    var Filter:string= DataDictLib.getFromDictionary("Filter Option");
    var FilterValue:string= DataDictLib.getFromDictionary("Filter Value");
    
    ObjCCI_LS.btn_Filter.isEnabled().then(function(result){
        if(result==true){
            ObjCCI_LS.btn_Filter.click();
            browser.sleep(3000);            
        }
    });

    ObjCCI_LS.lst_FilterOptions.count().then(function(total) {
        ObjCCI_LS.lst_FilterOptions.each(function (item) {
            var index=0
            if(total > index){
                item.getText().then((elem)=>{ 
                    if(elem==Filter){

                        //filter dropdown click
                        var xp_drpdwnOpt = "//*[text()='"+elem+"']//following::a[1]";
                        var btn_drpDwn = element(by.xpath(xp_drpdwnOpt));
                        reuse.ClickElement(btn_drpDwn, elem+" dropdown");
                        browser.sleep(3000);

                        //search value in filter textbox
                        var xp_SearchBox = "//*[text()='"+elem+"']//following::input[1]";
                        var txt_Search = element(by.xpath(xp_SearchBox)).sendKeys(FilterValue);
                        browser.sleep(3000);

                        //click first checkbox
                        var xp_chkbox="//*[text()='"+elem+"']//following::input[@name='filterChkBx'][1]";                        
                        var chkbox_elem = element(by.xpath(xp_chkbox));
                        chkbox_elem.isPresent().then(function(result){
                            if(result==true){
                                        reuse.ClickElement(chkbox_elem, "Checkbox");
                                        browser.sleep(3000);
                                        }
                    })
                        
                    }
                });
            }
        });
    });

}
/**==============================================================================
* 
* MethodName:  VerifyStatus
* Description: Verify account status based on filter
* Parameter (if any):  TCName,ColHeader
* Return type:  Void
===============================================================================*/
VerifyStatus(TCName,ColHeader){
    browser.waitForAngular();
    browser.sleep(3000);
    var TcRow = ReadFromXL.FindRowNum(TCName);
    DataDictLib.pushToDictionary(TcRow);
    var str_value:string= DataDictLib.getFromDictionary(ColHeader);
    
    
    ObjCCI_LS.List_address.isPresent().then(function(result){
        if(result==true){
            ObjCCI_LS.List_address.count().then(function(total){
                ObjCCI_LS.List_address.each(function (item) {
                    var index=0
                    if(total > index) {
                        var str_address=item.getText().then((elem)=>{
                            if(elem.search(str_value)==0){                                
                                item.click();
                                browser.sleep(5000);
                                browser.waitForAngularEnabled();

                                ObjCCI_LS.str_Status.isDisplayed().then(function(result){
                                    if(result==true)
                                    {   browser.sleep(3000);
                                        ObjCCI_LS.str_Status.getText().then((text)=>{
                                            if(text=="Active"){
                                                console.log("Location Profile is Active");
                                            }else if(text=="Inactive"){
                                                console.log("Location Profile is Inactive");
                                            }
                                        }) 
                                    }
                                })
                            }
                        })
                    }
                })
            }) 
            
        }
        else{console.log("Results did not match th search criteria")}
    });
    browser.sleep(2000);
}

}