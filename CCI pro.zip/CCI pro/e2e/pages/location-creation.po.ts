/* tslint:disable */
import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";
import {CCI_Objects} from '../ObjectsRepository/LocationSearchObjects'
let ObjCCI = new CCI_Objects();
import {CommonObjects} from '../ObjectsRepository/CommonObjects'
let ObjCommon = new CommonObjects();
import {ExcelReader} from "../CommonFiles/ReadFromXL"
var ReadFromXL= new ExcelReader()
import {DataDictionary} from "../DataFiles/DictionaryData"
import { Browser } from "selenium-webdriver";
var DataDictLib= new DataDictionary()
import {ReusableFunctions} from "../FunctionalLibrary/ReusableFunctions"
var reuse= new ReusableFunctions()
export class LocationCreation{
    
/*************************************************************************** 
	* MethodName:  SearchLocation
	* Description: Search Account Details
	* Parameter (if any):  
	* Return type:  Void
***************************************************************************/
SearchLocation(TCName)
{
    var TcRow=ReadFromXL.FindRowNum(TCName)
    DataDictLib.pushToDictionary(TcRow)
    var searchDetails = DataDictLib.getFromDictionary('Search Details')
    browser.executeScript('window.scrollTo(-2000,0);').then(function () {
        console.log("scroll right")
    })
    reuse.EnterValue(ObjCCI.txt_SearchLocationDetails,searchDetails,"Location Details")
    ObjCCI.obj_SearchIcon.sendKeys(protractor.Key.TAB)
    reuse.ClickElement(ObjCCI.obj_SearchIcon,"Search Button")
}
  
/*************************************************************************** 
	* MethodName:  invalidDataValidation
	* Description: verify invalid Location search result and check for Create Location Button
	* Parameter (if any):  
	* Return type:  Void
***************************************************************************/
async invalidDataValidation()
{
    var InvalidMessage : string = "We could not find results that matched your search.Refine your search or click below to create a new location.";
    var ele_invalidtext =ObjCCI.msg_InvalidData
    var uiText= await reuse.getTextValueFromElement(ele_invalidtext)
    if (uiText===InvalidMessage){
    browser.logger.info(uiText +' is Matched with '+InvalidMessage) 
    }  
    // else
    // {
    // browser.logger.error(uiText +' is not Matched with '+InvalidMessage)  
    // }              
    reuse.ClickElement(ObjCCI.btn_createLocation,"Create Location Button")
    reuse.checkElementIsPresent(ObjCCI.txt_addressField,"Create Location Page")
}

/*************************************************************************** 
	* MethodName:  createLocation
	* Description: Create  Location using Mellisa Address AS01
	* Parameter (if any):  
	* Return type:  Void
***************************************************************************/
async createLocation(TCName)
{
    var TcRow=ReadFromXL.FindRowNum(TCName)
    DataDictLib.pushToDictionary(TcRow)
    var locationInfo
    var stringAddress = DataDictLib.getFromDictionary('LocationAddress')
    var stringCity = DataDictLib.getFromDictionary('LocationCity')
    var stringState = DataDictLib.getFromDictionary('LocationState')
    var stringPostalCode = DataDictLib.getFromDictionary('LocationPostalCode')
    var stringLegalUser = DataDictLib.getFromDictionary('LocationLegalUser')
    reuse.EnterValue(ObjCCI.txt_addressField,stringAddress,"Location Address Field")
    reuse.EnterValue(ObjCCI.txt_city,stringCity,"Location City Field")
    reuse.ClickElement(ObjCCI.ddl_stateClick,"Location State DropDown")
    var ele_State = ObjCCI.ddl_stateList
    ele_State.filter(function (elem) {
        return elem.getText().then(function (text) {
            return text === stringState;
        });
    }).click();
    reuse.EnterValue(ObjCCI.txt_postcode,stringPostalCode,"Location Postal Code")
    reuse.EnterValue(ObjCCI.txt_ownerName,stringLegalUser,"Legal User name")
    reuse.ClickElement(ObjCCI.btn_create,"Create Button")
    reuse.ClickElement(ObjCCI.btn_nextMatchingLocation,"Clicking '>' in Matching Locations")
    reuse.checkElementIsPresent(ObjCCI.lbl_locationInfo,"Location Information")
    locationInfo = await reuse.getTextValueFromElement(ObjCCI.lbl_locationInfo)
    reuse.CompareValues(locationInfo,stringAddress)
}


/*************************************************************************** 
	* MethodName:  createNewLocation
	* Description: Create New Location using Mellisa Address AS01
	* Parameter (if any):  
	* Return type:  Void
***************************************************************************/
createNewLocation(TCName)
{
    var TcRow=ReadFromXL.FindRowNum(TCName)
    DataDictLib.pushToDictionary(TcRow)
    var stringRole = DataDictLib.getFromDictionary('Role')
    var stringLocation = DataDictLib.getFromDictionary('LocationType')
    var stringLocationType = DataDictLib.getFromDictionary('LocationSubType')
    reuse.ClickElement(ObjCCI.ddl_RoleClick,"Location Role DropDown")
    var ele_Role = ObjCCI.ddl_RoleSelect
    ele_Role.filter(function (elem) {
        return elem.getText().then(function (text) {
            return text === stringRole;
        });
    }).click();
    reuse.ClickElement(ObjCCI.ddl_locationTypeclick,"Location  DropDown")
    var ele_Location= ObjCCI.ddl_locationTypeSelect
    ele_Location.filter(function (elem) {
        return elem.getText().then(function (text) {
            return text === stringLocation;
        });
    }).click();
    reuse.ClickElement(ObjCCI.btn_createButton,"Create Button")
   // reuse.ClickElement(ObjCCI.btn_ok,"Ok Button")
   reuse.checkElementIsPresent(ObjCCI.msg_popupText,"Your request is pending with the Data Steward.")
}
}