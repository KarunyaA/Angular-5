/* tslint:disable */
import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";
import {CCI_Objects} from '../ObjectsRepository/AccountSearchObjects'
let ObjCCI = new CCI_Objects();
import {CommonObjects} from '../ObjectsRepository/CommonObjects'
let ObjCommon = new CommonObjects();
import {ExcelReader} from "../CommonFiles/ReadFromXL"
var ReadFromXL= new ExcelReader()
import {DataDictionary} from "../DataFiles/DictionaryData"
import { Browser } from "selenium-webdriver";
var DataDictLib= new DataDictionary()
import {ReusableFunctions} from "../FunctionalLibrary/ReusableFunctions"
import {BasePage} from "./base.po";
var reuse= new ReusableFunctions()
export class AccountSearchPage extends BasePage{

  tab_Account=element.all(by.cssContainingText('.routeDisplayText','Account'))
  subTab_AccountSearch=element(by.xpath("//span[text()='Account Search']"))
  txt_SearchAccountDetails = element(by.xpath("//input[@placeholder='Search by Address, Account Name, Account Code, Account Alias, Phone Number or Business Identifier']"))
  obj_SearchIcon =element(by.css("[class=\"icon-jbh_search form-control-feedback font18\"]"))
  msg_InvalidData=element(by.xpath("//*[@class='table table-responsive col-12 col-md-12 table-striped panel panel-default panelshadow']//tbody/tr/td"))
  buttonCreateAccount =element(by.id("createAccountBtn"))
  textaddressField =element(by.id("addressField"))
  buttonCreateLocation =element(by.id("createLocationBtn"))
  listSearchDetails = element.all(by.xpath("//*[@class='tableWrapper visible']//datatable-body//datatable-row-wrapper//datatable-body-cell//child::span"))
  listsearchFirstRow=element.all(by.xpath("//*[@class='tableWrapper visible']//datatable-body//datatable-row-wrapper//datatable-body-cell//child::span[1]"))
  listSearchPhoneNumber=element.all(by.xpath("//*[@class='tableWrapper visible']//datatable-body//datatable-row-wrapper//datatable-body-cell//child::span[3]"))
  buttonFilter =element(by.id("span-filter"))
  tab_accountRole=element(by.xpath("//h5[text()='Account Role']"))
  subTab_accountRole=element(by.xpath("//div[label[text()='Beneficial Owner']]//input"))
  btn_reset=element(by.id("resetLnk"))


SearchAccount(TCName)
{
    var TcRow=ReadFromXL.FindRowNum(TCName)
    DataDictLib.pushToDictionary(TcRow)
    var searchDetails = DataDictLib.getFromDictionary('Search Details')
    browser.executeScript('window.scrollTo(-2000,0);').then(function () {
        console.log("scroll right")
    })
    reuse.EnterValue(ObjCCI.txt_SearchAccountDetails,searchDetails,"Account Details")
    browser.executeScript('window.scrollTo(0,-2000);').then(function () {
        console.log("scroll left")
    })
    ObjCCI.obj_SearchIcon.sendKeys(protractor.Key.TAB)
    reuse.ClickElement(ObjCCI.obj_SearchIcon,"Search Button")
}



async invalidDataValidation()
{
    var InvalidMessage : string = "We could not find results that matched your search.Refine your search or click below to create a new Account.Create Account";
    var ele_invalidtext =ObjCCI.msg_InvalidData
    var uiText= await reuse.getTextValueFromElement(ele_invalidtext)
    if (uiText===InvalidMessage){
    browser.logger.info(uiText +' is Matched with '+InvalidMessage)
    }
    // else
    // {
    // browser.logger.error(uiText +' is not Matched with '+InvalidMessage)
    // }
    reuse.ClickElement(ObjCCI.btn_createAccount,"Create Account Button")
    reuse.checkElementIsPresent(ObjCCI.txt_addressField,"Create Account Page")
}



  async validateSearchDetails(TCName)
{
   var TcRow=ReadFromXL.FindRowNum(TCName)
   DataDictLib.pushToDictionary(TcRow)
   var stringAccount = DataDictLib.getFromDictionary('Search Account')
   var stringAddress = DataDictLib.getFromDictionary('Search Address')
   var stringBusinessID = DataDictLib.getFromDictionary('Search Business Identifier')
   var stringPhoneNumber = DataDictLib.getFromDictionary('Search PhoneNumber')
   var listSearchResults= ObjCCI.lst_SearchDetails
   var listSearchPhoneNumber =ObjCCI.lst_searchPhoneNumber


}

/***************************************************************************
	* MethodName:  filterAccountDetails
	* Description: verify  Account search result
	* Parameter (if any):
	* Return type:  Void
***************************************************************************/
filterAccountDetails(TCName)
{
    var TcRow=ReadFromXL.FindRowNum(TCName)
    DataDictLib.pushToDictionary(TcRow)
    var stringfilterBy = DataDictLib.getFromDictionary('Filter By')
    var stringsubFilterBy = DataDictLib.getFromDictionary('Filter Types')
    reuse.ClickElement(ObjCCI.btn_filter,"Filter Button")
    var tab_Filter=element(by.xpath("//h5[text()='"+stringfilterBy+"']"))
    reuse.ClickElement(tab_Filter,stringfilterBy+" tab")
    var tab_subFilter=element(by.xpath("//div[label[text()='"+stringsubFilterBy+"']]//input"))
    reuse.ClickElement(tab_subFilter,stringsubFilterBy+" tab")
    this.validateSearchDetails(TCName);
    tab_subFilter.click()
    //reuse.ClickElement(ObjCCI.btn_reset,"Reset Button")
}
}
