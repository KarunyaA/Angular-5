/*tslint:disable*/
import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";
export class CommonObjects{
    url = "https://account-tst-prof2.jbhunt.com/account/";
    btn_toggle=element(by.css("[class=\"fa fa-circle-o\"]"))
}