import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";

export class CCI_LocSearchObjects{
    url = "https://account-tst.jbhunt.com/account/#/tasks";
    btn_toggle= element(by.css("[class=\"fa fa-circle-o\"]")); 
    tab_Location = element(by.cssContainingText(".routeDisplayText",'Location'));
    subTab_LocationSearch =element(by.xpath("//span[text()='Location Search']"))
    txt_LocSearch = element(by.xpath("//input[@placeholder='Search by Address, Location Name, Location Code, Phone Number or Business Identifier']"));
    icon_Search = element(by.xpath("//*[@class='icon-jbh_search form-control-feedback font18']"));  
    List_address = element.all(by.xpath("//div/datatable-body-cell[2]"));
    str_LocName = element(by.xpath("//datatable-row-wrapper[1]//datatable-body-cell[1]"));
    int_PhNumcell = element(by.xpath("//datatable-row-wrapper[1]//datatable-body-cell[2]"));
    btn_Filter = element(by.css("[title='Filter']"));
    lst_FilterOptions = element.all(by.xpath("//div[@class='panel panel-default']/div[@class='panel-heading']"));
    str_Status = element(by.xpath("//*[text()='Status']//following::span[1]"));
    
}