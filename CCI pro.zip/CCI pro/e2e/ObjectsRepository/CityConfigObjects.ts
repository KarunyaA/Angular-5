import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";

export class CCI_CityObjects{
    
    txt_SearchCityTxtBox= element(by.xpath("//input[@placeholder='Search by City']"));
    btn_SearchIcon = element(by.xpath("//*[@class='icon-jbh_search form-control-feedback font18']"));
    btn_threedots= element(by.xpath("//datatable-row-wrapper[1]//i[@class='icon-jbh_three-dots font-icons']"));
    txt_view= element(by.xpath("//datatable-row-wrapper[1]//datatable-body-cell//a[text()='View']"));
    txt_Edit=element(by.xpath("//datatable-row-wrapper[1]//datatable-body-cell//a[text()='Edit']"));
    str_CityName = element(by.xpath("//p[text()='City Name']/following::p[1]"));
    str_CityAlias = element(by.xpath("//p[text()='City Alias']/following::p[1]"));
    btn_closeViewInfo= element(by.xpath("//h4[text()='View City Information']/preceding::button[@class='close icon-jbh_close font24']"));
    ele_DefaultResults= element.all(by.xpath("//datatable-scroller/datatable-row-wrapper/datatable-body-row"));
    btn_rightarrow=element(by.css("[class='icon icon-jbh_right_arrow']"));
    btn_leftarrow=element(by.css("[class='icon icon-jbh_back']"));
    //************Create city objects************* */
    btn_OverflowMenu = element(by.xpath("//span[@title='Overflow-menu']"));
    btn_CreateCity = element(by.xpath("//span[@title='Overflow-menu']//ul//a[text()='Create New City']"));
    txt_AddCity = element(by.xpath("//h4[text()='Add New City']"));
    drpdownIcon_Country  = element(by.xpath("//*[@id='countryRef']//i[@class='caret pull-right']"));
    txt_Country =element(by.xpath("//*[@formcontrolname='country']"));
    drpdownIcon_State=element(by.xpath("//*[@id='stateRef']//i[@class='caret pull-right']"));
    txt_State =element(by.xpath("//*[@formcontrolname='state']"));
    drpdwmIcon_County = element(by.xpath("//*[@id='countyElementRef']//i[@class='caret pull-right']"));
    txt_County=element(by.xpath("//*[@formcontrolname='county']"));  
    txt_CountyDisabled=element(by.xpath("//*[@id='countyElementRef']//div[@class='ui-disabled']"));  
    drpdwnIcon_CityName=element(by.xpath("//*[@id='cityName']//i[@class='caret pull-right']"));
    txt_CityName = element(by.xpath("//*[@formcontrolname='cityName']"));
    drpdwnIcon_PostalCode=element(by.xpath("//*[@id='postalCodeRef']/div/i[@class='caret']"));
    txt_PostalCode = element(by.xpath("//*[@formcontrolname='postalCode']"));
    txt_CityAlias=element(by.xpath("//input[@id='cityAliasRef']"));
    txt_FromDate=element(by.xpath("//*[text()='Add New City']//following::*[@id='fromDateRef']//input"));
    txt_ToDate=element(by.xpath("//*[text()='Add New City']//following::*[@id='toDateRef']//input"));
    btn_add=element(by.css("[id='saveButtonRef']"));
    btn_Cancel=element(by.css("[id='closeButtonRef']"));
    btn_closeAddcity=element(by.xpath("//h4[text()='Add New City']/preceding::button[@class='close icon-jbh_close font24']"));
    txt_errorMsg=element.all(by.xpath("//*[@class='jbh-error']/div"))    
    txt_EmptyRow=element(by.xpath("//datatable-body//div[@class='empty-row']"));
    txt_readonly=element.all(by.xpath("//div[@class='modal-content']//div[@class='row']//p"));
    btn_SendComments=element(by.css("[id='sendButton']"));
    txt_commentsErrorMsg=element(by.xpath("//*[@class='jbh-error comment-message pad-top10']/div"));
    txt_CommenttextBox=element(by.xpath("//textarea[@placeholder='New Comment']"));
    txt_CreateCityError=element(by.xpath("//div[@class='jbh-notifications']/simple-notifications//simple-notification"));
    btn_filter=element(by.xpath("//a[@id='filterElement']/span"));
   

}