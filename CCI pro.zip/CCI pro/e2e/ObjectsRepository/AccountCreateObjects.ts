import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";

export class CCI_AccCreateObjects{

}
