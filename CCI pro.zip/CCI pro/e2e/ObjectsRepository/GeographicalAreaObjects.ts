/*tslint:disable*/
import { ElementFinder, browser, by, element } from "protractor";
import { protractor } from "protractor/built/ptor";
export class CCI_Objects{
    username=   element(by.id("j_username"));    
    password=   element(by.id("j_password"));
    login_btn=  element(by.className("btn-submit"));
    str_url="http://account-tst-prof2.jbhunt.com/account/";
    txt_UsrName=element(by.css("[id='username']"));
    txt_Pswd=element(by.css("[id='password']"));
    btn_SignIn = element(by.css("[name='submit']"));
    txtSearchbyPostal = element(by.xpath("//input[@placeholder='Search by Postal Code, Area Name']"))
    iconSearch = element(by.xpath("//*[@class='icon-jbh_search form-control-feedback font18']"));
    //iconSearch = element(by.xpath("//span[@title='Search']/a/i"));
    SearchDataList = element.all(by.xpath("//*[@class='visible']//datatable-body"));
    SearchDataListRows = element.all(by.xpath("datatable-row-wrapper"));
    SearchDataListCells = element.all(by.xpath("//datatable-body-cell//child::span"));
    SearchDataListCell = element.all(by.xpath("datatable-body-cell"));
    lbl_getFirstColumn = element(by.xpath("//*[@class='visible']//datatable-body//datatable-row-wrapper[2]//datatable-body-cell//child::span[1]"))
    InvalidTxtMsg = element(by.xpath("//*[@id='overflowMenuHidden']//div"));
    areaName =element(by.xpath( "areaName"));
    ddlBUclick = element(by.xpath("//*[@placeholder='Business Unit']/descendant::span/parent::span"));
    ddlBUselect = element(by.xpath("//*[@placeholder='Business Unit']/descendant::ul//a/div"));
    ddlAreatypeclick = element(by.xpath("//*[@placeholder='Area Type']/descendant::span/parent::span"));
    ddlAreatypeselect =element(by.xpath("//*[@placeholder='Area Type']/descendant::ul//a/div"));
    ddlCountryclick = element(by.xpath("//*[@placeholder='Country']/descendant::span/parent::span"));
    ddlCountryselect = element(by.xpath("//*[@placeholder='Country']/descendant::ul//a/div"));
    fromDate = element(by.xpath("//*[@id='fromDate']/descendant::input"));
    toDate = element(by.xpath("//*[@id='toDate']/descendant::input"));
    ddlIncPostalcode = element(by.xpath("//*[@id='included']/descendant::input"));
    ddlIncpotalcodeselect = element(by.xpath("//*[@id='included']/descendant::ul//a/div"));
    ddlExecPostalcode = element(by.xpath("//*[@id='excluded']/descendant::input"));
    ddlExecpotalcodeselect = element(by.xpath("//*[@id='excluded']/descendant::ul//a/div"));
    btnCreate = element(by.xpath("//*[@id='save']"));
    span_OverFlowMenu = element(by.xpath("//span[@title='Overflow-menu']//a/child::i"));
    a_CreateNewGeographicalAreas = element(by.xpath("//a[text()='Create New Geographical Areas']"));
    dottedLink = element(by.xpath("//datatable-body-cell//child::span//i"));
    innerDottedlink = element(by.xpath("//descendant::li/a"));
    btnDeactivate = element(by.xpath("//button[@id='status']"));
    btnCancel = element(by.id("cancel"));
    btnCross = element(by.xpath("//button[@class='close icon-jbh_close formBtn']"));
    txtarea_view = element(by.id("text"));
    btn_send = element(by.id("send"));
    btn_Filter = element(by.css("[title='Filter']"));
    lst_FilterOptions = element.all(by.xpath("//div[@class='panel panel-default']/div[@class='panel-heading']"));
    btn_BU_reset=element(by.buttonText('Reset'));
    btn_AT_reset=element(by.id("resetLnk"))[2];
    btn_ST_reset=element(by.id("resetLnk"))[3];
    lst_searchBusinessUnit=element.all(by.xpath("//*[@class='visible']//datatable-body//datatable-row-wrapper[1]//datatable-body-cell[2]//span"))
    lst_searchAreaType=element.all(by.xpath("//*[@class='visible']//datatable-body//datatable-row-wrapper[1]//datatable-body-cell[3]//span"))
    lst_searchStatus=element.all(by.xpath("//*[@class='visible']//datatable-body//datatable-row-wrapper[1]//datatable-body-cell[4]//span"))
    btntablemenu=element(by.id("tableMenu"));
    CreateNewGeographicalArea=element(by.className("dropdown-item add"));
    txtarea_areaName=element(by.xpath("//input[@placeholder='Area Name']"))
    //dropdown_BU=element(by.className("ui-select-placeholder text-muted"));
    //dropdown_BU=element(by.css("[formcontrolname='businessUnit']"));
    dropdown_BU=element(by.xpath("//ng-select[@formcontrolname='businessUnit']//following::span[text()='Business Unit']"))
    dropdown_BUText=element(by.xpath("//input[@placeholder='Business Unit']"))
    
    //dropdown_AreaType=element(by.className("ui-select-match-text pull-left ui-select-allow-clear"));
    dropdown_AreaType=element(by.css("[formcontrolname='areaType']"));
    header_SignIn=element(by.id("heading1"));
    txt_SignInUser=element(by.css("[placeholder='Email or Username']"));
    txt_SignInPwd=element(by.css("[placeholder='Password']"));
    btn_SignInSubmit=element(by.css("[name='submit']"));
}