//Importing Neeeded NPM Packages from node modules
const { SpecReporter } = require('jasmine-spec-reporter');
var fs = require('fs');
var path = require("path");
var mkdirp = require('mkdirp');
var log4js = require('log4js');
//Timestamp Creation
const now = new Date();
exports.report_name = 'Report-' + now.getFullYear() + "-" + (now.getMonth() + 1) + "-" + now.getDate() + "-" + now.getHours() + "-" + now.getMinutes() + "-" + now.getSeconds();
exports.logfile_name = 'results-' + now.getFullYear() + "-" + (now.getMonth() + 1) + "-" + now.getDate() + "-" + now.getHours() + "-" + now.getMinutes() + "-" + now.getSeconds();
//Path Location Used Across Framework
var targetfolder = path.resolve("./") + '\\' + 'e2e'+'\\'+'Target' + '\\';
var resultpath =`${targetfolder}` + exports.report_name + '\\' + exports.logfile_name + '\\';
var dir =`${targetfolder}`+ 'Html' + '\\' + exports.report_name;
exports.screenshotpath = `${targetfolder}` + 'Screenshots' + '\\' + exports.report_name;
var logpath =`${targetfolder}` + 'logs' + '\\' + exports.report_name;
//Folder Creation
console.log(dir);
const mkdirSync = function (dir) {
    try {
        fs.mkdirSync(dir);
    }
    catch (err) {
        if (err.code !== 'EEXIST')
            throw err;
    }
};
mkdirp(exports.screenshotpath, function (err) {
});
//Main Config File
exports.config = {
  allScriptsTimeout: 11000,
  specs: [
    './e2e/**/JBH_CCI_AccountCreationTC023.ts'
  ],
  capabilities: {
    'browserName': 'chrome'
  },
  directConnect: true,
  baseUrl: 'http://localhost:4200/',
  framework: 'jasmine',
  useAllAngular2AppRoots: true,
  jasmineNodeOpts: {
    showColors: true,
    defaultTimeoutInterval: 30000,
    print: function() {}
  },
  beforeLaunch() {
    log4js.configure({
        appenders: {
            fileLog: { type: 'file', filename: logpath + '\\' + 'ExecutionLog.log' },
            console: { type: 'log4js-protractor-appender' }
        },
        categories: {
            file: { appenders: ['fileLog'], level: 'error' },
            another: { appenders: ['console'], level: 'trace' },
            default: { appenders: ['console', 'fileLog'], level: 'trace' }
        }
    });
},
  onPrepare() {
     let globals = require("protractor");
   let browser = globals.browser;
   browser.ignoreSynchronization=true;
   browser.manage().window().maximize();
   browser.manage().timeouts().implicitlyWait(5000);
   browser.logger = log4js.getLogger('protractorLog4js');
    require('ts-node').register({
      project: 'e2e/tsconfig.e2e.json'
    });
    jasmine.getEnv().addReporter(new SpecReporter({ spec: { displayStacktrace: true } }));
  }
};
