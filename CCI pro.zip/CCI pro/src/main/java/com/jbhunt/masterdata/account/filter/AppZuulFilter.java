package com.jbhunt.masterdata.account.filter;

import javax.servlet.http.HttpSession;

import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.jbhunt.biz.securepid.PIDCredentials;
import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class AppZuulFilter extends ZuulFilter {

    private PIDCredentials ldapPidCredential;
    private static final String SESS_USER = "jbhSecurityUserId";

    @Autowired
    public AppZuulFilter(PIDCredentials ldapPidCredential) {
        this.ldapPidCredential = ldapPidCredential;
    }

    @Override
    public Object run() {
        RequestContext ctx = RequestContext.getCurrentContext();
        final String auth = ldapPidCredential.getUsername() + ":" + ldapPidCredential.getPassword();
        final byte[] encodedAuth = Base64.encodeBase64(auth.getBytes());
        final String authHeader = "Basic " + new String(encodedAuth);
        ctx.getZuulRequestHeaders().put("Authorization", authHeader);
        String userId = getUserId();
        ctx.getZuulRequestHeaders().put("usernametoken", userId);
        log.debug(
                "AppZuilFilter-> PIDUserName -> " + ldapPidCredential.getUsername() + " Logged In UserID -> " + userId);
        return null;
    }

    @Override
    public boolean shouldFilter() {
        return true;
    }

    @Override
    public int filterOrder() {
        return 0;
    }

    @Override
    public String filterType() {
        return "pre";
    }

    private String getUserId() {
        ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
        HttpSession session = attr.getRequest().getSession(true);
        if (session.getAttribute(SESS_USER) != null) {
            return session.getAttribute(SESS_USER).toString().trim().toUpperCase();
        }
        return null;
    }
}
