package com.jbhunt.masterdata.account.configuration;

import com.jbhunt.biz.securepid.FusePIDReader;
import com.jbhunt.biz.securepid.PIDCredentials;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AccountConfiguration {

    @Bean
    public PIDCredentials jbhLdapCredentials() {
        FusePIDReader fusePIDReader = new FusePIDReader("masterdataaccount");
        return fusePIDReader.readPIDCredentials("activedirectory");
    }

}