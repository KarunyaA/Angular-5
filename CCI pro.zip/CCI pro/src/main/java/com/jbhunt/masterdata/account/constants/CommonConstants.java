package com.jbhunt.masterdata.account.constants;

public final class CommonConstants {

    public static final String CREDITUPLOADDOCUMENT_URI = "/credituploadfile/{partyID}/{documentTitle}/{nationalAccountCode}/{indexUserId}";
    public static final String CREDITDOCUMENT_URI = "/uploadservices";
    public static final String CREDITDOCUMENT_ACCOUNT_URI = "/accounts/";
    public static final String CREDITDOCUMENT_DOC_URI = "/documents";
    public static final String DOCUMENT_TITLE = "documentTitle";
    public static final String CUSTOMER_CODE = "nationalAccountCode";
    public static final String PARTY_ID = "partyID";
    public static final String FILE_NAME = "uploadedFileName";
    public static final String INDEX_USER_ID = "indexUserId";
    public static final String CONSUME_TYPE = "multipart/form-data";

    private CommonConstants() {
    }
}
