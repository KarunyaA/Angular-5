package com.jbhunt.masterdata.account.controller;

import java.io.IOException;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import com.jbhunt.masterdata.account.properties.AccountProperties;
import com.jbhunt.masterdata.location.dto.BulkUploadResponseDTO;
import com.jbhunt.masterdata.location.dto.LocationDocumentDTO;

@RestController
@RequestMapping(value = "/mdmservices")
public class LocationBulkUploadController {

    private final RestTemplate restTemplate;
    private final AccountProperties accountProperties;

    public LocationBulkUploadController(RestTemplate restTemplate, AccountProperties accountProperties) {
        this.restTemplate = restTemplate;
        this.accountProperties = accountProperties;
    }

    @RequestMapping(value = "/uploadFile", method = RequestMethod.POST, consumes = "multipart/form-data")
    @ResponseBody
    public ResponseEntity<BulkUploadResponseDTO> bulkLocationUpload(
            @RequestParam("uploadedFileName") MultipartFile multipartfile) throws IOException {
        LocationDocumentDTO documentDTO = new LocationDocumentDTO();
        documentDTO.setUploadType(1);
        documentDTO.setFileContent(multipartfile.getBytes());
        ResponseEntity<BulkUploadResponseDTO> responseEntity = this.restTemplate.exchange(
                accountProperties.getLocationBaseUrl() + "/locationbulkuploads", HttpMethod.POST,
                new HttpEntity<>(documentDTO), BulkUploadResponseDTO.class);
        return ResponseEntity.ok(responseEntity.getBody());
    }

    @PostMapping(value = "/uploadlocationpostalcodefile", consumes = "multipart/form-data")
    public ResponseEntity<BulkUploadResponseDTO> bulkLocationPostalCodeUpload(
            @RequestParam("uploadedFileName") MultipartFile multipartfile) throws IOException {
        LocationDocumentDTO documentDTO = new LocationDocumentDTO();
        documentDTO.setUploadType(2);
        documentDTO.setFileContent(multipartfile.getBytes());
        ResponseEntity<BulkUploadResponseDTO> responseEntity = this.restTemplate.exchange(
                accountProperties.getLocationBaseUrl() + "/locations/upload/postalcodes", HttpMethod.POST,
                new HttpEntity<>(documentDTO), BulkUploadResponseDTO.class);
        return ResponseEntity.ok(responseEntity.getBody());
    }

}