package com.jbhunt.masterdata.account.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class AppController {

    @RequestMapping({ "/dashboard", "/tasks/**", "/accounts/manageaccounts", "/accounts/createaccount/**",
            "/locations/managelocations", "/locations/createlocation/**", "/warehousesearch", "/settings",
            "/relationshipcontacts/**", "/settings/cityconfig", "/accountprofile/**", "/locationdetails/**",
            "/commitments/**", "/settings/geography", "/serviceguide/**", "/error401", "/error404", "/error500",
            "/mdmservices" })
    public String home() {
        return "forward:/index.html";
    }

}