package com.jbhunt.masterdata.account.configuration;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;

import org.springframework.web.WebApplicationInitializer;

public class ApplicationInitializer implements WebApplicationInitializer {

    @Override
    public void onStartup(ServletContext context) throws ServletException {
        // FilterRegistration characterEncodingFilter =
        // context.addFilter("encodingFilter", CharacterEncodingFilter.class);
        // characterEncodingFilter.setInitParameter("encoding", "UTF-8");
        // characterEncodingFilter.setInitParameter("forceEncoding", "true");
        // characterEncodingFilter.addMappingForUrlPatterns(null, false, "/*");
        // FilterRegistration authenticationFilter =
        // context.addFilter("jbhSSOFilter", AuthenticationFilter.class);
        // authenticationFilter.setInitParameter("app.filter.wrap.request",
        // "true");
        // authenticationFilter.addMappingForServletNames(null, true, "app");
        // authenticationFilter.addMappingForUrlPatterns(null, false, "/*");
        // authenticationFilter.addMappingForUrlPatterns(null, false, "*.html");
        // FilterRegistration authorizationFilter =
        // context.addFilter("AuthFilter",
        // AuthorizationEnforcementFilter.class);
        // authorizationFilter.setInitParameter("loginUrl", "/signin.html");
        // authorizationFilter.setInitParameter("stopFilterProcess", "true");
        // authorizationFilter.setInitParameter("notAuthorizedUrl",
        // "/securepages/notauthorized");
        // authorizationFilter.setInitParameter("secureUrls",
        // "/account/* /account/user /user /masterdataaccountservices/*
        // /masterdatalocationservices/* /masterdatageographyservices/*
        // /ws_capacity_commitments/*");
        // authorizationFilter.setInitParameter("useridResolverType",
        // "Container");
        // authorizationFilter.addMappingForUrlPatterns(null, true,
        // "/home/user");
        // authorizationFilter.addMappingForUrlPatterns(null, true, "/user");
        // context.addFilter("LogoutFilter",
        // LogoutFilter.class).addMappingForUrlPatterns(null, true, "/logout/");
    }

}