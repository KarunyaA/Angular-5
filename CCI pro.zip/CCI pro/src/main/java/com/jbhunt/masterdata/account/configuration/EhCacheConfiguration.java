package com.jbhunt.masterdata.account.configuration;

import java.net.MalformedURLException;

import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.ehcache.EhCacheCacheManager;
import org.springframework.cache.ehcache.EhCacheManagerFactoryBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.UrlResource;

import com.jbhunt.masterdata.account.properties.AccountProperties;

@Configuration
@EnableCaching
public class EhCacheConfiguration {

    private final AccountProperties accountProperties;
    
    public EhCacheConfiguration(AccountProperties accountProperties) {
        this.accountProperties = accountProperties;
    }

    @Bean
    @Primary
    public CacheManager masterdataAccountLocationCacheManager() throws MalformedURLException {
        return new EhCacheCacheManager(getEhCacheFactory().getObject());
    }   
    
    @Bean
    public EhCacheManagerFactoryBean getEhCacheFactory() throws MalformedURLException {
        EhCacheManagerFactoryBean factoryBean = new EhCacheManagerFactoryBean();
        factoryBean.setConfigLocation(new UrlResource(accountProperties.getEhcacheUrl()));
        return factoryBean;
    }

}