package com.jbhunt.masterdata.account.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping(value = "/mdmservices")
public class BulkUploadController {

    public String testController() {
        log.debug("testController  Called 0 ");
        return "TEST";
    }

    public String testController1() {
        log.debug("testController  Called 1 ");
        return "TEST1";
    }

    public String testController2() {
        log.debug("testController  Called 2");
        return "TEST2";
    }

}