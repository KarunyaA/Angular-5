package com.jbhunt.masterdata.account.controller;

import java.io.IOException;
import java.util.Base64;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import com.jbhunt.masterdata.account.constants.CommonConstants;
import com.jbhunt.masterdata.account.document.dto.DocumentDTO;
import com.jbhunt.masterdata.account.properties.AccountProperties;

@RestController
@RequestMapping(value = CommonConstants.CREDITDOCUMENT_URI)
public class DocumentUploadController {

    private final RestTemplate restTemplate;
    private final AccountProperties accountProperties;

    public DocumentUploadController(RestTemplate restTemplate, AccountProperties accountProperties) {
        this.restTemplate = restTemplate;
        this.accountProperties = accountProperties;
    }

    @PostMapping(value = CommonConstants.CREDITUPLOADDOCUMENT_URI, consumes = CommonConstants.CONSUME_TYPE)
    public ResponseEntity<Boolean> credituploadFile(@PathVariable(CommonConstants.DOCUMENT_TITLE) String documentTitle,
            @PathVariable(CommonConstants.CUSTOMER_CODE) String nationalAccountCode,
            @PathVariable(CommonConstants.PARTY_ID) String partyID,
            @PathVariable(CommonConstants.INDEX_USER_ID) String indexUserID,
            @RequestParam(CommonConstants.FILE_NAME) MultipartFile multipartfile) throws IOException {
        DocumentDTO documentDTO = new DocumentDTO();
        String encoded = Base64.getEncoder().encodeToString(multipartfile.getBytes());
        documentDTO.setDocumentContent(encoded);
        documentDTO.setDocumentTitle(documentTitle);
        documentDTO.setFileName(multipartfile.getOriginalFilename());
        documentDTO.setBillToCode(nationalAccountCode);
        documentDTO.setIndexUserId(indexUserID);
        ResponseEntity<Boolean> responseEntity = this.restTemplate.exchange(
                accountProperties.getAccountBaseUrl() + CommonConstants.CREDITDOCUMENT_ACCOUNT_URI + nationalAccountCode
                        + CommonConstants.CREDITDOCUMENT_DOC_URI,
                HttpMethod.POST, new HttpEntity<>(documentDTO), Boolean.class);
        return ResponseEntity.ok(responseEntity.getBody());
    }

}