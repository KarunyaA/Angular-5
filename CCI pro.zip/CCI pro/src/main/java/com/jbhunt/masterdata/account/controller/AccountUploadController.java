package com.jbhunt.masterdata.account.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping(value = "/mdmservices")
public class AccountUploadController {

    public String testController() {
        log.debug("testController  Called 0 ");
        return "TEST";
    }

    public String testController1() {
        log.debug("testController  Called 1 ");
        return "TEST1";
    }

    public String testController2() {
        log.debug("testController  Called 2");
        return "TEST2";
    }

    public String testController3() {
        log.debug("testController  Called 3 ");
        return "TEST3";
    }

    public String testController4() {
        log.debug("testController  Called 4 ");
        return "TEST4";
    }

    public String testController5() {
        log.debug("testController  Called 5");
        return "TEST5";
    }

    public String testController6() {
        log.debug("testController  Called 6 ");
        return "TEST6";
    }

    public String testController7() {
        log.debug("testController  Called 7 ");
        return "TEST7";
    }

    public String testController8() {
        log.debug("testController  Called 8");
        return "TEST8";
    }

    public String testController9() {
        log.debug("testController  Called 9 ");
        return "TEST9";
    }

    public String testController10() {
        log.debug("testController  Called 10");
        return "TEST10";
    }

    public String testController11() {
        log.debug("testController  Called 11");
        return "TEST11";
    }
}
