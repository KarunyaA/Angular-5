package com.jbhunt.masterdata.account.interceptor;

import java.io.IOException;

import javax.servlet.http.HttpSession;

import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class BasicAuthInterceptor implements ClientHttpRequestInterceptor {

    private final String username;
    private final String password;

    private static final String SESS_USER = "jbhSecurityUserId";

    public BasicAuthInterceptor(String username, String password) {
        this.username = username;
        this.password = password;
    }

    @Override
    public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution)
            throws IOException {
        log.debug("BasicAuthInterceptor.intercept() is called");
        final String auth = username + ":" + password;
        final byte[] encodedAuth = Base64.encodeBase64(auth.getBytes());
        final String authHeader = "Basic " + new String(encodedAuth);
        request.getHeaders().add("Authorization", authHeader);
        String userId = getUserId();
        request.getHeaders().add("usernametoken", userId);
        log.debug("BasicAuthInterceptor-> PIDUserName -> " + username + " Logged In UserID -> " + userId);
        return execution.execute(request, body);
    }

    private String getUserId() {
        ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
        HttpSession session = attr.getRequest().getSession(true);
        if (session.getAttribute(SESS_USER) != null) {
            return session.getAttribute(SESS_USER).toString().trim().toUpperCase();
        }
        return null;
    }

}