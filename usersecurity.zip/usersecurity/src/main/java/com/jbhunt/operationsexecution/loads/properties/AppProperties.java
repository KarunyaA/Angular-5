package com.jbhunt.operationsexecution.loads.properties;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

@Data
@RefreshScope
@Component
public class AppProperties {

  @Value("${ldapUserEndpoints.domain}")
  private String ldapEndpointURL;

  @Value("${ehcache.url}")
	private String ehcacheUrl;

//  @Value("${websocket.messaging.relayHost}")
//  private String host;
//
//  @Value("${websocket.messaging.relayPort}")
//  private Integer port;
//
//  @Value("${websocket.messaging.topic}")
//  private String topicName;
}
