package com.jbhunt.operationsexecution.loads.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class AppController {

	@RequestMapping({ "/dashboard", "/capacitysettings", "ldc", "/settings", "advancec-search/**" })
	public String home() {
		return "forward:/index.html";
	}

}