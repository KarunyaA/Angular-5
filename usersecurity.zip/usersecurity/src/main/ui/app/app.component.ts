import { Component, HostListener } from '@angular/core';
import { Message } from 'primeng/api';
import { ShortcutkeyService } from './shared/jbh-app-services/shortcutkey.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  public isLocked = false;
  /**
   * sidebar states
   * @type {any}
   */
  public sidebar: any = {
    left: {
      open: false,
      locked: false,
      changing: false
    },
    right: {
      open: false
    }
  };
  public breakPoint = '';

  public platform = {};
  msgs: Message[] = [];

  /**
   * [constructor description]
   * @param {BreakpointService} private _breakpointService [description]
   * @param {WindowService} private _window [description]
   */
  constructor(private shortcuts: ShortcutkeyService) { }
  /**
   * resetSidebarState sets sidebar locked and open states back to default (false)
   * @param {[type]} event [description]
   */
  resetSidebarState(event) {
    this.sidebar.left.locked = false;
    this.sidebar.left.open = false;
    this.sidebar.right.open = false;
  }

  /**
   * toggleSidebarLeft is called when a left sidebar toggle event is emitted
   * @param {[type]} event [description]
   */
  toggleSidebarLeft(event) {
    this.sidebar.left.locked = !this.sidebar.left.locked;
    this.sidebar.left.open = !this.sidebar.left.open;
    this.sidebar.right.open = false;
  }

  /**
   * toggleSidebarLeftLock is called when the left sidebar lock toggle event is emitted
   * @param {[type]} event [description]
   */
  toggleSidebarLeftLock(evnet) {
    this.sidebar.left.locked = !this.sidebar.left.locked;
  }

  /**
   * toggleSidebarLeftOpen
   * @param {[type]} state [description]
   */
  toggleSidebarLeftOpen(state) {
    this.sidebar.left.open = state;
  }

  @HostListener('window:keyup', ['$event'])
  keyboardInput(event: any): void {
      console.log(this.shortcuts.getKeyCode(event));
      this.shortcuts.saveData({
          keyCode: this.shortcuts.getKeyCode(event),
          eventElement: event.target
      });
  }
}
