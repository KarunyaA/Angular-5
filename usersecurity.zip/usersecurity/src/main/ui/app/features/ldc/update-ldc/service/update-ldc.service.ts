import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Http, RequestOptions } from '@angular/http';
import { AppConfig } from '../../../../../config/app.config';
import { AppLocalConfig } from '../../../../../config/app.local.config';
import { environment } from '../../../../../environments/environment';
@Injectable()
export class UpdateLdcService {
  endpoints: any;
  constructor(private http: HttpClient) {
    const appConfig = (environment.envName === 'local') ? AppLocalConfig.getConfig() : AppConfig.getConfig();
      this.endpoints = appConfig.api;
  }

  addLDC(data: Object): Observable<Response[]> {
    const url = this.endpoints.ldc.saveldc;
    return this.http.post(url, data)
    .map((res: Response) => {
      const responseJson: any = res;
      return responseJson;
    });
  }
  updateLDC(data: Object, capacityid: number) {
    const capacityID = capacityid;
    const url = this.endpoints.ldc.updateldc + capacityID;
    return this.http.patch(url, data)
    .map((res: Response) => {
      const responseJson: any = res;
      return responseJson;
    });

  }
}
