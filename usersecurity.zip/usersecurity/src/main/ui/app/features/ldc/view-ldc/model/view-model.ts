import { EventEmitter } from '@angular/core';

import { MenuItem } from 'primeng/api';
import { FormGroup } from '@angular/forms';

export interface UserSavedDataModel {
  userSavedSearchID?: number;
  personID: string;
  applicationSearchFunctionCode: string;
  userSearchName: string;
  userSearchDefaultIndicator: string;
  userSearchCriteriaContent: string;
}

export interface LocationDataModel {
  size: number;
  _source: Array<string>;
  query: object;
}

export class ViewModel {
    userRole: string;
    dailyRouteObservable: any;
    spinnerFormGroup: FormGroup;
    ldcTypeaheadFormGroup: FormGroup;
    specificDateAddOrRemoveFromFinal: EventEmitter<any>;
    userSavedSearchID: number;
    userSavedData: UserSavedDataModel;
    getLocationID: LocationDataModel;

    constructor() {}
}

