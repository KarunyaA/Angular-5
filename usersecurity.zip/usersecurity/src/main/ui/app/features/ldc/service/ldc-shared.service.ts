import { Output, EventEmitter, Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Injectable()
export class LdcSharedService {

  private sharingData: BehaviorSubject<boolean[]>;
  constructor() {
    this.sharingData = <BehaviorSubject<boolean[]>>new BehaviorSubject([]);
   }

  saveUpdatedData(data): void {
    this.sharingData.next(data);
  }

  getUpdatedData() {
      return this.sharingData;
  }

}
