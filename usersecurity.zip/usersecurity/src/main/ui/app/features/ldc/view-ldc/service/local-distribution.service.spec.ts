import { TestBed, inject } from '@angular/core/testing';

import { LocalDistributionService } from './local-distribution.service';

describe('LocalDistributionService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [LocalDistributionService]
    });
  });

  it('should be created', inject([LocalDistributionService], (service: LocalDistributionService) => {
    expect(service).toBeTruthy();
  }));
});
