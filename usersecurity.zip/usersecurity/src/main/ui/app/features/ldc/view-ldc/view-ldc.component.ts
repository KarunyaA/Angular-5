import { Component, Compiler, ComponentFactoryResolver, OnInit, OnDestroy, ViewChild, ElementRef, HostListener } from '@angular/core';
import { AbstractControl, FormGroup, FormArray, FormBuilder, Validators, FormControl } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { timer } from 'rxjs/observable/timer';

import { MenuItem } from 'primeng/api';
import { LocalDistributionService } from './service/local-distribution.service';
import { ViewModel } from './model/view-model';
import { Index } from '../ldcenum/index.enum';
import { ConfirmationService } from 'primeng/api';
import { Message } from 'primeng/components/common/api';
import { GrowlModule } from 'primeng/growl';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { FinalMileCapacityComponent } from '../final-mile-capacity/final-mile-capacity.component';
import { ShortcutkeyService } from 'app/shared/jbh-app-services/shortcutkey.service';
import * as _ from 'lodash';

@Component({
  selector: 'app-view-ldc',
  templateUrl: './view-ldc.component.html',
  styleUrls: ['./view-ldc.component.scss'],
})

export class ViewLdcComponent implements OnInit, OnDestroy {

  /**Variable declarations */
  capacityID: number;
  dailyRouteCapacity: Array<Object>;
  eventName: string;
  filteredLocationCenter: object;
  ldcData: Array<Object>;
  ldcIndex = Index;
  ldcLocationID: Object;
  ldcViewData: Object;
  locationName: string;
  msgs: Message[] = [];
  myForm: FormGroup;
  myValue = new FormControl([]);
  selectedIndex = 0;
  specificDates: Array<Object>;
  userId: string;
  viewModel: ViewModel;
  @ViewChild('finalMileCapacityRef') finalMileCapacityRef: any;
  @ViewChild('finalMileTab') finalMileTab: ElementRef;
  @ViewChild('dcsTab') dcsTab: ElementRef;
  @ViewChild('popupNo') popupNo: ElementRef;
  @ViewChild('popupYes') popupYes: ElementRef;
  @ViewChild('confirmDialog') confirmDialog: ElementRef;

  constructor(private formBuilder: FormBuilder, private ldcService: LocalDistributionService,
     private confirmationService: ConfirmationService,
  public componentFactoryResolver: ComponentFactoryResolver,
  private shortcutService: ShortcutkeyService) {
  }

  ngOnInit() {
    this.viewModel = new ViewModel();
    this.setKeyboardShortcuts();
    this.viewModel.userRole = 'LDCManager';
    this.ldcService.getUserSearch().subscribe((userSavedSearches: any) => {
    });
  }

  ngOnDestroy() {
    if (this.viewModel.dailyRouteObservable) {
      this.viewModel.dailyRouteObservable.unsubscribe();
    }

  }

  onChange(tabIndex: any): void {
    this.selectedIndex = tabIndex.index;
    if (tabIndex.index !== 0) {
      this.onBlurMethod();
    }
    if (tabIndex.index === 0) {
      this.finalMileCapacityRef.ngOnInit();
    }
  }
  onBlurMethod() {
    if ((typeof (this.viewModel.ldcTypeaheadFormGroup) !== 'undefined' && this.viewModel.ldcTypeaheadFormGroup.dirty) ||
      (typeof (this.viewModel.spinnerFormGroup) !== 'undefined' && this.viewModel.spinnerFormGroup.dirty)
    || (typeof (this.viewModel.specificDateAddOrRemoveFromFinal) !== 'undefined' && this.viewModel.specificDateAddOrRemoveFromFinal)) {
      this.confirmationService.confirm({
        message: 'You are about to lose all the changes. Do you want to proceed?',
        header: 'Confirmation',
        reject: () => {
          this.selectedIndex = 0;
          this.getUserSearch();
        },
        accept: () => {
        },
      });
    }
  }
  getALLocationInfo(): void {
    this.ldcData = [];
    this.viewModel.dailyRouteObservable = this.ldcService.getLocalCenters().subscribe((locations: any) => {
      if (!_.isEmpty(locations)) {
        const locationArray = locations['hits']['hits'];
        if (!_.isEmpty(locationArray)) {
          let locationObj;
          locationArray.forEach(element => {
            locationObj = {
              locationname: element['_source']['LocationName'],
              locationID: element['_source']['LocationID'],
              locationCode: element['_source']['LocationCode']
            };
            this.ldcData.push(locationObj);
          });
          this.filteredLocationCenter = this.ldcData.sort();
          const filterIndex = this.ldcIndex.indexZero;
          this.myForm.controls['ldcName'].patchValue({
            name: ` ${this.
              filteredLocationCenter[filterIndex]['locationname']} ${this.filteredLocationCenter[filterIndex]['locationCode']}`
          });
          this.getLDCDailyRoutesCapacity(this.filteredLocationCenter[filterIndex]['locationID']);
        }
        this.locationName = this.filteredLocationCenter[this.ldcIndex.indexZero]['locationname'];
      }
    });

  }
  getLDCDailyRoutesCapacity(locationID: number): void {
    this.viewModel.dailyRouteObservable =
    this.ldcService.getDailyRouteCapacity(locationID).subscribe((dailyRoutes: any) => {
      this.ldcViewData = {};
      if (!_.isEmpty(dailyRoutes)) {
        if (dailyRoutes['localDistributionCenterCapacityId']) {
          this.capacityID = dailyRoutes['localDistributionCenterCapacityId'];
        }
        const dailyRouteArray = dailyRoutes['localDistributionCenterDayOfWeekCapacities'];
        const speicificArray = dailyRoutes['localDistributionCenterDateCapacities'];
        const dailyLimitData = [];
        const specificDatesData = [];
        let dailyObj = {};
        dailyRouteArray.forEach(element => {
          dailyObj = {
            ldcday: element['weekDayCode'],
            ldclimit: element['localDistributionCenterRouteCapacityCount'],
            ldcrouteid: element['localDistributionCenterDayOfWeekCapacityId']
          };
          dailyLimitData.push(dailyObj);
        });
        this.dailyRouteCapacity = dailyLimitData;
        let specificObj = {};
        speicificArray.forEach(element => {
          specificObj = {
            specificCount: element['localDistributionCenterRouteCapacityCount'],
            specificDate: element['localDistributionCenterCapacityDate'],
            specificID: element['localDistributionCenterDateCapacityId']
          };
          specificDatesData.push(specificObj);
        });

        this.specificDates = specificDatesData;
        if (this.capacityID) {
          this.ldcViewData = {
            'locationId': locationID,
            'loc': this.locationName,
            'capacityID': this.capacityID,
            'dailyRoute': this.dailyRouteCapacity,
            'specificDates': this.specificDates
          };
        } else {
          this.ldcViewData = {
            'locationId': locationID,
            'loc': this.locationName,
            'dailyRoute': this.dailyRouteCapacity,
            'specificDates': this.specificDates
          };
        }
      }
    }, (error: Error) => {
      this.ldcViewData = {
        'locationId': locationID,
        'loc': this.locationName,
        'capacityID': '',
        'dailyRoute': [],
        'specificDates': []
      };
    });

  }
  getUserSearch() {
    this.ldcService.getUserInfo().subscribe((userInfo: any) => {
      this.userId = userInfo.userId;
    });
    this.ldcService.getUserSearch().subscribe((userSavedSearches: any) => {
      if (userSavedSearches) {
        this.viewModel.userSavedSearchID = userSavedSearches['userSavedSearchID'];
      }
      const userSearchCriteria = { 'LocationDistributionCenter': this.eventName };
      if (this.viewModel.userSavedSearchID) {
        this.viewModel.userSavedData = {
          userSavedSearchID: this.viewModel.userSavedSearchID,
          personID: this.userId,
          applicationSearchFunctionCode: 'CAP001',
          userSearchName: 'LdcCapacitySearch',
          userSearchDefaultIndicator: 'N',
          userSearchCriteriaContent: JSON.stringify(userSearchCriteria)
        };
      } else {
        this.viewModel.userSavedData = {
          personID: this.userId,
          applicationSearchFunctionCode: 'CAP001',
          userSearchName: 'LdcCapacitySearch',
          userSearchDefaultIndicator: 'N',
          userSearchCriteriaContent: JSON.stringify(userSearchCriteria)
        };
      }

      this.ldcService.saveUserSearch(this.viewModel.userSavedData).subscribe((saveUser: any) => {
      });
    });

  }

  filterLocations(locations: any): Object {
    const filtered = [];
    for (let i = 0; i < locations.length; i++) {
      const location = locations[i];
      if (location.locationname) {
        filtered.push({ 'name': location.locationname + location.locationCode, 'id': location.locationID });
      }
    }
    return filtered;
  }
  specificDateAddOrRemoveFromFinal(specificDateAddOrRemoveFromFinal): void {
    this.viewModel.specificDateAddOrRemoveFromFinal = specificDateAddOrRemoveFromFinal;
  }

  ldcTypeaheadFormGroup(ldcTypeaheadFormGroup): void {
  this.viewModel.ldcTypeaheadFormGroup = ldcTypeaheadFormGroup;
  }
  spinnerFormGroupMethodFromFinal(spinnerFormGroup): void {
    this.viewModel.spinnerFormGroup = spinnerFormGroup;
  }
  private setKeyboardShortcuts(): void {
    this.shortcutService.getData().subscribe(data => {
        if (data) {
          switch (data['keyCode']) {
            case 'alt+1':
                  this.finalMileCapacityRef['autocomplete']['inputEL']['nativeElement'].focus();
                  break;
              case 'alt+2':
                  this.selectedIndex = 0;
                  break;
              case 'ctrl+shift+A' || 'ctrl+shift+a' :
                if (this.confirmDialog['visible']) {
                    this.popupYes.nativeElement.click();
                } else {
                    this.finalMileCapacityRef['updateBtn']['nativeElement'].click();
                }
                 break;
              case 'ctrl+shift+B' || 'ctrl+shift+b':
                  this.popupNo.nativeElement.click();
                  break;
              default:
                  break;
          }
       }
    });
  }

  @HostListener('window:keyup', ['$event'])
  keyboardInput(event: any): void {
      this.shortcutService.saveData({
          keyCode: this.shortcutService.getKeyCode(event),
          eventElement: event.target
      });
  }

}
