import { Component, OnInit } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { BreadCrumb } from './model/bread-crumb';
@Component({
  selector: 'app-breadcrumb',
  templateUrl: './breadcrumb.component.html',
  styleUrls: ['./breadcrumb.component.scss']
})
export class BreadcrumbComponent implements OnInit {


   breadCrumbModel: BreadCrumb;


  ngOnInit() {
   this.breadCrumbModel = new BreadCrumb();
  }
}
