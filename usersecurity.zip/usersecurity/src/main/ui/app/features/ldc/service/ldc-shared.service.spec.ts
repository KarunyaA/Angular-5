import { TestBed, inject } from '@angular/core/testing';

import { LdcSharedService } from './ldc-shared.service';

describe('LdcSharedService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [LdcSharedService]
    });
  });

  it('should be created', inject([LdcSharedService], (service: LdcSharedService) => {
    expect(service).toBeTruthy();
  }));
});
