export class BreadCrumb {
    items = [

        { label: 'Home',  routerLink:  ['/dashboard'] },
        { label:  'Capacity Settings',  routerLink:  ['/ldc'] }
      ];
}
