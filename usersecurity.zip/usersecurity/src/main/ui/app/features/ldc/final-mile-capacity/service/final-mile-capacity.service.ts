import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Http, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { AppConfig } from '../../../../../config/app.config';
import { AppLocalConfig } from '../../../../../config/app.local.config';
import { environment } from '../../../../../environments/environment';
@Injectable()
export class FinalMileCapacityService {

  endpoints: any;

  constructor(private http: HttpClient) {
    const appConfig = (environment.envName === 'local') ? AppLocalConfig.getConfig() : AppConfig.getConfig();
    this.endpoints = appConfig.api;
  }

  getLocalCenters(): Observable<Response[]> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const url = this.endpoints.ldc.getlocation;
    return this.http.get<any>(url)
      .map((res: Response) => {
        const responseJson: any = res;
        return responseJson;
      });
  }
  getDailyRouteCapacity(locationID: number): Observable<Response[]> {
    let url = this.endpoints.ldc.getldccapacity;
    url += '?locationId=' + locationID;
    return this.http.get(url)
      .map((res: Response) => {
        const responseJson: any = res;
        return responseJson;
      });
  }
  getUserSearch(): Observable<Response[]> {
    const userId = 'jcnt311';
    const url = this.endpoints.ldc.getusersearch + '?userID=' + userId;
    return this.http.get(url)
    .map((res: Response) => {
      const responseJson: any = res;
      return responseJson;
    });
  }
  getUserInfo(): Observable<Response[]> {
    const url = 'mock/esaorder.json';
    return this.http.get(url)
    .map((res: Response) => {
      const responseJson: any = res;
      return responseJson;
    });
  }
  saveUserSearch(param): Observable<Response[]> {
    const url = this.endpoints.ldc.saveusersearch;
    return this.http.post(url, param)
    .map((res: Response) => {
      const responseJson: any = res;
      return responseJson;
    });
  }
   getLocationDTO(queryParam): Observable<Response[]>  {
    const url = this.endpoints.ldc.getlocation;
    return this.http.post(url, queryParam)
    .map((res: Response) => {
      const responseJson: any = res;
      return responseJson;
    });
   }


}
