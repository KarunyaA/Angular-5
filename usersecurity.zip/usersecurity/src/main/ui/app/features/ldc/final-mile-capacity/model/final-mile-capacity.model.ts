import { MenuItem } from 'primeng/api';
import { FormControl, FormGroup } from '@angular/forms';

export interface HomeDelivery {
    field: string;
    header: string;
}

export interface TerritoryData {
    territory: number;
    sun: number;
    mon: number;
    tue: number;
    wed: number;
    thu: number;
    fri: number;
    sat: number;
}

export interface ZoneData {
    zone: number;
    sun: number;
    mon: number;
    tue: number;
    wed: number;
    thu: number;
    fri: number;
    sat: number;
}

export interface UserSavedDataModel {
    userSavedSearchID?: number;
    personID: string;
    applicationSearchFunctionCode: string;
    userSearchName: string;
    userSearchDefaultIndicator: string;
    userSearchCriteriaContent: string;
}

export interface LocationDataModel {
    size: number;
    _source: Array<string>;
    query: object;
}

export interface DailyRouteCapacityModel {
    ldcday: string;
    ldclimit: number;
    ldcrouteid: number;
}

export class FinalMileCapacityModel {
    userRole: string;
    selectedTabFlag: boolean;
    dailyRouteObservable: any;
    spinnerFormGroup: FormGroup;
    specificDateAddOrRemove: boolean;
    items: MenuItem[];
    territoryColumns: Array<HomeDelivery>;
    territoryData: Array<TerritoryData>;
    zoneData: Array<ZoneData>;
    zoneColumns: Array<HomeDelivery>;
    userSavedSearchID: number;
    userSavedData: UserSavedDataModel;
    getLocationID: LocationDataModel;
    dailyRouteCapacity: Array<DailyRouteCapacityModel>;

    constructor() {
        this.items = [
            { label: 'FINAL MILE CAPACITY', id: 'finalmilecapacity' },
            { label: 'DCS INBOUND LIMITS', id: 'dcsinbound' },
        ];
        this.territoryColumns = [
            { field: 'territory', header: 'Territory' },
            { field: 'sun', header: 'Sun' },
            { field: 'mon', header: 'Mon' },
            { field: 'tue', header: 'Tue' },
            { field: 'wed', header: 'Wed' },
            { field: 'thu', header: 'Thu' },
            { field: 'fri', header: 'Fri' },
            { field: 'sat', header: 'Sat' }
        ];
        this.territoryData = [
            {
                'territory': 1,
                'sun': 12,
                'mon': 10,
                'tue': 12,
                'wed': 12,
                'thu': 60,
                'fri': 90,
                'sat': 80
            },
            {
                'territory': 2,
                'sun': 20,
                'mon': 30,
                'tue': 40,
                'wed': 50,
                'thu': 60,
                'fri': 90,
                'sat': 80
            },
            {
                'territory': 3,
                'sun': 12,
                'mon': 10,
                'tue': 12,
                'wed': 12,
                'thu': 60,
                'fri': 90,
                'sat': 80
            }
        ];
        this.zoneColumns = [
            { field: 'zone', header: 'Zone' },
            { field: 'sun', header: 'Sun' },
            { field: 'mon', header: 'Mon' },
            { field: 'tue', header: 'Tue' },
            { field: 'wed', header: 'Wed' },
            { field: 'thu', header: 'Thu' },
            { field: 'fri', header: 'Fri' },
            { field: 'sat', header: 'Sat' }
        ];
        this.zoneData = [
            {
                'zone': 1 - 1,
                'sun': 12,
                'mon': 10,
                'tue': 12,
                'wed': 12,
                'thu': 60,
                'fri': 90,
                'sat': 80
            },
            {
                'zone': 2 - 1,
                'sun': 20,
                'mon': 30,
                'tue': 40,
                'wed': 50,
                'thu': 60,
                'fri': 90,
                'sat': 80
            }
        ];
        this.getLocationID = {
            size: 5,
            _source: [
                'LocationName',
                'LocationCode',
                'Address.AddressLine1',
                'Address.AddressLine2',
                'Address.CityName',
                'Address.StateName',
                'Address.StateCode',
                'Address.CountryName',
                'Address.PostalCode',
                'OrganizationName',
                'locationtypes'
            ],
            query: {
                bool: {
                    must: [
                        {
                            query_string: {
                                fields: [
                                    'LocationName',
                                    'LocationCode',
                                    'Address.AddressLine2',
                                    'Address.CityName',
                                    'Address.StateName',
                                    'Address.StateCode',
                                    'Address.CountryName',
                                    'Address.PostalCode'
                                ],
                                query: 'Diamond*',
                                default_operator: 'and',
                                analyze_wildcard: 'true'
                            }
                        },
                        {
                            nested: {
                                path: 'locationtypes',
                                query: {
                                    query_string: {
                                        default_field: 'locationtypes.LocationSubTypeDescription',
                                        query: 'Local Distribution Center'
                                    }
                                }
                            }
                        }
                    ]
                }
            }
        };
    }
}
