import { FormControl } from '@angular/forms';

export class UpdateLdc {
    routeCapacity: Object;
    ldcID: any;
    ldcName: any;
    dailyLimitArray: Array<Object>;
    capacityId: number;
    sundayCapacityID: FormControl;
    mondayCapacityID: FormControl;
    tuesdayCapacityID: FormControl;
    wednesdayCapacityID: FormControl;
    thursdayCapacityID: FormControl;
    fridayCapacityID: FormControl;
    saturdayCapacityID: FormControl;
    capacityID: any;
    dailyRouteObservable: any;
}
