import { TestBed, inject } from '@angular/core/testing';

import { UpdateLdcService } from './update-ldc.service';

describe('UpdateLdcService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [UpdateLdcService]
    });
  });

  it('should be created', inject([UpdateLdcService], (service: UpdateLdcService) => {
    expect(service).toBeTruthy();
  }));
});
