import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators, FormArray } from '@angular/forms';

import { GrowlModule, Message } from 'primeng/primeng';
import { MessageService } from 'primeng/components/common/messageservice';
import { SelectItem } from 'primeng/api';
import * as _ from 'lodash';

import { InboundAreaModel } from './models/create-inbound-area.model';
import { CreateInboundAreaService } from './services/create-inbound-area.service';
import { SpecificDatesComponent } from './specific-dates/specific-dates.component';
import { JBHGlobals } from '../../../app.service';

@Component({
  selector: 'app-create-inbound-area',
  templateUrl: './create-inbound-area.component.html',
  providers: [CreateInboundAreaService],
  styleUrls: ['./create-inbound-area.component.scss']
})
export class CreateInboundAreaComponent implements OnInit {
  @Input() buType: any;
  @Output() splitClose = new EventEmitter();
  inboundAreaModel: InboundAreaModel;
  public userform: FormGroup;
  capacityArea: any;
  public myForm: FormGroup;
  showError = false;
  specificDateError = false;

  constructor(private jbhGlobals: JBHGlobals, private createInboundAreaService: CreateInboundAreaService,
    private formBuilder: FormBuilder) {
    this.inboundAreaModel = new InboundAreaModel();
  }

  ngOnInit() {
    this.inboundAreaModel.formValid1 = false;
    this.inboundAreaModel.formValid2 = false;
    this.inboundAreaModel.formValid3 = false;
    this.inboundAreaModel.businessUnit = this.buType;
    this.specificDateForm();

    this.userform = this.formBuilder.group({
      'capacityArea': new FormControl('', Validators.required),
      'serviceOffering': new FormControl('', Validators.required),
      'fleetType': new FormControl('', Validators.required),
      'sunday': new FormControl(''),
      'monday': new FormControl(''),
      'tuesday': new FormControl(''),
      'wednesday': new FormControl(''),
      'thursday': new FormControl(''),
      'friday': new FormControl(''),
      'saturday': new FormControl(''),
    });
    this.getServiceOffering();
  }
  specificDateForm(): void {
    this.myForm = this.formBuilder.group({
      date: this.formBuilder.array([])
    });
  }

  getServiceOffering(): void {
    this.createInboundAreaService.getServiceOffering(this.inboundAreaModel.businessUnit).subscribe(data => {
      if (data && data['_embedded'] && data['_embedded']['serviceOfferingBusinessUnitTransitModeAssociations']) {
        const listData = data['_embedded']['serviceOfferingBusinessUnitTransitModeAssociations'];
        const listValues = [];
        listData.forEach(element => {
          const obj = {
            name: element['serviceOfferingCode'],
            code: element['serviceOfferingCode']
          };
          listValues.push(obj);
        });
        this.inboundAreaModel.serviceOfferingList = listValues;
      }
    });
  }
  //
  onSelectType(event: any): void {
    /*this.createInboundAreaService.getFleetType(this.inboundAreaModel.businessUnit, event['code']).subscribe(data => {
      if (data && data['_embedded'] && data['_embedded']['serviceOfferingBusinessUnitTransitModeAssociations']) {
        const listData = data['_embedded']['serviceOfferingBusinessUnitTransitModeAssociations'];
        const listValues = [];
        listData.forEach(element => {
          const obj = {
            code: element['freightShippingType']['freightShippingTypeCode'],
            name: element['freightShippingType']['freightShippingTypeDescription']
          };
          listValues.push(obj);
        });
        this.inboundAreaModel.fleetTypeList = listValues;
      }
    });*/
    if (this.buType === 'JBI') {
      this.inboundAreaModel.fleetTypeList  = this.inboundAreaModel.jbiFleetype;
    }
    if (this.buType === 'JBT') {
      this.inboundAreaModel.fleetTypeList  = this.inboundAreaModel.jbtFleetype;
    }
    if (this.buType === 'DCS') {
      this.inboundAreaModel.fleetTypeList  = this.inboundAreaModel.dcsFleetype;
    }
    if (this.buType === 'ICS') {
      this.inboundAreaModel.fleetTypeList  = this.inboundAreaModel.icsFleetype;
    }
  }
  getForm(myForm):   any   {

    return   myForm.controls.date.controls;
  }
  formControl(myForm,   i):   any   {

    return   myForm.controls.date.controls[i];
  }

  initDate(): any {

    return this.formBuilder.group({
      specificDate: [''],
      specificDateLimit: ['']
    });

  }

  addNewDate(): void {

    const control = < FormArray > (this.myForm.controls['date']);
    const addCtrl = this.initDate();
    addCtrl.valueChanges.subscribe(dates => {
      this.checkDuplicate(dates, control);
    });
    control.push(addCtrl);
  }
  checkDuplicate(date: any, formArray: FormArray): void {
    const newDate = date;
    const dateArray = formArray.controls;
    const duplicateVal = [];
    this.showError = false;
    if (formArray.controls.length > 1) {
      formArray.controls.forEach(element => {
        if (element.value.specificDate !== '') {
          if (element.value.specificDate.indexOf(newDate.specificDate) !== -1) {
            this.inboundAreaModel.duplicateArray.push(newDate.specificDate);
            if (this.inboundAreaModel.duplicateArray.length > 1) {
              this.showError = true;
            }
          }
        }
      });
      this.inboundAreaModel.duplicateArray = [];
    } else {
      this.showError = false;
    }
  }

  removeDate(i: number): void {
    const control = < FormArray > this.myForm.controls['date'];
    control.removeAt(i);
    const newControl = < FormArray > this.myForm.controls['date'];
    if (newControl.controls.length > 1) {
      this.customGroupValidation(newControl);
    } else {
      this.showError = false;
    }
  }

  customGroupValidation(formArray: FormArray): void {
    const uniqueNames = [];
    if (formArray.controls.length > 1) {
      this.showError = false;
      for (let i = 0; i < formArray.controls.length; i++) {
        if (uniqueNames.indexOf(formArray.controls[i].value.specificDate) === -1) {
          this.showError = false;
          uniqueNames.push(formArray.controls[i].value.specificDate);
        } else {
          this.showError = true;
        }
      }
    }

  }

  getCapacityArea(event, ): void {
    const queryParam = event.query;
    this.createInboundAreaService.getCapacityArea(queryParam, this.inboundAreaModel.businessUnit).then(areas => {
      const arrayList = [];
      areas.forEach(areaObj => {
        arrayList.push({
          name: areaObj['capacityArea'],
          code: areaObj['id']
        });
      });
      this.inboundAreaModel.filteredArea = arrayList;
    });
  }

  saveAction(): void {
    const dailyLimitEntered = [];
    this.inboundAreaModel.test = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    for (let j = 0; j < this.inboundAreaModel.test.length; j++) {
      if (this.inboundAreaModel[this.inboundAreaModel.test[j]]) {
        dailyLimitEntered.push({
          'weekDayCode': this.inboundAreaModel.test[j],
          'inboundLoadCapacityLimitCount': this.inboundAreaModel[this.inboundAreaModel.test[j]]
        });
      }
    }
    const dates = this.myForm.value['date'];
    const arrayList = [];
    dates.forEach(dateObj => {
      const dateSeperated = dateObj['specificDate'].split('/');
      const dateArray = [parseInt(dateSeperated[2], 10),
        parseInt(dateSeperated[0], 10), parseInt(dateSeperated[1], 10)
      ];
      arrayList.push({
        inboundCapacityLimitDate: dateArray,
        inboundLoadCapacityDateLimitCount: dateObj['specificDateLimit'],
      });
    });
    this.inboundAreaModel.specificDates = arrayList;

    const reqJson = {
      'capacityAreaID': this.userform.value['capacityArea']['code'],
      'capacityAreaName': this.userform.value['capacityArea']['name'],
      'financeBusinessUnitCode': this.inboundAreaModel.businessUnit,
      'serviceOfferingCode': this.userform.value['serviceOffering']['code'],
      'fleetTypeCode': this.userform.value['fleetType']['code'],
      'specificDates': this.inboundAreaModel.specificDates,
      'dailyLimit': dailyLimitEntered,
    };
    for (let n = 0; n < this.myForm.controls.date['controls']['length']; n++) {
    if (this.myForm.controls.date['controls'][n].value.specificDate &&
     this.myForm.controls.date['controls'][n].value.specificDateLimit === '') {
      this.specificDateError = true;
       } else {
        this.specificDateError = false;
       }
      }
    if (this.userform.valid) {
      if (this.userform.valid && this.myForm.valid && this.showError === false
       && (this.userform.controls.sunday.value ||
       this.userform.controls.monday.value || this.userform.controls.tuesday.value ||
       this.userform.controls.wednesday.value || this.userform.controls.thursday.value ||
       this.userform.controls.friday.value || this.userform.controls.saturday.value)) {
        if (this.userform.valid && this.myForm.valid && this.showError === false
          && this.specificDateError === false && (this.userform.controls.sunday.value ||
         this.userform.controls.monday.value || this.userform.controls.tuesday.value ||
         this.userform.controls.wednesday.value || this.userform.controls.thursday.value ||
         this.userform.controls.friday.value || this.userform.controls.saturday.value)) {
      this.createInboundAreaService.saveInboundArea(reqJson).subscribe(data => {
        if (data['error']) {
          if (data['error']['errorMessage'] === 'DUPLICATE_INBOUND_AREA_EXISTS') {
          this.jbhGlobals.notifications.add({
            severity: 'error',
            summary: 'Duplicate Inbound Limit',
            detail: 'An active inbound limit already exists, ' +
            'please create new inbound limit or edit existing inbound limits54321125 RowsJBI INBOUND LIMITSLoadsCapacity Settings'
          });
        }
        if (data['error']['errorMessage'] === 'INBOUND_CAPACITY_AREA_ID_OR_LOCATION_ID_NOT_FOUND') {
          this.jbhGlobals.notifications.add({
            severity: 'error',
            summary: 'Error',
            detail: 'Error'
          });
        }
        } else {
         this.splitClose.emit(false);
          this.jbhGlobals.notifications.add({
            severity: 'success',
            summary: 'Save Inbound Limit',
            detail: 'Inbound Limit for ' + this.userform.value['capacityArea']['name'] + 'has been successfully added'
          });
        }
        this.userform.reset();
        this.myForm.reset();
        this.onCancel();
      });
    }
     } else {
      this.jbhGlobals.notifications.add({
        severity: 'Save',
        summary: 'daily limit',
        detail: 'Add atleast one daily limit'
      });
    }
    } else {
      this.inboundAreaModel.formValid1 = !this.userform.controls.capacityArea.valid;
      this.inboundAreaModel.formValid2 = !this.userform.controls.serviceOffering.valid;
      this.inboundAreaModel.formValid3 = !this.userform.controls.fleetType.valid;
    }
  }
  onCancel(): void {
    this.userform.reset();
    this.myForm.reset();
    this.specificDateForm();
    this.splitClose.emit(false);
  }
}

