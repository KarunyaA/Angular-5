import { TestBed, inject } from '@angular/core/testing';

import { ViewInboundAreaService } from './view-inbound-area.service';

describe('ViewInboundAreaService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ViewInboundAreaService]
    });
  });

  it('should be created', inject([ViewInboundAreaService], (service: ViewInboundAreaService) => {
    expect(service).toBeTruthy();
  }));
});
