import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/toPromise';
import { Data } from '@angular/router';

import { JBHGlobals } from '../../../../app.service';

@Injectable()
export class InboundAreaLocListService {
  constructor(private jbhGlobals: JBHGlobals) {}
  getLocationData(reqObject): Observable < any > {
    return this.jbhGlobals.apiService.addData(this.jbhGlobals.endpoints.inboundlimits.getinboundlocations, reqObject, true);
  }
  getAreaData(reqObject): Observable < any > {
    return this.jbhGlobals.apiService.addData(this.jbhGlobals.endpoints.inboundlimits.getinboundareas, reqObject, true);
  }
  getAreaSearchData(reqObject): Observable < any > {
    return this.jbhGlobals.apiService.addData(this.jbhGlobals.endpoints.inboundlimits.getinboundareas, reqObject, true);
  }
  getLocationSearchData(reqObject): Observable < any > {
    return this.jbhGlobals.apiService.addData(this.jbhGlobals.endpoints.inboundlimits.getinboundlocations, reqObject, true);
  }

}
