import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InboundLocationDatesComponent } from './inbound-location-dates.component';

describe('InboundLocationDatesComponent', () => {
  let component: InboundLocationDatesComponent;
  let fixture: ComponentFixture<InboundLocationDatesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InboundLocationDatesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InboundLocationDatesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
