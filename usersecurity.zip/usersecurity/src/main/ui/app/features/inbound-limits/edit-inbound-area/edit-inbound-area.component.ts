import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-inbound-area',
  templateUrl: './edit-inbound-area.component.html',
  styleUrls: ['./edit-inbound-area.component.scss']
})
export class EditInboundAreaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
