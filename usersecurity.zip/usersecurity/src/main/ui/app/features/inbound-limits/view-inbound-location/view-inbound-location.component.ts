import { Component, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-view-inbound-location',
  templateUrl: './view-inbound-location.component.html',
  styleUrls: ['./view-inbound-location.component.scss']
})
export class ViewInboundLocationComponent implements OnInit {

  ngOnInit() {
  }


}
