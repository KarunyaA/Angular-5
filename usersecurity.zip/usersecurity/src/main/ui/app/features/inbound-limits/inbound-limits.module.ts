import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { InboundLimitsRoutingModule } from './inbound-limits-routing.module';
import { InboundAreaListComponent } from './inbound-area-list/inbound-area-list.component';
import { InboundLocationListComponent } from './inbound-location-list/inbound-location-list.component';
import { CreateInboundLocationComponent } from './create-inbound-location/create-inbound-location.component';
import { CreateInboundAreaComponent } from './create-inbound-area/create-inbound-area.component';
import { ViewInboundAreaComponent } from './view-inbound-area/view-inbound-area.component';
import { EditInboundAreaComponent } from './edit-inbound-area/edit-inbound-area.component';
import { EditInboundLocationComponent } from './edit-inbound-location/edit-inbound-location.component';
import { ViewInboundLocationComponent } from './view-inbound-location/view-inbound-location.component';
import { InboundLimitComponent } from './inbound-limit/inbound-limit.component';

import { DataTableModule } from 'primeng/datatable';
import { ContextMenuModule } from 'primeng/contextmenu';
import { InputTextModule } from 'primeng/inputtext';
import { MenuModule } from 'primeng/menu';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { TableModule } from 'primeng/table';
import { ScrollPanelModule } from 'primeng/scrollpanel';
import { PaginatorModule } from 'primeng/paginator';
import { ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';
import { OrderListModule } from 'primeng/orderlist';
import { ToggleButtonModule } from 'primeng/togglebutton';
import { MenuItem } from 'primeng/api';
import { AccordionModule } from 'primeng/accordion';
import { CheckboxModule } from 'primeng/checkbox';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RadioButtonModule } from 'primeng/radiobutton';
import { DropdownModule } from 'primeng/dropdown';
import { BreadcrumbModule } from 'primeng/breadcrumb';
import { TabViewModule } from 'primeng/tabview';
import { PanelModule } from 'primeng/panel';
import { SpinnerModule } from 'primeng/spinner';
import { CalendarModule } from 'primeng/calendar';
import { GrowlModule } from 'primeng/growl';

import { InboundAreaLocListComponent } from './inbound-area-loc-list/inbound-area-loc-list.component';
import { SpecificDatesComponent } from './create-inbound-area/specific-dates/specific-dates.component';
import { InboundLocationDatesComponent } from './create-inbound-location/inbound-location-dates/inbound-location-dates.component';
import { ThousandsSeparatorPipe } from './inbound-area-loc-list/pipes/thousands-separator.pipe';


@NgModule({
    imports: [
        CommonModule,
        InboundLimitsRoutingModule,
        DataTableModule,
        ContextMenuModule,
        InputTextModule,
        MenuModule,
        AutoCompleteModule,
        TableModule,
        ScrollPanelModule,
        CalendarModule,
        SpinnerModule,
        PaginatorModule,
        ButtonModule,
        DialogModule,
        OrderListModule,
        ToggleButtonModule,
        AccordionModule,
        CheckboxModule,
        FormsModule,
        RadioButtonModule,
        GrowlModule,
        ReactiveFormsModule,
        DropdownModule,
        BreadcrumbModule,
        TabViewModule,
        PanelModule
    ],
    declarations: [InboundAreaListComponent, InboundLocationListComponent,
        CreateInboundLocationComponent, CreateInboundAreaComponent,
        ViewInboundAreaComponent, EditInboundAreaComponent, EditInboundLocationComponent,
        ViewInboundLocationComponent,
        InboundLimitComponent,
        InboundAreaLocListComponent,
        SpecificDatesComponent,
        InboundLocationDatesComponent,
        ThousandsSeparatorPipe
    ]
})
export class InboundLimitsModule { }
