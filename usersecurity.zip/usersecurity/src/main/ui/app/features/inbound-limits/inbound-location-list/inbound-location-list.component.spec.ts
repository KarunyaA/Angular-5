import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InboundLocationListComponent } from './inbound-location-list.component';

describe('InboundLocationListComponent', () => {
  let component: InboundLocationListComponent;
  let fixture: ComponentFixture<InboundLocationListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InboundLocationListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InboundLocationListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
