import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewInboundLocationComponent } from './view-inbound-location.component';

describe('ViewInboundLocationComponent', () => {
  let component: ViewInboundLocationComponent;
  let fixture: ComponentFixture<ViewInboundLocationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewInboundLocationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewInboundLocationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
