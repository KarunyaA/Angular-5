import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inbound-location-list',
  templateUrl: './inbound-location-list.component.html',
  styleUrls: ['./inbound-location-list.component.scss']
})
export class InboundLocationListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
