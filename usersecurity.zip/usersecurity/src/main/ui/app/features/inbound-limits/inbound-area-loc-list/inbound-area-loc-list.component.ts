import { Component, OnInit, Input } from '@angular/core';
import { InboundAreaLocListModel } from './models/inbound-area-loc-list.model';

import { InboundAreaLocListService } from '../inbound-area-loc-list/services/inbound-area-loc-list.service';
import { JBHGlobals } from '../../../app.service';

@Component({
  selector: 'app-inbound-area-loc-list',
  templateUrl: './inbound-area-loc-list.component.html',
  styleUrls: ['./inbound-area-loc-list.component.scss'],
  providers: [InboundAreaLocListService, InboundAreaLocListModel],
})
export class InboundAreaLocListComponent implements OnInit {
  @Input() buType: any;
  selectedRow: any;
  isDataTableDetailOpen;
  filterFlag: any = 0;
  formFlag: any = 0;
  formEditFlag: any = 0;
  formViewFlag: any = 0;
  formAddFlag: any = 0;
  dropdownvalue: any = 'inboundarea';
  filteredCountriesMultiple: any[];
  columnOptions: object[];
  items: object[];
  isController = true;
  dropdownlables: object[];
  breadcrumitems: object[];
  cols: object[];
  area_source: object[];
  loc_source: object[];
  dailyLimitList: object[];
  title: any;
  area_source_len: any;
  loc_source_len: any;
  display = false;
  searchInput: string;
  inboundAreaLocListModel: InboundAreaLocListModel;
  constructor(private jbhGlobals: JBHGlobals, private service: InboundAreaLocListService) {
    this.dropdownlables = [{
      label: 'Inbound Area Limits',
      value: 'inboundarea'
    }, {
      label: 'Inbound Location Limits',
      value: 'inboundlocation'
    }];
    this.inboundAreaLocListModel = new InboundAreaLocListModel();
  }
  ngOnInit() {
    const bu = this.buType;
    this.inboundAreaLocListModel['areaParamsList']['query']['bool']['must'][0]['match']['bu_type'] = bu;
    this.inboundAreaLocListModel['locParamsList']['query']['bool']['must'][0]['match']['bu_type'] = bu;
    this.inboundAreaLocListModel['areaSearchParams']['query']['bool']['must'][1]['match']['bu_type'] = bu;
    this.inboundAreaLocListModel['areaSearchParams']['query']['bool']['must'][0]['query_string']['query'] = '**';
    this.inboundAreaLocListModel['locSearchParams']['query']['bool']['must'][1]['match']['bu_type'] = bu;
    this.inboundAreaLocListModel['locSearchParams']['query']['bool']['must'][0]['query_string']['query'] = '**';
    this.fetchAllAreaData();
    this.breadcrumitems = [{
      label: 'Home',
      url: '#'
    }, {
      label: 'Capacity Settings'
    }];
    this.columnOptions = [];
    this.items = this.items = [{
      label: 'Add Inbound Limit',
      command: (onclick) => {
        this.formFlag = 1;
        this.formViewFlag = 0;
        this.formEditFlag = 0;
        this.formAddFlag = 1;
        this.filterFlag = 0;
        this.isDataTableDetailOpen = true;
      }
    }, {
      label: 'Manage Columns',
      command: (onclick) => {
        this.showDialog();
      }
    }, {
      label: 'Export to Excel'
    }];
  }
  addinbound() {
    this.formFlag = 1;
    this.formViewFlag = 0;
    this.formEditFlag = 0;
    this.formAddFlag = 1;
    this.filterFlag = 0;
    this.isDataTableDetailOpen = true;
  }
  editinbound() {
    this.formFlag = 1;
    this.formEditFlag = 1;
    this.formViewFlag = 0;
    this.formAddFlag = 0;
    this.filterFlag = 0;
    this.isDataTableDetailOpen = true;
  }
  viewinbound() {
    this.formFlag = 1;
    this.formEditFlag = 0;
    this.formViewFlag = 1;
    this.formAddFlag = 0;
    this.filterFlag = 0;
    this.isDataTableDetailOpen = true;
  }
  onToggelController() {
    this.isController = !this.isController;
  }

  handleRowSelect(event, data) {
    this.isDataTableDetailOpen = true;
    this.selectedRow = data;
  }
  onCloseSplitView() {
    this.isDataTableDetailOpen = false;
  }

  showDialog() {
    this.display = true;
  }
  handleChange(e) {
    const isChecked = e.checked;
  }
  onRowSelect(event: object): void {
    this.formFlag = 1;
    this.filterFlag = 0;
    this.formEditFlag = 0;
    this.formViewFlag = 1;
    this.formAddFlag = 0;
    this.isDataTableDetailOpen = true;
    this.dailyLimitList = [];
    const dayList = [{
        week_day_code: 'Sunday',
        limit_count: 0
      },
      {
        week_day_code: 'Monday',
        limit_count: 0
      },
      {
        week_day_code: 'Tuesday',
        limit_count: 0
      },
      {
        week_day_code: 'Wednesday',
        limit_count: 0
      },
      {
        week_day_code: 'Thursday',
        limit_count: 0
      },
      {
        week_day_code: 'Friday',
        limit_count: 0
      },
      {
        week_day_code: 'Saturday',
        limit_count: 0
      }
    ];
    if (this.selectedRow !== undefined && this.selectedRow['_source']['daily_limit'] !== undefined) {
      const dailyLimitList = this.selectedRow['_source']['daily_limit'];
      console.log(dailyLimitList);
      for (let i = 0; i < dayList.length; i++) {
        this.dailyLimitList.push(dayList[i]);
        for (let j = 0; j < dailyLimitList.length; j++) {
          if (dayList[i]['week_day_code'] === dailyLimitList[j]['week_day_code']) {
            this.dailyLimitList[i] = dailyLimitList[j];
          }
        }
      }
    }
  }
  removeForm(event: string): void {
    this.formFlag = 0;
    this.filterFlag = 0;
  }
  showFilter(event: string): void {
    this.filterFlag = (this.filterFlag === 0) ? 1 : 0;
    this.formFlag = 0;
  }
  onSelectType(event) {
    this.formFlag = 0;
    this.searchInput = '';
    if (event === 'inboundlocation') {
      this.dropdownvalue = 'inboundlocation';
      this.fetchAllLocationData();
    } else {
      this.dropdownvalue = 'inboundarea';
      this.fetchAllAreaData();
    }
  }

  onSearchChange(searchValue: string) {
    const bu = this.buType;
    if ((searchValue.length > 2) && (this.dropdownvalue === 'inboundarea')) {
      this.inboundAreaLocListModel.areaSearchParams['query']['bool']['must'][0]['query_string']['query'] = '*' + searchValue + '*';
      this.service.getAreaSearchData(this.inboundAreaLocListModel.areaSearchParams).subscribe(data => {
        this.area_source = data['hits']['hits'];
      });
    } else if ((searchValue.length > 2) && (this.dropdownvalue === 'inboundlocation')) {
      this.inboundAreaLocListModel.locSearchParams['query']['bool']['must'][0]['query_string']['query'] = '*' + searchValue + '*';
      this.service.getLocationSearchData(this.inboundAreaLocListModel.locSearchParams).subscribe(data => {
        this.loc_source = data['hits']['hits'];
      });
    } else if ((searchValue.length < 3) && (this.dropdownvalue === 'inboundarea')) {
      this.service.getAreaData(this.inboundAreaLocListModel.areaParamsList).subscribe(data => {
        this.area_source = data['hits']['hits'];
      });
    } else if ((searchValue.length < 3) && (this.dropdownvalue === 'inboundlocation')) {
      this.service.getLocationData(this.inboundAreaLocListModel.locParamsList).subscribe(data => {
        this.loc_source = data['hits']['hits'];
      });
    }
  }
  closeSplit(event): void {
    this.formFlag = 0;
    const bu = this.buType;
    setTimeout(() => {
      if (this.dropdownvalue === 'inboundarea') {
        this.fetchAllAreaData();
      } else {
        this.fetchAllLocationData();
      }
    }, 1000);
  }
  private fetchAllAreaData(): void {
    this.service.getAreaData(this.inboundAreaLocListModel.areaParamsList).subscribe(data => {
      this.area_source = data.hits.hits;
      this.area_source_len = this.area_source.length;
    });
  }
  private fetchAllLocationData(): void {
    this.service.getLocationData(this.inboundAreaLocListModel.locParamsList).subscribe(data => {
      this.loc_source = data.hits.hits;
      this.loc_source_len = this.loc_source.length;
    });
  }

}

