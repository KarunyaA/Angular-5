export class ViewInboundAreaModel {
}
