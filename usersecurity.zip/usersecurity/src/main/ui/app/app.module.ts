import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PlatformLocation } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { CoreModule } from './core/core.module';
import { BusinessUnitService, JbhEsaModule, UserService } from './shared/jbh-esa';
import { ErrorHandlerModule } from './shared/error-handler/error-handler.module';
import { SpinnerComponent, SpinnerService } from './shared/spinner/index';
import { AppSharedDataService } from './shared/jbh-app-services/app-shared-data.service';
import { LoggerService } from './shared/jbh-app-services/logger.service';
import { ShortcutkeyService } from './shared/jbh-app-services/shortcutkey.service';
import { MouseEventService } from './shared/jbh-app-services/mouseevent.service';
import { CanDeactivateGuardService } from './shared/jbh-app-services/can-deactivate-guard.service';
import { LocalStorageService } from './shared/jbh-app-services/local-storage.service';
import { MessageService } from 'primeng/components/common/messageservice';
import { GrowlModule } from 'primeng/growl';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
UserService.URL = 'mock/esaorder.json';
@NgModule({
  declarations: [
    AppComponent,
    SpinnerComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    CoreModule,
    AppRoutingModule,
    GrowlModule,
    JbhEsaModule.forRoot()
  ],
  providers: [
    SpinnerService,
    AppSharedDataService,
    LocalStorageService,
    LoggerService,
    MessageService,
    ShortcutkeyService,
    MouseEventService
  ],
  bootstrap: [AppComponent]
})
export class AppModule {

  constructor(private platformLocation: PlatformLocation) {
//     let hostName;
//     if (this.platformLocation && this.platformLocation['location']
//       && this.platformLocation['location']['host']) {
//       hostName = this.platformLocation['location']['host'];
//       if (hostName.indexOf('ldc') === -1) {
//          UserService.URL = 'mock/esaorder.json';
//       }
//     }
  }
}
