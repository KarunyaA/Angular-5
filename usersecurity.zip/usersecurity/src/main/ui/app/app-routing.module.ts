import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path: 'dashboard',
    loadChildren: 'app/features/dashboard/dashboard.module#DashboardModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Dashboard',
      pathIcon: `icon-Icon_Home`,
      order: 1
    }

  },
  {
    path: 'capacitysettings',
    loadChildren: 'app/features/inbound-limits/inbound-limits.module#InboundLimitsModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Capacity Settings',
      pathIcon: `icon-Icon_Home`,
      order: 1
    }

  },
  {
    path: 'ldc',
    loadChildren: 'app/features/ldc/ldc.module#LdcModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'LDC',
      pathIcon: `icon-Icon_Home`,
      order: 2
    }
  },
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
  { path: '**', redirectTo: 'dashboard', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
