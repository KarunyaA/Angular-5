import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';

@Injectable()
export class ProfileService {
url: string;
params = {
    'query': {
        'bool': {
            'should': [
                {
                    'multi_match': {
                        'fields': [
                            'userID'
                        ],
                        'query': '',
                        'type': 'phrase_prefix'
                    }
                }
            ]
        }
    }
}
constructor(
    public http: Http) {
}

loadUserRolesAndTasks(jbhGlobals: any, userService: any): void {
    this.url = jbhGlobals.endpoints.monitoring.exceptionManagementRoleUrl;
    this.params['query']['bool']['should'][0]['multi_match']['query'] = jbhGlobals.user.userDetails['userId'];
    this.http.post(this.url, this.params).map(res => res.json())
        .subscribe(data => {
            const empProfile = data.hits.hits;
            if (empProfile.length > 0) {
                userService.userDetails['roles'] = empProfile[0]['_source']['roles'];
                userService.userDetails['taskAssignments'] = empProfile[0]['_source']['taskAssignments'];
                userService.userDetails['teams'] = empProfile[0]['_source']['teams'];
				userService.userDetails['personId'] = empProfile[0]['_source']['emplid'];
            }
        });
}
}
