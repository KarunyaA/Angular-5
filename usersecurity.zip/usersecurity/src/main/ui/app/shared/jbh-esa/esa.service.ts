import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions } from '@angular/http';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { UserService } from './user.service';
import { Location } from '@angular/common';

@Injectable()
export class EsaService {

  constructor(
    private http: HttpClient,
    public userService: UserService,
    location: Location) { }

  load() {
    let esaURL: string;
    let path: any;
    path = location.pathname.split('/');
    esaURL = '/' + path[1] + '/user';
    console.log(UserService.URL);
    if (UserService.URL) {
      esaURL = UserService.URL;
    }

    console.log('esaurl', esaURL);

    return new Promise((resolve) => {

      const headers = new HttpHeaders();
      headers.append('Cache-Control', 'no-cache');
      headers.append('Pragma', 'no-cache');
      // const defaultOptions = new RequestOptions({
      //   headers: headers
      // });

      this.http.get(esaURL, { headers} ).map(res => res)
        .subscribe(data => {
          console.log(data);
          const me = this;
          this.userService.userDetails = data;
          resolve(null);
        }, error => {
          console.error('INITIALIZATION:', error);
          this.userService.userDetails = error;
          resolve(null);
        });
    });
  }
}
