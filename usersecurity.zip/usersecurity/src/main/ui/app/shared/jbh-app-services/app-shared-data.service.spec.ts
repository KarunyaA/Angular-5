import { inject, TestBed } from '@angular/core/testing';

import { AppSharedDataService } from './app-shared-data.service';

describe('AppSharedDataService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AppSharedDataService]
    });
  });

  it('should ...', inject([AppSharedDataService], (service: AppSharedDataService) => {
    expect(service).toBeTruthy();
  }));
});
