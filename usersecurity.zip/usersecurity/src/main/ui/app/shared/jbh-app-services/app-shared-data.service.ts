import { Injectable } from '@angular/core';

import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Injectable()
export class AppSharedDataService {

    private isVendorFormBackClick = false;
    private sharingData: BehaviorSubject<string[]>;
    private userDetails: Object;
    private paymentsDashboardData: any;
    private vendorFormsDashboardData: any;
    private advanceSearchDashboardData: any;
    private shareNotificationCount = new BehaviorSubject({});

    constructor() {
        this.sharingData = <BehaviorSubject<string[]>>new BehaviorSubject([]);
        this.shareNotificationCount = <BehaviorSubject<string[]>>new BehaviorSubject([]);
    }

    saveData(data): void {
        this.sharingData.next(data);
    }

    getData() {
        return this.sharingData.asObservable();
    }

    setUserDetails(data): void {
        this.userDetails = data;
    }

    getUserDetails(): any {
        return this.userDetails;
    }

    savePaymentsDashboardData(data): void {
        this.paymentsDashboardData = data;
    }

    getPaymentsDashboardData(): any {
        return this.paymentsDashboardData;
    }

    saveAdvanceSearchDashboardData(data): void {
        this.advanceSearchDashboardData = data;
    }

    getAdvanceSearchDashboardData(): any {
        return this.advanceSearchDashboardData;
    }

    saveVendorFormsDashboardData(data): void {
        this.vendorFormsDashboardData = data;
    }

    getVendorFormsDashboardData(data): any {
        return this.vendorFormsDashboardData;
    }

    getIsVendorFormsBackClick(): boolean {
        return this.isVendorFormBackClick;
    }

    setIsVendorFormsBackClick(isBackClick): void {
        this.isVendorFormBackClick = isBackClick;
    }

    saveNotificationCountData(data): void {
        this.shareNotificationCount.next(data);
    }

    getNotificationCountData() {
        return this.shareNotificationCount.asObservable();
    }
}
