import { inject, TestBed } from '@angular/core/testing';

import { ShortcutkeyService } from './shortcutkey.service';

describe('ShortcutkeyService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ShortcutkeyService]
    });
  });

  it('should ...', inject([ShortcutkeyService], (service: ShortcutkeyService) => {
    expect(service).toBeTruthy();
  }));
});
