import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import 'rxjs/add/operator/catch';
import { Observable } from 'rxjs/Observable';
import { MessageService } from 'primeng/components/common/messageservice';
import { SpinnerService } from '../../shared/spinner/index';
import { LoggerService } from '../../shared/jbh-app-services/logger.service';
@Injectable()
export class ApiClientService {
  requestCount: number;
  constructor(private http: HttpClient,
    private spinnerService: SpinnerService,
    private logger: LoggerService,
    private notifications: MessageService) {
    this.requestCount = 0;
  }
  getData(url: string, query ?: Object, showLoader ?: boolean, headers ?: any, needResponseHeaders ?: boolean): Observable < any[] > {
    this.requestCount++;
    this.spinnerService.spinnerText = 'Processing Service Requests ...';
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Cache-Control': 'no-cache',
        'Pragma': 'no-cache'
      })
    };
    let showLoaderFlag = true;
    if (showLoader === false) {
      showLoaderFlag = false;
    }
    if (showLoaderFlag === true && !this.spinnerService.showStatus) {
      this.spinnerService.show();
    }
    return this.http.get < any > (url, httpOptions).map((res: any) => {
      this.requestCount--;
      this.spinnerService.hide();
      if (this.requestCount <= 0) {
        this.requestCount = 0;
        this.spinnerService.hide();
      }
      return res;
    }).catch((err: HttpErrorResponse) => {
      // simple logging, but you can do a lot more, see below
      console.error('An error occurred:', err.error);
      this.spinnerService.hide();
       return [];
    });
  }
  addData(url, body: Object, headers ?: any): Observable < any[] > {
    this.spinnerService.show();
    this.spinnerService.spinnerText = 'Processing Service Requests ...';
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Cache-Control': 'no-cache',
        'Pragma': 'no-cache'
      })
    };

    const bodyString = JSON.stringify(body);
    return this.http.post < any > (url, bodyString, httpOptions).map((res: any) => {
      this.spinnerService.hide();
      return res;
    }).catch((err: HttpErrorResponse) => {
        // simple logging, but you can do a lot more, see below
        // console.error('An error occurred:', err.error);
        this.spinnerService.hide();
         return [err];
      });
  }
  formatError(err: any, isFile ?: boolean): Object {
    let error = {};

    try {
      const errJson = err.json();
      let errorMsg = errJson.errors[0].errorMessage;
      if (errorMsg.indexOf('deserialize') > -1 || errorMsg.indexOf('java.') > -1 || errorMsg.indexOf('org.') > -1) {
        errorMsg = 'Please Contact Administrator.';
      }
      return {
        title: errJson.errors[0].errorType,
        errorMessage: errorMsg,
        code: errJson.errors[0].code
      };

    } catch (e) {

    }

    if (err.status >= 500) {
      error = {
        title: err.error ? err.error : 'Server Error',
        errorMessage: err.message ? err.message : 'Please contact administrator.'
      };
    } else if (err.status === 404) {
      error = {
        title: 'Resource not found',
        errorMessage: 'Please contact administrator.'
      };
    } else if (isFile) {
      error = {
        title: 'Error',
        errorMessage: 'Error while Retrieving Paper Document.'
      };
    } else if (typeof err === 'object' && !err.stack && err._body) {
      const resBody = JSON.parse(err._body);
      if (resBody && resBody.errors && resBody.errors[0]) {
        let errMsg = resBody.errors[0].errorMessage;
        if (errMsg.indexOf('deserialize') > -1 || errMsg.indexOf('java.') > -1) {
          errMsg = 'Please Contact Administrator.';
        }
        error = {
          title: resBody.errors[0].errorType,
          errorMessage: errMsg,
          code: resBody.errors[0].code
        };
      } else if (resBody && resBody.error) {
        if (typeof resBody.error === 'object' && resBody.error.caused_by) {
          error = {
            title: resBody.error.caused_by.type,
            errorMessage: resBody.error.caused_by.reason
          };
        } else if (typeof resBody.error === 'object') {
          error = {
            title: 'Server Error',
            errorMessage: 'Please contact administrator.'
          };
        } else {
          error = {
            title: resBody.error ? resBody.error : 'Server Error',
            errorMessage: resBody.message ? resBody.message : 'Please contact administrator.',
            code: resBody.code
          };
        }
      } else {
        error = {
          title: err.statusText,
          errorMessage: err._body
        };
      }

    } else {
      error = {
        // hideModal: true,
        title: 'Unable to reach the server',
        errorMessage: 'Empty data returned.'
      };
    }
    return error;
  }

  errorHandler(errorInfo: any): void {
    // if (!errorInfo.hideModal) {
    // this.notifications.error(errorInfo.title, errorInfo.errorMessage, {timeOut: 0});
    //  this.notifications.push({severity:'error', summary:errorInfo.title, detail: errorInfo.errorMessage});
    // }
  }

}
