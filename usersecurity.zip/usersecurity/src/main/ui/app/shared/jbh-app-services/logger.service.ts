import { Injectable } from '@angular/core';

@Injectable()
export class LoggerService {
  private _log: Function;
  private _info: Function;
  private _warn: Function;
  private _error: Function;
  logLevel: number;

  constructor() {
    this._log = console.log;
    this._info = console.info;
    this._warn = console.warn;
    this._error = console.error;
  }

  init(level: number) {
    this.logLevel = level;
    this.blockDefaultConsoleMethods();
  }

  log(...args) {
    if (this.logLevel > 0) {
      Function.prototype.apply.call(this._log, console, args); // <--- change here
    }
  }

  info(...args) {
    if (this.logLevel > 1) {
      Function.prototype.apply.call(this._info, console, args); // <--- change here
    }
  }

  error(...args) {
    if (this.logLevel > 2) {
      Function.prototype.apply.call(this._error, console, args); // <--- change here
    }
  }

  warn(...args) {
    if (this.logLevel > 3) {
      Function.prototype.apply.call(this._warn, console, args); // <--- change here
    }
  }

  private blockDefaultConsoleMethods() {
    if (this.logLevel === 0) {
      console.log = console.info = console.warn = console.error = () =>
        null;
    }
  }
}
