/* tslint:disable:no-unused-variable */

import { async, inject, TestBed } from '@angular/core/testing';
import { ApiClientService } from './api-client.service';

describe('ApiClientService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ApiClientService]
    });
  });

  it('should ...', inject([ApiClientService], (service: ApiClientService) => {
    expect(service).toBeTruthy();
  }));
});
