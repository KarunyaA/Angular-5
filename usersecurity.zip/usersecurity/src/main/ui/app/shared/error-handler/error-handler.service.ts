import { ErrorHandler, Injectable } from '@angular/core';

import { JBHGlobals } from '../../app.service';
import { SpinnerService } from './../../shared/spinner/index';

@Injectable()

export class ErrorHandlerService extends ErrorHandler {

    constructor(private jbhGlobals: JBHGlobals,
                public spinnerService: SpinnerService) {
        super();
    }

    handleError(error) {
        this.jbhGlobals.logger.log('Error Handler', error);
        if (!error.title) {
            this.spinnerService.hide();
        }
        if (!error.title) {
            // if ( !error.title ) {
            this.jbhGlobals.logger.log('UI Runtime Error', error.message);
            console.log('UI Runtime Error', error.message);
            this.spinnerService.hide();
            /*this.jbhGlobals.notifications.error('UI Runtime Error',
                this.jbhGlobals.utils.truncate(error.message, {
                    'length': 200,
                    'separator': ' '
                }));*/
        }
    }
}
