/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';


import { AppComponent } from './app.component';
import { CoreModule } from './core/core.module';
import { SimpleNotificationsModule } from 'angular2-notifications';
import { SpinnerService, SpinnerComponent } from './shared/spinner/index';
import { JBHGlobals } from './app.service';
import { ConfigService } from '@nglibs/config';
import { ConfigLoader } from '@nglibs/config';
import { HttpModule } from '@angular/http';

import { NotificationsService } from 'angular2-notifications';

import { ApiClientService } from './shared/jbh-utils/api-client.service';
import { LoggerService } from './shared/jbh-utils/logger.service';
import { AppSharedDataService } from './shared/jbh-utils/app-shared-data.service';
import { LocalStorageService } from './shared/jbh-utils/local-storage.service';
import { ShortcutkeyService } from './shared/jbh-utils/shortcutkey.service';
import { TemplateJsonTransformerService } from './features/create-orders/templates/template-json-transformer.service';
import { MouseEventService } from './shared/jbh-utils/mouseevent.service';


describe('AppComponent', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule, CoreModule, SimpleNotificationsModule, HttpModule
      ],
      declarations: [
        AppComponent, SpinnerComponent
      ],
      providers: [ SpinnerService,
      JBHGlobals,
      ConfigService,
      ConfigLoader,
      ApiClientService,
      LoggerService,
      AppSharedDataService,
      LocalStorageService,
      ShortcutkeyService,
      TemplateJsonTransformerService,
      MouseEventService,
      NotificationsService
      ]
    });
    TestBed.compileComponents();
  });

  it('should create the app', async(() => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  }));

});
