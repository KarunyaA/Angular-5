import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
/*
import { ManageOrdersRoutes } from './features/manage-orders/manage-orders-routing.config';
*/
import { MonitoringRoutes } from './features/monitoring/monitoring-routing.config';

const routes: Routes = [
  {
    path: 'dashboard',
    loadChildren: 'app/features/dashboard/dashboard.module#DashboardModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Dashboard',
      pathIcon: `icon-jbh_home pull-right`,
      order: 1
    }
  },
  {
    path: 'createorders',
    loadChildren: 'app/features/create-orders/create-orders.module#CreateOrdersModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Create Order',
      pathIcon: `icon-jbh_add pull-right`,
      order: 1
    }
  },
  {
    path: 'ordersearch',
    loadChildren: 'app/features/order-search/order-search.module#OrderSearchModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Order Search',
      pathIcon: `icon-jbh_search pull-right`,
      order: 1
    }
  },
  {
    path: 'automationrules',
    loadChildren: 'app/features/automation-rules/automation-rules.module#AutomationRulesModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Automation Rules',
      pathIcon: `icon-jbh_placeholder pull-right`,
      order: 1
    }
  },
  {
    path: 'vieworder',
    loadChildren: 'app/features/view-order/view-order.module#ViewOrderModule',
  },
  {
    path: 'shippingoptions',
    loadChildren: 'app/features/shipping-options/shipping-options.module#ShippingOptionsModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Get Quote',
      pathIcon: `icon-jbh_item pull-right`,
      order: 1
    }
  },
  {
    path: 'monitoring',
    children: [...MonitoringRoutes],
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Monitoring',
      pathIcon: `icon-jbh_multi_item pull-right`,
      order: 1
    }
  },
  {
    path: 'opportunityorders',
    loadChildren: 'app/features/opportunity-orders/opportunity-orders.module#OpportunityOrdersModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Opportunity Orders',
      pathIcon: `icon-jbh_placeholder pull-right`,
      order: 1
    }
  },
  {
    path: 'manageratesheet',
    loadChildren: 'app/features/manage-rate-sheet/manage-rate-sheet.module#ManageRateSheetModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Manage Rate Sheet',
      pathIcon: `icon-jbh_item pull-right`,
      order: 1
    }
  },
  {
    path: 'loadinformation',
    loadChildren: 'app/features/load-information/load-information.module#LoadInformationModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Load Information',
      pathIcon: `icon-jbh_search pull-right`,
      order: 1
    }
  },
  {
    path: 'viewucr',
    loadChildren: 'app/features/view-ucr/view-ucr.module#ViewUcrModule'
  },
  {
    path: 'settings',
    loadChildren: 'app/features/settings/settings.module#SettingsModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Settings',
      pathIcon: `icon-jbh_placeholder pull-right`,
      order: 1
    }
  },
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
  { path: '**', redirectTo: 'dashboard', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  providers: []
})

export class AppRoutingModule { }
