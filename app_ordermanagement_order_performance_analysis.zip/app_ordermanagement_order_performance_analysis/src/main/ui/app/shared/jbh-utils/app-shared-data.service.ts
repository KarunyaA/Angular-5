import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Injectable()
export class AppSharedDataService {

    private sharingData: BehaviorSubject < string[] > ;
    private isTemplateView = false;
    private fromStopFlag = false;
    private tempObj: any = {};
    private stopTempDto = [];
    private entityDto = [];
    private templateHandlingUnit = [];
    private equipmentResponse: any = {};
    private tempCheckFlag = false;
    copies = 0;
    constructor() {
        this.sharingData = < BehaviorSubject < string[] >> new BehaviorSubject([]);
    }

    saveData(data): void {
        this.sharingData.next(data);
    }

    setTemplateFlagStatus(flag): void {
        this.isTemplateView = flag;
    }

    getTemplateFlagStatus(): boolean {
        return this.isTemplateView;
    }

    getData() {
        return this.sharingData.asObservable();
    }

    setTemplateData(key, value): void {
        this.tempObj[key] = value;
    }

    getTemplateData(): object {
        return this.tempObj;
    }
    setTemplateDtoArrayList(stopLIst): void {
        this.stopTempDto = stopLIst;
    }
    getStopList(): Array < Object > {
        return this.stopTempDto;
    }
    setTemplateEntity(entityList): void {
        this.entityDto = entityList;
    }
    getTemplateEntity(): Array < Object > {
        return this.entityDto;
    }
    setTemplateHandlingUnit(list): void {
        this.templateHandlingUnit = list;
    }
    getTemplateHandlingUnit(): Array < Object > {
        return this.templateHandlingUnit;
    }
    getFromStopCheckFlag() {
        return this.fromStopFlag;
    }
    setTemplateEditCheckFlag(flag) {
        this.tempCheckFlag = flag;
    }
    getTemplateEditCheckFlag() {
        return this.tempCheckFlag;
    }
    setFromStopCheckFlag(flag): void {
        this.fromStopFlag = flag;
    }
    getEquipmentRequirementResponse() {
        return this.equipmentResponse;
    }
    setEquipmentRequirementResponse(data): void {
        this.equipmentResponse = data;
    }
    setOrderCopies(value): void {
        this.copies = value;
    }
    getOrderCopies() {
        return this.copies;
    }
}
