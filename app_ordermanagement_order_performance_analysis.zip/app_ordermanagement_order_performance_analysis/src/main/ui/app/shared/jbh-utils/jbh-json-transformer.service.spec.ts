import { TestBed, inject } from '@angular/core/testing';

import { JbhJsonTransformerService } from './jbh-json-transformer.service';
import { JBHGlobals } from '../../app.service';

describe('JbhJsonTransformerService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [JbhJsonTransformerService,JBHGlobals]
    });
  });

  it('should ...', inject([JbhJsonTransformerService,JBHGlobals], (service: JbhJsonTransformerService) => {
    expect(service).toBeTruthy();
  }));
});
