import { Injectable } from '@angular/core';

import { JBHGlobals } from '../../app.service';
import { IOrderDtoModel } from '../../features/create-orders/orders/order-dto-model';
import { IOrderEntityModel } from '../../features/create-orders/orders/order-entity-model';

@Injectable()
export class JbhJsonTransformerService {

    constructor(private jbhGlobals: JBHGlobals) {

    }

    orderDtoToEntity(source: IOrderDtoModel, target: IOrderEntityModel): IOrderEntityModel {

        const me = this;
        const _ = me.jbhGlobals.utils;

        const mapProp: Object = {
            // orderCrossesBorderDetailDTOs:"orderCrossBorderDetails",
            // orderEquipmentRequirementDTOs: 'orderEquipmentRequirement',
            // referenceNumberDTOs: 'orderReferenceNumbers',
            // commentDTOs:"orderComments",
            orderRequestorDTOs: 'orderRequestorDetail',
            // stopDTOs:"stops",
            // chargeDTOs:"orderCharges",
            orderBillingDetailDTOs: 'orderBillingDetail',
            internationalService: 'internationalServices',
            // orderMaterialHandlingRequirementAssociation:"orderMaterialHandlingRequirementAssociations",
            customerID: 'customerID',
            serviceOfferingCode: 'serviceOfferingCode',
            requestedServiceLevelCode: 'requestedServiceLevelCode',
            servicePriorityTypeCode: 'servicePriorityTypeCode',
            transitModeCode: 'transitModeCode',
            financeBusinessUnitCode: 'financeBusinessUnitCode',
            orderSourceCode: 'orderSourceCode',
            orderStatusCode: 'orderStatusCode',
            orderTypeCode: 'orderTypeCode',
            orderSubTypeCode: 'orderSubTypeCode',
            orderValueTypeCode: 'orderValueTypeCode',
            orderVolumeTypeCode: 'orderVolumeTypeCode',
            shipmentIdentificationNumber: 'shipmentIdentificationNumber',
            orderTrackingNumber: 'orderTrackingNumber',
            orderValueAmount: 'orderValueAmount',
            orderRefrigeratedIndicator: 'orderRefrigeratedIndicator',
            orderHighValueIndicator: 'orderHighValueIndicator',
            orderGroupingID: 'orderGroupingID',
            // orderUnifiedCustomerRequestAssociations:"orderUnifiedCustomerRequestAssociations",
            // orderAdditionalInstructions:"orderAdditionalInstructions",
            orderCarrierDetailDTOs: 'orderCarrierDetails',
            // orderStatusWorkflows:"orderStatusWorkflows",
            // orderStatusEvents:"orderStatusEvents",
            orderFoodSafetyDetails: 'orderFoodSafetyDetails',
            internationalOrderElement: 'internationalOrderElement',
            // orderMonitorInformations:"orderMonitorInformations",
            orderOperationalElementDTOs: 'orderOperationalElement',
            orderServices: 'orderServices',
            orderID: 'orderID'
            // orderAssociatedParties:"orderAssociatedParties"
        };
        _.mapValues(source, function(o, key) {

            if (_.has(mapProp, key)) {
                switch (key) {
                    case 'orderBillingDetailDTOs':
                        target[mapProp[key]] = [];
                        _.mapValues(o, function(so) {
                         _.mapValues(so.orderBillingAdditionalInstruction, function(sso) {
                                sso.orderID = source.orderID;
                            });
                              target[mapProp[key]].push({
                                autoRateIndicator: so.autorateIndicator,
                                billToID: so.profileDTO && so.profileDTO.partyID ? so.profileDTO.partyID : '',
                                contactID: (so.profileDTO && so.profileDTO.contactDTO && so.profileDTO.contactDTO.contactId) ?
                                    so.profileDTO.contactDTO.contactId : '',
                                 contactTypeCode: (so.profileDTO && so.profileDTO.contactDTO && so.profileDTO.contactDTO.contactType) ?
                                    so.profileDTO.contactDTO.contactType : '',

                                freightChargeTermTypeCode: so.freightChargeTermTypeCode,
                                //ratingCycleType:so.ratingCycleDTO.ratingCode,
                                ratingCycleType: 'load',
                                lineOfBusinessCode: so.lineOfBusinessCode
                            });
                        });
                        break;
                    case 'orderRequestorDTOs':
                        target[mapProp[key]] = [];
                        _.mapValues(o, function(so) {
                            target[mapProp[key]].push({
                                contactID: '',

                                contactTypeCode: (so.profileDTO && so.profileDTO.contactDTO && so.profileDTO.contactDTO.contactType) ?
                                    so.profileDTO.contactDTO.contactType : '',

                                solicitorID: (so.profileDTO && so.profileDTO.partyID) ? so.profileDTO.partyID : ''
                            });
                        });
                        break;
                    case 'orderOperationalElementDTOs':
                        target[mapProp[key]] = [];
                        _.mapValues(o, function(so) {
                            if (so.orderOperationalElement.projectCode || so.orderOperationalElement.fleetCode) {
                                target[mapProp[key]].push({
                                    projectCode: so.orderOperationalElement.projectCode,
                                    fleetCode: so.orderOperationalElement.fleetCode
                                });
                            }
                        });
                        break;
                    case 'orderCarrierDetailDTOs':
                        target[mapProp[key]] = [];
                        _.mapValues(o, function(so) {
                                target[mapProp[key]].push({
                                    orderVolumeTradeShowTypeCode: so.orderCarrierDetail.orderVolumeTradeShowTypeCode,
                                    carrierName: so.orderCarrierDetail.carrierName,
                                    carrierQuoteNumber: so.orderCarrierDetail.carrierQuoteNumber,
                                    carrierBoothNumber: so.orderCarrierDetail.carrierBoothNumber,
                                });
                        });
                        break;
                    default:
                        if (_.isObject(o)) {
                            _.mapValues(o, function(so) {
                                delete so['lastUpdateTimestampString'];
                            });
                        }
                        target[mapProp[key]] = o;
                }
            }
        });
        return target;
    }
}
