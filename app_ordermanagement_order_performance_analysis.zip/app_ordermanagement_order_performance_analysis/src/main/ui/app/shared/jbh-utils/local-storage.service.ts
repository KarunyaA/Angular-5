import { Injectable } from '@angular/core';


@Injectable()
export class LocalStorageService {
  private storage = localStorage;

  constructor() { }

  public cacheData(parentName, key, value) {
    const data = value;
    let tempObj;

    if (this.isCachedParent(parentName)) {
      // tempObj = JSON.parse(JSON.stringify(this.storage.getItem(parentName)));
      tempObj = JSON.parse(this.storage.getItem(parentName));
    } else {
      tempObj = {};
    }
    tempObj[key] = data;
    this.storage.setItem(parentName, JSON.stringify(tempObj));

  }

  public getCachedData(parentName, key) {
    if (JSON.parse(JSON.stringify(this.storage.getItem(parentName))) !== null) {
      return JSON.parse(this.storage.getItem(parentName))[key];
    }
  };

  public clearCache(): void {
    this.storage.clear();
  }

  private isCachedParent(key) {
    if (!this.storage.getItem(key)) {
      return false;
    }
    return true;
  };
}
