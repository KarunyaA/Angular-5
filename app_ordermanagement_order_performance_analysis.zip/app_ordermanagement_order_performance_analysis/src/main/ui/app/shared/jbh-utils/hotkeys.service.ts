import {
  Injectable
} from '@angular/core';

declare var shortcut: any;

@Injectable()
export class HotkeysService {

  constructor() {

  }

  add(keys: string, callback, node?: any) {
    if (!node) {
      shortcut(keys, document.body).bindsTo(callback);
    } else {
      shortcut(keys, node).bindsTo(callback);
    }
  }

  remove(keys: string) {
    //shortcut.remove(keys);
  }

}
