import {
    Injectable
} from '@angular/core';
import {
    Http,
    Response,
    Headers,
    RequestOptions,
    URLSearchParams
} from '@angular/http';
import {
    Observable
} from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import {
    NotificationsService
} from 'angular2-notifications';

import {
    SpinnerService
} from '../../shared/spinner/index';
import {
    LoggerService
} from '../../shared/jbh-utils/logger.service';


@Injectable()
export class ApiClientService {
    private params: URLSearchParams;

    constructor(private http: Http,
        private spinnerService: SpinnerService,
        private logger: LoggerService,
        private notifications: NotificationsService) {}

    getData(url: string, query ?: Object, showLoader ?: boolean, headers ?:
        any): Observable < Response[] > {
        let showLoaderFlag = true;
        this.params = null;
        this.params = new URLSearchParams();
        const defaultOptions = new RequestOptions({
            headers: this.addHeaders(headers)
        });

        if (showLoader === false) {
            showLoaderFlag = false;
        }

        if (query) {
            for (const key in query) {
                if (query.hasOwnProperty(key)) {
                    this.params.set(key.toString(), query[key]);
                }
            }
        }

        defaultOptions.search = this.params;
        if (showLoaderFlag === true) {
            this.spinnerService.show();
        }
        return this.http.get(url, defaultOptions)
            .map((res: Response) => {
                // debugger;
                this.spinnerService.hide();
                return res.json();
            })
            /*.retryWhen((errors) => {
                debugger;
               return errors
                   .mergeMap((error) => (error.status === 429) ? Observable.throw(error) : Observable.of(error))
                   .delay(1000)
                   .take(2);
            })*/
            .catch((err: Response) => {
                this.spinnerService.hide();
                const details = this.formatError(err);
                this.errorHandler(details);
                return Observable.throw(details);
            });

    }

    addData(url, body: Object, headers ?: any): Observable < Response[] > {
        this.spinnerService.show();
        const defaultOptions = new RequestOptions({
            headers: this.addHeaders(headers)
        });
        const bodyString = JSON.stringify(body);
        return this.http.post(url, bodyString, defaultOptions) // ...using post request
            .map((res: Response) => {
                this.spinnerService.hide();
                return res.json();
            })
            /*.retryWhen((errors) => {
                debugger;
               return errors
                   .mergeMap((error) => (error.status === 429) ? Observable.throw(error) : Observable.of(error))
                   .delay(1000)
                   .take(2);
            })*/
            .catch((err: Response) => {
                this.spinnerService.hide();
                const details = this.formatError(err);
                this.errorHandler(details);
                return Observable.throw(details);
            }); //
    }

    updateData(url: string, body: Object, headers ?: any): Observable <
        Response[] > {
            this.spinnerService.show();
            const defaultOptions = new RequestOptions({
                headers: this.addHeaders(headers)
            });
            const bodyString = JSON.stringify(body);
            return this.http.put(`${url}`, bodyString, defaultOptions)
                .map((res: Response) => {
                    this.spinnerService.hide();
                    return res.json();
                })
                /*.retryWhen((errors) => {
                    debugger;
                   return errors
                       .mergeMap((error) => (error.status === 429) ? Observable.throw(error) : Observable.of(error))
                       .delay(1000)
                       .take(2);
                })*/
                .catch((err: Response) => {
                    this.spinnerService.hide();
                    const details = this.formatError(err);
                    this.errorHandler(details);
                    return Observable.throw(details);
                });
        }

    patchData(url: string, body: Object, headers ?: any): Observable <
        Response[] > {
            this.spinnerService.show();
            const defaultOptions = new RequestOptions({
                headers: this.addHeaders(headers)
            });
            const bodyString = JSON.stringify(body); // Stringify payload
            return this.http.patch(`${url}`, bodyString, defaultOptions) // ...using put request
                .map((res: Response) => {
                    this.spinnerService.hide();
                    return res.json();
                })
                /*.retryWhen((errors) => {
                    debugger;
                   return errors
                       .mergeMap((error) => (error.status === 429) ? Observable.throw(error) : Observable.of(error))
                       .delay(1000)
                       .take(2);
                })*/
                .catch((err: Response) => {
                    this.spinnerService.hide();
                    const details = this.formatError(err);
                    this.errorHandler(details);
                    return Observable.throw(details);
                });
        }

    removeData(url: string, headers ?: any): Observable < Response[] > {
        const defaultOptions = new RequestOptions({
            headers: this.addHeaders(headers)
        });
        return this.http.delete(`${url}`, defaultOptions) // ...using put request
            .map((res: Response) => {
                this.spinnerService.hide();
                return res.json();
            })
            /*.retryWhen((errors) => {
                debugger;
               return errors
                   .mergeMap((error) => (error.status === 429) ? Observable.throw(error) : Observable.of(error))
                   .delay(1000)
                   .take(2);
            })*/
            .catch((err: Response) => {
                this.spinnerService.hide();
                const details = this.formatError(err);
                this.errorHandler(details);
                return Observable.throw(details);
            });
    }


    addHeaders(headerParams: any): any {
        const headers = new Headers({
            'Content-Type': 'application/json'
        });
        headers.append('Authorization', 'Basic ' + btoa(
            'your id' + ':' + 'your password'));
        for (const i in headerParams) {
            if (headerParams.hasOwnProperty(i)) {
                headers.append(i, headerParams[i]);
            }
        }
        return headers;
    }


    formatError(err: any): Object {
        let error = {};

        try {
            const errJson = err.json();
            return {
                title: errJson.errors[0].errorType,
                errorMessage: errJson.errors[0].errorMessage
            };

        } catch (e) {

        }

        if (err.status >= 500) {
            error = {
                title: err.error ? err.error : 'Server Error',
                errorMessage: err.message ? err.message : 'Please contact administrator.'
            };
        } else if (err.status === 404) {
            error = {
                title: 'Resource not found',
                errorMessage: 'Please contact administrator.'
            };
        } else if (typeof err === 'object' && !err.stack) {
            const resBody = JSON.parse(err._body);
            if (resBody && resBody.errors && resBody.errors[0]) {
                error = {
                    title: resBody.errors[0].errorType,
                    errorMessage: resBody.errors[0].errorMessage
                };
            } else if (resBody && resBody.error) {
                error = {
                    title: resBody.error,
                    errorMessage: resBody.message
                };
            } else {
                error = {
                    title: err.statusText,
                    errorMessage: err._body
                };
            }

        } else {
            error = {
                hideModal: true,
                title: 'Unable to reach the server',
                errorMessage: 'Empty data returned.'
            };
        }
        return error;
    }


    errorHandler(errorInfo: any): void {
        if (!errorInfo.hideModal) {
            this.notifications.error(errorInfo.title, errorInfo.errorMessage);
        }
    }

    uploadBulkFile(url, body): Observable < Response[] > {
        this.spinnerService.show();
        const headers = new Headers();
        // headers.append('Content-Type', 'multipart/form-data');
        // headers.set('Accept', 'application/json');
        headers.append('Authorization', 'Basic ' + btoa(
            'your id' + ':' + 'your password'));
        const defaultOptions = new RequestOptions({
            headers: headers
        });
        return this.http.post(url, body, defaultOptions)
            .map((res: Response) => {
                this.spinnerService.hide();
                return res.json();
                // return Promise.resolve(res);
            })
            .catch((err: Response) => {
                this.spinnerService.hide();
                const details = this.formatError(err);
                this.errorHandler(details);
                return Observable.throw(details);
            });
    }


}
