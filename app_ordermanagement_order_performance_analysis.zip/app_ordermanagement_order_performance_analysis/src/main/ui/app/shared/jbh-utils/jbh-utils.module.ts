import {
  NgModule
} from '@angular/core';
import {
  CommonModule
} from '@angular/common';

import {
  JbhValidationComponent
} from '../jbh-validation/jbh-validation.component';
import {
  ValidationService
} from '../jbh-validation/validation.service';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [JbhValidationComponent],
  providers: [
    ValidationService
  ],
  exports: [
    JbhValidationComponent
  ]
})
export class JbhUtilsModule { }
