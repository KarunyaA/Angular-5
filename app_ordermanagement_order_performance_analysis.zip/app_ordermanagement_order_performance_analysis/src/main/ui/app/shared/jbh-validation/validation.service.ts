export class ValidationService {
  static getValidatorErrorMessage(validatorName: string, validatorValue?:
    any) {
    const config = {
      'required': 'Required',
      'invalidCreditCard': 'Is invalid credit card number',
      'invalidEmailAddress': 'Invalid email address',
      'invalid2decimalprecision': 'Please enter 2 decimal precision',
      'invalid4decimalprecision': 'Please enter 4 decimal precision',
    //  'invalid74decimalprecision': 'Invalid entry',
      'allowNull': '',
      'invalidPassword': 'Invalid password. Password must be at least 6 characters long, and contain a number.',
      'minlength': `Minimum length ${validatorValue.requiredLength}`,
      'maxlength': `You have reached the maximum character limit of ${validatorValue.requiredLength}`,
      'invalidRate': 'Please enter a valid amount',
      'invalidName': 'Please enter a valid Name',
      'invalidTime': 'Please choose a valid time',
      'invalidNumber': 'Please enter a valid number',
      'invalidValue': 'Special Characters are not allowed',
      'invalidComment': 'Please enter a valid comment',
      'invalidPhoneNumber': 'Please enter a valid Phone Number',
      'invalidMassQuantity': 'Please enter a valid Quantity',
      'invalidMeasurementCode': 'Please enter a valid number ',
      'invalidTechnicalName': 'You have reached the maximum character limit of 80 characters',
      'maxminlength': 'Min 50 charcters Max 250 Characters',
      'mandatory': 'Please enter',
      'mandatorySelect': 'Please select'
    };

    return config[validatorName];
  }

  static creditCardValidator(control) {
    // Visa, MasterCard, American Express, Diners Club, Discover, JCB
    // const pattern: RegExp = /^(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|6(?:011|5[0-9][0-9])
    // [0-9]{12}|3[47][0-9]{13}|3(?:0[0-5]|[68][0-9])[0-9]{11}|(?:2131|1800|35\d{3})\d{11})$/;
    /* if (control.value.match(pattern)) {
       return null;
     } else {
       return { 'invalidCreditCard': true };
     }*/
  }

  /*static emailValidator(control) {
    // RFC 2822 compliant regex
    // const pattern: RegExp = /[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?
    // ^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/;

    const pattern: RegExp = new RegExp(/\S+@\S+\.\S+/);
    if (control.value && control.value.match(pattern)) {
      console.log('valid email');
      return null;
    } else {
      console.log('Invalid Email');
      return {
        'invalidEmailAddress': true
      };
    }
  }*/

  static passwordValidator(control) {
    // {6,100}           - Assert password is between 6 and 100 characters
    // (?=.*[0-9])       - Assert a string has at least one number
    if (control.value.match(/^(?=.*[0-9])[a-zA-Z0-9!@#$%^&*]{6,100}$/)) {
      return null;
    } else {
      return {
        'invalidPassword': true
      };
    }
  }

  static chargeRateQuantity(control) {
    /*
        Values allowed 0 - 99.99
    */
    const pattern: RegExp = /^(\d{1,4}|\d\.\d{1,2}|\d{1,2}\.\d{1,2})$/;
    return pattern.test(control.value) ? null : {
      'invalid2decimalprecision': true
    };
  }

  static chargeRateCalculationAmount(control) {
    /*
        Values allowed 0 - 9999.9999
    */
    const pattern: RegExp = /^(\d{1,4}|\d\.\d{1,4}|\d{1,4}\.\d{1,4})$/;
    return pattern.test(control.value) ? null : {
      'invalid4decimalprecision': true
    };
  }

  static stopMeasurement(control) {
    const pattern: RegExp = /^(\d{1,7}|\d\.\d{1,7}|\d{1,4}\.\d{1,4})$/;
    if (control.value && !pattern.test(control.value)) {
      return {
        'invalid74decimalprecision': true
      };
    }
  }
  static allowNull(control) {
    const pattern: RegExp = /[null]$/;
    if (pattern.test(control.value)) {
      return {
        'allowNull': true
      };
    }
  }

  static rateValidator(control) {
    const pattern: RegExp = /^\d+(?:\.\d{2})$/;
    return pattern.test(control.value) ? null : { 'invalidRate': true };
  }

  static timeValidator(control) {
    const pattern: RegExp = /^(0[1-9]|1[0-2])\:[0-5][0-9]\s*[ap]m$/i;
    return pattern.test(control.value) ? null : { 'invalidTime': true };
  }

  static onlyNumber(control) {
    const pattern: RegExp = /^[0-9]{0,}$/i;
    if (control.value && !pattern.test(control.value)) {
      return {
        'invalidNumber': true
      };
    }
  }

  static onlyAlpha(control) {
    const pattern: RegExp = /^[a-zA-Z]+$/;
    return pattern.test(control.value) ? null : { 'invalidName': true };
  }

  static alphaNumeric(control) {
    const pattern: RegExp = /^[A-Za-z0-9]{0,}$/i;
    return pattern.test(control.value) ? null : { 'invalidValue': true };
  }


  static commentValidator(control) {

    const pattern: RegExp = /^[A-Za-z0-9.,\s]{0,}$/i;
    if (control.value && !pattern.test(control.value)) {
      return {
        'invalidComment': true
      };
    }
  }
  static maxLengthValidator(control) {

    const pattern: RegExp = /^[\s\S]{0,250}$/;
    if (control.value && !pattern.test(control.value)) {
      return {
        'maxlength': true
      };
    }
  }

  static phoneNumberValidator(control) {

    const pattern: RegExp = /^(\([0-9]{3}\) |[0-9]{3}-)[0-9]{3}-[0-9]{4}$/;
    if (control.value && !pattern.test(control.value)) {
      return {
        'invalidPhoneNumber': true
      };
    }
  }

  static massQuantity(control) {

    const pattern: RegExp = /^(\d{0,11}\.\d{0,4}|\d{0,11}|\.\d{0,4})$/;

    if (control.value && !pattern.test(control.value)) {
      return {
        'invalidMassQuantity': true
      };
    }

  }

  static measurementCode(control) {

    const pattern: RegExp = /^[0-9]{0,}$/i;
    if (control.value && !pattern.test(control.value)) {
      return {
        'invalidMeasurementCode': true
      };
    }
  }

  static materialTechnicalName(control) {

    const pattern: RegExp = /^[\s\S]{0,80}$/;
    if (control.value && !pattern.test(control.value)) {
      return {
        'invalidTechnicalName': true
      };
    }
  }

   static maxminLengthValidator(control) {

    const pattern: RegExp = /^[\s\S]{50,250}$/;
    if (control.value && !pattern.test(control.value)) {
      return {
        'maxminlength': true
      };
    }
  }
  static mandatory(control) {
    return control.value ? null : { 'mandatory': true };
  }
  static mandatorySelect(control) {
    return control.value ? null : { 'mandatorySelect': true };
  }
}


