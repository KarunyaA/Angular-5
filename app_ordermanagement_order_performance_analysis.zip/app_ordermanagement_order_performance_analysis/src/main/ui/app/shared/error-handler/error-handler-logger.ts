import { ErrorHandler, Injectable } from '@angular/core';
import { JBHGlobals } from '../../app.service';

@Injectable()

export class ErrorHandlerLogger extends ErrorHandler {

    constructor(private jbhGlobals: JBHGlobals) {
        super();
    }

    handleError( error ) {
        this.jbhGlobals.logger.log('Error Handler', error );
           if ( !this.jbhGlobals.environment.production && !error.title ) {
           //if ( !error.title ) {
            this.jbhGlobals.logger.log('UI Runtime Error', error.message );
            this.jbhGlobals.notifications.error( 'UI Runtime Error',
            this.jbhGlobals.utils.truncate(error.message, {
              'length': 200,
              'separator': ' '
            }));
        }
    }
}
