import { NgModule, ErrorHandler } from '@angular/core';
import { CommonModule } from '@angular/common';

import {ErrorHandlerLogger} from './error-handler-logger';

@NgModule({
    declarations: [],
    exports: [],
    imports: [],
    providers: [
        {provide: ErrorHandler, useClass: ErrorHandlerLogger}
    ]
})
export class ErrorHandlerModule {}
