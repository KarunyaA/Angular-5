import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';

import { JBHGlobals } from 'app/app.service';

@Component({
  selector: 'app-site-profile',
  templateUrl: './site-profile.component.html',
  styleUrls: ['./site-profile.component.scss']
})
export class SiteProfileComponent implements OnInit {
    @ViewChild('siteProfileModal') siteProfileModal: any;
    public siteProfile: FormGroup;
    public siteProfileList: any[] = [];
    public facilityHoursList: any[] = [];
    public daysofweekList: string[] = [];
    public facilityoperatingDetailsList: any[] = [];
    public siteRequirementList: any[] = [];
    public isEditInstructionsFlag = false;
    public isEditInstructionsFlagValueChange = false;
    public isEditDirectionsFlag = false;
    public isEditDirectionsFlagValueChange = false;
    public generalInstructionValue: any = '';
    public directionValue: any = '';

    constructor(public jbhGlobals: JBHGlobals, public formBuilder: FormBuilder) {
        this.siteProfile = this.formBuilder.group({
            customerDirections: '',
            generalInstructions: ''
        });
    }

    ngOnInit() {}

    // service call
    public loadLocationProfile(locationId) {
        const url = this.jbhGlobals.endpoints.order.getlocationprofile + '' + locationId; // + value
        this.jbhGlobals.apiService.getData(url).subscribe(data => {
            this.siteProfileList = data['locationProfileDTO'];
            this.facilityHoursList = this.siteProfileList[0].facilityOperationDTO;
            this.siteRequirementList = this.siteProfileList[0].facilityOverviewRequirementCodeDTO;
            for (let i = 0; i < this.facilityHoursList.length; i++) {
                this.daysofweekList.push(this.facilityHoursList[i].day);
                this.facilityoperatingDetailsList.push(this.facilityHoursList[i].facilityOperatingHourDTO[0]);
            }
        });
    }

    public onShowSiteProfileModal(locationId) {
        this.siteProfileModal.show();
        this.loadLocationProfile(locationId);
    }

    public onClickSiteProfileHide() {
        this.siteProfileModal.hide();
    }

    public onEditDirections() {
        this.siteProfile['controls']['customerDirections'].setValue(this.siteProfileList[0].customerDirections);
        this.isEditDirectionsFlag = true;
    }

    public onEditGeneralInstructions() {
        this.siteProfile['controls']['generalInstructions'].setValue(this.siteProfileList[0].generalInstructions);
        this.isEditInstructionsFlag = true;
    }

    public onSaveGeneralInstructions() {
        const params = {
            'locationProfileDTO': {
                'generalInstructionDTO': this.siteProfile['controls']['generalInstructions'].value,
                'locationId': this.siteProfileList[0].locationCode
            }
        };
        this.jbhGlobals.apiService.updateData(this.jbhGlobals.endpoints.order.savegeneralinstructions, params).subscribe(data => {
            this.generalInstructionValue = data['locationProfileDTO']['generalInstructionDTO'];
        });

        this.isEditInstructionsFlag = false;
        this.isEditInstructionsFlagValueChange = true;
    }

    public onSaveDirections() {
        const params = {
            'locationProfileDTO': {
                'customerDirection': {
                    'direction': this.siteProfile['controls']['customerDirections'].value,
                    'locationId': this.siteProfileList[0].locationCode
                }
            }
        };
        this.jbhGlobals.apiService.updateData(this.jbhGlobals.endpoints.order.savecustomerdirections, params).subscribe(data => {
            this.directionValue = data['locationProfileDTO']['customerDirection']['direction'];
        });
        this.isEditDirectionsFlag = false;
        this.isEditDirectionsFlagValueChange = true;
    }
}
