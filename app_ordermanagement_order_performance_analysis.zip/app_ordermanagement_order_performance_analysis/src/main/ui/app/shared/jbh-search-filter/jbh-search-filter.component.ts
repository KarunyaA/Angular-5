import { Component, Input, Output, EventEmitter } from '@angular/core';

import { JBHGlobals } from './../../app.service';

@Component({
    selector: 'jbh-search-filter',
    templateUrl: './jbh-search-filter.component.html',
    styleUrls: ['./jbh-search-filter.component.scss']
})
export class JbhSearchFilterComponent {

    /***************** Variable Declaration ****************/
    @Input() filterList: any[];
    @Input() closeOthers: boolean;
    @Input() filterTitle: string;
    @Input() filterTabIndex: string;
    @Output() checkedEvent = new EventEmitter < any > ();
    @Output() searchEvent = new EventEmitter < any > ();
    @Output() clickEvent: EventEmitter < number > = new EventEmitter < number > ();
    @Output() typeaheadEvent = new EventEmitter < any > ();
       @Output() DatechangedEvent = new EventEmitter < any > ();
    @Output() timepickerchangedEvent = new EventEmitter < any > ();
    @Input() count: any = [];
    flagShowHide = false;
    isOpen = '';
    solicitorDataList: any[];
    public bgColor: boolean = false;

    /***************** System Provided Methods ****************/
    constructor(private jbhGlobals: JBHGlobals) {}

    /******************  Filter Component Events  ********************/
    toggle(eve, val, bodyContent, headContent) {
        if (bodyContent.style.display === 'none') {
            this.flagShowHide = true;
            val['isOpen'] = true;
            bodyContent.style.display = 'block';
            headContent.style.backgroundColor = '#f9f9f9';
            this.bgColor = true;
        } else {
            val['isOpen'] = false;
            bodyContent.style.display = 'none';
            this.bgColor = false;
            headContent.style.backgroundColor = '#ffffff';
        }
    }

    changeEvent(object) {
        this.count[object.num] = object.count;
        this.checkedEvent.emit(object);
    }
    datechangeEventcall(object) {
    this.DatechangedEvent.emit(object);
  }
  timepickerchangeEventcall(eve) {
this.timepickerchangedEvent.emit(eve);
  }
    searchCallOnClick(object) {
        this.searchEvent.emit(object);
    }
    /***************** OnReset Btn Click Reset all the checkbox ****************/
    resetCheckValue(eve) {
        this.count[eve] = '';
        this.clickEvent.emit(eve);
    }
    /***************** typeAhead search query  ****************/
    typeAheadSearchCall(eve) {
        this.typeaheadEvent.emit(eve);
    }
}
