import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RatingModule } from 'ngx-bootstrap/rating';
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { MyDatePickerModule } from 'mydatepicker';
import { JbhSearchFilterComponent } from './jbh-search-filter.component';
import { JbhSearchFilterListComponent } from './jbh-search-filter-list/jbh-search-filter-list.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    PerfectScrollbarModule,
    MyDatePickerModule,
    RatingModule.forRoot()
  ],
  declarations: [
    JbhSearchFilterComponent,
    JbhSearchFilterListComponent
  ],
  exports: [
    JbhSearchFilterComponent,
    JbhSearchFilterListComponent
  ]
})
export class JbhSearchFilterModule { }
