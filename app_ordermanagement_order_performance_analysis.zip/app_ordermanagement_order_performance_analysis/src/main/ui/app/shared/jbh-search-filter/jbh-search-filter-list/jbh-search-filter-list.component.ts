import { Component, OnInit, Input, Output, EventEmitter, ViewChild } from '@angular/core';
import { IMyOptions } from 'mydatepicker';

import {JBHGlobals} from './../../../app.service';
interface IFilterDetail {
  index: any;
  title: any;
  key: any;
  rootVal: any;
  componentType: any;
  url: any;
  }
  @Component({
      selector: 'jbh-search-filter-list',
      templateUrl: './jbh-search-filter-list.component.html',
      styleUrls: ['./jbh-search-filter-list.component.scss']
  })

  export class JbhSearchFilterListComponent implements OnInit {

    /***************** Variable Declaration ****************/
    @ViewChild('searchInput') searchInput: any;
    @Input() filterDetail: IFilterDetail;
    @Input() filterTitleDetail: Object;
    @Input() filterListTabIndex: string;
    @Output() checkedEvent = new EventEmitter < any > ();
    @Output() clickEvent: EventEmitter < number > = new EventEmitter < number > ();
    @Output() searchEvent = new EventEmitter < any > ();
    @Output() typeaheadEvent = new EventEmitter < any > ();
    @Output() DatechangedEvent = new EventEmitter < any > ();
    @Output() TimepickerchangedEvent = new EventEmitter < any > ();
    dttodate: any = '';
    @ViewChild('totime') totime;
    @ViewChild('fromtime') fromtime;
    @ViewChild('todate') todate;
    myDatePickerOptions: IMyOptions = {
        todayBtnTxt: 'Today',
        dateFormat: 'dd-mm-yyyy',
        firstDayOfWeek: 'mo',
        showClearDateBtn: false,
        sunHighlight: true,
        height: '34px',
        width: '115px',
        inline: false,
        // disableUntil: {year: 2016, month: 8, day: 10},
        selectionTxtFontSize: '14px'
    };
    dataList: Array < Object >= [];
    dataCopyList: Object[];
    selectedList: Object[];
    count = 0;
    countPage = 0;
    sizeLimit = 0;
    listExist = false;
    filterListSearchTabIndex: any;
    filterListItemTabIndex: any;
    filterListResetTabIndex: any;
    ratingList: Array < Object >= [{
        'val': 'Recommended(1-3)',
        'fullVal': 4
    }, {
        'val': 'Fair (4-7)',
        'fullVal': 8
    }, {
        'val': 'Not Recommended (8-10)',
        'fullVal': 11
    }, {
        'val': 'Do Not Use (13)',
        'fullVal': 13
    }, {
        'val': 'Missing Data (99)',
        'fullVal': 99
    }];

    /***************** System Provided Methods ****************/
    constructor(private jbhGlobals: JBHGlobals) {

    }

    ngOnInit() {
        this.filterListSearchTabIndex = parseInt(this.filterListTabIndex) + 0.1;
        this.filterListItemTabIndex = parseInt(this.filterListTabIndex) + 0.2;
        this.filterListResetTabIndex = parseInt(this.filterListTabIndex) + 0.3;
        console.log(this.filterListSearchTabIndex, this.filterListItemTabIndex);
        this.serviceCall(this.filterDetail, this.filterDetail['params']);
    }

    /***************** Custom Methods ****************/

    /***************** Oncheck event emiting to parent ****************/
    changeEvent(eve, Obj) {
        if (Obj.checked) {
            this.count++;
        } else {
            this.count--;
        }

        const object = {
            'num': eve,
            'data': Obj,
            'count': this.count
        };
        this.checkedEvent.emit(object);
    }

    scrollEvent(eve) {
        console.log(this.isIE());
        if ((eve.wheelDeltaY < 0 || (this.isIE() > 10 && eve.deltaY < 0)) &&
            this.filterDetail['pagination'] && this.sizeLimit > this.dataList.length) {
            this.countPage++;
            // this.filterDetail['params']['page'] = this.countPage;
            this.paramsCreation(this.filterDetail['params'], this.countPage);
            this.serviceCall(this.filterDetail, this.filterDetail['params']);
        }
    }

    isIE() {
        const myNav = navigator.userAgent.toLowerCase();
        return (myNav.indexOf('msie') !== -1) ? parseInt(myNav.split('msie')[1]) : false;
    }

    paramsCreation(param, count) {
        if (param['page']) {
            this.filterDetail['params']['page'] = count;
        } else if (param['start'] !== undefined && param['end'] !== undefined) {
            this.filterDetail['params']['start'] = this.filterDetail['params']['end'] + 1;
            this.filterDetail['params']['end'] = this.filterDetail['params']['end'] + this.filterDetail['paginationSize'];
        } else if (param['from'] !== undefined && param['size']) {
            this.filterDetail['params']['from'] = count * param['size'];
            console.log(count * param['size']);
        }
    }

    searchCallOnClick(eve, Index, searchField) {
        const object = {
            'event': eve,
            'num': Index,
            'data': searchField
        };
        this.searchEvent.emit(object);
    }

    /***************** Oncheck event emiting to parent ****************/
    resetCheckValue(eve) {
        if (eve === 13) {
            this.searchInput.nativeElement.checked = false;
        } else {
            this.resetFunction(this.dataList);
            this.searchInput.nativeElement.value = '';
        }
        this.count = 0;

        this.dataList = this.dataCopyList ? this.dataCopyList : [];
        for (let i = 0; i < this.dataList.length; i++) {
            this.dataList[i]['checked'] = false;
        }
        this.clickEvent.emit(eve);
    }
    resetInput(eve) {
        //if (eve === 3) {
            const childNode = event.target['parentElement'].querySelectorAll('input');
            for (let i = 0; i < childNode.length; i++) {
                if (childNode[i].type === 'time') {
                    childNode[i].disabled = true;
                }
                childNode[i].value = '';
            }
            this.count = 0;
            this.dataList = this.dataCopyList;
            this.clickEvent.emit(eve);
       //}
    }
    resetFunction(arr) {
        const length = arr.length;
        for (let i = 0; i < length; i++) {
            arr[i].checked = false;
        }
    }

    /***************** Service call for CheckBox On Init ****************/
    serviceCall(cmp, params) {
        if (cmp && cmp.url) {
            const me = this;
            let methodType = 'getData';
            if (cmp.methodType) {
                methodType = cmp.methodType;
            }
            me.jbhGlobals.apiService[methodType](this.jbhGlobals.endpoints.template[cmp.url], params).subscribe(data => {
                if (data) {
                    const dataList = this.rootFormater(cmp.rootVal, data);
                    for (let i = 0; i < dataList['length']; i++) {
                        if (!cmp.key.includes('opportunity')) {
                            this.dataList.push(this.dataFormatter(dataList[i], cmp.title, data));
                        } else {
                            this.dataList.push(this.dataFormatterOpportunity(dataList[i], cmp.title, data));
                        }
                    }
                    this.dataCopyList = me.dataList;
                }
                this.listExist = (this.dataList.length > 0);
            });
        } else if (cmp && cmp.data) {
            this.dataList = cmp.data;
            this.dataCopyList = this.dataList;
            this.listExist = (this.dataList.length > 0);
        }

    }

    rootFormater(arr, data) {
        const leng = arr.length;
        switch (leng) {
            case 1:
                return data[arr[0]];
            case 2:
                return data[arr[0]][arr[1]];
            case 3:
                return data[arr[0]][arr[1]][arr[2]];
            case 4:
                return data[arr[0]][arr[1]][arr[2]][arr[3]];
            case 5:
                return data[arr[0]][arr[1]][arr[2]][arr[3]][arr[4]];
            default:
                return data;
        }
    }

    /***************** Service JSON formatter ****************/

    dataFormatter(dataObj, list, fulldata) {
        let obj = {
            checked: false,
            val: null
        };
        if (this.filterDetail['checkSelectionKey'] && !this.filterDetail['deepNestFlag'] &&
            !this.filterDetail['framerMethod']) {
            obj.val = dataObj[this.filterDetail['checkSelectionKey']];
            obj['fullVal'] = dataObj;
            this.sizeLimit = (fulldata['totalRecords']) ? fulldata['totalRecords'] : 8000;
            return obj;
        }
        if (this.filterDetail['framerMethod'] && this.filterDetail['myParentScope']) {
            const FramedVal = this.filterDetail['myParentScope'][this.filterDetail['framerMethod']];
            return FramedVal(dataObj);
        }
        switch (list) {

            case 'Business Unit':
                obj.val = dataObj['financeBusinessUnitServiceOfferingAssociation']['financeBusinessUnitCode'];
                obj['fullVal'] = dataObj['financeBusinessUnitServiceOfferingAssociation'];
                break;
            case 'Template Status':
                /* For Commitments */
            case 'Corporate Account':
            case 'Bill to Account':
            case 'Origin':
            case 'Destination':
            case 'Shipper Location':
            case 'Type':
            case 'Schedule':
            case 'Status':
            case 'Sales Person':
            case 'Operations Team Leader':
            case 'Order Owner':
            case 'Pricing Identifier':
                obj.val = dataObj['val'];
                obj['fullVal'] = dataObj;
                break;
            default:
                obj = {
                    checked: false,
                    val: null
                };
        }
        return obj;
    }

    dataFormatterOpportunity(dataObj, list, fulldata) {
        let obj = {
            checked: false,
            val: null
        };
        // this.sizeLimit = (fulldata['totalRecords']) ? fulldata['totalRecords'] : 8000;
        switch (list) {
            case 'Order Number':
                obj.val = dataObj;
                obj['fullVal'] = dataObj;
                this.sizeLimit = fulldata['totalRecords'];
                break;
            case 'Opportunity Creator':
                obj.val = dataObj['firstName'] + ' ' + dataObj['lastName'] + '(' + dataObj['inits'] + ')';
                obj['fullVal'] = dataObj['firstName'];
                this.sizeLimit = fulldata['totalRecords'];
                break;
            case 'Origin':
                obj.val = dataObj['key'] + '(' + dataObj['topacc_hits']['hits']['hits'][0]['_source']['locations']['StateCode'] + ')';
                obj['fullVal'] = dataObj['key'];
                this.sizeLimit = fulldata['totalRecords'];
                break;
            case 'Destination':
                obj.val = dataObj['key'] + '(' + dataObj['topacc_hits']['hits']['hits'][0]['_source']['locations']['StateCode'] + ')';
                obj['fullVal'] = dataObj['key'];
                this.sizeLimit = fulldata['totalRecords'];
                break;
            case 'Bill To Account':
                const billValue = dataObj['_source']['CustomerCode'] == null ?
                    dataObj['_source']['OrganizationName'] : dataObj['_source']['OrganizationName']
                    + '(' + dataObj['_source']['CustomerCode']
                    + ')';
                obj.val = billValue;
                obj['fullVal'] = dataObj['_source']['OrganizationName'];
                this.sizeLimit = 5000;
                break;
            case 'Status':
                obj.val = dataObj['opportunityStatusCode'];
                obj['fullVal'] = dataObj['opportunityStatusCode'];
                this.sizeLimit = fulldata['totalRecords'];
                break;

            case 'Order Owner':
                obj.val = dataObj['firstName'] + ' ' + dataObj['lastName'] +
                    '(' + dataObj['userName'] + ')';
                obj['fullVal'] = dataObj['firstName'];
                this.sizeLimit = fulldata['totalRecords'];
                break;
            default:
                obj = {
                    checked: false,
                    val: null
                };

        }
        return obj;
    }

    queryFilterList(eve, index) {
        if (!this.filterDetail['serviceFilter']) {
            const val = eve.target.value;
            this.dataList = this.transform(this.dataCopyList, val);
        }
        const me = this,
            object = {
                'event': eve,
                'num': index,
                'val': eve.target.value,
                'data': this.dataList,
                'setDatda': function(data) {
                    me.setDataList(data);
                }
                //            'temp': me.setDataList([])
            };
        this.typeaheadEvent.emit(object);
    }
    public datechange(eve, type) {
        if (type === 'from') {
            this.fromtime.nativeElement.disabled = false;
            this.fromtime.nativeElement.value = '00:00';
            this.totime.nativeElement.value = '00:00';
            this.totime.nativeElement.disabled = false;

            this.dttodate = eve;
        } else {
            this.totime.nativeElement.disabled = false;
            this.totime.nativeElement.value = '00:00';
        }
        //this.totime.nativeElement.disabled=true;
        eve.types = {};
        eve.types = type;
        this.DatechangedEvent.emit(eve);
    }
    public timechanged(eve, type) {
        eve.types = {};
        eve.types = type;
        this.TimepickerchangedEvent.emit(eve);
    }

    setDataList(data) {
        this.dataList = data;
        console.log('coming');
    }

    transform(items: any[], args: string): any {
        // filter items array, items which match and return true will be kept, false will be filtered out
        return items.filter(item => item.val.toLowerCase().indexOf(args.toLowerCase()) !== -1 || item.checked === true);
    }
}
