export enum SortDirection {
  asc = 'asc' as any,
  desc = 'desc' as any
}
