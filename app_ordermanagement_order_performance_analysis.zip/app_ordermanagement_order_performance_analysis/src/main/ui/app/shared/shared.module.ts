import {
  NgModule
} from '@angular/core';
import {
  CommonModule
} from '@angular/common';
import {
  FormsModule
} from '@angular/forms';
import {
  JBHDataTableModule
} from './jbh-data-table/jbh-data-table.module';
import { JbhTypeaheadComponent } from './jbh-typeahead/jbh-typeahead.component';



@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    JBHDataTableModule
  ],
  exports: [
    JBHDataTableModule
  ],
  declarations: [JbhTypeaheadComponent],
})
export class SharedModule { }
