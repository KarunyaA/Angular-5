export let SharedDemoRoutes = [{
  path: 'ng2-tab-pannel-demo',
  loadChildren: 'app/shared/demo/ng2-tabs/ng2-tabs.module#Ng2TabsModule',
  data: {
    createSidebarEntry: true,
    queryParams: {
      id: 1234
    },
    pathDisplayText: 'Ng2 Tabs Demo',
    pathIcon: `fa fa-building`,
    order: 1
  }
},
{
  path: 'jbh-data-table-demo',
  loadChildren: 'app/shared/demo/jbh-data-table/jbh-data-table.module#JbhDataTableModule',
  data: {
    createSidebarEntry: true,
    pathDisplayText: 'JBH DataTable Demo',
    pathIcon: `fa fa-building`,
    order: 2
  }
},

{
  path: 'resequence-demo',
  loadChildren: 'app/shared/demo/resequence/resequence.module#ResequenceModule',
  data: {
    createSidebarEntry: true,
    pathDisplayText: 'Resequence Demo',
    pathIcon: `fa fa-building`,
    order: 3
  }
}
  /*,
      {
          path: 'jbh-step-wizard-demo',
          loadChildren: 'app/shared/demo/jbh-step-wizard-demo/jbh-step-wizard-demo.module#JbhStepWizardDemoModule',
          data: {
              createSidebarEntry: true,
              pathDisplayText: "JBH Step Wizard Demo",
              pathIcon: `fa fa-building`,
              order: 3
          }
      }*/

  // Ramesh 24/03/2017 : Commented this route to prevent build error
];
