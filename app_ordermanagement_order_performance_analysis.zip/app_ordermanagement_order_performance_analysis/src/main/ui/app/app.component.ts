import { Component, OnInit, AfterViewInit, HostListener } from '@angular/core';
import { Router, Event as RouterEvent, NavigationStart, 
         NavigationEnd, NavigationCancel, NavigationError } from '@angular/router';

import { JBHGlobals } from './app.service';
import { SpinnerService } from './shared/spinner/index';

window.focus();

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.scss']
})

export class AppComponent implements OnInit, AfterViewInit {

    sidebarLock = false;
    isSidebarOpen = false;
    loading = true;
    commonData: any = {};
    public options: any;

    constructor(private router: Router,
        private jbhGlobals: JBHGlobals,
        private spinnerService: SpinnerService) {
        jbhGlobals.logger.info('Approot  initialized');

        router.events.subscribe((event: RouterEvent) => {
            this.navigationInterceptor(event);
        });

        this.options = this.jbhGlobals.settings.notificationsOptions;
        this.jbhGlobals.commonDataService.getData().subscribe(data => this.commonData = data);
    }

    ngOnInit() {
        /*const userId = 'rcon692';
         this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getUserDetails + userId).subscribe(data => {
           if (this.jbhGlobals.utils.isEmpty(this.jbhGlobals.userDetails)) {
             this.jbhGlobals.userDetails = data;
           }
         });*/
    }

    @HostListener('window:keydown', ['$event'])
    keyboardInput(event: any) {
        console.log(this.jbhGlobals.shortkeys.getKeyCode(event));
        this.jbhGlobals.shortkeys.saveData({
            keyCode: this.jbhGlobals.shortkeys.getKeyCode(event)
        });
    }

    @HostListener('window:click', ['$event'])
    trackAppClick(event: any) {
        this.jbhGlobals.mouseevents.saveData({
            target: this.jbhGlobals.mouseevents.getTarget(event)
        });
    }

    ngAfterViewInit() {
        this.commonData.headerOverlay = true;
    };

    toggleMobleSidebar(e) {
        this.isSidebarOpen = e;
        this.sidebarLock = e;
    }

    manageOverlayToggle(e) {
        this.commonData.headerOverlay = e;
        this.jbhGlobals.commonDataService.saveData(this.commonData);
    }

    onLockSideBar(e) {
        this.sidebarLock = e;
    }

    navigationInterceptor(event: RouterEvent): void {
        if (event instanceof NavigationStart) {
            this.jbhGlobals.logger.log('Naviagation start');
            this.spinnerService.show();
        } else if (event instanceof NavigationEnd || event instanceof NavigationCancel || event instanceof NavigationError) {
            this.jbhGlobals.logger.log('Naviagation end');
            this.spinnerService.hide();
        }
    }
}
