//import { ConfigStaticLoader } from '@nglibs/config';
//import { ConfigService } from '@nglibs/config';
import { Injectable } from '@angular/core';
import { NotificationsService } from 'angular2-notifications';
import * as _ from 'lodash';

import { ApiClientService } from '../app/shared/jbh-utils/api-client.service';
import { LoggerService } from '../app/shared/jbh-utils/logger.service';
import { ShortcutkeyService } from '../app/shared/jbh-utils/shortcutkey.service';
import { AppSharedDataService } from '../app/shared/jbh-utils/app-shared-data.service';
import { MouseEventService } from '../app/shared/jbh-utils/mouseevent.service';

import { ValidationService } from '../app/shared/jbh-validation/validation.service';
import { LocalStorageService } from '../app/shared/jbh-utils/local-storage.service';
import { AppConfig } from '../config/app.config';

import { environment } from '../environments/environment';

/*export function configFactory() {
  return new ConfigStaticLoader('./config/app.config.json');
}*/

@Injectable()
export class JBHGlobals {

  public endpoints: any;
  public apiService: ApiClientService;
  public logger: LoggerService;
  public notifications: NotificationsService;
  public shortkeys: any;
  public settings: any;
  public commonDataService: any;
  public utils: any;
  public customValidator: any;
  public userDetails: any;
  public commonStorageService: any;
  public mouseevents: any;
  public environment: any;
  public user: any = {
    'id': 'rcon744',
    'bu': 'ICS',
    'name': 'James Smith'
  };

  constructor(private apiClientService: ApiClientService,
    private log4js: LoggerService,
    private ns: NotificationsService,
    private shortcutkeyService: ShortcutkeyService,
    private appSharedDataService: AppSharedDataService,
    private localStorageService: LocalStorageService,
    private mouseevent: MouseEventService
  ) {
    const appConfig = AppConfig.getConfig();
    let logLevel = appConfig.system.logLevel;
    this.endpoints = appConfig.api;
    this.apiService = apiClientService;
    this.logger = log4js;
    this.notifications = ns;
    this.settings = appConfig.settings;
    this.utils = _;
    this.shortkeys = shortcutkeyService;
    this.commonDataService = appSharedDataService;
    this.customValidator = ValidationService;
    this.commonStorageService = localStorageService;
    this.mouseevents = mouseevent;
    this.environment = environment;
    if (this.environment.production) {
        logLevel = 0;
    }
    this.logger.init(Number(logLevel));
    this.logger.info('JBH Globals initialized');
  }
}

