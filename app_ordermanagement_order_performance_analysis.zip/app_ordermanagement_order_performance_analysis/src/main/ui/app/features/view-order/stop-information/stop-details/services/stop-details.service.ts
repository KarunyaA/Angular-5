import { Injectable } from '@angular/core';

import { JBHGlobals } from 'app/app.service';

@Injectable()
export class StopDetailsService {

  constructor(public jbhGlobals: JBHGlobals) { }

  loadServices(url) {
    return this.jbhGlobals.apiService.getData(url);
  }

  loadServiceWithParams(url, params) {
    return this.jbhGlobals.apiService.getData(url, params);
  }

   loadServiceWithBoolean(url, params, value) {
    return this.jbhGlobals.apiService.getData(url, params, value);
  }

}
