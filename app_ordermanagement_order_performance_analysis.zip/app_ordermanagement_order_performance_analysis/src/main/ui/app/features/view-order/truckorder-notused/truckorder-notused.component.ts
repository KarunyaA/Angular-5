import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { IMyOptions, IMyDateModel } from 'mydatepicker';

import { ValidationService } from 'app/shared/jbh-validation/validation.service';
import { JBHGlobals } from 'app/app.service';
import { OrderService } from 'app/features/create-orders/orders/order.service';
import { OrderOverviewComponent } from '../order-overview/order-overview.component';
import { StopInformationComponent } from '../stop-information/stop-information.component';
import { ViewOrderComponent } from '../../view-order/view-order.component';
import { TonuModel } from './models/tonu-model';


@Component({
    selector: 'app-truckorder-notused',
    templateUrl: './truckorder-notused.component.html',
    styleUrls: ['./truckorder-notused.component.scss']
})
export class TruckorderNotusedComponent implements OnInit {

    @ViewChild(OrderOverviewComponent) orderViewComponent: OrderOverviewComponent;
    @ViewChild(StopInformationComponent) stopInformationComponent: StopInformationComponent;

    @ViewChild('tonuKeepOrderActive') tonuKeepOrderActiveLink;
    @ViewChild('ipRadiotonuChargeOptions') ipRadiotonuChargeOptions;
    @ViewChild('ipRadioSetNewAppointment') ipRadioSetNewAppointment;
    @ViewChild('txttonuComments') txttonuComments;
    @ViewChild('btnTonuProcess') btnTonuProcess;
    @ViewChild('btnTonuCancel') btnTonuCancel;

    tonuModel: TonuModel;
    tonuForm: FormGroup;
    debounceValue: any;
    rateFlag: any;
    currentDate: any = new Date();
    currentYear: number = this.currentDate.getFullYear();
    currentMonth: number = this.currentDate.getMonth() + 1;
    currentDay: number = this.currentDate.getDate() - 1;


    myDatePickerOptions: IMyOptions = {
        todayBtnTxt: 'Today',
        dateFormat: 'mm-dd-yyyy',
        firstDayOfWeek: 'mo',
        showClearDateBtn: false,
        editableDateField: false,
        sunHighlight: true,
        height: '34px',
        inline: false,
        disableUntil: {
            year: this.currentYear,
            month: this.currentMonth,
            day: this.currentDay
        },
        selectionTxtFontSize: '14px'
    };



    constructor(
        private jbhGlobals: JBHGlobals,
        private orderService: OrderService,
        private formBuilder: FormBuilder,
        public viewOrderComponent: ViewOrderComponent
    ) { }


    ngOnInit() {
        this.debounceValue = this.jbhGlobals.settings.debounce;
        this.rateFlag = false;
        this.tonuModel = new TonuModel();
        this.tonuModel['standardFeeCode'] = 'RatePerCon';
        this.tonuModel['negoRateFeeCode'] = 'UseNegoRt';
        this.tonuModel['waiveFeeCode'] = 'WaivRecFee';

        // this.startDateLess = false;
        // this.dateTimeValidation = false;
        // this.timeValidation = false;
        // this.dateTimeValidationMsg = '';
        this.tonuModel['isChargeAmountVisible'] = true;
        this.tonuModel['ngModtonuChargeOptions'] = '';
        this.tonuModel['ngModtonuChangeAppoinment'] = '';

        this.tonuModel['isAppoinmentTimeVisible'] = true;
        // this.dateTimeValidationFn = (control: FormControl) => {
        //     return this.dateTimeValidationResult(this, control);
        // };


        this.tonuForm = this.formBuilder.group({
            tonuChargeOptions: ['', Validators.required],
            tonuChargeAmount: [{
                value: '',
                disabled: false
            }, Validators.required],
            tonuChangeAppoinment: [''],
            tonuChangeAppointmentStartDate: new FormControl('', Validators.required),
            tonuChangeAppointmentStartTime: new FormControl('', Validators.required),
            tonuChangeAppointmentEndDate: new FormControl('', Validators.required),
            tonuChangeAppointmentEndTime: new FormControl('', Validators.required),
            tonuComments: ['', Validators.compose([ValidationService.maxLengthValidator, ValidationService.commentValidator])]
            //tonuSendNotificationCheck: ['']
        });

        this.tonuForm['controls']['tonuChargeAmount']['valueChanges']
            .debounceTime(this.debounceValue)
            .distinctUntilChanged()
            .subscribe((value) => {

                this.validateFormRate(this.tonuForm['controls']['tonuChargeAmount']);

            }, (err: Error) => {
                this.jbhGlobals.logger.info(err);
            });

        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.viewOrder.getChargeCode, {}, true)
            .subscribe(data => {

                if (data !== undefined && data['_embedded'] && data['_embedded']['acceptedOrderModificationFeeActionTypes']) {

                    const dataArray = data['_embedded']['acceptedOrderModificationFeeActionTypes'];
                    const dataArrayLength = dataArray.length;
                    const jsonObj = {
                        'Rate As Per Contract': 'standardFeeCode',
                        'Use Negotiated Rate': 'negoRateFeeCode',
                        'Waive Off Reconsignment Fee': 'waiveFeeCode'
                    };
                    for (let idx = 0; idx < dataArrayLength; idx++) {
                        const codeValue = dataArray[idx];
                        const jsonValue = jsonObj[codeValue['acceptedOrderModificationFeeActionTypeDescription']];
                        if (jsonValue !== undefined) {
                            this[jsonValue] = codeValue['acceptedOrderModificationFeeActionTypeCode'];
                        }
                    }
                }
            });

        this.tonuModel['defaultbtn'] = true;
        this.tonuModel['btnprimary'] = true;
        this.setUpKeyboardShortcutsTonuProcess();
    }



    /*emailModalshown(): void {
        this.tonuModel['stopRow'] = this.stopInformationComponent['rows'];
    }*/


    private setUpKeyboardShortcutsTonuProcess(): void {
        this.jbhGlobals.shortkeys.getData().subscribe(data => {
            if (data.keyCode === 'alt+1') {
                this.tonuKeepOrderActiveLink.nativeElement.focus();
            } else if (data.keyCode === 'alt+2') {
                this.ipRadiotonuChargeOptions.nativeElement.focus();
            } else if (data.keyCode === 'alt+3') {
                this.ipRadioSetNewAppointment.nativeElement.focus();
            } else if (data.keyCode === 'alt+4') {
                this.txttonuComments.nativeElement.focus();
            } else if (data.keyCode === 'ctrl+!') {
                this.btnTonuProcess.nativeElement.focus();
            } else if (data.keyCode === 'ctrl+@') {
                this.btnTonuCancel.nativeElement.focus();
            }
        });
    }


    tunoRadioChange(event: any): void {
        this.updateViewAsPerRadio(event.target.value);
    }

    updateViewAsPerRadio(radioValue: string): void {
        //this.tonuModel['ngModTonuChargeAmount'] = this.tonuModel['chargeFeeValue'];
        switch (radioValue) {
            case this.tonuModel['waiveFeeCode']:
                this.tonuModel['isChargeAmountVisible'] = false;
                this.tonuForm.removeControl('tonuChargeAmount');
                break;
            case 'ipRadioContinueNewAppointment':
                this.tonuModel['isAppoinmentTimeVisible'] = false;
                this.removeNewAppoinmentControls();
                break;
            case 'ipRadioSetNewAppointment':
                this.tonuModel['isAppoinmentTimeVisible'] = true;
                if (!this.tonuForm.contains('tonuChangeAppointmentStartDate')) {
                    this.addNewAppoinmentControls();
                    // this.dateTimeValidation = false;
                }
                break;
            case this.tonuModel['standardFeeCode']:
            case this.tonuModel['negoRateFeeCode']:
                this.tonuModel['isChargeAmountVisible'] = true;
                if (!this.tonuForm.contains('tonuChargeAmount')) {
                    this.tonuForm.addControl('tonuChargeAmount',
                        new FormControl('', Validators.required));
                }
                if (radioValue === this.tonuModel['standardFeeCode']) {
                    this.tonuModel['readonlyBox'] = true;
                    this.tonuForm.get('tonuChargeAmount').disable();
                    //his.tonuForm.controls['tonuChargeAmount'].setValue(this.tonuModel['chargeFeeValue']);
                    this.tonuModel['ngModTonuChargeAmount'] = this.tonuModel['chargeFeeValue'];
                } else {
                    this.tonuModel['readonlyBox'] = false;
                    this.tonuForm.get('tonuChargeAmount').enable();
                    //is.tonuForm.controls['tonuChargeAmount'].setValue('');
                    this.tonuModel['ngModTonuChargeAmount'] = '';

                }
                break;
            default:
                break;
        }
    }



    processTruckModalShown(): void {

        this.tonuModel['processTruckModalOrginPickup'] = 'Pickup 10: 00 AM';
        this.tonuKeepOrderActiveClick();
        this.tonuModel['ngModtonuChargeOptions'] = 'standardFee';
        this.tonuModel['ngModtonuChangeAppoinment'] = 'ipRadioSetNewAppointment';
        this.updateViewAsPerRadio(this.tonuModel['ngModtonuChargeOptions']);
        this.updateViewAsPerRadio(this.tonuModel['ngModtonuChangeAppoinment']);
        // this.dateTimeValidation = false;
        this.tonuForm.controls['tonuComments'].setValue(' ');
        this.tonuKeepOrderActiveLink.nativeElement.focus();
        console.log(this.tonuKeepOrderActiveLink.nativeElement.focus());
        const orderId = this.viewOrderComponent.orderData.orderID ? this.viewOrderComponent.orderData.orderID : '';
        console.log(orderId);
        //const orderId = 3;
        const inputUrl = this.jbhGlobals.endpoints.viewOrder.getTruckorderNotUsedInputDetails.replace('_orderId', orderId);

        this.jbhGlobals.apiService.getData(inputUrl, {}, true)
            .subscribe(data => {
                console.log(data);
                if (data !== undefined) {
                    this.tonuModel['getTonuInputData'] = data;

                    //this.tonuForm.controls['tonuSendNotificationCheck'].setValue('tonuSendNotificationCheck');
                    this.populateChargeOption(this.tonuModel['getTonuInputData']);
                }
            });
        // this.timeValidation = false;
        // this.dateTimeValidationMsg = '';
        // this.startDateLess = false;

    }
    lgModaltonuHide(): void {
        this.tonuForm.controls['tonuComments'].setValue(' ');
    }

    private addChargeAmount(): void {
        if (!this.tonuForm.contains('tonuChargeAmount')) {
            this.tonuForm.addControl('tonuChargeAmount',
                new FormControl('', Validators.required));
            this.updateViewAsPerRadio(this.tonuModel['ngModtonuChargeOptions']);
            this.updateViewAsPerRadio(this.tonuModel['ngModtonuChangeAppoinment']);
        }
    }

    private populateChargeOption(data: any): void {
        this.tonuModel['chargeFeeValue'] = data['standardFee'];
        this.tonuModel['ngModtonuChargeOptions'] = this.tonuModel['standardFeeCode'];
        console.log(data[this.tonuModel['standardFeeCode']]);
        if (data['standardFee'] !== null && data['standardFee'] !== undefined) {
            this.addChargeAmount();
            this.tonuModel['chargeFeeValue'] = data['standardFee'];

            this.tonuModel['ngModtonuChargeOptions'] = this.tonuModel['standardFeeCode'];
            if (this.tonuModel['ngModtonuChargeOptions'] === this.tonuModel['standardFeeCode']) {
                this.tonuModel['isChargeAmountVisible'] = true;
                this.tonuForm.addControl('tonuChargeAmount',
                    new FormControl('', Validators.required));
            }
            this.tonuModel['ngModTonuChargeAmount'] = this.tonuModel['chargeFeeValue'];

        }/* else if (data[this.tonuModel['negoRateFeeCode']] !== null && data[this.tonuModel['negoRateFeeCode']] !== undefined) {
            this.addChargeAmount();
            this.tonuModel['chargeFeeValue'] = data[this.tonuModel['negoRateFeeCode']];
            this.tonuModel['ngModtonuChargeOptions'] = this.tonuModel['negoRateFeeCode'];
            this.tonuForm.controls['tonuChargeAmount'].setValue('');
        }*/
        this.updateViewAsPerRadio(this.tonuModel['ngModtonuChargeOptions']);
    }

    /* datepicker changes */
    tonuKeepOrderActiveClick(): void {
        this.tonuModel['keepOrderOpen'] = true;
        this.tonuModel['completeOpen'] = false;
        this.tonuModel['keepOrderDate'] = true;
        this.tonuModel['btnprimary'] = true;
        //this.tonuForm.controls['tonuChargeOptions'].setValue(this.tonuModel['ngModtonuChargeOptions']);
        //this.tonuForm.controls['tonuChangeAppoinment'].setValue(this.tonuModel['ngModtonuChangeAppoinment']);
        this.addNewAppoinmentControls();
        this.tonuModel['ngModtonuChargeOptions'] = this.tonuModel['standardFeeCode'];
        this.tonuModel['ngModtonuChangeAppoinment'] = 'ipRadioSetNewAppointment';
        this.updateViewAsPerRadio(this.tonuModel['ngModtonuChargeOptions']);
        this.updateViewAsPerRadio(this.tonuModel['ngModtonuChangeAppoinment']);
    }

    tonuCompleteOrder(): void {
        this.tonuModel['completeOpen'] = true;
        this.tonuModel['keepOrderOpen'] = false;
        this.tonuModel['keepOrderDate'] = false;
        this.tonuModel['btnprimary'] = false;
        this.tonuModel['ngModtonuChargeOptions'] = this.tonuModel['standardFeeCode'];
        this.removeNewAppoinmentControls();
        this.updateViewAsPerRadio(this.tonuModel['ngModtonuChargeOptions']);
    }

    private removeNewAppoinmentControls(): void {
        //this.tonuModel['chargeFeeValue'] = this.tonuModel['chargeFeeValue'];
        // this.dateTimeValidation = false;
        // this.startDateLess = false;
        // this.timeValidation = false;
        // if (this.tonuModel['keepOrderDate'] === false) {
        //     this.dateTimeValidation = false;
        //     this.startDateLess = false;
        //     this.timeValidation = false;
        // }
        this.tonuForm.removeControl('tonuChangeAppointmentStartDate');
        this.tonuForm.removeControl('tonuChangeAppointmentStartTime');
        this.tonuForm.removeControl('tonuChangeAppointmentEndDate');
        this.tonuForm.removeControl('tonuChangeAppointmentEndTime');
        this.getDateFieldStartDateValue();
        this.getDateFieldEndDateValue();
        this.getDateFieldStartTimeValue();
        this.getDateFieldEndTimeValue();
    }

    private addNewAppoinmentControls(): void {
        this.tonuForm.addControl('tonuChangeAppointmentStartDate',
            new FormControl('', Validators.required));
        this.tonuForm.addControl('tonuChangeAppointmentStartTime',
            new FormControl('', Validators.required));
        this.tonuForm.addControl('tonuChangeAppointmentEndDate',
            new FormControl('', Validators.required));
        this.tonuForm.addControl('tonuChangeAppointmentEndTime',
            new FormControl('', Validators.required));
    }

    private getDateFieldStartDateValue(): any {
        let startDate;
        const startDateValue = (this.tonuForm.contains('tonuChangeAppointmentStartDate')) ?
            this.tonuForm.controls['tonuChangeAppointmentStartDate']['_value'] : '';
        startDate = startDateValue.formatted;
        if (startDate === undefined) {
            startDate = '';
        }

        return startDate;
    }
    private getDateFieldEndDateValue(): any {
        let endDate;
        const endDateValue = (this.tonuForm.contains('tonuChangeAppointmentEndDate')) ?
            this.tonuForm.controls['tonuChangeAppointmentEndDate']['_value'] : '';
        endDate = endDateValue.formatted;
        if (endDate === undefined) {
            endDate = '';
        }

        return endDate;
    }
    private getDateFieldStartTimeValue(): any {
        let startTime;
        const startTimeValue = (this.tonuForm.contains('tonuChangeAppointmentStartTime')) ?
            this.tonuForm.controls['tonuChangeAppointmentStartTime']['_value'] : '';
        startTime = startTimeValue;
        return startTime;
    }
    private getDateFieldEndTimeValue(): any {
        let endTime;
        const endTimeValue = (this.tonuForm.contains('tonuChangeAppointmentEndTime')) ?
            this.tonuForm.controls['tonuChangeAppointmentEndTime']['_value'] : '';
        endTime = endTimeValue;
        return endTime;
    }


    tonuProcessBtnClicked(): void {
        const inputParam = {};
        inputParam['orderStatus'] = 'accept';
        inputParam['orderID'] = this.viewOrderComponent.orderData.orderID;
        //inputParam['orderID'] = 1;
        inputParam['tonuOption'] = this.tonuModel['keepOrderOpen'] ? 'active' : 'complete';
        inputParam['truckOrderNotUsedFeeActionTypeCode'] = this.tonuModel['ngModtonuChargeOptions'];
        inputParam['truckOrderNotUsedCustomerNegotiatedFeeAmount'] = (this.tonuForm.contains('tonuChargeAmount')) ?
            this.tonuForm.controls['tonuChargeAmount']['_value'] : '';
        inputParam['truckOrderNotUsedFeeComment'] = this.tonuForm.controls['tonuComments']['_value'];
        inputParam['message'] = 'start';
        inputParam['startDateValue'] = this.getDateFieldStartDateValue();
        inputParam['endDateValue'] = this.getDateFieldEndDateValue();
        inputParam['startTimeValue'] = this.getDateFieldStartTimeValue();
        inputParam['endTimeValue'] = this.getDateFieldEndTimeValue();

        console.log(inputParam);
        this.jbhGlobals.apiService.addData(this.jbhGlobals.endpoints.viewOrder.processTONU, inputParam)
            .subscribe(data => {
                const respVal = data;
                console.log(respVal);
                //this.jbhGlobals.notifications.alert('Success', '' + respVal['response'] + '');
                this.viewOrderComponent.tonuProcessModal.show();
            }, (err: any) => {
                console.log(err);
                this.resetTonu();
                this.jbhGlobals.notifications.alert('Failure', '' + err.errorMessage + '');
            });

    }

    //   dateTimeValidationResult(thisComponent: any, control: FormControl): any {

    //     if (thisComponent !== undefined && thisComponent.tonuForm !== undefined &&
    //         thisComponent.tonuForm.controls['tonuChangeAppointmentStartDate'] !== undefined &&
    //         thisComponent.tonuForm.touched) {
    //         const startDateAct = (!thisComponent.tonuForm.controls['tonuChangeAppointmentStartDate']) ? '' :
    //             thisComponent.tonuForm.controls['tonuChangeAppointmentStartDate']['_value'];
    //         const startTime = (!thisComponent.tonuForm.controls['tonuChangeAppointmentStartTime']) ? '' :
    //             thisComponent.tonuForm.controls['tonuChangeAppointmentStartTime']['_value'];
    //         const endDateAct = (!thisComponent.tonuForm.controls['tonuChangeAppointmentEndDate']) ? '' :
    //             thisComponent.tonuForm.controls['tonuChangeAppointmentEndDate']['_value'];
    //         const endTime = (!thisComponent.tonuForm.controls['tonuChangeAppointmentEndTime']) ? '' :
    //             thisComponent.tonuForm.controls['tonuChangeAppointmentEndTime']['_value'];

    //         const today = new Date();

    //         if (startDateAct) {
    //             const datetime = new Date(startDateAct.formatted + ' ' + startTime);
    //             const startDate = startDateAct.formatted;
    //             if (!startDate || datetime <= today) {
    //                 this.dateTimeValidation = true;
    //                 this.dateTimeValidationMsg = 'Please choose a valid start date';
    //                 return false;
    //             } else if (startTime === '') {
    //                 this.dateTimeValidation = true;
    //                 this.dateTimeValidationMsg = 'Please choose a valid start time';
    //                 return false;
    //             } else if (endDateAct) {
    //                 const endDate = endDateAct.formatted;
    //                 if (startDate && endDate || startDate < endDate ||
    //                     startDate >= endDate) {
    //                     this.dateTimeValidation = false;
    //                     if (datetime <= today) {
    //                         this.startDateLess = true;
    //                     }
    //                 }
    //                 if (startDate && endDate && startTime !== '' &&
    //                     endTime !== '' && startDate >= endDate) {
    //                     if (startDate > endDate) {
    //                         this.startDateLess = true;
    //                         this.dateTimeValidation = false;
    //                         return false;
    //                     } else if (startDate === endDate) {

    //                         if (startTime >= endTime) {
    //                             this.timeValidation = true;
    //                             this.startDateLess = false;
    //                             return false;
    //                         } else {
    //                             this.timeValidation = false;
    //                             this.startDateLess = false;
    //                             this.dateTimeValidation = false;
    //                             return true;
    //                         }
    //                     }
    //                     return false;
    //                 } else {
    //                     if (datetime <= today) {
    //                         this.startDateLess = true;
    //                         this.timeValidation = false;
    //                         if (datetime === today) {
    //                             console.log(datetime.getTime());
    //                             console.log(today.getTime());
    //                             if (datetime.getTime() - today.getTime() <= 0) {
    //                                 this.timeValidation = true;
    //                                 this.startDateLess = false;
    //                             }

    //                         }
    //                         return false;
    //                     }
    //                     this.dateTimeValidation = false;
    //                     this.timeValidation = false;
    //                     this.dateTimeValidationMsg = '';
    //                     this.startDateLess = false;
    //                     return true;
    //                 }
    //             }
    //         }

    //     }
    // }

    //   resetDatetime(event) {
    //     this.dateTimeValidation = false;
    //     this.timeValidation = false;
    //     this.dateTimeValidationMsg = '';
    //     this.startDateLess = false;
    // }

    resetTonu(): void {
        this.tonuForm.reset();
        this.viewOrderComponent.hideTonu();
        if (this.tonuForm.contains('tonuChangeAppointmentEndDate')) {
            this.tonuForm.controls['tonuChangeAppointmentEndDate'].setValue('');
        }
        if (this.tonuForm.contains('tonuChangeAppointmentStartDate')) {
            this.tonuForm.controls['tonuChangeAppointmentStartDate'].setValue('');
        }
        //this.resetDatetime('val');
    }


    // date validation


    validateStartDate(datepicker): void {
        if (datepicker.selectionDayTxt === '' || datepicker.selectionDayTxt === undefined) {
            this.tonuModel['startDateFlag'] = true;
        } else {
            this.tonuModel['startDateFlag'] = false;
        }
    }
    validateEndDate(datepicker): void {
        if (datepicker.selectionDayTxt === '' || datepicker.selectionDayTxt === undefined) {
            this.tonuModel['endDateFlag'] = true;
        } else {
            this.tonuModel['endDateFlag'] = false;
        }
    }
    validateDates(): void {

        const startDateVal = this.tonuForm.controls['tonuChangeAppointmentStartDate'].value.jsdate;
        const endDateVal = this.tonuForm.controls['tonuChangeAppointmentEndDate'].value.jsdate;
        const startTimeVal = this.tonuForm.controls['tonuChangeAppointmentStartTime'].value;
        const endTimeVal = this.tonuForm.controls['tonuChangeAppointmentEndTime'].value;
        const startDateObject = new Date(startDateVal).getTime();
        const endDateObject = new Date(endDateVal).getTime();
        console.log(startDateVal !== '');
        console.log(startDateVal !== undefined);

        const startDateNotNull = (startDateVal !== undefined);
        const endDateNotNull = (endDateVal !== undefined);
        if (startDateNotNull && startTimeVal !== '') {
            const startDate = (startDateVal.toString()).substr(4, 10);
            const currentDate = (this.currentDate.toString()).substr(4, 10);
            const startTimeMinutes = startTimeVal.split(':')[0] * 60 + parseInt(startTimeVal.split(':')[1]);
            const currentTimeMinutes = this.currentDate.getHours() * 60 + this.currentDate.getMinutes();
            if (startDate === currentDate) {
                if (startTimeMinutes < (currentTimeMinutes + 60)) {
                    this.tonuModel['startTimeMinFlag'] = true;
                    this.tonuModel['timeCompareFlag'] = false;
                    this.tonuModel['dateCompareFlag'] = false;
                } else {
                    this.tonuModel['startTimeMinFlag'] = false;
                }

            } else {
                this.tonuModel['startTimeMinFlag'] = false;
            }

        }
        if (startDateNotNull && endDateNotNull && startTimeVal !== '' && endTimeVal !== '') {
            if (startDateVal > endDateVal) {
                this.tonuModel['dateCompareFlag'] = true;
                this.tonuModel['timeCompareFlag'] = false;
            } else if (startDateObject === endDateObject) {
                if (startTimeVal > endTimeVal) {
                    this.tonuModel['timeCompareFlag'] = true;
                    this.tonuModel['dateCompareFlag'] = false;
                } else {
                    this.tonuModel['timeCompareFlag'] = false;
                    this.tonuModel['dateCompareFlag'] = false;
                }
            } else {
                this.tonuModel['dateCompareFlag'] = false;
                this.tonuModel['timeCompareFlag'] = false;
            }

        }
    }
    onpickUpDateChanged(event: IMyDateModel): void {
        // event properties are: event.date, event.jsdate, event.formatted and event.epoc
        this.tonuModel['startDateFlag'] = false;
        this.tonuModel['pickUpDate'] = event.epoc;
        this.tonuForm.controls['tonuChangeAppointmentStartDate'].setValue(event);
        this.validateDates();
    }
    ondeliveryDateChanged(event: IMyDateModel): void {
        // event properties are: event.date, event.jsdate, event.formatted and event.epoc
        this.tonuModel['endDateFlag'] = false;
        this.tonuModel['deliveryDate'] = event.epoc;
        this.tonuForm.controls['tonuChangeAppointmentEndDate'].setValue(event);
        this.validateDates();
    }

    addDecimal() {
        if (this.tonuModel['ngModTonuChargeAmount'] && this.tonuModel['ngModtonuChargeOptions'] === this.tonuModel['negoRateFeeCode']
            && this.tonuModel['ngModTonuChargeAmount'] !== null && this.tonuModel['ngModTonuChargeAmount'] !== undefined) {
            const decimalVal = parseFloat(this.tonuModel['ngModTonuChargeAmount']).toFixed(2);
            this.tonuModel['ngModTonuChargeAmount'] = decimalVal;
        } else {
            this.updateViewAsPerRadio(this.tonuModel['ngModtonuChargeOptions']);
        }
    }

    private validateFormRate(c) {
        if (this.tonuModel['ngModtonuChargeOptions'] === this.tonuModel['negoRateFeeCode']) {
            if (c.value !== 'undefined' && String(Math.floor(c.value)).length > 5) {
                this.rateFlag = true;
            } else {
                this.rateFlag = false;
            }
        } else if (c.value !== 'undefined' && String(Math.floor(c.value)).length < 5) {
            this.rateFlag = false;
        }
    }

    restrictNum(event: any) {
        const pattern = /[0-9\.]/;
        const inputChar = String.fromCharCode(event.charCode);

        if (!pattern.test(inputChar)) {
            // invalid character, prevent input
            event.preventDefault();
        }
    }
}

