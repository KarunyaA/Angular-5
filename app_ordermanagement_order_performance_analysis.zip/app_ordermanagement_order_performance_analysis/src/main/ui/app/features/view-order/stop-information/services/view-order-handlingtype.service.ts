import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { JBHGlobals } from 'app/app.service';


@Injectable()
export class ViewOrderHandlingtypeService {

    public sharingData: BehaviorSubject<any[]>;

    constructor(public jbhGlobals: JBHGlobals) {
        this.sharingData = <BehaviorSubject<any[]>>new BehaviorSubject([]);
        this.init();
    }

    init(): void {
        const url = this.jbhGlobals.endpoints.order.getHandlingUnit;
        //const params = { 'page': 0, 'size': 200 };
        this.jbhGlobals.apiService.getData(url, false).subscribe(data => {
            this.saveData(data['_embedded']['itemHandlingTypes']);
        });
    }
    saveData(data): void {
        this.sharingData.next(data);
    }
    getData() {
        return this.sharingData.asObservable();
    }

}
