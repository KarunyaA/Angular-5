import { Component, OnInit, ElementRef, ViewChild, Input } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';

import { JBHGlobals } from 'app/app.service';
import { ViewOrderService } from 'app/features/view-order/view-order.service';
import { OrderFormBuilder } from 'app/features/create-orders/orders/order-form-builder.service';
import { ShipmentInformationService } from './services/shipment-information.service';

@Component({
  selector: 'app-shipment-information',
  templateUrl: './shipment-information.component.html',
  styleUrls: ['./shipment-information.component.scss'],
  providers: [ShipmentInformationService]
})

export class ShipmentInformationComponent implements OnInit {
  @Input() isCurrViewTemplate: boolean;
  @Input() shipmentInformation: any;
  @ViewChild('taginput') tagel: ElementRef;
  @ViewChild('shipmentRequirementsTagsKey') shipmentRequirementsTagsKey: any;
  @ViewChild('shipmentIdentificationNumber') shipmentIdentificationNumber: any;
  @ViewChild('ordertype') ordertype: any;
  @ViewChild('secordtyp') secordtyp: any;
  @ViewChild('fleetCode') fleetCode: any;
  @ViewChild('portofentry') portofentry: any;
  @ViewChild('portofexit') portofexit: any;
  @ViewChild('bondType') bondType: any;
  @ViewChild('bondCarrier') bondCarrier: any;
  @ViewChild('bondHolder') bondHolder: any;
  @ViewChild('internationalService') internationalService: any;
  @ViewChild('clearingcustoms') clearingcustoms: any;

  public element: any;
  public placeholder = 'Add tag';
  public debounceValue: any;
  public orderTypeList: any = [];
  public secondaryOrderTypeList: any[] = [];
  public shipmentRequirementList: any[] = [];
  public fleetCodeList: any[] = [];
  public carrierNameList: any[] = [];
  public volumecarrierNameList: any[] = [];
  public customsBrokerList: any[] = [];
  public clearingCustomsList: any[] = [];
  public internationalServicesList: any[] = [];
  public bondHolderRoleList: any[] = [];
  public bondHolderPartyList: any[] = [];
  public bondHolderTypesList: any[] = [];
  public portOfEntryList: any[] = [];
  public portOfExitList: any[] = [];
  public internationalServiceDetails: any = [];
  public shipmentCompleteDetails: any = [];
  public selectedTradeShowCarrierName: string;
  public selectedBondHolderRoleCode: string;
  public shipmentRequirementsTags: string[] = [];
  public fleetcodeflag = false;
  public rmaorderflag = false;
  public rmanumberflag = false;
  public maritimeflag = false;
  public viewSection = true;
  public editSection = false;
  public refrigeratedIdentifier: string;

  // shipment requirement components
  public tradeshow = false;
  public volship = false;
  public tempcontrol = false;
  public intship = false;
  public refrigerated = false;
  public foodsafety = false;
  // temperature control components
  public precoolflag = false;
  public operatingflag = false;
  public omaximumerrorflag = false;
  public maximumerrorflag = false;
  public precooladdtemperatureflag = false;
  public operaddtemperatureflag = false;
  public addtemperaturezoneflag = false;
  public addoptemperaturezoneflag = false;
  public ptemperaturezone: any[] = [];
  public otemperaturezone: any[] = [];
  public ptemperaturezoneinFah: any[] = [];
  public otemperaturezoneinFah: any[] = [];
  public errorflag = false;
  public precoolerrorflag = false;
  public tscarrierId: any;
  public vscarrierId: any;
  // international shipment components
  public inbondflag = false;
  public addcustombrokerflag = false;
  public customsbrokersdisplayflag = false;
  public railintactserviceflag = false;
  public customsBrokerDetails: any[] = [];
  public customsbrokerId: number;
  public clearingcountrycode = '';
  public ordercrossborderdetailid: any;
  // getorder variables
  public orderData: any;
  public subscription: any;
  public saveSubscription: any;
  public serviceOfferingValue = '';
  public businessUnitValue = '';
  public transitMode = '';
  public orderType = '';
  public orderId = '';
  public populateFlag = true;
  public addressDetails: any = [];
  public countrycode: any = [];
  public rows: any = [];
  // temperature control save
  public equipmentRequirementID: any = '';
  public specificationID: any = '';
  public specificationAssociationID: any = '';
  public contactDetails: any;
  public tempControl: any;
  public temperatureControlFlag = false;
  public shipmentReqArray: any[] = [];
  public params: any = {
    'orderEquipmentRequirementID': '',
    'equipmentID': 0,
    'trailerPreloadedIndicator': 'Y',
    'equipmentTypeRequiredIndicator': 'Y',
    'equipmentLengthRequiredIndicator': 'Y',
    'equipmentClassificationTypeAssociationID': 1,
    'orderEquipmentRequirementSpecificationAssociations': [{
      'orderEquipmentRequirementSpecificationAssociationID': '',
      'equipmentRequirementSpecificationAssociationID': 1,
      'equipmentRequirementSpecificationDetailID': '',
      'orderEquipmentRequirementSpecificationDetails': []
    }],
    'orderNonCompanyEquipmentDetails': [],
    'orderEquipmentRequirementFeatureAssociations': [],
    'order': ''
  };
  public array = ['shipmentIdentificationNumber', 'orderTypeCode', 'orderSubTypeCode', 'orderValueAmount'];
  public internationalshipmentarray = ['vesselNumber', 'voyageNumber', 'bondHolder', 'bondHolderCarrierName', 'bondType',
    'bondNumber', 'entryNumber', 'portOfExit', 'portOfEntry'];
  public tradeshowarray = ['carrierName', 'carrierQuoteNumber', 'carrierBoothNumber'];
  public volshiparray = ['volcarrierName', 'volcarrierQuoteNumber'];
  public tradeShowFlag: boolean = false;
  public volumeShowFlag: boolean = false;
  public volumeData: any;
  public tradeData: any;
  constructor(public jbhGlobals: JBHGlobals,
    public formBuilder: FormBuilder,
    public viewOrderService: ViewOrderService,
    public orderFormBuilder: OrderFormBuilder,
    public shipmentInformationService: ShipmentInformationService) { }

  ngOnInit() {
    this.serviceCallInit();
    this.shipmentInformation = this.orderFormBuilder.orderForm['controls']['shipmentInformation'];
    this.shipmentInformation.get('shipmentRequirementsTags').setValidators([Validators.required]);
    this.debounceValue = this.jbhGlobals.settings.debounce;
    this.getOrderValues();
    this.loadShipmentRequirement();
    // shipment information value capture
    this.shipmentInformation['controls']['shipmentIdentificationNumber']['valueChanges']
      .debounceTime(this.debounceValue)
      .distinctUntilChanged()
      .subscribe((selectedshipmentIdentification) => {
        this.orderData.shipmentIdentificationNumber = selectedshipmentIdentification;
        console.log(this.orderData.shipmentIdentificationNumber);
        this.viewOrderService.saveData(this.orderData);
      }, (err: Error) => {
        this.jbhGlobals.logger.info(err);
      });
    // order sub type value capture
    this.shipmentInformation['controls']['orderSubTypeCode']['valueChanges']
      .debounceTime(this.debounceValue)
      .distinctUntilChanged()
      .subscribe((selectedOrdSubType) => {
        this.orderData.orderSubTypeCode = selectedOrdSubType;
        this.viewOrderService.saveData(this.orderData);
      }, (err: Error) => {
        this.jbhGlobals.logger.info(err);
      });
    // vessel number value capture
    this.shipmentInformation['controls']['vesselNumber']['valueChanges']
      .debounceTime(this.debounceValue)
      .distinctUntilChanged()
      .subscribe((selectedVesselNumber) => {
        if (this.orderData.internationalOrderElement) {
          if (this.orderData.internationalOrderElement.length === 0) {
            this.createInternationalOrderElement();
          }
          this.orderData.internationalOrderElement[0].vesselNumber = selectedVesselNumber;
          this.viewOrderService.saveData(this.orderData);
        }
      }, (err: Error) => {
        this.jbhGlobals.logger.info(err);
      });
    // voyage number value capture
    this.shipmentInformation['controls']['voyageNumber']['valueChanges']
      .debounceTime(this.debounceValue)
      .distinctUntilChanged()
      .subscribe((selectedVoyageNumber) => {
        if (this.orderData.internationalOrderElement) {
          if (this.orderData.internationalOrderElement.length === 0) {
            this.createInternationalOrderElement();
          }
          this.orderData.internationalOrderElement[0].voyageNumber = selectedVoyageNumber;
          this.viewOrderService.saveData(this.orderData);
        }
      }, (err: Error) => {
        this.jbhGlobals.logger.info(err);
      });
    // trade show carrier name value capture
    this.shipmentInformation['controls']['volcarrierName']['valueChanges']
      .debounceTime(this.debounceValue)
      .distinctUntilChanged()
      .subscribe((selectedVolumeShipmentCarrierName) => {
        if (!this.jbhGlobals.utils.isEmpty(selectedVolumeShipmentCarrierName) && selectedVolumeShipmentCarrierName.length > 2) {
          this.loadVolumeCarrierName(selectedVolumeShipmentCarrierName);
        }
      }, (err: Error) => {
        this.jbhGlobals.logger.info(err);
      });
    // trade show carrier name value capture
    this.shipmentInformation['controls']['carrierName']['valueChanges']
      .debounceTime(this.debounceValue)
      .distinctUntilChanged()
      .subscribe((selectedTradeShowCarrierName) => {
        if (!this.jbhGlobals.utils.isEmpty(selectedTradeShowCarrierName) && selectedTradeShowCarrierName.length > 2) {
          this.loadCarrierName(selectedTradeShowCarrierName);
        }
      }, (err: Error) => {
        this.jbhGlobals.logger.info(err);
      });
    // customs broker value capture
    this.shipmentInformation['controls']['customsbrokercarrier']['valueChanges']
      .debounceTime(this.debounceValue)
      .distinctUntilChanged()
      .subscribe((selectedcustomsbroker) => {
        if (!this.jbhGlobals.utils.isEmpty(selectedcustomsbroker) && selectedcustomsbroker.length > 2) {
          this.loadCustomsBroker(selectedcustomsbroker);
        }
      }, (err: Error) => {
        this.jbhGlobals.logger.info(err);
      });
    // entry number value capture
    this.shipmentInformation['controls']['entryNumber']['valueChanges']
      .debounceTime(this.debounceValue)
      .distinctUntilChanged()
      .subscribe((selectedEntryNumber) => {
        if (this.orderData.internationalOrderElement) {
          if (this.orderData.internationalOrderElement.length === 0) {
            this.createInternationalOrderElement();
          }
          this.orderData.internationalOrderElement[0].entryNumber = selectedEntryNumber;
          this.viewOrderService.saveData(this.orderData);
        }
      }, (err: Error) => {
        this.jbhGlobals.logger.info(err);
      });
    // bond number value capture
    this.shipmentInformation['controls']['bondNumber']['valueChanges']
      .debounceTime(this.debounceValue)
      .distinctUntilChanged()
      .subscribe((selectedBondNumber) => {
        if (this.orderData.internationalOrderElement) {
          if (this.orderData.internationalOrderElement.length === 0) {
            this.createInternationalOrderElement();
          }
          this.orderData.internationalOrderElement[0].bondNumber = selectedBondNumber;
          this.viewOrderService.saveData(this.orderData);
        }
      }, (err: Error) => {
        this.jbhGlobals.logger.info(err);
      });
    // bond holder role value capture
    this.shipmentInformation['controls']['bondHolder']['valueChanges']
      .debounceTime(this.debounceValue)
      .distinctUntilChanged()
      .subscribe((selectedBondHolderRole) => {
        this.selectedBondHolderRoleCode = selectedBondHolderRole;
        if (this.orderData.internationalOrderElement) {
          if (this.orderData.internationalOrderElement.length === 0) {
            this.createInternationalOrderElement();
          }
          this.orderData.internationalOrderElement[0].bondHolder = selectedBondHolderRole;
          this.viewOrderService.saveData(this.orderData);
        }
        this.loadBondHolderParty();
      }, (err: Error) => {
        this.jbhGlobals.logger.info(err);
      });
    // bond holder party value capture
    this.shipmentInformation['controls']['bondHolderCarrierName']['valueChanges']
      .debounceTime(this.debounceValue)
      .distinctUntilChanged()
      .subscribe((selectedBondHolderparty) => {
        if (this.orderData.internationalOrderElement) {
          if (this.orderData.internationalOrderElement.length === 0) {
            this.createInternationalOrderElement();
          }
          this.orderData.internationalOrderElement[0].bondHolderCarrierName = selectedBondHolderparty;
          this.viewOrderService.saveData(this.orderData);
        }
      }, (err: Error) => {
        this.jbhGlobals.logger.info(err);
      });
    // bond type value capture
    this.shipmentInformation['controls']['bondType']['valueChanges']
      .debounceTime(this.debounceValue)
      .distinctUntilChanged()
      .subscribe((selectedBondType) => {
        if (this.orderData.internationalOrderElement) {
          if (this.orderData.internationalOrderElement.length === 0) {
            this.createInternationalOrderElement();
          }
          this.orderData.internationalOrderElement[0].bondType = selectedBondType;
          this.viewOrderService.saveData(this.orderData);
        }
      }, (err: Error) => {
        this.jbhGlobals.logger.info(err);
      });
    // fleet code value capture
    this.shipmentInformation['controls']['fleetCode']['valueChanges']
      .debounceTime(this.debounceValue)
      .distinctUntilChanged()
      .subscribe((selectedfleetcode) => {
        if (!this.jbhGlobals.utils.isArray(this.orderData.orderOperationalElements)) {
          this.orderData.orderOperationalElements = [];
        }
        if (!this.jbhGlobals.utils.isEmpty(this.orderData.orderOperationalElements)) {
          if (this.orderData.orderOperationalElements.length === 0) {
            const obj = {
              'fleetCode': '',
            };
            this.orderData.orderOperationalElements.push(obj);
          }
          this.orderData.orderOperationalElements[0].fleetCode = selectedfleetcode;
          this.viewOrderService.saveData(this.orderData);
        }
      }, (err: Error) => {
        this.jbhGlobals.logger.info(err);
      });
    // auto rate value capture
    this.shipmentInformation['controls']['autorateIndicator']['valueChanges']
      .debounceTime(this.debounceValue)
      .distinctUntilChanged()
      .subscribe((selectedautorate) => {
        if (!this.jbhGlobals.utils.isEmpty(this.orderData.orderBillingDetailDTOs)) {
          if (this.orderData.orderBillingDetailDTOs.length === 0) {
            const obj = {
              'autorateIndicator': ''
            };
            this.orderData.orderBillingDetailDTOs.push(obj);
          }
          if (selectedautorate === true) {
            this.orderData.orderBillingDetailDTOs[0].autorateIndicator = 'Y';
          } else {
            this.orderData.orderBillingDetailDTOs[0].autorateIndicator = 'N';
          }
          this.viewOrderService.saveData(this.orderData);
        }
      }, (err: Error) => {
        this.jbhGlobals.logger.info(err);
      });
    // order value capture
    this.shipmentInformation['controls']['orderValueAmount']['valueChanges']
      .debounceTime(this.debounceValue)
      .distinctUntilChanged()
      .subscribe((orderValue) => {
        this.orderData.orderValueAmount = orderValue;
        this.viewOrderService.saveData(this.orderData);
      }, (err: Error) => {
        this.jbhGlobals.logger.info(err);
      });
  }
  /* ngAfterViewInit() {
      const me = this;
      this.jbhGlobals.hotkeys.add('shift a', function(event){
           me.shipmentRequirementsTagsKey.focus();
      });
      this.jbhGlobals.hotkeys.add('shift b', function(event){
          me.shipmentIdentificationNumber.nativeElement.focus();
      });
   }; */

   public serviceCallInit() {
        this.viewOrderService.getData().subscribe(data => {
          if (!this.jbhGlobals.utils.isEmpty(data)) {
            this.shipmentCompleteDetails = data;
            // console.log(this.shipmentCompleteDetails.internationalOrderElement[0].bondHolder);
            this.refrigeratedIdentifier = this.shipmentCompleteDetails.orderRefrigeratedIndicator;
            const tradeShow = this.shipmentCompleteDetails.orderCarrierDetailDTOs;
            if (!this.jbhGlobals.utils.isEmpty(tradeShow)) {
                for (let i = 0; i < tradeShow.length; i++) {
                if (tradeShow[i].orderCarrierDetail.orderVolumeTradeShowTypeCode !== null &&
                  tradeShow[i].orderCarrierDetail.orderVolumeTradeShowTypeCode === 'TrdShip') {
                  this.tradeShowFlag = true;
                  this.tradeData = tradeShow[i];
                }
               if (tradeShow[i].orderCarrierDetail.orderVolumeTradeShowTypeCode !== null &&
                tradeShow[i].orderCarrierDetail.orderVolumeTradeShowTypeCode === 'VolShip') {
                  this.volumeShowFlag = true;
                  this.volumeData = tradeShow[i];
                }
              }
            }
           if (!this.jbhGlobals.utils.isEmpty(this.shipmentCompleteDetails.orderEquipmentRequirementDTOs[0])) {
          const temp = this.shipmentCompleteDetails.orderEquipmentRequirementDTOs[0].orderEquipmentRequirement;
          if (!this.jbhGlobals.utils.isEmpty(temp.orderEquipmentRequirementSpecificationAssociations[0] &&
            temp.orderEquipmentRequirementSpecificationAssociations[0].orderEquipmentRequirementSpecificationDetails[0])) {
          this.tempControl = temp.orderEquipmentRequirementSpecificationAssociations[0].orderEquipmentRequirementSpecificationDetails[0];
          this.temperatureControlFlag = true;
          }
        }
            if (data['orderCrossesBorderDetailDTOs'][0] && data['orderCrossesBorderDetailDTOs'][0]['profileDTO']) {
              this.rows = [];
              for (let i = 0; i < data['orderCrossesBorderDetailDTOs'].length; i++) {
              this.contactDetails = data['orderCrossesBorderDetailDTOs'][i]['profileDTO']['contactDTO'];
              this.addressDetails = data['orderCrossesBorderDetailDTOs'][i]['profileDTO']['addressDTO'];
              this.countrycode = data['orderCrossesBorderDetailDTOs'][i]['clearingCountryCode'];
              const customBrokerObj = {
                'broker': this.addressDetails,
                'clearing': this.countrycode
              };
              this.rows.push(customBrokerObj);
            }
          }
        // console.log(this.shipmentInformation.controls['shipmentRequirementsTags'].value);
      }
        });
    }
  // get orderdto value
  public getOrderValues(): void {
    this.subscription = this.viewOrderService.getData().subscribe(sharedOrderData => {
      this.orderData = sharedOrderData;
      if (this.orderData) {
        if (this.serviceOfferingValue !== this.orderData.serviceOfferingCode
          || this.businessUnitValue !== this.orderData.financeBusinessUnitCode) {
            this.transitMode = this.orderData.transitModeCode;
            this.serviceOfferingValue = this.orderData.serviceOfferingCode;
            this.businessUnitValue = this.orderData.financeBusinessUnitCode;
            // this.businessUnitValueBased();
        }
        if ( this.orderData.serviceOfferingCode && this.orderData.financeBusinessUnitCode) {
            this.loadOrderType();
        }
        if (this.populateFlag) {
          // this.shipmentRequirementsTagsKey.active = [];
          this.populateData();
        }
      }
      if (this.orderData && this.orderData.tempData) {
          if (this.serviceOfferingValue !== this.orderData.tempData.serviceOfferingCode
          || this.businessUnitValue !== this.orderData.tempData.financeBusinessUnitCode) {
              this.transitMode = this.orderData.tempData.transitMode;
              this.serviceOfferingValue = this.orderData.tempData.serviceOfferingCode;
              this.businessUnitValue = this.orderData.tempData.financeBusinessUnitCode;
              // this.businessUnitValueBased();
          }
          if (this.populateFlag) {
              this.shipmentRequirementsTagsKey.active = [];
              this.populateTemplateData();
          }
          if (this.orderData.tempData.serviceOfferingCode && this.orderData.tempData.financeBusinessUnitCode) {
              this.loadOrderType();
          }
      }
    });
  }
  public checkTransitMode(): void {
    if (this.transitMode === 'Rail') {
        this.railintactserviceflag = true;
        this.loadPortOfEntry();
        this.loadPortOfExit();
      } else {
        this.railintactserviceflag = false;
      }
  }
  // public businessUnitValueBased(): void {
  //   debugger;
  //   if (!this.jbhGlobals.utils.isEmpty(this.businessUnitValue) &&
  //      !this.jbhGlobals.utils.isEmpty(this.serviceOfferingValue) &&
  //      !this.jbhGlobals.utils.isEmpty(this.transitMode)) {
  //     this.checkTransitMode();
  //     switch (this.businessUnitValue) {
  //       case 'JBT':
  //         this.fleetcodeflag = true;
  //         //this.loadFleetCode();
  //         break;
  //       case 'ICS':
  //         if (this.addTag({ id: 'Refrigerated', text: 'Refrigerated' })) {
  //           this.refrigerated = true;
  //           this.saveRefrigeratedIndicatorValue(true);
  //         }
  //         this.serviceOfferingValueBased();
  //         break;
  //       case 'DCS':
  //         this.refrigerated = false;
  //         this.saveRefrigeratedIndicatorValue(false);
  //         this.volship = false;
  //         this.tradeshow = false;
  //         this.serviceOfferingValueBased();
  //         break;
  //       case 'JBI':
  //         this.fleetcodeflag = true;
  //         //this.loadFleetCode();
  //         break;
  //       default:
  //         this.refrigerated = false;
  //         this.saveRefrigeratedIndicatorValue(false);
  //         this.volship = false;
  //         this.tradeshow = false;
  //         break;
  //     }
  //   }
  // }
  // public serviceOfferingValueBased(): void {
  //   debugger;
  //   if (!this.jbhGlobals.utils.isEmpty(this.serviceOfferingValue)) {
  //     switch (this.serviceOfferingValue) {
  //       case 'Maritime':
  //         this.maritimeflag = true;
  //         this.fleetcodeflag = true;
  //         //this.loadFleetCode();
  //         break;
  //       case 'LTL Dir':
  //         if (this.addTag({ id: 'Volume Shipment', text: 'Volume Shipment' })) {
  //           this.volship = true;
  //         }
  //         if (this.addTag({ id: 'Trade Show', text: 'Trade Show' })) {
  //           this.tradeshow = true;
  //         }
  //         this.fleetcodeflag = true;
  //         //this.loadFleetCode();
  //         this.maritimeflag = false;
  //         break;
  //       case 'Brokerage':
  //       case 'Flatbed':
  //         this.fleetcodeflag = true;
  //         //this.loadFleetCode();
  //         break;
  //       case 'LTL Cons':
  //         this.rmanumberflag = true;
  //         this.fleetcodeflag = false;
  //         this.maritimeflag = false;
  //         break;
  //       case 'Freezer':
  //         if (this.addTag({ id: 'Refrigerated', text: 'Refrigerated' })) {
  //           this.refrigerated = true;
  //           this.saveRefrigeratedIndicatorValue(true);
  //         }
  //         this.fleetcodeflag = true;
  //         //this.loadFleetCode();
  //         this.maritimeflag = false;
  //         break;
  //       case 'Final Mile':
  //         this.fleetcodeflag = false;
  //         this.rmanumberflag = true;
  //         this.maritimeflag = false;
  //         break;
  //       default:
  //         this.maritimeflag = false;
  //         this.fleetcodeflag = true;
  //         //this.loadFleetCode();
  //         this.rmanumberflag = false;
  //         this.refrigerated = false;
  //         this.saveRefrigeratedIndicatorValue(false);
  //         break;
  //     }
  //   }
  // }


  // service call
  public loadOrderType(): void {
    const params = { 'financeBusinessUnitCode': this.businessUnitValue, 'serviceOfferingCode': this.serviceOfferingValue };
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getordertype, params, false).subscribe(data => {
      this.orderTypeList = data['_embedded']['orderTypeFinanceBusinessUnitServiceOfferingAssociations'];
      // this.orderTypeList = data['orderTypeFinanceBusinessUnitServiceOfferingAssociations'];
         this.shipmentInformation['controls']['orderTypeCode'].setValue(this.shipmentCompleteDetails.orderTypeCode);
         }
    );
  }
  public loadSecondaryOrderType(): void {
    const params = { 'orderTypeCode': this.orderType, 'projection': true };
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getsecordertype, params, false).subscribe(data => {
      this.secondaryOrderTypeList = data['_embedded']['orderTypeSubTypeAssociations'];
      console.log(this.secondaryOrderTypeList);
       this.shipmentInformation['controls']['orderSubTypeCode'].setValue(this.shipmentCompleteDetails.orderSubTypeCode);
    }
    );
  }
  public loadShipmentRequirement(): void {
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getshipmentrequirements).subscribe(data => {
      this.shipmentRequirementList = data;
      console.log( this.shipmentRequirementList);
    });
  }
  public loadFleetCode(): void {
    this.shipmentInformationService.loadFleetCode(this.jbhGlobals.endpoints.order.getfleetcode,
      { 'businessunit': this.businessUnitValue }).subscribe(data => {
      this.fleetCodeList = data;
    });
  }
  public loadCarrierName(value): void {
    const params = { 'query': value, 'limit': 20 };
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getCarrier, params, false).subscribe(data => {
      this.carrierNameList = data;
    }
    );
  }
  public loadVolumeCarrierName(value): void {
    const params = { 'query': value, 'limit': 20 };
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getCarrier, params, false).subscribe(data => {
      this.volumecarrierNameList = data;
    }
    );
  }
  public loadCustomsBroker(value): void {
    const params = { value: value, roletype: 'BROKER', active: 'yes',
    page: 0, size: 5, approved: true, addresstype: 'PHYSICAL' };
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getcustomsbroker, params, false).subscribe(data => {
      this.customsBrokerList = data['profileDTO'];
    }
    );
  }
  public loadClearingCustoms(): void {
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getclearingcustoms).subscribe(data => {
      this.clearingCustomsList = data['country'];
      // this.shipmentInformation['controls']['serviceType'].setValue(this.shipmentCompleteDetails.internationalService[0].serviceType);
      console.log(this.clearingCustomsList);
    }
    );
  }
  public loadInternationalServices(): void {
    const params = { 'serviceCategoryCode': 'IOS' };
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getinternationalservices, params).subscribe(data => {
      this.internationalServicesList = data['_embedded']['serviceTypes'];
      this.shipmentInformation['controls']['serviceType'].setValue(this.shipmentCompleteDetails.internationalService[0].serviceType);
    }
    );
  }
  public loadBondHolderRole(): void {
    const params = { 'businessUnit': this.businessUnitValue, 'transitMode': this.transitMode };
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getbondholderrole, params).subscribe(data => {
      this.bondHolderRoleList = data;
      const tempBondHolderRole = this.shipmentCompleteDetails.internationalOrderElement[0].bondHolder;
       this.shipmentInformation['controls']['bondHolder'].setValue(tempBondHolderRole);
    }
    );
  }
  public loadBondHolderParty(): void {
    const params = { 'bondHolderCode': this.selectedBondHolderRoleCode };
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getbondholderparty, params, true).subscribe(data => {
      this.bondHolderPartyList = data['_embedded']['bondHolderCarriers'];
      const tempBondHolderParty = this.shipmentCompleteDetails.internationalOrderElement[0].bondHolderCarrierName;
       this.shipmentInformation['controls']['bondHolderCarrierName'].setValue(tempBondHolderParty);
    }
    );
  }
  public loadBondHolderTypes(): void {
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getbondholdertype).subscribe(data => {
      this.bondHolderTypesList = data['_embedded']['bondTypes'];
      this.shipmentInformation['controls']['bondType'].setValue(this.shipmentCompleteDetails.internationalOrderElement[0].bondType);
    }
    );
  }
  public loadPortOfEntry(): void {
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getportofentry).subscribe(data => {
      this.portOfEntryList = data['EntryPort'];
      this.shipmentInformation['controls']['entryNumber'].setValue(this.shipmentCompleteDetails.internationalOrderElement[0].entryNumber);
    }
    );
  }
  public loadPortOfExit(): void {
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getportofexit).subscribe(data => {
      this.portOfExitList = data['ExitPort'];
      this.shipmentInformation['controls']['portOfExit'].setValue(this.shipmentCompleteDetails.internationalOrderElement[0].portOfExit);
    }
    );
  }
  public loadPortOfEntryByExit(value): void {
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getportofentrybyexit + '/' + value).subscribe(data => {
      this.portOfEntryList = data['EntryPort'];
      this.shipmentInformation.controls['portOfEntry'].setValue('');
    }
    );
  }
  // functionality
  public createInternationalOrderElement(): void {
    const obj = {
      'bondHolder': '',
      'bondHolderCarrierName': '',
      'bondNumber': '',
      'bondType': '',
      'entryNumber': '',
      'portOfEntry': null,
      'portOfExit': null,
      'vesselNumber': null,
      'voyageNumber': null
    };
    this.orderData.internationalOrderElement.push(obj);
  }
  public saveRefrigeratedIndicatorValue(booleanvalue): void {
    if (booleanvalue === true) {
      this.orderData.orderRefrigeratedIndicator = 'Y';
    } else {
      this.orderData.orderRefrigeratedIndicator = 'N';
    }
  }
  public onSelectOrderType(selectedOrdType): void {
    this.orderType = selectedOrdType;
    switch (selectedOrdType) {
      case 'Return':
        this.orderSubTypeSetValidation(false);
        if (this.rmanumberflag === true) {
          this.rmaorderflag = true;
        } else {
          this.rmaorderflag = false;
        }
        break;
      case 'Other':
        this.orderSubTypeSetValidation(true);
        this.rmaorderflag = false;
        break;
      default:
        this.rmaorderflag = false;
        this.orderSubTypeSetValidation(false);
        break;
    }
    this.orderData.orderTypeCode = selectedOrdType;
    this.viewOrderService.saveData(this.orderData);
    this.loadSecondaryOrderType();
    this.shipmentInformation.get('orderSubTypeCode').setValue('');
  }
  public orderSubTypeSetValidation(booleanVal): void {
    if (booleanVal) {
      this.shipmentInformation.get('orderSubTypeCode').setValidators([Validators.required]);
    } else {
      this.shipmentInformation.get('orderSubTypeCode').setValidators([]);
    }
    this.shipmentInformation.get('orderSubTypeCode').updateValueAndValidity();
  }
  public inbondfreight(check: boolean): void {
    if (check === true) {
      this.inbondflag = true;
      this.loadBondHolderRole();
      this.loadBondHolderTypes();
      if (this.railintactserviceflag === true) {
        this.loadPortOfEntry();
        this.loadPortOfExit();
      }
    } else {
      this.inbondflag = false;
      for (let i = 0; i < this.internationalshipmentarray.length; i++) {
        this.shipmentInformation['controls'][this.internationalshipmentarray[i]]['setValue']('');
      }
    }
  }

   public onShipmentRequirementLoadData() {
    this.shipmentReqArray = [];
    // alert();
     if (this.tradeShowFlag === true) {
     const tradeShowObj = {'id': this.shipmentRequirementList[1], 'text': this.shipmentRequirementList[1]};
       this.shipmentReqArray.push(tradeShowObj);
       this.tradeshow = true;
     }
        if (this.volumeShowFlag === true) {
     const volumeShowObj = {'id': this.shipmentRequirementList[2], 'text': this.shipmentRequirementList[2]};
     this.shipmentReqArray.push(volumeShowObj);
     this.volship = true;
   }
   if (this.temperatureControlFlag === true) {
         const tempCtrlObj = {'id': 'Temperature Control', 'text': 'Temperature Control'};
          this.shipmentReqArray.push(tempCtrlObj);
          this.tempcontrol = true;
       }
       if (this.refrigeratedIdentifier !== null && this.refrigeratedIdentifier === 'Y') {
         const refrigeratedObj = {'id': 'Refrigerated', 'text': 'Refrigerated'};
          this.shipmentReqArray.push(refrigeratedObj);
          this.refrigerated = true;
       }
       if (this.shipmentCompleteDetails.internationalOrderElement.length > 0) {
         const internationalObj = {'id': 'International', 'text': 'International'};
           this.shipmentReqArray.push(internationalObj);
       }
       if (this.shipmentCompleteDetails.orderHighValueIndicator === true) {
         const highValueObj = {'id': this.shipmentRequirementList[0], 'text': this.shipmentRequirementList[0]};
           this.shipmentReqArray.push(highValueObj);
       }
       if (this.shipmentCompleteDetails.orderFoodSafetyDetails.length > 0) {
         const foodSafetyObj = {'id': 'Food Safety', 'text': 'Food Safety'};
           this.shipmentReqArray.push(foodSafetyObj);
       }
       if (this.shipmentCompleteDetails.orderCrossesBorderDetailDTOs.length > 0) {
          const internatinalShipObj = {'id': this.shipmentRequirementList[3], 'text': this.shipmentRequirementList[3]};
           this.shipmentReqArray.push(internatinalShipObj);
           this.intship = true;
       }
      this.shipmentInformation.controls['shipmentRequirementsTags'].setValue(this.shipmentReqArray);
  }

  public onShipmentRequirementTagSelection(e, precool, operating, booleanvalue): void {
    // console.log(e.text,e, precool, operating, booleanvalue);
    switch (e.text) {
      case 'High Value Shipment':
        this.orderValueSetValidation(booleanvalue);
        this.orderData.orderHighValueIndicator = booleanvalue;
        this.viewOrderService.saveData(this.orderData);
        break;
      case 'Trade Show':
        this.orderValueSetValidation(false);
        this.tradeshow = booleanvalue;
        console.log(this.tradeshow);
        if (!this.tradeshow) {
          for (let j = 0; j < this.tradeshowarray.length; j++) {
            this.shipmentInformation['controls'][this.tradeshowarray[j]]
            ['setValue']('');
          }
          if (this.jbhGlobals.utils.isArray(this.orderData.orderCarrierDetails)) {
             if (this.orderData.orderCarrierDetails.length > 0) {
              for (let i = 0; i < this.orderData.orderCarrierDetails.length; i++) {
                if (this.orderData.orderCarrierDetails[i].orderVolumeTradeShowTypeCode === 'TrdShip') {
                  this.orderData.orderCarrierDetails.splice(i, 1);
                }
              }
            }
          }
        }
        break;
      case 'Volume Shipment':
        this.orderValueSetValidation(false);
        this.volship = booleanvalue;
        if (!this.volship) {
          for (let j = 0; j < this.volshiparray.length; j++) {
            this.shipmentInformation['controls'][this.volshiparray[j]]['setValue']('');
          }
          if (this.jbhGlobals.utils.isArray(this.orderData.orderCarrierDetails)) {
            if (this.orderData.orderCarrierDetails.length > 0) {
              for (let i = 0; i < this.orderData.orderCarrierDetails.length; i++) {
                if (this.orderData.orderCarrierDetails[i].orderVolumeTradeShowTypeCode === 'VolShip') {
                  this.orderData.orderCarrierDetails.splice(i, 1);
                }
              }
            }
          }
        }
        break;
      case 'Temperature Control':
        this.orderValueSetValidation(false);
        this.tempcontrol = booleanvalue;
        if (booleanvalue) {
          this.onLoadOperating(operating);
          this.preCoolAutoFlag(precool);
        }
        break;
      case 'International Shipment':
        this.orderValueSetValidation(false);
        this.intship = booleanvalue;
        this.loadInternationalServices();
        if (!this.intship) {
          this.shipmentInformation['controls']['serviceType']['setValue']('');
          this.inbondfreight(false);
          this.intship = false;
        }
        break;
      case 'Refrigerated':
        this.orderValueSetValidation(false);
        this.refrigerated = booleanvalue;
        this.saveRefrigeratedIndicatorValue(booleanvalue);
        this.viewOrderService.saveData(this.orderData);
        this.preCoolAutoFlag(precool);
        break;
      case 'Food Safety':
        this.orderValueSetValidation(false);
        this.foodsafety = booleanvalue;
        if (!this.jbhGlobals.utils.isArray(this.orderData.orderFoodSafetyDetails)) {
          this.orderData.orderFoodSafetyDetails = [];
        }
        if (booleanvalue === true) {
          const obj = {
            orderFoodSafetyDetailID: 1
          };
          this.orderData.orderFoodSafetyDetails.push(obj);
          this.viewOrderService.saveData(this.orderData);
        } else {
          this.orderData.orderFoodSafetyDetails = [];
          this.viewOrderService.saveData(this.orderData);
        }
        this.preCoolAutoFlag(precool);
        break;
      default:
        break;
    }
  }
  public orderValueSetValidation(booleanVal): void {
    if (booleanVal) {
      this.shipmentInformation.controls['orderValueAmount'].setValidators([Validators.required, Validators.pattern('^[0-9]{1,20}$')]);
    } else {
      this.shipmentInformation.controls['orderValueAmount'].setValidators([Validators.pattern('^[0-9]{1,20}$')]);
    }
    this.shipmentInformation.get('orderValueAmount').updateValueAndValidity();
  }
  public onTradeShowCarrierSelect(quote, booth, event?: any): void {
    if (!this.jbhGlobals.utils.isArray(this.orderData.orderCarrierDetails)) {
      this.orderData.orderCarrierDetails = [];
    }
    if (event) {
      this.tscarrierId = event.item.carrierID;
    }
    if (this.tscarrierId && quote.value && booth.value) {
      if (this.orderData.orderCarrierDetails.length > 0) {
        for (let i = 0; i < this.orderData.orderCarrierDetails.length; i++) {
          if (this.orderData.orderCarrierDetails[i].orderVolumeTradeShowTypeCode === 'TrdShip') {
            this.orderData.orderCarrierDetails[i].carrierQuoteNumber = quote.value;
            this.orderData.orderCarrierDetails[i].carrierBoothNumber = booth.value;
            this.orderData.orderCarrierDetails[i].carrierName = this.tscarrierId;
          } else {
            this.carrierDetailsObjectCreation(this.tscarrierId, quote, booth);
          }
        }
      } else {
         this.carrierDetailsObjectCreation(this.tscarrierId, quote, booth);
      }
      this.viewOrderService.saveData(this.orderData);
    }
  }
  public onVolumeShipmentCarrierSelect(quote, event?: any): void {
    if (!this.jbhGlobals.utils.isArray(this.orderData.orderCarrierDetails)) {
      this.orderData.orderCarrierDetails = [];
    }
    if (event) {
      this.vscarrierId = event.item.carrierID;
    }
    if (this.vscarrierId && quote.value) {
      if (this.orderData.orderCarrierDetails.length > 0) {
        for (let i = 0; i < this.orderData.orderCarrierDetails.length; i++) {
          if (this.orderData.orderCarrierDetails[i].orderVolumeTradeShowTypeCode === 'VolShip') {
            this.orderData.orderCarrierDetails[i].carrierQuoteNumber = quote.value;
            this.orderData.orderCarrierDetails[i].carrierBoothNumber = null;
            this.orderData.orderCarrierDetails[i].carrierName = this.vscarrierId;
          } else {
            this.carrierDetailsObjectCreation(this.vscarrierId, quote);
          }
        }
      } else {
        this.carrierDetailsObjectCreation(this.vscarrierId, quote);
      }
      this.viewOrderService.saveData(this.orderData);
    }
  }
  public carrierDetailsObjectCreation(carrierId, quote, booth?: any): void {
    const obj = {
      'orderCarrierDetailID': '',
      'orderVolumeTradeShowTypeCode': booth ? 'TrdShip' : 'VolShip',
      'carrierName': carrierId,
      'carrierQuoteNumber': quote.value,
      'carrierBoothNumber': booth ? booth.value : null
    };
    this.orderData.orderCarrierDetails.push(obj);
  }
  public onChangeInternationalService(selectedvalue): void {
    if (!this.jbhGlobals.utils.isArray(this.orderData.internationalService)) {
      this.orderData.internationalService = [];
    }
    const obj = {
      'serviceLevelTypeCode': 'IOS',
      'serviceType': selectedvalue
    };
    this.orderData.internationalService.push(obj);
    this.viewOrderService.saveData(this.orderData);
  }
  public onTemperatureSelect(temperature, check): void {
    switch (temperature.id) {
      case 'pre-cool-temperature':
        this.precoolflag = check;
        if (check === false) {
          this.ptemperaturezone = [];
          this.ptemperaturezoneinFah = [];
          this.onClickCancelTempZone(false);
        }
        break;
      case 'operating-temperature':
        this.operatingflag = check;
        if (check === false) {
          this.otemperaturezone = [];
          this.otemperaturezoneinFah = [];
          this.onClickCancelTempZone(true);
        }
        break;
      default:
        break;
    }
  }
  public preCoolAutoFlag(precool): void {
    // console.log("ref"+this.refrigerated,"temp"+this.tempcontrol,"food"+this.foodsafety);
      if (this.refrigerated === true && this.foodsafety === true && this.tempcontrol === true) {
        precool.checked = true;
        this.precoolflag = true;
      } else {
        precool.checked = false;
        this.precoolflag = false;
      }
  }
  public onLoadOperating(operating): void {
    operating.checked = true;
    this.operatingflag = true;
  }
  public onClickAddTempZone(booleanValue): void {
    if (booleanValue) { // operating
      if (this.otemperaturezone.length < 2) {
        this.omaximumerrorflag = false;
        this.operaddtemperatureflag = true;
      } else {
        this.omaximumerrorflag = true;
        this.onClickCancelTempZone(booleanValue);
      }
    } else { // precool
      if (this.ptemperaturezone.length < 2) {
        this.maximumerrorflag = false;
        this.precooladdtemperatureflag = true;
      } else {
        this.maximumerrorflag = true;
        this.onClickCancelTempZone(booleanValue);
      }
    }
  }
  public onBlurAddTempZone(booleanValue): void {
    if (booleanValue) { // operating
      this.omaximumerrorflag = false;
    } else { // precool
      this.maximumerrorflag = false;
    }
  }
  public onClickCancelTempZone(booleanValue): void {
    if (booleanValue) {
      this.operaddtemperatureflag = false;
      this.shipmentInformation.controls['temperatureLowRange'].setValue('');
      this.shipmentInformation.controls['temperatureHighRange'].setValue('');
      this.errorflag = false;
    } else {
      this.precooladdtemperatureflag = false;
      this.shipmentInformation.controls['frontZonePrecoolTemperature'].setValue('');
      this.shipmentInformation.controls['rearZonePrecoolTemperature'].setValue('');
      this.precoolerrorflag = false;
    }
  }
  public showTempInCel(showCel, flag): void {
    if (showCel.checked === true) {
      this.convertFahtoCel(flag, true);
    } else {
      this.convertFahtoCel(flag, false);
    }
    this.ptemperaturezone = this.jbhGlobals.utils.uniqWith(this.ptemperaturezone, this.jbhGlobals.utils.isEqual);
    this.otemperaturezone = this.jbhGlobals.utils.uniqWith(this.otemperaturezone, this.jbhGlobals.utils.isEqual);
  }
  public convertFahtoCel(flag, toCel): void {
    if (flag) {// oper
      this.otemperaturezone = [];
      this.toCelsius(this.otemperaturezoneinFah, flag, toCel);
    } else {// pre
      this.ptemperaturezone = [];
      this.toCelsius(this.ptemperaturezoneinFah, flag, toCel);
    }
  }
  public toCelsius(array, flag, toCel): void {
    for (let i = 0; i < array.length; i++) {
      const tempObj = { min: null, max: null };
      if (toCel) {
        // this.saveTemperatureControl(flag,array[i].min,array[i].max,true)
        tempObj.min = Math.round((array[i].min - 32) * (5 / 9));
        tempObj.max = Math.round((array[i].max - 32) * (5 / 9));
      } else {
        // this.saveTemperatureControl(flag,array[i].min,array[i].max,false)
        tempObj.min = array[i].min;
        tempObj.max = array[i].max;
      }
      if (flag) { // operating
        this.otemperaturezone.push(tempObj);
      } else { // pre cool
        this.ptemperaturezone.push(tempObj);
      }
    }
  }
  public addingTempZone(event, minTempZone, maxTempZone, flag, showCel): void {
    if (!this.jbhGlobals.utils.isEmpty(event.relatedTarget)) {
      if (event.relatedTarget.id === 'pre-cool-cancel-button' || event.relatedTarget.id === 'operating-cancel-button') {
        event.preventDefault();
        this.onClickCancelTempZone(flag);
      } else {
        this.addTempZone(minTempZone, maxTempZone, flag, showCel);
      }
    } else {
      this.addTempZone(minTempZone, maxTempZone, flag, showCel);
    }
  }
  public addTempZone(minTempZone, maxTempZone, flag, showCel): void {
    if (!this.jbhGlobals.utils.isEmpty(minTempZone.value) && !this.jbhGlobals.utils.isEmpty(maxTempZone.value)) {
      const minVal = parseInt(minTempZone.value, 10);
      const maxVal = parseInt(maxTempZone.value, 10);
      if (minVal >= -10 && minVal < 80 && minVal < maxVal && maxVal > -10 && maxVal > minVal && maxVal <= 80) {
        const tempObj = { min: null, max: null };
        tempObj.min = minVal;
        tempObj.max = maxVal;
        if (flag) { // operating temperature
          this.addoptemperaturezoneflag = true;
          this.operaddtemperatureflag = false;
          this.otemperaturezoneinFah.push(tempObj);
          this.shipmentInformation.controls['temperatureLowRange'].setValue('');
          this.shipmentInformation.controls['temperatureHighRange'].setValue('');
          this.errorflag = false;
        } else { // pre cool temperature
          this.addtemperaturezoneflag = true;
          this.precooladdtemperatureflag = false;
          this.ptemperaturezoneinFah.push(tempObj);
          this.shipmentInformation.controls['frontZonePrecoolTemperature'].setValue('');
          this.shipmentInformation.controls['rearZonePrecoolTemperature'].setValue('');
          this.precoolerrorflag = false;
        }
        this.showTempInCel(showCel, flag);
        this.saveTemperatureControl(flag, minVal, maxVal, showCel.checked);
      } else { // error message
        if (flag) {
          this.errorflag = true;
        } else {
          this.precoolerrorflag = true;
        }
      }
    }
  }
  public onRemoveTempZone(recordIndex, flag): void {
    let removeArray: any[] = [];
    if (flag) {
      this.otemperaturezoneinFah.splice(recordIndex, 1);
      removeArray = this.otemperaturezone.splice(recordIndex, 1);
      this.onRemoveSaveTempZone(flag, removeArray[0].min, removeArray[0].max);
      if (this.otemperaturezone.length === 0) {
        this.onClickCancelTempZone(flag);
      }
    } else {
      this.ptemperaturezoneinFah.splice(recordIndex, 1);
      removeArray = this.ptemperaturezone.splice(recordIndex, 1);
      this.onRemoveSaveTempZone(flag, removeArray[0].min, removeArray[0].max);
      if (this.ptemperaturezone.length === 0) {
        this.onClickCancelTempZone(flag);
      }
    }
  }

  saveTemperatureControl(flag, minVal, maxVal, showCel?: any): void {
    const obj = {
      'orderEquipmentRequirementSpecificationDetailID': '',
      'temperatureLowRange': '',
      'temperatureHighRange': '',
      'unitOfTemperatureMeasurementCode': '',
      'specificationDetailValue': '',
      'frontZoneprecoolTemperature': '',
      'rearZoneprecoolTemperature': '',
      'orderEquipmentRequirementSpecificationAssociation': {}
    };
    if (flag) {
      obj.temperatureLowRange = minVal.toString();
      obj.temperatureHighRange = maxVal.toString();
      if (showCel === true) {
        obj.unitOfTemperatureMeasurementCode = 'Celsius';
      } else {
        obj.unitOfTemperatureMeasurementCode = 'Fahrenheit';
      }
    } else {
      obj.frontZoneprecoolTemperature = minVal.toString();
      obj.rearZoneprecoolTemperature = maxVal.toString();
      if (showCel === true) {
        obj.unitOfTemperatureMeasurementCode = 'Celsius';
      } else {
        obj.unitOfTemperatureMeasurementCode = 'Fahrenheit';
      }
    }
    this.params.order = '/' + this.orderData.orderID;
    this.params.orderEquipmentRequirementID = this.equipmentRequirementID;
    this.params.orderEquipmentRequirementSpecificationAssociations[0].orderEquipmentRequirementSpecificationAssociationID
    = this.specificationAssociationID;
    const specDetails = this.params.orderEquipmentRequirementSpecificationAssociations[0].orderEquipmentRequirementSpecificationDetails;
    if (this.params.orderEquipmentRequirementSpecificationAssociations[0].orderEquipmentRequirementSpecificationDetails.length === 0) {
      this.params.orderEquipmentRequirementSpecificationAssociations[0].orderEquipmentRequirementSpecificationDetails.push(obj);
      this.params.orderEquipmentRequirementSpecificationAssociations[0].orderEquipmentRequirementSpecificationDetails
      = this.jbhGlobals.utils.uniqWith(specDetails, this.jbhGlobals.utils.isEqual);

      this.jbhGlobals.apiService.addData(this.jbhGlobals.endpoints.order.savetemperaturezone, this.params).subscribe(data => {
        this.equipmentRequirementID = data['orderEquipmentRequirementID'];
        this.specificationID
         = data['orderEquipmentRequirementSpecificationAssociations'][0]['orderEquipmentRequirementSpecificationDetails'][0]
         ['orderEquipmentRequirementSpecificationDetailID'];
        this.specificationAssociationID
         = data['orderEquipmentRequirementSpecificationAssociations'][0]['orderEquipmentRequirementSpecificationAssociationID'];
        this.params['orderEquipmentRequirementSpecificationAssociations'][0]['orderEquipmentRequirementSpecificationDetails'][0]
        ['orderEquipmentRequirementSpecificationDetailID'] = this.specificationID;
      }, (err: Error) => {
        this.jbhGlobals.logger.info(err);
      });
    } else {
      this.params.orderEquipmentRequirementSpecificationAssociations[0].orderEquipmentRequirementSpecificationDetails.push(obj);
      this.params.orderEquipmentRequirementSpecificationAssociations[0].orderEquipmentRequirementSpecificationDetails
       = this.jbhGlobals.utils.uniqWith(specDetails, this.jbhGlobals.utils.isEqual);
      const url = this.jbhGlobals.endpoints.order.savetemperaturezone + '/' + this.equipmentRequirementID;
      this.jbhGlobals.apiService.updateData(url, this.params).subscribe(data => {
        this.equipmentRequirementID = data['orderEquipmentRequirementID'];
        if (data['orderEquipmentRequirementSpecificationAssociations'][0]['orderEquipmentRequirementSpecificationDetails'][0]) {
          this.specificationID = data['orderEquipmentRequirementSpecificationAssociations'][0]
          ['orderEquipmentRequirementSpecificationDetails'][0]['orderEquipmentRequirementSpecificationDetailID'];
        }
        this.specificationAssociationID
         = data['orderEquipmentRequirementSpecificationAssociations'][0]['orderEquipmentRequirementSpecificationAssociationID'];
      }, (err: Error) => {
        this.jbhGlobals.logger.info(err);
      });
    }
  }
  public onRemoveSaveTempZone(flag, min, max): void {
    const a = this.params.orderEquipmentRequirementSpecificationAssociations[0].orderEquipmentRequirementSpecificationDetails;
    let delflag = false;
    let index: number = null;
    if (flag) {
      for (let i = 0; i < a.length; i++) {
        if ((a[i].temperatureLowRange === min.toString()) && (a[i].temperatureHighRange === max.toString())) {
          delflag = true;
          index = i;
        }
      }
    } else {
      for (let i = 0; i < a.length; i++) {
        if ((a[i].frontZoneprecoolTemperature === min.toString()) && (a[i].temperatureHighRange === max.toString())) {
          delflag = true;
          index = i;
        }
      }
    }
    if (delflag) {
      this.params.orderEquipmentRequirementSpecificationAssociations[0].orderEquipmentRequirementSpecificationDetails.splice(index, 1);
      const url = this.jbhGlobals.endpoints.order.savetemperaturezone + '/' + this.equipmentRequirementID;
      this.jbhGlobals.apiService.updateData(url, this.params).subscribe(data => {
        this.equipmentRequirementID = data['orderEquipmentRequirementID'];
        this.specificationID = data['orderEquipmentRequirementSpecificationAssociations'][0]
        ['orderEquipmentRequirementSpecificationDetails'][0]['orderEquipmentRequirementSpecificationDetailID'];
        this.specificationAssociationID = data['orderEquipmentRequirementSpecificationAssociations'][0]
        ['orderEquipmentRequirementSpecificationAssociationID'];
      }, (err: Error) => {
        this.jbhGlobals.logger.info(err);
      });
    }
  }
  public onAddAdditionalCustomBroker(): void {
    if (this.customsBrokerDetails.length < 3) {
      this.addcustombrokerflag = true;
    }
  }
  public onCustomBrokerSelect(e, customsbroker, clearingscustoms): void {
    this.customsbrokerId = e.item.id;
    this.shipmentInformation.controls['customsbrokercarrier'].setValue((e.item.name ? e.item.name : '')
     + '-' + (e.item.addressDTO.addressLine1 ? e.item.addressDTO.addressLine1 : '') + ' '
     + (e.item.addressDTO.addressLine2 ? e.item.addressDTO.addressLine2 : '') + ','
     + (e.item.addressDTO.city ? e.item.addressDTO.city : '') + ' '
     + (e.item.addressDTO.country ? e.item.addressDTO.country : '') + ' '
     + (e.item.addressDTO.state ? e.item.addressDTO.state : '') + ' '
     + (e.item.addressDTO.zipCode ? e.item.addressDTO.zipCode : '') + ' '
     + (e.item.code ? e.item.code : ''));
    this.loadClearingCustoms();
    this.onChangeClearingCustoms(customsbroker, clearingscustoms);
  }
  public onRemoveCustomBroker(recordIndex): void {
    this.customsBrokerDetails.splice(recordIndex, 1);
    const url = this.jbhGlobals.endpoints.order.savecustomsbroker;
    this.jbhGlobals.apiService.removeData(url + '/' + this.ordercrossborderdetailid).subscribe(data => {
      this.jbhGlobals.logger.info(data);
    }, (err: Error) => {
      this.jbhGlobals.logger.info(err);
    });
    if (this.customsBrokerDetails.length === 0) {
      this.customsbrokersdisplayflag = false;
      this.shipmentInformation.controls['clearingCountryCode'].setValidators([Validators.required]);
      this.shipmentInformation.controls['customsbrokercarrier'].setValidators([Validators.required]);
      this.shipmentInformation.get('clearingCountryCode').updateValueAndValidity();
      this.shipmentInformation.get('customsbrokercarrier').updateValueAndValidity();
    }
  }
  public onChangeClearingCustoms(customsbroker, clearingscustoms): void {
    if (this.shipmentInformation.controls['customsbrokercarrier'].value && clearingscustoms.value) {
      const customsBrokerObj = { custombroker: null, clearingcustoms: null };
      customsBrokerObj.custombroker = this.shipmentInformation.controls['customsbrokercarrier'].value;
      customsBrokerObj.clearingcustoms = clearingscustoms.value.toUpperCase();
      this.customsBrokerDetails.push(customsBrokerObj);
      this.customsBrokerDetails = this.jbhGlobals.utils.uniqWith(this.customsBrokerDetails, this.jbhGlobals.utils.isEqual);
      this.clearingcountrycode = clearingscustoms.value;
      this.saveCustomsBroker();
      this.shipmentInformation.controls['customsbrokercarrier'].setValue('');
      this.shipmentInformation.controls['clearingCountryCode'].setValue('');
      this.shipmentInformation.get('clearingCountryCode').setValidators([]);
      this.shipmentInformation.get('customsbrokercarrier').setValidators([]);
      this.shipmentInformation.get('clearingCountryCode').updateValueAndValidity();
      this.shipmentInformation.get('customsbrokercarrier').updateValueAndValidity();
      this.addcustombrokerflag = false;
      this.customsbrokersdisplayflag = true;
    }
  }
  public saveCustomsBroker(): void {
    switch (this.clearingcountrycode) {
      case 'mx':
        this.clearingcountrycode = 'MEX';
        break;
      case 'cn':
        this.clearingcountrycode = 'CND';
        break;
      case 'usa':
        this.clearingcountrycode = 'USA';
        break;
      default:
        break;
    }
    const params = {
      'orderCrossBorderDetailID': '',
      'customsBrokerID': this.customsbrokerId.toString(),
      'clearanceCountryCode': this.clearingcountrycode,
      'order': '/' + this.orderData.orderID
    };
    this.jbhGlobals.apiService.addData(this.jbhGlobals.endpoints.order.savecustomsbroker, params).subscribe(data => {
      this.ordercrossborderdetailid = data['orderCrossBorderDetailID'];
    }, (err: Error) => {
      this.jbhGlobals.logger.info(err);
    });
  }
  public saveRmaNumber(selectedrmanumber): void {
    const params = {
      'order': '/' + this.orderData.orderID,
      'referenceNumberID': '',
      'referenceNumberTypeCode': 'ReturnNbr',
      'referenceNumberLevelTypeCode': 'ORDER',
      'referenceNumberValue': selectedrmanumber,
      'stopId': ''
    };
    this.jbhGlobals.apiService.addData(this.jbhGlobals.endpoints.order.postReferencesType, params).subscribe(data => {
      this.jbhGlobals.logger.info(data);
    }, (err: Error) => {
      this.jbhGlobals.logger.info(err);
    });
  }
  public onChangePortOfEntry(selectedentryport): void {
    if (this.orderData.internationalOrderElement.length === 0) {
      this.createInternationalOrderElement();
    }
    this.orderData.internationalOrderElement[0].portOfEntry = selectedentryport;
    this.viewOrderService.saveData(this.orderData);
  }
  public onChangePortOfExit(selectedexitport): void {
    if (this.orderData.internationalOrderElement.length === 0) {
      this.createInternationalOrderElement();
    }
    this.orderData.internationalOrderElement[0].portOfExit = selectedexitport;
    this.viewOrderService.saveData(this.orderData);
    this.loadPortOfEntryByExit(selectedexitport);
    this.shipmentInformation.controls['portOfEntry'].setValue('');
  }

  public populateData(): void {
    this.populateFlag = false;
    if (this.orderData.orderTypeCode) {
      this.loadSecondaryOrderType();
    }
    for (let i = 0; i < this.array.length; i++) {
      if (this.orderData[this.array[i]]) {
        this.shipmentInformation['controls'][this.array[i]]['patchValue'](this.orderData[this.array[i]]);
      }
    }
    // this.shipmentInformation.controls['rmaNumber'].setValue(this.orderData.orderSubTypeCode);
    if (this.orderData.orderHighValueIndicator === true) {
      if (this.addTag({ id: 'High Value', text: 'High Value' })) {
        this.orderValueSetValidation(true);
      }
    }
    if (this.orderData.orderRefrigeratedIndicator === 'Y') {
      if (this.addTag({ id: 'Refrigerated', text: 'Refrigerated' })) {
        this.refrigerated = true;
      }
    }
    if ((!this.jbhGlobals.utils.isEmpty(this.orderData.internationalService)) &&
      (!this.jbhGlobals.utils.isEmpty(this.orderData.internationalOrderElement))) {
      if ((this.orderData.internationalService !== null) || (this.orderData.internationalOrderElement.length > 0)) {
        if (this.addTag({ id: 'International Shipment', text: 'International Shipment' })) {
          this.intship = true;
          this.loadInternationalServices();
        }
      }
    }
    if (!this.jbhGlobals.utils.isEmpty(this.orderData.orderFoodSafetyDetails)) {
      if (this.orderData.orderFoodSafetyDetails.length > 0) {
        if (this.addTag({ id: 'Food Safety', text: 'Food Safety' })) {
          this.foodsafety = true;
        }
      }
    }
    if (!this.jbhGlobals.utils.isEmpty(this.orderData.orderCarrierDetails)) {
      for (let i = 0; i < this.orderData.orderCarrierDetails.length; i++) {
        if (this.orderData.orderCarrierDetails[i].orderVolumeTradeShowTypeCode === 'TrdShip') {
          if (this.addTag({ id: 'Trade Show', text: 'Trade Show' })) {
            this.tradeshow = true;
          }
          for (let j = 0; j < this.tradeshowarray.length; j++) {
            this.shipmentInformation['controls'][this.tradeshowarray[j]]
            ['setValue'](this.orderData.orderCarrierDetails[i][this.tradeshowarray[j]]);
          }
        } else if (this.orderData.orderCarrierDetails[i].orderVolumeTradeShowTypeCode === 'VolShip') {
          if (this.addTag({ id: 'Volume Shipment', text: 'Volume Shipment' })) {
            this.volship = true;
          }
          for (let k = 0; k < this.volshiparray.length; k++) {
            this.shipmentInformation['controls'][this.volshiparray[k]]
            ['setValue'](this.orderData.orderCarrierDetails[i][this.tradeshowarray[k]]);
          }
        }
      }
    }
    if (!this.jbhGlobals.utils.isEmpty(this.orderData.internationalService)) {
      this.shipmentInformation['controls']['serviceType']['patchValue'](this.orderData.internationalService[0].serviceType);
    }
    if (!this.jbhGlobals.utils.isEmpty(this.orderData.internationalOrderElement)) {
      this.inbondfreight(true);
      this.loadBondHolderParty();
      this.checkTransitMode();
      this.shipmentInformation['controls']['inbondFreight']['patchValue'](true);
      for (let i = 0; i < this.internationalshipmentarray.length; i++) {
        if (this.orderData['internationalOrderElement'].length > 0) {
          this.shipmentInformation['controls'][this.internationalshipmentarray[i]]
          ['patchValue'](this.orderData['internationalOrderElement'][0]
            [this.internationalshipmentarray[i]]);
        }
      }
    }
    if (!this.jbhGlobals.utils.isEmpty(this.orderData.orderBillingDetailDTOs)) {
      if (this.orderData.orderBillingDetailDTOs.length > 0) {
        if (this.orderData.orderBillingDetailDTOs[0].autorateIndicator === 'Y') {
          this.shipmentInformation.controls['autorateIndicator'].setValue(true);
        } else {
          this.shipmentInformation.controls['autorateIndicator'].setValue(false);
        }
      }
    }
    if (!this.jbhGlobals.utils.isEmpty(this.orderData.orderOperationalElements)) {
      this.loadFleetCode();
      this.shipmentInformation['controls']['fleetCode']['patchValue'](this.orderData.orderOperationalElements[0].fleetCode);
    }
  }

  public populateTemplateData(): void {
    this.populateFlag = false;
    if (this.orderData.tempData.orderTypeCode) {
      this.loadSecondaryOrderType();
    }
    for (let i = 0; i < this.array.length; i++) {
      if (this.orderData.tempData[this.array[i]]) {
        this.shipmentInformation['controls'][this.array[i]]['patchValue'](this.orderData.tempData[this.array[i]]);
      }
    }
    if (this.orderData.tempData.orderHighValueIndicator === true) {
      if (this.addTag({ id: 'High Value', text: 'High Value' })) {
        this.orderValueSetValidation(true);
      }
    }
    if (this.orderData.tempData.orderRefrigeratedIndicator === 'Y') {
      if (this.addTag({ id: 'Refrigerated', text: 'Refrigerated' })) {
        this.refrigerated = true;
      }
    }
    if ((this.orderData.tempData.internationalService !== null) || (this.orderData.tempData.internationalOrderElement.length > 0)) {
      if (this.addTag({ id: 'International Shipment', text: 'International Shipment' })) {
        this.intship = true;
        this.loadInternationalServices();
      }
    }
    if (!this.jbhGlobals.utils.isEmpty(this.orderData.tempData.orderFoodSafetyDetails)) {
      if (this.orderData.tempData.orderFoodSafetyDetails.length > 0) {
        if (this.addTag({ id: 'Food Safety', text: 'Food Safety' })) {
          this.foodsafety = true;
        }
      }
    }
    if (!this.jbhGlobals.utils.isEmpty(this.orderData.tempData.orderCarrierDetails)) {
      for (let i = 0; i < this.orderData.tempData.orderCarrierDetails.length; i++) {
        if (this.orderData.tempData.orderCarrierDetails[i].orderVolumeTradeShowTypeCode === 'TrdShip') {
          if (this.addTag({ id: 'Trade Show', text: 'Trade Show' })) {
            this.tradeshow = true;
          }
          for (let j = 0; j < this.tradeshowarray.length; j++) {
            this.shipmentInformation['controls'][this.tradeshowarray[j]]
            ['setValue'](this.orderData.tempData.orderCarrierDetails[i][this.tradeshowarray[j]]);
          }
        } else if (this.orderData.tempData.orderCarrierDetails[i].orderVolumeTradeShowTypeCode === 'VolShip') {
          if (this.addTag({ id: 'Volume Shipment', text: 'Volume Shipment' })) {
            this.volship = true;
          }
          for (let k = 0; k < this.volshiparray.length; k++) {
            this.shipmentInformation['controls'][this.volshiparray[k]]
            ['setValue'](this.orderData.tempData.orderCarrierDetails[i][this.tradeshowarray[k]]);
          }
        }
      }
    }
    if (!this.jbhGlobals.utils.isEmpty(this.orderData.tempData.internationalService)) {
      this.shipmentInformation['controls']['serviceType']['patchValue'](this.orderData.tempData.internationalService[0].serviceType);
    }
    if (!this.jbhGlobals.utils.isEmpty(this.orderData.tempData.internationalOrderElement)) {
      this.inbondfreight(true);
      this.loadBondHolderParty();
      this.checkTransitMode();
      this.shipmentInformation['controls']['inbondFreight']['patchValue'](true);
      for (let i = 0; i < this.internationalshipmentarray.length; i++) {
        if (this.orderData.tempData['internationalOrderElement'].length > 0) {
          this.shipmentInformation['controls'][this.internationalshipmentarray[i]]
          ['patchValue'](this.orderData.tempData['internationalOrderElement'][0]
            [this.internationalshipmentarray[i]]);
        }
      }
    }
    if (!this.jbhGlobals.utils.isEmpty(this.orderData.tempData.orderBillingDetailDTOs)) {
      if (this.orderData.tempData.orderBillingDetailDTOs.length > 0) {
        if (this.orderData.tempData.orderBillingDetailDTOs[0].autorateIndicator === 'Y') {
          this.shipmentInformation.controls['autorateIndicator'].setValue(true);
        } else {
          this.shipmentInformation.controls['autorateIndicator'].setValue(false);
        }
      }
    }
    if (!this.jbhGlobals.utils.isEmpty(this.orderData.tempData.orderOperationalElements)) {
      this.loadFleetCode();
      this.shipmentInformation['controls']['fleetCode']['patchValue'](this.orderData.tempData.orderOperationalElements[0].fleetCode);
    }
  }
  public addTag(obj): boolean {
    if (this.jbhGlobals.utils.findIndex(this.shipmentRequirementsTagsKey.active, obj) === -1) {
      this.shipmentRequirementsTagsKey.active.push(obj);
      return true;
    } else {
      return false;
    }
  }

  public editFunction() {
    this.viewSection = false;
    this.editSection = true;
    this.onShipmentRequirementLoadData();
  }
  public closeFunction() {
    this.viewSection = true;
    this.editSection = false;
  }
}
