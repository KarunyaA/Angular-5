import { Injectable } from '@angular/core';

import { JBHGlobals } from 'app/app.service';


@Injectable()
export class StopInformationService {

  constructor(public jbhGlobals: JBHGlobals) { }

  loadServices(url) {
    return this.jbhGlobals.apiService.getData(url);
  }

  loadServiceWithParams(url, params) {
    return this.jbhGlobals.apiService.getData(url, params);
  }
}
