import { TestBed, inject } from '@angular/core/testing';

import { StopDetailsService } from './stop-details.service';

describe('StopDetailsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [StopDetailsService]
    });
  });

  it('should be created', inject([StopDetailsService], (service: StopDetailsService) => {
    expect(service).toBeTruthy();
  }));
});
