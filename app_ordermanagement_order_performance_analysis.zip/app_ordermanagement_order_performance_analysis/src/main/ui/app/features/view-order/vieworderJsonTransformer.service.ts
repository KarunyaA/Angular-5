import { Injectable } from '@angular/core';

@Injectable()
export class VieworderjsontransformerService {

    public stopEntity;
  constructor() { }

  stopDTOsToEntity(data) {
    if (data) {
        this.stopEntity = {
            'locationID': data['locationID'],
            'locationContactID': data['locationContactID'],
            'stopReason': data['stopReason'],
            'totalStopWeight': data['totalStopWeight'],
            'unitOfWeightMeasurementCode': data['unitOfWeightMeasurementCode'],
            'highCostDeliveryIndicator': data['highCostDeliveryIndicator'],
            'initialOfferedDate': data['initialOfferedDate'],
            'locationContactType': data['locationContactType'],
            'stopID': data['stopID'],
            'stopSequenceNumber': data['stopSequenceNumber'],
            'stopServices': data['stopServices'],
            'appointment': data['appointment'],
            'orderTransactionalContact': null,
            'stopCharges': null,
            'stopComments': null,
            'stopReferenceNumbers': null,
            'stopItemHandlingDetailAssociation': null,
            'stopAdditionalInstructions': null,
            'lastUpdateTimestampString': null
         };
     return this.stopEntity;

    }

  }
}

