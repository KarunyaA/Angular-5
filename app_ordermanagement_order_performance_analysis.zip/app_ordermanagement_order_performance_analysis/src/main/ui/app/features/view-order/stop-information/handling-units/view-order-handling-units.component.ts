import { Component, OnInit, Input, EventEmitter, Output, ChangeDetectorRef } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { JBHGlobals } from 'app/app.service';
import { OrderService } from 'app/features/create-orders/orders/order.service';
import { OrderFormBuilder } from 'app/features/create-orders/orders/order-form-builder.service';
// import {
//     ItemDetailsComponent
// } from '../item-details/view-order-item-details.component';
import { ViewOrderHandlingModel } from '../models/view-order-handling-model';
import { ViewOrderHandlingtypeService } from '../services/view-order-handlingtype.service';
import { ViewOrderUnitOfLengthService } from '../services/view-order-unit-of-length.service';
import { ViewOrderUnitOfWeightService } from '../services/view-order-unit-of-weight.service';
import { ViewOrderHandlingUnitService } from '../services/view-order-handling-unit.service';


@Component({
    selector: 'app-handling-units',
    templateUrl: './view-order-handling-units.component.html',
    styleUrls: ['./view-order-handling-units.component.scss'],
    providers: [ViewOrderHandlingtypeService, ViewOrderUnitOfLengthService,
        ViewOrderUnitOfWeightService, ViewOrderHandlingUnitService]
})
export class HandlingUnitsComponent implements OnInit {
    @Input() handlingUnitIndex: number;
    @Input() stopInfoJson: any;
    // @ViewChild('handlingVolumeId') handlingVolumeId: ElementRef;
    @Output() addAnotherHandling = new EventEmitter();
    handlingUnitForm: any;
    // public rows: any = [];
    // public selected: any = [];
    // public dimensionsSelect = true;
    // public itemhandlingList: any = [];
    // public debounceValue: any;
    // public itemHandlingUnitList: any[] = [];
    // public itemWeightList: any[] = [];
    // public itemLengthList: any[] = [];
    // public handlingReferenceList: any[] = [];
    // public stopId: any;
    // orderData: any;
    // public handlingDetails: any;
    // public handlingItemDetailsDto: any;
    // public handlingUnitVolume: any;
    // public handlingDimensionFlag = true;
    // public handlingUnitDensity: any;
    // public handlingVolumeVal: any;
    // public handlingDensityVal: any;
    // public handlingVolume: any;
    // public handlingformCount: number = 0;
    // public addHandlingUnitFormFlag: boolean;
    // private isDataLoaded = false;
    // public handlingUnitId: any;
    // public flatbedFlag = false;
    // denMeasureFlag = false;
    // volMeasureFlag = false;
    handlingModel: ViewOrderHandlingModel;
    constructor(public formBuilder: FormBuilder, public jbhGlobals: JBHGlobals,
        public orderFormBuilder: OrderFormBuilder, public changeDetector: ChangeDetectorRef,
        public orderService: OrderService, public handlingTypeService: ViewOrderHandlingtypeService,
        public lengthService: ViewOrderUnitOfLengthService,
        public weightService: ViewOrderUnitOfWeightService, public handlingService: ViewOrderHandlingUnitService) {
        this.handlingModel = new ViewOrderHandlingModel();
    }


    ngOnInit() {
        this.handlingUnitForm = this.orderFormBuilder.addHandlingUnit();
        this.loadHandlingData();
        this.loadHandlingUnit();
        this.loadHandlingWeight();
        this.loadUnitofLength();
        this.handlingModel.handlingUnitVolume = '';
        this.handlingModel.handlingUnitDensity = '';
        // this.loadHandlingReference(this.stopId);


        this.handlingModel.debounceValue = this.jbhGlobals.settings.debounce;
        this.handlingUnitForm['controls']['itemHandlingUnitLength'].valueChanges
            .debounceTime(this.handlingModel.debounceValue)
            .distinctUntilChanged()
            .subscribe((data) => {
                if (data) {
                    this.handlingUnitForm['controls']['itemHandlingUnitLength'].setValue(data);
                    this.calculateVolume();
                    this.calculateDensity();
                    this.handlingModel.handlingItemDetailsDto.itemHandlingUnitLength = data;
                } else {
                    this.handlingModel.handlingItemDetailsDto.itemHandlingUnitLength = '';
                    this.setMeasurementEmpty();
                }
            }, (err: Error) => {
                console.log(err);
            });

        this.handlingUnitForm['controls']['itemHandlingUnitWidth'].valueChanges
            .debounceTime(this.handlingModel.debounceValue)
            .distinctUntilChanged()
            .subscribe((data) => {
                if (data) {
                    this.handlingUnitForm['controls']['itemHandlingUnitWidth'].setValue(data);
                    this.handlingModel.handlingItemDetailsDto.itemHandlingUnitWidth = data;
                    this.calculateVolume();
                    this.calculateDensity();
                } else {
                    this.handlingModel.handlingItemDetailsDto.itemHandlingUnitWidth = '';
                    this.setMeasurementEmpty();
                }
            }, (err: Error) => {
                console.log(err);
            });

        this.handlingUnitForm['controls']['itemHandlingUnitHeight'].valueChanges
            .debounceTime(this.handlingModel.debounceValue)
            .distinctUntilChanged()
            .subscribe((data) => {
                if (data) {
                    this.handlingUnitForm['controls']['itemHandlingUnitHeight'].setValue(data);
                    this.handlingModel.handlingItemDetailsDto.itemHandlingUnitHeight = data;
                    this.calculateVolume();
                    this.calculateDensity();
                } else {
                    this.handlingModel.handlingItemDetailsDto.itemHandlingUnitHeight = '';
                    this.setMeasurementEmpty();
                }
            }, (err: Error) => {
                console.log(err);
            });


        this.handlingUnitForm['controls']['unitOfLengthMeasurementCode'].valueChanges
            .debounceTime(this.handlingModel.debounceValue)
            .distinctUntilChanged()
            .subscribe((data) => {
                if (data.length > 0) {
                    this.handlingModel.handlingItemDetailsDto.unitOfLengthMeasurementCode = data;
                    this.calculateVolume();
                    this.calculateDensity();
                } else {
                    this.handlingModel.handlingItemDetailsDto.unitOfLengthMeasurementCode = '';
                    this.setMeasurementEmpty();
                }
            }, (err: Error) => {
                console.log(err);
            });

        this.handlingUnitForm['controls']['itemHandlingUnitWeight'].valueChanges
            .debounceTime(this.handlingModel.debounceValue)
            .distinctUntilChanged()
            .subscribe((data) => {
                if (data) {
                    this.handlingUnitForm['controls']['itemHandlingUnitWeight'].setValue(parseFloat(data));
                    this.handlingModel.handlingItemDetailsDto.itemHandlingUnitWeight = data;
                    if (this.handlingModel.handlingDimensionFlag) {
                        this.calculateVolume();
                        this.calculateDensity();
                    }
                    this.calculateVolumeConversion();
                } else {
                    this.handlingModel.handlingItemDetailsDto.itemHandlingUnitWeight = '';
                    this.handlingModel.handlingUnitDensity = '';
                }
            }, (err: Error) => {
                console.log(err);
            });

        this.handlingUnitForm['controls']['unitOfWeightMeasurementCode'].valueChanges
            .debounceTime(this.handlingModel.debounceValue)
            .distinctUntilChanged()
            .subscribe((data) => {
                if (data.length > 0) {
                    this.handlingModel.handlingItemDetailsDto.unitOfWeightMeasurementCode = data;
                    if (this.handlingModel.handlingDimensionFlag) {
                        this.calculateVolume();
                        this.calculateDensity();
                    }
                    this.calculateVolumeConversion();
                } else {
                    this.handlingModel.handlingItemDetailsDto.unitOfWeightMeasurementCode = '';
                    this.handlingModel.handlingUnitDensity = '';
                }
            }, (err: Error) => {
                console.log(err);
            });

        this.handlingUnitForm['controls']['itemHandlingUnitVolume'].valueChanges
            .debounceTime(this.handlingModel.debounceValue)
            .distinctUntilChanged()
            .subscribe((data) => {
                if (data) {
                    this.handlingModel.handlingVolumeVal = data;
                    this.handlingModel.volMeasureFlag = true;
                    this.handlingUnitForm['controls']['unitOfVolumeMeasurementCode'].setValue('Cubic CM');
                    this.handlingModel.handlingItemDetailsDto.itemHandlingUnitVolume = data;
                    this.calculateVolumeConversion();
                } else {
                    this.handlingModel.handlingVolumeVal = '';
                    this.handlingModel.handlingDensityVal = '';
                    this.handlingModel.handlingVolume = '';
                    this.handlingModel.volMeasureFlag = false;
                    this.handlingModel.handlingItemDetailsDto.itemHandlingUnitVolume = '';
                }
            }, (err: Error) => {
                console.log(err);
            });

        this.handlingUnitForm['controls']['itemHandlingTypeCode'].valueChanges
            .debounceTime(this.handlingModel.debounceValue)
            .distinctUntilChanged()
            .subscribe((data) => {
                if (data.length > 0) {
                    this.handlingModel.handlingItemDetailsDto.itemHandlingTypeCode = data;
                } else {
                    this.handlingModel.handlingItemDetailsDto.itemHandlingTypeCode = '';
                }
            }, (err: Error) => {
                console.log(err);
            });


        this.handlingUnitForm['controls']['itemHandlingTypeQuantity'].valueChanges
            .debounceTime(this.handlingModel.debounceValue)
            .distinctUntilChanged()
            .subscribe((data) => {
                if (data) {
                    this.handlingModel.handlingItemDetailsDto.itemHandlingTypeQuantity = data;
                } else {
                    this.handlingModel.handlingItemDetailsDto.itemHandlingTypeQuantity = '';
                }
            }, (err: Error) => {
                console.log(err);
            });

    }

    public loadHandlingData() {
        this.orderService.getData().subscribe(sharedOrderData => {
            this.handlingModel.orderData = sharedOrderData;
        });
        this.handlingModel.selected = this.stopInfoJson;
        this.handlingModel.stopId = this.stopInfoJson.stop.stopID;
        this.handlingModel.handlingItemDetailsDto = this.handlingModel.selected['itemHandlingDetailDTOs'][this.handlingUnitIndex];
        this.handlingModel.handlingUnitId = this.handlingModel.handlingItemDetailsDto.itemHandlingDetail.itemHandlingDetailID;
        if (this.handlingModel.stopId) {
            this.loadHandlingReference(this.handlingModel.stopId);
        }
        if (!this.handlingModel.isDataLoaded) {
            this.onBusinessUnitBased();
            if (this.handlingModel.stopId && this.handlingModel.handlingUnitId) {
                this.populateData(this.handlingModel.handlingItemDetailsDto);
            }
        }
        this.handlingModel.isDataLoaded = true;
        // this.populateData(this.handlingModel.handlingItemDetailsDto);
    }

    public onSelectPrefix(event: any): void {
    }

    public loadHandlingUnit() {
        // const url = this.jbhGlobals.endpoints.order.getHandlingUnit;
        // // const params = {
        // //     'page': 0,
        // //     'size': 200
        // // };
        // this.jbhGlobals.apiService.getData(url, false).subscribe(data => {
        //     this.handlingModel.itemHandlingUnitList = data['_embedded']['itemHandlingTypes'];
        // });


        this.handlingTypeService.getData().subscribe(data => {
            this.handlingModel.itemHandlingUnitList = data;
        });

    }
    public loadHandlingWeight() {
        // // this.itemWeightList = ['Pounds','Grams','Tons'];
        // this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getUnitOfWeight).subscribe(data => {
        //     this.handlingModel.itemWeightList = data['_embedded']['unitOfWeightMeasurements'];
        // });
        this.weightService.getData().subscribe(data => {
            this.handlingModel.itemWeightList = data;
        });
    }
    public loadUnitofLength() {
        // // this.itemLengthList = ['Inches','Feet'];
        // this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getUnitofLength).subscribe(data => {
        //     this.handlingModel.itemLengthList = data['_embedded']['unitOfLengthMeasurements'];
        // });
        this.lengthService.getData().subscribe(data => {
            this.handlingModel.itemLengthList = data;
        });
    }

    public loadHandlingReference(stopId) {
        if (stopId) {
            const params = stopId + '/' + 'referencenumbertypes';
            // this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getHandlingReference + params).subscribe(data => {
            //     this.handlingModel.handlingReferenceList = data;
            // });
            this.handlingService.getHandlingReference(this.jbhGlobals.endpoints.order.getHandlingReference + params).subscribe(data => {
                this.handlingModel.handlingReferenceList = data;
            });
        }
    }

    public measurementSelect(measurement) {
        if (measurement === true) {
            this.handlingModel.dimensionsSelect = true;
        } else {
            this.handlingModel.dimensionsSelect = false;
        }
    }

    public populateData(data: any) {
        if (data.itemHandlingDetail) {
            // this.handlingUnitForm.patchValue(data.itemHandlingDetail);
            this.handlingUnitForm['controls']['itemHandlingTypeCode'].setValue([data.itemHandlingDetail.itemHandlingTypeCode]);
            this.handlingUnitForm['controls']['itemHandlingTypeQuantity'].setValue(data.itemHandlingDetail.itemHandlingTypeQuantity);
            this.handlingUnitForm['controls']['itemHandlingUnitWeight'].setValue(data.itemHandlingDetail.itemHandlingUnitWeight);
            this.handlingUnitForm['controls']['unitOfWeightMeasurementCode']
                .setValue([data.itemHandlingDetail.unitOfWeightMeasurementCode]);
            this.handlingUnitForm['controls']['itemHandlingUnitLength'].setValue(data.itemHandlingDetail.itemHandlingUnitLength);
            this.handlingUnitForm['controls']['itemHandlingUnitWidth'].setValue(data.itemHandlingDetail.itemHandlingUnitWidth);
            this.handlingUnitForm['controls']['itemHandlingUnitHeight'].setValue(data.itemHandlingDetail.itemHandlingUnitHeight);
            this.handlingUnitForm['controls']['unitOfLengthMeasurementCode']
                .setValue([data.itemHandlingDetail.unitOfLengthMeasurementCode]);
            this.handlingUnitForm['controls']['itemHandlingUnitVolume'].setValue(data.itemHandlingDetail.itemHandlingUnitVolume);
            if (data.itemHandlingDetail.itemHandlingDetailReferenceNumberAssociations) {
                if (data.itemHandlingDetail.itemHandlingDetailReferenceNumberAssociations.length > 0) {
                    const referenceVal = data.itemHandlingDetail.itemHandlingDetailReferenceNumberAssociations[0];
                    this.handlingUnitForm['controls']['itemReference'].setValue([referenceVal]);
                }
            }
            if (data.itemHandlingDetail.itemHandlingUnitVolume &&
                !this.jbhGlobals.utils.isEmpty(data.itemHandlingDetail.unitOfVolumeMeasurementCode) &&
                !data.itemHandlingDetail.itemHandlingUnitLength &&
                !data.itemHandlingDetail.itemHandlingUnitWidth && !data.itemHandlingDetail.itemHandlingUnitHeight) {
                this.handlingModel.handlingDimensionFlag = false;
                this.handlingModel.handlingVolumeVal = this.handlingUnitForm.itemHandlingUnitVolume.value;
                this.handlingModel.volMeasureFlag = true;
                if (data.itemHandlingDetail.itemHandlingUnitWeight &&
                    !this.jbhGlobals.utils.isEmpty(data.itemHandlingDetail.unitOfWeightMeasurementCode)) {
                    this.handlingModel.handlingDensityVal = this.handlingUnitForm.itemHandlingUnitDensity.value;
                    this.handlingModel.denMeasureFlag = true;
                }
            } else {
                this.handlingModel.handlingDimensionFlag = true;
                this.handlingModel.handlingVolumeVal = '';
                this.handlingModel.handlingDensityVal = '';
                this.handlingModel.volMeasureFlag = false;
                this.handlingModel.denMeasureFlag = false;
            }
            if (data.itemHandlingDetail.itemHandlingUnitLength && data.itemHandlingDetail.itemHandlingUnitWidth &&
                data.itemHandlingDetail.itemHandlingUnitHeight &&
                !this.jbhGlobals.utils.isEmpty(data.itemHandlingDetail.unitOfLengthMeasurementCode) &&
                data.itemHandlingDetail.itemHandlingUnitVolume &&
                !this.jbhGlobals.utils.isEmpty(data.itemHandlingDetail.unitOfVolumeMeasurementCode)) {
                this.handlingModel.handlingUnitVolume = this.handlingUnitForm.controls.itemHandlingUnitVolume.value;
                this.handlingModel.volMeasureFlag = true;
                if (data.itemHandlingDetail.itemHandlingUnitWeight &&
                    !this.jbhGlobals.utils.isEmpty(data.itemHandlingDetail.unitOfWeightMeasurementCode)) {
                    this.handlingModel.handlingUnitDensity = this.handlingUnitForm.controls.itemHandlingUnitDensity.value;
                    this.handlingModel.denMeasureFlag = true;
                }
            } else {
                this.handlingModel.handlingUnitVolume = '';
                this.handlingModel.handlingUnitDensity = '';
                this.handlingModel.denMeasureFlag = false;
                this.handlingModel.volMeasureFlag = false;
            }
        }
    }

    public onDimensionClick(value) {
        if (value === 'handlingDimension') {
            this.handlingUnitForm['controls']['itemHandlingUnitVolume'].setValue('');
            this.handlingModel.handlingItemDetailsDto.itemHandlingDetail.itemHandlingUnitVolume = '';
            this.handlingModel.handlingDimensionFlag = true;
        } else {
            this.handlingUnitForm['controls']['itemHandlingUnitLength'].setValue('');
            this.handlingUnitForm['controls']['itemHandlingUnitWidth'].setValue('');
            this.handlingUnitForm['controls']['itemHandlingUnitHeight'].setValue('');
            this.handlingUnitForm['controls']['unitOfLengthMeasurementCode'].setValue('');
            this.handlingModel.handlingItemDetailsDto.itemHandlingDetail.itemHandlingUnitLength = '';
            this.handlingModel.handlingItemDetailsDto.itemHandlingDetail.itemHandlingUnitWidth = '';
            this.handlingModel.handlingItemDetailsDto.itemHandlingDetail.itemHandlingUnitHeight = '';
            this.handlingModel.handlingItemDetailsDto.itemHandlingDetail.unitOfLengthMeasurementCode = '';
            this.handlingModel.handlingDimensionFlag = false;
        }
    }
    public calculateVolume() {
        const handLength = parseFloat(this.handlingUnitForm.value.itemHandlingUnitLength);
        const handWidth = parseFloat(this.handlingUnitForm.value.itemHandlingUnitWidth);
        const handHeigth = parseFloat(this.handlingUnitForm.value.itemHandlingUnitHeight);
        const handUnit = this.handlingUnitForm.value.unitOfLengthMeasurementCode.toString();

        if (handLength && handWidth &&
            handHeigth && !this.jbhGlobals.utils.isEmpty(handUnit)) {
            const length = this.conversionToInches(handLength, handUnit);
            const width = this.conversionToInches(handWidth, handUnit);
            const height = this.conversionToInches(handHeigth, handUnit);
            const volume = (length * width * height) / (12 * 12 * 12);
            const volumeVal = this.validateDimensionAndVolume(volume);
            if (volumeVal) {
                this.handlingModel.handlingUnitVolume = volume.toFixed(4);
                this.handlingModel.volMeasureFlag = true;
                this.handlingUnitForm['controls']['itemHandlingUnitVolume'].setValue(parseFloat(volume.toFixed(4)));
                this.handlingUnitForm['controls']['unitOfVolumeMeasurementCode'].setValue('Cubic CM');
                this.handlingModel.handlingItemDetailsDto.itemHandlingDetail.itemHandlingUnitVolume = parseFloat(volume.toFixed(4));
                this.handlingModel.handlingItemDetailsDto.itemHandlingDetail.unitOfVolumeMeasurementCode = 'Cubic CM';
            }
        } else {
            this.handlingUnitForm['controls']['itemHandlingUnitVolume'].setValue('');
            this.handlingUnitForm['controls']['unitOfVolumeMeasurementCode'].setValue('');
            this.handlingModel.handlingItemDetailsDto.itemHandlingDetail.itemHandlingUnitVolume = '';
            this.handlingModel.handlingItemDetailsDto.itemHandlingDetail.unitOfVolumeMeasurementCode = '';
            this.handlingModel.handlingUnitVolume = '';
            this.handlingModel.volMeasureFlag = false;
        }

    }

    public conversionToInches(value, unit) {
        let measurement;
        switch (unit) {
            case 'Centimeter':
                measurement = parseFloat(value) / 2.54;
                break;
            case 'Feet':
                measurement = parseFloat(value) * 12;
                break;
            case 'Kilometers':
                measurement = parseFloat(value) * 39379.96;
                break;
            case 'Meter':
                measurement = parseFloat(value) / 0.0254;
                break;
            case 'Miles':
                measurement = parseFloat(value) * 63360;
                break;
            case 'Inches':
                measurement = parseFloat(value);
                break;
            default:
                break;
        }
        return measurement;
    }

    public validateDimensionAndVolume(value): any {
        const val = this.jbhGlobals.utils.floor(value);
        const valLength = val.toString().length;
        if (!isNaN(value) && valLength < 8) {
            return value;
        } else {
            this.setDimensionandVolumeEmpty();
            this.jbhGlobals.notifications.error('Error', 'Please enter proper value for Dimesion or Volume');
            return null;
        }
    }

    public setDimensionandVolumeEmpty() {
        if (this.handlingModel.handlingDimensionFlag) {
            this.handlingUnitForm['controls']['itemHandlingUnitLength'].setValue('');
            this.handlingUnitForm['controls']['itemHandlingUnitWidth'].setValue('');
            this.handlingUnitForm['controls']['itemHandlingUnitHeight'].setValue('');
            this.handlingUnitForm['controls']['itemHandlingUnitVolume'].setValue('');
            this.handlingUnitForm['controls']['unitOfVolumeMeasurementCode'].setValue('');
            this.handlingUnitForm['controls']['itemHandlingUnitWeight'].setValue('');
            this.setDensityEmpty();
        } else {
            this.handlingUnitForm['controls']['itemHandlingUnitWeight'].setValue('');
            this.handlingUnitForm['controls']['itemHandlingUnitVolume'].setValue('');
            this.handlingUnitForm['controls']['unitOfVolumeMeasurementCode'].setValue('');
            this.setDensityEmpty();
        }
    }

    public setDensityEmpty() {
        this.handlingModel.denMeasureFlag = false;
        this.handlingUnitForm['controls']['unitOfDensityMeasurementCode'].setValue('');
        this.handlingUnitForm['controls']['itemHandlingUnitDensity'].setValue('');
        this.handlingModel.handlingItemDetailsDto.itemHandlingDetail.itemHandlingUnitDensity = '';
        this.handlingModel.handlingItemDetailsDto.itemHandlingDetail.unitOfDensityMeasurementCode = '';
    }

    public calculateDensity() {
        const handLength = parseFloat(this.handlingUnitForm.value.itemHandlingUnitLength);
        const handWidth = parseFloat(this.handlingUnitForm.value.itemHandlingUnitWidth);
        const handHeigth = parseFloat(this.handlingUnitForm.value.itemHandlingUnitHeight);
        const handUnit = this.handlingUnitForm.value.unitOfLengthMeasurementCode.toString();
        const handWeight = parseFloat(this.handlingUnitForm.value.itemHandlingUnitWeight);
        const handWeightUnit = this.handlingUnitForm.value.unitOfWeightMeasurementCode.toString();

        if (handLength && handWidth && handHeigth && !this.jbhGlobals.utils.isEmpty(handUnit) &&
            handWeight && !this.jbhGlobals.utils.isEmpty(handWeightUnit)) {
            const length = this.conversionToFeet(handLength, handUnit);
            const width = this.conversionToFeet(handWidth, handUnit);
            const height = this.conversionToFeet(handHeigth, handUnit);
            const weight = this.weightConversion(handWeight, handWeightUnit);
            const density = weight / (length * width * height);
            const densityVal = this.validateDimensionAndVolume(density);
            if (densityVal) {
                this.handlingModel.handlingUnitDensity = density.toFixed(4);
                this.setDensityVal(density.toFixed(4));
            }
        } else {
            this.handlingModel.handlingUnitDensity = '';
            this.setDensityEmpty();
        }
    }

    public conversionToFeet(value, unit) {
        switch (unit) {
            case 'Centimeter':
                value = parseFloat(value) / 30.48;
                break;
            case 'Inches':
                value = parseFloat(value) / 12;
                break;
            case 'Kilometers':
                value = parseFloat(value) * 3280.8398950131;
                break;
            case 'Meter':
                value = parseFloat(value) / 0.3048;
                break;
            case 'Miles':
                value = parseFloat(value) * 5280;
                break;
            case 'Inches':
                value = parseFloat(value);
                break;
            default:
                break;
        }
        return value;
    }

    public weightConversion(value, unit) {
        let weight;
        switch (unit) {
            case 'Grams':
                weight = parseFloat(value) / 453.59237;
                break;
            case 'Kilogram':
                weight = parseFloat(value) / 0.45359237;
                break;
            case 'MetricTons':
                weight = parseFloat(value) / 0.00045359237;
                break;
            case 'Ounces':
                weight = parseFloat(value) / 16;
                break;
            case 'Tons':
                weight = parseFloat(value) / 0.00045359237;
                break;
            case 'Pounds':
                weight = parseFloat(value);
                break;
            default:
                break;
        }
        return weight;
    }

    public setDensityVal(value) {
        this.handlingModel.denMeasureFlag = true;
        this.handlingUnitForm['controls']['itemHandlingUnitDensity'].setValue(parseFloat(value));
        this.handlingUnitForm['controls']['unitOfDensityMeasurementCode'].setValue('GM/CC');
        this.handlingUnitForm.value.itemHandlingUnitDensity = parseFloat(value);
        this.handlingUnitForm.value.unitOfDensityMeasurementCode = 'GM/CC';
        this.handlingModel.handlingItemDetailsDto.itemHandlingDetail.itemHandlingUnitDensity = parseFloat(value);
        this.handlingModel.handlingItemDetailsDto.itemHandlingDetail.unitOfDensityMeasurementCode = 'GM/CC';
    }

    public setMeasurementEmpty() {
        this.handlingModel.denMeasureFlag = false;
        this.handlingModel.volMeasureFlag = false;
        this.handlingUnitForm['controls']['itemHandlingUnitVolume'].setValue('');
        this.handlingUnitForm['controls']['itemHandlingUnitDensity'].setValue('');
        this.handlingModel.handlingUnitDensity = '';
        this.handlingModel.handlingUnitVolume = '';
        this.handlingModel.handlingItemDetailsDto.itemHandlingDetail.itemHandlingUnitVolume = '';
        this.handlingModel.handlingItemDetailsDto.itemHandlingDetail.itemHandlingUnitDensity = '';
    }

    public calculateVolumeConversion() {
        const volume = this.handlingUnitForm.value.itemHandlingUnitVolume;
        const weight = this.handlingUnitForm.value.itemHandlingUnitWeight;
        const weightUnit = this.handlingUnitForm.value.unitOfWeightMeasurementCode.toString();
        if (volume && weight && !this.jbhGlobals.utils.isEmpty(weightUnit)) {
            const density = this.weightConversion(weight, weightUnit) / volume * (12 * 12 * 12);
            const densityVal = this.validateDimensionAndVolume(density);
            if (densityVal) {
                this.handlingModel.handlingDensityVal = parseFloat(density.toFixed(4));
                this.setDensityVal(density.toFixed(4));
            }
        } else {
            this.setDensityEmpty();
            this.handlingModel.handlingDensityVal = '';
        }
    }
    public addHandlingUnitForm() {
        this.handlingModel.addHandlingUnitFormFlag = false;
        let stopItemArray: any;
        const stopItemObj = {
            stopItem: this.orderFormBuilder.addItem()
        };
        stopItemArray = [];
        // tempHandUnit['controls']['itemHandlingUnitDensity'] = '';
        const tempHandUnit = this.orderFormBuilder.addHandlingUnit();
        stopItemArray.push(stopItemObj['stopItem']['controls']);
        const handlingUnitObject = {
            itemHandlingDetail: tempHandUnit['controls'],
            stopItemDTOs: stopItemArray
        };
        this.addAnotherHandling.emit(handlingUnitObject);
    }
    public addItemForm() {
        const stopObject = {
            stopItem: this.orderFormBuilder.addItem()
        };
        this.handlingModel.selected['itemHandlingDetailDTOs'][this.handlingUnitIndex]
        ['stopItemDTOs'].push(stopObject['stopItem']['controls']);
        // this.stopHandUnitJson['stopItemDTOs'].push(stopObject['stopItem']['controls']);
    }
    public onBusinessUnitBased() {
        switch (this.handlingModel.orderData.financeBusinessUnitCode) {
            case 'DCS':
                this.onServiceOfferingBased();
                break;
            case 'ICS':
                this.onServiceOfferingBased();
                break;
            case 'JBI':
                this.onServiceOfferingBased();
                break;
            case 'JBT':
                this.onServiceOfferingBased();
                break;
            default:
                break;
        }
    }
    public onServiceOfferingBased() {
        switch (this.handlingModel.orderData.serviceOfferingCode) {
            /*case "Final Mile":
                this.dcsFlag = true;
                break;
            case "LTL Dir":
                this.icsLTLFlag = true;
                break;
            case "LTL Cons":
                this.icsLTLFlag = true;
                break;*/
            case 'Flatbed':
                this.handlingModel.flatbedFlag = true;
                break;
            default:
                break;
        }
    }
}
