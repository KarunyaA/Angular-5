import { TestBed, inject } from '@angular/core/testing';

import { ShipmentInformationService } from './shipment-information.service';

describe('ShipmentInformationService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ShipmentInformationService]
    });
  });

  it('should be created', inject([ShipmentInformationService], (service: ShipmentInformationService) => {
    expect(service).toBeTruthy();
  }));
});
