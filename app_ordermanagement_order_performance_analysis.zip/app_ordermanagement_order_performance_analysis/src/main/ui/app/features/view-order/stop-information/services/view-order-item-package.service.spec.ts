import { TestBed, inject } from '@angular/core/testing';

import { ViewOrderItemPackageService } from './view-order-item-package.service';

describe('ViewOrderItemPackageService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ViewOrderItemPackageService]
    });
  });

  it('should be created', inject([ViewOrderItemPackageService], (service: ViewOrderItemPackageService) => {
    expect(service).toBeTruthy();
  }));
});
