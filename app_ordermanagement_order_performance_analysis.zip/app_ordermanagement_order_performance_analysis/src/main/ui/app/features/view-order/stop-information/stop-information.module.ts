/*import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HandlingUnitsComponent } from './handling-units/view-order-handling-units.component';
import { ItemDetailsComponent } from './item-details/view-order-item-details.component';
import { StopDetailsComponent } from './stop-details/view-order-stop-details.component';
import { AppointmentDetailsComponent } from './stop-details/view-order-appointment-details.component';
import { ItemHazmatComponent } from './item-details/view-order-item-hazmat.component';
import { StopHandlingComponent } from './handling-units/view-order-stop-handling.component';
import { DeliveryHandlingUnitsComponent } from './delivery-handling-units/view-order-delivery-handling-units.component';
import { SiteProfileComponent } from './stop-details/site-profile/view-order-site-profile.component';
import { StopResequenceComponent } from './stop-details/stop-resequence/view-order-stop-resequence.component';
import { AddcontactComponent } from './stop-details/addcontact/view-order-addcontact.component';
import { CreateLocationComponent } from './stop-details/create-location/view-order-create-location.component';
import { VieworderjsontransformerService } from 'app/features/view-order/vieworderJsonTransformer.service';
import { StopInformationComponent } from './stop-information.component';
import { JBHDataTableModule } from '../../../shared/jbh-data-table/jbh-data-table.module';
import { StopInformationRoutingModule } from './stop-information-routing.module'
import { AgmCoreModule } from 'angular2-google-maps/core';





import { SelectModule } from '../../../shared/select';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PopoverModule } from 'ngx-bootstrap/popover';
import { ModalModule } from 'ngx-bootstrap';
import { TypeaheadModule } from 'ngx-bootstrap/typeahead';
import { MyDatePickerModule } from 'mydatepicker';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { DragulaModule } from 'ng2-dragula';
import { TagInputModule } from 'ng2-tag-input';

import { OrderFormBuilder } from 'app/features/create-orders/orders/order-form-builder.service';
import { OrderService } from 'app/features/create-orders/orders/order.service';
import { JbhUtilsModule } from 'app/shared/jbh-utils/jbh-utils.module';

@NgModule({
  imports: [
    CommonModule,
    SelectModule,
    FormsModule,
    ReactiveFormsModule,
    PopoverModule.forRoot(),
    ModalModule.forRoot(),
    MyDatePickerModule,
    JbhUtilsModule,
    TypeaheadModule.forRoot(),
    //  DatepickerModule.forRoot(),
    BsDropdownModule.forRoot(),
    TagInputModule,
    DragulaModule,
    JBHDataTableModule,
    StopInformationRoutingModule,
     AgmCoreModule.forRoot({
      apiKey: 'AIzaSyCbS51Lks3sDEyIwTobAYajcVqEtsePDBM'
    }),

  ],

  declarations: [
    HandlingUnitsComponent,
    ItemDetailsComponent,
    StopDetailsComponent,
    AppointmentDetailsComponent,
    ItemHazmatComponent,
    StopHandlingComponent,
    DeliveryHandlingUnitsComponent,
    SiteProfileComponent,
    StopResequenceComponent,
    AddcontactComponent,
    CreateLocationComponent,
    StopInformationComponent
  ],

  providers: [OrderService, OrderFormBuilder, VieworderjsontransformerService]
})

export class StopInformationModule { }
*/

