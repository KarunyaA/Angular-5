import { Component, Input, OnInit, OnDestroy } from '@angular/core';
import { JBHGlobals } from 'app/app.service';
import { ViewOrderService } from 'app/features/view-order/view-order.service';
@Component({
  selector: 'app-stop-resequence',
  templateUrl: './view-order-stop-resequence.component.html',
  styleUrls: ['./view-order-stop-resequence.component.scss']
})
export class StopResequenceComponent implements OnInit, OnDestroy   {
  @Input() stopResequenceList: any;
  @Input() orderId;
  public source: any;
  public selectedStop: any;
  public selectedItem: any;
  public tempArray = [];
  public sortedArray = [];
  constructor(public jbhGlobals: JBHGlobals, public viewOrderService: ViewOrderService) { }
  ngOnInit() {
    this.stopResequenceList.forEach((item) => {
      this.tempArray.push(item);
    });
  }
  isbefore(a, b): boolean {
    if (a.parentNode === b.parentNode) {
      for (let cur = a; cur; cur = cur.previousSibling) {
        if (cur === b) {
          return true;
        }
      }
    }
    return false;
  }
  onDragEnter(e, item, index): void {
    e.target.style.border = '2px dashed #000';
    e.target.style.backgroundColor = '#eeeeee';
    const temp = e.target.querySelector('#cityName').innerHTML;
    e.target.querySelector('#cityName').innerHTML = this.source.querySelector('#cityName').innerHTML;
    this.source.querySelector('#cityName').innerHTML = temp;
    const sourceStop = this.source.querySelector('#stopName').innerHTML;
    const targetStop = e.target.querySelector('#stopName').innerHTML;
    for (let i = 0; i < this.tempArray.length; i++) {
      if (this.tempArray[i].stop.stopName === sourceStop) {
        this.tempArray[i].stop.stopFields.cityName = this.source.querySelector('#cityName').innerHTML;
      }
      if (this.tempArray[i].stop.stopName === targetStop) {
        this.tempArray[i].stop.stopFields.cityName = e.target.querySelector('#cityName').innerHTML;
      }
    }
  }
  public showStopResequence(event, stopResequenceModal) {
    event.stopPropagation();
    stopResequenceModal.show();
  }
  onDragLeave(e, item, index): void {
    this.source = e.target;
    e.dataTransfer.effectAllowed = 'all';
    e.target.style.border = '1px solid #000';
    e.target.style.backgroundColor = '#ffffff';
  }
  onDragStart(e, item, index): void {
    this.source = e.target;
    e.dataTransfer.effectAllowed = 'all';
  }
  public updateStopResequence(stopData: any) {
    const stopParam = '/' + stopData.stop.stopID + '?reSequenceFlag=true';
    const stopForm = {
      'stop': {
        'stopID': stopData.stop.stopID,
        'stopSequenceNumber': stopData.stop.stopSequenceNumber
      }
    };
    this.jbhGlobals.apiService.addData(this.jbhGlobals.endpoints.order.crudStopDetails + stopParam, stopForm).subscribe(data => {
      if (!this.jbhGlobals.utils.isEmpty(data)) {
        this.jbhGlobals.logger.info('Stop Resequence Updated');
      }
    }, (err: Error) => {
             return false;
        });
  }
  public stopResequenceValidation() {
     const resequenceFlag = this.orderId + '?resequenceflag=true';
     this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getResequenceValidation + resequenceFlag).subscribe(data => {
          if (!this.jbhGlobals.utils.isEmpty(data)) {
             this.jbhGlobals.logger.info('Stops Validated Successfully');
          }
     }, (err: Error) => {
             return false;
        });
  }
  onDragEnd(e, item, index): void {
    const lis = document.getElementById('list').getElementsByTagName('li');
    const data = [];
    this.sortedArray = [];
    for (let i = 0; i < lis.length; i++) {
      data.push(lis[i].querySelector('#cityName').innerHTML);
    }
    this.updateStopResequence(item);
    for (let i = 0; i < data.length; i++) {
      for (let j = 0; j < this.tempArray.length; j++) {
        if (data[i] === this.tempArray[j].stop.stopID) {
          this.tempArray[j].stop.stopSequenceNumber = i + 1;
          this.sortedArray.push(this.tempArray[j]);
          break;
        }
      }
    }
  }
  showStopDesc(item: any): void {
    this.selectedStop = item;
  }
  removeStopResequence(event, pos: number, stopId: number) {
    event.stopPropagation();
    this.stopResequenceList.splice(pos, 1);
    //  this.removeStopEvent.emit();
  }
  ngOnDestroy(): void {
    this.sortedArray = [];
    this.tempArray = [];
  }
}
