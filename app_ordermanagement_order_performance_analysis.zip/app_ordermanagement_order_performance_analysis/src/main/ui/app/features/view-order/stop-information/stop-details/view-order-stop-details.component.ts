import { Component, Input, OnInit, ViewChild,  ViewChildren, ElementRef, EventEmitter, Output } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';

import * as jsonpatch from 'fast-json-patch';

import { SiteProfileComponent } from './site-profile/view-order-site-profile.component';
import { JBHGlobals } from 'app/app.service';
// import { OrderService } from 'app/features/create-orders/orders/order.service';
import { OrderFormBuilder } from 'app/features/create-orders/orders/order-form-builder.service';
import { VieworderjsontransformerService } from 'app/features/view-order/vieworderJsonTransformer.service';
import { StopDetailsService } from './services/stop-details.service';
import { ViewOrderService } from '../../view-order.service';


@Component({
    selector: 'app-stop-details',
    templateUrl: './view-order-stop-details.component.html',
    styleUrls: ['./view-order-stop-details.component.scss'],
    providers: [StopDetailsService]
})

export class StopDetailsComponent implements OnInit {
    @ViewChildren('apptRequestedChild') apptRequestedChild: any;
    @ViewChildren('apptScheduledChild') apptScheduledChild: any;
    @ViewChild('serviceTypeCodeTag') serviceTypeCodeTag: any;
    @ViewChild('appointmentNumber') appointmentNumber: ElementRef;
    @ViewChild('appointmentInsTag') appointmentInsTag: any;
    @ViewChild('handlingUnitRef') handlingUnitRef: any;
    @ViewChild(SiteProfileComponent) siteprofile: SiteProfileComponent;
    @ViewChild('popover') popover: any;
    @Input() stopNumber;
    @Input() stopDetail;
    @Input() editMode;
    @Input() stopResequenceDetails: any;
    @Output() closeFunctions = new EventEmitter();
    @Output() submitSelected = new EventEmitter();
    stopForm: any;
    stopDetails: any;
    stopSaveActionSuccess = true;
    requestedAppts: any = {};
    stopAppointmentValue: any[];
    scheduledAppts: any = {};
    scheduledAppt: any;
    stopServices: FormGroup;
    stopServiceObject: any;
    stopJson: any;
    stopReasonList: string[] = [];
    isStopMiles = false;
    totalMilesList: string[] = [];
    appointmentInstructionListObj: any;
    appointmentInstructionObj: string[] = [];
    serviceLevelTypeCodeListObj: any;
    serviceLevelTypeCodeObj: Array < string > = [];
    locationLoading: boolean;
    locationNoResults: boolean;
    isFirstStop = false;
    roleType: string;
    stopTotalMiles = 0;
    locationCode: string;
    preStopNumber: number;
    curStopZip: number;
    prevStopZip: number;
    zipCode: string;
    debounceValue: number;
    scheduledForm: any;
    appointmentInstruction: FormGroup;
    orderData: any;
    stopId: number;
    currentStopId: number;
    stopReasonType;
    isDataLoaded = false;
    locationContactTypeRes: any[] = [];
    locationContactList: any[] = [];
    appointmentInstructionList: any[] = [];
    serviceLevelTypeCodeList: any[] = [];
    typeAheadList: string[] = [];
    closeFlag = 1;
    stopID: any;
    jsonpatch: any;
    changeObserver: any = [];
    encFormData: any;
    stopEntity: any;
    stopServiceObserver: any;
    stopServiceEntity: any;
    stopAppointmentEntity: any;
    initialJson: any;
    modifiedJson: any;

    constructor(public orderFormBuilder: OrderFormBuilder,
                public router: Router,
                public jbhGlobals: JBHGlobals,
                public viewOrderService: ViewOrderService,
                public transformerService: VieworderjsontransformerService,
                public stopDetailsService: StopDetailsService) {

        this.jsonpatch = jsonpatch;
    }
    ngOnInit() {
        this.loadOrderData();
        this.loadStopReason();
        this.onSelectContactType();
        this.loadAppointmentInstruction();
        this.stopForm = this.orderFormBuilder.getStopDetailList();
        this.debounceValue = this.jbhGlobals.settings.debounce;
        this.stopServices = this.stopForm['controls']['stopServices']['controls'][0];
        this.appointmentInstruction = this.orderFormBuilder.getAppointmentInstruction();
        this.stopForm['controls']['locationID']['valueChanges']
            .debounceTime(this.debounceValue)
            .distinctUntilChanged()
            .subscribe((value) => {
                if (value !== undefined && value.length > 2) {
                    this.roleType = 'solicitor';
                    this.getLocationTypeAhead(value, this.roleType);
                }
            }, (err: Error) => {
                console.log(err);
            });
        this.scheduledForm = this.orderFormBuilder.scheduledAppointments();
        this.loadStopDetails();
    }
    public loadStopDetails() {
        let stopUrl: string;
        if (this.stopDetail && this.editMode === true) {
            const stopParam = this.orderData.orderID + '/stops/' + this.stopDetail.stop.stopID;
            stopUrl = this.jbhGlobals.endpoints.order.getstopbyid + stopParam;
        } else {
            stopUrl = this.jbhGlobals.endpoints.order.getstopmockdata;
        }
        this.stopDetailsService.loadServices(stopUrl).subscribe(data => {
            if (!this.jbhGlobals.utils.isEmpty(data)) {
                this.stopDetails = data['stop'];
                this.orderData.stopDTOs = data;
                if (this.stopDetail && this.editMode === true) {
                    this.populateStopData(this.stopDetail);
                    this.stopEntity = this.transformerService.stopDTOsToEntity(this.stopDetail.stop);
                    this.initialJson = this.stopEntity;
                }
                if (this.orderData.stopDTOs.stop.appointment) {
                    const apptArr = this.orderData.stopDTOs.stop.appointment;
                    let requestedExist = false;
                    let scheduledExist = false;
                    const apptInstruction = this.orderFormBuilder.getAppointmentInstruction();
                    for (const appts of apptArr) {
                        if (appts['appointmentTypeCode'] === 'requested') {
                            requestedExist = true;
                            this.requestedAppts = appts;
                        } else if (appts['appointmentTypeCode'] === 'scheduled') {
                            this.scheduledAppts = appts;
                            scheduledExist = true;
                            if (!this.scheduledAppts.appointmentInstructionAssociation) {
                                this.scheduledAppts.appointmentInstructionAssociation = [apptInstruction.value];
                            }
                        }
                    }
                    if (!requestedExist) {
                        this.addAppointments(0);
                    }
                    if (!scheduledExist) {
                        this.addAppointments(1);
                    }
                }
                if (this.orderData.stopDTOs.stop.stopServices) {
                    const stopService = this.orderFormBuilder.getStopServices();
                    if (this.orderData.stopDTOs.stop.stopServices.length === 0) {
                        this.stopServiceObject = [stopService.value];
                    } else {
                        this.stopServiceObject = this.orderData.stopDTOs.stop.stopServices;
                    }
                    // this.stopForm['controls']['stopServices']['patchValue'](this.stopServiceObject);
                }
            }
        }, (err: Error) => {
            return false;
        });
    }

    public loadStopReason() {
        this.stopDetailsService.loadServices(this.jbhGlobals.endpoints.order.getstopreason).subscribe(data => {
            this.stopReasonList = data['_embedded']['stopReasons'];
        }, (err: Error) => {
            return false;
        });
    }
    public loadAppointmentInstruction() {
        this.stopDetailsService.loadServices(this.jbhGlobals.endpoints.order.getappointmentinstruction).subscribe(data => {
            this.appointmentInstructionList = this.jbhGlobals.utils.uniqBy(data['_embedded']['appointmentInstructions'],
                'appointmentInstructionText');
            this.appointmentInstructionListObj = this.jbhGlobals.utils.clone(this.appointmentInstructionList);
            this.appointmentInstructionList = this.jbhGlobals.utils.map(this.appointmentInstructionList, 'appointmentInstructionText');
        }, (err: Error) => {
            return false;
        });
    }
    public loadStopServicesList() {
        const params = {
                'businessUnit': this.orderData.financeBusinessUnitCode,
                'serviceOffering': this.orderData.serviceOfferingCode,
                'serviceCategoryCode': 'StopServ'
            };
        this.stopDetailsService.loadServiceWithParams(this.jbhGlobals.endpoints.order.getstopserviceslist, params).subscribe(data => {
            if (!this.jbhGlobals.utils.isEmpty(data) && !this.jbhGlobals.utils.isEmpty(data['_embedded'])) {
                this.serviceLevelTypeCodeList = this.jbhGlobals.utils.uniqBy(data['_embedded']['serviceTypes'], 'serviceTypeDescription');
            this.serviceLevelTypeCodeListObj = this.jbhGlobals.utils.clone(this.serviceLevelTypeCodeList);
            this.serviceLevelTypeCodeList = this.jbhGlobals.utils.map(this.serviceLevelTypeCodeList, 'serviceTypeDescription');
            }
        });
    }
    public onStopServiceSelection(eve) {
        const serviceTypeVal = this.jbhGlobals.utils.find(this.serviceLevelTypeCodeListObj, {
            serviceTypeDescription: eve.text
        });
        this.serviceLevelTypeCodeObj.push(this.populateStopServiceObj(serviceTypeVal));
        this.orderData['stopDTOs']['stop']['stopServices'] = [];
        this.orderData['stopDTOs']['stop']['stopServices'] = this.serviceLevelTypeCodeObj;
        console.log(this.orderData['stopDTOs']['stop']['stopServices']);
    }

    public appointmentNumberChanged(val) {
        const apptArr = this.orderData.stopDTOs.stop.appointment;
        const scheduledAppt = this.jbhGlobals.utils.find(apptArr, {
            appointmentTypeCode: 'scheduled'
        });
        scheduledAppt.appointmentConfirmationNumber = val;
    }

    public onApptInstructionSelection(eve) {
        const apptInstruction = this.jbhGlobals.utils.find(this.appointmentInstructionListObj, {
            appointmentInstructionText: eve.text
        });
        this.appointmentInstructionObj.push(this.generateAppointmentInsObj(apptInstruction));
        const apptArr = this.orderData.stopDTOs.stop.appointment;
        this.scheduledAppt = this.jbhGlobals.utils.find(apptArr, {
            appointmentTypeCode: 'scheduled'
        });
        this.scheduledAppt.appointmentInstructionAssociation = [];
        this.scheduledAppt.appointmentInstructionAssociation = this.appointmentInstructionObj;
    }

    public onApptInstructionRemove(eve) {
        this.jbhGlobals.utils.remove(this.appointmentInstructionObj, {
            appointmentInstructionAdditionalDetail: eve.text
        });
        // this.scheduledAppt.appointmentInstructionAssociation = this.appointmentInstructionObj;
    }

    public onStopServiceRemove(eve) {
        const serviceTypeVal = this.jbhGlobals.utils.find(this.serviceLevelTypeCodeListObj, {
            serviceTypeDescription: eve.text
        });
        this.jbhGlobals.utils.remove(this.serviceLevelTypeCodeObj, {
            serviceType: serviceTypeVal.serviceTypeCode
        });
        this.orderData['stopDTOs']['stop']['stopServices'] = this.serviceLevelTypeCodeObj;
    }

    public getCurrentStopMile(currentStopMile, currentStopResequenceList) {
        for (const resequenceObj of currentStopResequenceList) {
            if (resequenceObj['stopMiles'] && resequenceObj['stopMiles'] !== undefined) {
                this.stopTotalMiles = (this.stopTotalMiles + resequenceObj['stopMiles']);
                this.isStopMiles = true;
            }
        }
        this.stopTotalMiles = (this.stopTotalMiles + currentStopMile);
    }

    public typeaheadOnSelect(eve) {
        this.locationCode = eve.item.code;
        if (this.orderData && this.orderData.stopDTOs && this.orderData.stopDTOs.stop !== null) {
            this.orderData.stopDTOs.stop.locationID = this.locationCode;
            this.orderData.stopDTOs.stop.stopReason = this.stopReasonType;
            // this.orderData.stopDTOs.stop.stopSequenceNumber = this.stopResequenceDetails[this.stopNumber]['stop']['stopSequenceNumber'];
            this.stopForm['controls']['locationID']['setValue'](eve.item.name + '-' +
                eve.item.addressDTO.addressLine1 + ' ' + eve.item.addressDTO.addressLine2 +
                ',' + eve.item.addressDTO.city + ' ' + eve.item.addressDTO.country +
                ' ' + eve.item.addressDTO.state + ' ' + eve.item.addressDTO.zipcode + ' ' + '(' + eve.item.code + ')');

        }

    }
    public onSelectContactType() {
        /* const params = {
             code: locationCode,
             roletype: 'solicitor',
             active: 'yes'
         }; */
        this.stopDetailsService.loadServiceWithParams(this.jbhGlobals.endpoints.order.getlocationContactType, false).subscribe(data => {
            if (data && data !== undefined) {
                this.locationContactTypeRes = data;
                this.locationContactList = [];
                for (let i = 0; i < this.locationContactTypeRes.length; i++) {
                    const value1 = this.locationContactTypeRes[i].firstName + ' ' + this.locationContactTypeRes[i].lastName;
                    const value = value1 + ' , ' + this.locationContactTypeRes[i].contactValue;
                    this.locationContactList.push({
                        id: value,
                        text: value
                    });
                }
                this.locationContactList.push({
                    id: 'Add Contact',
                    text: 'Add Contact'
                });
            }
        }, (err: Error) => {
            return false;
        });
    }
    public loadOrderData() {
        if (this.jbhGlobals.utils.isEmpty(this.orderData) && !this.isDataLoaded) {
            this.viewOrderService.getData().subscribe(sharedOrderData => {
                this.orderData = sharedOrderData;
                this.isDataLoaded = true;
                this.loadStopServicesList();
            }, (err: Error) => {
                return false;
            });
        }
    }

    public onStopReasonChange(reason: string) {
        this.stopReasonType = reason.trim();
        if (this.orderData && this.orderData.stopDTOs && this.orderData.stopDTOs.stop !== null) {
            this.orderData.stopDTOs.stop.stopReason = this.stopReasonType;

        }

    }
    public getLocationTypeAhead(value, roleType) {
        const params = {
            value: value,
            roletype: roleType,
            active: 'yes',
            page: 0,
            size: 5,
            approved: true,
            addresstype: 'mailing'
        };
        this.stopDetailsService.loadServiceWithBoolean(this.jbhGlobals.endpoints.order.gettypeaheadbillto,
            params, false).subscribe(data => {
            if (data['profileDTO'] !== undefined) {
                this.typeAheadList = data['profileDTO'];
            }
        }, (err: Error) => {
            return false;
        });
    }
    public addAppointments(appt: number) {
        const stopCtrl = this.orderFormBuilder.getInitDateTimeDetails();
        const apptInstruction = this.orderFormBuilder.getAppointmentInstruction();
        if (appt === 0) {
            //            if (this.apptRequestedChild && this.apptRequestedChild.isApptReqSaved === false) {
            //                this.jbhGlobals.notifications.alert('Warning', 'Current appointment not saved');
            //                return;
            //            }
            const isReqApptFormValid = this.jbhGlobals.utils.findIndex(this.apptRequestedChild._results, function(obj) {
                return obj.appointmentForm.valid === false;
            });
            if (isReqApptFormValid !== -1) {
                this.jbhGlobals.notifications.alert('Warning', 'Please enter all the required fields');
                return;
            }
            if (!this.requestedAppts.appointmentDateTimeDetails) {
                this.requestedAppts.appointmentDateTimeDetails = [stopCtrl.value];
            } else {
                this.requestedAppts.appointmentDateTimeDetails.push(stopCtrl.value);
            }
        } else if (appt === 1) {
            //            if (this.apptScheduledChild && this.apptScheduledChild.isApptScheduledSaved === false) {
            //                this.jbhGlobals.notifications.alert('Warning', 'Current appointment not saved');
            //                return;
            //            }
            const isSchdApptFormValid = this.jbhGlobals.utils.findIndex(this.apptScheduledChild._results, function(obj) {
                return obj.appointmentForm.valid === false;
            });
            if (isSchdApptFormValid !== -1) {
                this.jbhGlobals.notifications.alert('Warning', 'Please enter all the required fields');
                return;
            }
            if (!this.scheduledAppts.appointmentDateTimeDetails) {
                this.scheduledAppts.appointmentDateTimeDetails = [stopCtrl.value];
            } else {
                this.scheduledAppts.appointmentDateTimeDetails.push(stopCtrl.value);
            }
            if (!this.scheduledAppts.appointmentInstructionAssociation) {
                this.scheduledAppts.appointmentInstructionAssociation = [apptInstruction.value];
            }
        }
    }
    public onClickSiteProfileShow() {
        this.popover.hide();
        this.siteprofile.onShowSiteProfileModal();
    }
    populateStopServiceObj(serviceTypeVal) {
        if (!this.jbhGlobals.utils.isEmpty(serviceTypeVal)) {
            const stopServiceObject: any = {
                serviceID: '',
                serviceCount: '',
                unitOfServiceMeasurementCode: 'HOURS',
                serviceLevelTypeCode: 'STOP',
                serviceType: serviceTypeVal.serviceTypeCode
            };
            return stopServiceObject;
        }
    }
    generateAppointmentInsObj(apptInstruction) {
        const appointmentInsObj: any = {
            appointmentInstructionAssociationID: '',
            appointmentInstruction: apptInstruction.appointmentInstructionID,
            appointmentInstructionAdditionalDetail: apptInstruction.appointmentInstructionText
        };

        return appointmentInsObj;
    }
    public populateStopData(stopData) {
        const stopLocation = stopData.locationDTO;
        let partyName;
        let addressLine1;
        let addressLine2;
        let city;
        let country;
        let state;
        let zip;
        if (stopLocation && stopLocation !== undefined) {
            if (stopLocation.partyName !== undefined) {
                partyName = stopLocation.partyName;
            }
            if (stopLocation.addressDTO.addressLineOne !== undefined) {
                addressLine1 = stopLocation.addressDTO.addressLineOne;
            }
            if (stopLocation.addressDTO.addressLineTwo !== undefined) {
                addressLine2 = stopLocation.addressDTO.addressLineTwo;
            }
            if (stopLocation.addressDTO.city !== undefined) {
                city = stopLocation.addressDTO.city;
            }
            if (stopLocation.addressDTO.country !== undefined) {
                country = stopLocation.addressDTO.country;
            }
            if (stopLocation.addressDTO.state !== undefined) {
                state = stopLocation.addressDTO.state;
            }
            if (stopLocation.addressDTO.zipCode !== undefined) {
                zip = stopLocation.addressDTO.zipCode;
            }
            this.stopForm['controls']['locationID']['setValue'](partyName + '-' + addressLine1 + ' ' + addressLine2 +
                ',' + city + ' ' + country + ' ' + state + ' ' + zip);
        }
        if (!this.jbhGlobals.utils.isEmpty(stopData.stop.stopServices)) {
            const stopServices = stopData.stop.stopServices;
            this.populateStopServices(stopServices);

        }
        const locationID = stopData.stop.locationID;
        this.stopForm['controls']['stopReason']['setValue'](stopData.stop.stopReason);
        this.orderData.stopDTOs.stop.locationID = this.locationCode;
        this.orderData.stopDTOs.stop.stopReason = stopData.stop.stopReasonType;
        this.orderData.stopDTOs.stop.locationID = locationID;
        const isScheduledApptExist = this.jbhGlobals.utils.find(stopData.stop.appointment, {
            appointmentTypeCode: 'scheduled'
        });
        if (isScheduledApptExist && isScheduledApptExist !== undefined) {
            const appointmentInstruction = isScheduledApptExist.appointmentInstructionAssociation;
            this.populateAppointmentIns(appointmentInstruction);
            if (isScheduledApptExist.appointmentConfirmationNumber !== null &&
                isScheduledApptExist.appointmentConfirmationNumber !== '') {
                this.appointmentNumber.nativeElement.value = isScheduledApptExist.appointmentConfirmationNumber;
            }
        }
    }

    populateStopServices(stopServices) {
        setTimeout(() => {
            if (!this.jbhGlobals.utils.isEmpty(stopServices)) {
                for (let i = 0; i < stopServices.length; i++) {
                    const serviceTypeVal = this.jbhGlobals.utils.find(this.serviceLevelTypeCodeListObj, {
                        serviceTypeCode: stopServices[i].serviceType
                    });
                    if (!this.jbhGlobals.utils.isEmpty(serviceTypeVal)) {
                        this.serviceLevelTypeCodeObj.push(this.populateStopServiceObj(serviceTypeVal));
                        this.serviceTypeCodeTag.active.push({
                            id: serviceTypeVal.serviceTypeDescription,
                            text: serviceTypeVal.serviceTypeDescription
                        });
                    }
                }
            }
        }, 500);
    }

    populateAppointmentIns(appointmentInstruction) {
        if (!this.jbhGlobals.utils.isEmpty(appointmentInstruction)) {
            setTimeout(() => {
                for (let j = 0; j < appointmentInstruction.length; j++) {
                    const apptInstruction = this.jbhGlobals.utils.find(this.appointmentInstructionListObj, {
                        appointmentInstructionID: Number(appointmentInstruction[j].appointmentInstruction)
                    });
                    this.appointmentInstructionObj.push(this.generateAppointmentInsObj(apptInstruction));
                    this.appointmentInsTag.active.push({
                        id: apptInstruction.appointmentInstructionText,
                        text: apptInstruction.appointmentInstructionText
                    });
                }
            }, 500);
        }

    }
    // public stopDetailSaveForm(page) {
    //     let isFormTouched = false;
    //     let apptArr: any = '';
    //     let scheduledAppt: any = '';
    //     // if (this.stopForm.touched && this.stopForm.dirty) {
    //         if (this.stopServices.touched && this.stopServices.dirty) {
    //             this.orderData.stopDTOs.stop.stopServices = [];
    //             this.orderData.stopDTOs.stop.stopServices = this.serviceLevelTypeCodeObj;
    //         }
    //         isFormTouched = true;
    //     // }
    //     if (this.scheduledForm.touched && this.scheduledForm.dirty) {
    //         if (this.orderData.stopDTOs.stop && this.orderData.stopDTOs.stop.appointment) {
    //             apptArr = this.orderData.stopDTOs.stop.appointment;
    //             scheduledAppt = this.jbhGlobals.utils.find(apptArr, {
    //                 appointmentTypeCode: 'scheduled'
    //             });
    //         }
    //         scheduledAppt.appointmentConfirmationNumber = this.appointmentNumber.nativeElement.value;
    //         isFormTouched = true;
    //     }
    //     if (this.appointmentInstruction.touched && this.appointmentInstruction.dirty) {
    //         if (scheduledAppt && scheduledAppt !== undefined) {
    //             scheduledAppt.appointmentInstructionAssociation = [];
    //             scheduledAppt.appointmentInstructionAssociation = this.appointmentInstructionObj;
    //         }
    //         isFormTouched = true;
    //     }
    //        if (isFormTouched) {
    //            let stopID = this.orderData.stopDTOs.stop.stopID;
    //            const orderID = this.orderData.orderID;
    //            // this.stopJson = this.getStopJson(orderID);
    //            if (stopID && stopID !== undefined) {
    //                stopID = '/' + stopID;
    //                return this.updateStopDetails(stopID, this.stopJson, page);
    //            } else {
    //                return this.addStopDetails(this.stopJson, page);
    //            }
    //        } else if (!isFormTouched && page === 'prev') {
    //            this.router.navigateByUrl('/createorders/order/create?id=' + this.orderData.orderID);
    //        }
    // }

    public closeFunction() {
        this.closeFunctions.emit(this.closeFlag);
    }

    onSubmit() {
        if (this.editMode) {
            this.modifiedJson = this.transformerService.stopDTOsToEntity(this.orderData.stopDTOs.stop);
            const url =  'http://winx-v0424:8081/ordermanagementorderupdateservices/orders/' + this.orderData.orderID + '/stops/' +
            this.orderData.stopDTOs.stop.stopID + '/patch';
            this.viewOrderService.updateData(url, this.initialJson, this.modifiedJson).subscribe(data => {
                if (this.jbhGlobals.utils.isEmpty(data)) {
                    console.log(data);
                }
            });
            this.submitSelected.emit(this.orderData);
        } else {
            this.submitSelected.emit(this.orderData);
        }
    }
    public addHandlingUnitForm(handlingUnitObject) {
        this.stopDetail.itemHandlingDetailDTOs.push(handlingUnitObject);
        // this.addHandlingUnitFlag = false;
        // this.changeDetector.markForCheck();
    }
}
