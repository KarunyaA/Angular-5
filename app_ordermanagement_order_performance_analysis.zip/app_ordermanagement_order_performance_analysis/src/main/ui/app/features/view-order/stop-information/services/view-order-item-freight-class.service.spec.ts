import { TestBed, inject } from '@angular/core/testing';

import { ViewOrderItemFreightClassService } from './view-order-item-freight-class.service';

describe('ViewOrderItemFreightClassService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ViewOrderItemFreightClassService]
    });
  });

  it('should be created', inject([ViewOrderItemFreightClassService], (service: ViewOrderItemFreightClassService) => {
    expect(service).toBeTruthy();
  }));
});
