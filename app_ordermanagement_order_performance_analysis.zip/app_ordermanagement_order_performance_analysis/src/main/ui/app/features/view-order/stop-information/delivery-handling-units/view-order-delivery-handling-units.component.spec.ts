import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeliveryHandlingUnitsComponent } from './view-order-delivery-handling-units.component';

describe('DeliveryHandlingUnitsComponent', () => {
  let component: DeliveryHandlingUnitsComponent;
  let fixture: ComponentFixture<DeliveryHandlingUnitsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeliveryHandlingUnitsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeliveryHandlingUnitsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
