import { Component, OnInit } from '@angular/core';
import { JBHGlobals } from 'app/app.service';
import { ViewOrderService } from 'app/features/view-order/view-order.service';
import { OrderFormBuilder } from 'app/features/create-orders/orders/order-form-builder.service';
// import { HandlingUnitsComponent } from '../handling-units/view-order-handling-units.component';

@Component({
  selector: 'app-stop-handling',
  templateUrl: './view-order-stop-handling.component.html' ,
  styleUrls: ['./view-order-stop-handling.component.scss']
})
export class StopHandlingComponent implements OnInit {
    // public getHandlingData: any;
    // public handlingForm: any;
    // public orderData: any;
    // private isDataLoaded = false;
    // @ViewChildren(HandlingUnitsComponent) handlingComponent: QueryList<HandlingUnitsComponent>;

  constructor(public jbhGlobals: JBHGlobals,
              public viewOrderService: ViewOrderService,
              public orderFormBuilder: OrderFormBuilder) {}

   ngOnInit() {
      // this.handlingForm =  this.orderFormBuilder.addHandlingUnit();
      // this.loadOrderData();
  }

   // public loadOrderData() {
   //    if (this.jbhGlobals.utils.isEmpty(this.orderData) && !this.isDataLoaded) {
   //      this.viewOrderService.getData().subscribe( sharedOrderData => {
   //       // this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getorder).subscribe(sharedOrderData => {
   //           if (!this.jbhGlobals.utils.isEmpty(sharedOrderData)) {
   //                  this.orderData = sharedOrderData;
   //                  this.isDataLoaded = true;
   //               }
   //     });
   //    }
   //  }
   // public stopHandlingFormSave(): any {
   //     this.handlingComponent.last.handlingUnitSaveCall();
   // }
}
