export class ViewOrderHandlingModel {
    rows: any = [];
    selected: any = [];
    dimensionsSelect = true;
    itemhandlingList: any = [];
    debounceValue: any;
    itemHandlingUnitList: any[] = [];
    itemWeightList: any[] = [];
    itemLengthList: any[] = [];
    handlingReferenceList: any[] = [];
    stopId: any;
    orderData: any;
    handlingDetails: any;
    handlingItemDetailsDto: any;
    handlingUnitVolume: any;
    handlingDimensionFlag = true;
    handlingUnitDensity: any;
    handlingVolumeVal: any;
    handlingDensityVal: any;
    handlingVolume: any;
    handlingformCount: number = 0;
    addHandlingUnitFormFlag: boolean;
    isDataLoaded = false;
    handlingUnitId: any;
    flatbedFlag = false;
    denMeasureFlag = false;
    volMeasureFlag = false;

}
