import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { IMyOptions, IMyDateModel } from 'mydatepicker';
import { JBHGlobals } from 'app/app.service';
import { ViewOrderService } from 'app/features/view-order/view-order.service';
import { DatePipe } from '@angular/common';
import { OrderFormBuilder } from 'app/features/create-orders/orders/order-form-builder.service';

@Component({
  selector: 'app-appointment-details',
  templateUrl: './view-order-appointment-details.component.html',
  styleUrls: ['./view-order-appointment-details.component.scss'],
  providers: [ DatePipe ]
})
export class AppointmentDetailsComponent implements OnInit {
   @Input() apptType;
   @Input() position;
   @Input() appointmentData;
   @Input() scheduledAppts;
   @Input() apptRequested;
   @Input() stopDTO;
   @Input() editMode;
   @Output() orderDataList = new EventEmitter();
   public appointmentForm: any;
   public apptStartDate: any;
   public apptStartTime: any;
   public apptEndDate: any;
   public apptEndTime: any;
   public apptJson: any;
   public apptStartDateTime: any;
   public apptEndDateTime: any;
   public isApptReqSaved = true;
   public isApptScheduledSaved = true;
   @Input() dateTimeForm: any;
   public orderData: any;
   public requestedApptObject: any = [];
   public scheduledApptObject: any = [];
   public requestedAppt: any;
   public scheduledAppt: any;
   selectedStartDate: string = '';
   selectedEndDate: string = '';
   public myDatePickerOptionsStartDate: IMyOptions = {
       todayBtnTxt: 'Today',
       dateFormat: 'mm/dd/yyyy',
       firstDayOfWeek: 'mo',
       showTodayBtn: false,
       showClearDateBtn: false,
       editableDateField: false,
       sunHighlight: true,
       height: '34px',
       width: '170px',
       inline: false,
       // disableUntil: {year: 2016, month: 8, day: 10},
       dayLabels: { su: 'S', mo: 'M', tu: 'T', we: 'W', th: 'T', fr: 'F', sa: 'S' },
       selectionTxtFontSize: '14px'
   };
   public myDatePickerOptionsEndDate: IMyOptions = {
       todayBtnTxt: 'Today',
       dateFormat: 'mm/dd/yyyy',
       firstDayOfWeek: 'mo',
       showTodayBtn: false,
       showClearDateBtn: false,
       editableDateField: false,
       sunHighlight: true,
       height: '34px',
       width: '170px',
       inline: false,
       // disableUntil: {year: 2016, month: 8, day: 10},
       dayLabels: { su: 'S', mo: 'M', tu: 'T', we: 'W', th: 'T', fr: 'F', sa: 'S' },
       selectionTxtFontSize: '14px'
   };
   constructor(public jbhGlobals: JBHGlobals, public datePipe: DatePipe,
       public viewOrderService: ViewOrderService,
       public orderFormBuilder: OrderFormBuilder) {
   }
   ngOnInit() {
       this.loadOrderData();
       this.disableCurrentDate();
       this.appointmentForm = this.orderFormBuilder.getInitDateTimeDetails();
                   this.populateApptDetails();
                   this.populateAppointmentInEditMode();
   }
   public loadOrderData() {
       if (this.jbhGlobals.utils.isEmpty(this.orderData)) {
          this.viewOrderService.getData().subscribe(sharedOrderData => {
               if (!this.jbhGlobals.utils.isEmpty(sharedOrderData)) {
                   this.orderData = sharedOrderData;
                   this.orderData.stopDTOs = this.stopDTO;
               }
           }, (err: Error) => {
             return false;
        });
       }
   }
   public populateApptDetails() {
       if (this.apptType === 0) {
           this.apptStartDateTime = this.apptRequested.appointmentStartTimestamp;
           this.apptEndDateTime = this.apptRequested.appointmentEndTimestamp;
       } else if (this.apptType === 1) {
           this.apptStartDateTime = this.scheduledAppts.appointmentStartTimestamp;
           this.apptEndDateTime = this.scheduledAppts.appointmentEndTimestamp;
       }
       if (this.apptStartDateTime && this.apptStartDateTime !== undefined &&
           this.apptEndDateTime && this.apptEndDateTime !== undefined) {
           this.setAppointmentDetails(this.apptStartDateTime, this.apptEndDateTime);
       }
   }
   public setAppointmentDetails(apptStartDateTime, apptEndDateTime) {
       const startDateLimit = apptStartDateTime.indexOf('T');
       const datePipe = new DatePipe('en-US');
       const startDate = apptStartDateTime.substr(0, startDateLimit);
       this.apptStartDate = datePipe.transform(startDate, 'MM-dd-yyyy');
       const appStartDate = new Date(startDate);
       this.appointmentForm['controls']['appointmentStartDate']['setValue']({
           date: {
               year: appStartDate.getFullYear(),
               month: appStartDate.getMonth(),
               day: appStartDate.getDate()
           }
       });
       this.apptStartTime = datePipe.transform(apptStartDateTime, 'hh:mm');
       this.appointmentForm['controls']['appointmentStartTimestamp']['setValue'](this.apptStartTime);
       const endDateLimit = apptEndDateTime.indexOf('T');
       const endDate = apptEndDateTime.substr(0, endDateLimit);
       const appEndDate = new Date(endDate);
      this.apptEndDate = datePipe.transform(endDate, 'MM-dd-yyyy');
       this.appointmentForm['controls']['appointmentEndDate']['setValue']({
           date: {
               year: appEndDate.getFullYear(),
               month: appEndDate.getMonth(),
               day: appEndDate.getDate()
           }
       });
       this.apptEndTime = datePipe.transform(apptEndDateTime, 'hh:mm');
       this.appointmentForm['controls']['appointmentEndTimestamp']['setValue'](this.apptEndTime);
   }
   public removeAppointmentDate(appt: number, pos: number, apptId: number) {
       const appointmentArray = this.orderData.stopDTOs.stop.appointment[appt].appointmentDateTimeDetails;
       appointmentArray.splice(pos, 1);
       // const apptID = '/' + apptId;
       // if (!apptID) {
       //     this.jbhGlobals.apiService.removeData(this.jbhGlobals.endpoints.order.crudApptDetails + apptID).subscribe(apptData => {
       //         this.jbhGlobals.notifications.info('Deleted', 'Appointment Deleted');
       //     }, (err: Error) => {
       //       return false;
       //  });
       // }
   }
   public appointmentJson(apptType: number, appointmentStartTime: any, appointmentEndTime: any,
       primaryCallBack: string, apptId: number, apptDetailId: number): any {
       // const stopID = '/' + stopId;
       let appointmentDateTimeDetailID: any = '';
       let appointmentInstructionArr = [];
       if (apptType === 1) {
           if (this.scheduledAppts.appointmentDateTimeDetailID) {
              appointmentDateTimeDetailID = this.scheduledAppts.appointmentDateTimeDetailID;
           }
           const apptScheduled = this.orderData.stopDTOs.stop.appointment[apptType];
           const apptInstArr = this.jbhGlobals.utils.transform(apptScheduled.appointmentInstructionAssociation, function(result, obj) {
                        result.push({appointmentInstruction: obj.appointmentInstruction, appointmentInstructionAdditionalDetail: '',
                                    appointmentInstructionAssociationID: ''});
                    }, []);
           const appointmentConfirmationNumber = apptScheduled.appointmentConfirmationNumber;
           if ((apptScheduled.appointmentInstructionAssociation.length === 1 &&
            !apptScheduled.appointmentInstructionAssociation[0].appointmentInstruction) ||
                apptScheduled.appointmentInstructionAssociation.length < 1) {
               appointmentInstructionArr = [];
           } else {
               appointmentInstructionArr = apptInstArr;
           }
           return this.apptJson = {
               'appointmentID': '',
               'appointmentTypeCode': 'scheduled',
               'appointmentConfirmationNumber': appointmentConfirmationNumber,
               'requestCallBackIndicator': 'Y',
               'appointmentInboundDate': '',
               'appointmentDetails': [{
                   'appointmentDetailID': '',
                   'appointmentSetReasonCode': '02'
               }],
               'appointmentDateTimeDetails': [{
                   'appointmentDateTimeDetailID': appointmentDateTimeDetailID,
                   'appointmentStartTimestamp': appointmentStartTime,
                   'appointmentEndTimestamp': appointmentEndTime,
                   'primaryAppointmentIndicator': primaryCallBack
               }],
               'appointmentInstructionAssociations': appointmentInstructionArr,
               // 'stop': stopID
           };
       } else {
             // if (this.apptRequested.appointmentDateTimeDetailID) {
             //    appointmentDateTimeDetailID = this.apptRequested.appointmentDateTimeDetailID;
             // }
           return this.apptJson = {
               'appointmentID': '',
               'appointmentTypeCode': 'requested',
               'requestCallBackIndicator': 'Y',
               'recommendedAppointmentTimeStamp': '',
               'appointmentInboundDate': '',
               'appointmentDetails': [{
                   'appointmentDetailID': '',
                   'appointmentSetReasonCode': '02'
               }],
               'appointmentDateTimeDetails': [{
                   'appointmentDateTimeDetailID': appointmentDateTimeDetailID,
                   'appointmentStartTimestamp': appointmentStartTime,
                   'appointmentEndTimestamp': appointmentEndTime,
                   'primaryAppointmentIndicator': primaryCallBack
               }],
               // 'stop': stopID
           };
       }
   }
   public setApptToStopDto(appType, apptJson) {
      const apptArr = this.orderData.stopDTOs.stop.appointment;
      if (appType === 0) {
          // this.apptRequested.appointmentDateTimeDetailID = apptData.appointmentDateTimeDetailID;
           this.requestedAppt = this.jbhGlobals.utils.find(apptArr, {
              appointmentTypeCode: 'requested'
          });
          if (this.requestedAppt && this.requestedAppt !== undefined) {
              const indx =  (this.requestedAppt.appointmentDateTimeDetails.length - 1);
              this.requestedAppt.appointmentDateTimeDetails.splice(indx, 1, apptJson.appointmentDateTimeDetails[0]);
          }

      } else {
          // this.scheduledAppts.appointmentDateTimeDetailID = apptData.appointmentDateTimeDetailID;
           this.scheduledAppt = this.jbhGlobals.utils.find(apptArr, {
              appointmentTypeCode: 'scheduled'
          });
          if (this.scheduledAppt && this.scheduledAppt !== undefined) {
              const indx =  (this.scheduledAppt.appointmentDateTimeDetails.length - 1);
              this.scheduledAppt.appointmentDateTimeDetails.splice(indx, 1, apptJson.appointmentDateTimeDetails[0]);
          }
      }
      // this.completeAppoinmentList(this.requestedAppt,this.scheduledAppt);
   }
   public addAppointmentDetails(appointmentStartTime: any, appointmentEndTime: any, primaryCallBack: string) {
       const apptId: any = '';
       const apptDetailId: any = '';
       this.apptJson = this.appointmentJson(this.apptType, appointmentStartTime,
       appointmentEndTime, primaryCallBack, apptId, apptDetailId);
       this.setApptToStopDto(this.apptType, this.apptJson);
   }
   public getStartDate() {
       const datePipe = new DatePipe('en-US');
       let startDate = this.appointmentForm.controls['appointmentStartDate'].value;
       if (startDate && startDate !== undefined) {
          startDate = startDate.date.month + '-' + startDate.date.day + '-' + startDate.date.year;
          return  datePipe.transform(startDate, 'MM-dd-yyyy');
       }
       return;
   }
   public getEndDate() {
       const datePipe = new DatePipe('en-US');
       let endDate = this.appointmentForm.controls['appointmentEndDate'].value;
       if (endDate && endDate !== undefined) {
          endDate = endDate.date.month + '-' + endDate.date.day + '-' + endDate.date.year;
          return  datePipe.transform(endDate, 'MM-dd-yyyy');
       }
       return;
   }
   public saveAppointment() {
       if (this.apptStartDate === undefined) {
          this.apptStartDate = this.getStartDate();
       }
       if (this.apptEndDate === undefined) {
          this.apptEndDate = this.getEndDate();
       }
       if (this.apptStartTime !== undefined && this.apptEndTime !== undefined) {
           let apptId;
           let apptDetailId;
           const appt = this.orderData.stopDTOs.stop.appointment[this.apptType];
           if (appt && appt.appointmentID) {
               apptId = appt.appointmentID;
           }
           if (appt && appt.appointmentDetails[0].appointmentDetailID) {
               apptDetailId = appt.appointmentDetails[0].appointmentDetailID;
           }
           let primaryIndicator;
           if (this.position === 0) {
               primaryIndicator = 'Y';
           } else {
               primaryIndicator = 'N';
           }
           let appointmentStartTime = this.apptStartDate + ' ' + this.apptStartTime;
           let appointmentEndTime = this.apptEndDate + ' ' + this.apptEndTime;
           const datePipe = new DatePipe('en-US');
           appointmentStartTime = datePipe.transform(appointmentStartTime, 'yyyy-MM-ddThh:mm:ss.000');
           appointmentEndTime = datePipe.transform(appointmentEndTime, 'yyyy-MM-ddThh:mm:ss.000');
           this.addAppointmentDetails(appointmentStartTime, appointmentEndTime, primaryIndicator);
       }
       return;
   }
   onStartDateChanged(event: IMyDateModel) {
       this.selectedStartDate = event.formatted;
       this.apptEndDate = this.getEndDate();
       this.apptStartDate = event.date.month + '-' + event.date.day + '-' + event.date.year;
       this.myDatePickerOptionsEndDate = {
                disableUntil: {
                    year: event.date.year,
                    month: event.date.month,
                    day: event.date.day - 1
                }
              };
       this.saveAppointment();
       this.dateDurationValidator();
   }

   onStartTimeChanged(startTimeStamp) {
       this.apptStartTime = startTimeStamp;
       if (this.apptEndTime && !(this.apptStartTime < this.apptEndTime)) {
           this.jbhGlobals.notifications.alert('Warning', 'Start time must be lesser than end time');
           this.appointmentForm.controls['appointmentStartTimestamp'].setValue('');
           return;
       }
       this.saveAppointment();
   }
   onEndDateChanged(event: IMyDateModel) {
       this.apptStartDate = this.getStartDate();
       this.myDatePickerOptionsStartDate = {
                disableSince: {
                    year: event.date.year,
                    month: event.date.month,
                    day: event.date.day + 1
                }
            };
        this.apptEndDate = event.date.month + '-' + event.date.day + '-' + event.date.year;
       this.saveAppointment();
       this.dateDurationValidator();
   }

   dateDurationValidator() {
      const today = new Date();
     if (this.apptStartDate) {
       const timeDiff1 = Math.abs(new Date(this.apptStartDate).getTime() - today.getTime());
       const diffDays1 = Math.ceil(timeDiff1 / (1000 * 3600 * 24));
       if (diffDays1 > 180) {
           this.selectedStartDate = null;
           this.jbhGlobals.notifications.alert('Warning', 'The Start Date should not exceed more than 180 days');
           // this.appointmentForm.controls.appointmentEndDate.setValue(null);
           // this.selectedStartDate = '';

       }
     }
     if (this.apptEndDate) {
       const timeDiff2 = Math.abs(new Date(this.apptEndDate).getTime() - today.getTime());
       const diffDays2 = Math.ceil(timeDiff2 / (1000 * 3600 * 24));
        if (diffDays2 > 180) {
           this.jbhGlobals.notifications.alert('Warning', 'The End Date should not exceed more than 180 days');
           // this.appointmentForm.controls.appointmentEndDate.setValue(null);
           this.selectedEndDate = null;
           this.disableCurrentDate();


       }
     }
  }
   onEndTimeChanged(endTimeStamp) {
       this.apptEndTime = endTimeStamp;
       this.apptStartDate = this.getStartDate();
       this.apptEndDate = this.getEndDate();
       if (this.apptStartTime && !(this.apptEndTime > this.apptStartTime)) {
           this.jbhGlobals.notifications.alert('Warning', 'End time must be greater than start time');
           this.appointmentForm.controls['appointmentEndTimestamp'].setValue('');
           return;
       }

       this.saveAppointment();
       this.orderDataList.emit(this.orderData);

   }

  disableCurrentDate() {
    const today = new Date();
    const numdays = 180;
    let d = new Date();
    d = new Date(d.getTime() + 1000 * 60 * 60 * 24 * numdays);
      this.myDatePickerOptionsStartDate = {
        disableUntil: {
          year: today.getFullYear(),
          month: today.getMonth() + 1,
          day: today.getDate() - 1
        }
      };
      // this.myDatePickerOptionsStartDate = {
      //   disableSince: {
      //     year: d.getFullYear(),
      //     month: d.getMonth() + 1,
      //     day: d.getDate() - 1
      //   }
      // };
      this.myDatePickerOptionsEndDate = {
        disableUntil: {
          year: today.getFullYear(),
          month: today.getMonth() + 1,
          day: today.getDate() - 1
        }
      };

      // this.myDatePickerOptionsStartDate = {
      //   disableSince: {
      //     year: d.getFullYear(),
      //     month: d.getMonth() + 1,
      //     day: d.getDate() - 1
      //   }
      // };
      // this.myDatePickerOptionsEndDate = {
      //   disableSince: {
      //     year: d.getFullYear(),
      //     month: d.getMonth() + 1,
      //     day: d.getDate() - 1
      //   }
      // };
  }

  populateAppointmentInEditMode() {
    this.disableCurrentDate();
    if (this.editMode === true) {
         this.disableCurrentDate();
         if (this.apptRequested && this.apptRequested.appointmentStartTimestamp !== '') {
         this.populateStarDate(this.apptRequested.appointmentStartTimestamp);
         this.populateEndDate(this.apptRequested.appointmentEndTimestamp);
         }
         if (this.scheduledAppts && this.scheduledAppts.appointmentStartTimestamp !== '') {
         this.populateStarDateSch(this.scheduledAppts.appointmentStartTimestamp);
         this.populateEndDateSch(this.scheduledAppts.appointmentEndTimestamp);
         }
       }
  }

  getDateObject(value) {
     const obj = {
             year: value.slice(0, 4),
             month: value.slice(5, 7),
             day: value.slice(8, 10)
           };
      return obj;
  }
  populateStarDate(value) {
       const obj = this.getDateObject(value);
           this.myDatePickerOptionsEndDate = {
                disableUntil: {
                    year: obj.year,
                    month: obj.month - 1,
                    day: obj.day - 2
                }
            };
            this.apptStartDate = obj.month + '-' + obj.day + '-' + obj.year;
            this.dateDurationValidator();
  }

  populateEndDate(value) {
     const obj = {
             year: value.slice(0, 4),
             month: value.slice(5, 7),
             day: value.slice(8, 10)
           };
      this.myDatePickerOptionsStartDate = {
                disableSince: {
                    year: obj.year,
                    month: obj.month - 1,
                    day: obj.day
                }
            };
            this.apptEndDate = obj.month + '-' + obj.day + '-' + obj.year;
            this.dateDurationValidator();
  }
  populateStarDateSch(value) {
    const obj = {
             year: value.slice(0, 4),
             month: value.slice(5, 7),
             day: value.slice(8, 10)
           };
           this.myDatePickerOptionsEndDate = {
                disableUntil: {
                    year: obj.year,
                    month: obj.month - 1,
                    day: obj.day - 2
                }
            };
            this.apptStartDate = obj.month + '-' + obj.day + '-' + obj.year;
            this.dateDurationValidator();
  }

  populateEndDateSch(value) {
     const obj = {
             year: value.slice(0, 4),
             month: value.slice(5, 7),
             day: value.slice(8, 10)
           };
      this.myDatePickerOptionsStartDate = {
                disableSince: {
                    year: obj.year,
                    month: obj.month - 1,
                    day: obj.day
                }
            };
            this.apptEndDate = obj.month + '-' + obj.day + '-' + obj.year;
            this.dateDurationValidator();
  }
  // clearEndDate() {
  //    this.selectedEndDate = '';

  // }
}
