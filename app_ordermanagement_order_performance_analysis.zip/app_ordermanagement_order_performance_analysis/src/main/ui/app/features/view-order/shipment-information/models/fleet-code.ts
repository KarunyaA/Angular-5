export class FleetCode {
}
