import { TestBed, inject } from '@angular/core/testing';

import { ViewOrderItemCategoryService } from './view-order-item-category.service';

describe('ViewOrderItemCategoryService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ViewOrderItemCategoryService]
    });
  });

  it('should be created', inject([ViewOrderItemCategoryService], (service: ViewOrderItemCategoryService) => {
    expect(service).toBeTruthy();
  }));
});
