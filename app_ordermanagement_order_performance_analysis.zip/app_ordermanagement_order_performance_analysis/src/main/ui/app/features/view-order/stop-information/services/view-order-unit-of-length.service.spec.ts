import { TestBed, inject } from '@angular/core/testing';

import { ViewOrderUnitOfLengthService } from './view-order-unit-of-length.service';

describe('ViewOrderUnitOfLengthService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ViewOrderUnitOfLengthService]
    });
  });

  it('should be created', inject([ViewOrderUnitOfLengthService], (service: ViewOrderUnitOfLengthService) => {
    expect(service).toBeTruthy();
  }));
});
