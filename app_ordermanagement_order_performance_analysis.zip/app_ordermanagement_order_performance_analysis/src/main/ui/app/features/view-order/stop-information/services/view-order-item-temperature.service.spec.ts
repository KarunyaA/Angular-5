import { TestBed, inject } from '@angular/core/testing';

import { ViewOrderItemTemperatureService } from './view-order-item-temperature.service';

describe('ViewOrderItemTemperatureService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ViewOrderItemTemperatureService]
    });
  });

  it('should be created', inject([ViewOrderItemTemperatureService], (service: ViewOrderItemTemperatureService) => {
    expect(service).toBeTruthy();
  }));
});
