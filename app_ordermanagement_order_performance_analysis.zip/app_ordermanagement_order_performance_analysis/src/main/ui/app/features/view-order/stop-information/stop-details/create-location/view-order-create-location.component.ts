
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-location',
  templateUrl: './view-order-create-location.component.html',
  styleUrls: ['./view-order-create-location.component.scss']
})
export class CreateLocationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
