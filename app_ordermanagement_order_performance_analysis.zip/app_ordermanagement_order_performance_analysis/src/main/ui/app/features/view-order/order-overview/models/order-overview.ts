export class OrderOverview {
	orderData: any;
    indicator: any;
    count: number;
    originStop: any;
    destinationStop: any;
    orderOverViewListStop: any;
    orderOverViewEquipment: any;
    orderOverViewEquipmentIndicator: any;
    billtoaccountprofile: any;
    originStopSchAppNo: any;
    destinationStopAppNo: any;
    pickupAppointment: any;
    destinationAppointment: any;
    scheduledTimeOrigin: any;
    scheduledTimeDestination: any;
}
