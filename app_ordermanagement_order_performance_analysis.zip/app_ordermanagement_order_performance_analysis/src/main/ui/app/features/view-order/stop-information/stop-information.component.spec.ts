import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StopInformationComponent } from './stop-information.component';

describe('StopInformationComponent', () => {
  let component: StopInformationComponent;
  let fixture: ComponentFixture<StopInformationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StopInformationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StopInformationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
