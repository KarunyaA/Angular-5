import { Injectable } from '@angular/core';
import { Response } from '@angular/http';
import { ActivatedRoute } from '@angular/router';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';
import * as jsonpatch from 'fast-json-patch';

import { JBHGlobals } from 'app/app.service';
import { JbhJsonTransformerService } from 'app/shared/jbh-utils/jbh-json-transformer.service';
import { IOrderDtoModel } from 'app/features/create-orders/orders/order-dto-model';
import { IOrderEntityModel } from 'app/features/create-orders/orders/order-entity-model';
// import { TemplateJsonTransformerService } from 'app/features/create-orders/templates/template-json-transformer.service';
// import { ITemplateEntityModel } from 'app/features/create-orders/templates/template-entity-model';

@Injectable()
export class ViewOrderService {
    public jsonpatch: any;
    public sharingData: BehaviorSubject < IOrderDtoModel[] > ;
    public orderEntity = < IOrderEntityModel > {};
    // public templateEntity = < ITemplateEntityModel > {};
    public data: IOrderDtoModel;

    constructor(public jbhGlobals: JBHGlobals,
        public transformerService: JbhJsonTransformerService,
        // public transformerServiceTemplate: TemplateJsonTransformerService,
        public route: ActivatedRoute) {
        this.jsonpatch = jsonpatch;
        this.sharingData = < BehaviorSubject < IOrderDtoModel[] >> new BehaviorSubject([]);
        this.init();
        this.jbhGlobals.logger.info('Order Service initialized');
    }

    init(): void {
        this.route.queryParams.subscribe(
            (queryParam: any) => {
                if (!this.jbhGlobals.utils.isEmpty(queryParam['id'])) {
                    this.loadOrder(parseInt(queryParam['id'], 10));
                }
            });
    }

    loadOrder(id): void {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getorder + id).subscribe(data => {
            this.saveData(data);
            this.jbhGlobals.logger.info('Order Dto Loaded', data);
        });
    }

    saveData(orderDtoData): void {
        this.data = orderDtoData;
        this.sharingData.next(orderDtoData);
    }

    getData() {
        return this.sharingData.asObservable();
    }

    getDataAsEntity(orderDtoData): IOrderEntityModel {
        return this.transformerService.orderDtoToEntity(orderDtoData, this.orderEntity);
    }

    getDataAsDto(): IOrderDtoModel {
        return this.data;
    }

    saveOrder(orderData): Observable < Response[] > {
        const data = this.getDataAsEntity(orderData);
        console.log('dataAsEntity : ', data);
        const url = this.jbhGlobals.endpoints.order.updateorder + data.orderID;
        this.jbhGlobals.logger.info('Saving  Data', JSON.stringify(data));
        return this.jbhGlobals.apiService.updateData(url, data);
    }

    updateData(url, initialJson, modifiedJson) {
        const saveData = JSON.stringify(this.jsonpatch.compare(initialJson, modifiedJson));
            const params = {
                patchDetails: window.btoa(saveData)
            };
        return this.jbhGlobals.apiService.patchData(url, params);
    }

    // saveTemplate(): void {
    //     const data = this.getDataAsTempalteEntity();
    //     console.log(data);
    //     this.jbhGlobals.commonDataService.setTemplateEntity(data);
    //     console.log(this.jbhGlobals.commonDataService.getTemplateEntity());
    // }
    // getDataAsTempalteEntity() {
    //     console.log('transformer running');
    //     return this.transformerServiceTemplate.orderDtoToEntity(this.data);
    // }

}
