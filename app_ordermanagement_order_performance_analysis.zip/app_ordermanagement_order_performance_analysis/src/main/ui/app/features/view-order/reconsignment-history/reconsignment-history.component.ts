import { Component, OnInit } from '@angular/core';

import { JBHGlobals } from 'app/app.service';

@Component({
    selector: 'app-reconsignment-history',
    templateUrl: './reconsignment-history.component.html',
    styleUrls: ['./reconsignment-history.component.scss']
})
export class ReconsignmentHistoryComponent implements OnInit {
    public rows: any[];
    public totalRecordsCount = 0;
    public offset = 0;
    public limit = 5;
    public valWidth = 1;
    public dataUrl = '';

    constructor(public jbhGlobals: JBHGlobals) { }

    ngOnInit() {
        this.dataUrl = this.jbhGlobals.endpoints.viewOrder.reconHistory;
        this.loadPage(this.offset, this.limit);
    }

    public loadPage(offset, limit): void {
        const params = {
            'page': offset,
            'size': limit
        };
        this.jbhGlobals.apiService.getData(this.dataUrl, params).subscribe(data => {
            this.totalRecordsCount = data.length;
            this.rows = data;
        });
    }

    public onPage(event): void {
        this.loadPage(event.offset, event.limit);
    }

}
