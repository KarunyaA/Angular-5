import { TestBed, inject } from '@angular/core/testing';

import { OrderOverviewService } from './order-overview.service';

describe('OrderOverviewService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [OrderOverviewService]
    });
  });

  it('should be created', inject([OrderOverviewService], (service: OrderOverviewService) => {
    expect(service).toBeTruthy();
  }));
});
