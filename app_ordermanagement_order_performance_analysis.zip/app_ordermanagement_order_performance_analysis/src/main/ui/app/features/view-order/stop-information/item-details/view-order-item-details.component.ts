import {
    Component,
    OnInit,
    Input,
    ViewChild
} from '@angular/core';
import {
    FormBuilder,
    Validators
} from '@angular/forms';
import {
    JBHGlobals
} from 'app/app.service';
import {
    OrderService
} from '../../../create-orders/orders/order.service';
import {
    OrderFormBuilder
} from '../../../create-orders/orders/order-form-builder.service';
import {
    ItemHazmatComponent
} from '../item-details/view-order-item-hazmat.component';
import { TypeaheadMatch } from 'ngx-bootstrap';
import { ViewOrderItemPackageService } from '../services/view-order-item-package.service';
import { ViewOrderItemFreightClassService } from '../services/view-order-item-freight-class.service';
import { ViewOrderUnitOfLengthService } from '../services/view-order-unit-of-length.service';
import { ViewOrderUnitOfWeightService } from '../services/view-order-unit-of-weight.service';
import { ViewOrderItemService } from '../services/view-order-item.service';
import { ViewOrderItemTemperatureService } from '../services/view-order-item-temperature.service';
import { ViewOrderItemCategoryService } from '../services/view-order-item-category.service';
// import {
//     StopHandlingComponent
// } from '../../../create-orders/orders/add-stops/handling-units/stop-handling.component';
//import { StopHandlingComponent } from '../../../create-orders/orders/add-stops/handling-units/stop-handling.component';
import {
    Observable,
    Subscription
} from 'rxjs/Rx';
import { ViewOrderItemModel } from '../models/view-order-item-model';
@Component({
    selector: 'app-item-details',
    templateUrl: './view-order-item-details.component.html',
    styleUrls: ['./view-order-item-details.component.scss'],
    // tslint:disable-next-line:max-line-length
    providers: [ViewOrderItemPackageService, ViewOrderItemFreightClassService,
        ViewOrderUnitOfLengthService, ViewOrderUnitOfWeightService, ViewOrderItemService,
        ViewOrderItemTemperatureService, ViewOrderItemCategoryService]
})
export class ItemDetailsComponent implements OnInit {
    @Input() StophandlingIndex: any;
    @Input() dataIndex: any;
    @Input() ItemsCount: any;
    @Input() stopHandUnitJson: any;
    @Input() stopID: any;

    @ViewChild('itemCharacteristicsTag') itemCharacteristicsTag: any;
    @ViewChild('itemBarCodeNumber') itemBarCodeNumber: any;
    @ViewChild('pop') pop: any;
    @ViewChild('transitem') transitem: any;
    @ViewChild('majorRadio') majorRadio: any;
    @ViewChild('minorRadio') minorRadio: any;
    @ViewChild('saveditem') saveditem: any;
    @ViewChild(ItemHazmatComponent) hazmatComponent: ItemHazmatComponent;
    @ViewChild('propershippingnameTag') propershippingnameTag: any;
    @ViewChild('primaryhazTag') primaryhazTag: any;
    @ViewChild('packaginggrpTag') packaginggrpTag: any;
    @ViewChild('itemDiv') itemDiv: any;
    addItemsDescForm: any;
    itemModel: ViewOrderItemModel;
    sub: Subscription;
    constructor(public formBuilder: FormBuilder, public jbhGlobals: JBHGlobals,
        public orderFormBuilder: OrderFormBuilder, public orderService: OrderService,
        public itemService: ViewOrderItemService, public lengthService: ViewOrderUnitOfLengthService,
        public weightService: ViewOrderUnitOfWeightService, public temperatureService: ViewOrderItemTemperatureService,
        public packageService: ViewOrderItemPackageService, public frieghtService: ViewOrderItemFreightClassService,
        public categoryService: ViewOrderItemCategoryService) {
        this.itemModel = new ViewOrderItemModel();
    }

    ngOnInit() {
        this.addItemsDescForm = this.orderFormBuilder.addItem();
        this.itemModel.emptyObj = this.itemModel.itemDescriptionObj;
        this.loadPackageType();
        this.loaditemWeight();
        this.loadUnitofLength();
        this.loadItemCharacteristics();
        this.loadTemperatureControl();
        this.loadBarCodeType();
        this.loadFreightClass();
        this.loadCategory();
        this.loadItemService('');
        this.loadHandUnitItemData();
        this.loadExtremeLength();
        this.itemModel.debounceValue = this.jbhGlobals.settings.debounce;
        this.itemModel.timer = Observable.timer(2000);
        // this.itemPopup['onHidden'].subscribe((selectedTranDesc) => {
        // this.onPopupOutsideClose();
        // });
        this.itemModel.transItemFlag = (this.itemModel.icsLTLFlag || this.itemModel.dcsFlag) ? false : true;

        /*Transactional typeahead dropdown */
        this.addItemsDescForm['controls']['itemDescription']['valueChanges']
            .debounceTime(this.itemModel.debounceValue)
            .distinctUntilChanged()
            .subscribe((selectedTranDesc) => {
                if (selectedTranDesc.length < 1) {
                    this.itemModel.transSearchFlag = false;
                    this.itemModel.saveSearchFlag = false;
                    this.itemModel.showTransDetailIcon = false;
                    this.itemModel.showSaveDetailIcon = false;
                    this.itemModel.onSelectTransValue = false;
                }
                if (selectedTranDesc !== undefined && selectedTranDesc.length > 2) {
                    if (!this.itemModel.onSelectTransValue) {
                        this.itemModel.typeaheadFlag = false;
                        if (this.transitem.nativeElement.checked === true) {
                            this.loadTransType(selectedTranDesc);
                        } else {
                            this.loadSavedItem(selectedTranDesc);
                        }
                    }
                } else {
                    this.addItemsDescForm['controls']['freightClassCode'].setValue('');
                }
            }, (err: Error) => {
                console.log(err);
            });
        this.addItemsDescForm['controls']['popupItemDescription']['valueChanges']
            .debounceTime(this.itemModel.debounceValue)
            .distinctUntilChanged()
            .subscribe((selectedValue) => {
                if (selectedValue !== undefined && selectedValue.length > 2) {
                    if (this.itemModel.itemPopupHeading === 'Transactional Item') {
                        this.loadTransType(selectedValue);
                    } else {
                        this.loadSavedItem(selectedValue);
                    }
                }
                if (selectedValue.length < 1) {
                    if (this.itemModel.itemPopupHeading === 'Transactional Item') {
                        this.addItemsDescForm['controls']['nmfcNumber'].setValue('');
                    } else {
                        this.dataPopulation(this.addItemsDescForm['controls'], this.itemModel.itemDescriptionObj);
                    }
                }
            }, (err: Error) => {
                console.log(err);
            });
        this.addItemsDescForm['controls']['nmfcNumber']['valueChanges']
            .debounceTime(this.itemModel.debounceValue)
            .distinctUntilChanged()
            .subscribe((selectedValue) => {
                if (selectedValue !== undefined && selectedValue !== '' && selectedValue !== null) {
                    if (selectedValue.length > 2) {
                        if (this.itemModel.itemPopupHeading === 'Transactional Item') {
                            this.loadTransType(selectedValue);
                        }
                    }
                }
            }, (err: Error) => {
                console.log(err);
            });
        this.addItemsDescForm['controls']['itemLength']['valueChanges']
            .debounceTime(this.itemModel.debounceValue)
            .distinctUntilChanged()
            .subscribe((itemlength) => {
                if (itemlength) {
                    this.itemModel.selected[this.dataIndex].itemLength = itemlength;
                    this.calculateVolume();
                    this.calculateDensity();
                    this.checkExtremeLength();
                } else {
                    this.itemModel.selected[this.dataIndex].itemLength = '';
                    this.setMeasurementEmpty();
                }
            }, (err: Error) => {
                console.log(err);
            });
        this.addItemsDescForm['controls']['itemWidth']['valueChanges']
            .debounceTime(this.itemModel.debounceValue)
            .distinctUntilChanged()
            .subscribe((width) => {
                if (width) {
                    this.itemModel.selected[this.dataIndex].itemWidth = width;
                    this.calculateVolume();
                    this.calculateDensity();
                } else {
                    this.itemModel.selected[this.dataIndex].itemWidth = '';
                    this.setMeasurementEmpty();
                }
            }, (err: Error) => {
                console.log(err);
            });
        this.addItemsDescForm['controls']['itemHeight']['valueChanges']
            .debounceTime(this.itemModel.debounceValue)
            .distinctUntilChanged()
            .subscribe((height) => {
                if (height) {
                    this.itemModel.selected[this.dataIndex].itemHeight = height;
                    this.calculateVolume();
                    this.calculateDensity();
                } else {
                    this.itemModel.selected[this.dataIndex].itemHeight = '';
                    this.setMeasurementEmpty();
                }
            }, (err: Error) => {
                console.log(err);
            });
        this.addItemsDescForm['controls']['unitOfLengthMeasurementCode']['valueChanges']
            .debounceTime(this.itemModel.debounceValue)
            .distinctUntilChanged()
            .subscribe((unit) => {
                if (unit.length > 0) {
                    this.itemModel.selected[this.dataIndex].unitOfLengthMeasurementCode = unit;
                    this.calculateVolume();
                    this.calculateDensity();
                    this.checkExtremeLength();
                } else {
                    this.itemModel.selected[this.dataIndex].unitOfLengthMeasurementCode = '';
                    this.setMeasurementEmpty();
                }
            }, (err: Error) => {
                console.log(err);
            });
        this.addItemsDescForm['controls']['itemWeight']['valueChanges']
            .debounceTime(this.itemModel.debounceValue)
            .distinctUntilChanged()
            .subscribe((weight) => {
                if (weight) {
                    this.itemModel.selected[this.dataIndex].itemWeight = weight;
                    if (this.itemModel.itemDimensionFlag) {
                        this.calculateVolume();
                        this.calculateDensity();
                    }
                    this.calculateVolumeConversion();
                } else {
                    this.itemModel.selected[this.dataIndex].itemWeight = '';
                    this.itemModel.selected[this.dataIndex].unitOfWeightMeasurementCode = '';
                    this.addItemsDescForm['controls']['unitOfWeightMeasurementCode'].setValue('');
                    this.setDensityEmpty();
                    this.itemModel.itemDensity = '';
                    this.itemModel.itemDenistyVal = '';
                }
            }, (err: Error) => {
                console.log(err);
            });
        this.addItemsDescForm['controls']['unitOfWeightMeasurementCode']['valueChanges']
            .debounceTime(this.itemModel.debounceValue)
            .distinctUntilChanged()
            .subscribe((weightunit) => {
                if (weightunit.length > 0) {
                    this.itemModel.selected[this.dataIndex].unitOfWeightMeasurementCode = weightunit;
                    if (this.itemModel.itemDimensionFlag) {
                        this.calculateVolume();
                        this.calculateDensity();
                    }
                    this.calculateVolumeConversion();
                } else {
                    this.itemModel.selected[this.dataIndex].unitOfWeightMeasurementCode = '';
                    this.setDensityEmpty();
                    this.itemModel.itemDensity = '';
                }
            }, (err: Error) => {
                console.log(err);
            });
        this.addItemsDescForm['controls']['packagingUnitTypeCode']['valueChanges']
            .debounceTime(this.itemModel.debounceValue)
            .distinctUntilChanged()
            .subscribe((packageUnit) => {
                if (packageUnit.length > 0) {
                    this.itemModel.selected[this.dataIndex].packagingUnitTypeCode = packageUnit;
                } else {
                    this.itemModel.selected[this.dataIndex].packagingUnitTypeCode = '';
                }
            }, (err: Error) => {
                console.log(err);
            });
        this.addItemsDescForm['controls']['packagingUnitTypeQuantity']['valueChanges']
            .debounceTime(this.itemModel.debounceValue)
            .distinctUntilChanged()
            .subscribe((value) => {
                if (value) {
                    this.itemModel.selected[this.dataIndex].packagingUnitTypeQuantity = value;
                } else {
                    this.itemModel.selected[this.dataIndex].packagingUnitTypeQuantity = null;
                }
            }, (err: Error) => {
                console.log(err);
            });
        this.addItemsDescForm['controls']['freightClassCode']['valueChanges']
            .debounceTime(this.itemModel.debounceValue)
            .distinctUntilChanged()
            .subscribe((value) => {
                if (!this.jbhGlobals.utils.isEmpty(value)) {
                    this.itemModel.selected[this.dataIndex].freightClassCode = value;
                } else {
                    this.itemModel.selected[this.dataIndex].freightClassCode = null;
                }
            }, (err: Error) => {
                console.log(err);
            });
        this.addItemsDescForm['controls']['itemTemperatureControlMethodCode']['valueChanges']
            .debounceTime(this.itemModel.debounceValue)
            .distinctUntilChanged()
            .subscribe((value) => {
                if (value.length > 0) {
                    this.itemModel.selected[this.dataIndex].stopItem.itemTemperatureControlMethodCode = value;
                } else {
                    this.itemModel.selected[this.dataIndex].stopItem.itemTemperatureControlMethodCode = '';
                }
            }, (err: Error) => {
                console.log(err);
            });
        this.addItemsDescForm['controls']['itemVolume']['valueChanges']
            .debounceTime(this.itemModel.debounceValue)
            .distinctUntilChanged()
            .subscribe((itemVolume) => {
                if (itemVolume) {
                    // console.log(itemVolume);
                    this.itemModel.selected[this.dataIndex].itemVolume = itemVolume;
                    this.itemModel.volMeasureFlag = true;
                    // this.itemVolumeVal = itemVolume + 'kg/m3';
                    this.itemModel.itemVolumeVal = itemVolume;
                    this.addItemsDescForm['controls']['itemVolume'].setValue(itemVolume);
                    this.addItemsDescForm['controls']['unitOfVolumeMeasurementCode'].setValue('Cubic CM');
                    this.calculateVolumeConversion();

                } else {
                    this.itemModel.itemVolumeVal = '';
                    this.itemModel.itemDenistyVal = '';
                    this.itemModel.volMeasureFlag = false;
                    this.itemModel.selected[this.dataIndex].itemVolume = '';
                    this.itemModel.selected[this.dataIndex].unitOfVolumeMeasurementCode = '';
                    this.addItemsDescForm['controls']['unitOfVolumeMeasurementCode'].setValue('');
                    this.addItemsDescForm['controls']['itemVolume'].setValue('');
                    this.setDensityEmpty();
                }
            }, (err: Error) => {
                console.log(err);
            });
    }
    public loadHandUnitItemData() {
        this.orderService.getData().subscribe(sharedOrderData => {
            this.itemModel.orderData = sharedOrderData;
        });
        this.itemModel.detailsItems = this.stopHandUnitJson;
        this.itemModel.selected = this.itemModel.detailsItems.stopItemDTOs;
        this.itemModel.stopItemID = this.itemModel.selected[this.dataIndex].stopItemID;
        this.itemModel.handlingUnitID = this.itemModel.detailsItems.itemHandlingDetail.itemHandlingDetailID;
        if (this.itemModel.selected[this.dataIndex].stopItem) {
            this.addItemsDescForm.patchValue(this.itemModel.selected[this.dataIndex].stopItem);
            if (!this.itemModel.isDataLoaded) {
                this.onBusinessUnitBased();
            }
            this.itemModel.isDataLoaded = true;
            // this.addItemsDescForm.controls.packagingUnitTypeCode.setValue(this.selected[this.dataIndex].stopItem.packagingUnitTypeCode);
            // this.addItemsDescForm.controls.packagingUnitTypeQuantity
            // .setValue(this.selected[this.dataIndex].stopItem.packagingUnitTypeQuantity);
            // this.addItemsDescForm.controls.itemWeight.setValue(this.selected[this.dataIndex].stopItem.itemWeight);
            // this.addItemsDescForm.controls.unitOfWeightMeasurementCode
            // .setValue(this.selected[this.dataIndex].stopItem.unitOfWeightMeasurementCode);
            // this.addItemsDescForm.controls.itemLength.setValue(this.selected[this.dataIndex].stopItem.itemLength);
            // this.addItemsDescForm.controls.itemWidth.setValue(this.selected[this.dataIndex].stopItem.itemWidth);
            // this.addItemsDescForm.controls.itemHeight.setValue(this.selected[this.dataIndex].stopItem.itemHeight);
            // this.addItemsDescForm.controls.unitOfLengthMeasurementCode
            // .setValue(this.selected[this.dataIndex]['stopItem']['unitOfLengthMeasurementCode']);
            // this.addItemsDescForm.controls.itemDescription.setValue(this.selected[this.dataIndex].stopItem.itemDescription);
            // this.addItemsDescForm.controls.freightClassCode.setValue(this.selected[this.dataIndex].stopItem.freightClassCode);
            // const tempCharcter = (this.selected[this.dataIndex].stopItem.stopItemHazardousMaterialDetails) ? 'Hazmat' : '';
            // this.itemCharacteristicsTag.active.push({'id': 'Stackabl', 'text': 'Stackabl'});
        }
    }
    public loadPackageType() {
        // this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getPackagingUnitType).subscribe(data => {
        //     this.itemModel.packageTypeList = data['_embedded']['packagingUnitTypes'];
        // });
        if (this.jbhGlobals.utils.isEmpty(this.itemModel.packageTypeList)) {
            this.packageService.getData().subscribe(data => {
                this.itemModel.packageTypeList = data;
            });
        }
    }
    public loadBarCodeType() {
        // this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getItemBarCodeType).subscribe(data => {
        //     this.itemModel.itemBarCodeTypeList = data['_embedded']['barcodeTypes'];
        // });
        this.itemService.getBarCode(this.jbhGlobals.endpoints.order.getItemBarCodeType).subscribe(data => {
            this.itemModel.itemBarCodeTypeList = data['_embedded']['barcodeTypes'];
        });
    }
    public loaditemWeight() {
        // this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getUnitOfWeight).subscribe(data => {
        //     this.itemModel.itemWeightList = data['_embedded']['unitOfWeightMeasurements'];
        // });
        if (this.jbhGlobals.utils.isEmpty(this.itemModel.itemWeightList)) {
            this.weightService.getData().subscribe(data => {
                this.itemModel.itemWeightList = data;
            });
        }
    }

    public loadUnitofLength() {
        // this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getUnitofLength).subscribe(data => {
        //     this.itemModel.itemLengthList = data['_embedded']['unitOfLengthMeasurements'];
        // });
        if (this.jbhGlobals.utils.isEmpty(this.itemModel.itemLengthList) ||
            this.jbhGlobals.utils.isArray(this.itemModel.itemLengthList)) {
            this.lengthService.getData().subscribe(data => {
                this.itemModel.itemLengthList = data;
            });
        }
    }

    public loadFreigthClass() {
        // this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getFrieghtClass).subscribe(data => {
        //     this.itemModel.frieghtClassList = data['_embedded']['freightClasses'];
        // });
        if (this.jbhGlobals.utils.isEmpty(this.itemModel.frieghtClassList)) {
            this.frieghtService.getData().subscribe(data => {
                this.itemModel.frieghtClassList = data;
            });
        }
    }

    public loadTransType(value) {
        // this.transTypeaheadList = ['tttt', 'ssss', 'xxxx','tyco'];
        const url = this.jbhGlobals.endpoints.order.getTransTypeahead + '/' + value;
        // const url = this.jbhGlobals.endpoints.order.getTransTypeahead;
        this.itemService.transItemDescription(url).subscribe(data => {
            this.itemModel.transSearchFlag = data.length < 1 ? true : false;
            this.itemModel.transTypeaheadList = data;
            // this.transTypeaheadList = ['t', 's', 'x'];
        });
    }
    public loadSavedItem(value) {
        const url = this.jbhGlobals.endpoints.order.getSavedItem + '/' + value;
        this.itemService.getSavedItemDescription(url).subscribe(data => {
            this.itemModel.saveSearchFlag = data.length < 1 ? true : false;
            this.itemModel.saveItemList = data;
        });
    }

    public loadItemCharacteristics() {
        this.itemService.getItemCharacteristics(this.jbhGlobals.endpoints.order.getItemCharacteristics).subscribe(data => {
            this.itemModel.itemCharacteristicsList = data;
            if (this.itemModel.icsLTLFlag && this.itemModel.itemCharacteristicsList.length > 0) {
                this.itemModel.itemCharacteristicsList.push('Extreme Length');
            }
            const formdata = this.itemModel.selected[this.dataIndex].stopItem;
            // if (this.stopID && this.handlingUnitID && this.stopItemID) {
            if (formdata) {
                this.setItemCharacteristics(formdata);
            }
            // if (this.isCurrViewTemplate && !this.jbhGlobals.utils.isEmpty(formdata)) {
            if (!this.jbhGlobals.utils.isEmpty(formdata)) {
                this.setItemCharacteristics(formdata);
            }
        });
    }
    public loadTemperatureControl() {
        // this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getItemTemperatureControl).subscribe(data => {
        //     this.itemModel.itemTemperatureControlList = data['_embedded']['itemTemperatureControlMethods'];
        // });
        // const urlVal = this.jbhGlobals.endpoints.order.getItemTemperatureControl;
        if (this.jbhGlobals.utils.isEmpty(this.itemModel.itemTemperatureControlList)) {
            this.temperatureService.getData().subscribe(data => {
                this.itemModel.itemTemperatureControlList = data;
            });
        }
    }
    public loadItemService(value) {
        const url = this.jbhGlobals.endpoints.order.getItemServices;
        // const params = {
        //     'modelNumber': 20185260,
        //     'productCategory': 'ALL',
        //     'tradingPartner': 'ABFS'
        // };
        // this.jbhGlobals.apiService.getData(url, params, false).subscribe(data => {
        this.itemService.getLoadItem(url).subscribe(data => {
            this.itemModel.standardServicesList = data['Standard Services'];
            this.itemModel.itemServiceList = data['Additonal Services'];
            for (let i = 0; i < this.itemModel.standardServicesList.length; i++) {
                const itemServiceObj = {
                    stopItemServiceDetailID: '',
                    itemServiceID: this.itemModel.standardServicesList[i].requestServiceTypeId,
                    itemServiceTypeCode: this.itemModel.standardServicesList[i].customerServiceTypeCode,
                    itemServiceDescription: this.itemModel.standardServicesList[i].serviceDescription,
                    itemServiceQuantity: 0
                };
                if (this.itemModel.selected[this.dataIndex].stopItem !== undefined) {
                    this.itemModel.selected[this.dataIndex].stopItem.stopItemServiceDetails.push(itemServiceObj);
                }
            }
            this.itemModel.standardServiceFlag = false;
        });
    }

    public onClickOfSerailNumber(event) {
        this.itemModel.serialNumberFlag = true;
    }

    public onClickOfBardCode(event) {
        this.loadBarCodeType();
        this.itemModel.barcodeFlag = true;
    }
    public onRequirementServicesTagSelection(event, booleanValue) { }

    public onInstructionsTagSelection(event, booleanValue) { }

    public onItemCharacterTagSelection(event, flag) {
        const itemCharacteristics = event.text;
        switch (itemCharacteristics) {
            case 'Temperature Control':
                this.itemModel.showTemperature = flag;
                if (!flag) {
                    // this.itemData[this.dataIndex].stopItem.itemTemperatureControlMethodCode = '';
                }
                // this.itemForm['controls']['itemTemperatureControlMethodCode'].setValue('');
                break;
            case 'Hazmat':
                this.itemModel.showHazmat = flag;
                if (!flag) {
                    /* empty the hazmat data */
                }
                break;
            //   case 'Freeze Protect':
            //     if (flag) {
            //       this.itemData[this.dataIndex].stopItem.itemProtectionType = 'Freeze';
            //     } else {
            //       this.itemData[this.dataIndex].stopItem.itemProtectionType = null;
            //     }
            //     break;
            //   case 'Stackable':
            //     if (flag) {
            //       this.itemData[this.dataIndex].stopItem.itemStackingType = 'Stackable';
            //     } else {
            //       this.itemData[this.dataIndex].stopItem.itemStackingType = null;
            //     }
            //     break;
            //   case 'Extreme Length':
            //     if (flag) {
            //       this.itemData[this.dataIndex].stopItem.itemLengthType = 'Extreme Length';
            //     } else {
            //       this.itemData[this.dataIndex].stopItem.itemLengthType = null;
            //     }
            //     this.checkExtremeLength();
            //     break;
            default:
                break;
        }
    }

    public onSelectPrefix(arg) { }

    //Functio to add serial number
    public addSerialNumber(event: any, Serialindex: number) {
        const serialNumber = event.target.value;
        if (serialNumber !== '') {
            const serialObj = {
                'barCodeTypeCode': '',
                'stopItemBarCodeNumber': '',
                'stopItemSerialNumber': serialNumber,
                'stopitemSerialNumberDetailID': ''
            };
            // const serialArr = this.itemData[this.dataIndex].stopItem.stopItemSerialNumberDetails;
            this.addItemsDescForm['controls']['serialNumber'].setValue('');
            const serialArr = this.itemModel.selected[Serialindex]['stopItem']['stopItemSerialNumberDetails'];
            if (!this.jbhGlobals.utils.isEmpty(serialNumber)) {
                if (this.jbhGlobals.utils.findIndex(serialArr, serialObj) === -1) {
                    this.itemModel.serialNumberFlag = false;
                    this.itemModel.selected[Serialindex]['stopItem']['stopItemSerialNumberDetails'].push(serialObj);
                    this.itemModel.serialNumberFlag = false;
                } else {
                    this.jbhGlobals.notifications.error('Error', 'The serial number is already added');
                    this.itemModel.serialNumberFlag = true;
                }
            } else {
                this.jbhGlobals.notifications.error('Error', 'The serial number should not be empty');
                this.itemModel.serialNumberFlag = true;
            }

            /* if (this.jbhGlobals.utils.findIndex(serialArr, serialObj) === -1 && this.itemForm['controls']['serialNumber']['valid']) {
              this.itemData[this.dataIndex].stopItem.stopItemSerialNumberDetails.push(serialObj);
              this.itemForm['controls']['serialNumber'].setValue('');
              this.serialNumberFlag = false;
              }
              else if (this.jbhGlobals.utils.findIndex(serialArr, serialObj) !== -1) {
              this.jbhGlobals.notifications.error('Error', 'The serial number is already added');
              this.itemForm['controls']['serialNumber'].setValue('');
              this.serialNumberFlag = true;
            } else if (!this.itemForm['controls']['serialNumber']['valid']) {
              this.itemForm['controls']['serialNumber'].setValue('');
              this.serialNumberFlag = true;
            } */
        }
    }

    // public onTransValueSelected(event) {
    //
    //
    //     const transItemDesc = event.item.itemDescription ? event.item.itemDescription : '';
    //     const transItemNumber = event.item.nmfcNumber ? event.item.nmfcNumber : '';
    //     const freightClass = event.item.nmfcFreightClassification;
    //     if (event.item.itemDescription) {
    //         this.itemModel.showTransDetailIcon = true;
    //         this.itemModel.itemDescriptionNMFC = this.itemModel.itemDescriptionObj;
    //         console.log(this.itemModel.itemDescriptionObj);
    //         console.log(this.itemModel.itemDescriptionNMFC);
    //         this.itemModel.itemDescriptionNMFC['itemDescription'] = transItemDesc;
    //         this.itemModel.itemDescriptionNMFC['nmfcNumber'] = transItemNumber;
    //         this.saveItemDescription(transItemDesc, freightClass, this.itemModel.itemDescriptionNMFC);
    //     }
    //     this.addItemsDescForm['controls']['itemDescription'].setValue(transItemDesc + ' (' + transItemNumber + ')');
    //     this.addItemsDescForm['controls']['freightClassCode'].setValue(freightClass);
    //     this.itemModel.typeaheadFlag = true;
    //     this.itemModel.onSelectTransValue = true;
    //     this.itemModel.transSearchFlag = false;
    // }
    public onTransValueSelected(event: TypeaheadMatch): void {
        const transItemDesc = event.value ? event.value : '';
        const transItemNumber = event.item.nmfcNumber ? event.item.nmfcNumber : '';
        const freightClass = event.item.nmfcFreightClassification;
        if (event.item.itemDescription) {
            this.itemModel.showTransDetailIcon = true;
            this.itemModel.itemDescriptionNMFC = this.itemModel.itemDescriptionObj;
            this.itemModel.itemDescriptionNMFC['itemDescription'] = transItemDesc;
            this.itemModel.itemDescriptionNMFC['nmfcNumber'] = transItemNumber;
            this.saveItemDescription(transItemDesc, freightClass, this.itemModel.itemDescriptionNMFC);
        }
        this.addItemsDescForm['controls']['itemDescription'].setValue(transItemDesc + ' (' + transItemNumber + ')');
        for (let i = 0; i < this.itemModel.freightClassList.length; i++) {
            const freightClassListId = parseInt(this.itemModel.freightClassList[i].id);
            if (freightClassListId === freightClass) {
                this.addItemsDescForm['controls']['freightClassCode'].setValue
                    ([{ 'id': freightClass, 'text': this.itemModel.freightClassList[i].text }]);
            }
        }
        this.itemModel.typeaheadFlag = true;
        this.itemModel.onSelectTransValue = true;
        this.itemModel.transSearchFlag = false;
        //this.itemFormSaveCall(false);
    }
    public saveItemDescription(transItemDesc, freightClass, itemdesc) {
        for (let i = 0; i < this.itemModel.editItemArray.length; i++) {
            const editObj = itemdesc[this.itemModel.editItemObjArray[i]] ?
                itemdesc[this.itemModel.editItemObjArray[i]] : '';
            this.itemModel.selected[this.dataIndex]['stopItem'][this.itemModel.editItemArray[i]] = editObj;
        }
        this.itemModel.selected[this.dataIndex].stopItem.itemDescription = transItemDesc;
        this.itemModel.selected[this.dataIndex].stopItem.freightClassCode = freightClass;
    }
    public onClickOfAddService(event) {
        this.itemModel.addServiceFlag = true;
    }

    public onItemTypeChange(value) {
        this.itemModel.transItemFlag = !this.itemModel.transItemFlag;
        this.itemModel.saveSearchFlag = false;
    }
    public itemDesNoMatchFound(event: TypeaheadMatch): void {
        this.itemModel.saveSearchFlag = event ? true : false;
    }
    public onSavedItemValueSelected(event: TypeaheadMatch): void {
        this.itemModel.saveSearchFlag = false;
    }
    public onAddNewItemClick(itemPopup, itemType) {
        this.addItemsDescForm['controls']['popupItemDescription'].setValidators([Validators.maxLength(80), Validators.required]);
        this.addItemsDescForm['controls']['itemDescription'].setValidators([Validators.maxLength(80), Validators.required]);
        itemPopup.show();
        this.itemModel.itemPopupButton = 'Add';
        const itemdescobj = {
            'itemMake': '',
            'upc': '',
            'itemManufacturer': '',
            'modelNumber': '',
            'sku': '',
            'supplierSKU': '',
            'itemCategory': '',
            'itemClassification': '',
            'itemDescription': '',
            'nmfcNumber': '',
            'itemPartNumber': ''
        };
        itemdescobj['itemDescription'] = this.addItemsDescForm['controls']['itemDescription'].value;
        if (itemType.name === 'addNewTransItem') {
            this.itemModel.itemPopupHeading = 'Transactional Item';
            this.itemModel.transEditFlag = true;
            this.itemModel.itemDescriptionNMFC = itemdescobj;
        } else {
            this.itemModel.itemPopupHeading = 'Saved Item';
            this.itemModel.saveEditFlag = true;
            this.itemModel.itemDescriptionSaved = itemdescobj;
        }
        //this.dataPopulation(this.itemForm['controls'], itemdescobj);
    }


    public onCloseOfItemPopup(itemPopup) {
        itemPopup.hide();
        this.itemModel.showTransDetailIcon = true;
        // this.showSaveDetailIcon = true;
        // if (this.itemPopupHeading === 'Transactional Item') {
        //   this.transPopCloseFlag = true;
        // } else {
        //   this.savedPopCloseFlag = true;
        // }
    }

    public setItemCharacteristics(itemDataPopulation) {
        this.itemCharacteristicsTag.active = [];
        if (itemDataPopulation.itemLengthType === 'Extreme Length') {
            if (this.jbhGlobals.utils.findIndex(this.itemCharacteristicsTag.active, {
                id: 'Extreme Length',
                text: 'Extreme Length'
            }) === -1) {
                this.itemCharacteristicsTag.active.push({
                    id: 'Extreme Length',
                    text: 'Extreme Length'
                });
            }
        }
        if (itemDataPopulation.itemProtectionType === 'Freeze') {
            if (this.jbhGlobals.utils.findIndex(this.itemCharacteristicsTag.active, {
                id: 'Freeze Protect',
                text: 'Freeze Protect'
            }) === -1) {
                this.itemCharacteristicsTag.active.push({
                    id: 'Freeze Protect',
                    text: 'Freeze Protect'
                });
            }
        }
        if (itemDataPopulation.itemStackingType === 'Stackable') {
            if (this.jbhGlobals.utils.findIndex(this.itemCharacteristicsTag.active, {
                id: 'Stackable',
                text: 'Stackable'
            }) === -1) {
                this.itemCharacteristicsTag.active.push({
                    id: 'Stackable',
                    text: 'Stackable'
                });
            }
        }
        if (itemDataPopulation.itemTemperatureControlMethodCode.length > 0) {
            if (this.jbhGlobals.utils.findIndex(this.itemCharacteristicsTag.active, {
                id: 'Temperature Control',
                text: 'Temperature Control'
            }) === -1) {
                this.itemCharacteristicsTag.active.push({
                    id: 'Temperature Control',
                    text: 'Temperature Control'
                });
                const tempMethod = this.itemModel.selected[this.dataIndex].stopItem.itemTemperatureControlMethodCode;
                this.itemModel.showTemperature = true;
                this.addItemsDescForm['controls']['itemTemperatureControlMethodCode'].setValue(tempMethod);
            }
        }

        if (this.itemModel.selected[this.dataIndex].stopItem.stopItemHazardousMaterialDetails.length > 0) {
            if (this.jbhGlobals.utils.findIndex(this.itemCharacteristicsTag.active, {
                id: 'Hazmat',
                text: 'Hazmat'
            }) === -1) {
                this.itemCharacteristicsTag.active.push({
                    id: 'Hazmat',
                    text: 'Hazmat'
                });
                this.itemModel.showHazmat = true;
                /* Todo setHazmat Values; */
                this.sub = this.itemModel.timer.subscribe(t => this.getHazmatValue());
                this.sub = this.itemModel.timer.subscribe(t => this.addHazmatProper());
                this.sub = this.itemModel.timer.subscribe(t => this.addHazmatClass());
                this.sub = this.itemModel.timer.subscribe(t => this.addHazmatGroupClass());
            }
        }
    }
    public barCodeTransform(items: any[], args: string): any {
        /* filter items array, items which match and return true will be kept, false will be filtered out */
        return items.filter(item => item.barcodeTypeDescription.toLowerCase().indexOf(args.toLowerCase()) !== -1);
    }

    // public onSelectOfItemService(itemdesc, quantity, event?: any) {
    //     let itemServiceObj: any;
    //     if (event) {
    //         this.itemModel.itemServiceCode = (event.item.customerServiceTypeCode) ? event.item.customerServiceTypeCode : '';
    //         this.itemModel.itemServiceDescription = (event.item.serviceDescription) ? event.item.serviceDescription : '';
    //         this.itemModel.serviceId = (event.item.requestServiceTypeId) ? event.item.requestServiceTypeId : '';
    //         this.addItemsDescForm['controls']['itemService'].setValue(this.itemModel.itemServiceCode + ' ' +
    //             this.itemModel.itemServiceDescription);
    //     }
    //     if (itemdesc.value !== '' && quantity.value !== '') {
    //         itemServiceObj = {
    //             stopItemServiceDetailID: '',
    //             itemServiceID: this.itemModel.serviceId,
    //             itemServiceTypeCode: this.itemModel.itemServiceCode,
    //             itemServiceDescription: this.itemModel.itemServiceDescription,
    //             itemServiceQuantity: quantity.value
    //         };
    //         // const serviceArray = this.itemData[this.dataIndex].stopItem.stopItemServiceDetails;
    //         const serviceArray = this.itemModel.selected[this.StophandlingIndex]['stopItem']['stopItemServiceDetails'];

    //         if (this.jbhGlobals.utils.findIndex(serviceArray, itemServiceObj) === -1) {
    //             // this.itemData[this.dataIndex].stopItem.stopItemServiceDetails.push(itemServiceObj);
    //             this.itemModel.selected[this.StophandlingIndex]['stopItem']['stopItemServiceDetails'].push(itemServiceObj);
    //         } else {
    //             this.jbhGlobals.notifications.error('Error', 'The service is already added');
    //         }
    //         this.itemModel.addServiceFlag = false;
    //         itemdesc.value = '';
    //         this.addItemsDescForm['controls']['itemService'].setValue('');
    //         this.addItemsDescForm['controls']['itemServiceQuantity'].setValue('');
    //         quantity.value = '';
    //         this.itemModel.itemServiceCode = '';
    //         this.itemModel.itemServiceDescription = '';
    //     }
    //     this.itemModel.standardServiceFlag = true;
    // }
    public onSelectOfItemService(itemdesc, quantity, event?: any) {
        let itemServiceObj: any;
        if (event) {
            this.itemModel.itemServiceCode = (event.item.customerServiceTypeCode) ? event.item.customerServiceTypeCode : '';
            this.itemModel.itemServiceDescription = (event.item.serviceDescription) ? event.item.serviceDescription : '';
            this.itemModel.serviceId = (event.item.requestServiceTypeId) ? event.item.requestServiceTypeId : '';
            this.addItemsDescForm['controls']['itemService'].setValue(
                this.itemModel.itemServiceCode + ' ' + this.itemModel.itemServiceDescription);
        }
        if (itemdesc.value !== '' && quantity.value !== '') {
            itemServiceObj = {
                stopItemServiceDetailID: '',
                itemServiceID: this.itemModel.serviceId,
                itemServiceTypeCode: this.itemModel.itemServiceCode,
                itemServiceDescription: this.itemModel.itemServiceDescription,
                itemServiceQuantity: quantity.value
            };
            const serviceArray = this.itemModel.selected[this.dataIndex].stopItem.stopItemServiceDetails;
            if (this.jbhGlobals.utils.findIndex(serviceArray, itemServiceObj) === -1) {
                this.itemModel.selected[this.dataIndex].stopItem.stopItemServiceDetails.push(itemServiceObj);
            } else {
                this.jbhGlobals.notifications.error('Error', 'The service is already added');
            }
            this.itemModel.addServiceFlag = false;
            itemdesc.value = '';
            this.addItemsDescForm['controls']['itemService'].setValue('');
            quantity.value = '';
            this.itemModel.itemServiceCode = '';
            this.itemModel.itemServiceDescription = '';
        }
        this.itemModel.standardServiceFlag = true;
    }
    public removeSerialNumber(i: number, sliceIndex: number) {
        this.itemModel.selected[i]['stopItem']['stopItemSerialNumberDetails'].splice(sliceIndex, 1);
    }
    // public removeBarCode(i: number, sliceIndex: number) {
    //     this.itemModel.selected[i]['stopItem']['stopItemBarcodeDetails'].splice(sliceIndex, 1);
    // }
    // public removeItemService(i: number, sliceIndex: number) {
    //     this.itemModel.selected[i]['stopItem']['stopItemServiceDetails'].splice(sliceIndex, 1);
    // }
    public removeItemService(x: number) {
        const serviceArray = this.itemModel.selected[this.dataIndex].stopItem.stopItemServiceDetails;
        serviceArray.splice(x, 1);
    }
    public onDimensionChange(value) {
        if (value === 'itemDimension') {
            this.itemModel.itemDimensionFlag = true;
            this.addItemsDescForm.controls['itemVolume'].setValue('');
            this.itemModel.selected[this.dataIndex].itemVolume = '';
            this.itemModel.selected[this.dataIndex].unitOfVolumeMeasurementCode = '';
            this.setDensityEmpty();
            this.itemModel.validataDimensionFlag = true;
        } else {
            this.itemModel.itemDimensionFlag = false;
            this.addItemsDescForm.controls['itemLength'].setValue('');
            this.addItemsDescForm.controls['itemWidth'].setValue('');
            this.addItemsDescForm.controls['itemHeight'].setValue('');
            this.addItemsDescForm.controls['unitOfLengthMeasurementCode'].setValue('');
            this.itemModel.selected[this.dataIndex].itemLength = '';
            this.itemModel.selected[this.dataIndex].itemWidth = '';
            this.itemModel.selected[this.dataIndex].itemHeight = '';
            this.itemModel.selected[this.dataIndex].unitOfLengthMeasurementCode = '';
            this.setDensityEmpty();
            this.itemModel.validataDimensionFlag = false;
        }
        this.validateDimension(false);
    }
    public setDensityEmpty() {
        this.addItemsDescForm['controls']['unitOfDensityMeasurementCode'].setValue('');
        this.addItemsDescForm['controls']['itemDensity'].setValue('');
        this.itemModel.selected[this.dataIndex].unitOfDensityMeasurementCode = '';
        this.itemModel.selected[this.dataIndex].itemDensity = '';
        this.itemModel.denMeasureFlag = true;
        this.itemModel.volMeasureFlag = true;
    }
    public validateDimension(flag: boolean) {
        const arr = ['itemLength', 'itemWidth', 'itemHeight', 'unitOfLengthMeasurementCode'];
        if (flag) {
            if (this.itemModel.validataDimensionFlag) {
                for (let i = 0; i < arr.length; i++) {
                    this.addItemsDescForm['controls'][arr[i]].setValidators([Validators.required]);
                    this.addItemsDescForm['controls'][arr[i]].updateValueAndValidity();
                }
                this.addItemsDescForm['controls']['itemVolume'].setValidators([]);
                this.addItemsDescForm['controls']['itemVolume'].updateValueAndValidity();
            } else {
                for (let i = 0; i < arr.length; i++) {
                    this.addItemsDescForm['controls'][arr[i]].setValidators([]);
                    this.addItemsDescForm['controls'][arr[i]].updateValueAndValidity();
                }
                this.addItemsDescForm['controls']['itemVolume'].setValidators([Validators.required]);
                this.addItemsDescForm['controls']['itemVolume'].updateValueAndValidity();
            }
        } else {
            for (let i = 0; i < arr.length; i++) {
                this.addItemsDescForm['controls'][arr[i]].setValidators([]);
                this.addItemsDescForm['controls'][arr[i]].updateValueAndValidity();
            }
            this.addItemsDescForm['controls']['itemVolume'].setValidators([]);
            this.addItemsDescForm['controls']['itemVolume'].updateValueAndValidity();
        }
    }
    public calculateVolume() {
        const itemLength = this.addItemsDescForm.value.itemLength;
        const itemWidth = this.addItemsDescForm.value.itemWidth;
        const itemHeigth = this.addItemsDescForm.value.itemHeight;
        const itemUnit = this.addItemsDescForm.value.unitOfLengthMeasurementCode;
        if (itemLength && itemWidth && itemHeigth && !this.jbhGlobals.utils.isEmpty(itemUnit)) {
            const length = this.conversionToInches(itemLength, itemUnit);
            const width = this.conversionToInches(itemWidth, itemUnit);
            const height = this.conversionToInches(itemHeigth, itemUnit);
            const volume = (length * width * height) / (12 * 12 * 12);
            const val = this.validateDimensionAndVolume(volume);
            if (val) {
                this.itemModel.volumeVal = parseFloat(val.toFixed(4));
                this.itemModel.volMeasureFlag = true;
                this.itemModel.denMeasureFlag = true;
                this.addItemsDescForm['controls']['itemVolume'].setValue(parseFloat(volume.toFixed(4)));
                this.addItemsDescForm['controls']['unitOfVolumeMeasurementCode'].setValue('Cubic CM');
                this.itemModel.selected[this.dataIndex].itemVolume = parseFloat(volume.toFixed(4));
                this.itemModel.selected[this.dataIndex].unitOfVolumeMeasurementCode = 'Cubic CM';
            }
        } else {
            this.addItemsDescForm['controls']['itemVolume'].setValue('');
            this.addItemsDescForm['controls']['unitOfVolumeMeasurementCode'].setValue('');
            this.itemModel.selected[this.dataIndex].itemVolume = '';
            this.itemModel.selected[this.dataIndex].unitOfVolumeMeasurementCode = '';
            this.itemModel.volMeasureFlag = false;
            this.itemModel.denMeasureFlag = false;
        }
    }
    public conversionToInches(value, unit) {
        let measurement;
        switch (unit) {
            case 'Centimeter':
                measurement = parseFloat(value) / 2.54;
                break;
            case 'Feet':
                measurement = parseFloat(value) * 12;
                break;
            case 'Kilometers':
                measurement = parseFloat(value) * 39379.96;
                break;
            case 'Meter':
                measurement = parseFloat(value) / 0.0254;
                break;
            case 'Miles':
                measurement = parseFloat(value) * 63360;
                break;
            case 'Inches':
                measurement = parseFloat(value);
                break;
            default:
                break;
        }
        return measurement;
    }
    public validateDimensionAndVolume(value): any {
        const val = this.jbhGlobals.utils.floor(value);
        const valLength = val.toString().length;
        if (!isNaN(value) && valLength < 8) {
            return value;
        } else {
            this.setDimensionandVolumeEmpty();
            this.jbhGlobals.notifications.error('Error', 'Please enter proper value for Dimesion or Volume');
            return null;
        }
    }
    public setDimensionandVolumeEmpty() {
        if (this.itemModel.itemDimensionFlag) {
            this.addItemsDescForm['controls']['itemLength'].setValue('');
            this.addItemsDescForm['controls']['itemWidth'].setValue('');
            this.addItemsDescForm['controls']['itemHeight'].setValue('');
            this.addItemsDescForm['controls']['itemWeight'].setValue('');
            this.addItemsDescForm['controls']['unitOfVolumeMeasurementCode'].setValue('');
            this.addItemsDescForm['controls']['itemVolume'].setValue('');
            this.setDensityEmpty();
        } else {
            this.addItemsDescForm['controls']['itemWeight'].setValue('');
            this.addItemsDescForm['controls']['itemVolume'].setValue('');
            this.addItemsDescForm['controls']['unitOfVolumeMeasurementCode'].setValue('');
            this.setDensityEmpty();
        }
    }
    public calculateDensity() {
        const itemLength = this.addItemsDescForm.value.itemLength;
        const itemWidth = this.addItemsDescForm.value.itemWidth;
        const itemHeigth = this.addItemsDescForm.value.itemHeight;
        const itemUnit = this.addItemsDescForm.value.unitOfLengthMeasurementCode;
        const itemWeight = this.addItemsDescForm.value.itemWeight;
        const itemWeightUnit = this.addItemsDescForm.value.unitOfWeightMeasurementCode;
        if (itemLength && itemWidth && itemHeigth && !this.jbhGlobals.utils.isEmpty(itemUnit) &&
            itemWeight && !this.jbhGlobals.utils.isEmpty(itemWeightUnit)) {
            const length = this.conversionToFeet(itemLength, itemUnit);
            const width = this.conversionToFeet(itemWidth, itemUnit);
            const height = this.conversionToFeet(itemHeigth, itemUnit);
            const weight = this.weightConversion(itemWeight, itemWeightUnit);
            const density = weight / (length * width * height);
            const denVal = this.validateDimensionAndVolume(density);
            if (denVal) {
                // this.itemDensity = density.toFixed(4) + 'kg/m3';
                this.itemModel.itemDensity = density.toFixed(4);
                this.setDensityVal(density.toFixed(4));
            }
        } else {
            this.setDensityEmpty();
            this.itemModel.itemDensity = '';
        }
    }
    public conversionToFeet(value, unit) {
        switch (unit) {
            case 'Centimeter':
                value = parseFloat(value) / 30.48;
                break;
            case 'Inches':
                value = parseFloat(value) / 12;
                break;
            case 'Kilometers':
                value = parseFloat(value) * 3280.8398950131;
                break;
            case 'Meter':
                value = parseFloat(value) / 0.3048;
                break;
            case 'Miles':
                value = parseFloat(value) * 5280;
                break;
            case 'Inches':
                value = parseFloat(value);
                break;
            default:
                break;
        }
        return value;
    }
    public weightConversion(value, unit) {
        let weight;
        switch (unit) {
            case 'Grams':
                weight = parseFloat(value) / 453.59237;
                break;
            case 'Kilogram':
                weight = parseFloat(value) / 0.45359237;
                break;
            case 'MetricTons':
                weight = parseFloat(value) / 0.00045359237;
                break;
            case 'Ounces':
                weight = parseFloat(value) / 16;
                break;
            case 'Tons':
                weight = parseFloat(value) / 0.00045359237;
                break;
            case 'Pounds':
                weight = parseFloat(value);
                break;
            default:
                break;
        }
        return weight;
    }
    public setDensityVal(density) {
        this.addItemsDescForm['controls']['itemDensity'].setValue(parseFloat(density));
        this.addItemsDescForm['controls']['unitOfDensityMeasurementCode'].setValue('GM/CC');
        this.itemModel.selected[this.dataIndex].itemDensity = parseFloat(density);
        this.itemModel.selected[this.dataIndex].unitOfDensityMeasurementCode = 'GM/CC';
    }
    public checkExtremeLength() {
        const length = this.addItemsDescForm.value.itemLength;
        const lengthUnit = this.addItemsDescForm.value.unitOfLengthMeasurementCode;
        const extremeVal = this.itemModel.selected[this.dataIndex].itemLengthType;
        if (this.itemModel.icsLTLFlag && length && !this.jbhGlobals.utils.isEmpty(lengthUnit)) {
            const itemLength = this.conversionToInches(length, lengthUnit);
            if (this.jbhGlobals.utils.isEmpty(extremeVal) && itemLength > parseFloat(this.itemModel.extremeLength)) {
                this.jbhGlobals.notifications.alert('Warning', 'Length has exceeded 14inch');
                this.itemModel.selected[this.dataIndex].itemLengthType = 'Extreme Length';
                if (this.itemCharacteristicsTag.active.indexOf({
                    id: 'Extreme Length',
                    text: 'Extreme Length'
                }) === -1) {
                    this.itemCharacteristicsTag.active.push({
                        id: 'Extreme Length',
                        text: 'Extreme Length'
                    });
                }
                this.itemModel.validataDimensionFlag = true;
                this.validateDimension(true);
            } else if (!this.jbhGlobals.utils.isEmpty(extremeVal)) {
                this.itemModel.validataDimensionFlag = false;
                this.validateDimension(false);
            }
            if (itemLength > 10.8 && itemLength < parseFloat(this.itemModel.extremeLength)) {
                this.jbhGlobals.notifications.alert('Warning', 'Length has exceeded 10.8 Inches');
            }
        }
    }
    public setMeasurementEmpty() {
        this.addItemsDescForm['controls']['itemVolume'].setValue('');
        this.addItemsDescForm['controls']['itemDensity'].setValue('');
        this.itemModel.itemDensity = '';
        this.itemModel.volumeVal = '';
        this.itemModel.volMeasureFlag = false;

        this.itemModel.denMeasureFlag = false;
    }
    public calculateVolumeConversion() {
        const volume = this.addItemsDescForm.value.itemVolume;
        const weight = this.addItemsDescForm.value.itemWeight;
        const weightUnit = this.addItemsDescForm.value.unitOfWeightMeasurementCode;
        if (volume && weight && !this.jbhGlobals.utils.isEmpty(weightUnit)) {
            const weightConv = this.weightConversion(weight, weightUnit);
            const density = weightConv / volume * (12 * 12 * 12);
            const denVal = this.validateDimensionAndVolume(density);
            if (denVal) {
                //this.itemDenistyVal = density.toFixed(4) + 'kg/m3';
                this.itemModel.itemDenistyVal = density.toFixed(4);
                this.setDensityVal(denVal.toFixed(4));
            }
        } else {
            this.itemModel.itemDenistyVal = '';
            this.setDensityEmpty();
        }
    }
    // public dataPopulation(form, itemDesc) {
    //
    //
    //     form['popupItemDescription'].setValue(itemDesc['itemDescription'] ? itemDesc['itemDescription'] : '');
    //     const len = this.itemModel.editItemArray.length;
    //     for (let i = 0; i < len; i++) {
    //         const editArr = itemDesc[this.itemModel.editItemObjArray[i]] ? itemDesc[this.itemModel.editItemObjArray[i]] : '';
    //         form[this.itemModel.editItemArray[i]].setValue(editArr);
    //     }
    //     if (itemDesc['itemClassification'] === 'MAJOR') {
    //         this.majorRadio.nativeElement.checked = true;
    //     }
    //     if (itemDesc['itemClassification'] === 'MINOR') {
    //         this.minorRadio.nativeElement.checked = true;
    //     }
    //     if (itemDesc['itemClassification'] === '') {
    //         this.majorRadio.nativeElement.checked = false;
    //         this.minorRadio.nativeElement.checked = false;
    //     }
    // }
    public onEditItemClick(itemPopup, transItem) {
        this.pop.hide();
        itemPopup.show();
        this.itemModel.popupFlag = true;
        this.itemModel.itemPopupButton = 'Save';
        this.addItemsDescForm['controls']['popupItemDescription'].setValidators([Validators.required]);
        this.addItemsDescForm['controls']['popupItemDescription'].updateValueAndValidity();
        if (transItem.name === 'editTransItem') {
            this.itemModel.itemPopupHeading = 'Transactional Item';
            this.itemModel.transEditFlag = true;
            this.itemModel.transPopCloseFlag = false;
            this.itemModel.transSearchFlag = false;
            this.dataPopulation(this.addItemsDescForm['controls'], this.itemModel.itemDescriptionNMFC);
        } else {
            this.itemModel.itemPopupHeading = 'Saved Item';
            this.itemModel.transTypeaheadList = this.itemModel.saveItemList;
            this.itemModel.saveEditFlag = true;
            this.itemModel.savedPopCloseFlag = false;
            this.itemModel.saveSearchFlag = false;
            this.dataPopulation(this.addItemsDescForm['controls'], this.itemModel.itemDescriptionSaved);
        }
    }

    public dataPopulation(form, itemDesc) {
        form['popupItemDescription'].setValue(itemDesc['itemDescription'] ? itemDesc['itemDescription'] : '');
        const len = this.itemModel.editItemArray.length;
        for (let i = 0; i < len; i++) {
            const editArr = itemDesc[this.itemModel.editItemObjArray[i]] ? itemDesc[this.itemModel.editItemObjArray[i]] : '';
            form[this.itemModel.editItemArray[i]].setValue(editArr);
        }
        if (itemDesc['itemClassification'] === 'MAJOR') {
            this.majorRadio.nativeElement.checked = true;
        }
        if (itemDesc['itemClassification'] === 'MINOR') {
            this.minorRadio.nativeElement.checked = true;
        }
        if (itemDesc['itemClassification'] === '') {
            this.majorRadio.nativeElement.checked = false;
            this.minorRadio.nativeElement.checked = false;
        }
    }
    public loadExtremeLength() {
        const params = {
            'ParameterName': 'Extreme Length'
        };
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getExtremLength, params).subscribe(data => {
            this.itemModel.extremeLength = data['parameterValue'];
            if (this.itemModel.icsLTLFlag) {
                this.checkExtremeLength();
            }
        });
    }
    public getHazmatValue() {
        this.itemModel.hazmatData = this.itemModel.selected[this.dataIndex].stopItem.stopItemHazardousMaterialDetails[0];
        this.hazmatComponent.itemHazmatForm['patchValue'](this.itemModel.hazmatData);
    }
    public onBusinessUnitBased() {
        switch (this.itemModel.orderData.financeBusinessUnitCode) {
            case 'DCS':
                this.onServiceOfferingBased();
                break;
            case 'ICS':
                this.onServiceOfferingBased();
                break;
            default:
                break;
        }
        this.disableSavedItem();
    }

    public onServiceOfferingBased() {
        console.log(this.itemModel.orderData.serviceOfferingCode);
        switch (this.itemModel.orderData.serviceOfferingCode) {
            case 'FinalMile':
                this.itemModel.dcsFlag = true;
                if (this.itemModel.orderData.orderTypeCode === 'Standard') {
                    this.itemModel.modelNumberFlag = true;
                }
                if (this.itemModel.orderData.orderTypeCode === 'Standard' || this.itemModel.orderData.orderTypeCode === 'Return') {
                    this.addItemsDescForm['controls']['itemModelNumber'].setValidators([Validators.required]);
                    this.addItemsDescForm['controls']['itemModelNumber'].updateValueAndValidity();
                    this.addItemsDescForm['controls']['itemweight'].setValidators([Validators.required]);
                    this.addItemsDescForm['controls']['itemweight'].updateValueAndValidity();
                } else {
                    this.addItemsDescForm['controls']['itemModelNumber'].setValidators([]);
                    this.addItemsDescForm['controls']['itemModelNumber'].updateValueAndValidity();
                    this.addItemsDescForm['controls']['itemweight'].setValidators([]);
                    this.addItemsDescForm['controls']['itemweight'].updateValueAndValidity();
                }
                break;
            case 'LTL':
                if (this.itemModel.orderData.orderSubTypeCode !== 'CON') {
                    this.itemModel.icsLTLDirFlag = true;
                }
                this.itemModel.icsLTLFlag = true;
                this.mandateCheck();
                break;
            case 'Flatbed':
                this.itemModel.flatbedFlag = true;
                break;
            case 'Refrigerated':
                this.mandateCheck();
                break;
            default:
                break;
        }
        this.disableSavedItem();
    }
    public mandateCheck() {
        if (this.itemModel.orderData.orderRefrigeratedIndicator === 'Y') {
            this.addItemsDescForm['controls']['freightClassCode'].setValidators([]);
            this.addItemsDescForm['controls']['freightClassCode'].updateValueAndValidity();
            this.addItemsDescForm['controls']['itemWeight'].setValidators([Validators.required]);
            this.addItemsDescForm['controls']['itemWeight'].updateValueAndValidity();
        } else {
            this.addItemsDescForm['controls']['freightClassCode'].setValidators([Validators.required]);
            this.addItemsDescForm['controls']['freightClassCode'].updateValueAndValidity();
            this.addItemsDescForm['controls']['itemWeight'].setValidators([Validators.required]);
            this.addItemsDescForm['controls']['itemWeight'].updateValueAndValidity();
        }
    }
    public disableSavedItem() {
        if (this.itemModel.dcsFlag || this.itemModel.icsLTLFlag) {
            this.saveditem.nativeElement.disabled = false;
        } else {
            this.saveditem.nativeElement.disabled = true;
        }
    }

    public onEditClick(popup) {
        let itemDescObj = {};
        let validFlag = true;
        if (this.itemModel.transEditFlag) {
            itemDescObj = this.itemModel.itemDescriptionNMFC;
            this.itemModel.transSearchFlag = false;
        } else {
            itemDescObj = this.itemModel.itemDescriptionSaved;
            this.itemModel.saveSearchFlag = false;
        }
        this.addItemsDescForm['controls']['itemDescription'].setValue(this.addItemsDescForm['controls']['popupItemDescription'].value);
        if (this.itemModel.popUpItemDescriptionNMFC) {
            this.addItemsDescForm['controls']['freightClassCode'].setValue([{
                'id': this.itemModel.popUpItemDescriptionNMFC.freightClass,
                'text': this.itemModel.popUpItemDescriptionNMFC.freightClass
            }]);
        }
        itemDescObj['itemDescription'] = this.addItemsDescForm['controls']['itemDescription'].value ?
            this.addItemsDescForm['controls']['itemDescription'].value : '';
        if (this.majorRadio.nativeElement.checked === true) {
            this.addItemsDescForm['controls']['itemClassificationCode'].setValue('MAJOR');
        }
        if (this.minorRadio.nativeElement.checked === true) {
            this.addItemsDescForm['controls']['itemClassificationCode'].setValue('MINOR');
        }
        for (let i = 0; i < this.itemModel.editItemObjArray.length; i++) {
            if (this.addItemsDescForm['controls'][this.itemModel.editItemArray[i]].valid) {
                const editArr = this.addItemsDescForm['controls'][this.itemModel.editItemArray[i]].value ?
                    this.addItemsDescForm['controls'][this.itemModel.editItemArray[i]].value : '';
                itemDescObj[this.itemModel.editItemObjArray[i]] = editArr;
            } else {
                validFlag = false;
            }
        }
        if (this.itemModel.transEditFlag) {
            this.itemModel.itemDescriptionNMFC = itemDescObj;
            this.itemModel.showTransDetailIcon = true;
        } else {
            this.itemModel.itemDescriptionSaved = itemDescObj;
            this.itemModel.showSaveDetailIcon = true;
        }
        const itemDesc = this.jbhGlobals.utils.split(this.addItemsDescForm['controls']['itemDescription'].value.toString(), '(')[0];
        if (validFlag && this.addItemsDescForm['controls']['itemDescription'].valid) {
            this.saveItemDescription(itemDesc, this.addItemsDescForm['controls']['freightClassCode'].value, itemDescObj);
            this.itemModel.popupFlag = false;
            this.itemModel.onSelectTransValue = true;
            this.itemDiv.nativeElement.focus();
            popup.hide();
            this.addItemsDescForm['controls']['popupItemDescription'].setValidators([]);
            this.addItemsDescForm['controls']['popupItemDescription'].updateValueAndValidity();
        }
        if (itemDescObj['modelNumber'] && itemDescObj['itemManufacturer']) {
            this.findModelNumber(itemDescObj['modelNumber'], itemDescObj['itemManufacturer']);
        }
    }
    public findModelNumber(modelValue, manufacturerValue) {
        const url = this.jbhGlobals.endpoints.order.checkModelNumber;
        const params = {
            'modelNumber': modelValue,
            'manufacturer': manufacturerValue,
            'lob': 'TKLT'
        };
        this.jbhGlobals.apiService.getData(url, params, false).subscribe(data => {
            this.itemModel.newModelNumberFlag = data;
            if (this.itemModel.newModelNumberFlag) {
                this.validateModelNumber();
            }
        });
    }
    public validateModelNumber() {
        if (this.itemModel.newModelNumberFlag) {
            this.addItemsDescForm['controls']['itemManufacturer'].setValidators([Validators.required]);
            this.addItemsDescForm['controls']['itemManufacturer'].updateValueAndValidity();
            this.itemModel.validataDimensionFlag = (this.itemModel.itemDimensionFlag) ? true : false;
            this.validateDimension(true);
        } else {
            this.addItemsDescForm['controls']['itemManufacturer'].setValidators([]);
            this.addItemsDescForm['controls']['itemManufacturer'].updateValueAndValidity();
            this.itemModel.validataDimensionFlag = false;
            this.validateDimension(true);
        }
    }
    public addHazmatProper() {
        // if (this.jbhGlobals.utils.findIndex(this.hazmatComponent.propershippingname.active,
        //       ({ 'id': this.hazmatData['propershippingname'], 'text': this.hazmatData['propershippingname'] } )) === -1) {
        //     this.hazmatComponent.propershippingname.active.push({ 'id': this.hazmatData['propershippingname'],
        //       'text': this.hazmatData['propershippingname'] });
        //     return true;
        //   } else {
        //     return false;
        //   }
    }
    public addHazmatClass() {
        // if (this.jbhGlobals.utils.findIndex(this.hazmatComponent.primaryhazTag.active,
        //       ({ 'id': this.hazmatData['hazmatclasscodes'], 'text': this.hazmatData['hazmatclasscodes'] } )) === -1) {
        //     this.hazmatComponent.primaryhazTag.active.push({ 'id': this.hazmatData['hazmatclasscodes'],
        //       'text': this.hazmatData['hazmatclasscodes'] });
        //     return true;
        //   } else {
        //     return false;
        //   }
    }

    public addHazmatGroupClass() {
        // if (this.jbhGlobals.utils.findIndex(this.ItemHazmatComponent.packaginggrpTag.active,
        //       ({ 'id': this.hazmatData['packaginggroup'], 'text': this.hazmatData['packaginggroup'] } )) === -1) {
        //     this.hazmatComponent.packaginggrpTag.active.push({ 'id': this.hazmatData['packaginggroup'],
        //       'text': this.hazmatData['packaginggroup'] });
        //     return true;
        //   } else {
        //     return false;
        //   }
    }
    public onPopUpItemDescValueSelected(event) { }


    public onBarCodeSelect(barcodeType, qunatity) {
        let itemBarCodeObj: any;
        const itemBarCodeType = this.addItemsDescForm.controls['itemBarCodeType'];
        const barcodeSelectObj = (itemBarCodeType.value !== '') ?
            this.barCodeTransform(this.itemModel.itemBarCodeTypeList, itemBarCodeType.value)[0] : '';
        const itemBarCodeNumber = (this.itemBarCodeNumber.nativeElement.value) ? this.itemBarCodeNumber.nativeElement.value : '';
        if (itemBarCodeType.value !== '' && itemBarCodeNumber !== '' && !this.jbhGlobals.utils.isEmpty(barcodeSelectObj)) {
            console.log(this.itemModel.selected[this.dataIndex].stopbarCode);
            this.itemModel.selected[this.dataIndex].stopbarCode = (this.itemModel.selected[this.dataIndex].stopbarCode) ?
                this.itemModel.selected[this.dataIndex].stopbarCode : [];
            console.log(this.itemModel.selected[this.dataIndex].stopbarCode);
            itemBarCodeObj = {
                stopItemBarcodeDetail: {
                    stopItemBarcodeDetailID: '',
                    barcodeTypeCode: barcodeSelectObj.barcodeTypeCode,
                    stopItemBarcodeNumber: itemBarCodeNumber
                },
                barcodeTypeDescription: barcodeSelectObj.barcodeTypeDescription
            };
            this.itemModel.barcodeFlag = false;
            if (this.jbhGlobals.utils.findIndex(this.itemModel.selected[this.dataIndex].stopbarCode, itemBarCodeObj) === -1) {
                this.itemModel.selected[this.dataIndex].stopbarCode.push(itemBarCodeObj);
                this.itemModel.barCodeDetails.push(itemBarCodeObj.stopItemBarcodeDetail);
                this.itemBarCodeNumber.nativeElement.value = '';
                this.addItemsDescForm.controls['itemBarCodeType'].setValue('');
                this.addItemsDescForm.controls['itemBarCodeNumber'].setValue('');
            } else {
                this.addItemsDescForm.controls['itemBarCodeType'].setValue('');
                this.addItemsDescForm.controls['itemBarCodeNumber'].setValue('');
                this.jbhGlobals.notifications.error('Error', 'The bar code is already added');
            }
            this.itemModel.barcodeFlag = false;
        } else if (itemBarCodeType.value === '' && itemBarCodeNumber === '') {
            this.jbhGlobals.notifications.error('Error', 'Please enter both barcode Type and Quantity');
        }
    }
    public removeBarCode(y: number) {
        const barCodeArray = this.itemModel.selected[this.dataIndex].stopbarCode;
        barCodeArray.splice(y, 1);
        this.itemModel.barCodeDetails.splice(y, 1);
    }
    public loadCategory() {
        if (this.jbhGlobals.utils.isEmpty(this.itemModel.categoryList)) {
            this.categoryService.getData().subscribe(data => {
                this.itemModel.categoryList = data;
                console.log(this.itemModel.categoryList);
            });
        }
    }
    public loadFreightClass() {
        if (this.jbhGlobals.utils.isEmpty(this.itemModel.freightClass)) {
            this.frieghtService.getData().subscribe(data => {
                this.itemModel.freightClass = data;
                this.itemModel.freightClassList = [];
                for (const freightCode of this.itemModel.freightClass) {
                    this.itemModel.freightClassList.push({
                        'id': freightCode.freightClassCode,
                        'text': freightCode.freightClassDescription
                    });
                }
                for (let i = 0; i < this.itemModel.freightClassList.length; i++) {
                    const freightClassListId = this.itemModel.freightClassList[i].id;
                    const frValue = this.itemModel.selected[this.dataIndex].stopItem.freightClassCode;
                    if (frValue === freightClassListId) {
                        this.addItemsDescForm['controls']['freightClassCode'].setValue([{
                            'id': freightClassListId,
                            'text': this.itemModel.freightClassList[i].text
                        }]);
                    }
                }
            });
        }
    }
    public onClickOfBarCode($event) {
        this.loadBarCodeType();
        this.itemModel.barcodeFlag = true;
    }
}
