import { TestBed, inject } from '@angular/core/testing';

import { ViewOrderItemService } from './view-order-item.service';

describe('ViewOrderItemService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ViewOrderItemService]
    });
  });

  it('should be created', inject([ViewOrderItemService], (service: ViewOrderItemService) => {
    expect(service).toBeTruthy();
  }));
});
