export class TonuModel {
    chargeFeeValue: any;
    stopRow: any;
    processTruckModalOrginPickup: string;
    isChargeAmountVisible: boolean;
    getTonuInputData: any;
    ngModtonuChargeOptions: string;
    ngModtonuChangeAppoinment: string;
    ngModTonuChargeAmount: string;
    isAppoinmentTimeVisible: boolean;
    // dateTimeValidationFn: any;
    // startDateValue: any;
    // endDateValue: any;
    // todayTime: any;
    // onTypeValidateFunc: any;


    standardFeeCode: any = '';
    negoRateFeeCode: any = '';
    waiveFeeCode: any = '';
    keepOrderDate: boolean = true;
    defaultbtn: boolean = true;
    keepOrderOpen: boolean = false;
    completeOpen: boolean = false;
    btnprimary: boolean = true;
    readonlyBox: boolean = false;
    startDateFlag: boolean = false;
    endDateFlag: boolean = false;
    dateCompareFlag: boolean = false;
    timeCompareFlag: boolean = false;
    startTimeMinFlag: boolean = false;

    deliveryDate: any;
    pickUpDate: any;
    // currentDate: any = new Date();
    // currentYear: number = this.currentDate.getFullYear();
    // currentMonth: number = this.currentDate.getMonth() + 1;
    // currentDay: number = this.currentDate.getDate() - 1;
}
