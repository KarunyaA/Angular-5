/**
 * Created by jisaum1 on 5/17/2017.
 */
import {Injectable} from '@angular/core';
import {Http} from '@angular/http';
import {Observable} from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
// import {IOrder} from '../../shared/interface/order';


@Injectable()
export class OrderServices {

longitude: number;
  latitude: number;
  constructor(private _http: Http) {

  }

  getOrders(): Observable<any> {
    const orderListString = `{"elements": [
  {
  "loadNumber": null,
  "loadLatitude": null,
  "loadLongitude": null,
  "geographicalDetailDTOs": [
    {
      "stopID": 73,
      "scheduledAppointmentTime": null,
      "latitude": 36.245188,
      "longitude":-94.148398,
      "stopActivitiStatus": null
    },
    {
      "stopID": 74,
      "scheduledAppointmentTime": null,
      "latitude": 36.246777,
      "longitude":-94.142506,
      "stopActivitiStatus": null
    },
    {
      "stopID": 75,
      "scheduledAppointmentTime": null,
     "latitude": 36.244759,
      "longitude":-94.149415,
      "stopActivitiStatus": null
    }
  ]
}


    ]}`;
    return JSON.parse(orderListString);
  }
}
