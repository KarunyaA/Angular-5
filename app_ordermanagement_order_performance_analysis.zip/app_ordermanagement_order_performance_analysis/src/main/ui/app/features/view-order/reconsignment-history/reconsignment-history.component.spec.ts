import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReconsignmentHistoryComponent } from './reconsignment-history.component';

describe('ReconsignmentHistoryComponent', () => {
  let component: ReconsignmentHistoryComponent;
  let fixture: ComponentFixture<ReconsignmentHistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReconsignmentHistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReconsignmentHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
