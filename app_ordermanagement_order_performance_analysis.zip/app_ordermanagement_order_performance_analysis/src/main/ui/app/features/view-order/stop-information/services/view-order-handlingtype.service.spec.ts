import { TestBed, inject } from '@angular/core/testing';

import { ViewOrderHandlingtypeService } from './view-order-handlingtype.service';

describe('ViewOrderHandlingtypeService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ViewOrderHandlingtypeService]
    });
  });

  it('should be created', inject([ViewOrderHandlingtypeService], (service: ViewOrderHandlingtypeService) => {
    expect(service).toBeTruthy();
  }));
});
