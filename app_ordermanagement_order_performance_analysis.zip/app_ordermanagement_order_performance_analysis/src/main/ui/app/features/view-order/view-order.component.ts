import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { IMyOptions } from 'mydatepicker';
import { ValidationService } from 'app/shared/jbh-validation/validation.service';
import { JBHGlobals } from 'app/app.service';
import { OrderService } from 'app/features/create-orders/orders/order.service';
import { OrderOverviewComponent } from './order-overview/order-overview.component';
import { StopInformationComponent } from './stop-information/stop-information.component';
import { ModalDirective } from 'ngx-bootstrap/modal';

@Component({
    selector: 'app-view-order',
    templateUrl: './view-order.component.html',
    styleUrls: ['./view-order.component.scss']
})
export class ViewOrderComponent implements OnInit {

    @ViewChild(OrderOverviewComponent) public orderViewComponent: OrderOverviewComponent;
    @ViewChild(StopInformationComponent) public stopInformationComponent: StopInformationComponent;

    @ViewChild('lgModalRecon') public lgModalRecon: ModalDirective;
    @ViewChild('lgModaltonu') public lgModaltonu: ModalDirective;
    @ViewChild('tonuProcessModal') tonuProcessModal: ModalDirective;
    @ViewChild('btnGotIt') btnGotIt;

    /* reject order */
    @ViewChild('rejectScreen') public rejectScreenLink;
    @ViewChild('rejectClose') public rejectClose;
    /* reject order */
    @ViewChild('reconsignpopup') public reconsignpopup;
    @ViewChild('tonuPopup') public tonuPopup;




    private holdOrder = false;
    public orderData;
    tonuLinkFlag: any;
    tonuBtnSelected: any;
    /* reject order */
    public parentFlag: any;
    reasonCodelists: any;
    rejectReasonArray: any;
    rejectUrl: any;
    orderId: any;
    rejectForm: FormGroup;
    invalidreasonflagReject: boolean;
    rejReason: any;
    reasonCodeVal: any;
    rejectReasonArrayJson: any;
    rejectLinkFlag: any;
    /* reject order */

    public myDatePickerOptions: IMyOptions = {
        todayBtnTxt: 'Today',
        dateFormat: 'mm/dd/yyyy',
        firstDayOfWeek: 'mo',
        showClearDateBtn: false,
        sunHighlight: true,
        height: '34px',
        inline: false,
        // disableUntil: {year: 2016, month: 8, day: 10},
        selectionTxtFontSize: '14px'
    };



    constructor(
        public jbhGlobals: JBHGlobals,
        public orderService: OrderService,
        public formBuilder: FormBuilder,
        public router: Router,
    ) { }


    ngOnInit() {
        this.orderService.init();
        this.invalidreasonflagReject = false;

        /* reject order */
        this.rejectForm = this.formBuilder.group({
            rejectOption: ['', Validators.required],
            rejectComments: new FormControl('',
                Validators.compose([ValidationService.maxLengthValidator, ValidationService.commentValidator]))
        });

        /* reject order */

        this.orderService.getData().subscribe(sharedOrderData => {
            this.orderData = sharedOrderData;
            // console.log(this.orderData);
            this.tonuLinkFlag = (this.orderData.orderStatusCode === 'Accepted') ? true : false;
            this.rejectLinkFlag = (this.orderData.orderStatusCode === 'Pending') ? true : false;
        });

        this.jbhGlobals.commonDataService.getData().subscribe(data => {

        });


    }

    public orderShow() {
        this.holdOrder = !this.holdOrder;
    }


    /*  reject order changes starts */
    rejectScreenShown() {
        this.rejectScreenLink.nativeElement.focus();
        this.setUpKeyboardShortcutsRejectScreen();
        console.log(this.rejectScreenLink.nativeElement.focus());
        this.populateReasoncode();
    }

    populateReasoncode() {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.monitoring.rejectReason).subscribe(data => {
            this.rejectReasonArrayJson = this.jbhGlobals.utils.uniqBy(data['_embedded']['orderStatusEventReasons'],
                'orderStatusEventReasonDescription');
            this.rejectReasonArray = this.jbhGlobals.utils.map(this.rejectReasonArrayJson, 'orderStatusEventReasonDescription');
            this.reasonCodelists = this.rejectReasonArray;
            this.invalidreasonflagReject = false;
        });
    }

    onSelectPrefix(event: Object, selectedDropdown: string) {
        const selectedValue = event['id'];
        const itrReasonCode = this.rejectReasonArrayJson.filter(function(item) {
            return typeof item === 'object' && item['orderStatusEventReasonDescription'].indexOf(selectedValue) > -1;
        });
        this.reasonCodeVal = (itrReasonCode && itrReasonCode.length !== 0) ?
            itrReasonCode[0]['orderStatusEventReasonID'] : '';
        this.invalidreasonflagReject = false;
        console.log(this.reasonCodeVal);
    }

    onTypeValidations(thisObj: string, controlVal: any): void {
        const reasonCodelists = Array.prototype.slice.call(controlVal);
        for (let i = 0; i < reasonCodelists.length; i++) {

            if (reasonCodelists[i] === thisObj) {
                this.invalidreasonflagReject = false;
                break;
            } else {
                this.invalidreasonflagReject = true;
            }
        }
        console.log(thisObj);
    }


    setUpKeyboardShortcutsRejectScreen() {
        this.jbhGlobals.shortkeys.getData().subscribe(data => {
            if (data.keyCode === 'alt+1') {
                this.rejectClose.nativeElement.focus();
            }
        });
    }


    onSelectReason(rejReason) {
        console.log(this.rejReason);
        /*if (this.rejReason !== undefined) {
          console.log(this.rejReason[0]);
        }*/
    }


    rejectClick() {
        const obj = {
            'orderStatusReasonId': this.reasonCodeVal,
            'orderRejectComments': this.rejectForm.controls['rejectComments']['_value']
        };
        const orderId = this.orderData.orderID;
        this.rejectUrl = this.jbhGlobals.endpoints.monitoring.reject.replace('_orderId', orderId);
        this.jbhGlobals.apiService.patchData(this.rejectUrl, obj).subscribe(data => {
            const respVal = data.toString();
            this.jbhGlobals.notifications.alert('Success', '' + respVal + '');
            this.resetRejectForm();
        }, (err: any) => {
            console.log(err);
            this.jbhGlobals.notifications.alert('Failure', '' + err.errorMessage + '');
        });
        setTimeout(() => {
            location.reload();
        }, 2000);
    }

    resetRejectForm() {
        this.rejectForm.reset();
        this.invalidreasonflagReject = false;
    }
    /* reject order changes ends */

    /* reconsignment */
    hideRecon() {
        this.lgModalRecon.hide();
    } /* reconsignment */

    /* TONU */
    hideTonu() {
        this.lgModaltonu.hide();
    }

    processTruckSubModalShown(): void {
        this.setUpKeyboardShortcutsProcesscomplete();
        this.btnGotIt.nativeElement.focus();
        this.tonuBtnSelected = this.tonuPopup.tonuModel['keepOrderOpen'] ? 'active' : 'complete';
        this.tonuPopup.resetTonu();
    }

    processTruckSubModalHidden(): void {
        /* this.tonuPopup.tonuKeepOrderActiveLink.nativeElement.focus();
         this.tonuPopup.setUpKeyboardShortcutsTonuProcess();*/
        console.log('hide');
    }
    setUpKeyboardShortcutsProcesscomplete(): void {
        this.jbhGlobals.shortkeys.getData().subscribe(data => {
            if (data.keyCode === 'alt+1') {
                this.btnGotIt.nativeElement.focus();
            }
        });
    }

    makeCopy() {
        let obj: any;
        const url = this.jbhGlobals.endpoints.order.getorder + 'ordercopy';
        const params = {
            noOfCopies: '1',
            sourceOrderId: this.orderData.orderID,
            copyType: 'COPY_PREVIOUS'
        };
        this.jbhGlobals.apiService.addData(url, params).subscribe(data => {
            if (!this.jbhGlobals.utils.isEmpty(data)) {
                obj = data;
                if (!this.jbhGlobals.utils.isEmpty(obj)) {
                    this.router.navigateByUrl('/createorders/order/create?id=' + obj['0'].orderId);
                }
            }
        });
    }
    /* TONU */
}
