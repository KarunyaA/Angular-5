import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { ValidationService } from 'app/shared/jbh-validation/validation.service';

import { JBHGlobals } from 'app/app.service';
import { ViewOrderComponent } from '../../view-order/view-order.component';

@Component({
  selector: 'app-reconsignment',
  templateUrl: './reconsignment.component.html',
  styleUrls: ['./reconsignment.component.scss']
})
export class ReconsignmentComponent implements OnInit {

  @ViewChild('recondriverTypeahead') public recondriverTypeahead;
  @ViewChild('reconChargeOption') public reconChargeOptionLink;
  @ViewChild('reconReason') public reconReasonLink;

  chargeFeeValue: number;
  reconsigmentForm: FormGroup;
  isChargeAmountVisible: boolean;
  reasonCodelist: any;
  driverStatusList: any[] = [];
  levelList: any[] = [];
  waiveFeeList: any;
  reconLoadValues: any;
  confirmCharges: any;
  chargeOptionsVal: any;
  reconChargeAmount: any;
  chargeAmt: any;
  invalidreasoncodeflag: boolean;
  invalidWaiveFlag: boolean;
  invalidLevelflag: boolean;
  reasonCodelistArray: any[] = [];
  waiveFeeListArray: any[] = [];
  driverStatusListArray: any[] = [];
  levelListArray: any[] = [];
  stopArray: any[] = [];
  ngModreasonCode = '';
  driveRequired: boolean;
  debounceValue: any;
  driverStatus: string;
  manualEntry: boolean = false;
  isChecked: boolean = false;
  ruleCheck: boolean;
  orderOwnerCheck: boolean;
  displayConfirm: boolean;
  disabledWaiveFee: boolean = false;
  disableLevel: boolean = false;
  reasonCodeVal: any;
  waiveCodeVal: any;
  levelCodeVal: any;
  standardFeeCodeRecon = '';
  negoRateFeeCodeRecon = '';
  waiveFeeCodeRecon = '';
  readonlyBox: boolean = false;
  driverDetails: any;
  confirmLaterCode: any;


  constructor(
    public jbhGlobals: JBHGlobals,
    public formBuilder: FormBuilder,
    public viewOrderComponent: ViewOrderComponent
  ) {

    this.reconsigmentForm = this.formBuilder.group({
      driverStatus: ['', Validators.required],
      reconChargeOptions: [{ value: '', disabled: false }, Validators.required],
      reconChargeAmount: [{ value: '', disabled: false }, Validators.compose([Validators.required, ValidationService.rateValidator])],
      /* reasonCode: new FormControl('', [Validators.required, this.onTypeValidateFunc]),*/
      reasonCode: ['', Validators.required],
      waiveFee: [{ value: '', disabled: false }],
      level: [{ value: '', disabled: false }],
      confirmCharges: [''],
      reconComments: ['', Validators.maxLength(250)]
    });
  }


  ngOnInit() {

    this.debounceValue = this.jbhGlobals.settings.debounce;
    this.reasonCodelistArray = [];
    this.standardFeeCodeRecon = 'RatePerCon';
    this.negoRateFeeCodeRecon = 'UseNegoRt';
    this.waiveFeeCodeRecon = 'WaivRecFee';
    this.confirmLaterCode = 'ConfChgL';
    this.ngModreasonCode = '';
    this.chargeFeeValue = 0;
    this.invalidreasoncodeflag = false;
    this.invalidWaiveFlag = false;
    this.invalidLevelflag = false;

    this.isChargeAmountVisible = true;
    this.driveRequired = false;
    this.manualEntry = true;

    this.reconsigmentForm['controls']['driverStatus']['valueChanges']
      .debounceTime(this.debounceValue)
      .distinctUntilChanged()
      .subscribe((value) => {
        if (value && value.length > 3) {
          this.populateDriverStatus(value);
          console.log('test');
        }
      },
      (err: Error) => {
        console.log(err);
      });

    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.viewOrder.getChargeCodeRecon, {}, true)
      .subscribe(data => {
        if (data !== undefined && data['_embedded'] && data['_embedded']['acceptedOrderModificationFeeActionTypes']) {

          const dataArrayRecon = data['_embedded']['acceptedOrderModificationFeeActionTypes'];
          const itrLength = dataArrayRecon.length;
          const jsonObj = {
            'Confirm charges later': 'confirmCharges',
            'Rate As Per Contract': 'standardFeeCode',
            'Use Negotiated Rate': 'negoRateFeeCode',
            'Waive Off Reconsignment Fee': 'waiveFeeCode'
          };
          for (let idx = 0; idx < itrLength; idx++) {
            const codeValueRecon = dataArrayRecon[idx];
            const jsonValueRecon = jsonObj[codeValueRecon['acceptedOrderModificationFeeActionTypeDescription']];
            if (jsonValueRecon !== undefined) {
              this[jsonValueRecon] = codeValueRecon['acceptedOrderModificationFeeActionTypeCode'];
            }
          }
        }
      });

  }

  reconshortcutkeys(): void {
    this.jbhGlobals.shortkeys.getData().subscribe(data => {
      if (data.keyCode === 'alt+3') {
        this.reconReasonLink.nativeElement.focus();
      } else if (data.keyCode === 'alt+2') {
        this.reconChargeOptionLink.nativeElement.focus();
      } else if (data.keyCode === 'alt+1') {
        this.recondriverTypeahead.nativeElement.focus();
      }

    });
  }

  showReconsignment(): void {
    this.loadReconPopup();
    this.populateReasonCode();
    this.populateWaiveFee();

    this.reconshortcutkeys();
    if (this.reconsigmentForm.contains('driverStatus')) {
      console.log(this.reconsigmentForm['controls']['driverStatus']);

    }
  }

  reconRadioChange(event: any): void {
    this.updateView(event.target.value);
  }

  updateView(radioValue: string): void {
    switch (radioValue) {
      case this.waiveFeeCodeRecon:
        this.isChargeAmountVisible = false;
        this.reconChargeAmount = '';
        this.reconsigmentForm.removeControl('reconChargeAmount');
        this.reconsigmentForm.removeControl('level');
        if (!this.reconsigmentForm.contains('waiveFee')) {
          this.reconsigmentForm.removeControl('reconChargeAmount');
          this.reconsigmentForm.removeControl('level');
          this.reconsigmentForm.addControl('waiveFee',
            new FormControl('', Validators.compose([Validators.required])));
        }
        break;
      case this.negoRateFeeCodeRecon:
      case this.standardFeeCodeRecon:
        this.isChargeAmountVisible = true;
        if (this.reconsigmentForm.contains('waiveFee')) {
          this.reconsigmentForm.controls['waiveFee'].setValue([]);
          this.reconsigmentForm.removeControl('waiveFee');
        }
        if (!this.reconsigmentForm.contains('reconChargeAmount')) {
          this.reconsigmentForm.removeControl('waiveFee');
          this.reconsigmentForm.addControl('reconChargeAmount',
            new FormControl('', Validators.compose([Validators.required, ValidationService.rateValidator])));
        }
        if (!this.reconsigmentForm.contains('level')) {
          this.reconsigmentForm.removeControl('waiveFee');
          this.reconsigmentForm.addControl('level',
            new FormControl('', Validators.compose([Validators.required])));
        }
        if (radioValue === this.standardFeeCodeRecon) {
          this.readonlyBox = true;
          //this.reconsigmentForm.controls['reconChargeAmount'].setValue(this.chargeAmt);
          this.reconChargeAmount = this.chargeAmt;
          this.reconsigmentForm.get('reconChargeAmount').disable();
        } else {
          this.readonlyBox = false;
          //this.reconsigmentForm.controls['reconChargeAmount'].setValue('');
          this.reconChargeAmount = '';
          this.reconsigmentForm.get('reconChargeAmount').enable();
        }
        break;
      default:
        break;
    }
  }

  reconCancel() {
    this.reconsigmentForm.reset();
    this.invalidreasoncodeflag = false;
    this.invalidWaiveFlag = false;
    this.driveRequired = false;
    this.viewOrderComponent.hideRecon();
    this.reconsigmentForm.addControl('reconChargeAmount',
      new FormControl(''));
    this.reconsigmentForm.addControl('waiveFee',
      new FormControl(''));
    this.reconsigmentForm.addControl('level',
      new FormControl(''));
    this.reconsigmentForm.get('reconChargeAmount').enable();
    this.reconsigmentForm.get('waiveFee').enable();
    this.reconsigmentForm.get('reconChargeOptions').enable();
    this.reconsigmentForm.get('level').enable();
    this.disabledWaiveFee = false;
    this.disableLevel = false;
  }

  loadReconPopup() {
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.viewOrder.loadReconData).subscribe(data => {
      this.reconLoadValues = data;
      this.populateLoadValues(this.reconLoadValues);
      this.enableDriverTextbox(this.reconLoadValues);
      this.setConfirmcharges(this.reconLoadValues);
      this.populateLevel(this.reconLoadValues);
    });
    this.getDriverDetails();
  }



  enableDriverTextbox(loadData) {
    const state = loadData.driverCurrentLocationStateCode;
    const city = loadData.driverCurrentLocationCityName;
    if (!state && !city) {
      this.manualEntry = true;
      this.reconsigmentForm.addControl('driverStatus',
        new FormControl('', Validators.compose([Validators.required])));
      this.recondriverTypeahead.nativeElement.focus();



    } else {
      this.manualEntry = false;
      this.reconsigmentForm.removeControl('driverStatus');
    }
  }

  setConfirmcharges(loadData) {
    this.ruleCheck = loadData.ruleCheck;
    this.orderOwnerCheck = loadData.orderOwnerCheck;
    if (this.ruleCheck === true && this.orderOwnerCheck === true) {
      this.displayConfirm = true;
    } else {
      this.displayConfirm = false;
    }
  }

  populateLoadValues(loadData) {
    this.chargeOptionsVal = '';
    this.chargeOptionsVal = this.standardFeeCodeRecon;

    if (loadData['standardFee'] !== null && loadData['standardFee'] !== undefined) {
      this.addAmtControl();
      this.chargeAmt = loadData['standardFee'];
      //this.reconsigmentForm.controls['reconChargeAmount'].setValue(this.chargeAmt);
      this.reconChargeAmount = this.chargeAmt;
      this.chargeOptionsVal = this.standardFeeCodeRecon;
    }/* else if (loadData[this.negoRateFeeCodeRecon] !== null && loadData[this.negoRateFeeCodeRecon] !== undefined) {
      this.addAmtControl();
      this.chargeAmt = loadData[this.negoRateFeeCodeRecon];
      this.chargeOptionsVal = this.negoRateFeeCodeRecon;
      this.reconsigmentForm.controls['reconChargeAmount'].setValue(this.chargeAmt);
      this.reconChargeAmount = '';
    }*/
    this.updateView(this.chargeOptionsVal);
  }

  addAmtControl(): void {
    if (!this.reconsigmentForm.contains('reconChargeAmount')) {
      this.reconsigmentForm.addControl('reconChargeAmount',
        new FormControl('', Validators.compose([Validators.required, ValidationService.rateValidator])));
      this.reconsigmentForm.removeControl('waiveFee');
      this.updateView(this.chargeOptionsVal);
    }
  }


  reconSubmit(reconsigmentForm) {
    //console.log(this.reconsigmentForm.getRawValue());
    const reconValues = {};
    const obj = {};
    reconValues['ruleCheck'] = this.ruleCheck;
    reconValues['orderOwnerCheck'] = this.orderOwnerCheck;
    reconValues['orderReconsignmentID'] = '153';
    reconValues['acceptedOrderModificationID'] = '1';
    reconValues['orderID'] = '2990';
    reconValues['orderReconsignmentReasonCode'] = this.reasonCodeVal;
    reconValues['orderReconsignmentStatusCode'] = 'pending';
    reconValues['driverCurrentLocationStateCode'] = (this.reconsigmentForm.contains('driverStatus')) ?
      this.reconsigmentForm.controls['driverStatus']['_value'].split(',')[1] : '';
    reconValues['driverCurrentLocationCityName'] = (this.reconsigmentForm.contains('driverStatus')) ?
      this.reconsigmentForm.controls['driverStatus']['_value'].split(',')[0] : '';
    reconValues['driverCurrentLocationLongitude'] = -122.231698;
    reconValues['driverCurrentLocationLatitude'] = -122.231698;
    reconValues['orderReconsignmentComment'] = this.reconsigmentForm.controls['reconComments']['_value'];
    reconValues['preApprovalText'] = 'text';
    reconValues['standardFee'] = (this.chargeOptionsVal === this.standardFeeCodeRecon) ? this.chargeAmt : '';
    reconValues['stopNumber'] = (this.reconsigmentForm.contains('level')) ? this.levelCodeVal : '';
    obj['orderReconsignmentFeeID'] = '153';
    obj['orderReconsignmentID'] = '151';
    obj['orderReconsignmentFeeActionTypeCode'] = (this.isChecked) ? this.confirmLaterCode : this.chargeOptionsVal;
    obj['orderReconsignmentFeeActionReasonTypeCode'] = (this.reconsigmentForm.contains('waiveFee')) ?
      this.waiveCodeVal : null;
    obj['orderReconsignmentCustomNegotiatedFeeAmount'] = (this.reconsigmentForm.contains('reconChargeAmount') &&
      (this.chargeOptionsVal === this.negoRateFeeCodeRecon)) ?
      this.reconsigmentForm.controls['reconChargeAmount']['_value'] : this.chargeAmt;
    obj['orderReconsignmentFeeComment'] = 'Fee comments';

    reconValues['orderReconsignmentFeeDTO'] = obj;
    console.log(reconValues);




    this.jbhGlobals.apiService.updateData(this.jbhGlobals.endpoints.viewOrder.submitRecon, reconValues).subscribe(data => {
      console.log(reconsigmentForm);
      const respVal = data;
      this.jbhGlobals.notifications.alert('Success', '' + respVal['response'] + '');
    }, (err: any) => {
      console.log(err);
      this.jbhGlobals.notifications.alert('Failure', '' + err.errorMessage + '');
    });
    this.reconCancel();
  }

  getDriverDetails() {
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.viewOrder.getDriverDetails).subscribe(data => {
      this.driverDetails = data;
      console.log(this.driverDetails);
    });
  }

  populateReasonCode() {
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.viewOrder.getReasonCode).subscribe(data => {
      this.reasonCodelistArray = this.jbhGlobals.utils.uniqBy(data['_embedded']['orderReconsignmentReasons'],
        'orderReconsignmentReasonDescription');
      /*this.reasonCodelistArrayObj = this.jbhGlobals.utils.clone(this.reasonCodelistArray);*/
      const reasonCodelistDes = this.jbhGlobals.utils.map(this.reasonCodelistArray, 'orderReconsignmentReasonDescription');
      this.reasonCodelist = reasonCodelistDes;
    });
  }

  populateWaiveFee() {
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.viewOrder.getWaivelist).subscribe(data => {
      this.waiveFeeListArray = this.jbhGlobals.utils.uniqBy(data['_embedded']['acceptedOrderModificationFeeActionReasonTypes'],
        'acceptedOrderModificationFeeActionReasonTypeDescription');
      const waiveFeeListDes = this.jbhGlobals.utils.map(this.waiveFeeListArray, 'acceptedOrderModificationFeeActionReasonTypeDescription');
      this.waiveFeeList = waiveFeeListDes;

    });
  }

  populateLevel(loadData) {
    //this.levelListArray;
    const objList = [];
    this.stopArray = loadData.stopDetailsDTO;
    //const itrLength = this.stopArray.length;
    //for (let i = 0; i < itrLength; i++) {
    const orderObj = {};
    orderObj['id'] = '0';
    orderObj['text'] = 'Order';
    objList.push(orderObj);
    for (const levelItem of this.stopArray) {
      const obj = {};
      //objList['stopVal'] = 'Stop' + this.stopArray[i]['stopID'] + '(' + this.stopArray[i]['locationCode'] + ')';
      //this.levelListArray.push(objList);
      obj['id'] = levelItem['stopID'];
      obj['text'] = 'Stop' + levelItem['stopID'] + '(' + levelItem['locationCode'] + ')';
      objList.push(obj);
    }
    console.log(objList);
    this.levelList = objList;
    console.log(this.levelList);
  }


  onSelectPrefix(event: Object, selectedDropdown: string): void {
    const selectedValue = event['id'];
    switch (selectedDropdown) {
      case 'reasonCodelist':
        const itrReasonCode = this.reasonCodelistArray.filter(function (item) {
          return typeof item === 'object' && item['orderReconsignmentReasonDescription'].indexOf(selectedValue) > -1;
        });
        this.reasonCodeVal = (itrReasonCode && itrReasonCode.length !== 0) ?
          itrReasonCode[0]['orderReconsignmentReasonCode'] : '';
        this.invalidreasoncodeflag = false;
        console.log(this.reasonCodeVal);
        break;

      case 'waiveFeeList':
        this.invalidWaiveFlag = false;
        const itrWaiveCode = this.waiveFeeListArray.filter(function (item) {
          return typeof item === 'object' && item['acceptedOrderModificationFeeActionReasonTypeDescription'].indexOf(selectedValue) > -1;
        });
        this.waiveCodeVal = (itrWaiveCode && itrWaiveCode.length !== 0) ?
          itrWaiveCode[0]['acceptedOrderModificationFeeActionReasonTypeCode'] : '';

        console.log(this.waiveCodeVal);
        break;

      case 'levelList':
        //.substring(4, 5);
        /*this.invalidWaiveFlag = false;
        const itrLevelCode = this.stopArray.filter(function (item) {
          return typeof item === 'object' && item['stopID'] === (parseInt(searchVal));
        });*/
        this.levelCodeVal = selectedValue;
        this.invalidLevelflag = false;
        console.log(selectedValue);
        break;

      default:
        break;
    }
  }

  onRemovePrefix(value: any): void {
    // console.log(value);
  }

  onTypeValidate(inputVal: string, errorField: string, controlVal: any): void {
    const dropDownArray = Array.prototype.slice.call(controlVal);
    const thisObj = this;
    if (inputVal.length !== 0) {
      thisObj.checkInputValExits({
        'value': inputVal,
        'dropdownArray': dropDownArray,
        'callBackFn': (isValid: boolean) => {
          if (errorField === 'reasonCode') {
            this.invalidreasoncodeflag = isValid;
          } else if (errorField === 'waiveFee') {
            this.invalidWaiveFlag = isValid;
          }
        }
      });
    }
  }

  checkInputValExits(jsonObjArgument): void {
    const value = jsonObjArgument['value'];
    const dropdownArray = jsonObjArgument['dropdownArray'];
    const callBackFn = jsonObjArgument['callBackFn'];
    const iteratedResults = dropdownArray.filter(function (item) {
      return typeof item === 'string' && item.toLowerCase().indexOf(value.toLowerCase()) > -1;
    });
    if (callBackFn !== undefined) {
      callBackFn(iteratedResults.length === 0);
    }
  }

  refreshValue(value: any): void {
    // console.log(value);
  }

  onDataPrefix(value) {

    console.log(value);

  }


  populateDriverStatus(txtBoxValue) {
    const searchParams = {
      '_source': false,
      'query': {
        'nested': {
          'path': 'locations',
          'query': {
            'multi_match': {

              'fields': ['locations.StateName^20', 'locations.CityName^10',
                'locations.AddressLine1', 'locations.AddressLine2',
                'locations.CountryName', 'locations.PostalCode'
              ],

              'query': txtBoxValue,
              'type': 'phrase_prefix'
            }
          },

          'inner_hits': {
            'size': 1,
            '_source': {
              'includes': ['locations.AddressLine1', 'locations.AddressLine2',
                'locations.CityName', 'locations.StateName', 'locations.CountryName', 'locations.PostalCode']
            }
          }
        }
      }
    };



    console.log(searchParams);
    this.jbhGlobals.apiService.addData(this.jbhGlobals.endpoints.viewOrder.getDriverStatus, searchParams).subscribe(data => {
      const driverStatusListArray = [];
      const dataList = data['hits']['hits'];
      const itrLength = dataList.length;
      for (let i = 0; i < itrLength; i++) {
        const objList = {};
        objList['CityName'] = dataList[i].inner_hits.locations.hits.hits[0]._source.locations.CityName;
        objList['CountryName'] = dataList[i].inner_hits.locations.hits.hits[0]._source.locations.StateName;
        driverStatusListArray.push(objList);
      }
      this.driverStatusList = this.jbhGlobals.utils.uniqBy(driverStatusListArray,
        'CityName');
      //this.driverStatusList = driverStatusListArray;
      console.log(this.driverStatusList);
    });



  }

  driveTypeaheadNoResults(e: boolean, typedValue: string, driverList: any): void {
    this.driveRequired = true;
  }

  typeaheadOnSelect(e, typedValue: string, driverList: any): void {
    console.log(e, typedValue, driverList);
    this.driveRequired = false;
    this.driverStatus = e.item.CityName + ',' + e.item.CountryName;
  }

  disableChargeRadio(event) {
    if (event.target.checked) {
      if (!this.reconsigmentForm.contains('confirmCharges')) {
        this.reconsigmentForm.addControl('confirmCharges',
          new FormControl(''));
      }
      this.reconsigmentForm.addControl('reconChargeAmount',
        new FormControl(''));
      this.reconsigmentForm.addControl('waiveFee',
        new FormControl(''));
      this.reconsigmentForm.addControl('level',
        new FormControl(''));
      this.reconsigmentForm.get('reconChargeAmount').disable();
      this.reconsigmentForm.get('waiveFee').disable();
      this.reconsigmentForm.get('reconChargeOptions').disable();
      this.reconsigmentForm.get('level').disable();
      this.disabledWaiveFee = true;
      this.disableLevel = true;
      this.isChecked = true;
    } else {
      /*if (this.reconsigmentForm.contains('confirmCharges')) {
        this.reconsigmentForm.removeControl('confirmCharges');
      }*/
      this.reconsigmentForm.addControl('reconChargeAmount',
        new FormControl(''));
      this.reconsigmentForm.addControl('waiveFee',
        new FormControl(''));
      this.reconsigmentForm.addControl('level',
        new FormControl(''));
      if (this.chargeOptionsVal === this.standardFeeCodeRecon) {
        this.reconsigmentForm.get('reconChargeAmount').enable();
        this.readonlyBox = true;
      } else {
        this.reconsigmentForm.get('reconChargeAmount').enable();
        this.readonlyBox = false;
      }
      this.reconsigmentForm.get('waiveFee').enable();
      this.reconsigmentForm.get('reconChargeOptions').enable();
      this.reconsigmentForm.get('level').enable();
      this.disabledWaiveFee = false;
      this.disableLevel = false;
      this.isChecked = false;
    }
    this.updateView(this.chargeOptionsVal);
    /* if (!this.isChecked) {
         this.reconsigmentForm.removeControl('confirmCharges');
       } else {
         this.reconsigmentForm.addControl('confirmCharges',
         new FormControl(''));
       }*/
  }

  addDecimal() {
    if (!!this.reconChargeAmount) {
      this.reconChargeAmount = parseFloat(this.reconChargeAmount).toFixed(2);
    }
  }


}
