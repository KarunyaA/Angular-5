import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';

import { JBHGlobals } from '../../../app.service';
import { ViewOrderService } from 'app/features/view-order/view-order.service';
import { OrderOverviewService } from './services/order-overview.service';
import { OrderOverview } from './models/order-overview';

@Component({
  selector: 'app-order-overview',
  templateUrl: './order-overview.component.html',
  styleUrls: ['./order-overview.component.scss'],
  providers: [OrderOverviewService]
})

export class OrderOverviewComponent implements OnInit, OnDestroy {

  orderOverview: OrderOverview;
  @ViewChild('originContactList') origintList: any;
  @ViewChild('billToContacts') billToContacts: any;
  @ViewChild('destinationLists') destinationList: any;
  @ViewChild('creatorList') creatorLists: any;
  @ViewChild('ownerList') ownerLists: any;
  subscriptions: Array < Subscription > = [];
  electronicOrder = false;
  loadNumber = false;

  constructor(public jbhGlobals: JBHGlobals,
    public router: Router,
    public viewOrderService: ViewOrderService,
    public orderOverviewService: OrderOverviewService) {
    this.orderOverview = new OrderOverview();
  }

  ngOnInit() {
    if (this.jbhGlobals.utils.isEmpty(this.orderOverview.orderData)) {
      const subsOne = this.viewOrderService.getData().subscribe(
        sharedOrderData => {
          if (!this.jbhGlobals.utils.isEmpty(sharedOrderData)) {
            this.orderOverview.orderData = sharedOrderData;
            this.setOrderOverviewDataStops(this.orderOverview.orderData.orderID);
            if (sharedOrderData['orderEquipmentRequirementDTOs'] &&
              !this.jbhGlobals.utils.isEmpty(sharedOrderData[
                'orderEquipmentRequirementDTOs'][0])) {
              this.orderOverview.orderOverViewEquipment = sharedOrderData[
                'orderEquipmentRequirementDTOs'][0];
              const datas = sharedOrderData[
                'orderEquipmentRequirementDTOs'][0];
              this.orderOverview.indicator = datas[
                'orderEquipmentRequirement'][
                'equipmentTypeRequiredIndicator'
              ];
            }
            if (sharedOrderData['orderBillingDetailDTOs'] &&
              !this.jbhGlobals.utils.isEmpty(sharedOrderData[
                'orderBillingDetailDTOs'][0])) {
              this.orderOverview.billtoaccountprofile = sharedOrderData[
                'orderBillingDetailDTOs'][0]['profileDTO'];
            }
            this.validateElectronicOrder(); // To validate Electronic Order
            this.validateLoadNumber(); // To validate Load Number
          }
          this.subscriptions.push(subsOne);
        });

    }

  }

  validateElectronicOrder() {
    // Electronic Order Check
    if (this.orderOverview.orderData) {
      const electronicOrderChk = this.orderOverview.orderData.createProgramName
        .toString()
        .toLowerCase();
      console.log(electronicOrderChk);
      if (electronicOrderChk === 'electronic') {
        this.electronicOrder = true;
      } else {
        this.electronicOrder = false;
      }
    }
  }
  // Load Number Check
  validateLoadNumber() {
    if (this.orderOverview.orderData) {
      const loadNumberChk = this.orderOverview.orderData.loadNumber;
      console.log(loadNumberChk);
      if (loadNumberChk) {
        this.loadNumber = true;
      } else {
        this.loadNumber = false;
      }
    }
  }
  setOrderOverviewDataStops(orderID) {
    const params = orderID + '/stops';
    const subsTwo = this.orderOverviewService.loadServices(this.jbhGlobals.endpoints
      .order.getstopresequencelistorderoverview +
      params).subscribe(data => {
      if (!this.jbhGlobals.utils.isEmpty(data)) {
        this.orderOverview.orderOverViewListStop = data;
        this.orderOverview.count = data.length;
        if (!this.jbhGlobals.utils.isEmpty(data[0]) &&
          !this.jbhGlobals.utils.isEmpty(data[0]['locationDTO'])) {
          this.orderOverview.originStop = data[0]['locationDTO'];
          this.getAppointmentDetailsOrigin(orderID, data[0]['stop'][
            'stopID'
          ], 'first');
        }
        if (!this.jbhGlobals.utils.isEmpty(data[this.orderOverview.count -
            1]) &&
          !this.jbhGlobals.utils.isEmpty(data[this.orderOverview.count - 1]
            ['locationDTO']) &&
          (this.orderOverview.count - 1 >= 1)) {
          this.orderOverview.destinationStop = data[this.orderOverview.count -
            1]['locationDTO'];
          this.getAppointmentDetailsDestination(orderID, data[this.orderOverview
            .count - 1]['stop']['stopID'], 'last');
        }
      }
      this.subscriptions.push(subsTwo);
    });
  }

  getAppointmentDetailsOrigin(orderID, stopID, pos) {
    const params = orderID + '/stops/';
    let stopAppointmentValue: any;
    let isScheduledApptExist: any;
    const stopUrl = this.jbhGlobals.endpoints.order.getstopresequencelistorderoverview;
    const subsThree = this.orderOverviewService.loadServices(stopUrl + params +
      stopID).subscribe(data => {
      if (!this.jbhGlobals.utils.isEmpty(data)) {
        stopAppointmentValue = data['stop'];
        if (!this.jbhGlobals.utils.isEmpty(stopAppointmentValue.appointment)) {
          isScheduledApptExist = this.jbhGlobals.utils.find(
            stopAppointmentValue.appointment, {
              appointmentTypeCode: 'scheduled'
            });
          if (!this.jbhGlobals.utils.isEmpty(isScheduledApptExist)) {
            const isScheduledAppt = this.jbhGlobals.utils.find(
              isScheduledApptExist.appointmentDateTimeDetails, {
                primaryAppointmentIndicator: 'Y'
              });
            if (!this.jbhGlobals.utils.isEmpty(isScheduledAppt) &&
              !this.jbhGlobals.utils.isEmpty(isScheduledAppt.appointmentStartTimestamp)
            ) {
              this.orderOverview.scheduledTimeOrigin = isScheduledAppt.appointmentStartTimestamp;
            }
          }
        }
      }
      this.subscriptions.push(subsThree);

    });
  }

  getAppointmentDetailsDestination(orderID, stopID, pos) {
    const params = orderID + '/stops/';
    let isScheduledApptExist: any;
    const stopUrl = this.jbhGlobals.endpoints.order.getstopresequencelistorderoverview;
    const subsFour = this.orderOverviewService.loadServices(stopUrl + params +
      stopID).subscribe(data => {
      if (!this.jbhGlobals.utils.isEmpty(data)) {
        if (data['stop'] &&
          !this.jbhGlobals.utils.isEmpty(data['stop'].appointment)) {
          isScheduledApptExist = this.jbhGlobals.utils.find(data['stop'].appointment, {
            appointmentTypeCode: 'scheduled'
          });
          if (!this.jbhGlobals.utils.isEmpty(isScheduledApptExist)) {
            const isScheduledAppt = this.jbhGlobals.utils.find(
              isScheduledApptExist.appointmentDateTimeDetails, {
                primaryAppointmentIndicator: 'Y'
              });
            if (!this.jbhGlobals.utils.isEmpty(isScheduledAppt) &&
              !this.jbhGlobals.utils.isEmpty(isScheduledAppt.appointmentEndTimestamp)
            ) {
              this.orderOverview.scheduledTimeDestination = isScheduledAppt
                .appointmentEndTimestamp;
            }
          }
        }
      }
      this.subscriptions.push(subsFour);
    });
  }

  billToDetails(popover) {
    setTimeout(() => {
        const popOVerList = this.billToContacts['nativeElement'];
        popOVerList.setAttribute('tabindex', '3');
        popOVerList.focus();
        popOVerList.addEventListener('blur', function(event) {
          popover.hide();
        });
      },
      500);
  }

  originPopover(popover) {
    setTimeout(() => {
        const popOVerList = this.origintList['nativeElement'];
        popOVerList.setAttribute('tabindex', '4');
        popOVerList.focus();
        popOVerList.addEventListener('blur', function(event) {
          popover.hide();
        });
      },
      500);
  }

  destnationPopover(popover) {
    setTimeout(() => {
        const popOVerList = this.destinationList['nativeElement'];
        popOVerList.setAttribute('tabindex', '5');
        popOVerList.focus();
        popOVerList.addEventListener('blur', function(event) {
          popover.hide();
        });
      },
      500);
  }

  orderCreatorPop(popover) {
    setTimeout(() => {
        const popOVerList = this.creatorLists['nativeElement'];
        popOVerList.setAttribute('tabindex', '7');
        popOVerList.focus();
        popOVerList.addEventListener('blur', function(event) {
          popover.hide();
        });
      },
      500);
  }

  orderOwnerPop(popover) {
    setTimeout(() => {
        const popOVerList = this.ownerLists['nativeElement'];
        popOVerList.setAttribute('tabindex', '6');
        popOVerList.focus();
        popOVerList.addEventListener('blur', function(event) {
          popover.hide();
        });
      },
      500);
  }

  redirectToURL(pagename: string): void {
    if (pagename) {
      this.router.navigateByUrl('/' + pagename + '?id=' + this.orderOverview.orderData
        .orderID);
    }
  }

  ngOnDestroy() {
    for (const subs of this.subscriptions) {
      // subs.unsubscribe();
    }
  }
}
