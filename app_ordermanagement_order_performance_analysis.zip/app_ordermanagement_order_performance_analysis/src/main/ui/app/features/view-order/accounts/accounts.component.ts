import { Component, OnInit} from '@angular/core';

import { JBHGlobals } from '../../../app.service';
import { ViewOrderService } from '../../../features/view-order/view-order.service';
import { AccountsService } from './services/accounts.service';
import * as jsonpatch from 'fast-json-patch';

@Component({
  selector: 'app-accounts',
  templateUrl: './accounts.component.html',
  styleUrls: ['./accounts.component.scss'],
  providers: [AccountsService]
})

export class AccountsComponent implements OnInit {
    rows: any = [];
    temp: any[];
    showViewDetailGrid = true;
    showViewDetail = false;
    accountInfo;
    billToDataAddress: any = [];
    accountRole: any;
    accountContact: any;
    orderBilling: any;
    orderBillingDetail: any;
    arrRole: any;
    initialJson: any;
    modifiedJson: any;
    jsonpatch: any;
    encFormData: any;
    constructor(public jbhGlobals: JBHGlobals,
                public viewOrderService: ViewOrderService) {
        this.jsonpatch = jsonpatch;
    }

    ngOnInit() {
        this.loadOrderData();
    }

    loadOrderData() {
        this.viewOrderService.getData().subscribe(data => {
            if (!this.jbhGlobals.utils.isEmpty(data)) {
                this.accountInfo = data;
                this.orderBilling = this.orderBillingDTOEntity(this.accountInfo);
                this.initialJson = this.orderBilling;
                console.log(this.initialJson);    
                if (this.accountInfo.orderBillingDetailDTOs &&
                    this.accountInfo.orderBillingDetailDTOs.length > 0 &&
                    this.accountInfo.orderBillingDetailDTOs[0].profileDTO) {
                    this.billToDataAddress.push(this.accountInfo.orderBillingDetailDTOs[0].profileDTO);
                    this.rows = this.billToDataAddress;
                }
            }
        });
    }
    orderBillingDTOEntity(data) {
        if (data) {
            this.orderBillingDetail = {
                'orderBillingDetailDTOs': data['orderBillingDetailDTOs']
            };
        return this.orderBillingDetail;
        }
    }

    showViewDetailsForm() {
        this.showViewDetail = true;
        this.showViewDetailGrid = false;
    }

    closeViewDetailsForm() {
        this.showViewDetail = false;
        this.showViewDetailGrid = true;
    }

    onClickAdditionalParty() {}
    onChangeAccountRole(value) {
    this.accountRole = value.target.value;
    // console.log(this.accountRole);
    this.accountInfo.orderBillingDetailDTOs[0].profileDTO.partyType = this.accountRole;
    }
    onChangeAccountContact(value) {
    this.accountContact = value.target.value;
    console.log(this.accountInfo.orderBillingDetailDTOs[0].profileDTO);
    }
    onClickSave() {
    this.showViewDetail = false;
    this.showViewDetailGrid = true;
    this.modifiedJson = this.orderBillingDTOEntity(this.accountInfo);
    console.log(this.modifiedJson);
        // const url =  'http://ordermanagementorderupdateservices-dev.jbhunt.com/ordermanagementorderupdateservices/orders/' +
        //     this.accountInfo.orderID + '/patch';
        //     this.viewOrderService.updateData(url, this.initialJson, this.modifiedJson).subscribe(data => {
        //         if (this.jbhGlobals.utils.isEmpty(data)) {
        //             console.log(data);
        //         }
        //     });
    }
}
