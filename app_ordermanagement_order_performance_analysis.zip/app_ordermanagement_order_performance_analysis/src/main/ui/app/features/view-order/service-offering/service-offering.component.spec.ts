import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ServiceOfferingComponent } from './service-offering.component';

describe('ServiceOfferingComponent', () => {
  let component: ServiceOfferingComponent;
  let fixture: ComponentFixture<ServiceOfferingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ServiceOfferingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ServiceOfferingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
