import { TestBed, inject } from '@angular/core/testing';

import { ViewOrderHandlingUnitService } from './view-order-handling-unit.service';

describe('ViewOrderHandlingUnitService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ViewOrderHandlingUnitService]
    });
  });

  it('should be created', inject([ViewOrderHandlingUnitService], (service: ViewOrderHandlingUnitService) => {
    expect(service).toBeTruthy();
  }));
});
