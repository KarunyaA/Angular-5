import { Component, OnInit } from '@angular/core';
import { JBHGlobals } from 'app/app.service';
import { ViewOrderService } from 'app/features/view-order/view-order.service';


@Component({
  selector: 'app-delivery-handling-units',
  templateUrl: './view-order-delivery-handling-units.component.html',
  styleUrls: ['./view-order-delivery-handling-units.component.scss']
})
export class DeliveryHandlingUnitsComponent implements OnInit {

  public handlingUnitList: Array<Object>;
  public handlingUnitSelectedList: Array<Object>;
  public orderData: any;
  public stopId: any;
  public orderId: any;

  constructor(public jbhGlobals: JBHGlobals,
              public viewOrderService: ViewOrderService) { }

  ngOnInit() {
    this.loadOrderData();
  }
  public loadOrderData() {
       if (this.jbhGlobals.utils.isEmpty(this.orderData)) {
         this.viewOrderService.getData().subscribe( sharedOrderData => {
       // this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getorder).subscribe(sharedOrderData => {
            this.orderData = sharedOrderData;
            if (this.orderData && this.orderData.stopDTOs && this.orderData.stopDTOs.stop !== null ) {
              // this.stopId = this.orderData.stopDTOs.stop.stopID;
              this.orderId = this.orderData.orderID;
              this.stopServiceCall();
            }
        });
      }
  }
  public stopServiceCall(): void {
    const url = this.jbhGlobals.endpoints.order.getstopbyid + this.orderId + '/stops';
    this.jbhGlobals.apiService.getData(url).subscribe(data => {
      if (data) {
        const list = data['stop']['stopItemHandlingDetailAssociation'];
        if (list.stop.stopItemHandlingDetailAssociation) {
          this.handlingUnitSelectedList = list;
        }
        this.servicecall();
      } else {
        this.servicecall();
      }
    });
  }

  public servicecall(): void {
    const url = this.jbhGlobals.endpoints.order.updateorder + '' + this.orderId + '/fetchUnDeliveredItems';
    this.jbhGlobals.apiService.getData(url).subscribe(data => {
      this.handlingUnitList = data;
      console.log(this.handlingUnitList);
    }
    );
  }

  public saveCallOnClick(obj: Object, parent: any): void {
    const stopId = this.stopId,
      checkbox = event.target;
    if (checkbox['checked']) {
      this.formSaveServiceCall(obj, stopId, parent, checkbox);
    } else {
      const itemhandLingId = obj['itemHandlingDetail']['itemHandlingDetailID'];
      this.formDeleteServiceCall(stopId, itemhandLingId, 'Delivery', parent, checkbox);
    }
  }
  public formSaveServiceCall(obj, stopId, parent, checkbox) {
    let params = {};
    const url = this.jbhGlobals.endpoints.order.crudHandlingUnit + '/' + stopId + '/itemhandlingdetails';
    params = obj;
    this.jbhGlobals.apiService.addData(url, params).subscribe(data => {
      this.stopServiceCall();
    }, (err: Error) => {
      checkbox['checked'] = false;
    });
  }

  public formDeleteServiceCall(stopId, handlingUnitId, reason, parent, checkbox) {
    const url = this.jbhGlobals.endpoints.order.crudHandlingUnit + '/' + stopId + '/itemhandlingdetails/' + handlingUnitId;
    this.jbhGlobals.apiService.removeData(url).subscribe(data => {
      this.stopServiceCall();
    }, (err: Error) => {
      checkbox['checked'] = true;
    });
  }
}
