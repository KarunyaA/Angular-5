import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HandlingUnitsComponent } from './stop-information/handling-units/view-order-handling-units.component';
import { ItemDetailsComponent } from './stop-information/item-details/view-order-item-details.component';
import { StopDetailsComponent } from './stop-information/stop-details/view-order-stop-details.component';
import { AppointmentDetailsComponent } from './stop-information/stop-details/view-order-appointment-details.component';
import { ItemHazmatComponent } from './stop-information/item-details/view-order-item-hazmat.component';
import { StopHandlingComponent } from './stop-information/handling-units/view-order-stop-handling.component';
import { DeliveryHandlingUnitsComponent } from './stop-information/delivery-handling-units/view-order-delivery-handling-units.component';
import { SiteProfileComponent } from './stop-information/stop-details/site-profile/view-order-site-profile.component';
import { StopResequenceComponent } from './stop-information/stop-details/stop-resequence/view-order-stop-resequence.component';
import { AddcontactComponent } from './stop-information/stop-details/addcontact/view-order-addcontact.component';
import { CreateLocationComponent } from './stop-information/stop-details/create-location/view-order-create-location.component';
import { VieworderjsontransformerService } from 'app/features/view-order/vieworderJsonTransformer.service';
// import { AppointmentDetailsSchComponent } from './stop-information/stop-details/view-order-appointmentsch-details.component';

// import { SelectModule } from 'ng2-select';
import { SelectModule } from '../../shared/select';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// import { AgmCoreModule } from 'angular2-google-maps/core';

import { PopoverModule } from 'ngx-bootstrap/popover';
import { ModalModule } from 'ngx-bootstrap';
import { TypeaheadModule } from 'ngx-bootstrap/typeahead';
import { MyDatePickerModule } from 'mydatepicker';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { DragulaModule } from 'ng2-dragula';
import { TagInputModule } from 'ng2-tag-input';



import { ViewOrderRoutingModule } from './view-order-routing.module';
import { ViewOrderService } from './view-order.service';
import { ViewOrderComponent } from './view-order.component';
import { EquipmentsComponent } from './equipments/equipments.component';
import { ShipmentInformationComponent } from './shipment-information/shipment-information.component';
import { ServiceOfferingComponent } from './service-offering/service-offering.component';
import { StopInformationComponent } from './stop-information/stop-information.component';
import { AccountsComponent } from './accounts/accounts.component';
import { OrderFormBuilder } from 'app/features/create-orders/orders/order-form-builder.service';
import { JBHDataTableModule } from '../../shared/jbh-data-table/jbh-data-table.module';
import { OrderService } from 'app/features/create-orders/orders/order.service';
import { OrderOverviewComponent } from './order-overview/order-overview.component';
import { JbhUtilsModule } from 'app/shared/jbh-utils/jbh-utils.module';
import { ReconsignmentComponent } from './reconsignment/reconsignment.component';
import { TruckorderNotusedComponent } from './truckorder-notused/truckorder-notused.component';
import { ViewMapComponent } from 'app/features/view-order/stop-information/view-map/view-map.component';
// import {OrderServices} from 'app/features/view-order/stop-information/view-map/view-map.service';
import { ManageoverlayModule } from './../create-orders/orders/manageoverlay/manageoverlay.module';

//import { EsriLoaderService } from 'angular2-esri-loader';
//import { Angular2Esri4Module } from 'angular2-esri4-components';
import { ReconsignmentHistoryComponent } from './reconsignment-history/reconsignment-history.component';
import { StopSharedDataService } from '../create-orders/orders/add-stops/services/stop-shared-data.service';

@NgModule({
  imports: [
    CommonModule,
    ViewOrderRoutingModule,
    //Angular2Esri4Module,
    SelectModule,
    FormsModule,
    ReactiveFormsModule,
    JBHDataTableModule,
    ManageoverlayModule,
    // AgmCoreModule.forRoot({
    //   apiKey: 'AIzaSyCbS51Lks3sDEyIwTobAYajcVqEtsePDBM'
    // }),
    PopoverModule.forRoot(),
    ModalModule.forRoot(),
    MyDatePickerModule,
    JbhUtilsModule,
    TypeaheadModule.forRoot(),
    MyDatePickerModule,
    //  DatepickerModule.forRoot(),
    BsDropdownModule.forRoot(),
    TagInputModule,
    DragulaModule

  ],
  declarations: [ViewOrderComponent,
    EquipmentsComponent,
    ShipmentInformationComponent,
    ServiceOfferingComponent,
    StopInformationComponent,
    AccountsComponent,
    OrderOverviewComponent,
    HandlingUnitsComponent,
    ItemDetailsComponent,
    StopDetailsComponent,
    AppointmentDetailsComponent,
    ItemHazmatComponent,
    StopHandlingComponent,
    DeliveryHandlingUnitsComponent,
    SiteProfileComponent,
    StopResequenceComponent,
    AddcontactComponent,
    CreateLocationComponent,
    ReconsignmentComponent,
    TruckorderNotusedComponent,
    ReconsignmentHistoryComponent,
    ViewMapComponent,
  ],
  providers: [OrderService,
             OrderFormBuilder,
             VieworderjsontransformerService,
             StopSharedDataService,
             ViewOrderService
             ]
})
export class ViewOrderModule { }
