import { TestBed, inject } from '@angular/core/testing';

import { ViewOrderUnitOfWeightService } from './view-order-unit-of-weight.service';

describe('ViewOrderUnitOfWeightService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ViewOrderUnitOfWeightService]
    });
  });

  it('should be created', inject([ViewOrderUnitOfWeightService], (service: ViewOrderUnitOfWeightService) => {
    expect(service).toBeTruthy();
  }));
});
