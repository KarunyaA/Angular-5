export class ViewOrderItemModel {
    denMeasureFlag = false;
    volMeasureFlag = false;
    itemData: any;
    // addItemsDescForm: any;
    itemFleetList: any = [];
    serialNumberFlag: boolean;
    barcodeFlag: boolean;
    addServiceFlag: boolean;
    showHazmat = false;
    showTemperature = false;
    transItemFlag = true;
    showTransDetailIcon = false;
    showSaveDetailIcon = false;
    onSelectTransValue = false;
    icsLTLFlag = false;
    standardServiceFlag = false;
    //  itemForm: any;
    itemPopupButton: string;
    popupFlag: boolean;
    packageTypeList: any[] = [];
    itemWeightList: any[] = [];
    itemLengthList: any[] = [];
    transTypeaheadList: any[] = [];
    saveItemList: any[] = [];
    itemServiceList: any[] = [];
    itemCharacteristicsList: any[] = [];
    itemTemperatureControlList: any[] = [];
    itemBarCodeTypeList: any[] = [];
    barCodeDetails: any[] = [];
    standardServicesList: any[] = [];
    selected: any[] = [];

    transSearchFlag = false;
    saveSearchFlag = false;
    typeaheadFlag = true;
    debounceValue: any;
    itemServiceCode: any;
    itemServiceDescription: any;
    serviceId: any;
    frieghtClassList: any[] = [];
    categoryList: any = [];

    itemDimensionFlag = true;
    validataDimensionFlag = false;
    volumeVal: any;
    itemDensity: any;
    extremeLength: any;
    itemDenistyVal: any;
    itemVolumeVal: any;
    stopItemID: any;
    detailsItems: any = [];
    handlingUnitID: any;
    itemPopupHeading: string;
    emptyObj: any;
    timer;
    dcsFlag = false;
    itemDescriptionObj = {
        'itemMake': '',
        'upc': '',
        'itemManufacturer': '',
        'modelNumber': '',
        'sku': '',
        'supplierSKU': '',
        'itemCategory': '',
        'itemClassification': '',
        'itemDescription': '',
        'nmfcNumber': '',
        'itemPartNumber': ''
    };
    editItemArray = ['nmfcNumber', 'skuNumber', 'supplierSKU', 'itemMake',
        'itemModelNumber', 'itemManufacturer', 'itemCategory',
        'itemPartNumber', 'itemUniversalProductCode', 'itemClassificationCode'
    ];
    editItemObjArray = ['nmfcNumber', 'sku', 'supplierSKU', 'itemMake',
        'modelNumber', 'itemManufacturer', 'itemCategory',
        'itemPartNumber', 'upc', 'itemClassification'
    ];
    hazmatObj: any;
    hazmatData: any[] = [];
    orderData: any;
    icsLTLDirFlag = false;
    modelNumberFlag = false;
    flatbedFlag = false;
    isDataLoaded = false;
    transEditFlag = false;
    saveEditFlag = false;
    transPopCloseFlag = false;
    savedPopCloseFlag = false;
    itemDescriptionNMFC: any;
    itemDescriptionSaved: any;
    popUpItemDescriptionNMFC: any;
    newModelNumberFlag: any;
    itemCategoryList: any;
    handlingIndex: any;
    freightClass: any;
    freightClassList; any = [];
    handlingData: any;
    stopID: any;
    addItemFlag = false;
    saveItemFlag = true;
    // itemData: any;
}
