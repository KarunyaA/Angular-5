export class StopDetails {
}
