import { Injectable } from '@angular/core';

import { JBHGlobals } from 'app/app.service';

@Injectable()
export class ShipmentInformationService {

  constructor(public jbhGlobals: JBHGlobals) { }

  loadFleetCode (url, params): any {
    return this.jbhGlobals.apiService.getData(url, params);
  }
}
