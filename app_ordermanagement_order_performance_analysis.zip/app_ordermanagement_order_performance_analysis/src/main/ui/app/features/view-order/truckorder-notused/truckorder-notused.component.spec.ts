import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TruckorderNotusedComponent } from './truckorder-notused.component';

describe('TruckorderNotusedComponent', () => {
  let component: TruckorderNotusedComponent;
  let fixture: ComponentFixture<TruckorderNotusedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TruckorderNotusedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TruckorderNotusedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
