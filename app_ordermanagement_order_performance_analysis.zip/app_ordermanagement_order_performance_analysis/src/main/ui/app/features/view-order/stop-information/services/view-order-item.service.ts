import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Response } from '@angular/http';

import { JBHGlobals } from 'app/app.service';

@Injectable()
export class ViewOrderItemService {

  constructor(private jbhGlobals: JBHGlobals) { }

  getTransItemDescription(value) {
    const url = this.jbhGlobals.endpoints.order.getTransTypeahead + '/' + value;
    return this.jbhGlobals.apiService.getData(url, null, false);
  }
  getSavedItemDescription(value) {
    const url = this.jbhGlobals.endpoints.order.getSavedItem + '/' + value;
    return this.jbhGlobals.apiService.getData(url, null, false);
  }
  getLoadItem(value) {
    return this.jbhGlobals.apiService.getData(value, false);
  }
  addItem(url, params): Observable<Response[]> {
    return this.jbhGlobals.apiService.addData(url, params);
  }
  updateItem(url, params): Observable<Response[]> {
    return this.jbhGlobals.apiService.updateData(url, params);
  }
  getBarCode(url): Observable<Response[]> {
    return this.jbhGlobals.apiService.getData(url, null, false);
  }
  // getItemService(url, param): Observable<Response[]> {
  //   return this.jbhGlobals.apiService.getData(url, param, false);
  // }
  // getModelNumber(url, param): Observable<Response[]> {
  //   return this.jbhGlobals.apiService.getData(url, param, false);
  // }
  getItemCharacteristics(url): Observable<Response[]> {
    return this.jbhGlobals.apiService.getData(url, null, false);
  }
  // getExtremeLength(url, params): Observable<Response[]> {
  //   return this.jbhGlobals.apiService.getData(url, params, false);
  // }
  // getSavedItemListService(url, params): Observable<Response[]> {
  //   return this.jbhGlobals.apiService.getData(url, params, false);
  // }
  transItemDescription(url): Observable<Response[]> {
    return this.jbhGlobals.apiService.getData(url, null);
  }
  // savedItemDescription(url): Observable<Response[]> {
  //   return this.jbhGlobals.apiService.getData(url, null);
  // }
}
