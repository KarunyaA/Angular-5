import { Component, OnInit, ViewChild} from '@angular/core';
import {JBHGlobals} from '../../../app.service';
import { FormGroup, FormBuilder } from '@angular/forms';
import { ViewOrderService } from 'app/features/view-order/view-order.service';
import { ActivatedRoute } from '@angular/router';



@Component({
    selector: 'app-equipments',
    templateUrl: './equipments.component.html',
    styleUrls: ['./equipments.component.scss']
})
export class EquipmentsComponent implements OnInit {
    @ViewChild('equipOptionCategory') equipOptionCategory: any;
    @ViewChild('equipOptiontype') equipOptiontype: any;
    @ViewChild('equipOptionLength') equipOptionLength: any;
    @ViewChild('equip') equipmentoptionTag;
    @ViewChild('freightsecurement') freightsecurementTag;
    @ViewChild('protectionmaterial') protectionmaterialTag;
    // @ViewChild('showEquipmentForm') showEquipmentForm: any;
    subscription: any;
    orderData: any;
    orderID: any;
    public showEquipmentGrid = true;
    public showEquipmentForm = false;
    public orderEquipSpecification: any[] = [];
    public orderEquipSpec: any[] = [];
    public freightSecurement: any[] = [];
    public personalProtectionList: any[] = [];
    public financeBUValue: any;
    public serviceOfferingValue: any;
    public equipSaveParams: any;
    public equipmentLength: any;
    public viewEquipmentList: any[] = [];
    public viewFreightSecure: any[] = [];
    public equiplendropdown: any[];
    public equipType: any[] = [];
    public viewEquipmentDataList: any[] = [];
    public viewPersonalList: any[] = [];
    public equipmentOptions: any[] = [];
    public orderOverViewListTrailervalue: any[] = [];
    public orderTrailerValue: any;
    public orderTrailerPrefix: any[] = [];
    public equipTypeInitialValue: any;
    public equipCategoryIntialValue: any;
    //public getEquipmentCategoryService: any[] = [];
    public orderCategroyType: any[] = [];
    public equipmentTypeCode: any[] = [];
    public equipOption: any = '';
    public equipList: any[] = [];
    public personalProtectionMaterialList: any[] = [];
    public personalProtectionMaterialListDescription: any[];
    public equipOptionList: any[];
    public freightSecureListDescription: any[];
    public equipmentLengthType: any[] = [];
    public freightsecure: any[] = [];
    public freightSecureList: any[] = [];
    public selectedEquipmentTags: any = [];
    public freightsecuredata: any[] = [];
    public equipmentLengthTypeCode: any[] = [];
    public equipmentLengthServ: any[] = [];
    public equipmentLenghLev: any[] = [];
    public freightSecure: string;
    public equipmentType: any[];
    public equipmentCategory: any[];
    public personalProtection: string;
    public selCategory: '';
    public equipmentdetails: any = [];
    public jsonpatch: any;
    public encFormData: any;
    public changeObserver: any = [];
    public equipData: any[] = [];
    public cateval: any;
    public typval: any;
    public lenval: any;

    equipId: any;
    editEquipmentDetail: FormGroup;

    constructor(public jbhGlobals: JBHGlobals, public viewOrderService: ViewOrderService, public route:
        ActivatedRoute, public formBuilder: FormBuilder) {}

    ngOnInit() {
        this.getOrder();

        this.route.queryParams.subscribe(
            (queryParam: any) => {
                if (!this.jbhGlobals.utils.isEmpty(queryParam['id'])) {
                    this.equipId = Number(queryParam['id']);
                    // this.stopSharedDataService.getStopsSummary(this.orderId);
                };
            });
    }

    public getOrder() {
        this.viewOrderService.getData().subscribe(data => {
            if (!this.jbhGlobals.utils.isEmpty(data)) {
                this.orderData = data;
                console.log(this.orderData);
                this.setEquipmentOption();
                this.addEquipmentFormBuilder();
                this.getEquipmentCategory();
                this.getEquipmentType();
                this.loadProtectionMaterialHandling();
            }
        });
    }
    public setEquipmentOption() {
        const me = this;
        const orderEquipmentRequirement = this.orderData['orderEquipmentRequirementDTOs'];
        for (const i of orderEquipmentRequirement) {
            me.orderEquipSpecification.push(i['orderEquipmentRequirementSpecificationAssociationDTOs']);
            // me.viewEquipmentList.push(i['orderEquipmentTypeCategoryDetailDTO']['equipmentCategoryDescription']);
        }
        console.log(me.orderEquipSpecification);
        for (const i of me.orderEquipSpecification) {
            for (const j of i) {
                if (j['equipmentRequirementTypeCode'] === 'Floor' || j['equipmentRequirementTypeCode'] ===
                    'Door' || j['equipmentRequirementTypeCode'] === 'Roof') {
                    me.viewEquipmentList.push(j['equipmentRequirementSpecificationDescription'] + ' ' + j[
                        'equipmentRequirementTypeCode']);
                } else if (j['equipmentRequirementTypeCode'] === 'Freight') {
                    me.freightSecurement.push(j['equipmentRequirementSpecificationDescription']);
                } else if (j['equipmentRequirementTypeCode'] === 'MatHandEqu' || j[
                        'equipmentRequirementTypeCode'] === 'PersnalPro') {
                    me.personalProtectionList.push(j['equipmentRequirementSpecificationDescription']);
                }
            }
        }
    }
    public equipSelectedData(value: any): void {
        this.selectedEquipmentTags = value;
    }
    /* public onSelectEquipOptionsService(value) {
         let selVal = value.id;
         selVal = selVal.substring(0, selVal.indexOf('&'));
         const equipRequirementObj = this.transformEquip(this.equipList, selVal)[0];
         for (let i = 0; i < this.selectedEquipList.length; i++) {
             if (this.selectedEquipList[i].type === equipRequirementObj.code) {
                 if (this.selectedEquipmentTags.length > 1) {
                     this.selectedEquipmentTags.splice(this.selectedEquipmentTags.indexOf(this.selectedEquipList[i].desc), 1);
                 }
             }
         }
         const equipObj = {
             'type': equipRequirementObj.code,
             'desc': equipRequirementObj.description
         };
         const isPresent = this.jbhGlobals.utils.find(this.selectedEquipList, {
             'type': equipRequirementObj.code,
         });
         if (this.jbhGlobals.utils.isEmpty(isPresent)) {
             this.selectedEquipList.push(equipObj);
         }
         if (this.selectedEquipmentTags.indexOf(value) !== -1) {
             const selEquipObj = this.transformEquip(this.equipList, selVal)[0];
             if (selEquipObj.equipmentClassificationTypeFeatureAssociationID !== null) {
                 this.frameFeatureSpecificationOrderDTO(selEquipObj);
             } else {
                 this.frameEquipSpecificationOrderDTO(selEquipObj);
             }
         }
     }*/


    public showEquipmentDetails() {
        this.showEquipmentForm = true;
        this.showEquipmentGrid = false;
        this.populateData();
    }

    public closeEquipmentDetail() {
        this.showEquipmentForm = false;
        this.showEquipmentGrid = true;
    }

    public getEquipmentCategory() {
        this.financeBUValue = this.orderData.financeBusinessUnitCode;
        this.serviceOfferingValue = this.orderData.serviceOfferingCode;
        const params = {
            financebusinessunitcode: this.financeBUValue,
            serviceofferingcode: this.serviceOfferingValue
        };
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getEquipmentCategory, params).subscribe(
            data => {
                this.equipData = data['_embedded']['equipmentClassifications'];
                this.equipmentCategory = [];
                for (const i of this.equipData) {
                    this.equipmentCategory.push({
                        'id': i['equipmentClassificationCode'],
                        'text': i['equipmentClassificationDescription']
                    });
                }
            });


    }

    public getEquipmentType() {
        this.financeBUValue = this.orderData.financeBusinessUnitCode;
        this.serviceOfferingValue = this.orderData.serviceOfferingCode;
        const params = {
            financebusinessunitcode: this.financeBUValue,
            serviceofferingcode: this.serviceOfferingValue
        };
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getEquipmentType, params).subscribe(
            data => {
                this.equipType = data['_embedded']['equipmentTypes'];
                this.equipmentType = [];
                for (const i of this.equipType) {
                    this.equipmentType.push({
                        'id': i['equipmentTypeCode'],
                        'text': i['equipmentTypeDescription']
                    });
                }
            });
    }

    public onSelectOfEquipmentType(val) {
        const obj = this.transform(this.equipType, val.text)[0];
        const associationId = obj.equipmentClassificationTypeAssociations[0].equipmentClassificationTypeAssociationID;
        this.getEquipmentLength(associationId);
    }

    public onSelectEquipmentCategory(value) {
        const val = value.text;
        this.getEquipmentOption(val);
        this.getFreightSecurement(val);
    }
    public getEquipmentOption(value) {
        const params = {
            equipmentclassificationcode: value
        };
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getEquipmentOption, params).subscribe(
            data => {
                this.equipList = data;
                this.equipOptionList = [];
                for (let i = 0; i < this.equipList.length; i++) {
                    const equipCode = this.equipList[i]['code'];
                    if (equipCode !== 'Freight' && equipCode !== 'Length' && equipCode !==
                        'MatHandEqu' && equipCode !== 'PersnalPro') {
                        if ((this.equipList[i]['code'] === 'Door') || (this.equipList[i]['code'] ===
                                'Roof') ||
                            (this.equipList[i]['code'] === 'Floor')) {
                            this.equipOptionList.push(this.equipList[i]['associatedDescription'] +
                                '&nbsp;' + this.equipList[i]['code']);
                        } else {
                            this.equipOptionList.push(this.equipList[i]['associatedDescription'] +
                                '&nbsp;' + 'Other');
                        }
                    }
                }
                // if (!this.jbhGlobals.utils.isEmpty(selval)) {
                //     this.onSelectEquipOptionsService(selval);
                // }
            });
    }
    public addEquipmentOption(equipoption) {
        if (!this.jbhGlobals.utils.isEmpty(equipoption)) {
            for (const i of equipoption) {
                const equipOptionsVal = this.jbhGlobals.utils.find(this.equipList, {
                    serviceTypeCode: i.serviceType
                });
                if (!this.jbhGlobals.utils.isEmpty(equipOptionsVal)) {
                    this.equipOption.active.push({
                        id: equipOptionsVal.serviceTypeDescription,
                        text: equipOptionsVal.serviceTypeDescription
                    });
                }
            }
        }
    }


    public getFreightSecurement(value) {
        const params = {
            equipmentclassificationcode: value
        };
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getEquipmentOption, params).subscribe(
            data => {
                this.freightSecureList = data;
                this.freightSecureListDescription = [];
                for (let i = 0; i < this.freightSecureList.length; i++) {
                    const freightCode = this.freightSecureList[i]['code'];
                    if (freightCode === 'Freight') {
                        this.freightSecureListDescription.push(this.freightSecureList[i][
                            'associatedDescription'
                        ]);
                    }
                }
            });
    }
    transform(items: any[], args: string): any {
        // filter items array, items which match and return true will be kept, false will be filtered out
        return items.filter(item => item.equipmentTypeDescription.toLowerCase().indexOf(args.toLowerCase()) !==
            -1);
    }

    public getEquipmentLength(val) {
        const params = {
            'equipmentclassificationtypeassociationid': val
        };
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getEquipmentLength, params).subscribe(
            data => {
                if (data !== undefined) {
                    this.equipmentLength = data['_embedded'][
                        'equipmentRequirementSpecificationAssociations'
                    ];
                    this.equiplendropdown = [];
                    for (const equiplength of this.equipmentLength) {
                        this.equiplendropdown.push({
                            'id': equiplength.equipmentRequirementSpecification.equipmentRequirementSpecificationDescription,
                            'text': equiplength.equipmentRequirementSpecification.equipmentRequirementSpecificationDescription
                        });
                    }
                }
            });

    }

    public loadProtectionMaterialHandling() {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getProtectionMaterialHandling)
            .subscribe(data => {
                this.personalProtectionMaterialList = data['_embedded'][
                    'equipmentRequirementSpecificationAssociations'
                ];
                this.personalProtectionMaterialListDescription = [];
                for (let i = 0; i < this.personalProtectionMaterialList.length; i++) {
                    const eSpc = this.personalProtectionMaterialList[i][
                        'equipmentRequirementSpecification'
                    ];
                    const eDesc = eSpc['equipmentRequirementSpecificationDescription'];
                    this.personalProtectionMaterialListDescription.push(eDesc);
                }
                console.log(this.personalProtectionMaterialListDescription);
            });
    }

    public addEquipmentFormBuilder() {
        this.editEquipmentDetail = this.formBuilder.group({
            'equipmentCategoryCode': '',
            'equipmentTypeCode': '',
            'equipmentLength': '',
            'equipOption': '',
            'equipmentLengthlevel': '',
            'equipmentTypeRequiredIndicator': '',
            'freightSecurement': '',
            'protectionMaterialHandling': '',
            'equipmentTypeIndicator': '',
        });
    }

    public populateData() {
      setTimeout(() => {
        if (this.orderData.orderEquipmentRequirementDTOs.length !== 0) {
            if (!this.jbhGlobals.utils.isEmpty(this.orderData.orderEquipmentRequirementDTOs[0].orderEquipmentRequirement)) {
                this.equipSaveParams =
                    this.orderData.orderEquipmentRequirementDTOs[0].orderEquipmentRequirement;
            }
        }
        if (this.orderData.orderEquipmentRequirementDTOs.length !== 0 &&
         !this.jbhGlobals.utils.isEmpty(this.orderData.orderEquipmentRequirementDTOs)) {
            if (!this.jbhGlobals.utils.isEmpty(this.orderData.orderEquipmentRequirementDTOs[0].orderEquipmentTypeCategoryDetailDTO)) {
                this.equipTypeInitialValue =
                    this.orderData.orderEquipmentRequirementDTOs[0].orderEquipmentTypeCategoryDetailDTO.equipmentTypeCode;
                this.equipCategoryIntialValue =
                    this.orderData.orderEquipmentRequirementDTOs[0].orderEquipmentTypeCategoryDetailDTO.equipmentCategoryDescription;
                this.cateval = this.equipCategoryIntialValue;
                this.typval = this.equipTypeInitialValue;
                this.getEquipmentOption(this.cateval);
                this.getFreightSecurement(this.cateval);
            }
            if (!this.jbhGlobals.utils.isEmpty(
                    this.orderData.orderEquipmentRequirementDTOs[0].orderEquipmentRequirementSpecificationAssociationDTOs
                )) {
                this.equipOptionCategory.active.push({
                  'id': this.orderData.orderEquipmentRequirementDTOs[0].orderEquipmentTypeCategoryDetailDTO.equipmentCategoryCode,
                  'text': this.orderData.orderEquipmentRequirementDTOs[0].orderEquipmentTypeCategoryDetailDTO.equipmentCategoryDescription
                });
                this.equipOptiontype.active.push({
                  'id': this.orderData.orderEquipmentRequirementDTOs[0].orderEquipmentTypeCategoryDetailDTO.equipmentTypeCode,
                  'text': this.orderData.orderEquipmentRequirementDTOs[0].orderEquipmentTypeCategoryDetailDTO.equipmentTypeDescription
                });
    //             public setEquipmentOption() {
    //     const me = this;
    //     const orderEquipmentRequirement = this.orderData['orderEquipmentRequirementDTOs'];
    //     for (const i of orderEquipmentRequirement) {
    //         me.orderEquipSpecification.push(i['orderEquipmentRequirementSpecificationAssociationDTOs']);
    //         // me.viewEquipmentList.push(i['orderEquipmentTypeCategoryDetailDTO']['equipmentCategoryDescription']);
    //     }
    //     console.log(me.orderEquipSpecification);
    //     for (const i of me.orderEquipSpecification) {
    //         for (const j of i) {
    //             if (j['equipmentRequirementTypeCode'] === 'Floor' || j['equipmentRequirementTypeCode'] ===
    //                 'Door' || j['equipmentRequirementTypeCode'] === 'Roof') {
    //                 me.viewEquipmentList.push(j['equipmentRequirementSpecificationDescription'] + ' ' + j[
    //                     'equipmentRequirementTypeCode']);
    //             } else if (j['equipmentRequirementTypeCode'] === 'Freight') {
    //                 me.freightSecurement.push(j['equipmentRequirementSpecificationDescription']);
    //             } else if (j['equipmentRequirementTypeCode'] === 'MatHandEqu' || j[
    //                     'equipmentRequirementTypeCode'] === 'PersnalPro') {
    //                 me.personalProtectionList.push(j['equipmentRequirementSpecificationDescription']);
    //             }
    //         }
    //     }
    // }
                const orderEqpReq = this.orderData['orderEquipmentRequirementDTOs'];
                for (const i of orderEqpReq) {
                  this.orderEquipSpec.push(i['orderEquipmentRequirementSpecificationAssociationDTOs']);
                }
                for (const i of this.orderEquipSpec) {
                  for (const j of i) {
                    const equipTypeCode = j.equipmentRequirementTypeCode;
                    const obj = {
                            'id': equipTypeCode,
                            'text': j.equipmentRequirementSpecificationDescription + ' ' + equipTypeCode,
                        };
                        const obj1 = {
                            'id': equipTypeCode,
                            'text': j.equipmentRequirementSpecificationDescription,
                        };
                    switch (equipTypeCode) {
                        case 'Floor':
                        case 'Door':
                        case 'Roof':
                          if (this.jbhGlobals.utils.findIndex(this.equipmentoptionTag.active, obj) === -1) {
                               this.equipmentoptionTag.active.push(obj);
                            }
                            this.getEquipmentOption(this.equipCategoryIntialValue);
                            break;
                        case 'Other':
                            if (this.jbhGlobals.utils.findIndex(this.equipmentoptionTag.active, obj1) === -1) {
                               this.equipmentoptionTag.active.push(obj1);
                            }
                            this.getEquipmentOption(this.equipCategoryIntialValue);
                            break;
                        case 'Freight':
                            if (this.jbhGlobals.utils.findIndex(this.freightsecurementTag.active, obj1) === -1) {
                               this.freightsecurementTag.active.push(obj1);
                            }
                            this.getFreightSecurement(this.equipCategoryIntialValue);
                            break;
                        case 'MatHandEqu':
                        case 'PersnalPro':
                            if (this.jbhGlobals.utils.findIndex(this.protectionmaterialTag.active, obj1) === -1) {
                               this.protectionmaterialTag.active.push(obj1);
                            }
                            this.loadProtectionMaterialHandling();
                            break;
                        case 'Length':
                            this.lenval = j.equipmentRequirementSpecificationDescription;
                            const AssociationId =
                                this.orderData.orderEquipmentRequirementDTOs[0].
                            orderEquipmentRequirement.equipmentClassificationTypeAssociationID;
                            // this.getEquipmentLength(AssociationId);
                            this.equipOptionLength.active.push({
                                'id': equipTypeCode,
                                'text': j.equipmentRequirementSpecificationDescription,
                            });
                            this.getEquipmentLength(AssociationId);
                            break;
                        default:
                            break;
                    }
                  }
                }
            }
        }
     }, 500);
    }
}
