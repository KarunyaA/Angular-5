import { Component, OnInit } from '@angular/core';
import { JBHGlobals } from '../../../../app.service';
import { ViewOrderService } from '../../view-order.service';
declare var L: any;

@Component({
    selector: 'app-view-map',
    templateUrl: './view-map.component.html'
})
export class ViewMapComponent implements OnInit {

    public map;
    orderID: any;
    orderData: any;
    public points = [];
    public orders: any;
    constructor(private jbhGlobals: JBHGlobals,  public viewOrderService: ViewOrderService) {}
    ngOnInit() {
        this.loadOrderData();
    }
     // Getting orderID from orderDTO
    public loadOrderData(): void {
              if (this.jbhGlobals.utils.isEmpty(this.orderData)) {
                this.viewOrderService.getData().subscribe(sharedOrderData => {
                if (!this.jbhGlobals.utils.isEmpty(sharedOrderData)) {
                    this.orderData = sharedOrderData;
                    this.orderID = this.orderData.orderID;
                    this.mapService();
                }
            });
        }

    }
    mapService() {
        const params = this.orderID;
        const url = this.jbhGlobals.endpoints.viewOrder.getMapLocation;
            this.jbhGlobals.apiService.getData(url + params).subscribe(data => {
                this.orders = data;
                this.getEsriMap();
            });
    }
    public getEsriMap() {
            this.map = L.map('map').setView([this.orders.geographicalDetailDTOs[0].latitude,
            this.orders.geographicalDetailDTOs[0].longitude], 12);
            L.esri.basemapLayer('Streets').addTo(this.map);
            this.points = this.orders.geographicalDetailDTOs;
            for (let i = 0; i < this.points.length; i++) {
                const data = L.marker([this.points[i].latitude, this.points[i].longitude]).addTo(this.map);
                const stopId = this.points[i].stopID;
                data.bindPopup(function(layer) {
                    return L.Util.template('<p><b>Stop ' + stopId + '</p>');
                });
        }
    }
    }
