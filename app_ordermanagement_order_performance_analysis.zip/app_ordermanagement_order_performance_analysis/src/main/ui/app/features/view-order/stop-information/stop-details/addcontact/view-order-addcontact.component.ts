import { Component, OnInit, ViewChild, Input} from '@angular/core';
// import { ModalDirective } from 'ngx-bootstrap/modal';
// import {FormBuilder, FormGroup, Validators, FormControl} from '@angular/forms';
import { OrderFormBuilder } from 'app/features/create-orders/orders/order-form-builder.service';
import { ViewOrderService } from 'app/features/view-order/view-order.service';
import {JBHGlobals} from 'app/app.service';


@Component({
  selector: 'app-addcontact',
  templateUrl: './view-order-addcontact.component.html',
  styleUrls: ['./view-order-addcontact.component.scss']
})
export class AddcontactComponent implements OnInit {
  @ViewChild('autoShownModal') autoShownModal: any;
  @Input() contactDetail: any;
    subscription: any;
    orderData: any;
    orderdtoList: any;
  constructor(public jbhGlobals: JBHGlobals, public orderFormBuilder: OrderFormBuilder, public viewOrderService: ViewOrderService) { }

  ngOnInit() {

      this.contactDetail = this.orderFormBuilder.orderForm['controls']['contactDetail'];
      this.orderdata();
   }

  public showModal(): void {

    this.autoShownModal.show();
  }

  public hideModal(autoShownModal): void {
    this.autoShownModal.hide();
  }
  onsubmit(autoShownModal) {
this.autoShownModal.hide();
  }
  orderdata() {
    const me = this;
    this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getorderoverview).subscribe(data => {
      me.orderdtoList = data;
      console.log( me.orderdtoList);
   });
  }

   /*ngAfterContentChecked() {
        if (this.orderData !== 'undefined') {
            this.subscription = this.orderService.getData().subscribe(sharedOrderData => {
                this.orderData = sharedOrderData;
            });
        }
    }*/
}

