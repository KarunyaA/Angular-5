import { TestBed, inject } from '@angular/core/testing';

import { StopInformationService } from './stop-information.service';

describe('StopInformationService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [StopInformationService]
    });
  });

  it('should be created', inject([StopInformationService], (service: StopInformationService) => {
    expect(service).toBeTruthy();
  }));
});
