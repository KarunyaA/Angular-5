import {
    Component,
    OnInit,
    ViewChild
} from '@angular/core';
import {
    JBHGlobals
} from '../../../app.service';
import {
    FormBuilder,
    FormGroup,
    Validators
} from '@angular/forms';
import {
    ViewOrderService
} from 'app/features/view-order/view-order.service';
import * as jsonpatch from 'fast-json-patch';

//declare var jsonpatch: any;

@Component({
    selector: 'app-service-offering',
    templateUrl: './service-offering.component.html',
    styleUrls: ['./service-offering.component.scss']
})

export class ServiceOfferingComponent implements OnInit {
    @ViewChild('orderserviceTag') orderserviceTag;
    public subscription: any;
    public orderData: any;
    public ownername: string;
    public editsection = false;
    serviceOfferingForm: FormGroup;
    public viewsection = true;
    public selServiceLevel: string;
    public selserviceType: any = [];
    public selBusinessUnitCode: string;
    public selserviceOfferingCode: string;
    public selfreightChargeTerm: string;
    public businessUnitList: string[] = [];
    public serviceOfferingList: string[] = [];
    public serviceLevelList: string[] = [];
    public freightChargeList: string[] = [];
    public transitMode: string;
    public operationalOwnerListDescription: string[] = [];
    // public operationalServicesListDescription: string[] = [];
    public operationalOwnerList: string[] = [];
    // public changeObserver: any;
    public serviceOfferingDetails: any = [];
    public serviceOfferingDetails2: any;
    public changeObserver: any = [];
    public operationalServicesList: any = [];
    public jsonpatch: any;
    public encFormData: any;
    public operationalServicesListDescription: any[];
    initialJson: any;
    modifiedJson: any;
    public serviceOfferingEntity;
    public serviceOfferEntity;

    constructor(public jbhGlobals: JBHGlobals,
        public fb: FormBuilder,
        public viewOrderService: ViewOrderService) {
        this.jsonpatch = jsonpatch;
        this.serviceOfferingForm = this.fb.group({
            bussinessUnit: ['', Validators.required],
            serviceOffered: ['', Validators.required],
            serviceLevel: ['', Validators.required],
            freightCharge: ['', Validators.required],
            operationalOwner: ['', Validators.required],
            operationalServices: ['', Validators.required]
        });

        this.serviceOfferingForm.controls.bussinessUnit.valueChanges.subscribe((value) =>
            this.getPatchUpdate(value, 'financeBusinessUnitCode'));

        this.serviceOfferingForm.controls.serviceOffered.valueChanges.subscribe((value) =>
            this.getPatchUpdate(value, 'serviceOfferingCode'));

        this.serviceOfferingForm.controls.serviceLevel.valueChanges.subscribe((value) =>
            this.getPatchUpdate(value, 'transitModeCode'));

        this.serviceOfferingForm.controls.freightCharge.valueChanges.subscribe((value) =>
            this.getPatchUpdate(value, 'freightChargeTermTypeCode'));

        this.serviceOfferingForm.controls.operationalOwner.valueChanges.subscribe((value) =>
            this.getPatchUpdate(value, 'operationalOwner'));

        this.serviceOfferingForm.controls.operationalServices.valueChanges.subscribe((value) =>
            this.getPatchUpdate(value, 'operationalServices'));


    }

    serviceOfferingDTOsToEntity(data) {
        if (data) {
            this.serviceOfferingEntity = {
                'financeBusinessUnitCode': data['financeBusinessUnitCode'],
                'serviceOfferingCode': data['serviceOfferingCode'],
                'transitModeCode': data['transitModeCode'],
                'requestedServiceLevelCode': data['requestedServiceLevelCode'],
                'freightChargeTermTypeCode': data['orderBillingDetailDTOs'] !== undefined
                && data['orderBillingDetailDTOs'].length !== 0 &&
                data['orderBillingDetailDTOs'] !== null ? data['orderBillingDetailDTOs'][0]['freightChargeTermTypeCode'] : '',
                'operationalOwner': data['orderOperationalElementDTOs'] !== undefined
                && data['orderOperationalElementDTOs'].length !== 0 && data['orderOperationalElementDTOs'] !== null
                ? data['orderOperationalElementDTOs'][0]['orderOperationalElement']['projectCode'] : '',
                'operationalServices': data['orderServices'] !== undefined && data['orderServices'].length !== 0 &&
                    data['orderServices'] !== null ? data['orderServices'][0]['serviceType'] : ''
            };
            return this.serviceOfferingEntity;

        }
    }

    public getPatchUpdate(value: any, field: String): void {
        switch (field) {
            case 'financeBusinessUnitCode':
                this.serviceOfferingDetails['financeBusinessUnitCode'] = value;
                this.loadServiceOfferingList(value);
                break;

            case 'serviceOfferingCode':
                this.serviceOfferingDetails['serviceOfferingCode'] = value;
                break;

            case 'serviceLevel':
                this.serviceOfferingDetails['requestedServiceLevelCode'] = value;
                break;

            case 'freightChargeTermTypeCode':
                if (this.serviceOfferingDetails['orderBillingDetailDTOs'] !== undefined
                    && this.serviceOfferingDetails['orderBillingDetailDTOs'].length !== 0
                 && this.serviceOfferingDetails['orderBillingDetailDTOs'] !== null) {
                    for (let i = 0; i < this.serviceOfferingDetails.orderBillingDetailDTOs.length; i++) {
                        this.serviceOfferingDetails.orderBillingDetailDTOs[i].freightChargeTermTypeCode = value;
                    }
                }
                break;

            case 'operationalServices':
                if (this.serviceOfferingDetails['orderServices'].length !== 0
                    && this.serviceOfferingDetails['orderServices'] !== undefined
                    && this.serviceOfferingDetails['orderServices'] !== null) {
                    for (let i = 0; i < this.serviceOfferingDetails['orderServices'].length; i++) {
                        const result = ((value.text !== undefined) ? value[i].text : null);
                        this.serviceOfferingDetails['orderServices'][i]['serviceType'] = result;
                    }
                }
                break;

            case 'operationalOwner':
                if (this.serviceOfferingDetails['orderOperationalElementDTOs'] != null
                    && this.serviceOfferingDetails['orderOperationalElementDTOs'] !== undefined
                    && this.serviceOfferingDetails['orderOperationalElementDTOs'].length !== 0) {
                    for (let i = 0; i < this.serviceOfferingDetails['orderOperationalElementDTOs'].length; i++) {
                        this.serviceOfferingDetails.orderOperationalElementDTOs[i].orderOperationalElement.projectCode = value;
                    }
                }
                break;
            default:
                // code...
                break;
        }
    }

    ngOnInit() {
        // this.ownername = 'Patrick Jones (123)-123 1234';
        this.getOrder();
        // this.serviceOfferingCallInit();
    }

    public getOrder() {
        this.subscription = this.viewOrderService.getData().subscribe(sharedOrderData => {
            if (!this.jbhGlobals.utils.isEmpty(sharedOrderData)) {
                this.serviceOfferingDetails = sharedOrderData;
                this.serviceOfferEntity = this.serviceOfferingDTOsToEntity(this.serviceOfferingDetails);
                this.initialJson = this.serviceOfferEntity;
                // this.changeObserver = this.jsonpatch.observe(this.serviceOfferingDetails);
                // if (this.orderData.tempData) {
                //   this.orderserviceTag.active = [];
                //   this.populateTemplateData();
                // }
                if (!this.jbhGlobals.utils.isEmpty(this.serviceOfferingDetails)) {
                    // this.orderserviceTag.active = [];
                    this.populateData();
                    this.loadBusinessUnit();
                    // this.loadOperationalServices();
                    this.loadOperationalServices(null);
                    this.loadServiceOfferingList(this.serviceOfferingDetails['financeBusinessUnitCode']);
                    this.loadServiceLevels();
                    this.loadFreightChargeTerms();
                }
            }
        });
    }

    populateData() {
        if (this.serviceOfferingDetails.financeBusinessUnitCode !== undefined) {
            this.selBusinessUnitCode = this.serviceOfferingDetails.financeBusinessUnitCode;
        }
        if (this.serviceOfferingDetails.serviceOfferingCode !== undefined) {
            this.selserviceOfferingCode = this.serviceOfferingDetails.serviceOfferingCode;
        }
        if (!this.jbhGlobals.utils.isEmpty(this.serviceOfferingDetails.orderBillingDetailDTOs)) {
            this.selfreightChargeTerm = this.serviceOfferingDetails.orderBillingDetailDTOs[0].freightChargeTermTypeCode;
        }
        if (this.serviceOfferingDetails.requestedServiceLevelCode) {
            this.selServiceLevel = this.serviceOfferingDetails.requestedServiceLevelCode;
        }
        /*if (this.serviceOfferingDetails.orderOperationalElements.length !== 0) {
             this.ownername = this.serviceOfferingDetails.orderOperationalElements[0].projectCode;
         }*/
        if (this.serviceOfferingDetails.orderOperationalElementDTOs.length !== 0) {
            this.ownername = this.serviceOfferingDetails.orderOperationalElementDTOs[0].orderOperationalElement.projectCode;
        }
        if (this.serviceOfferingDetails.orderServices !== null && this.serviceOfferingDetails.orderServices.length !== 0) {
            this.selserviceType = this.serviceOfferingDetails.orderServices[0].serviceType;
            this.loadOperationalServices(this.serviceOfferingDetails.orderServices);
        }
        if (this.serviceOfferingDetails.transitModeCode !== null) {
            this.transitMode = this.serviceOfferingDetails.transitModeCode;
        }

    }

    // public populateTemplateData() {
    //     console.log('populateTemplateData');
    // }

    public loadBusinessUnit() {
        // Get all BusinessUnits
        // this.businessUnitList = ['JBI', 'DCS', 'ICS', 'JBT'];
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getbusinessunit).subscribe(data => {
            this.businessUnitList = data['_embedded']['serviceOfferingBusinessUnitTransitModeAssociations'];
            // console.log(this.businessUnitList);
        });
    }

    public loadServiceOfferingList(value) {
        // Get all ServiceOffering
        // this.serviceOfferingList = ['Dedicated', 'Backhaul', 'Intermodal'];
        const params = {
            'financeBusinessUnitCode': value,
            'projection': 'viewserviceofferingbusinessunittransitmode'
        };
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getserviceoffering, params).subscribe(data => {
            if (!this.jbhGlobals.utils.isEmpty(data) && data['_embedded']) {
                this.serviceOfferingList = data['_embedded']['serviceOfferingBusinessUnitTransitModeAssociations'];
            }
        });
    }

    public loadServiceLevels() {
        // Get all ServiceLevels
        //this.serviceLevelList = ['Standard', 'PREMIUM', 'EXPEDITED'];
        const params = {
            'financeBusinessUnitCode': this.selBusinessUnitCode,
            'serviceOfferingCode': this.selserviceOfferingCode
        };
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getservicelevels, params).subscribe(data => {
            if (!this.jbhGlobals.utils.isEmpty(data) && data['_embedded']) {
                this.serviceLevelList = data['_embedded']['serviceLevelBusinessUnitServiceOfferingAssociations'];
            }
            // console.log(this.serviceLevelList);
            //this.selServiceLevel = this.serviceLevelList[0]['serviceLevel']['serviceLevelCode'];
        });
    }

    public loadFreightChargeTerms() {
        // Get all FreightChargeTerms
        // this.freightChargeList = ['3rd Party', 'Collect', 'Prepaid'];
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getfreightchargeterms).subscribe(data => {
            if (!this.jbhGlobals.utils.isEmpty(data) && data['_embedded']) {
                this.freightChargeList = data['_embedded']['freightChargeTerms'];

            }

        });
    }

    public loadOperationalOwner(selectedOprOwner) {
        // Get all OperationalOwner
        // this.operationalOwnerListDescription = ['AMAZ'];
        this.operationalOwnerListDescription = [];
        const params = {
            'projectCode': selectedOprOwner
        };
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getoperationalowner, params, false).subscribe(data => {
            if (!this.jbhGlobals.utils.isEmpty(data) && data['_embedded']) {
                this.operationalOwnerList = data['_embedded']['projects'];
                for (let i = 0; i < this.operationalOwnerList.length; i++) {
                    this.operationalOwnerListDescription.push(this.operationalOwnerList[i]['projectDescription'].trim());
                }
            }


        });
    }

    // public loadOperationalServices() {
    //     // Get all OperationalServices
    //     // this.operationalServicesListDescription = ['Team Driving', 'Cash On Delivery'];
    //     const params = {
    //     'serviceCategoryCode': 'OrderServ'
    //     };
    //     this.operationalServicesListDescription = [];
    //     this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getoperationalservices, params).subscribe(data => {
    //         if (!this.jbhGlobals.utils.isEmpty(data) && data['_embedded']) {
    //             this.operationalServicesList = data['_embedded']['serviceTypes'];
    //             for (let i = 0; i < this.operationalServicesList.length; i++) {
    //                 this.operationalServicesListDescription.push(this.operationalServicesList[i]['serviceTypeDescription']);
    //             }
    //         }
    //         console.log(this.operationalServicesListDescription);
    //     });
    // }

    public loadOperationalServices(array) {
        const params = {
            'serviceCategoryCode': 'OrderServ'
        };
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getoperationalservices, params).subscribe(data => {
            this.operationalServicesList = data['_embedded']['serviceTypes'];
            this.operationalServicesListDescription = [];
            for (const operServ of this.operationalServicesList) {
                this.operationalServicesListDescription.push({
                    'id': operServ['serviceTypeCode'],
                    'text': operServ['serviceTypeDescription']
                });
                if (array) {
                    for (let i = 0; i < array.length; i++) {
                        if (array[i]['serviceType'] === operServ['serviceTypeCode']) {
                            this.orderserviceTag.active.push({
                                'id': array[i]['serviceType'],
                                'text': operServ['serviceTypeDescription']
                            });
                        }
                    }
                }
            }
        });
    }

    // public serviceOfferingCallInit() {
    //     this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getorderoverview).subscribe(data => {
    //         this.serviceOfferingDetails = data;
    //         //this.changeObserver = jsonpatch.observe( this.serviceOfferingDetails );
    //        });
    // }

    public onSelectOperationalService(event) {
        // if (event.text === 'Limitation of Liability') {
        //   this.dollarInputRequired = true;
        // }
        // const oprServiceObj = this.oprTransform(this.operationalServicesList, event.id)[0];
        //  const OrderServicesObj = {
        //       'serviceCount' : 1,
        //       'serviceLevelTypeCode' : 'ORDER',
        //       'serviceType' : oprServiceObj.serviceTypeCode,
        //       'stopID' : '',
        //       'unitOfServiceMeasurementCode' : 'Hours'
        //     };
        // if (!this.serviceOfferingDetails.orderServices) {
        //   this.serviceOfferingDetails.orderServices = [];
        // }
        // this.serviceOfferingDetails.orderServices.push(OrderServicesObj);
        // this.viewOrderService.saveData(this.serviceOfferingDetails);
    }

    public onRemoveOperationalService(event) {
        // if (event.text === 'Limitation of Liability') {
        //   this.dollarInputRequired = false;
        // }
        // const oprServiceObj = this.oprTransform(this.operationalServicesList, event.id)[0];
        // for ( let i = 0; i < this.serviceOfferingDetails.orderServices.length; i++) {
        //    if (this.serviceOfferingDetails.orderServices[i].serviceType === oprServiceObj.serviceTypeCode) {
        //        this.serviceOfferingDetails.orderServices.splice(i, 1);
        //    }
        //  }
        //  this.viewOrderService.saveData(this.serviceOfferingDetails);
    }

    public oprTransform(items: any[], args: string): any {
        return items.filter(item => item.serviceTypeCode.toLowerCase().indexOf(args.toLowerCase()) !== -1);
    }

    public editData() {
        this.editsection = true;
        this.viewsection = false;
        this.orderserviceTag.active.length = 0;
        if (this.selserviceType) {
            const orderSerTagObj = {
                'id': this.selserviceType,
                'text': this.selserviceType
            };
            this.orderserviceTag.active.push(orderSerTagObj);
        }
    }

    // Function for form submit
    public seviceOfferedSubmit(value) {
        this.populateData();
        this.editsection = false;
        this.viewsection = true;
        this.modifiedJson = this.serviceOfferingDTOsToEntity(this.serviceOfferingDetails);
        const saveData = this.jsonpatch.compare(this.initialJson, this.modifiedJson);
        // const saveData = JSON.stringify(this.jsonpatch.generate(this.changeObserver));
        this.encFormData = window.btoa(saveData);
        // const payLoad = { 'patchDetails': this.encFormData };
        // this.jbhGlobals.apiService.updateData('http://WINX-V0762:8089/ordermanagementorderservices
        // /orders/apply/string', payLoad).subscribe( data => {
        //     console.log(data);
        // });
    }

    public cancelOfferedSubmit() {
        this.editsection = false;
        this.viewsection = true;
        this.populateData();
    }
}
