import { Injectable } from '@angular/core';

import { JBHGlobals } from 'app/app.service';


@Injectable()
export class OrderOverviewService {

  constructor(public jbhGlobals: JBHGlobals) { }

  loadServices(url) {
    return this.jbhGlobals.apiService.getData(url);
  }

}
