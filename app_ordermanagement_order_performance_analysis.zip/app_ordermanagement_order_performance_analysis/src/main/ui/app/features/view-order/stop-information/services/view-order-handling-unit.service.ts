import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Response } from '@angular/http';

import { JBHGlobals } from 'app/app.service';

@Injectable()
export class ViewOrderHandlingUnitService {
  constructor(private jbhGlobals: JBHGlobals) { }

  getHandlingReference(url): Observable<Response[]> {
    return this.jbhGlobals.apiService.getData(url);
  }
  // addHandlingData(url, params): Observable<Response[]> {
  //   return this.jbhGlobals.apiService.addData(url, params);
  // }
  // updateHandlingData(url, params): Observable<Response[]> {
  //   return this.jbhGlobals.apiService.updateData(url, params);
  // }
  // removeHandlingData(url): Observable<Response[]> {
  //   return this.jbhGlobals.apiService.removeData(url);
  // }
  // removeItemData(url): Observable<Response[]> {
  //   return this.jbhGlobals.apiService.removeData(url);
  // }
  // fetchUndeliveredHandling(url): Observable<Response[]> {
  //   return this.jbhGlobals.apiService.getData(url);
  // }
  // getStopDetails(url): Observable<Response[]> {
  //   return this.jbhGlobals.apiService.getData(url);
  // }
}
