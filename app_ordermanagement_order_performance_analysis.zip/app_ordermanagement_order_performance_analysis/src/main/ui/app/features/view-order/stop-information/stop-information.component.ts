import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';
import {JBHGlobals} from '../../../app.service';
import { JBHDataTableComponent } from 'app/shared/jbh-data-table/components/jbh-data-table.component';
import { ViewOrderService } from '../view-order.service';
import { VieworderjsontransformerService } from 'app/features/view-order/vieworderJsonTransformer.service';
import { StopInformation } from './models/stop-information';
import { StopInformationService } from './services/stop-information.service';

@Component({
    selector: 'app-stop-information',
    templateUrl: './stop-information.component.html',
    styleUrls: ['./stop-information.component.scss'],
    providers: [StopInformationService]
})

export class StopInformationComponent implements OnInit, OnDestroy {
    stopInformation: StopInformation;
    @ViewChild('popOverTemplates') pop: any;
    @ViewChild('addressPopoverList') popAddress: any;
    @ViewChild('partyNames') partyNames: any;
    @ViewChild('contactDetailList') contactList: any;
    @ViewChild(JBHDataTableComponent) jbhdatatable: JBHDataTableComponent;
    subscriptions: Array<Subscription> = [];

    constructor(public jbhGlobals: JBHGlobals,
                public viewOrderService: ViewOrderService,
                public transformerService: VieworderjsontransformerService,
                public stopInformationService: StopInformationService
    ) {}

    ngOnInit() {
        this.stopInformation = new StopInformation();
        this.loadOrderData();
    }

    // Getting orderID from orderDTO
    loadOrderData() {
              if (this.jbhGlobals.utils.isEmpty(this.stopInformation.orderData)) {
                const subsOne = this.viewOrderService.getData().subscribe(sharedOrderData => {
                if (!this.jbhGlobals.utils.isEmpty(sharedOrderData)) {
                    this.stopInformation.orderData = sharedOrderData;
                    this.stopInformation.orderID = this.stopInformation.orderData.orderID;
                    this.serviceCall();
                }
                this.subscriptions.push(subsOne);
            });
       }
    }

    // Assigning data to grid
    serviceCall() {
        const params = this.stopInformation.orderID + '/stops';
        const stopURL = this.jbhGlobals.endpoints.order.getstopresequencelist;
       const subsTwo = this.stopInformationService.loadServices(stopURL + params).subscribe(data => {
            if (!this.jbhGlobals.utils.isEmpty(data)) {
                this.stopInformation.rows = data;
                this.stopInformation.totalStopsCount = data.length;
            }
            this.subscriptions.push(subsTwo);
        });
    }
    loadStopServicesList(val) {
         const params = {
                'businessUnit': this.stopInformation.orderData.financeBusinessUnitCode,
                'serviceOffering': this.stopInformation.orderData.serviceOfferingCode,
                'serviceCategoryCode': 'StopServ'
            };
        const serviceTypeVal = [];
        this.stopInformation.serviceTypeList = [];
        const subsThree = this.stopInformationService.loadServiceWithParams(this.jbhGlobals.endpoints.order.getstopserviceslist,
            params).subscribe(serviceData => {
            if (!this.jbhGlobals.utils.isEmpty(serviceData) && serviceData['_embedded']) {
                this.stopInformation.serviceLevelTypeCodeList = this.jbhGlobals.utils.uniqBy(serviceData['_embedded']['serviceTypes'],
                 'serviceTypeDescription');
                  if (!this.jbhGlobals.utils.isEmpty(this.stopInformation.serviceLevelTypeCodeList) &&
                      !this.jbhGlobals.utils.isEmpty(this.stopInformation.serviceTypeCodeList)) {
                    for (let i = 0; i < this.stopInformation.serviceTypeCodeList.length; i++) {
                    serviceTypeVal.push(this.jbhGlobals.utils.find(this.stopInformation.serviceLevelTypeCodeList, {
                    serviceTypeCode: val[i].serviceType
                    }));
                }
                    for (let j = 0; j < serviceTypeVal.length; j ++) {
                    const obj = {
                    id: serviceTypeVal[j].serviceTypeCode,
                    text: serviceTypeVal[j].serviceTypeDescription
                    };
                    this.stopInformation.serviceTypeList.push(obj);

                    }
                    this.stopInformation.serviceTypeListFlag = true;
                }
            }
            this.subscriptions.push(subsThree);
        });
    }
    stopReferenceType(val) {
        const subsFour = this.stopInformationService.loadServices(val +
            '/referencenumberTypes').subscribe(data => {
            this.stopInformation.referenceTypes = data;
            this.stopInformation.referenceTypeList = [];
            if (!this.jbhGlobals.utils.isEmpty(this.stopInformation.parentRefenceId) &&
                !this.jbhGlobals.utils.isEmpty(this.stopInformation.referenceTypes)) {
            for (let i = 0; i < this.stopInformation.parentRefenceId.length; i++) {
                for (let j = 0; j < this.stopInformation.referenceTypes.length; j++) {
                    if (this.stopInformation.referenceTypes[j].referenceNumber.referenceNumberID ===
                        this.stopInformation.parentRefenceId[i]) {
                          const obj = {
                            referenceNumberTypeCode: this.stopInformation.referenceTypes[i].referenceNumber.referenceNumberTypeCode,
                            referenceNumberValue: this.stopInformation.referenceTypes[i].referenceNumber.referenceNumberValue
                        };
                        this.stopInformation.referenceTypeList.push(obj);
                    }
                }
            }
        }
        console.log(this.stopInformation.referenceTypeList);
        this.subscriptions.push(subsFour);
        });
    }

    // function for getting data fro jbh data table

    onActivate(event) {
        this.stopInformation.selected = [];
        const totalItems: any = [];
        if (event.type === 'click' && this.stopInformation.selected.length <= 1 && this.stopInformation.popOverFlag === 0) {
            this.stopInformation.stopID = event.row.stop.stopID;
            // this.referenceTypeURL = this.stopURL + this.params + '/' + this.stopID;
            this.stopInformation.stopUrl = this.jbhGlobals.endpoints.order.getstopresequencelist +
            this.stopInformation.orderID + '/stops/' + this.stopInformation.stopID;
            const subsFive = this.stopInformationService.loadServices(this.stopInformation.stopUrl).subscribe(data => {
                if (!this.jbhGlobals.utils.isEmpty(data)) {
                    this.stopInformation.selected = data;
                    if (data['stop'] && data['stop']['stopServices'].length !== 0) {
                        this.stopInformation.serviceTypeCodeList = data['stop']['stopServices'];
                        this.loadStopServicesList(this.stopInformation.serviceTypeCodeList);
                    }
                if (data['stop'] && data['stop']['appointment']) {
                    const schAppt = this.jbhGlobals.utils.find(data['stop']['appointment'], {
                         appointmentTypeCode: 'scheduled'
                    });
                    this.schAppointmentList(schAppt);
                }
            if (data['itemHandlingDetailDTOs']) {
                for (let i = 0; i < data['itemHandlingDetailDTOs'].length; i++) {
                totalItems.push(data['itemHandlingDetailDTOs'][i]['stopItemDTOs']);
                if (data['itemHandlingDetailDTOs'][i].itemHandlingDetail.itemHandlingDetailReferenceNumberAssociations.length !== 0) {
                const path = data['itemHandlingDetailDTOs'][i].itemHandlingDetail.itemHandlingDetailReferenceNumberAssociations[0];
                this.stopInformation.parentRefenceId.push(path.stopReferenceNumber.referenceNumberID);
                }
         }
             if (totalItems.length !== 0) {
                 for (let i = 0; i < totalItems.length; i++) {
                     this.stopInformation.totalItemsList.push(totalItems[i].length);
                 }
             }
            //this.stopReferenceType(this.stopUrl);
                }
                for (let i = 0; i < this.stopInformation.selected.stop.appointment.length; i++) {
                    const appointmentTypeCode = this.stopInformation.selected.stop.appointment[i].appointmentTypeCode;
                    switch (appointmentTypeCode) {
                        case 'requested':
                            const params1 = 'requested';
                            this.stopInformation.normalAppointemntReq = [];
                            this.appointmentArray(this.stopInformation.selected.stop.appointment[i].appointmentDateTimeDetails, params1);
                            break;
                        case 'scheduled':
                            const params2 = 'scheduled';
                            this.stopInformation.normalAppointemntSch = [];
                            this.appointmentArray(this.stopInformation.selected.stop.appointment[i].appointmentDateTimeDetails, params2);
                            break;
                        default:

                    }
                }
                }
                this.subscriptions.push(subsFive);
            });
            this.jbhdatatable.isDataTableDetailOpen = true;
            this.jbhDataTableCol(true, false);
            this.stopInformation.stopViewSection = true;
            this.stopInformation.flag++;
            this.stopInformation.isAddStopSelected = false;
        } else {
            this.stopInformation.popOverFlag = 0;
        }
    }

    schAppointmentList(schAppt) {
        if (schAppt) {
            this.stopInformation.appointmentCnfNum = schAppt['appointmentConfirmationNumber'];
            this.stopInformation.commonFlag = true;
            if (!this.jbhGlobals.utils.isEmpty(schAppt['appointmentInstructionAssociation'])) {
                this.stopInformation.appointmentInstFlag = true;
                this.stopInformation.appintmentInstruction = schAppt['appointmentInstructionAssociation'];
            }
        }
    }
    appointmentArray(value, type) {
        if (value) {
            for (let i = 0; i < value.length; i++) {
                const indicatorType = value[i].primaryAppointmentIndicator;
                switch (indicatorType) {
                    case 'Y':
                        if (type === 'requested') {
                            const data1 = [value[i]];
                            this.stopInformation.primaryAppointemntReq = [];
                            this.stopInformation.primaryAppointmentReqFlag = true;
                            this.populateAppointment(data1);
                            this.stopInformation.primaryAppointemntReq.push(this.stopInformation.object);
                        }
                        if (type === 'scheduled') {
                            const data2 = [value[i]];
                            this.stopInformation.primaryAppointemntSch = [];
                            this.stopInformation.primaryAppointmentSchFlag = true;
                            this.populateAppointment(data2);
                            this.stopInformation.primaryAppointemntSch.push(this.stopInformation.object);
                        }

                        break;
                    case 'N':
                        if (type === 'requested') {
                            const data3 = [];
                            data3.push(value[i]);
                            this.stopInformation.normalAppointemntReqFlag = true;
                            this.populateAppointment(data3);
                            this.stopInformation.normalAppointemntReq.push(this.stopInformation.object);
                        }
                        if (type === 'scheduled') {
                            const data4 = [];
                            data4.push(value[i]);
                            this.stopInformation.normalAppointemntSchFlag = true;
                            this.populateAppointment(data4);
                            this.stopInformation.normalAppointemntSch.push(this.stopInformation.object);
                        }

                        break;
                    default:
                }
            }
        }

    }
    populateAppointment(value) {
        if (value) {
            for (let i = 0; i < value.length; i++) {
                this.stopInformation.object = {};
                this.stopInformation.object['appointmentStartTime'] = value[i].appointmentStartTimestamp.slice(11);
                this.stopInformation.object['appointmentStartDate'] = value[i].appointmentStartTimestamp.slice(0, 10);
                this.stopInformation.object['appointmentEndTime'] = value[i].appointmentEndTimestamp.slice(11);
                this.stopInformation.object['appointmentEndDate'] = value[i].appointmentEndTimestamp.slice(0, 10);
            }
            return this.stopInformation.object;
        }
    }
    jbhDataTableCol(value1: boolean, value2: boolean): void {
        this.stopInformation.first = value1;
        this.stopInformation.second = value2;
    }
    mapTableDetails(value1, value2, value3, value4, value5, value6): void {
        this.stopInformation.mapIcon = value1;
        this.stopInformation.listIcon = value2;
        this.stopInformation.mapView = value3;
        this.stopInformation.tableView = value4;
        this.stopInformation.stopViewSection = value5;
        this.stopInformation.isAddStopSelected = value6;

    }
    mapDetailShow() {
        this.mapTableDetails(false, true, true, false, false, false);
    }


    tableDetailShow() {
        this.mapTableDetails(true, false, false, true, false, false);

    }

    valueForTableOrMap(value) {
        if (value === 'Table') {
            this.tableDetailShow();
        }
        if (value === 'Map') {
            this.mapDetailShow();
        }
    }
    showTableOrMap(value) {
        if (this.stopInformation.flag !== 0) {
            this.jbhDataTableCol(false, true);
            this.stopInformation.flag = 0;
            this.valueForTableOrMap(value);

        } else {
            this.valueForTableOrMap(value);

        }
    }
    // Function for displaying Grid
    showTable() {
        this.showTableOrMap('Table');

    }
    // Function for displaying MAP
    showMap() {
        this.showTableOrMap('Map');

    }
    // Function for editing the stops view section for map

    editStopsViewSectionMap() {
        this.stopInformation.stopViewSection = false;
        this.stopInformation.isAddStopSelected = true;
        this.stopInformation.isAddStopEditScenario = true;
    }

    // Function for close Operation of Edit and View Section for map

    stopViewCloseMap() {
        this.stopInformation.stopViewSection = false;
        this.stopInformation.isAddStopSelected = false;
        this.jbhDataTableCol(false, true);
        this.jbhdatatable.isDataTableDetailOpen = false;
        this.stopInformation.flag = 0;
    }

    // PopOver click function for enabling and disabling the flag for split view

    popOverSelected(value, popover) {
        this.stopInformation.popOverFlag++;
        this.stopInformation.stopIndex = value.$$index;
        setTimeout(() => {
                const popOVerList = this.pop['nativeElement'];
                popOVerList.setAttribute('tabindex', '1');
                popOVerList.focus();
                popOVerList.addEventListener('blur', function(event) {
                popover.hide();
                });
            },
            2000);
    }
    addressPopover(pop) {
        this.stopInformation.popOverFlag++;
        setTimeout(() => {
                const popOVerList = this.popAddress['nativeElement'];
                popOVerList.setAttribute('tabindex', '2');
                popOVerList.focus();
                popOVerList.addEventListener('blur', function(event) {
                pop.hide();
                });
            },
            500);
    }
    partyNameSelected(popover) {
        setTimeout(() => {
                const popOVerList = this.partyNames['nativeElement'];
                popOVerList.setAttribute('tabindex', '3');
                popOVerList.focus();
                popOVerList.addEventListener('blur', function(event) {
                popover.hide();
                });
            },
            500);
    }

    contactDetailSelected(popover) {
        setTimeout(() => {
                const popOVerList = this.contactList['nativeElement'];
                popOVerList.setAttribute('tabindex', '4');
                popOVerList.focus();
                popOVerList.addEventListener('blur', function(event) {
                popover.hide();
                });
            },
            500);
    }
    // Function for adding a new stop in JBH table

    onAddNewStop(popover) {
        popover.hide();
        this.stopInformation.popOverFlag++;
        this.stopInformation.isAddStopSelected = true;
        this.stopInformation.isAddStopEditScenario = false;
        this.jbhdatatable.isDataTableDetailOpen = true;
        this.jbhDataTableCol(true, false);
        this.stopInformation.flag++;
    }

    isChildCloseSelected(val) {
        this.jbhDataTableCol(false, true);
        this.stopInformation.isAddStopSelected = false;
        this.jbhdatatable.isDataTableDetailOpen = false;
    }

    onDeleteStop(popover) {
        popover.hide();
        this.stopInformation.popOverFlag++;
        this.stopInformation.rows.splice(this.stopInformation.stopIndex, 1);
    }
    isSubmitSelected(val) {
        this.jbhDataTableCol(false, true);
        this.stopInformation.isAddStopSelected = false;
        this.jbhdatatable.isDataTableDetailOpen = false;
        if (val !== null && val && val !== undefined) {
            this.stopInformation.orderData = val;
            console.log(this.transformerService.stopDTOsToEntity(this.stopInformation.orderData.stopDTOs.stop));
        }
    }
    
    ngOnDestroy() {
        for (const subs of this.subscriptions) {
            //subs.unsubscribe();
        }
    }
}
