
import { Component, ViewChild, OnInit} from '@angular/core';
import { IMyOptions } from 'mydatepicker';
import { FormBuilder, FormGroup } from '@angular/forms';
// import { SiteProfileComponent } from '../../create-orders/orders/add-stops/stop-details/site-profile/site-profile.component';
import { JBHGlobals } from 'app/app.service';
import { JBHDataTableComponent } from 'app/shared/jbh-data-table/components/jbh-data-table.component';
import { DatePipe, CurrencyPipe } from '@angular/common';

@Component({
  selector: 'app-opportunity-arview',
  templateUrl: './opportunity-arview.component.html',
  styleUrls: ['./opportunity-arview.component.scss']

})
export class OpportunityArviewComponent implements OnInit {
    rate = 0;
    rows = [];
    currentstatusValue = {};
    selected = [];
    totalRecordsCount = 0;
    offset = 0;
    limit = 5;
    favUrl = '';
    arViewForm: FormGroup;
    selectedcount = 0;
    val = 1;
    val2 = 0.7;
    flag = 0;
    conditionwrapper = false;
    columns = [];
    filterTitle = 'Filter By';
    @ViewChild(JBHDataTableComponent) jbhdatatable: JBHDataTableComponent;
    @ViewChild('splitViewTemplateContainer') splitViewTemplateContainer;
//    @ViewChild(SiteProfileComponent) siteprofile: SiteProfileComponent;
    @ViewChild('billtoPopover') billtoPopover: any;
    @ViewChild('originPopover') originPopover: any;
    @ViewChild('destinationPopover') destinationPopover: any;

    Elasticsearchparams: any = {
        'query': {
            'bool': {
                'must': []
            }
        }
    };

    filterData: any = {
        'opportunityStatusCode': [],
        'origin.locationDTO.addressDTO.city': [],
        'destination.locationDTO.addressDTO.city': [],
        'billToProfile.partyName': [],
        'orderOwner.firstName': [],
        'opportunityCreator.firstName': []
    };

    public FilterList: any[] = [{
        'index': 0,
        'title': 'Origin',
        'key': 'opportunity-origin.locationDTO.addressDTO.city',
        'rootVal': ['aggregations', 'locations', 'only_loc', 'topinner', 'buckets'],
        'componentType': 'lsitType',
        // 'url': 'origin',
        'methodType': 'addData',
        'count': 0,
        'url': 'origin',
        'params': {
            '_source': false,
            'query': {
                'nested': {
                    'path': 'locations',
                    'query': {
                        'query_string': {
                            'default_field': 'locations.CityName',
                            'query': '*'
                        }
                    }
                }
            },

            'aggs': {
                'locations': {
                    'nested': {
                        'path': 'locations'
                    },
                    'aggs': {
                        'only_loc': {
                            'filter': {
                                'query_string': {
                                    'default_field': 'locations.CityName',
                                    'query': '*'
                                }
                            },

                            'aggs': {
                                'topinner': {
                                    'terms': {
                                        'field': 'locations.CityName.keyword'
                                    },
                                    'aggs': {
                                        'topacc_hits': {
                                            'top_hits': {
                                                'sort': [{
                                                    '_score': {
                                                        'order': 'desc'
                                                    }
                                                }],
                                                '_source': {
                                                    'includes': ['locations.StateCode']
                                                },
                                                'size': 1
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        //getLocationData

    }, {
        'index': 1,
        'key': 'opportunity-destination.locationDTO.addressDTO.city',
        'title': 'Destination',
        'rootVal': ['aggregations', 'locations', 'only_loc', 'topinner', 'buckets'],
        'componentType': 'lsitType',
        'count': 0,
        'url': 'destination',
        'methodType': 'addData',
        //'url': 'Orgintest',
        'params': {
            '_source': false,
            'query': {
                'nested': {
                    'path': 'locations',
                    'query': {
                        'query_string': {
                            'default_field': 'locations.CityName',
                            'query': '*'
                        }
                    }
                }
            },
            'aggs': {
                'locations': {
                    'nested': {
                        'path': 'locations'
                    },
                    'aggs': {
                        'only_loc': {
                            'filter': {
                                'query_string': {
                                    'default_field': 'locations.CityName',
                                    'query': '*'
                                }
                            },
                            'aggs': {
                                'topinner': {
                                    'terms': {
                                        'field': 'locations.CityName.keyword'
                                    },
                                    'aggs': {
                                        'topacc_hits': {
                                            'top_hits': {
                                                'sort': [{
                                                    '_score': {
                                                        'order': 'desc'
                                                    }
                                                }],
                                                '_source': {
                                                    'includes': ['locations.StateCode']
                                                },
                                                'size': 1
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

    }, {
        'index': 2,
        'key': 'opportunity-billToProfile.partyName',
        'title': 'Bill To Account',
        'count': 0,
        'rootVal': ['hits', 'hits'],
        'componentType': 'lsitType',
        'url': 'billto',
        'methodType': 'addData',
        'paginationSize': 2,
        'pagination': true,
        //'url': '',
        'params': {
            'size': 5,
            'from': 0,
            '_source': ['OrganizationName', 'PartyID'],
            'highlight': {
                'fields': {
                    '*': {}
                }
            },
            'query': {
                'bool': {
                    'should': [{
                        'multi_match': {

                            'fields': ['OrganizationName'],

                            'query': '*',
                            'type': 'phrase_prefix'
                        }
                    }],
                    'filter': {
                        'nested': {
                            'path': 'partyaddresses',
                            'query': {
                                'query_string': {
                                    'fields': ['partyaddresses.PartyRoleTypeDescription'],
                                    'query': 'BILL AND TO'
                                }
                            }

                        }
                    }
                }
            }
        }

    }, {
        'index': 3,
        'key': 'opportunity-opportunityStatusCode',
        'title': 'Status',
        'count': 0,
        'rootVal': ['_embedded', 'opportunityStatuses'],
        'componentType': 'lsitType',
        // 'url': 'opportunitystatus',
        'url': 'opportunitystatus',

    }, {
        'index': 4,
        'key': 'opportunity-opportunityCreator.firstName',
        'title': 'Opportunity Creator',
        'rootVal': [],
        'count': 0,
        'componentType': 'lsitType',
        'url': 'opportunitycreater',

    }, {
        'index': 5,
        'key': 'opportunity-orderOwner.firstName',
        'title': 'Order Owner',
        'componentType': 'lsitType',
        'rootVal': [],
        'url': 'orderowner',
        'count': 0,


    }];
    myDatePickerOptions: IMyOptions = {
        todayBtnTxt: 'Today',
        dateFormat: 'dd-mm-yyyy',
        firstDayOfWeek: 'mo',
        showClearDateBtn: false,
        sunHighlight: true,
        height: '32px',
        width: '210px',
        inline: false,
        // disableUntil: {year: 2016, month: 8, day: 10},
        selectionTxtFontSize: '14px'
    };
    public addidtionalsearch() {
        if (this.flag === 0) {
            this.flag = 1;
            //  this.fliterCmpLoad=true;
            //  this.searchElasticQuery(event);

        } else {
            this.flag = 0;
            this.page(0, this.limit);
        }
    }
    public changeEvent(eve) {

        const propname = this.FilterList[eve.num].key.split('-')[1];

        if (eve.data.checked) {
            this.filterData[propname].push(eve.data.fullVal.split(' ')[0].toString().toLowerCase());
        } else {
            this.filterData[propname] = this.filterData[propname].filter(val =>
                val !== eve.data.fullVal.split(' ')[0].toString().toLowerCase()
            );
        }

        this.Elasticsearchparams.query.bool.must = [];

        // Object.keys(this.filterData).map(key => {
        //  if (this.filterData[key].length > 0) {
        //   const obj = {
        //    'match': {}
        //   };
        //   obj.match[key] = this.filterData[key].toString();
        //   this.Elasticsearchparams.query.bool.must.push(obj);
        //  }
        // });

        Object.keys(this.filterData).map(item => {
            if (this.filterData[item].length > 0) {
                const obj = {
                    'bool': {
                        should: []
                    }
                };
                for (let j = 0; j < this.filterData[item].length; j++) {
                    const baseprefix = {
                        'prefix': {}
                    };
                    baseprefix.prefix[item] = this.filterData[item][j];
                    obj.bool.should.push(baseprefix);
                }
                this.Elasticsearchparams.query.bool.must.push(obj);
            }
        });

        this.FilterList[eve.num].count = eve.count;
        console.log(this.Elasticsearchparams);
        this.page(0, this.limit);
    }
    public clickReset(index) {
        const propname = this.FilterList[index].key.split('-')[1];
        this.filterData[propname] = [];
        this.Elasticsearchparams.query.bool.must = [];
        // Object.keys(this.filterData).map(key => {
        //  if (this.filterData[key].length > 0) {
        //   const obj = {
        //    'match': {}
        //   };
        //   obj.match[key] = this.filterData[key].toString();
        //   this.Elasticsearchparams.query.bool.must.push(obj);
        //  }
        // });
        Object.keys(this.filterData).map(item => {
            if (this.filterData[item].length > 0) {
                const obj = {
                    'bool': {
                        should: []
                    }
                };
                for (let j = 0; j < this.filterData[item].length; j++) {
                    const baseprefix = {
                        'prefix': {}
                    };
                    baseprefix.prefix[item] = this.filterData[item][j];
                    obj.bool.should.push(baseprefix);
                }
                this.Elasticsearchparams.query.bool.must.push(obj);
            }
        });

        this.page(0, this.limit);
        this.FilterList[index].count = 0;
    }
    constructor(public formBuilder: FormBuilder, public jbhGlobals: JBHGlobals) {
        this.favUrl = this.jbhGlobals.endpoints.opportunities.Arview;
    }
    public typeAheadSearchCall(eve) {
        if (eve.num === 2) {
            this.FilterList[eve.num]['params']['query']['bool']['should'][0]['multi_match']['query'] = eve.val + '*';
            this.FilterList[eve.num]['params']['from'] = 0;
            this.searchTypeAhead(this.jbhGlobals.endpoints.template[this.FilterList[eve.num].url], this.FilterList[eve.num].params, eve);
        }
        if (eve.num === 0 || eve.num === 1) {
            this.FilterList[eve.num]['params']['query']['nested']['query']['query_string']['query'] = eve.val + '*';
            // this.FilterList[eve.num]['params']['from'] = 0;
            this.searchTypeAhead(this.jbhGlobals.endpoints.template[this.FilterList[eve.num].url], this.FilterList[eve.num].params, eve);
        }
    }

    public searchTypeAhead(url, param, eve) {
        const me = this;
        me.jbhGlobals.apiService.addData(url, param).subscribe(data => {
            if (data) {
                if (eve.num === 2) {
                    const dataListLenght = data['hits']['hits'].length,
                        arr = [],
                        setData = eve.setDatda;
                    for (let i = 0; i < dataListLenght; i++) {
                        const obj = {
                            checked: false,
                            val: data['hits']['hits'][i]['_source']['OrganizationName'],
                            fullVal: data['hits']['hits'][i]['_source']['OrganizationName']
                        };
                        arr.push(obj);
                    }


                    setData(arr);
                } else if (eve.num === 0 || eve.num === 1) {
                    const dataListLenght = data['aggregations']['locations']['only_loc']['topinner']['buckets'].length,
                        arr = [],
                        setData = eve.setDatda;
                    for (let i = 0; i < dataListLenght; i++) {
                        const current = data['aggregations']['locations']['only_loc']['topinner']['buckets'][i];
                        const obj = {
                            checked: false,
                            val: current['key'] +
                                '(' + current['topacc_hits']['hits']['hits'][0]['_source']['locations']['StateCode'] + ')',
                            fullVal: current['key']
                        };
                        arr.push(obj);
                    }


                    setData(arr);
                }
            }
        });
    }
    ngOnInit() {
        this.page(this.offset, this.limit);
        this.arViewForm = this.formBuilder.group({

        });
    }
    page(offset, limit) {
        const from = offset * limit;
        const searchURL = this.favUrl + '?size=' + limit + '&from=' + from;
        console.log(searchURL);
        this.jbhGlobals.apiService.addData(searchURL, this.Elasticsearchparams).subscribe(data => {
            //this.jbhGlobals.apiService.getData(this.favUrl).subscribe(data => {
            this.totalRecordsCount = data['hits']['total'];
            this.rows = this.formatGridItems(data['hits']['hits']);
            //  for (let i = 0; i < data['hits']['hits'].length; i++)
            //  {
            //  this.rows['origin'] = data['hits']['hits'][i]['_source']['stopDTOs'][0];
            //  this.rows['destination'] =
            //	data['hits']['hits'][i]['_source']['stopDTOs'][data['hits']['hits'][i]['_source']['stopDTOs'].length - 1];
            //  }

        });
    }
    public onClickSiteProfileShow(comp) {
        this[comp].hide();
        // this.siteprofile.onShowSiteProfileModal();
    }
    onPage(event) {
        console.log('Page Event', event);
        this.page(event.offset, event.limit);
    }


    onActivate(event) {
        this.currentstatusValue =
            event.row._source.opportunityPostingWorkflowDTOs[event.row._source.opportunityPostingWorkflowDTOs.length - 1];
        if (event.row._source.opportunityStatusCode.toString().indexOf('Con') !== -1 &&
            this.currentstatusValue['opportunityPostingStatusCode'].toString().indexOf('Con') !== -1) {
            this.conditionwrapper = true;
        } else {
            this.conditionwrapper = false;
        }
        console.log('Activate Event', event);
        // this.currentstatusValue =event.row._source.opportunityPostingWorkflowDTOs.filter(
        //   val=>val.opportunityPostingStatusCode == event.row._source.opportunityStatusCode
        // )[0];
        //  this.rate=Math.round( event.row._source.desirabilityIndex/20 *2)/2;
        this.rate = Math.round(event.row._source.desirabilityIndex / 20);
        this.jbhdatatable.isDataTableDetailOpen = true;
        this.selected.splice(0, this.selected.length);
        this.selected.push(event.row);

        this.setUpKeyboardShortcuts();
    }
    HourCalculation(ExpireDate, str) {
        const timeStart = new Date().getTime();
        const timeEnd = new Date(ExpireDate).getTime();
        const hourDiff = timeEnd - timeStart; //in ms
        const minDiff = hourDiff / 60 / 1000; //in minutes
        const hDiff = hourDiff / 3600 / 1000; //in hours

        const hours = Math.floor(hDiff);
        const minutes = minDiff - 60 * hours;

        if (hours > 0) {
            if (str === '1') {
                return hours + ' hr ' + minutes.toFixed(0) + ' min ' + 'left';
            } else {
                return hours + ' hr ' + minutes.toFixed(0) + ' min ';
            }
        } else {
            return '';
        }
    }
    findDesirability(di) {
        di = parseInt(di);
        if (di === 13) {
            return 'Do Not Use';
        }
        if (di === 99) {
            return 'Missing Data';
        }
        if (di >= 1 && di <= 3) {
            return 'Recommended';
        } else if (di >= 4 && di <= 7) {
            return 'Fair';
        } else if (di >= 8 && di <= 10) {
            return 'Not Recommended';
        }
        return '';
    }

    formatGridItems(data) {
        function formatAddress(obj) {
            const temp = [];
            const final = [];
            temp.push(formatBracket(obj.partyName, obj.partyCode));
            final.push(temp.join(' '));
            final.push(obj.addressDTO.addressLineOne, obj.addressDTO.addressLineTwo, obj.addressDTO.city,
                obj.addressDTO.country, obj.addressDTO.state, obj.addressDTO.zipCode);
            console.log('bill to', obj, temp, final);
            return final.join(', ');
        }

        function formatService(serviceOfferingCode, transitMode, financeBusinessUnitCode) {
            const final = [];
            final.push(serviceOfferingCode, transitMode, financeBusinessUnitCode);
            console.log('Service');
            return final.join(' - ');
        }

        function formatBracket(name, code) {
            const bracketedCode = '(' + code + ')';
            console.log('Bracket');
            return name + ' ' + bracketedCode;
        }

        function formatStatus(status, date) {
            let hourstr, minstr, statusFinal;

            const timeStart = new Date().getTime();
            const timeEnd = new Date(date).getTime();
            if (timeEnd < timeStart) {
                return status;
            }
            const hourDiff = timeEnd - timeStart; //in ms
            const minDiff = hourDiff / 60 / 1000; //in minutes
            const hDiff = hourDiff / 3600 / 1000; //in hours

            const hours = Math.floor(hDiff);
            const minutes = Math.floor(minDiff - 60 * hours);

            if (hours > 1) {
                hourstr = ' hrs ';
            } else {
                hourstr = ' hr ';
            }
            if (minutes > 1) {
                minstr = ' mins';
            } else {
                minstr = ' min';
            }
            if (status === 'Available') {
                statusFinal = status + '\n';
            } else {
                return status;
            }
            return statusFinal + hours + hourstr + minutes + minstr + ' left';
        }

        function formatTenderRate(tenderRate, rateGuidance) {
            const currencyPipe = new CurrencyPipe('USD');
            const ntenderRate = currencyPipe.transform(tenderRate, 'USD', true);
            const nrateGuidance = currencyPipe.transform(rateGuidance, 'USD', true);
            console.log('Tender');
            return ntenderRate + '\n' + nrateGuidance;
        }

        function formatPickup(start, end, ship) {
            const datePipe = new DatePipe('en-US');
            let startdate = datePipe.transform(start, 'MM/dd');
            const starttime = datePipe.transform(start, 'h:mm a');
            let enddate = datePipe.transform(end, 'MM/dd');
            const endtime = datePipe.transform(end, 'h:mm a Z');
            if (ship) {
                startdate = datePipe.transform(start, 'yMMMd');
                enddate = datePipe.transform(end, 'yMMMd');
            }
            return startdate + ' - ' + enddate + '\n' + starttime + ' - ' + endtime;
        }

        function formatDelivery(start, end, ship) {
            const datePipe = new DatePipe('en-US');
            let startdate = datePipe.transform(start, 'MM/dd/yyyy');
            const starttime = datePipe.transform(start, 'h:mm a');
            let enddate = datePipe.transform(end, 'MM/dd/yyyy');
            const endtime = datePipe.transform(end, 'h:mm a Z');
            if (ship) {
                startdate = datePipe.transform(start, 'yMMMd');
                enddate = datePipe.transform(end, 'yMMMd');
            }
            return startdate + ' - ' + enddate + '\n' + starttime + ' - ' + endtime;
        }

        function formatHazmat(hazmat, highvalue) {
            const final = [];
            if (hazmat === 'true') {
                final.push('Hazmat');
            }
            if (highvalue === 'true') {
                final.push('High Value');
            }
            return final.join(', ');
        }
        const dataLen = data.length;
        for (let i = 0; i < dataLen; i++) {
            const stopLen = data[i]['_source']['stopDTOs'].length;
            /* Grid Data formatting */
            data[i]['_source']['newBillToProfile'] = formatAddress(data[i]['_source']['billToProfile']);
            data[i]['_source']['newOrigin'] = formatAddress(data[i]['_source']['stopDTOs'][0]['locationDTO']);
            data[i]['_source']['newDestination'] = formatAddress(data[i]['_source']['stopDTOs'][stopLen - 1]['locationDTO']);
            data[i]['_source']['newServiceOffering'] = formatService(data[i]['_source']['serviceOfferingCode'],
                data[i]['_source']['transitMode'],
                data[i]['_source']['financeBusinessUnitCode']);
            data[i]['_source']['newAssignedTo'] = formatBracket(data[i]['_source']['assignedTo']['firstName'],
                data[i]['_source']['assignedTo']['inits']);
            data[i]['_source']['newStatus'] = formatStatus(data[i]['_source']['opportunityStatusCode'], data[i]['_source']['expireTime']);
            data[i]['_source']['newPickup'] = formatPickup(data[i]['_source']['pickup']['appointmentDateTimeDetail']
                ['appointmentStartTimestamp'], data[i]['_source']['pickup']['appointmentDateTimeDetail']
                ['appointmentEndTimestamp'], false);
            data[i]['_source']['newPickupShip'] = formatPickup(data[i]['_source']['pickup']['appointmentDateTimeDetail']
                ['appointmentStartTimestamp'], data[i]['_source']['pickup']['appointmentDateTimeDetail']
                ['appointmentEndTimestamp'], true);
            data[i]['_source']['newDelivery'] = formatDelivery(data[i]['_source']['delivery']['appointmentDateTimeDetail']
                ['appointmentStartTimestamp'], data[i]['_source']['delivery']['appointmentDateTimeDetail']
                ['appointmentEndTimestamp'], false);
            data[i]['_source']['newDeliveryShip'] = formatDelivery(data[i]['_source']['delivery']['appointmentDateTimeDetail']
                ['appointmentStartTimestamp'], data[i]['_source']['delivery']['appointmentDateTimeDetail']
                ['appointmentEndTimestamp'], true);
            /* Other data formatting as required */
            data[i]['_source']['newHazmat'] = formatHazmat(data[i]['_source']['hazmatFlag'], data[i]['_source']['highValueIndicator']);
            data[i]['_source']['newOpportunityOwner'] = data[i]['_source']['opportunityPostingWorkflow']['opportunity']['opportunityOwner'];
            data[i]['_source']['newDesirabilityIndex'] =
                data[i]['_source']['opportunityPostingWorkflow']['opportunity']['desirabilityIndex'];
            data[i]['_source']['newTenderRate'] =
                formatTenderRate(data[i]['_source']['opportunityPostingWorkflow']['opportunity']['tenderRate'],
                    data[i]['_source']['opportunityPostingWorkflow']['opportunity']['rateGuidance']);
        }
        console.log(data);
        return data;
    }

    onSelect({
        selected
    }) {
        console.log('Select Event', selected, this.selected);
    }
    setUpKeyboardShortcuts() {
        this.jbhGlobals.shortkeys.getData().subscribe(data => {
            if (data.keyCode === 'ctrl+!' && this.jbhdatatable.isDataTableDetailOpen) {
                this.jbhdatatable.SplitViewTemplate.nativeElement.querySelector('.cancelkeystorke').focus();
            } else if (data.keyCode === 'Shift+S' && this.jbhdatatable.isDataTableDetailOpen) {
                this.jbhdatatable.SplitViewTemplate.nativeElement.querySelector('.clockkeystroke').focus();
            } else if (data.keyCode === 'Shift+I' && this.jbhdatatable.isDataTableDetailOpen) {
                this.jbhdatatable.SplitViewTemplate.nativeElement.querySelector('.availablekeystroke').focus();
            } else if (data.keyCode === 'Shift+C' && this.jbhdatatable.isDataTableDetailOpen) {
                this.jbhdatatable.SplitViewTemplate.nativeElement.querySelector('.circlekeystroke').focus();
            } else if (data.keyCode === 'Shift+O' && this.jbhdatatable.isDataTableDetailOpen) {
                this.jbhdatatable.SplitViewTemplate.nativeElement.querySelector('.pagekeystroke').focus();
            } else if (data.keyCode === 'Shift+O' && this.jbhdatatable.isDataTableDetailOpen) {
                this.jbhdatatable.SplitViewTemplate.nativeElement.querySelector('.shipmentkeystroke').focus();
            } else if ((data.keyCode === 'Escape' && this.jbhdatatable.isDataTableDetailOpen) ||
                (data.keyCode === 'ArrowLeft' && this.jbhdatatable.isDataTableDetailOpen)) {
                this.jbhdatatable.SplitViewTemplate.nativeElement.querySelector('.closekshortcut').focus();
            } else if (data.keyCode === 'ctrl+@' && this.jbhdatatable.isDataTableDetailOpen && this.conditionwrapper === true) {
                this.jbhdatatable.SplitViewTemplate.nativeElement.querySelector('.acceptkshortcut').focus();
            } else if (data.keyCode === 'ctrl+#' && this.jbhdatatable.isDataTableDetailOpen && this.conditionwrapper === true) {
                this.jbhdatatable.SplitViewTemplate.nativeElement.querySelector('.rejectkshortcut').focus();
            }
        });
    }
    /* Cleanup code goes here */
    onCleanup() {
        console.log('Cleanup Event');
    }
    cancelOPPClick() {
        const opportunityId = this.selected[0]._source.opportunityId;
        const canceloppURL = this.jbhGlobals.endpoints.opportunities.ar.cancelopportunity.replace('_id', opportunityId);
        this.jbhGlobals.apiService.patchData(canceloppURL, {}).subscribe(data => {
            console.log('cancelopportunities', data);
        });
    }
    Acceptopportunity() {
        const object = {
            opportunityPostingWorkflowId: this.selected[0]._source.opportunityPostingWorkflowDTOs[0].opportunityPostingWorkflowId,
            comment: this.selected[0]._source.opportunityPostingWorkflowDTOs[0].comment
        };
        const opportunityId = this.selected[0]._source.opportunityId;
        const AcceptopportunityURL = this.jbhGlobals.endpoints.opportunities.ar.acceptopportunity.replace('_id', opportunityId);

        this.jbhGlobals.apiService.patchData(AcceptopportunityURL +
            '?opportunityPostingWorkflowId=' +
            object.opportunityPostingWorkflowId +
            '&comment=' + object.comment + '', {}).subscribe(data => {
            console.log('Acceptopportunity', data);


        });

    }
    Rejectopportunity() {
        const object = {
            opportunityPostingWorkflowId: this.selected[0]._source.opportunityPostingWorkflowDTOs[0].opportunityPostingWorkflowId,
            comment: this.selected[0]._source.opportunityPostingWorkflowDTOs[0].comment
        };
        const opportunityId = this.selected[0]._source.opportunityId;
        const RejectopportunityURL = this.jbhGlobals.endpoints.opportunities.ar.rejectopportunity.replace('_id', opportunityId);
        this.jbhGlobals.apiService.patchData(RejectopportunityURL +
            '?opportunityPostingWorkflowId=' +
            object.opportunityPostingWorkflowId +
            '&comment=' + object.comment + '', object).subscribe(data => {
            console.log('RejectopportunityURL', data);
        });

    }
}
