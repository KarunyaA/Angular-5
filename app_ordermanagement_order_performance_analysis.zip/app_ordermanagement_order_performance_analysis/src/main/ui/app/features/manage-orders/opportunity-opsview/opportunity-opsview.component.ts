import { Component, ViewChild, OnInit } from '@angular/core';
import { IMyOptions } from 'mydatepicker';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DatePipe, CurrencyPipe } from '@angular/common';
// import { SiteProfileComponent } from '../../create-orders/orders/add-stops/stop-details/site-profile/site-profile.component';
import { JBHGlobals } from 'app/app.service';
import { JBHDataTableComponent } from 'app/shared/jbh-data-table/components/jbh-data-table.component';
import { ValidationService } from 'app/shared/jbh-validation/validation.service';


@Component({
  selector: 'app-opportunity-opsview',
  templateUrl: './opportunity-opsview.component.html',
  styleUrls: ['./opportunity-opsview.component.scss']
})
export class OpportunityOpsviewComponent implements OnInit {
    @ViewChild(JBHDataTableComponent) jbhdatatable: JBHDataTableComponent;
    @ViewChild('splitViewTemplateContainer') splitViewTemplateContainer;
//    @ViewChild(SiteProfileComponent) siteprofile: SiteProfileComponent;
    @ViewChild('billtoPopover') billtoPopover: any;
    @ViewChild('originPopover') originPopover: any;
    @ViewChild('destinationPopover') destinationPopover: any;
    rows: any[];
    selected = [];
    fleets: any[];
    totalRecordsCount = 0;
    offset = 0;
    limit = 5;
    favUrl = '';
    singleselect = true;
    showPickup = false;
    showDelivery = false;
    showRate = false;
    yesSelected = false;
    opsViewForm: FormGroup;
    selectedcount = 0;
    val = 1;
    flag = 0;
    filterTitle = 'Filter By';
    rate: any = 3;
    di = 0;
    fleetCodeList = [];
    // // Elasticsearchparams: any = {
    //   'query': {
    //     'bool': {
    //       'must': [
    //       ]
    //     }
    //   }
    // };
    Elasticsearchparams: any = {
        'query': {
            'bool': {
                'must': [{
                        'prefix': {
                            'opportunityPostingWorkflowDTOs.financeBusinessUnitCode': 'ics'
                        }
                    },
                    {
                        'prefix': {
                            'opportunityPostingWorkflowDTOs.serviceOfferingCode': 'jbt'
                        }
                    },
                    {
                        'prefix': {
                            'opportunityStatusCode': 'avai'
                        }
                    },
                    {
                        'prefix': {
                            'opportunityPostingWorkflowDTOs.opportunityPostingStatusCode': 'cond'
                        }
                    }
                ]
            }
        }
    };
    filterData: any = {
        'opportunityStatusCode': [],
        'origin.locationDTO.addressDTO.city': [],
        'destination.locationDTO.addressDTO.city': [],
        'billToProfile.partyName': [],
        'orderOwner.firstName': [],
        'opportunityCreator.firstName': [],
        'opportunityPostingWorkflowDTOs.financeBusinessUnitCode': ['ics'],
        'opportunityPostingWorkflowDTOs.serviceOfferingCode': ['jbt'],
        'opportunityPostingWorkflowDTOs.opportunityPostingStatusCode': ['cond']
    };



    public FilterList: any[] = [{
        'index': 0,
        'title': 'Origin',
        'key': 'opportunity-origin.locationDTO.addressDTO.city',
        'rootVal': ['aggregations', 'locations', 'only_loc', 'topinner', 'buckets'],
        'componentType': 'lsitType',
        // 'url': 'origin',
        'methodType': 'addData',
        'count': 0,
        'url': 'origin',
        'params': {
            '_source': false,
            'query': {
                'nested': {
                    'path': 'locations',
                    'query': {
                        'query_string': {
                            'default_field': 'locations.CityName',
                            'query': '*'
                        }
                    }
                }
            },

            'aggs': {
                'locations': {
                    'nested': {
                        'path': 'locations'
                    },
                    'aggs': {
                        'only_loc': {
                            'filter': {
                                'query_string': {
                                    'default_field': 'locations.CityName',
                                    'query': '*'
                                }
                            },

                            'aggs': {
                                'topinner': {
                                    'terms': {
                                        'field': 'locations.CityName.keyword'
                                    },
                                    'aggs': {
                                        'topacc_hits': {
                                            'top_hits': {
                                                'sort': [{
                                                    '_score': {
                                                        'order': 'desc'
                                                    }
                                                }],
                                                '_source': {
                                                    'includes': ['locations.StateCode']
                                                },
                                                'size': 1
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        //getLocationData

    }, {
        'index': 1,
        'key': 'opportunity-destination.locationDTO.addressDTO.city',
        'title': 'Destination',
        'rootVal': ['aggregations', 'locations', 'only_loc', 'topinner', 'buckets'],
        'componentType': 'lsitType',
        'count': 0,
        'url': 'destination',
        'methodType': 'addData',
        //'url': 'Orgintest',
        'params': {
            '_source': false,
            'query': {
                'nested': {
                    'path': 'locations',
                    'query': {
                        'query_string': {
                            'default_field': 'locations.CityName',
                            'query': '*'
                        }
                    }
                }
            },
            'aggs': {
                'locations': {
                    'nested': {
                        'path': 'locations'
                    },
                    'aggs': {
                        'only_loc': {
                            'filter': {
                                'query_string': {
                                    'default_field': 'locations.CityName',
                                    'query': '*'
                                }
                            },
                            'aggs': {
                                'topinner': {
                                    'terms': {
                                        'field': 'locations.CityName.keyword'
                                    },
                                    'aggs': {
                                        'topacc_hits': {
                                            'top_hits': {
                                                'sort': [{
                                                    '_score': {
                                                        'order': 'desc'
                                                    }
                                                }],
                                                '_source': {
                                                    'includes': ['locations.StateCode']
                                                },
                                                'size': 1
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

    }, {
        'index': 2,
        'key': 'opportunity-billToProfile.partyName',
        'title': 'Bill To Account',
        'count': 0,
        'rootVal': ['hits', 'hits'],
        'componentType': 'lsitType',
        'url': 'billto',
        'methodType': 'addData',
        'paginationSize': 2,
        'pagination': true,
        //'url': '',
        'params': {
            'size': 5,
            'from': 0,
            '_source': ['OrganizationName', 'PartyID'],
            'highlight': {
                'fields': {
                    '*': {}
                }
            },
            'query': {
                'bool': {
                    'should': [{
                        'multi_match': {

                            'fields': ['OrganizationName'],

                            'query': '*',
                            'type': 'phrase_prefix'
                        }
                    }],
                    'filter': {
                        'nested': {
                            'path': 'partyaddresses',
                            'query': {
                                'query_string': {
                                    'fields': ['partyaddresses.PartyRoleTypeDescription'],
                                    'query': 'BILL AND TO'
                                }
                            }

                        }
                    }
                }
            }
        }

    }, {
        'index': 3,
        'key': 'opportunity-opportunityStatusCode',
        'title': 'Status',
        'count': 0,
        'rootVal': ['_embedded', 'opportunityStatuses'],
        'componentType': 'lsitType',
        // 'url': 'opportunitystatus',
        'url': 'opportunitystatus',

    }, {
        'index': 4,
        'key': 'opportunity-opportunityCreator.firstName',
        'title': 'Opportunity Creator',
        'rootVal': [],
        'count': 0,
        'componentType': 'lsitType',
        'url': 'opportunitycreater',

    }, {
        'index': 5,
        'key': 'opportunity-orderOwner.firstName',
        'title': 'Order Owner',
        'componentType': 'lsitType',
        'rootVal': [],
        'url': 'orderowner',
        'count': 0,


    }];

    /* datepicker changes */
    myDatePickerOptions: IMyOptions = {
        todayBtnTxt: 'Today',
        dateFormat: 'dd-mm-yyyy',
        firstDayOfWeek: 'mo',
        showClearDateBtn: false,
        sunHighlight: true,
        height: '34px',
        width: '115px',
        inline: false,
        // disableUntil: {year: 2016, month: 8, day: 10},
        selectionTxtFontSize: '14px'
    };
    constructor(public formBuilder: FormBuilder, public jbhGlobals: JBHGlobals,
        private datePipe: DatePipe, private currencyPipe: CurrencyPipe) {
        /*this.favUrl = this.jbhGlobals.endpoints.opportunities.opsview;
        this.jbhGlobals.apiService.getData(this.favUrl).subscribe(data => {
          this.rows = data[0]['opsGrid'];
          this.rows = data;
          console.log(this.rows);

        }); */

        this.favUrl = this.jbhGlobals.endpoints.opportunities.opsview;
        /*this.jbhGlobals.apiService.addData(this.favUrl, object).subscribe(data => {
          this.rows = data['hits']['hits'];
          console.log(this.rows);
        });*/

        this.opsViewForm = this.formBuilder.group({});
    }


    ngOnInit() {
        this.page(this.offset, this.limit);
        /* this.opsViewForm = new FormGroup({
         });*/
        this.opsViewForm = this.formBuilder.group({
            pickupDate: ['', Validators.required],
            pickupTime: ['', Validators.compose([Validators.required, ValidationService.timeValidator])],
            deliveryDate: ['', Validators.required],
            deliveryTime: ['', Validators.compose([Validators.required, ValidationService.timeValidator])],
            requestedRate: ['', Validators.compose([Validators.required, ValidationService.rateValidator])],
            commentsOPS: ['', Validators.maxLength(1000)],
            assignedFleet: ['', Validators.required]
        });

        this.loadFleetCode();
    }
    public addidtionalsearch() {
        if (this.flag === 0) {
            this.flag = 1;
            //  this.fliterCmpLoad=true;
            //  this.searchElasticQuery(event);
        } else {
            this.flag = 0;
            this.page(0, this.limit);
        }
    }
    public changeEvent(eve) {
        const propname = this.FilterList[eve.num].key.split('-')[1];
        if (eve.data.checked) {
            this.filterData[propname].push(eve.data.fullVal.split(' ')[0].toString().toLowerCase());
        } else {
            this.filterData[propname] =
                this.filterData[propname].filter(val => val !== eve.data.fullVal.split(' ')[0].toString().toLowerCase());
        }

        this.Elasticsearchparams.query.bool.must = [];

        // Object.keys(this.filterData).map(key => {
        //  if (this.filterData[key].length > 0) {
        //   const obj = {
        //    'match': {}
        //   };
        //   obj.match[key] = this.filterData[key].toString();
        //   this.Elasticsearchparams.query.bool.must.push(obj);
        //  }
        // });
        Object.keys(this.filterData).map(item => {
            if (this.filterData[item].length > 0) {
                const obj = {
                    'bool': {
                        should: []
                    }
                };
                for (let j = 0; j < this.filterData[item].length; j++) {
                    const baseprefix = {
                        'prefix': {}
                    };
                    baseprefix.prefix[item] = this.filterData[item][j];
                    obj.bool.should.push(baseprefix);
                }
                this.Elasticsearchparams.query.bool.must.push(obj);
            }
        });

        this.FilterList[eve.num].count = eve.count;
        console.log(this.Elasticsearchparams);
        this.page(0, this.limit);

    }
    public clickReset(index) {

        const propname = this.FilterList[index].key.split('-')[1];
        this.filterData[propname] = [];
        this.Elasticsearchparams.query.bool.must = [];
        // Object.keys(this.filterData).map(key => {
        //  if (this.filterData[key].length > 0) {
        //   const obj = {
        //    'match': {}
        //   };
        //   obj.match[key] = this.filterData[key].toString();
        //   this.Elasticsearchparams.query.bool.must.push(obj);
        //  }
        // });
        Object.keys(this.filterData).map(item => {
            if (this.filterData[item].length > 0) {
                const obj = {
                    'bool': {
                        should: []
                    }
                };
                for (let j = 0; j < this.filterData[item].length; j++) {
                    const baseprefix = {
                        'prefix': {}
                    };
                    baseprefix.prefix[item] = this.filterData[item][j];
                    obj.bool.should.push(baseprefix);
                }
                this.Elasticsearchparams.query.bool.must.push(obj);
            }
        });

        this.page(0, this.limit);
        this.FilterList[index].count = 0;
    }
    public typeAheadSearchCall(eve) {
        if (eve.num === 2) {
            this.FilterList[eve.num]['params']['query']['bool']['should'][0]['multi_match']['query'] = eve.val + '*';
            this.FilterList[eve.num]['params']['from'] = 0;
            this.searchTypeAhead(this.jbhGlobals.endpoints.template[this.FilterList[eve.num].url], this.FilterList[eve.num].params, eve);
        }
        if (eve.num === 0 || eve.num === 1) {
            this.FilterList[eve.num]['params']['query']['nested']['query']['query_string']['query'] = eve.val + '*';
            // this.FilterList[eve.num]['params']['from'] = 0;
            this.searchTypeAhead(this.jbhGlobals.endpoints.template[this.FilterList[eve.num].url], this.FilterList[eve.num].params, eve);
        }
    }

    public searchTypeAhead(url, param, eve) {
        const me = this;
        me.jbhGlobals.apiService.addData(url, param).subscribe(data => {
            if (data) {
                if (eve.num === 2) {
                    const dataListLenght = data['hits']['hits'].length,
                        arr = [],
                        setData = eve.setDatda;
                    for (let i = 0; i < dataListLenght; i++) {
                        const obj = {
                            checked: false,
                            val: data['hits']['hits'][i]['_source']['OrganizationName'],
                            fullVal: data['hits']['hits'][i]['_source']['OrganizationName']
                        };
                        arr.push(obj);
                    }


                    setData(arr);
                } else if (eve.num === 0 || eve.num === 1) {
                    const dataListLenght = data['aggregations']['locations']['only_loc']['topinner']['buckets'].length,
                        arr = [],
                        setData = eve.setDatda;
                    for (let i = 0; i < dataListLenght; i++) {
                        const current = data['aggregations']['locations']['only_loc']['topinner']['buckets'][i];
                        const obj = {
                            checked: false,
                            val: current['key'] +
                                '(' + current['topacc_hits']['hits']['hits'][0]['_source']['locations']['StateCode'] + ')',
                            fullVal: current['key']
                        };
                        arr.push(obj);
                    }


                    setData(arr);
                }
            }
        });
    }

    toQueryString(obj) {
        let params = '?';
        if (obj) {
            for (const key in obj) {
                if (obj.hasOwnProperty(key)) {
                    params += key.toString() + '=' + obj[key] + '&';
                }
            }
            return params.slice(0, -1);
        }
    }

    isNotEmpty(control, key) {
        if (key === 'opportunityPostingWorkflowIds') {
            return true;
        } else {
            return !!control.value;
        }
    }

    acceptOpp(opsViewForm) {
        console.log(opsViewForm);
        const list = [];
        for (let i = 0; i < this.selected.length; i++) {

            list.push(this.selected[i]._source.opportunityId);

        }
        const obj = {
            comment: opsViewForm.controls['commentsOPS'].value,
            opportunityPostingWorkflowIds: list,
            fleetCode: opsViewForm.controls['assignedFleet'].value[0].text
        };

        if (!obj.comment) {
            delete obj.comment;
        }

        const qs = this.toQueryString(obj);
        const url = this.jbhGlobals.endpoints.opportunities.ops.acceptopportunity;
        this.jbhGlobals.apiService.patchData(url + qs, null).subscribe(data => {
            if (!this.jbhGlobals.utils.isEmpty(data)) {
                const selLen = this.selected.length;
                if (selLen === 1) {
                    this.jbhGlobals.notifications.success('Accepted', 'The Opportunity ' +
                        this.selected[0]._source.opportunityId + ' has been accepted');
                } else {
                    this.jbhGlobals.notifications.success('Accepted', selLen + ' Opportunities ' +
                        'were accepted');
                }
            } else {
                this.jbhGlobals.notifications.alert('Error', 'There was an error in accepting the Opportunity');
            }
        });
    }

    convertFormat24Hours(otime) {
        const time = otime.match(/(\d+):(\d+)\s*?(\w)/);
        let hours = Number(time[1]);
        const minutes = Number(time[2]);
        const seconds = 0;
        const ampm = time[3].toLowerCase();
        if (ampm === 'p' && hours < 12) {
            hours += 12;
        } else if (ampm === 'a' && hours === 12) {
            hours -= 12;
        }
        return {
            'hours': hours,
            'minutes': minutes,
            'seconds': seconds
        };
    }

    combineDate(date, time) {
        if (!!date && !!time) {
            const rtime = this.convertFormat24Hours(time);
            return new Date(date.value.jsdate.getFullYear(), date.value.jsdate.getMonth(), date.value.jsdate.getDate(),
                rtime.hours, rtime.minutes, rtime.seconds);
        } else {
            return null;
        }
    }

    conditionAccept(opsViewForm) {
        function formatObject(obj) {
            if (obj.pickup && obj.pickupTime) {
                const rdate = this.combineDate(obj.pickup, obj.pickupTime.value);
                console.log('rdate', rdate);
                obj.pickup = rdate.toISOString();
                delete obj['pickupTime'];
            }
            if (obj.delivery && obj.deliveryTime) {
                const rdate = this.combineDate(obj.delivery, obj.deliveryTime.value);
                console.log('rdate delivery', rdate);
                obj.delivery = rdate.toISOString();
                delete obj['deliveryTime'];
            }
            if (obj.rate) {
                obj.rate = obj.rate.value;
            }
            if (obj.fleetCode) {
                obj.fleetCode = obj.fleetCode.value[0].text;
            }
            if (obj.comment) {
                obj.comment = obj.comment.value;
            }
            return obj;
        }

        const list = [];
        for (let i = 0; i < this.selected.length; i++) {
            list.push(this.selected[i]._source.opportunityId);
        }

        const checkobj = {
            comment: opsViewForm.controls['commentsOPS'],
            opportunityPostingWorkflowIds: list,
            fleetCode: opsViewForm.controls['assignedFleet'],
            rate: opsViewForm.controls['requestedRate'],
            pickup: opsViewForm.controls['pickupDate'],
            delivery: opsViewForm.controls['deliveryDate'],
            pickupTime: opsViewForm.controls['pickupTime'],
            deliveryTime: opsViewForm.controls['deliveryTime']
        };

        if (this.yesSelected && !this.showPickup && !this.showDelivery && !this.showRate) {
            this.jbhGlobals.notifications.alert('Error', 'Choose at least one Condition');
            return;
        }
        if (this.yesSelected &&
            this.validatePickup(checkobj.pickup, checkobj.pickupTime) &&
            this.validateDelivery(checkobj.delivery, checkobj.deliveryTime) &&
            this.validateRate(checkobj.rate)) {

            console.log(opsViewForm);

            let obj = {};

            for (const key in checkobj) {
                if (this.isNotEmpty(checkobj[key], key)) {
                    obj[key] = checkobj[key];
                }
            }
            const that = this;
            obj = formatObject.call(that, obj);
            console.log('after format', obj);

            if (obj.hasOwnProperty('pickup') && !this.isDateValid(checkobj.pickup, checkobj.pickupTime)) {
                this.jbhGlobals.notifications.alert('Error', 'Please check the Pickup Date');
                return;
            }

            if (obj.hasOwnProperty('delivery') && !this.isDateValid(checkobj.delivery, checkobj.deliveryTime)) {
                this.jbhGlobals.notifications.alert('Error', 'Please check the Delivery Date');
                return;
            }

            if (obj.hasOwnProperty('pickup') && obj.hasOwnProperty('delivery')) {
                if (!this.isDatesValid(this.combineDate(checkobj.pickup, checkobj.pickupTime.value),
                        this.combineDate(checkobj.delivery, checkobj.deliveryTime.value))) {
                    this.jbhGlobals.notifications.alert('Error', 'Deliver date to be greater than Pickup date');
                    return;
                }
            }

            const qs = this.toQueryString(obj);
            const url = this.jbhGlobals.endpoints.opportunities.ops.conditionallyaccept;

            this.jbhGlobals.apiService.patchData(url + qs, null).subscribe(data => {
                console.log('conditionAccept', data);
                if (!this.jbhGlobals.utils.isEmpty(data)) {
                    const selLen = this.selected.length;
                    if (selLen === 1) {
                        this.jbhGlobals.notifications.success('Conditionally Accepted', 'The Opportunity ' +
                            this.selected[0]._source.opportunityId + ' has been Conditionally Accepted');
                    } else {
                        this.jbhGlobals.notifications.success('Conditionally Accepted', selLen + ' Opportunities ' +
                            'were Conditionally accepted');
                    }
                } else {
                    this.jbhGlobals.notifications.alert('Error', 'There was an error in Conditionally Accepting the Opportunity');
                }
            });
        } else {
            this.jbhGlobals.notifications.alert('Error', 'One or more fields are not valid');
        }
    }

    rejectOpp(opsViewForm) {
        const list = [];
        for (let i = 0; i < this.selected.length; i++) {
            list.push(this.selected[i]._source.opportunityId);
        }
        const obj = {
            opportunityPostingWorkflowIds: list,
        };
        const qs = this.toQueryString(obj);
        const url = this.jbhGlobals.endpoints.opportunities.ops.rejectopportunity;
        this.jbhGlobals.apiService.patchData(url + qs, null).subscribe(data => {
            if (!this.jbhGlobals.utils.isEmpty(data)) {
                const listlen = list.length;
                if (listlen === 1) {
                    this.jbhGlobals.notifications.success('Rejected', 'The Opportunity ' + list + ' was rejected');
                } else {
                    this.jbhGlobals.notifications.success('Rejected', listlen + ' Opportunities were rejected');
                }
            } else {
                this.jbhGlobals.notifications.alert('Error', 'There was an error in rejecting the Opportunity');
            }
        });
    }

    validateConditions() {
        if (this.validatePickup(this.opsViewForm.controls['pickupDate'], this.opsViewForm.controls['pickupTime']) &&
            this.validateDelivery(this.opsViewForm.controls['deliveryDate'], this.opsViewForm.controls['deliveryTime']) &&
            this.validateRate(this.opsViewForm.controls['requestedRate']) &&
            this.opsViewForm.controls['assignedFleet'].valid) {
            return true;
        } else {
            return false;
        }
    }
    validatePickup(date, time) {
        if (this.showPickup) {
            if (date.valid && time.valid) {
                return true;
            } else {
                return false;
            }
        } else {
            return true;
        }
    }

    validateDelivery(date, time) {
        if (this.showDelivery) {
            if (date.valid && time.valid) {
                return true;
            } else {
                return false;
            }
        } else {
            return true;
        }
    }

    validateRate(rate) {
        if (this.showRate) {
            if (rate.valid) {
                return true;
            } else {
                return false;
            }
        } else {
            return true;
        }
    }

    isDatesValid(cpickup, cdelivery) {
        if (!!cpickup && !!cdelivery) {
            console.log(cdelivery.getTime(), cpickup.getTime());
            return (cdelivery.getTime() - cpickup.getTime() >= 0);
        } else {
            return false;
        }
    }

    isDateValid(date, time) {
        const cdate = this.combineDate(date, time.value);
        console.log('Dater', cdate, time.value);
        const today = new Date();
        if (cdate.getTime() - today.getTime() >= 0) {
            return true;
        } else {
            return false;
        }
    }

    findDesirability(di) {
        di = parseInt(di);
        if (di === 13) {
            return 'Do Not Use';
        }
        if (di === 99) {
            return 'Missing Data';
        }
        if (di >= 1 && di <= 3) {
            return 'Recommended';
        } else if (di >= 4 && di <= 7) {
            return 'Fair';
        } else if (di >= 8 && di <= 10) {
            return 'Not Recommended';
        }
        return '';
    }

    page(offset, limit) {
        offset = offset * limit;
        limit = limit;
        const params = {
            'from': offset,
            'size': limit
        };
        this.favUrl += '?size=' + params.size + '&from=' + params.from;
        this.jbhGlobals.apiService.addData(this.favUrl, this.Elasticsearchparams).subscribe(data => {
            //this.totalRecordsCount = data['totalElements'];

            //        	const start = offset * limit;
            //        	const end = start + limit;
            //        	const rows = [...this.rows];

            //	          for (let i = start; i < end; i++) {
            //	            rows[i] = data[i];
            //	          }

            //this.rows = data['content'];
            this.totalRecordsCount = data['hits']['total'];

            this.rows = this.formatGridItems(data['hits']['hits']);
            // console.log('Page Results', start, end, rows);
        });
    }

    formatGridItems(data) {
        function formatAddress(obj) {
            const temp = [];
            const final = [];
            temp.push(formatBracket(obj.partyName, obj.partyCode));
            final.push(temp.join(' '));
            final.push(obj.addressDTO.addressLineOne, obj.addressDTO.addressLineTwo, obj.addressDTO.city,
                obj.addressDTO.country, obj.addressDTO.state, obj.addressDTO.zipCode);
            console.log('bill to', obj, temp, final);
            return final.join(', ');
        }

        function formatService(serviceOfferingCode, transitMode, financeBusinessUnitCode) {
            const final = [];
            final.push(serviceOfferingCode, transitMode, financeBusinessUnitCode);
            console.log('Service');
            return final.join(' - ');
        }

        function formatBracket(name, code) {
            const bracketedCode = '(' + code + ')';
            console.log('Bracket');
            return name + ' ' + bracketedCode;
        }

        function formatExpireTime(date) {
            let hourstr, minstr;
            const timeStart = new Date().getTime();
            const timeEnd = new Date(date).getTime();
            if (timeEnd < timeStart) {
                return '';
            }
            const hourDiff = timeEnd - timeStart; //in ms
            const minDiff = hourDiff / 60 / 1000; //in minutes
            const hDiff = hourDiff / 3600 / 1000; //in hours

            const hours = Math.floor(hDiff);
            const minutes = Math.floor(minDiff - 60 * hours);

            if (hours > 1) {
                hourstr = ' hrs ';
            } else {
                hourstr = ' hr ';
            }
            if (minutes > 1) {
                minstr = ' mins';
            } else {
                minstr = ' min';
            }
            return hours + hourstr + minutes + minstr;
        }

        function formatTenderRate(tenderRate, rateGuidance) {
            const currencyPipe = new CurrencyPipe('USD');
            const ntenderRate = currencyPipe.transform(tenderRate.toLocaleString(), 'USD', true);
            const nrateGuidance = currencyPipe.transform(rateGuidance.toLocaleString(), 'USD', true);
            console.log('Tender');
            return ntenderRate + '\n' + nrateGuidance;
        }

        function formatPickup(start, end, ship) {
            const datePipe = new DatePipe('en-US');
            let startdate = datePipe.transform(start, 'MM/dd');
            const starttime = datePipe.transform(start, 'h:mm a');
            let enddate = datePipe.transform(end, 'MM/dd');
            const endtime = datePipe.transform(end, 'h:mm a Z');
            if (ship) {
                startdate = datePipe.transform(start, 'yMMMd');
                enddate = datePipe.transform(end, 'yMMMd');
            }
            return startdate + ' - ' + enddate + '\n' + starttime + ' - ' + endtime;
        }

        function formatDelivery(start, end, ship) {
            const datePipe = new DatePipe('en-US');
            let startdate = datePipe.transform(start, 'MM/dd/yyyy');
            const starttime = datePipe.transform(start, 'h:mm a');
            let enddate = datePipe.transform(end, 'MM/dd/yyyy');
            const endtime = datePipe.transform(end, 'h:mm a Z');
            if (ship) {
                startdate = datePipe.transform(start, 'yMMMd');
                enddate = datePipe.transform(end, 'yMMMd');
            }
            return startdate + ' - ' + enddate + '\n' + starttime + ' - ' + endtime;
        }

        function formatHazmat(hazmat, highvalue) {
            const final = [];
            if (hazmat === 'true') {
                final.push('Hazmat');
            }
            if (highvalue === 'true') {
                final.push('High Value');
            }
            return final.join(', ');
        }
        const dataLen = data.length;
        for (let i = 0; i < dataLen; i++) {
            const stopLen = data[i]['_source']['stopDTOs'].length;
            /* Grid Data formatting */
            data[i]['_source']['newBillToProfile'] = formatAddress(data[i]['_source']['billToProfile']);
            data[i]['_source']['newOrigin'] = formatAddress(data[i]['_source']['stopDTOs'][0]['locationDTO']);
            data[i]['_source']['newDestination'] = formatAddress(data[i]['_source']['stopDTOs'][stopLen - 1]['locationDTO']);
            data[i]['_source']['newServiceOffering'] = formatService(data[i]['_source']['serviceOfferingCode'],
                data[i]['_source']['transitMode'],
                data[i]['_source']['financeBusinessUnitCode']);
            data[i]['_source']['newAssignedTo'] = formatBracket(data[i]['_source']['assignedTo']['firstName'],
                data[i]['_source']['assignedTo']['inits']);
            data[i]['_source']['newExpireTime'] = formatExpireTime(data[i]['_source']['expireTime']);
            data[i]['_source']['newPickup'] = formatPickup(data[i]['_source']['pickup']['appointmentDateTimeDetail']
                ['appointmentStartTimestamp'], data[i]['_source']['pickup']['appointmentDateTimeDetail']
                ['appointmentEndTimestamp'], false);
            data[i]['_source']['newPickupShip'] = formatPickup(data[i]['_source']['pickup']['appointmentDateTimeDetail']
                ['appointmentStartTimestamp'], data[i]['_source']['pickup']['appointmentDateTimeDetail']
                ['appointmentEndTimestamp'], true);
            data[i]['_source']['newDelivery'] = formatDelivery(data[i]['_source']['delivery']['appointmentDateTimeDetail']
                ['appointmentStartTimestamp'], data[i]['_source']['delivery']['appointmentDateTimeDetail']
                ['appointmentEndTimestamp'], false);
            data[i]['_source']['newDeliveryShip'] = formatDelivery(data[i]['_source']['delivery']['appointmentDateTimeDetail']
                ['appointmentStartTimestamp'], data[i]['_source']['delivery']['appointmentDateTimeDetail']
                ['appointmentEndTimestamp'], true);
            /* Other data formatting as required */
            data[i]['_source']['newHazmat'] =
                formatHazmat(data[i]['_source']['hazmatFlag'], data[i]['_source']['highValueIndicator']);
            data[i]['_source']['newOpportunityOwner'] =
                data[i]['_source']['opportunityPostingWorkflow']['opportunity']['opportunityOwner'];
            data[i]['_source']['newDesirabilityIndex'] =
                data[i]['_source']['opportunityPostingWorkflow']['opportunity']['desirabilityIndex'];
            data[i]['_source']['newTenderRate'] =
                formatTenderRate(data[i]['_source']['opportunityPostingWorkflow']['opportunity']['tenderRate'],
                    data[i]['_source']['opportunityPostingWorkflow']['opportunity']['rateGuidance']);
        }
        console.log(data);
        return data;
    }
    public onClickSiteProfileShow(comp) {
        this[comp].hide();
        // this.siteprofile.onShowSiteProfileModal();
    }
    onPage(event) {
        console.log('Page Event', event);
        this.page(event.offset, event.limit);
    }

    onActivate(event) {
        console.log('after COnverted', this.di);
        if (this.selected) {
            if (this.selected.length > 1) {
                this.singleselect = false;
            } else {
                this.singleselect = true;
            }
        }
        console.log('Activate Event', this.selected, event);
        if (event.type === 'click' && event.column.name !== 'checkboxedCol' && this.selected.length <= 1) {
            this.selected.splice(0, this.selected.length);
            this.selected.push(event.row);
            this.onCleanup();
            this.jbhdatatable.isDataTableDetailOpen = true;
            this.flag = 0;
        } else if (event.type === 'click' && event.column.name === 'checkboxedCol') {

            this.jbhdatatable.isDataTableDetailOpen = false;
            this.onCleanup();
            this.flag = 0;
        }
        this.setUpKeyboardShortcuts();
    }

    onSelect({
        selected
    }) {
        console.log('Select Event', selected, this.selected);
    }

    onSelectPrefix(value): void {
        // console.log(value);
    }

    onRemovePrefix(value: any): void {
        // console.log(value);
    }


    onTypePrefix(event): void {
        // console.log(event);
    }

    refreshValue(value: any): void {
        // console.log(value);
    }

    onDataPrefix(value) {
        console.log(value);
    }

    setUpKeyboardShortcuts() {
        this.jbhGlobals.shortkeys.getData().subscribe(data => {
            if (data.keyCode === 'ctrl+$' && this.jbhdatatable.isDataTableDetailOpen && this.yesSelected === true) {
                this.jbhdatatable.SplitViewTemplate.nativeElement.querySelector('.conditionalkeystorke').focus();
            } else if (data.keyCode === 'Shift+S' && this.jbhdatatable.isDataTableDetailOpen) {
                this.jbhdatatable.SplitViewTemplate.nativeElement.querySelector('.clockkeystroke').focus();
            } else if (data.keyCode === 'Shift+I' && this.jbhdatatable.isDataTableDetailOpen) {
                this.jbhdatatable.SplitViewTemplate.nativeElement.querySelector('.availablekeystroke').focus();
            } else if (data.keyCode === 'Shift+C' && this.jbhdatatable.isDataTableDetailOpen) {
                this.jbhdatatable.SplitViewTemplate.nativeElement.querySelector('.circlekeystroke').focus();
            } else if (data.keyCode === 'Shift+O' && this.jbhdatatable.isDataTableDetailOpen) {
                this.jbhdatatable.SplitViewTemplate.nativeElement.querySelector('.pagekeystroke').focus();
            } else if (data.keyCode === 'Shift+O' && this.jbhdatatable.isDataTableDetailOpen && this.singleselect === true) {
                this.jbhdatatable.SplitViewTemplate.nativeElement.querySelector('.shipmentkeystroke').focus();
            } else if ((data.keyCode === 'Escape' && this.jbhdatatable.isDataTableDetailOpen) ||
                (data.keyCode === 'ArrowLeft' && this.jbhdatatable.isDataTableDetailOpen)) {
                this.jbhdatatable.SplitViewTemplate.nativeElement.querySelector('.closekshortcut').focus();
            } else if (data.keyCode === 'ctrl+@' && this.jbhdatatable.isDataTableDetailOpen && this.yesSelected === false) {
                this.jbhdatatable.SplitViewTemplate.nativeElement.querySelector('.acceptkshortcut').focus();
            } else if (data.keyCode === 'ctrl+#' && this.jbhdatatable.isDataTableDetailOpen) {
                this.jbhdatatable.SplitViewTemplate.nativeElement.querySelector('.rejectkshortcut').focus();
            }
        });
    }
    /* Cleanup code goes here */
    onCleanup() {
        console.log('Cleanup Event');
        this.yesSelected = false;
        this.showPickup = false;
        this.showDelivery = false;
        this.showRate = false;
        this.opsViewForm.reset();
    }

    resetPickup(event) {
        if (!event.target.checked) {
            this.opsViewForm.controls['pickupDate'].reset();
            this.opsViewForm.controls['pickupTime'].reset();
        }
    }

    resetDelivery(event) {
        if (!event.target.checked) {
            this.opsViewForm.controls['deliveryDate'].reset();
            this.opsViewForm.controls['deliveryTime'].reset();
        }
    }

    resetRate(event) {
        if (!event.target.checked) {
            this.opsViewForm.controls['requestedRate'].reset();
        }
    }

    public loadFleetCode(): void {
        const businessUnitValue = 'OCR';
        const params = {
            'businessunit': businessUnitValue
        };
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getfleetcode, params).subscribe(data => {
            const options = [];
            for (const opt of data) {
                const obj = {
                    'name': '',
                    'id': '',
                    'text': ''
                };
                obj.name = opt['description'];
                obj.id = opt['id'];
                obj.text = obj.name;
                options.push(obj);
            }
            this.fleetCodeList = options;
        });
    }

    remove(index) {
        console.log(index);
        this.selected.splice(index, 1);
        if (this.selected.length === 1) {
            this.singleselect = true;
        }
    }

}
