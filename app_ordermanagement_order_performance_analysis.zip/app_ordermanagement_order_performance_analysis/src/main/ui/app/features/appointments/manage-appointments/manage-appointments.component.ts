import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { JBHGlobals } from '../../../app.service';
import { TabsetComponent } from 'ngx-bootstrap';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { SetAppointmentComponent } from '../set-appointment/set-appointment.component';

@Component({
    selector: 'app-manage-appointments',
    templateUrl: './manage-appointments.component.html',
    styleUrls: ['./manage-appointments.component.scss']
})
export class ManageAppointmentsComponent implements OnInit {
    @ViewChild('appointments') setTab: TabsetComponent;
    @ViewChild('emailContent') emailContent: ElementRef;
    @ViewChild('SetAppointmentComponent') getFormDetails: SetAppointmentComponent;
    @ViewChild('previewModalForText') public previewModalForText: ModalDirective;
    @ViewChild('previewModalForEmail') public previewModalForEmail: ModalDirective;
    public highlightedStep: number;
    public flag: number;
    public hideTab: boolean = true;
    public setWebsite: boolean = false;
    public setEmail: boolean = false;
    public setPhone: boolean = false;
    public setText: boolean = false;
    public buttonData: string;
    public textValue: string;
    public clicked: boolean;
    public orderTrackingNumber: any[] = [];
    public addMessage: any;
    public AppointmentReason: any = [];
    public addedContact: any[] = [];
    public reason: any = [];
    public workNumber: Number;
    public mobNumber: Number;
    public firstCallPurpose: any;
    public secondCallPurpose: any;
    public callDir1: any;
    public callDir2: any;
    public callResult: any;
    public addAnotherContact: FormGroup;
    public callRecording: FormGroup;
    public emailForm: FormGroup;
    public textForm: FormGroup;
    public callForm: FormGroup;
    public addContactHeading: boolean = true;
    public alternateContactField: boolean = false;
    public setWrongSelectReasonCategory: boolean = false;
    public setWrongSelectReasonSetting: boolean = false;
    public setWrongSelectToName: boolean = false;
    public resultOfCall: any[] = [];
    public callDirection: any[] = [];
    public purposeOfCall: any[] = [];
    public result: any;
    public direction: any;
    public purpose: any;
    public orderNumber: number;
    public setWrongSelectPurpose: boolean = false;
    public setWrongSelectDirection: boolean = false;
    public setWrongSelectResult: boolean = false;


    public toNames: any = ['Stronburn', 'xczxcz', 'xczsdadasd', 'erwrwe'];
    public toName: any;
    constructor(public jbhGlobals: JBHGlobals, public formBuilder: FormBuilder) {
        this.highlightedStep = 1;
    }
    ngOnInit() {
        this.reasonSetting();
        this.emailPreview();
        this.appointmentReason();

        this.serviceCall();
        this.phoneCall();
        this.addAnotherContact = this.formBuilder.group({
            contactName: ['', Validators.required],
            contactNumber: ['']
        });
        this.addedContact.push({
            'contactName': 'John Smith',
            'contactNumber': 321321
        });

    }
    public serviceCall() {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.appointments.recommendedAppointmentTimeStamp).subscribe(data => {
            console.log(data[0]['recommendedAppointmentTimeStamp']);

        });

    }

    public phoneCall() {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.appointments.getCallDetails).subscribe(data => {
            console.log(data);
            for (let i = 0; i < data[1]['callReason'].length; i++) {
                this.purposeOfCall.push(data[1]['callReason'][i].type);
            }
            for (let i = 0; i < data[2]['callDirection'].length; i++) {
                this.callDirection.push(data[2]['callDirection'][i].type);
            }
            for (let i = 0; i < data[3]['callResult'].length; i++) {
                this.resultOfCall.push(data[3]['callResult'][i].type);
            }
            this.workNumber = data[0]['work'];
            this.mobNumber = data[0]['mobile'];
        });
        this.callRecording = this.formBuilder.group({
            callPurpose: '',
            callDirection: '',
            callResult: ''
        });

    }

    onActivateTab(a) {
        this.hideTab = false;
        if (a === 'setAppointmentCancel') {
            console.log();
            this.hideTab = true;
            this.setTab.tabs[0].active = true;
        }
        this.buttonData = a;
        if (this.buttonData === 'Website') {
            this.setWebsite = true;
            this.setEmail = false;
            this.setPhone = false;
            this.setText = false;
        } else if (this.buttonData === 'Email') {
            this.setEmail = true;
            this.setWebsite = false;
            this.setPhone = false;
            this.setText = false;
        } else if (this.buttonData === 'Phone') {
            this.setPhone = true;
            this.setWebsite = false;
            this.setEmail = false;
            this.setText = false;
        } else if (this.buttonData === 'Text') {
            this.setText = true;
            this.setWebsite = false;
            this.setEmail = false;
            this.setPhone = false;
        }
    }

    showStep(newValue: number) {
        this.highlightedStep = newValue;
    }

    removeContact(i) {
        console.log(JSON.stringify(this.addedContact));

        this.addedContact.splice(i, 1);
        if (this.addedContact.length === 0) {
            if (this.alternateContactField === true) {
                this.addContactHeading = true;
            } else {
                this.addContactHeading = false;
            }
            this.addAnotherContact.setValue({
                'contactName': ' ',
                'contactNumber': null
            });
        }

    }

    clearValue() {
        this.addAnotherContact.setValue({
            'contactName': ' ',
            'contactNumber': null
        });
    }

    focusContactNumber(event) {
        event.target.nextElementSibling.focus();
    }

    addContactList(event) {
        const nameNull = (this.addAnotherContact.value.contactName === null);
        const nameSpace = (this.addAnotherContact.value.contactName === ' ');
        const nameNospace = (this.addAnotherContact.value.contactName === '');
        const numberNull = (this.addAnotherContact.value.contactNumber === null);
        const numberSpace = (this.addAnotherContact.value.contactNumber === ' ');
        const numberNospace = (this.addAnotherContact.value.contactNumber === '');

        const contactNameNullFlag = (nameNull || nameNospace || nameSpace);
        const contactNumberNullFlag = (numberNull || numberNospace || numberSpace);

        console.log(contactNameNullFlag);
        console.log(contactNumberNullFlag);
        if (contactNameNullFlag || contactNumberNullFlag) {
            this.addContactHeading = true;
            this.alternateContactField = true;
        } else if (this.addAnotherContact.value.contactName !== ' ' && this.addAnotherContact.value.contactNumber !== null) {

            if (this.addedContact.length === 0) {
                this.addedContact.push(this.addAnotherContact.value);
                this.addAnotherContact.setValue({
                    'contactName': ' ',
                    'contactNumber': null
                });
                this.addContactHeading = true;
            } else {
                const name = this.addAnotherContact.value.contactName;
                const contactNumber = this.addAnotherContact.value.contactNumber;
                const lastName = this.addedContact[this.addedContact.length - 1].contactName;
                const lastNumber = this.addedContact[this.addedContact.length - 1].contactNumber;

                const contactNameValueFlag = (name === lastName);
                const contactNumberValueFlag = (contactNumber === lastNumber);

                if (!(contactNameValueFlag && contactNumberValueFlag)) {
                    this.addedContact.push(this.addAnotherContact.value);
                    this.addAnotherContact.setValue({
                        'contactName': ' ',
                        'contactNumber': null
                    });
                    this.addContactHeading = true;
                }
            }
        } else if (this.addedContact.length === 0) {
            this.addContactHeading = false;
        }
    }

    public preview() {
        this.clicked = true;
        console.log(this.emailContent.nativeElement.value);
        this.textValue = this.emailContent.nativeElement.value;
    }
    public reasonSetting() {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.appointments.appointmentReasonSetting).subscribe(data => {
            console.log(data['_embedded']['appointmentSetReasons'][0]['appointmentSetReasonDescription']);
            for (let i = 0; i < data['_embedded']['appointmentSetReasons'].length; i++) {
                this.AppointmentReason.push(data['_embedded']['appointmentSetReasons'][i]['appointmentSetReasonDescription']);
            }
            console.log(this.AppointmentReason);
        });
    }
    public sendEmailText() {
        this.hideTab = true;
        console.log(this.orderNumber);
        console.log(this.orderTrackingNumber);
    }
    public cancel() {
        this.hideTab = true;
    }
    public setCancel() {
        this.hideTab = true;
        this.setTab.tabs[0].active = true;
    }
    getFormData() {
        this.getFormDetails.myFunc();
    }
    public emailPreview() {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.appointments.getEmailPreview).subscribe(data => {
            this.orderTrackingNumber = data['orderTrackingNumber'];
            this.orderNumber = data['orderNumber'];
            this.addMessage = data['Add Custom Message'];
            console.log(this.addMessage);
        });
        this.emailForm = new FormGroup({
            reasonForSetting: new FormControl('', [Validators.required]),
            appointmentReason: new FormControl('', [Validators.required]),
            toName: new FormControl('', [Validators.required])
        });
        this.textForm = new FormGroup({
            reasonForSetting: new FormControl('', [Validators.required]),
            appointmentReason: new FormControl('', [Validators.required]),
            toName: new FormControl('', [Validators.required])
        });

    }
    public onToNameTagSelection(event, booleanValue) {
        this.toName = event.text;
        this.setWrongSelectToName = false;
    }
    public onReasonSettingTagSelection(event, booleanValue) {
        console.log(event);
        this.setWrongSelectReasonSetting = false;
    }
    public onReasonCategoryTagSelection(event, booleanValue) {
        console.log(event);
        this.setWrongSelectReasonCategory = false;
    }
    public appointmentReason() {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.appointments.getAppointmentReason).subscribe(data => {
            console.log(data['_embedded']['appointmentSetReasonCategories'][0]['appointmentSetReasonCategoryDescription']);
            for (let i = 0; i < data['_embedded']['appointmentSetReasonCategories'].length; i++) {
                this.reason.push(data['_embedded']['appointmentSetReasonCategories'][i]['appointmentSetReasonCategoryDescription']);
            }
        });
    }
    public showPreviewModalForText() {
        this.previewModalForText.show();
    }
    public hidePreviewModalForText() {
        this.previewModalForText.hide();
    }
    public showPreviewModalForEmail() {
        this.previewModalForEmail.show();
    }
    public hidePreviewModalForEmail() {
        this.previewModalForEmail.hide();
    }
    public getPhoneData() {
        console.log(this.callRecording.value);
        console.log(this.direction);
        console.log(this.purpose);
        console.log(this.result);
    }
    public typedReasonCategory(typedWord) {
        console.log(typedWord);
        for (let i = 0; i < this.reason.length; i++) {
            if (typedWord !== this.reason[i]) {
                this.setWrongSelectReasonCategory = true;
            }
        }
    }
    public typedReasonForSetting(typedWord) {
        for (let i = 0; i < this.AppointmentReason.length; i++) {
            if (typedWord !== this.AppointmentReason[i]) {
                this.setWrongSelectReasonSetting = true;
            }
        }
    }
    public typedToName(typedWord) {
        for (let i = 0; i < this.toNames.length; i++) {
            if (typedWord !== this.toNames) {
                this.setWrongSelectToName = true;
            }
        }
    }
    public typedPurposeOfCall(typedWord) {
        for (let i = 0; i < this.purposeOfCall.length; i++) {
            if (typedWord !== this.purposeOfCall) {
                this.setWrongSelectPurpose = true;
            }
        }
    }
    public typedCallDirection(typedWord) {
        for (let i = 0; i < this.callDirection.length; i++) {
            if (typedWord !== this.callDirection) {
                this.setWrongSelectDirection = true;
            }
        }
    }
    public typedResultOfCall(typedWord) {
        for (let i = 0; i < this.resultOfCall.length; i++) {
            if (typedWord !== this.resultOfCall) {
                this.setWrongSelectResult = true;
            }
        }
    }
    public onPurposeOfCallSelect(i) {
        this.purpose = i.text;
        console.log(this.purpose);
        this.setWrongSelectPurpose = false;
    }
    public onCallDirectionSelect(i) {
        this.direction = i.text;
        this.setWrongSelectDirection = false;
    }
    public onResultOfCallSelect(i) {
        this.result = i.text;
        this.setWrongSelectDirection = false;
    }
}
