import { Component, OnInit, EventEmitter, Output, ViewChild, ElementRef } from '@angular/core';
import { IMyOptions, IMyDateModel } from 'mydatepicker';
import { JBHGlobals } from '../../../app.service';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';

 @Component({
    selector: 'app-set-appointment',
    templateUrl: './set-appointment.component.html',
    styleUrls: ['./set-appointment.component.scss']
})

export class SetAppointmentComponent implements OnInit {
    public highlightedStep: number;
    public deliveryDate: any;
    public pickUpDate: any;
    public flag = 0;
    public names: any = [];
    public appointmentCategory: any = [];
    public time: any = [];
    public items: any = [];
    public AppointmentReason: any = [];
    public scheduleForm: FormGroup;
    public prefName = '';
    public obj = '';

    @Output() activateTab: EventEmitter < any > = new EventEmitter();
    @ViewChild('warningMsg') warningMsg: ElementRef;
    @ViewChild('override') override: ElementRef;

    public myDatePickerOptions: IMyOptions = {
        todayBtnTxt: 'Today',
        dateFormat: 'mm-dd-yyyy',
        firstDayOfWeek: 'mo',
        showClearDateBtn: false,
        editableDateField: false,
        sunHighlight: true,
        height: '34px',
        inline: false,
        // disableUntil: {year: 2016, month: 8, day: 10},
        selectionTxtFontSize: '14px'
    };

    constructor(public jbhGlobals: JBHGlobals, public fb: FormBuilder) {
        this.highlightedStep = 1;
        this.createForm();
    }

    onpickUpDateChanged(event: IMyDateModel) {
        // event properties are: event.date, event.jsdate, event.formatted and event.epoc
        this.pickUpDate = event.epoc;
        console.log(this.pickUpDate);
    }
    ondeliveryDateChanged(event: IMyDateModel) {
        // event properties are: event.date, event.jsdate, event.formatted and event.epoc
        this.deliveryDate = event.epoc;
        console.log(this.deliveryDate);
    }
    createForm() {
        this.scheduleForm = this.fb.group({
            appNum: ['', Validators.required],
            startDate: '',
            startTime: '',
            endDate: '',
            endTime: '',
            trailerNum: ['', Validators.required],
            reasonforAppSet: '',
            comments: '',
            appointmentReasonCategory: ''
        });
    }

    ngOnInit() {
        this.serviceCall();
        this.reasonSetting();
        this.getpreferredname();
        this.getAppointmentReasonCategory();

    }

    public serviceCall() {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.appointments.recommendedAppointmentTimeStamp).subscribe(data => {
            console.log(data[0]['recommendedAppointmentTimeStamp']);
            console.log(data[2]['work']);
            this.items = data[0]['recommendedAppointmentTimeStamp'];
        });
    }
    public getpreferredname() {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.appointments.getpreferredname).subscribe(data => {
            console.log(data);
            this.names = data['people'];
            console.log(this.names);
        });
    }
    public getAppointmentReasonCategory() {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.appointments.getAppointmentReason).subscribe(data => {
            console.log(data);
            this.appointmentCategory = data['_embedded']['appointmentSetReasonCategories'];
        });
    }
    public reasonSetting() {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.appointments.appointmentReasonSetting).subscribe(data => {
            console.log(data['_embedded']['appointmentSetReasons'][0]['appointmentSetReasonDescription']);
            this.AppointmentReason = data['_embedded']['appointmentSetReasons'];
        });
    }


    saveData() {
        console.log(this.scheduleForm.value);
        this.obj = this.scheduleForm.value;
        console.log(this.obj);
    }
    cancel() {
        this.activateTab.emit('setAppointmentCancel');
    }
    onSelect(e) {
        //console.log(e.target.value);
        this.prefName = e.target.value;

    }
    myFunc() {
        alert();
    }
    prefClick() {
        const override = {
            'name': this.prefName,
            'warning1': this.warningMsg.nativeElement.children[2].innerHTML,
            'warning2': this.warningMsg.nativeElement.children[3].innerHTML,
            'warning3': this.warningMsg.nativeElement.children[4].innerHTML
        };
        console.log(override);
        console.log(override.warning2);
    }
}
