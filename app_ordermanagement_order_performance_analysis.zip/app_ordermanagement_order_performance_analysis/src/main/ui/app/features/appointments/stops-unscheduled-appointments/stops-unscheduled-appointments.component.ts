import { Component, ViewChild, OnInit } from '@angular/core';
import { JBHGlobals } from 'app/app.service';
import { JBHDataTableComponent } from 'app/shared/jbh-data-table/components/jbh-data-table.component';

@Component({
    selector: 'app-stops-unscheduled-appointments',
    templateUrl: './stops-unscheduled-appointments.component.html',
    styleUrls: ['./stops-unscheduled-appointments.component.scss']
})
export class StopsUnscheduledAppointmentsComponent implements OnInit {
    @ViewChild(JBHDataTableComponent) jbhdatatable: JBHDataTableComponent;
    rows: any[];
    selected = [];
    fleets: any[];
    count = 0;
    offset = 0;
    limit = 5;
    favUrl = '';
    singleselect = true;
    showPickup = false;
    showDelivery = false;
    showRate = false;
    yesSelected = false;
    flag = 0;
    filterTitle = 'Filter By';
    //panel
    footerDisplay: boolean;
    manageappointments: boolean;
    snoozeSection: boolean;
    ignoreSection: boolean;
    completeSection: boolean;
    public FilterList: any[] = [{
        'index': 0,
        'title': 'Status',
        'key': 'appointments',
        'rootVal': [],
        'componentType': 'lsitType',
    }, {
        'index': 1,
        'key': 'appointments',
        'title': 'Anticipated Appointment D...',
        'rootVal': [],
        'componentType': 'lsitType',
    }, {
        'index': 2,
        'key': 'appointments',
        'title': 'Loading Type',
        'rootVal': [],
        'componentType': 'lsitType',
    }, {
        'index': 3,
        'key': 'appointments',
        'title': 'Business Unit',
        'rootVal': [],
        'componentType': 'lsitType',
    }, {
        'index': 4,
        'key': 'appointments',
        'title': 'Service Oerings',
        'rootVal': [],
        'componentType': 'lsitType',
    }, {
        'index': 5,
        'key': 'appointments',
        'title': 'Stop Number',
        'componentType': 'lsitType',
        'rootVal': [],
    }, {
        'index': 6,
        'key': 'appointments',
        'title': 'Shipment Origin Name',
        'componentType': 'lsitType',
        'rootVal': [],
    }, {
        'index': 7,
        'key': 'appointments',
        'title': 'Shipment Origin City, State',
        'componentType': 'lsitType',
        'rootVal': [],
    }, {
        'index': 8,
        'key': 'appointments',
        'title': 'Shipment Destination Name',
        'componentType': 'lsitType',
        'rootVal': [],
    }, {
        'index': 9,
        'key': 'appointments',
        'title': 'Shipment Destination City, ...',
        'componentType': 'lsitType',
        'rootVal': [],
    }, {
        'index': 10,
        'key': 'appointments',
        'title': 'Bill To Account Name',
        'componentType': 'lsitType',
        'rootVal': [],
    }, {
        'index': 11,
        'key': 'appointments',
        'title': 'Bill To Account City, State',
        'componentType': 'lsitType',
        'rootVal': [],
    }];


    constructor(public jbhGlobals: JBHGlobals) {

        this.favUrl = this.jbhGlobals.endpoints.appointments.getStopInformation;
        this.jbhGlobals.apiService.getData(this.favUrl).subscribe(data => {
            /*  this.rows = data[0]['opsGrid'];*/
            this.rows = data;
            console.log(this.rows);

        });
    }

    ngOnInit() {
        this.footerDisplay = false;
        this.manageappointments = true;
        this.snoozeSection = false;
        this.page(this.offset, this.limit);

    }
    /* Snooze */
    snooze() {
        this.manageappointments = false;
        this.footerDisplay = true;
        this.snoozeSection = true;
        this.ignoreSection = false;
        this.completeSection = false;
    }
    /* Ignore */
    ignore() {
        this.manageappointments = false;
        this.footerDisplay = true;
        this.ignoreSection = true;
        this.snoozeSection = false;
        this.completeSection = false;
    }
    /* Complete */
    complete() {
        this.manageappointments = false;
        this.footerDisplay = true;
        this.completeSection = true;
        this.snoozeSection = false;
        this.ignoreSection = false;
    }
    cancel() {
        this.manageappointments = true;
        this.footerDisplay = false;
        this.completeSection = false;
        this.snoozeSection = false;
        this.ignoreSection = false;
    }
    public addidtionalsearch() {
        if (this.flag === 0) {
            this.flag = 1;
            //  this.fliterCmpLoad=true;
            //  this.searchElasticQuery(event);
        } else {
            this.flag = 0;
        }
    }

    page(offset, limit) {
        this.jbhGlobals.apiService.getData(this.favUrl).subscribe(data => {
            /* this.count = data[0]['opsGrid'].length;*/
            this.count = data.length;

            const start = offset * limit;
            const end = start + limit;
            const rows = [...this.rows];

            for (let i = start; i < end; i++) {
                /*rows[i] = data[0]['opsGrid'][i];*/
                rows[i] = data[i];
            }
            this.rows = rows;
            console.log(rows[0]);
        });
    }

    onPage(event) {
        console.log('Page Event', event);
        this.page(event.offset, event.limit);
    }


    onActivate(event) {
        this.manageappointments = true;
        this.snoozeSection = false;
        this.ignoreSection = false;
        this.completeSection = false;
        this.footerDisplay = false;
        if (event.type === 'click' && event.column.name !== 'checkboxedCol' && this.selected.length <= 1) {
            this.selected.splice(0, this.selected.length);
            this.selected.push(event.row);
            //this.setUpKeyboardShortcuts();
            this.jbhdatatable.isDataTableDetailOpen = true;
        } else if (event.type === 'click' && event.column.name === 'checkboxedCol') {
            this.jbhdatatable.isDataTableDetailOpen = false;
        }
        this.setUpKeyboardShortcuts();
    }

    onSelect({
        selected
    }) {
        if (selected) {
            if (selected.length > 1) {
                this.singleselect = false;
            } else {
                this.singleselect = true;
            }
        }
        console.log('Select Event', selected, this.selected);
    }

    setUpKeyboardShortcuts() {
        this.jbhGlobals.shortkeys.getData().subscribe(data => {
            if (data.keyCode === 'Shift+S' && this.jbhdatatable.isDataTableDetailOpen) {
                this.jbhdatatable.SplitViewTemplate.nativeElement.querySelector('.clockkeystroke').focus();
            } else if (data.keyCode === 'Shift+I' && this.jbhdatatable.isDataTableDetailOpen) {
                this.jbhdatatable.SplitViewTemplate.nativeElement.querySelector('.availablekeystroke').focus();
            } else if (data.keyCode === 'Shift+C' && this.jbhdatatable.isDataTableDetailOpen) {
                this.jbhdatatable.SplitViewTemplate.nativeElement.querySelector('.circlekeystroke').focus();
            } else if (data.keyCode === 'Shift+O' && this.jbhdatatable.isDataTableDetailOpen) {
                this.jbhdatatable.SplitViewTemplate.nativeElement.querySelector('.pagekeystroke').focus();
            } else if ((data.keyCode === 'Escape' && this.jbhdatatable.isDataTableDetailOpen) ||
                (data.keyCode === 'ArrowLeft' && this.jbhdatatable.isDataTableDetailOpen)) {
                this.jbhdatatable.SplitViewTemplate.nativeElement.querySelector('.closekshortcut').focus();
            } else if (data.keyCode === 'alt+1' && this.jbhdatatable.isDataTableDetailOpen) {
                this.jbhdatatable.SplitViewTemplate.nativeElement.querySelector('.focuswebsite').focus();
            } else if (data.keyCode === 'alt+o' && this.jbhdatatable.isDataTableDetailOpen) {
                this.jbhdatatable.SplitViewTemplate.nativeElement.querySelector('.focusappointment').focus();
            }
        });
    }

}
