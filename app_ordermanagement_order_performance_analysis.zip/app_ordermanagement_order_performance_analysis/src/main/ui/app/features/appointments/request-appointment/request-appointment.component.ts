import { Component, OnInit, ViewChild, ElementRef, EventEmitter, Output } from '@angular/core';
import { JBHGlobals } from 'app/app.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
    selector: 'app-request-appointment',
    templateUrl: './request-appointment.component.html',
    styleUrls: ['./request-appointment.component.scss']
})
export class RequestAppointmentComponent implements OnInit {
    public callLog: any[] = [];
    public requestData: any[] = [];
    public tableData: any[] = [];
    public commentsFlag: boolean = false;
    public phoneType: boolean = false;
    public textType: boolean = false;
    public emailType: boolean = false;
    public websiteType: boolean = false;
    public splitStr: Array < string > = [];
    public buttonContent: string;
    public callLogLength: number;
    @ViewChild('radioVal') rv: ElementRef;
    @ViewChild('expandWindow') ew;
    public comments: boolean = false;
    public expandFlag: boolean = true;
    public setViewMore: boolean = false;
    public setViewMoreLink: boolean = true;
    commentsForm: FormGroup;
    public selectedRow: number = 0;
    public initRadioFlag: number = 0;
    @Output() activateTab: EventEmitter < any > = new EventEmitter();

    constructor(public jbhGlobals: JBHGlobals, public formBuilder: FormBuilder) {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.appointments.getrequestappointment).subscribe(data => {
            this.requestData = data;
            this.tableData = this.requestData[0]['contacts'];
            /* Load the first contact Method */
            if (this.tableData.length > 0) {
                this.showContact(this.tableData[0].contactMethod);
            }
            this.callLog = this.requestData[1]['CallLogDTO'];
            this.callLogLength = this.requestData[1]['CallLogDTO'].length;
        });
    }

    ngOnInit() {
        this.commentsForm = this.formBuilder.group({
            comments: ['', Validators.required],
        });

    }

    changeContact(contactData, index) {
        this.showContact(contactData.contactMethod);
        this.selectedRow = index;

    }
    showContact(contactMethod) {
        this.phoneType = false;
        this.emailType = false;
        this.textType = false;
        this.websiteType = false;
        this.splitStr = contactMethod.split(',');
        for (let i = 0; i < this.splitStr.length; i++) {
            const trimmedContent = (this.splitStr[i].length > 0) ? this.splitStr[i].trim().toLowerCase() : '';
            if (trimmedContent === 'phone') {
                this.phoneType = true;
            } else if (trimmedContent === 'email') {
                this.emailType = true;
            } else if (trimmedContent === 'text') {
                this.textType = true;
            } else if (trimmedContent === 'website') {
                this.websiteType = true;
            }
        }
    }

    openSet(event) {
        this.buttonContent = event.target.innerHTML;
        this.activateTab.emit(this.buttonContent);
    }
    expand() {
        this.ew.nativeElement.style.display = 'block';
        this.comments = true;
        this.expandFlag = false;
    }
    collapse() {
        this.ew.nativeElement.style.display = 'none';
        this.comments = false;
        this.expandFlag = true;
    }
    cancel() {
        this.ew.nativeElement.style.display = 'none';
        this.expandFlag = true;
        this.comments = false;
    }
    viewMore() {
        this.setViewMore = true;
        this.setViewMoreLink = false;
    }
    saveComments() {
        console.log(this.commentsForm.value);
    }
}

