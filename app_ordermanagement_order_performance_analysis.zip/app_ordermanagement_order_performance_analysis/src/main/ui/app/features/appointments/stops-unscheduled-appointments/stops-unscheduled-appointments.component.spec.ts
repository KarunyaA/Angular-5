import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StopsUnscheduledAppointmentsComponent } from './stops-unscheduled-appointments.component';

describe('StopsUnscheduledAppointmentsComponent', () => {
  let component: StopsUnscheduledAppointmentsComponent;
  let fixture: ComponentFixture<StopsUnscheduledAppointmentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StopsUnscheduledAppointmentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StopsUnscheduledAppointmentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
