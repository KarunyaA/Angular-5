import {
    Component,
    OnInit
} from '@angular/core';
import {
    JBHGlobals
} from 'app/app.service';

@Component({
    selector: 'app-appointment-details',
    templateUrl: './appointment-details.component.html',
    styleUrls: ['./appointment-details.component.scss']
})
export class AppointmentDetailsComponent implements OnInit {

    appointment: any[];
    stopReason: string;
    totalStops: number;
    currentStop: number;
    favUrl = '';
    constructor(public jbhGlobals: JBHGlobals) {
        this.favUrl = this.jbhGlobals.endpoints.appointments.getAppointmentDetails;
        this.jbhGlobals.apiService.getData(this.favUrl).subscribe(data => {
            /*  this.rows = data[0]['opsGrid'];*/
            this.appointment = data;
            this.stopReason = this.appointment[0].stop.stopReason;
            this.totalStops = this.appointment.length;
            this.currentStop = this.appointment[0].stop.stopSequenceNumber;
            console.log(this.appointment[0].stop.stopSequenceNumber);

        });
    }

    ngOnInit() {}
}
