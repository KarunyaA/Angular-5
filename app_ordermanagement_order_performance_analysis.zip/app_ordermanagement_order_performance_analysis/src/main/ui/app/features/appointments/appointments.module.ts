import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { JBHDataTableModule } from '../../../app/shared/jbh-data-table/jbh-data-table.module';
import { JbhSearchFilterModule } from '../../../app/shared/jbh-search-filter/jbh-search-filter.module';
import { JbhUtilsModule } from '../../../app/shared/jbh-utils/jbh-utils.module';
import { AppointmentsRoutingModule } from './appointments-routing.module';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { AccordionModule } from 'ngx-bootstrap';
import { MyDatePickerModule } from 'mydatepicker';
import { ModalModule } from 'ngx-bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PopoverModule } from 'ngx-bootstrap';
import { SelectModule } from '../../shared/select';
import { UnscheduledAppointmentsComponent } from './unscheduled-appointments/unscheduled-appointments.component';
import { StopsUnscheduledAppointmentsComponent } from './stops-unscheduled-appointments/stops-unscheduled-appointments.component';
import { ManageAppointmentsComponent } from './manage-appointments/manage-appointments.component';
import { RequestAppointmentComponent } from './request-appointment/request-appointment.component';
import { SetAppointmentComponent } from './set-appointment/set-appointment.component';
import { AppointmentDetailsComponent } from './appointment-details/appointment-details.component';
import { OrderDetailsComponent } from './order-details/order-details.component';

@NgModule({
    imports: [
        CommonModule,
        AppointmentsRoutingModule,
        JBHDataTableModule,
        JbhSearchFilterModule,
        JbhUtilsModule,
        AccordionModule.forRoot(),
        TabsModule.forRoot(),
        MyDatePickerModule,
        ModalModule.forRoot(),
        FormsModule,
        ReactiveFormsModule,
        SelectModule,
        PopoverModule.forRoot()
    ],
    declarations: [
        UnscheduledAppointmentsComponent,
        StopsUnscheduledAppointmentsComponent,
        ManageAppointmentsComponent,
        RequestAppointmentComponent,
        SetAppointmentComponent,
        AppointmentDetailsComponent,
        OrderDetailsComponent
    ]
})
export class AppointmentsModule {}
