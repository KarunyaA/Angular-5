import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UnscheduledAppointmentsComponent } from './unscheduled-appointments/unscheduled-appointments.component';
import { StopsUnscheduledAppointmentsComponent } from './stops-unscheduled-appointments/stops-unscheduled-appointments.component';
import { ManageAppointmentsComponent } from './manage-appointments/manage-appointments.component';
import { OrderDetailsComponent } from './order-details/order-details.component';
import { SetAppointmentComponent } from './set-appointment/set-appointment.component';
import { AppointmentDetailsComponent } from './appointment-details/appointment-details.component';

const routes: Routes = [{
  path: 'unscheduledappointments',
  component: UnscheduledAppointmentsComponent // Rules List Component
}, {
  path: 'stopsunscheduledappointments',
  component: StopsUnscheduledAppointmentsComponent
}, {
  path: 'manageappointments',
  component: ManageAppointmentsComponent
},
{
  path: 'setappointments',
  component: SetAppointmentComponent

},
{
  path: 'orderdetails',
  component: OrderDetailsComponent
}, {
  path: 'appointmentdetails',
  component: AppointmentDetailsComponent
}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AppointmentsRoutingModule { }
