import { Component, OnInit } from '@angular/core';
import { JBHGlobals } from 'app/app.service';

@Component({
    selector: 'app-order-details',
    templateUrl: './order-details.component.html',
    styleUrls: ['./order-details.component.scss']
})
export class OrderDetailsComponent implements OnInit {
    orderDetails: any;
    favUrl: string;
    billtoaccountprofile: any;
    billtoaccountaddress: any;
    solicitorprofile: any;
    solicitoraddress: any;
    orderOverViewListStop: any;
    count: number;
    originStop: any;
    destinationStop: any;
    originStopAddress: any;
    destinationStopAddress: any;
    destinationValue: any;
    constructor(public jbhGlobals: JBHGlobals) {
        this.favUrl = this.jbhGlobals.endpoints.appointments.getOrderInformation;
        this.jbhGlobals.apiService.getData(this.favUrl).subscribe(data => {
            this.orderDetails = data;
            this.billtoaccountprofile = data['orderBillingDetailDTOs'][0]['profileDTO'];
            this.billtoaccountaddress = data['orderBillingDetailDTOs'][0]['profileDTO']['addressDTO'];
            this.solicitorprofile = data['orderRequestorDTOs'][0]['profileDTO'];
            this.solicitoraddress = data['orderRequestorDTOs'][0]['profileDTO']['addressDTO'];
        });

        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.order.getstopresequencelistorderoverview).subscribe(data => {
            this.orderOverViewListStop = data;
            this.count = data['totalElements'];
            this.originStop = data['content'][0]['locationDTO'];
            this.destinationStop = data['content'][this.count - 1]['locationDTO'];
            this.originStopAddress = data['content'][0]['locationDTO']['addressDTO'];
            this.destinationStopAddress = data['content'][this.count - 1]['locationDTO']['addressDTO'];
            //this.destinationValue(this.count);
            //this.originValue(this.initialValue);
        });
    }

    ngOnInit() {}
}
