import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { JBHGlobals } from '../../../app.service';
import { Router } from '@angular/router';

@Component({
    selector: 'app-unscheduled-appointments',
    templateUrl: './unscheduled-appointments.component.html',
    styleUrls: ['./unscheduled-appointments.component.scss']
})
export class UnscheduledAppointmentsComponent implements OnInit {
    public rows: any[];
    public selected = [];
    public rulesGridMenu = [{
            'name': 'ascending',
            'id': 'asc'
        },
        {
            'name': 'descending',
            'id': 'desc'
        }
    ];
    public rulesFilterTitle = 'Filter By';
    public flag = 0;
    public flag1 = 0;
    @ViewChild('tasks') tasks: ElementRef;
    @ViewChild('view') view: ElementRef;
    @ViewChild('filter') filter: ElementRef;
    @ViewChild('sort') sort: ElementRef;
    public rulesFilterList: any[] = [{
        'index': 0,
        'key': 'orderBillingDetailDTOs.solicitorCode',
        'title': 'Appointment Location',
        'componentType': 'lsitType',
        'rootVal': [],
        'pagination': true,
        'url': ''
    }, {
        'index': 1,
        'title': 'Awaiting my action',
        'key': 'lineOfBusinessCode',
        'rootVal': [],
        'componentType': 'lsitType',
        'pagination': true,
        'url': ''
    }, {
        'index': 2,
        'key': 'Customer',
        'title': 'Earliest appointment Date',
        'rootVal': [],
        'componentType': 'lsitType',
        'pagination': true,
        'url': ''
    }, {
        'index': 3,
        'key': 'tradingPartnerCode',
        'title': 'Total appointments',
        'rootVal': [],
        'componentType': 'lsitType',
        'url': ''
    }, {
        'index': 4,
        'key': 'owner.inits',
        'title': 'Type of Appointments',
        'rootVal': [],
        'componentType': 'lsitType',
        'url': ''
    }, {
        'index': 5,
        'key': 'Number of Stops',
        'title': 'Contact party',
        'rootVal': [],
        'componentType': 'lsitType',
        'url': ''
    }];


    constructor(public router: Router, public jbhGlobals: JBHGlobals) {}

    ngOnInit() {
        this.serviceCall();
        this.setUpKeyboardShortcuts();
    }
    public serviceCall() {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.appointments.unscheduled).subscribe(data => {
            console.log(data);
            this.rows = data;
        });
    }
    private setUpKeyboardShortcuts() {
        this.jbhGlobals.shortkeys.getData().subscribe(data => {
            if (data.keyCode === 'alt+1') {
                this.tasks.nativeElement.focus();
            } else if (data.keyCode === 'alt+2') {
                this.view.nativeElement.focus();
            } else if (data.keyCode === 'ctrl+f') {
                event.preventDefault();
                this.filter.nativeElement.focus();
            } else if (data.keyCode === 'alt+s') {
                this.sort.nativeElement.focus();
            }
        });
    }
    onActivate(event) {
        console.log('Activate Event', event);
        this.router.navigateByUrl('/appointments/stopsunscheduledappointments');
        this.selected.push(event.row);
    }

    public additionalSearch() {
        if (this.flag === 0) {
            this.flag = 1;
        } else {
            this.flag = 0;
        }
    }

}
