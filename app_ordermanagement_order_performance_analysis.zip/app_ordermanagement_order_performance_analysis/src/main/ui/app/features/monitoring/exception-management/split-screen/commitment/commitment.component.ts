import { Component, OnInit, Input } from '@angular/core';

import { ExceptionManagementComponent } from '../../exception-management.component';
import { CommitmentModel } from './models/commitment.model';

@Component({
    selector: 'app-commitment',
    templateUrl: './commitment.component.html',
    styleUrls: ['./commitment.component.scss'],
})
export class CommitmentComponent implements OnInit {
    parentFlag;
    commitmentModel: CommitmentModel;

    @Input()
    set flag(flagArg) {
        this.parentFlag = flagArg;
    }

    constructor(public closeSplitScreen: ExceptionManagementComponent) {
        this.commitmentModel = new CommitmentModel();
    }

    closeSplit() {
        this.closeSplitScreen.exceptionManagementModel.managementvar.selected = [];
        this.closeSplitScreen.jbhdatatable.toggleDataTableDetail();
    }

    ngOnInit() {}

}
