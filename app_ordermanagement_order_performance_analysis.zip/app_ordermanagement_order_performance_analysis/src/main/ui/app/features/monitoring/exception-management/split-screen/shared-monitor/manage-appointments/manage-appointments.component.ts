import {
    Component,
    OnInit,
    ViewChild,
    ElementRef,
    Input
} from '@angular/core';
import {
    JBHGlobals
} from 'app/app.service';
import {
    TabsetComponent
} from 'ngx-bootstrap';
import {
    FormBuilder,
    FormGroup,
    Validators
} from '@angular/forms';
import {
    ModalDirective
} from 'ngx-bootstrap/modal';
import {
    Headers,
    RequestOptions
} from '@angular/http';

import {
    SetAppointmentComponent
} from '../../shared-monitor/set-appointment/set-appointment.component';

@Component({
    selector: 'app-manage-appointments',
    templateUrl: './manage-appointments.component.html',
    styleUrls: ['./manage-appointments.component.scss']
})
export class ManageAppointmentsComponent implements OnInit {
    @ViewChild('appointments') setTab: TabsetComponent;
    @ViewChild('emailContent') emailContent: ElementRef;
    @ViewChild(SetAppointmentComponent) setAppointmentComponent: SetAppointmentComponent;
    @ViewChild('previewModalForText') public previewModalForText: ModalDirective;
    @ViewChild('previewModalForEmail') public previewModalForEmail: ModalDirective;
    @ViewChild('callNum') callNum: ElementRef;
    @ViewChild('reasonCateg') reasonCateg;
    @ViewChild('reasonSetting') reasonSetting;
    @ViewChild('setappointment') setappointment;
    @ViewChild('setAppointmetTab') setAppointmetTab;

    public highlightedStep: number;
    public flag: number;
    public hideTab: boolean = true;
    public setWebsite: boolean = false;
    public setEmail: boolean = false;
    public setPhone: boolean = false;
    public setText: boolean = false;
    public buttonData: string;
    public textValue: string;
    public clicked: boolean;
    public orderTrackingNumber: any[] = [];
    public addMessage: any;
    public appointmentReasonArray: any[];
    public addedContact: any[] = [];
    public reason: any = [];
    public workNumber: Number;
    public mobNumber: Number;
    // public firstCallPurpose: any;
    // public secondCallPurpose: any;
    // public callDir1: any;
    // public callDir2: any;
    //public callResult: any;
    public addAnotherContact: FormGroup;
    public callRecording: FormGroup;
    public emailForm: FormGroup;
    public textForm: FormGroup;
    public callForm: FormGroup;
    public addContactHeading: boolean = false;
    public alternateContactField: boolean = false;
    // public setWrongSelectReasonCategory: boolean = false;
    // public setWrongSelectReasonSetting: boolean = false;
    public setWrongSelectToName: boolean = false;
    public resultOfCall: any[] = [];
    public callDirection: any[] = [];
    public purposeOfCall: any[] = [];
    public callResultValue: any;
    public direction: any;
    public purpose: any;
    //public callIntent: any[] = [];
    //public directionOfCall: any[] = [];
    //public callRes: any[] = [];
    public orderNumber: number;
    // public setWrongSelectPurpose: boolean = false;
    // public setWrongSelectDirection: boolean = false;
    // public setWrongSelectResult: boolean = false;
    // public dest: string = '';
    // public destination;
    // public myTest: number = 435353;
    public purposeId: string;
    public toNames: any = ['Stronburn', 'john', 'joe', 'bailey'];
    public toName: any;
    public slashView: any;
    public selectedRow: number = 0;
    public reasonCategoryParams: string;
    public selectedObject: any;
    public phoneContinueFlag: boolean = false;
    @Input()
    set slashViewFlag(flagArg) {
        this.slashView = flagArg;
    }

    constructor(public jbhGlobals: JBHGlobals, public formBuilder: FormBuilder) {
        this.highlightedStep = 1;
    }
    ngOnInit() {
        this.emailPreview();
        this.appointmentReasonOnInit();
        this.phoneCall();

        this.addAnotherContact = this.formBuilder.group({
            contactName: ['', Validators.compose([Validators.required, this.jbhGlobals.customValidator.onlyAlpha])],
            contactNumber: ['', Validators.compose([Validators.required, this.jbhGlobals.customValidator.phoneNumberValidator])]
        });

    }

    public phoneCall() {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.appointments.getCallPurpose).subscribe(data => {
            console.log(data);
            //this.callIntent = data;
            for (let i = 0; i < data.length; i++) {
                this.purposeOfCall.push(data[i].type);
            }
            this.workNumber = data[0]['work'];
            this.mobNumber = data[0]['mobile'];
        });
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.appointments.getCallDirection).subscribe(data => {
            console.log(data);
            //this.directionOfCall = data;
            for (let i = 0; i < data.length; i++) {
                this.callDirection.push(data[i].type);
            }
        });
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.appointments.getCallResult).subscribe(data => {
            console.log(data);
            //this.callRes = data;
            for (let i = 0; i < data.length; i++) {
                this.resultOfCall.push(data[i].type);
            }
        });
        this.callRecording = this.formBuilder.group({
            callPurpose: ['', Validators.required],
            callDirection: ['', Validators.required],
            callResult: ['', Validators.required]
        });

    }
    onActivateTab(a) {
        this.selectedObject = a.selectedObject;
        this.selectedRow = a.selectedRow;
        this.hideTab = false;
        if (a.buttonContent === 'setAppointmentCancel') {
            this.hideTab = true;
            this.setTab.tabs[0].active = true;
        }
        this.buttonData = a.buttonContent;
        if (this.buttonData === 'Website') {
            this.setWebsite = true;
            this.setEmail = false;
            this.setPhone = false;
            this.setText = false;
        } else if (this.buttonData === 'Email') {
            this.toNames.pop();
            this.setEmail = true;
            this.setWebsite = false;
            this.setPhone = false;
            this.setText = false;
            this.emailForm.controls.toName.setValue([{
                'id': a.selectedObject.emailContactValue,
                'text': a.selectedObject.firstName
            }]);
            this.toNames.push(a.selectedObject.firstName);
        } else if (this.buttonData === 'Phone') {
            this.setPhone = true;
            this.setWebsite = false;
            this.setEmail = false;
            this.setText = false;
        } else if (this.buttonData === 'Text') {
            this.toNames.pop();
            this.setText = true;
            this.setWebsite = false;
            this.setEmail = false;
            this.setPhone = false;
            this.textForm.controls.toName.setValue([{
                'id': a.selectedObject.emailContactValue,
                'text': a.selectedObject.firstName
            }]);
            this.toNames.push(a.selectedObject.firstName);
        }
    }

    showStep(newValue: number) {
        this.highlightedStep = newValue;
    }

    public continue (newValue: number) {
        if (this.callRecording.valid) {
            if (this.alternateContactField === true) {
                if (this.addAnotherContact.valid) {
                    alert();
                    this.highlightedStep = newValue;
                    this.phoneContinueFlag = true;
                } else {
                    const me = this;
                    this.jbhGlobals.utils.forIn(this.addAnotherContact.controls.contactName,
                        function(value, name, object) {
                            me.addAnotherContact.controls.contactName.markAsTouched();
                        });
                    this.jbhGlobals.utils.forIn(this.addAnotherContact.controls.contactNumber,
                        function(value, name, object) {
                            me.addAnotherContact.controls.contactNumber.markAsTouched();
                        });
                    this.jbhGlobals.notifications.error('Appointments', 'Fill all required fields.');
                }
            } else {
                this.highlightedStep = newValue;
                this.phoneContinueFlag = true;
            }
        } else {
            const me = this;
            this.jbhGlobals.utils.forIn(this.callRecording.controls.callPurpose,
                function(value, name, object) {
                    me.callRecording.controls.callPurpose.markAsTouched();
                });
            this.jbhGlobals.utils.forIn(this.callRecording.controls.callDirection,
                function(value, name, object) {
                    me.callRecording.controls.callDirection.markAsTouched();
                });
            this.jbhGlobals.utils.forIn(this.callRecording.controls.callResult,
                function(value, name, object) {
                    me.callRecording.controls.callResult.markAsTouched();
                });
            this.jbhGlobals.notifications.error('Appointments', 'Fill all required fields.');
        }
    }

    removeContact(i) {
        this.addedContact.splice(i, 1);
        if (this.addedContact.length === 0) {
            if (this.alternateContactField === true) {
                this.addContactHeading = true;
            } else {
                this.addContactHeading = false;
            }
            // this.addAnotherContact.setValue({
            //     'contactName': '',
            //     'contactNumber': null
            // });
            this.clearValue();
        }
    }

    clearValue() {
        /*this.addAnotherContact.setValue({
            'contactName': '',
            'contactNumber': null
        });*/
        this.addAnotherContact.reset();
    }

    focusContactNumber(event) {
        event.target.nextElementSibling.focus();
    }

    addContactList(event) {
        const nameNull = (this.addAnotherContact.value.contactName === null);
        const nameSpace = (this.addAnotherContact.value.contactName === ' ');
        const nameNospace = (this.addAnotherContact.value.contactName === '');
        const numberNull = (this.addAnotherContact.value.contactNumber === null);
        const numberSpace = (this.addAnotherContact.value.contactNumber === ' ');
        const numberNospace = (this.addAnotherContact.value.contactNumber === '');
        const contactNameNullFlag = (nameNull || nameNospace || nameSpace);
        const contactNumberNullFlag = (numberNull || numberNospace || numberSpace);

        if (contactNameNullFlag || contactNumberNullFlag) {
            this.addContactHeading = true;
            this.alternateContactField = true;
        } else if (this.addAnotherContact.value.contactName !== ' ' && this.addAnotherContact.value.contactNumber !== null) {
            if (this.addAnotherContact.valid) {
                if (this.addedContact.length === 0) {
                    this.addedContact.push(this.addAnotherContact.value);
                    /*this.addAnotherContact.setValue({
                        'contactName': ' ',
                        'contactNumber': null
                    });*/
                    this.clearValue();
                    this.addContactHeading = true;
                } else {
                    const name = this.addAnotherContact.value.contactName;
                    const contactNumber = this.addAnotherContact.value.contactNumber;
                    const lastName = this.addedContact[this.addedContact.length - 1].contactName;
                    const lastNumber = this.addedContact[this.addedContact.length - 1].contactNumber;

                    const contactNameValueFlag = (name === lastName);
                    const contactNumberValueFlag = (contactNumber === lastNumber);

                    if (!(contactNameValueFlag && contactNumberValueFlag)) {
                        this.addedContact.push(this.addAnotherContact.value);
                        /*this.addAnotherContact.setValue({
                            'contactName': ' ',
                            'contactNumber': null
                        });*/
                        this.clearValue();
                        this.addContactHeading = true;
                    }
                }
            } else {
                this.alternateContactField = true;
            }
        } else if (this.addedContact.length === 0) {
            this.addContactHeading = false;
        }
    }

    public preview() {
        this.clicked = true;
        this.textValue = this.emailContent.nativeElement.value;
    }

    public sendEmailText() {
        this.hideTab = true;
    }
    public cancel() {
        this.highlightedStep = 1;
        this.hideTab = true;
    }
    public setCancel() {
        this.hideTab = true;
        this.setTab.tabs[0].active = true;
    }
    public saveFormDetails() {
        this.setAppointmentComponent.saveData();
        this.setAppointmetTab.setAppointmentValidation();
    }
    public emailPreview() {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.appointments.getEmailPreview).subscribe(data => {
            this.orderTrackingNumber = data['orderTrackingNumber'];
            this.orderNumber = data['orderNumber'];
            this.addMessage = data['Add Custom Message'];
        });

        this.emailForm = this.formBuilder.group({
            appntReasonSetting: ['', Validators.required],
            appntReasonCateg: ['', Validators.required],
            toName: ['', Validators.required]
        });

        this.textForm = this.formBuilder.group({
            appntReasonSetting: ['', Validators.required],
            appntReasonCateg: ['', Validators.required],
            toName: ['', Validators.required]
        });

    }
    public onToNameTagSelection(event, booleanValue) {
        this.toName = event.text;
        this.setWrongSelectToName = false;
    }

    ///reason*********************************************************************************


    public appointmentReasonOnInit() {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.appointments.getAppointmentReason).subscribe(data => {
            this.reason = [];
            for (let i = 0; i < data['_embedded']['appointmentSetReasonCategories'].length; i++) {
                this.reason.push(data['_embedded']['appointmentSetReasonCategories'][i]['appointmentSetReasonCategoryDescription']);
            }
        });

    }
    public reasonSettingFunction() {
        const url = this.jbhGlobals.endpoints.appointments.appointmentReasonSetting;
        const params = {
            'appointmentSetReasonCategoryCode': this.reasonCategoryParams
        };
        this.jbhGlobals.apiService.getData(url, params).subscribe(data => {
            this.appointmentReasonArray = [];
            for (let i = 0; i < data['_embedded']['appointmentSetReasons'].length; i++) {
                this.appointmentReasonArray.push(data['_embedded']['appointmentSetReasons'][i]['appointmentSetReasonDescription']);
            }
        });
    }
    public onReasonCategoryTagSelection(event) {
        this.reasonCategoryParams = event.text.toLowerCase();
        this.reasonSettingFunction();
        this.reasonSetting.active = [];

    }
    public onReasonSettingTagSelection(event) {

    }
    public blurredOnSelect(event, selectComponent, formValue) {
        // console.log(formValue);
        const compName = selectComponent.element.nativeElement.id;
        if (event.innerText === '') {
            this.appointmentReasonArray = [];
            formValue.get(compName).markAsTouched();
            formValue.get(compName).setErrors(
                compName === 'appntReasonCateg' || compName === 'appntReasonSetting' ||
                compName === 'callResult' || compName === 'callDirection' || compName === 'callPurpose' ? {
                    'mandatory': true
                } : null);
            if (selectComponent.multiple !== true && selectComponent.active.length > 0) {
                selectComponent.active = [];
            }
            if (compName === 'appntReasonCateg') {
                this.onClearOrChangeAppntReasonCateg();
            }
        }

    }
    public onClearOrChangeAppntReasonCateg() {
        this.reasonSetting.active = [];
        this.appointmentReasonArray = null;
    }
    public showPreviewModalForText() {
        this.previewModalForText.show();
    }
    public hidePreviewModalForText() {
        this.previewModalForText.hide();
    }
    public showPreviewModalForEmail() {
        this.previewModalForEmail.show();
    }
    public hidePreviewModalForEmail() {
        this.previewModalForEmail.hide();
    }
    public getPhoneData() {
        const params = [{
            'createdProgramCode': 'OM_APPT',
            'createdStamp': 1494963565167,
            'createdUserId': 'Agent',
            'lastUpdatedProgramCode': 'OM_APPT',
            'lastUpdatedStamp': 1494963565167,
            'lastUpdatedUserId': 'Agent',
            'associations': {
                'customerRequestToComunicationAssociation': [{
                    'createdProgramCode': 'OM_APPT',
                    'createdStamp': 1494963565170,
                    'createdUserId': 'Agent',
                    'lastUpdatedProgramCode': 'OM_APPT',
                    'lastUpdatedStamp': 1494963565170,
                    'lastUpdatedUserId': 'Agent',
                    'effectiveStamp': 1494963565170,
                    'endStamp': 1494963565170,
                    'identity': null,
                    'trackingNumber': 'TRACK123'
                }]
            },
            'callBeginDateTime': 1494963565000,
            'callEndDateTime': 1494963565000,
            'callResult': this.callResultValue,
            'communicationDirection': this.direction,
            'communicationType': 'CALL',
            'contactFirstName': 'Thomas',
            'contactLastName': 'Smith',
            'humanResourcePersonId': '565656',
            'identity': null,
            'intentCode': this.purposeId,
            'intentResultCode': this.purposeId,
            'phoneNumber': '5456789876'
        }];
        const headers = new Headers({
            'Content-Type': 'application/json'
        });
        const codeHeader = new RequestOptions({
            headers: headers
        });
        const favUrl = this.jbhGlobals.endpoints.appointments.postCallDetails;
        this.jbhGlobals.apiService.addData(favUrl, params, codeHeader).subscribe(data => {
            //alert('inside post');
            console.log(data);
        });
    }

    public typedToName(typedWord) {
        for (let i = 0; i < this.toNames.length; i++) {
            if (typedWord !== this.toNames) {
                this.setWrongSelectToName = true;
            }
        }
    }

    public phoneContinue() {
        this.continue(3);
        if (this.phoneContinueFlag === true && this.setappointment.scheduleForm.valid) {
            this.getPhoneData();
        } else {
            this.setappointment.setAppointmentValidation();
        }
    }

    public onPurposeOfCallSelect(i) {
        this.purpose = i.text;
        //this.setWrongSelectPurpose = false;
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.appointments.getCallPurpose).subscribe(data => {
            for (let j = 0; j < data.length; j++) {
                if (this.purpose === data[j]['type']) {
                    this.purposeId = data[j]['id'];
                }
            }
        });
    }
    public onCallDirectionSelect(i) {
        this.direction = i.text;
        //this.setWrongSelectDirection = false;
    }
    public onResultOfCallSelect(i) {
        this.callResultValue = i.text;
        //this.setWrongSelectDirection = false;
    }
    public onDial() {

        console.log(this.callNum.nativeElement.value);

        const headers = new Headers({
            'Content-Type': 'application/json'
        });
        const options = new RequestOptions({
            headers: headers,
            withCredentials: true
        });
        const body = JSON.stringify(this.callNum.nativeElement.value);
        this.jbhGlobals.apiService.addData(this.jbhGlobals.endpoints.appointments.cimplicity, body, options)
            .subscribe(
                (data) => {
                    // alert('Success');
                    console.log(data);
                },
                err => {
                    console.log(err);
                }
            );
    }
}
