export class RateModel {
    ratevar = {
        emailFlag: true
    };
}
