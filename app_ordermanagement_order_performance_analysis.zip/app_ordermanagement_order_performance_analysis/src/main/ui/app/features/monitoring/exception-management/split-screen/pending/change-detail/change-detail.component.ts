import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-change-detail',
  templateUrl: './change-detail.component.html',
  styleUrls: ['./change-detail.component.scss']
})
export class ChangeDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
