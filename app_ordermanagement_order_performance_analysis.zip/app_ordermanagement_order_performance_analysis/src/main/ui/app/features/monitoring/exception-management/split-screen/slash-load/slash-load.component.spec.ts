import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SlashLoadComponent } from './slash-load.component';

describe('SlashLoadComponent', () => {
  let component: SlashLoadComponent;
  let fixture: ComponentFixture<SlashLoadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SlashLoadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SlashLoadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
