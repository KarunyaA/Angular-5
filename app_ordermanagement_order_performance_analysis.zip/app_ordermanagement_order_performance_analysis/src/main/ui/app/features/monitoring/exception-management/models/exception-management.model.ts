  export class ExceptionManagementModel {
      exceptionColumns: any;
      filterColumns: any;
      exception: any;
      splitFlag: any;
      filterList: any[];
      rows: any[];
      columns: any[];
      editColumns: any[];
      editColumnLength: any;
      managementvar = {
          singleFlag: false,
          filterFlag: 0,
          selected: [],
          filterTitle: 'Filter By',
          finalColumn: []
      };
  }
