import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ViewManagementComponent } from './view-management.component';
import { ConfigureNewExceptionComponent } from './configure-new-exception/configure-new-exception.component';
import { UpdateExceptionComponent } from './update-exception/update-exception.component';

const routes: Routes = [
  {
    path: '',
    component: ViewManagementComponent
  }, {
    path: 'configurenewrule',
    component: ConfigureNewExceptionComponent
  }, {
    path: 'updateexception',
    component: UpdateExceptionComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ViewManagementRoutingModule { }
