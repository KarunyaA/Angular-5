import { Component, OnInit, Input, ViewChild } from '@angular/core';

import { ExceptionManagementComponent } from '../../exception-management.component';
import { RequestAppointmentComponent } from '../shared-monitor/request-appointment/request-appointment.component';


@Component({
    selector: 'app-slash-load',
    templateUrl: './slash-load.component.html',
    styleUrls: ['./slash-load.component.scss'],
    providers: [RequestAppointmentComponent]
})
export class SlashLoadComponent implements OnInit {
    parentFlag;
    emailFlag = true;

    @ViewChild('rejectScreen') public rejectScreenLink;
    @ViewChild('rejectClose') public rejectClose;
    @Input()
    set flag(flagArg) {
        this.parentFlag = flagArg;
    }

    //@Output() slashViewEmit: EventEmitter<any> = new EventEmitter();
    constructor(public closeSplitScreen: ExceptionManagementComponent, public requestCustomize: RequestAppointmentComponent) {}
    createEmail($event) {
        this.emailFlag = false;
    }

    closeSplit() {
        this.closeSplitScreen.exceptionManagementModel.managementvar.selected = [];
        this.closeSplitScreen.jbhdatatable.toggleDataTableDetail();
    }

    ngOnInit() {
        /*this.requestCustomize.slashView = true;
        console.log(this.requestCustomize);*/
    }

    rejectScreenShown() {
        this.rejectScreenLink.nativeElement.focus();
    }

}
