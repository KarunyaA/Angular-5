export class ExceptionListingModel {
    public colDefine: any;
    public filterColumns: any;
    public showGrid: boolean = true;
    public filterFlag = 0;
    public filterTitle = 'Filter By';
    public filterList: any[];
    public rows: any[];
    public columns: any[];
}
