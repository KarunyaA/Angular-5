import { Component, OnInit, Input } from '@angular/core';

import { ExceptionManagementComponent } from '../../exception-management.component';
import { ServiceExceptionModel } from './models/service-exception.model';

@Component({
    selector: 'app-service',
    templateUrl: './service.component.html',
    styleUrls: ['./service.component.scss']
})
export class ServiceComponent implements OnInit {

    parentFlag;
    serviceExceptionModel: ServiceExceptionModel;

    @Input()
    set flag(flagArg) {
        this.parentFlag = flagArg;
    }
    constructor(public closeSplitScreen: ExceptionManagementComponent) {
        this.serviceExceptionModel = new ServiceExceptionModel();
    }
    createEmail($event) {
        this.serviceExceptionModel.servicevar.emailFlag = false;
    }

    closeSplit() {
        this.closeSplitScreen.exceptionManagementModel.managementvar.selected = [];
        this.closeSplitScreen.jbhdatatable.toggleDataTableDetail();
    }

    ngOnInit() {}
}
