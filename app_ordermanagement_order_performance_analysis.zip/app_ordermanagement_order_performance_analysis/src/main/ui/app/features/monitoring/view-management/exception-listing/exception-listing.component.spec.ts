import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExceptionListingComponent } from './exception-listing.component';

describe('ExceptionListingComponent', () => {
  let component: ExceptionListingComponent;
  let fixture: ComponentFixture<ExceptionListingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExceptionListingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExceptionListingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
