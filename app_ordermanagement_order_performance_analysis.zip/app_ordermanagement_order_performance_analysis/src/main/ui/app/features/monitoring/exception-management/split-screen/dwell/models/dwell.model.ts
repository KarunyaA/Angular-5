export class DwellModel {
    dwellvar = {
        emailFlag: true
    };
}
