import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Response } from '@angular/http';

import { JBHGlobals } from 'app/app.service';

@Injectable()
export class ExceptionListingService {
  constructor(private jbhGlobals: JBHGlobals) { }
  // Getting columns
  getColumns(url): Observable<Response[]> {
    return this.jbhGlobals.apiService.getData(url, true);
  }
  // Getting Rows
  getRows(url): Observable<Response[]> {
    return this.jbhGlobals.apiService.getData(url, true);
  }
  // Getting Filter data
  getFilter(url): Observable<Response[]> {
    return this.jbhGlobals.apiService.getData(url, true);
  }
}
