import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DwellComponent } from './dwell.component';

describe('DwellComponent', () => {
  let component: DwellComponent;
  let fixture: ComponentFixture<DwellComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DwellComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DwellComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
