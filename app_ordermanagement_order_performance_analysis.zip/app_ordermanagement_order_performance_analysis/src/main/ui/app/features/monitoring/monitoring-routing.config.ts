export let MonitoringRoutes = [
  {
    path: 'exceptionmaintenance',
    loadChildren: 'app/features/monitoring/exception-maintenance/exception-maintenance.module#ExceptionMaintenanceModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Exception Maintenance',
      pathIcon: `fa fa-building`,
      order: 1
    }
  },
  {
    path: 'exceptionmanagement',
    loadChildren: 'app/features/monitoring/exception-management/exception-management.module#ExceptionManagementModule',
    data: {
      createSidebarEntry: true,
      pathDisplayText: 'Exception Management',
      pathIcon: `fa fa-building`,
      order: 2
    }
  }
];
