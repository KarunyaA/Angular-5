import { Component, OnInit, Input } from '@angular/core';

import { ExceptionManagementComponent } from '../../exception-management.component';
import { RateModel } from './models/rate.model';

@Component({
    selector: 'app-rate',
    templateUrl: './rate.component.html',
    styleUrls: ['./rate.component.scss'],
})

export class RateComponent implements OnInit {
    parentFlag;
    rateModel: RateModel;

    @Input()
    set flag(flagArg) {
        this.parentFlag = flagArg;
    }
    constructor(public closeSplitScreen: ExceptionManagementComponent) {
        this.rateModel = new RateModel();
    }
    createEmail($event) {
        this.rateModel.ratevar.emailFlag = false;
    }

    closeSplit() {
        this.closeSplitScreen.exceptionManagementModel.managementvar.selected = [];
        this.closeSplitScreen.jbhdatatable.toggleDataTableDetail();
    }

    ngOnInit() {}
}
