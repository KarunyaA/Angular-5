import { Component, OnInit, Input } from '@angular/core';

import { ExceptionManagementComponent } from '../../exception-management.component';
import { DwellModel } from './models/dwell.model';

@Component({
    selector: 'app-dwell',
    templateUrl: './dwell.component.html',
    styleUrls: ['./dwell.component.scss'],
})

export class DwellComponent implements OnInit {
    parentFlag;
    dwellModel: DwellModel;
    @Input()

    set flag(flagArg) {
        this.parentFlag = flagArg;
    }

    constructor(public closeSplitScreen: ExceptionManagementComponent) {
        this.dwellModel = new DwellModel();
    }

    createEmail($event) {
        this.dwellModel.dwellvar.emailFlag = false;
    }

    closeSplit() {
        this.closeSplitScreen.exceptionManagementModel.managementvar.selected = [];
        this.closeSplitScreen.jbhdatatable.toggleDataTableDetail();
    }

    ngOnInit() {}

}
