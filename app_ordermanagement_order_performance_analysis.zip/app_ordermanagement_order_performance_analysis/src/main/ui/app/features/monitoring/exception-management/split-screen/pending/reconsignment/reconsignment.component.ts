import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reconsignment',
  templateUrl: './reconsignment.component.html',
  styleUrls: ['./reconsignment.component.scss']
})
export class ReconsignmentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
