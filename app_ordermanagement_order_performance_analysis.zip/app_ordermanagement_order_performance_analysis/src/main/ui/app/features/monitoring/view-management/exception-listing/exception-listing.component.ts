import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { JBHGlobals } from 'app/app.service';
import { ExceptionListingModel } from './models/exception-listing.model';
import { ExceptionListingService } from './services/exception-listing.service';

@Component({
  selector: 'app-exception-listing',
  templateUrl: './exception-listing.component.html',
  styleUrls: ['./exception-listing.component.scss'],
  providers: [ExceptionListingService]
})
export class ExceptionListingComponent implements OnInit {

    public exceptionListingModel: ExceptionListingModel;

    constructor(public jbhGlobals: JBHGlobals, private router: Router, public exceptionListingService: ExceptionListingService) {
        this.exceptionListingModel = new ExceptionListingModel();
        this.init();
    }

    // initial function that proceeds the operations
    private init(): void {

        let url = this.jbhGlobals.endpoints.monitoring.exceptionMaintenanceTypes;

        this.exceptionListingService.getColumns(url).subscribe(data => {
            this.exceptionListingModel.colDefine = data;
            this.exceptionListingModel.columns = this.exceptionListingModel.colDefine.exceptionMaintenance.data;
        });

        url = this.jbhGlobals.endpoints.monitoring.exceptionMaintenancePath;
        this.exceptionListingService.getRows(url).subscribe(data => {
            this.exceptionListingModel.rows = data;
            console.log(this.exceptionListingModel.rows);
        });

        const filterUrl = this.jbhGlobals.endpoints.monitoring.exceptionMaintenanceFilterTypes;
        this.exceptionListingService.getFilter(filterUrl).subscribe(data => {
            this.exceptionListingModel.filterColumns = data;
            this.exceptionListingModel.filterList = this.exceptionListingModel.filterColumns;
        });
    }

    // OnActivate method that calls, when the table is active
    public onActivate(event): void {
        this.exceptionListingModel.showGrid = false;
        this.navigatePage();
    }

    private navigatePage(): void {
        this.router.navigateByUrl('/monitoring/viewmanagement/updateexception');
    }

    public enableConfigureScreen(): void {
        this.router.navigateByUrl('/monitoring/viewmanagement/configurenewrule');
    }

    // enables the filter screen
    public enableFilter(): void {
        if (this.exceptionListingModel.filterFlag === 0) {
            this.exceptionListingModel.filterFlag = 1;
        } else {
            this.exceptionListingModel.filterFlag = 0;
        }
    }

    ngOnInit() {}


}
