import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigureNewExceptionComponent } from './configure-new-exception.component';

describe('ConfigureNewExceptionComponent', () => {
  let component: ConfigureNewExceptionComponent;
  let fixture: ComponentFixture<ConfigureNewExceptionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfigureNewExceptionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigureNewExceptionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
