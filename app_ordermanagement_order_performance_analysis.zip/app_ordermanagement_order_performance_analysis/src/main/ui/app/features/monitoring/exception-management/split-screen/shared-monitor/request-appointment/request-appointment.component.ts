import {
    Component,
    OnInit,
    ViewChild,
    ElementRef,
    EventEmitter,
    Output,
    Input
} from '@angular/core';
import {
    JBHGlobals
} from 'app/app.service';
import {
    FormBuilder,
    FormGroup,
    Validators
} from '@angular/forms';

@Component({
    selector: 'app-request-appointment',
    templateUrl: './request-appointment.component.html',
    styleUrls: ['./request-appointment.component.scss']
})
export class RequestAppointmentComponent implements OnInit {
    //public callLog: any[] = [];
    public requestData: any[] = [];
    public tableData: any[] = [];
    public commentsFlag: boolean = false;
    public phoneType: boolean = false;
    public textType: boolean = false;
    public emailType: boolean = false;
    public websiteType: boolean = false;
    public splitStr: Array < string > = [];
    public buttonContent: string;
    //public callLogLength: number;
    public comments: boolean = false;
    public expandFlag: boolean = true;
    public setViewMore: boolean = false;
    public setViewMoreLink: boolean = true;
    public callLogStart: any;
    //public callLogEnd: any;
    public purposeOfCall: any[] = [];
    public callIntentValue: any;
    public intentCode: any;
    public commentsForm: FormGroup;
    public selectedRow: number = 0;
    //public initRadioFlag: number = 0;
    public slashView: any;
    public callStartTime: Array < string > = [];
    public callEndTime: Array < string > = [];
    public monitoringComments: Array < string > = [];
    public selectedObject: any;
    public contactObject = [{
            'primary': {
                'contactMethod': '',
                'firstName': '',
                'lastName': '',
                'contactType': '',
                'phoneContactValue': '',
                'emailContactValue': '',
                'websiteContactValue': '',
                'textContactValue': ''
            }
        },
        {
            'secondary': {
                'contactMethod': '',
                'firstName': '',
                'lastName': '',
                'contactType': '',
                'phoneContactValue': '',
                'emailContactValue': '',
                'websiteContactValue': '',
                'textContactValue': ''
            }
        }
    ];
    @Input()
    set slashLoad(flagArg) {
        this.slashView = flagArg;
    }
    @Input() currentlySelectedRow: number;
    @Output() activateTab: EventEmitter < any > = new EventEmitter();
    @ViewChild('radioVal') rv: ElementRef;
    @ViewChild('expandWindow') ew;

    constructor(public jbhGlobals: JBHGlobals, public formBuilder: FormBuilder) {
    }


    ngOnInit() {
        this.commentsForm = this.formBuilder.group({
            comments: ['', Validators.required],
        });
        this.getCallLogInfo();
        this.loadContactTable();

    }
    public loadContactTable() {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.appointments.getContactService).subscribe(response => {
            const data = response[0]['contacts'];
            for (let i = 0; i < data.length; i++) {
                if (data[i]['contactType'] === 'primary') {
                    this.setContactData(this.contactObject[0]['primary'], data[i], 'primary');
                } else if (data[i]['contactType'] === 'secondary') {
                    this.setContactData(this.contactObject[1]['secondary'], data[i], 'secondary');
                }
            }
            this.requestData = response;
            this.tableData = this.contactObject;
            /* Load the first contact Method */
            if (this.tableData.length > 0) {
                if (this.currentlySelectedRow === 0) {
                    this.showContact(this.tableData[this.currentlySelectedRow]['primary'].contactMethod);
                    this.selectedObject = this.tableData[this.currentlySelectedRow]['primary'];
                } else if (this.currentlySelectedRow === 1) {
                    this.showContact(this.tableData[this.currentlySelectedRow]['secondary'].contactMethod);
                    this.selectedObject = this.tableData[this.currentlySelectedRow]['secondary'];
                }
            }
            //this.callLog = this.requestData[1]['CallLogDTO'];
            //this.callLogLength = this.requestData[1]['CallLogDTO'].length;
        });
    }
    public setContactData(baseObject, data, contactType) {
        if (baseObject['contactMethod'] === '') {
            baseObject['contactMethod'] = data['contactMethod'];
            baseObject['firstName'] = data['firstName'];
            baseObject['lastName'] = data['lastName'];
            baseObject['contactType'] = data['contactType'];
            this.setContactValue(data['contactMethod'], data['contactValue'], baseObject);
            this.updateContactTypeObject(contactType, baseObject);
        } else {
            const temp = baseObject['contactMethod'].concat(', ' + data['contactMethod']);
            baseObject['contactMethod'] = temp;
            this.setContactValue(data['contactMethod'], data['contactValue'], baseObject);
            this.updateContactTypeObject(contactType, baseObject);
        }
    }
    public updateContactTypeObject(contactType, value) {
        if (contactType === 'primary') {
            this.contactObject['primary'] = value;
        } else if (contactType === 'secondary') {
            this.contactObject['secondary'] = value;
        }
    }
    public setContactValue(key, value, base) {
        switch (key) {
            case 'Phone':
                base.phoneContactValue = value;
                break;
            case 'EMAIL':
                base.emailContactValue = value;
                break;
            case 'Website':
                base.websiteContactValue = value;
                break;
            case 'Text':
                base.textContactValue = value;
                break;
            default:
                break;
        }
        this.updateContactTypeObject(base.contactType, base);
    }
    public getCallLogInfo() {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.appointments.getCallLog).subscribe(data => {
            this.callLogStart = data;
            this.callIntent();
            for (let i = 0; i < data.length; i++) {
                const d = new Date(this.callLogStart[i]['callBeginDateTime']);
                this.callStartTime.push(d.toLocaleString());
            }
            for (let i = 0; i < data.length; i++) {
                const e = new Date(this.callLogStart[i]['callEndDateTime']);
                this.callEndTime.push(e.toLocaleString());
            }
        });
    }
    public callIntent() {
        this.intentCode = this.callLogStart[0]['intentCode'];
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.appointments.getCallPurpose).subscribe(data => {
            for (let i = 0; i < data.length; i++) {
                this.purposeOfCall.push(data[i]['id']);
            }
            for (let j = 0; j < this.purposeOfCall.length; j++) {
                if (this.intentCode === this.purposeOfCall[j]) {
                    this.callIntentValue = data[j].type;
                }
            }
        });
    }
    changeContact(contactData, index) {
        console.log(contactData);
        this.selectedObject = contactData;
        if (index === 0) {
            this.showContact(contactData.primary.contactMethod);
            this.selectedObject = contactData.primary;
        } else if (index === 1) {
            this.showContact(contactData.secondary.contactMethod);
            this.selectedObject = contactData.secondary;
        }
        this.selectedRow = index;
        this.currentlySelectedRow = this.selectedRow;

    }
    showContact(contactMethod) {
        this.phoneType = false;
        this.emailType = false;
        this.textType = false;
        this.websiteType = false;
        this.splitStr = contactMethod.split(',');
        for (let i = 0; i < this.splitStr.length; i++) {
            const trimmedContent = (this.splitStr[i].length > 0) ? this.splitStr[i].trim().toLowerCase() : '';
            if (trimmedContent === 'phone') {
                this.phoneType = true;
            } else if (trimmedContent === 'email') {
                this.emailType = true;
            } else if (trimmedContent === 'text') {
                this.textType = true;
            } else if (trimmedContent === 'website') {
                this.websiteType = true;
            }
        }
    }

    openSet(event) {
        this.buttonContent = event.target.innerHTML;
        const requestEvent = {
            'buttonContent': event.target.innerHTML,
            'selectedRow': this.currentlySelectedRow,
            'selectedObject': this.selectedObject
        };
        this.activateTab.emit(requestEvent);
        console.log(requestEvent);
    }
    expand() {
        this.ew.nativeElement.style.display = 'block';
        this.comments = true;
        this.expandFlag = false;
    }
    collapse() {
        this.ew.nativeElement.style.display = 'none';
        this.comments = false;
        this.expandFlag = true;
    }
    cancel() {
        this.ew.nativeElement.style.display = 'none';
        this.expandFlag = true;
        this.comments = false;
    }
    viewMore() {
        this.setViewMore = true;
        this.setViewMoreLink = false;
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.appointments.getMonitoringComments).subscribe(data => {
            const monitoringTaskWorkflow = data[0]['monitoringTaskAssignmentRoleTypeAssociationDTO']['monitoringTaskWorkflowDTO'];
            for (let i = 0; i < monitoringTaskWorkflow.length; i++) {
                this.monitoringComments.push(monitoringTaskWorkflow[i].monitoringTaskComment);
            }
        });

    }
    saveComments() {
        console.log(this.commentsForm.value);
    }
}
