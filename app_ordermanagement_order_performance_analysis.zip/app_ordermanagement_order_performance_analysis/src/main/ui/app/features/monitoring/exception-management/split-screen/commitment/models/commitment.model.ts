export class CommitmentModel {
    commitvar = {
        tempView: 1,
        checkView: 1,
        callDetail: false
    };
}
