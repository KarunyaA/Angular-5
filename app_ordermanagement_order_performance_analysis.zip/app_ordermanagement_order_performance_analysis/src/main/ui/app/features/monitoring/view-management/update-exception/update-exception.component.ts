import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-exception',
  templateUrl: './update-exception.component.html',
  styleUrls: ['./update-exception.component.scss']
})
export class UpdateExceptionComponent implements OnInit {

    constructor() {}

    ngOnInit() {}

}
