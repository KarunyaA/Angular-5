import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QualificationExceptionComponent } from './qualification-exception.component';

describe('QualificationExceptionComponent', () => {
  let component: QualificationExceptionComponent;
  let fixture: ComponentFixture<QualificationExceptionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QualificationExceptionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QualificationExceptionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
