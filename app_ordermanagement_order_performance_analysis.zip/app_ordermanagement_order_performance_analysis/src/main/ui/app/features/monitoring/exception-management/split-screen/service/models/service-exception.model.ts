export class ServiceExceptionModel {
    servicevar
        = {
            emailFlag: true
        };
}
