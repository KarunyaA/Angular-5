import {
    Component,
    OnInit,
    EventEmitter,
    Output,
    ViewChild,
    ElementRef,
    Input
} from '@angular/core';
import {
    IMyOptions,
    IMyDateModel
} from 'mydatepicker';
import {
    FormBuilder,
    Validators,
    FormGroup
} from '@angular/forms';

import {
    JBHGlobals
} from 'app/app.service';
import {
    Headers,
    RequestOptions
} from '@angular/http';


@Component({
    selector: 'app-set-appointment',
    templateUrl: './set-appointment.component.html',
    styleUrls: ['./set-appointment.component.scss']
})

export class SetAppointmentComponent implements OnInit {
    public highlightedStep: number;
    public deliveryDate: any;
    public pickUpDate: any;
    public flag = 0;
    public names: any = [];
    //public time: any = [];
    public items: any = [];
    //public AppointmentReason: any = [];
    public scheduleForm: FormGroup;
    public prefName = '';
    public obj = '';
    public reasonCategoryParams: string;
    public appointmentReasonArray: any[];
    public reason: any[];
    public slashViewAppointment: any;
    //public preferedName: string = '';
    public prferedNameTypeAheadUrl: string;
    public debounceValue: any;
    public preferedNameData: any[] = [];
    public overrideWarnings: boolean = false;
    public startDateFlag: boolean = false;
    public endDateFlag: boolean = false;
    public dateCompareFlag: boolean = false;
    public timeCompareFlag: boolean = false;
    public startTimeMinFlag: boolean = false;
    public currentDate: any = new Date();
    public currentYear: number = this.currentDate.getFullYear();
    public currentMonth: number = this.currentDate.getMonth() + 1;
    public currentDay: number = this.currentDate.getDate() - 1;


    @Input()
    set slashLoad(flagArg) {
        this.slashViewAppointment = flagArg;
    }

    @Output() activateTab: EventEmitter < any > = new EventEmitter();
    @ViewChild('warningMsg') warningMsg: ElementRef;
    @ViewChild('override') override: ElementRef;
    @ViewChild('reasonCateg') reasonCateg;
    @ViewChild('reasonSetting') reasonSetting;
    @ViewChild('startDate') startDate;
    @ViewChild('endDate') endDate;
    public myDatePickerOptions: IMyOptions = {
        todayBtnTxt: 'Today',
        dateFormat: 'mm-dd-yyyy',
        firstDayOfWeek: 'mo',
        showClearDateBtn: false,
        editableDateField: false,
        sunHighlight: true,
        height: '34px',
        inline: false,
        disableUntil: {
            year: this.currentYear,
            month: this.currentMonth,
            day: this.currentDay
        },
        selectionTxtFontSize: '14px'
    };

    constructor(public jbhGlobals: JBHGlobals, public fb: FormBuilder) {
        this.highlightedStep = 1;
        this.createForm();
    }
    validateStartDate(datepicker) {
        if (datepicker.selectionDayTxt === '' || datepicker.selectionDayTxt === undefined) {
            this.startDateFlag = true;
        } else {
            this.startDateFlag = false;
        }
    }
    validateEndDate(datepicker) {
        if (datepicker.selectionDayTxt === '' || datepicker.selectionDayTxt === undefined) {
            this.endDateFlag = true;
        } else {
            this.endDateFlag = false;
        }
    }
    validateDates() {

        const startDateVal = this.scheduleForm.controls.startDate.value.jsdate;
        const endDateVal = this.scheduleForm.controls.endDate.value.jsdate;
        const startTimeVal = this.scheduleForm.controls.startTime.value;
        const endTimeVal = this.scheduleForm.controls.endTime.value;
        const startDateObject = new Date(startDateVal).getTime();
        const endDateObject = new Date(endDateVal).getTime();
        console.log(startDateVal !== '');
        console.log(startDateVal !== undefined);

        const startDateNotNull = (startDateVal !== undefined);
        const endDateNotNull = (endDateVal !== undefined);
        if (startDateNotNull && startTimeVal !== '') {
            const startDate = (startDateVal.toString()).substr(4, 10);
            const currentDate = (this.currentDate.toString()).substr(4, 10);
            const startTimeMinutes = startTimeVal.split(':')[0] * 60 + parseInt(startTimeVal.split(':')[1]);
            const currentTimeMinutes = this.currentDate.getHours() * 60 + this.currentDate.getMinutes();
            if (startDate === currentDate) {
                if (startTimeMinutes < (currentTimeMinutes + 60)) {
                    this.startTimeMinFlag = true;
                    this.timeCompareFlag = false;
                    this.dateCompareFlag = false;
                } else {
                    this.startTimeMinFlag = false;
                }

            } else {
                this.startTimeMinFlag = false;
            }

        }
        if (startDateNotNull && endDateNotNull && startTimeVal !== '' && endTimeVal !== '') {
            if (startDateVal > endDateVal) {
                this.dateCompareFlag = true;
                this.timeCompareFlag = false;
            } else if (startDateObject === endDateObject) {
                if (startTimeVal > endTimeVal) {
                    this.timeCompareFlag = true;
                    this.dateCompareFlag = false;
                } else {
                    this.timeCompareFlag = false;
                    this.dateCompareFlag = false;
                }
            } else {
                this.dateCompareFlag = false;
                this.timeCompareFlag = false;
            }

        }
    }
    onpickUpDateChanged(event: IMyDateModel) {
        // event properties are: event.date, event.jsdate, event.formatted and event.epoc
        this.startDateFlag = false;
        this.pickUpDate = event.epoc;
        this.scheduleForm.controls.startDate.setValue(event);
        this.validateDates();
    }
    ondeliveryDateChanged(event: IMyDateModel) {
        // event properties are: event.date, event.jsdate, event.formatted and event.epoc
        this.endDateFlag = false;
        this.deliveryDate = event.epoc;
        this.scheduleForm.controls.endDate.setValue(event);
        this.validateDates();
    }
    createForm() {
        this.scheduleForm = this.fb.group({
            startDate: ['', Validators.required],
            startTime: ['', Validators.required],
            endDate: ['', Validators.required],
            endTime: ['', Validators.required],
            comments: ['', Validators.compose([Validators.maxLength(250)])],
            appntReasonSetting: ['', Validators.required],
            appntReasonCateg: ['', Validators.required],
            preferedName: ['', Validators.required],
            appNum: ['', Validators.compose([Validators.required, this.jbhGlobals.customValidator.onlyNumber])]
        });
    }

    ngOnInit() {
        this.serviceCall();
        this.getpreferredname();
        this.appointmentReasonOnInit();
        this.debounceValue = this.jbhGlobals.settings.debounce;
        this.scheduleForm['controls']['preferedName']['valueChanges']
            .debounceTime(this.debounceValue)
            .distinctUntilChanged()
            .subscribe((value) => {
                if (!this.jbhGlobals.utils.isEmpty(value) && value !== undefined) {
                    //this.preferedName = '';
                    this.getPreferedName(value);
                }
            }, (err: Error) => {});

        this.preferredNameService();
    }

    public preferredNameService() {
        console.log(this.jbhGlobals.endpoints.appointments.preferredName);
        const headers = new Headers({
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'JBH-EOI-VER': 1.0,
            'JBH-EOI-APPID': 'WBT',
            'JBH-EOI-PID': 'PIDWTA'
        });
        const options = new RequestOptions({
            headers: headers
        });
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.appointments.preferredName, options).subscribe(data => {
            console.log(data);
        });
    }

    public getPreferedName(e) {
        this.prferedNameTypeAheadUrl = this.jbhGlobals.endpoints.appointments.getPrferedNames;
        if (e.length > 0) {
            this.preferedNameData = [];
            const nameParam = {
                'prferedName': e
            };
            this.jbhGlobals.apiService.getData(this.prferedNameTypeAheadUrl, nameParam).subscribe(data => {
                if (!this.jbhGlobals.utils.isEmpty(data)) {
                    for (let i = 0; i < data['people'].length; i++) {
                        this.preferedNameData.push(data['people'][i].firstName);
                        console.log(this.preferedNameData);
                    }
                }
            });
        }
    }
    public typeaheadNameSelect(prefname) {
        console.log(prefname);
    }
    public serviceCall() {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.appointments.recommendedAppointmentTimeStamp).subscribe(data => {
            this.items = data['_embedded']['appointments'][0]['recommendedAppointmentTimeStamp'];
        });
    }
    public getpreferredname() {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.appointments.getpreferredname).subscribe(data => {
            console.log(data);
            this.names = data['people'];
            console.log(this.names);
        });
    }
    /**********************reason*********************************/
    public appointmentReasonOnInit() {
        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.appointments.getAppointmentReason).subscribe(data => {
            this.reason = [];
            console.log(data['_embedded']['appointmentSetReasonCategories'][0]['appointmentSetReasonCategoryDescription']);
            for (let i = 0; i < data['_embedded']['appointmentSetReasonCategories'].length; i++) {
                this.reason.push(data['_embedded']['appointmentSetReasonCategories'][i]['appointmentSetReasonCategoryDescription']);
            }
        });

    }
    public reasonSettingFunction() {
        const url = this.jbhGlobals.endpoints.appointments.appointmentReasonSetting;
        const params = {
            'appointmentSetReasonCategoryCode': this.reasonCategoryParams
        };
        this.jbhGlobals.apiService.getData(url, params).subscribe(data => {
            console.log(data);
            this.appointmentReasonArray = [];
            for (let i = 0; i < data['_embedded']['appointmentSetReasons'].length; i++) {
                this.appointmentReasonArray.push(data['_embedded']['appointmentSetReasons'][i]['appointmentSetReasonDescription']);
            }
        });
    }
    public onReasonCategoryTagSelection(event) {
        console.log(event);
        this.reasonCategoryParams = event.text.toLowerCase();
        this.reasonSettingFunction();
        this.reasonSetting.active = [];

    }
    public onReasonSettingTagSelection(event) {

    }
    public blurredOnSelect(event, selectComponent) {
        console.log(event);
        console.log(selectComponent);

        const compName = selectComponent.element.nativeElement.id;
        console.log(compName);
        if (event.innerText === '') {
            this.scheduleForm.get(compName).markAsTouched();
            this.scheduleForm.get(compName).setErrors(
                compName === 'appntReasonCateg' || compName === 'appntReasonSetting' ? {
                    'mandatory': true
                } : null);
            if (selectComponent.multiple !== true && selectComponent.active.length > 0) {
                selectComponent.active = [];

            }
            if (compName === 'appntReasonCateg') {
                this.onClearOrChangeAppntReasonCateg();
            }
            //this.reasonSetting.active = [];
            //this.appointmentReasonArray=[];
        }

    }
    public onClearOrChangeAppntReasonCateg() {
        this.reasonSetting.active = [];
        this.appointmentReasonArray = null;
    }
    saveData() {
        //console.log(this.scheduleForm.value);
        this.obj = this.scheduleForm.value;
        console.log(this.obj);
        this.overrideWarnings = true;
    }
    cancel() {
        this.activateTab.emit('setAppointmentCancel');
    }
    onSelect(e) {
        //console.log(e.target.value);
        this.prefName = e.target.value;

    }

    overrideExceptionClick() {
        const overrideParams = [{
            'ruleExceptionID': 25,
            'exceptionApproverID': 1,
            'overrideReasonCode': 'SpotOffer',
            'pushToDownStreamTypeCode': 'Monitor',
            'overrideComment': 'unit test12132'
        }];
        this.jbhGlobals.apiService.addData(this.jbhGlobals.endpoints.appointments.postOverride, overrideParams).subscribe(data => {
            console.log(data);
        });

        const override = {
            'name': this.prefName,
            'warning1': this.warningMsg.nativeElement.children[2].innerHTML,
            'warning2': this.warningMsg.nativeElement.children[3].innerHTML,
            'warning3': this.warningMsg.nativeElement.children[4].innerHTML
        };
        console.log(override);
        console.log(override.warning2);
    }
    public setAppointmentValidation() {
        const me = this;
        if (this.startDate.selectionDayTxt === '') {
            this.startDateFlag = true;
        } else {
            this.startDateFlag = false;
        }
        this.jbhGlobals.utils.forIn(this.scheduleForm.controls.startTime,
            function(value, name, object) {
                me.scheduleForm.controls.startTime.markAsTouched();
            });
        if (this.endDate.selectionDayTxt === '') {
            this.endDateFlag = true;
        } else {
            this.endDateFlag = false;
        }
        this.jbhGlobals.utils.forIn(this.scheduleForm.controls.endTime,
            function(value, name, object) {
                me.scheduleForm.controls.endTime.markAsTouched();
            });
        this.jbhGlobals.utils.forIn(this.scheduleForm.controls.appNum,
            function(value, name, object) {
                me.scheduleForm.controls.appNum.markAsTouched();
            });
        this.jbhGlobals.utils.forIn(this.scheduleForm.controls.appntReasonCateg,
            function(value, name, object) {
                me.scheduleForm.controls.appntReasonCateg.markAsTouched();
            });
        this.jbhGlobals.utils.forIn(this.scheduleForm.controls.appntReasonSetting,
            function(value, name, object) {
                me.scheduleForm.controls.appntReasonSetting.markAsTouched();
            });
        this.jbhGlobals.notifications.error('Appointments', 'Fill all required fields.');
    }
}
