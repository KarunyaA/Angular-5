export class EdiModel {
    edivar = {
        errorFlag: false,
        resolveFlag: false,
        showMenu: false,
        menuFlag: ''

    };
}
