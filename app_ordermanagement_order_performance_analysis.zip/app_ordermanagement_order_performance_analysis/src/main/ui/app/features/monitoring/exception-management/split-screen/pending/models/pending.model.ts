import { FormGroup } from '@angular/forms';

export class PendingModel {
    rejectForm: FormGroup;
    rejectItemList: any;
    reasonCodelist: any;
    reasonCodelistArray: any;
    orderId: any;
    reasonCodeVal: any;
    pendingvar = {
        invalidreasoncodeflag: false,
        rejectUrl: '',
        acceptUrl: ''
    };
}
