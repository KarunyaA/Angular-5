import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-qualification-exception',
  templateUrl: './qualification-exception.component.html',
  styleUrls: ['./qualification-exception.component.scss']
})
export class QualificationExceptionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
