import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ConfigureNewExceptionComponent } from './configure-new-exception.component';

const routes: Routes = [
  {
    path: '',
    component: ConfigureNewExceptionComponent,
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ConfigureNewExceptionRoutingModule { }
