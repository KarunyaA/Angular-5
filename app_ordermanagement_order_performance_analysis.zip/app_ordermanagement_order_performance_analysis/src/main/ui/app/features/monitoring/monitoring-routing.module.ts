import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MonitoringComponent } from './monitoring.component';

const routes: Routes = [
  {
    path: '',
    component: MonitoringComponent
  },
  {
    path: 'exceptionmaintenance',
    loadChildren: 'app/features/monitoring/exception-maintenance/exception-maintenance.module#ExceptionMaintenanceModule',
  },
  {
    path: 'exceptionmanagement',
    loadChildren: 'app/features/monitoring/exception-management/exception-management.module#ExceptionManagementModule',
  }


];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MonitoringRoutingModule { }
