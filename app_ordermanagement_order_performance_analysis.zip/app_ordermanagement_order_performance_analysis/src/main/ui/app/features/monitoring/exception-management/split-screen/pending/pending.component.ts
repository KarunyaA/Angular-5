import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { JBHGlobals } from 'app/app.service';
import { ValidationService } from 'app/shared/jbh-validation/validation.service';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
// import { ModalDirective } from 'ngx-bootstrap/modal';
import { ExceptionManagementComponent } from '../../exception-management.component';
import { PendingModel } from './models/pending.model';


@Component({
    selector: 'app-pending',
    templateUrl: './pending.component.html',
    styleUrls: ['./pending.component.scss']
})

export class PendingComponent implements OnInit {
    parentFlag: any;
    rejReason: any;
    pendingModel: PendingModel;

    @ViewChild('rejectScreen') public rejectScreenLink;
    @ViewChild('rejectClose') public rejectClose;

    @Input()
    set flag(flagArg) {
        this.parentFlag = flagArg;
    }

    constructor(public jbhGlobals: JBHGlobals, public formBuilder: FormBuilder, public closeSplitScreen: ExceptionManagementComponent) {
        this.pendingModel = new PendingModel();
    }

    ngOnInit() {
        this.pendingModel.rejectForm = this.formBuilder.group({
            rejectOption: ['', Validators.required],
            rejectComments: new FormControl('', Validators
                .compose([ValidationService.maxLengthValidator, ValidationService.commentValidator]))
        });

        this.jbhGlobals.apiService.getData(this.jbhGlobals.endpoints.monitoring.rejectReason).subscribe(data => {
            this.pendingModel.reasonCodelistArray = this.jbhGlobals.utils.uniqBy(data['_embedded']['orderStatusEventReasons'],
                'orderStatusEventReasonDescription');
            const reasonCodelistDes = this.jbhGlobals.utils.map(this.pendingModel.reasonCodelistArray, 'orderStatusEventReasonDescription');
            this.pendingModel.reasonCodelist = reasonCodelistDes;
            this.pendingModel.pendingvar.invalidreasoncodeflag = false;
        });

    }
    /* accept/reject changes starts */
    onTypeValidate(thisObj: string, controlVal: any): void {
        const reasonCodelistArray = Array.prototype.slice.call(controlVal);
        for (let i = 0; i < reasonCodelistArray.length; i++) {

            if (reasonCodelistArray[i] === thisObj) {
                this.pendingModel.pendingvar.invalidreasoncodeflag = false;
                break;
            } else {
                this.pendingModel.pendingvar.invalidreasoncodeflag = true;
            }
        }
        console.log(thisObj);
    }

    public rejectScreenShown() {
        this.rejectScreenLink.nativeElement.focus();
        this.setUpKeyboardShortcutsRejectScreen();
        console.log(this.rejectScreenLink.nativeElement.focus());

    }

    public setUpKeyboardShortcutsRejectScreen() {
        this.jbhGlobals.shortkeys.getData().subscribe(data => {
            if (data.keyCode === 'alt+1') {
                this.rejectClose.nativeElement.focus();
            }
        });
    }

    public onSelectReason(rejReason) {
        console.log(this.rejReason);
        console.log(rejReason);
        // console.log(this.rejReason[0].text);
    }

    onSelectPrefix(event: Object, selectedDropdown: string) {
        const selectedValue = event['id'];
        const itrReasonCode = this.pendingModel.reasonCodelistArray.filter(function (item) {
            return typeof item === 'object' && item['orderStatusEventReasonDescription'].indexOf(selectedValue) > -1;
        });
        this.pendingModel.reasonCodeVal = (itrReasonCode && itrReasonCode.length !== 0) ?
            itrReasonCode[0]['orderStatusEventReasonID'] : '';
        this.pendingModel.pendingvar.invalidreasoncodeflag = false;
        console.log(this.pendingModel.reasonCodeVal);
    }

    rejectClick() {
        const obj = {
            'orderStatusReasonId': this.pendingModel.reasonCodeVal,
            'orderRejectComments': this.pendingModel.rejectForm.controls['rejectComments']['_value']
        };
        //const orderId = this.closeSplitScreen.selected[0].OrderNumber;
        const orderId = 735;
        this.pendingModel.pendingvar.rejectUrl = this.jbhGlobals.endpoints.monitoring.reject.replace('_orderId', orderId);
        this.jbhGlobals.apiService.patchData(this.pendingModel.pendingvar.rejectUrl, obj).subscribe(data => {
            const respVal = data;
            this.jbhGlobals.notifications.alert('Success', '' + respVal + '');
        }, (err: any) => {
            console.log(err);
            this.jbhGlobals.notifications.alert('Failure', '' + err.errorMessage + '');
        });
        this.resetRejectForm();
    }

    acceptButtonClick() {
        const obj = {
            'orderId': this.closeSplitScreen.exceptionManagementModel.managementvar.selected[0].OrderNumber
        };
        //const orderId = this.closeSplitScreen.selected[0].OrderNumber;
        const orderId = 735;
        this.pendingModel.pendingvar.acceptUrl = this.jbhGlobals.endpoints.monitoring.accept.replace('_orderId', orderId);
        this.jbhGlobals.apiService.patchData(this.pendingModel.pendingvar.acceptUrl, obj).subscribe(data => {
            const respVal = data;
            this.jbhGlobals.notifications.alert('Success', '' + respVal[0] + '');
        }, (err: any) => {
            console.log(err);
            this.jbhGlobals.notifications.alert('Failure', '' + err.errorMessage + '');
        });
    }

    resetRejectForm() {
        this.pendingModel.rejectForm.reset();
    }
    /* accept/reject changes ends */

}
