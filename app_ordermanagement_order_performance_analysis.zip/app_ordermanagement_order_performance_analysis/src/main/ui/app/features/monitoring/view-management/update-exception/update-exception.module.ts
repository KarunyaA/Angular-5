import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UpdateExceptionRoutingModule } from './update-exception-routing.module';


@NgModule({
  imports: [
    CommonModule,
    UpdateExceptionRoutingModule
  ],
  declarations: []
})
export class UpdateExceptionModule { }
