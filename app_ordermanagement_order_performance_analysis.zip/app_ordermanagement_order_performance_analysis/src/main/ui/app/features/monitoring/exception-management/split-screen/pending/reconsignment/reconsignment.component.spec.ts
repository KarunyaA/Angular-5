import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReconsignmentComponent } from './reconsignment.component';

describe('ReconsignmentComponent', () => {
  let component: ReconsignmentComponent;
  let fixture: ComponentFixture<ReconsignmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReconsignmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReconsignmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
