import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ConfigureNewExceptionRoutingModule } from './configure-new-exception-routing.module';

@NgModule({
  imports: [
    CommonModule,
    ConfigureNewExceptionRoutingModule
  ],
  declarations: []
})
export class ConfigureNewExceptionModule { }
