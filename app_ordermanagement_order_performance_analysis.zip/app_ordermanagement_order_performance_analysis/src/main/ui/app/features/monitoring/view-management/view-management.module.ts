import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BsDropdownModule } from 'ngx-bootstrap';

import { JBHDataTableModule } from 'app/shared/jbh-data-table/jbh-data-table.module';
import { JbhSearchFilterModule } from '../../../shared/jbh-search-filter/jbh-search-filter.module';

import { ViewManagementRoutingModule } from './view-management-routing.module';
import { ViewManagementComponent } from './view-management.component';
import { ExceptionListingComponent } from './exception-listing/exception-listing.component';
import { ConfigureNewExceptionComponent } from './configure-new-exception/configure-new-exception.component';
import { UpdateExceptionComponent } from './update-exception/update-exception.component';

@NgModule({
  imports: [
    CommonModule,
    BsDropdownModule.forRoot(),
    JBHDataTableModule,
    JbhSearchFilterModule,
    ViewManagementRoutingModule
  ],
  declarations: [ViewManagementComponent, ExceptionListingComponent, ConfigureNewExceptionComponent, UpdateExceptionComponent]
})
export class ViewManagementModule { }
