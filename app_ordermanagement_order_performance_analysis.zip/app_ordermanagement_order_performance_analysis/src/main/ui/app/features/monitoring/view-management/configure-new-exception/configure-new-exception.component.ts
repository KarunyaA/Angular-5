import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-configure-new-exception',
  templateUrl: './configure-new-exception.component.html',
  styleUrls: ['./configure-new-exception.component.scss']
})
export class ConfigureNewExceptionComponent implements OnInit {

    constructor() {}

    ngOnInit() {}

}
