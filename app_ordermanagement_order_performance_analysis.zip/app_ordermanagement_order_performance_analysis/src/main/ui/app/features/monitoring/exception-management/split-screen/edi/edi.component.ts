import { Component, OnInit, Input } from '@angular/core';

import { ExceptionManagementComponent } from '../../exception-management.component';
import { EdiModel } from './models/edi.model';

@Component({
    selector: 'app-edi',
    templateUrl: './edi.component.html',
    styleUrls: ['./edi.component.scss'],
})

export class EdiComponent implements OnInit {
    parentFlag;
    ediModel: EdiModel;
    @Input()

    set flag(flagArg) {
        this.parentFlag = flagArg;
    }
    constructor(public closeSplitScreen: ExceptionManagementComponent) {
            this.ediModel = new EdiModel();
        }
        // To enable snooze screen
    enableSnooze() {
        this.ediModel.edivar.errorFlag = false;
        this.ediModel.edivar.showMenu = true;
        this.ediModel.edivar.menuFlag = 'Snooze';

    }

    // To enable ignore screen

    enableIgnore() {
        this.ediModel.edivar.errorFlag = false;
        this.ediModel.edivar.showMenu = true;
        this.ediModel.edivar.menuFlag = 'Ignore';
    }

    // To enable complete screen

    enableComplete() {
        this.ediModel.edivar.errorFlag = false;
        this.ediModel.edivar.showMenu = true;
        this.ediModel.edivar.menuFlag = 'Complete';
    }

    closeMenu() {
        this.ediModel.edivar.showMenu = false;
        this.ediModel.edivar.resolveFlag = true;
    }

    closeSplit() {
        this.closeSplitScreen.exceptionManagementModel.managementvar.selected = [];
        this.closeSplitScreen.jbhdatatable.toggleDataTableDetail();
    }


    ngOnInit() {}

}
