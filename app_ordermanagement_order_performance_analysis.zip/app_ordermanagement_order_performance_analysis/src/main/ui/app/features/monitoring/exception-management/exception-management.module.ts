import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { AccordionModule } from 'ngx-bootstrap';
import { MyDatePickerModule } from 'mydatepicker';
import { ModalModule, SortableModule } from 'ngx-bootstrap';
import { PopoverModule } from 'ngx-bootstrap';
import { BsDropdownModule } from 'ngx-bootstrap';
import { TypeaheadModule } from 'ngx-bootstrap';
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';


import { SelectModule } from 'app/shared/select';
import { JBHDataTableModule } from 'app/shared/jbh-data-table/jbh-data-table.module';
import { JbhSearchFilterModule } from '../../../shared/jbh-search-filter/jbh-search-filter.module';
import { JbhUtilsModule } from 'app/shared/jbh-utils/jbh-utils.module';

import { ExceptionManagementRoutingModule } from './exception-management-routing.module';
import { ExceptionManagementComponent } from './exception-management.component';
import { PendingComponent } from './split-screen/pending/pending.component';
import { RateComponent } from './split-screen/rate/rate.component';
import { CommitmentComponent } from './split-screen/commitment/commitment.component';
import { EdiComponent } from './split-screen/edi/edi.component';
import { AppointmentDetailsComponent } from './split-screen/shared-monitor/appointment-details/appointment-details.component';
import { ManageAppointmentsComponent } from './split-screen/shared-monitor/manage-appointments/manage-appointments.component';
import { OrderDetailsComponent } from './split-screen/appointment/order-details/order-details.component';
import { RequestAppointmentComponent } from './split-screen/shared-monitor/request-appointment/request-appointment.component';
import { SetAppointmentComponent } from './split-screen/shared-monitor/set-appointment/set-appointment.component';
import { SplitWrapperComponent } from './split-screen/appointment/split-wrapper/split-wrapper.component';
import { ManageColumnsComponent } from '../view-screens/manage-columns/manage-columns.component';
import { MyTaskComponent } from '../view-screens/my-task/my-task.component';
import { UserModalComponent } from '../view-screens/user-modal/user-modal.component';
import { CustomViewsComponent } from '../view-screens/custom-views/custom-views.component';
import { ManageViewsComponent } from '../view-screens/manage-views/manage-views.component';
import { DwellComponent } from './split-screen/dwell/dwell.component';
import { ServiceComponent } from './split-screen/service/service.component';
import { SlashLoadComponent } from './split-screen/slash-load/slash-load.component';
import { QualificationExceptionComponent } from './split-screen/pending/qualification-exception/qualification-exception.component';
import { ReconsignmentComponent } from './split-screen/pending/reconsignment/reconsignment.component';
import { ChangeDetailComponent } from './split-screen/pending/change-detail/change-detail.component';

@NgModule({
    imports: [
        CommonModule,
        JBHDataTableModule,
        JbhSearchFilterModule,
        TabsModule.forRoot(),
        AccordionModule.forRoot(),
        MyDatePickerModule,
        ModalModule.forRoot(),
        FormsModule,
        ReactiveFormsModule,
        PopoverModule.forRoot(),
        SelectModule,
        TypeaheadModule,
        SortableModule.forRoot(),
        ModalModule.forRoot(),
        JbhUtilsModule,
        BsDropdownModule.forRoot(),
        PerfectScrollbarModule,
        ExceptionManagementRoutingModule
    ],

    declarations: [
        ExceptionManagementComponent,
        PendingComponent,
        RateComponent,
        CommitmentComponent,
        EdiComponent,
        AppointmentDetailsComponent,
        ManageAppointmentsComponent,
        OrderDetailsComponent,
        RequestAppointmentComponent,
        SetAppointmentComponent,
        SplitWrapperComponent,
        ManageColumnsComponent,
        MyTaskComponent,
        UserModalComponent,
        CustomViewsComponent,
        ManageViewsComponent,
        DwellComponent,
        ServiceComponent,
        SlashLoadComponent,
        QualificationExceptionComponent,
        ReconsignmentComponent,
        ChangeDetailComponent
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class ExceptionManagementModule {}
