import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Response } from '@angular/http';

import { JBHGlobals } from 'app/app.service';

@Injectable()
export class PendingService {
    constructor(private jbhGlobals: JBHGlobals) {}
    fetchRejectData(url, params, flag): Observable < Response[] > {
        if (params === null) {
            return this.jbhGlobals.apiService.getData(url, flag);
        } else {
            return this.jbhGlobals.apiService.getData(url, params, flag);
        }
    }
    pushData(url, params, flag): Observable < Response[] > {
        if (params === null) {
            return this.jbhGlobals.apiService.patchData(url, flag);
        } else {
            return this.jbhGlobals.apiService.patchData(url, params, flag);
        }
    }
}
