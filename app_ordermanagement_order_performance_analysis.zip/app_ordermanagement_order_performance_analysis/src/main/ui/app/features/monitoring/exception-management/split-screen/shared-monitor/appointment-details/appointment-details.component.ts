import {
    Component,
    OnInit
} from '@angular/core';
import {
    JBHGlobals
} from 'app/app.service';
import {
    ExceptionManagementComponent
} from '../../../exception-management.component';

@Component({
    selector: 'app-appointment-details',
    templateUrl: './appointment-details.component.html',
    styleUrls: ['./appointment-details.component.scss']
})
export class AppointmentDetailsComponent implements OnInit {

    //appointment: any[];
    public stopReason: string;
    //totalStops: number;
    //currentStop: number;
    public status: string;
    public addrLine1: string;
    public addrLine2: string;
    public state: string;
    public zipCode: string;
    public appointmentNumber: number;
    public stopId: number = 2983;
    public favUrl = '';
    public stopComments: string;
    public appointmentReference: string;
    public stopNumber: any;
    public orderId: string;
    constructor(public jbhGlobals: JBHGlobals, public exceptionManagementComponent: ExceptionManagementComponent) {

    }

    ngOnInit() {
        this.appointmentService();
    }

    public appointmentService() {
        // debugger;
        console.log(this.exceptionManagementComponent.exceptionManagementModel.managementvar.selected);
        this.stopNumber = this.exceptionManagementComponent.exceptionManagementModel.managementvar.selected[0]['StopNumber'];
        this.orderId = this.exceptionManagementComponent.exceptionManagementModel.managementvar.selected[0]['Order'];
        console.log(this.orderId);
        this.favUrl = this.jbhGlobals.endpoints.appointments.getAppointmentDetails;
        this.jbhGlobals.apiService.getData(this.favUrl + '/' + this.stopId).subscribe(data => {
            // this.jbhGlobals.apiService.getData(this.favUrl).subscribe(data => {

            console.log(data);
            // alert(data);
            this.stopReason = data['stop']['stopReason'];
            //this.totalStops = data.length;
            //this.currentStop = data['stop']['stopSequenceNumber'];
            this.stopId = data['stop']['stopID'];

            this.status = data['stop']['appointment'][0]['appointmentTypeCode'];
            this.appointmentReference = data['stopReferenceNumbers'];
            console.log(this.status);
            //this.appointmentNumber = this.stopDetails['stop']['appointment'][0]['appointmentDetails'][0]['appointmentDetailID'];
            this.appointmentNumber = data['stop']['appointment'][0]['appointmentID'];
            this.addrLine1 = data['locationDTO']['addressDTO']['addressLineOne'];
            this.addrLine2 = data['locationDTO']['addressDTO']['addressLineTwo'];
            this.state = data['locationDTO']['addressDTO']['state'];
            this.zipCode = data['locationDTO']['addressDTO']['zipCode'];
            this.stopComments = data['stop']['stopComments'];
            console.log(this.stopComments);
            console.log(this.status, this.appointmentNumber, this.addrLine1, this.addrLine2);
        });
    }
}
