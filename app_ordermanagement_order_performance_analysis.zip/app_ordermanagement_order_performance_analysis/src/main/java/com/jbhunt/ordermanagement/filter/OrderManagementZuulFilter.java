package com.jbhunt.ordermanagement.filter;


import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.jbhunt.biz.securepid.PIDCredentials;
import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;

import lombok.extern.slf4j.Slf4j;

/**
 * Zuul Filter class. To add header information.
 * 
 * @author rcon406
 *
 */
@Slf4j
@Component
public class OrderManagementZuulFilter extends ZuulFilter {

	private PIDCredentials ldapPidCredential;

	@Autowired
	public OrderManagementZuulFilter(PIDCredentials ldapPidCredential) {
		this.ldapPidCredential = ldapPidCredential;
	}

	@Override
	public Object run() {
		RequestContext ctx = RequestContext.getCurrentContext();
		final String auth = ldapPidCredential.getUsername() + ":" + ldapPidCredential.getPassword();
		final byte[] encodedAuth = Base64.encodeBase64(auth.getBytes());
		final String authHeader = "Basic " + new String(encodedAuth);
		ctx.getZuulRequestHeaders().put("Authorization", authHeader);
		return null;
	}

	@Override
	public boolean shouldFilter() {
		return true;
	}

	@Override
	public int filterOrder() {
		return 0;
	}

	@Override
	public String filterType() {
		return "pre";
	}

}