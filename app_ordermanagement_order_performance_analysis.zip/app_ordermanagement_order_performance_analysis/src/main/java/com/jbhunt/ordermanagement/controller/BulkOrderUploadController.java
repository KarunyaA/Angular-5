package com.jbhunt.ordermanagement.controller;

import java.io.IOException;
import java.util.Base64;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import com.jbhunt.ordermanagement.order.dto.BulkUploadResponseDTO;
import com.jbhunt.ordermanagement.properties.OrderProperties;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping(value = "/ordermanagementservices")
@Slf4j
public class BulkOrderUploadController {

    private RestTemplate restTemplate;
    private OrderProperties orderProperties;

    @Autowired
    public BulkOrderUploadController(RestTemplate restTemplate, OrderProperties orderProperties) {
        this.restTemplate = restTemplate;
        this.orderProperties = orderProperties;
    }

    @RequestMapping(value = "/uploadFile", method = RequestMethod.POST, consumes = "multipart/form-data")
    @ResponseBody
    public ResponseEntity<?> bulkOrderUpload(@RequestParam("uploadedFileName") MultipartFile multipartfile)
            throws RestClientException, IOException {
        log.info("___In Client Controller");
        String encoded = Base64.getEncoder().encodeToString(multipartfile.getBytes());
        ResponseEntity<BulkUploadResponseDTO> responseEntity = this.restTemplate.exchange(orderProperties.getOrderBaseUrl() + "/bulkorderupload",
                org.springframework.http.HttpMethod.POST, new HttpEntity(encoded), BulkUploadResponseDTO.class);
        return ResponseEntity.ok(responseEntity.getBody());
    }
}
