/*package com.jbhunt.ordermanagement.configuration;

import javax.servlet.FilterRegistration;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration;

import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.request.RequestContextListener;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.filter.CharacterEncodingFilter;
import org.springframework.web.filter.RequestContextFilter;
import org.springframework.web.servlet.DispatcherServlet;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;

import com.jbhunt.biz.security.sso.filters.AuthenticationFilter;
import com.jbhunt.biz.security.sso.filters.LogoutFilter;
import com.jbhunt.lib.lnf.session.SessionTimeoutFilter;

import AppServletConfiguration.AppServletConfiguration;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ApplicationInitializer implements WebApplicationInitializer {

	
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.springframework.web.WebApplicationInitializer#onStartup(javax.servlet
	 * .ServletContext)
	 
	@Override
	public void onStartup(ServletContext context) throws ServletException {
		log.info("WebApplicationInitializer..onStartup");
		// Character encoding filter
		FilterRegistration characterEncodingFilter = context.addFilter("encodingFilter", CharacterEncodingFilter.class);
		characterEncodingFilter.setInitParameter("encoding", "UTF-8");
		characterEncodingFilter.setInitParameter("forceEncoding", "true");
		characterEncodingFilter.addMappingForUrlPatterns(null, false, "/*");
		
		context.addFilter("requestContextFilter", new RequestContextFilter() ).addMappingForUrlPatterns(null, false, "/*");
		context.addListener( new RequestContextListener() );
        
		addServlet(context, "app", AppServletConfiguration.class, 1, "/index.html", "/error.html");
		//Authentication filter
		FilterRegistration authenticationFilter = context.addFilter("jbhSSOFilter", AuthenticationFilter.class);
		authenticationFilter.setInitParameter("app.filter.wrap.request", "true");
		authenticationFilter.addMappingForServletNames(null, true, "app");
		authenticationFilter.addMappingForUrlPatterns(null, false, "/*");
		authenticationFilter.addMappingForUrlPatterns(null, false, "*.html");

		context.addFilter("SessionTimeoutFilter", SessionTimeoutFilter.class)
			.addMappingForUrlPatterns(null, true, "*");
		//Logout filter
		context.addFilter("LogoutFilter", LogoutFilter.class).addMappingForUrlPatterns(null, true, "/logout/");
	}

	*//**
	 * @param rootContext
	 * @param name
	 * @param servletContextClass
	 * @param loadOnStartup
	 * @param mappings
	 *//*
	private void addServlet(ServletContext rootContext, String name, Class<? extends WebMvcConfigurationSupport> servletContextClass, int loadOnStartup, String... mappings) {
		AnnotationConfigWebApplicationContext servletContext = new AnnotationConfigWebApplicationContext();
		servletContext.register(servletContextClass);
		
		ServletRegistration.Dynamic dispatcher = rootContext.addServlet(name, new DispatcherServlet(servletContext));
		dispatcher.setAsyncSupported(true);
		dispatcher.setLoadOnStartup(loadOnStartup);
		dispatcher.addMapping(mappings);
	}
}
*/