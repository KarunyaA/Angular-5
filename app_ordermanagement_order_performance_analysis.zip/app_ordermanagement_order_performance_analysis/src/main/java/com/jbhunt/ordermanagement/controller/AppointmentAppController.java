package com.jbhunt.ordermanagement.controller;

import static com.jbhunt.ordermanagement.constants.OrderConstants.RECORD_STATUS;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jbhunt.contact.entities.PhoneCallVO;
import com.jbhunt.contact.entities.StandardCodeVO;
import com.jbhunt.ordermanagement.util.ContactWebserviceClient;
import com.jbhunt.ordermanagement.util.ContactWebserviceUtil;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/appointment")
@Slf4j
public class AppointmentAppController {

	private ContactWebserviceUtil contactWebserviceUtil;

	@Autowired
	public AppointmentAppController(ContactWebserviceUtil contactWebserviceUtil) {
		this.contactWebserviceUtil = contactWebserviceUtil;
	}

	/**
	 * Method to fetch Call Intent
	 * @param 
	 * @return Map<String, String>
	 */

	@GetMapping(value = "/contact/callintent/")
	public ResponseEntity<List<Map<String, String>>> fetchCalllogIntent() {
		log.debug("Inside the method fetchCalllogIntent()");
		List<Map<String, String>> callintentList = new ArrayList<>();
		contactWebserviceUtil.getStatusCodesByCallIntent().stream()
			.filter(statusCode -> RECORD_STATUS.equalsIgnoreCase(statusCode.getRecordStatus()))
			.forEach(standardCode -> {
				callintentList.add(getStandardCodeMap(standardCode));
			});
		return callintentList.isEmpty() ? new ResponseEntity<>(HttpStatus.NOT_FOUND)
				: new ResponseEntity<List<Map<String,String>>>(callintentList, HttpStatus.OK);
	}

	/**
	 * Method to fetch Call Result
	 * @param 
	 * @return Map<String, String>
	 */
	@GetMapping(value = "/contact/callresult/")
	public ResponseEntity<List<Map<String, String>>> fetchCalllogResult(Object eventRepository) {
		log.debug("Inside the method fetchCalllogResult()");
		List<Map<String, String>> callResultList = new ArrayList<>();
		contactWebserviceUtil.getStatusCodesByCallResult().stream()
				.filter(statusCode -> RECORD_STATUS.equalsIgnoreCase(statusCode.getRecordStatus()))
				.forEach(standardCode -> {
					callResultList.add(getStandardCodeMap(standardCode));
				});
		return callResultList.isEmpty() ? new ResponseEntity<>(HttpStatus.NOT_FOUND)
				: new ResponseEntity<List<Map<String,String>>>(callResultList, HttpStatus.OK);
	}

	/**
	 * Method to fetch Call Direction
	 * @param 
	 * @return Map<String, String>
	 */
	@GetMapping(value = "/contact/calldirection/")
	public ResponseEntity<List<Map<String, String>>> fetchCalllogDirection() {
		log.debug("Inside the method fetchCalllogDirection()");
		List<Map<String, String>> callDirectionList = new ArrayList<>();
		contactWebserviceUtil.getStatusCodesByCallDirection().stream()
				.filter(statusCode -> RECORD_STATUS.equalsIgnoreCase(statusCode.getRecordStatus()))
				.forEach(standardCode -> {
					callDirectionList.add(getStandardCodeMap(standardCode));
					});
		return callDirectionList.isEmpty() ? new ResponseEntity<>(HttpStatus.NOT_FOUND)
				: new ResponseEntity<List<Map<String,String>>>(callDirectionList, HttpStatus.OK);
	}

	/**
	 * Method to format the list as id-type values
	 * input : StandardCodeVO
	 * @return Map<String, String>
	 */
	private Map<String, String> getStandardCodeMap(StandardCodeVO  standardCode){
		Map<String, String> standardCodeMap = new LinkedHashMap<>();
		Optional.ofNullable(standardCode).ifPresent( code ->{
			standardCodeMap.put("id", code.getCode());
			standardCodeMap.put("type", code.getPresentationName());
		});
		return standardCodeMap;

	}

	/**
	 * Method to fetch CallLog
	 * @param orderTrackingNumber
	 * @return List<PhoneCallVO>
	 */

	@GetMapping(value = "/calllog/{orderTrackingNumber}")
	public ResponseEntity<List<PhoneCallVO>> fetchCalllog(@PathVariable String orderTrackingNumber) {
		log.debug("Inside the method fetchCalllog()");
		List<PhoneCallVO> phoneCallOptional  = contactWebserviceUtil.getPhoneCall(Arrays.asList(orderTrackingNumber.split("\\s*,\\s*")));
		return phoneCallOptional.isEmpty() ? new ResponseEntity<>(HttpStatus.NOT_FOUND)
				: new ResponseEntity<List<PhoneCallVO>>(phoneCallOptional, HttpStatus.OK);
	}

	/**
	 * Method to Save CallLog
	 * 
	 * @return List<PhoneCallVO>
	 */

	@PostMapping(value = "/calllog")
	public ResponseEntity<List<PhoneCallVO>> saveCalllog(@RequestBody List<PhoneCallVO> phoneCalls) {
		log.debug("Inside the method saveCalllog()");
		List<PhoneCallVO> savedPhoneCall = contactWebserviceUtil.savePhoneCalls(phoneCalls);
		return new ResponseEntity<List<PhoneCallVO>>(savedPhoneCall, HttpStatus.CREATED);
	}	

}
