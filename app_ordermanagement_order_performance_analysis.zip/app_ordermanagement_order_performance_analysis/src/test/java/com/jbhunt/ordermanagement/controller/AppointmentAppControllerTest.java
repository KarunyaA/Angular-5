package com.jbhunt.ordermanagement.controller;

import static org.mockito.Matchers.anyList;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.springframework.restdocs.mockmvc.MockMvcRestDocumentation.document;
import static org.springframework.restdocs.mockmvc.MockMvcRestDocumentation.documentationConfiguration;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.ConfigFileApplicationContextInitializer;
import org.springframework.http.MediaType;
import org.springframework.restdocs.JUnitRestDocumentation;
import org.springframework.restdocs.mockmvc.RestDocumentationResultHandler;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jbhunt.contact.entities.ArrayOfStandardCodeVO;
import com.jbhunt.contact.entities.PhoneCallVO;
import com.jbhunt.contact.entities.StandardCodeVO;
import com.jbhunt.ordermanagement.util.ContactWebserviceClient;
import com.jbhunt.ordermanagement.util.ContactWebserviceUtil;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(initializers = ConfigFileApplicationContextInitializer.class)
public class AppointmentAppControllerTest {

	@Rule
	public final JUnitRestDocumentation restDocumentation = new JUnitRestDocumentation("target/generated-snippets");
	private RestDocumentationResultHandler document;
	
	@InjectMocks
	private AppointmentAppController appointmentAppController;

	private MockMvc mockMvc;

	@InjectMocks
	private ContactWebserviceUtil contactWebserviceUtil;

	private ContactWebserviceClient contactWebserviceClient;

	@Before
	public void setup() {			
		this.document = document("{method-name}");
		contactWebserviceUtil = mock(ContactWebserviceUtil.class);
		contactWebserviceClient = mock(ContactWebserviceClient.class);
		appointmentAppController = new AppointmentAppController(contactWebserviceUtil);
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(appointmentAppController).apply(documentationConfiguration(this.restDocumentation).uris().withScheme("https"))
				.alwaysDo(this.document).build();
	}

	@Test
	public void testfetchCalllogIntentFallBack() throws Exception {

		// ---StandarCodeVO Array---
		ArrayOfStandardCodeVO arrayOfStatusCodeVO = new ArrayOfStandardCodeVO();

		// ---StandarCodeVO List---
		List<StandardCodeVO> standardCodeVOList = new ArrayList<StandardCodeVO>();

		// StandardCodeVO
		StandardCodeVO standardCodeVO = new StandardCodeVO();
		standardCodeVO.setRecordStatus("A");
		standardCodeVO.setCode("APPT");
		standardCodeVO.setPresentationName("Update Appointment");
		arrayOfStatusCodeVO.getStandardCodeVO().add(standardCodeVO);
		standardCodeVOList.add(standardCodeVO);

		// --- ACT ---
		when(contactWebserviceUtil.getStatusCodesByCallIntent()).thenCallRealMethod();
		when(contactWebserviceClient.getStatusCodesForCallIntent()).thenReturn(standardCodeVOList);

		// ----Mock MVC ---
		// --- EXPECTS ---
		// Expects status is ok and Call intent fallback output is correct
		mockMvc.perform(get("/appointment/contact/callintent/").contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk()).andExpect(jsonPath("$.[0].type").value("Update Appointment"))
				.andExpect(jsonPath("$[0].id").value("APPT"))
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE));
	}

	@Test
	public void testFetchCalllogIntentFail() throws Exception {

		// --- ACT---
		when(contactWebserviceUtil.getStatusCodesByCallIntent()).thenReturn(new ArrayList<StandardCodeVO>());

		// ---Mock MVC---
		// --- EXPECTS ---
		// Expects status is ok and Call intent doesn't exist
		mockMvc.perform(get("/appointment/contact/callintent/").contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isNotFound()).andExpect(jsonPath("$.APPT").doesNotExist());
	}

	@Test
	public void testFetchCalllogIntentSuccess() throws Exception {

		// ---StandarCodeVO Array---
		ArrayOfStandardCodeVO arrayOfStatusCodeVO = new ArrayOfStandardCodeVO();

		// ---StandardCodeVO List
		List<StandardCodeVO> standardCodeVOList = new ArrayList<StandardCodeVO>();

		// --- StandardCodeVO
		StandardCodeVO standardCodeVO = new StandardCodeVO();
		standardCodeVO.setRecordStatus("A");
		standardCodeVO.setCode("APPT");
		standardCodeVO.setPresentationName("Update Appointment");
		arrayOfStatusCodeVO.getStandardCodeVO().add(standardCodeVO);
		standardCodeVOList.add(standardCodeVO);

		// ---ACT ---
		when(contactWebserviceUtil.getStatusCodesByCallIntent()).thenReturn(standardCodeVOList);

		// ---Mock MVC ---
		// --- EXPECTS ---
		// Expects status is ok and Call intent output is correct
		mockMvc.perform(get("/appointment/contact/callintent/").contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk()).andExpect(jsonPath("$.[0].type").value("Update Appointment"))
				.andExpect(jsonPath("$[0].id").value("APPT"))
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)).andDo(document);
	}
	
	@Test
	public void testFetchCalllogResultFail() throws Exception {
		// ---ACT ---
		when(contactWebserviceUtil.getStatusCodesByCallResult()).thenReturn(new ArrayList<StandardCodeVO>());

		// ---Mock MVC---
		// --- EXPECTS ---
		// Expects status is ok and Call result doesn't exist
		mockMvc.perform(get("/appointment/contact/callresult/").contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isNotFound()).andExpect(jsonPath("$.[0].type").doesNotExist());
	}

	@Test
	public void testFetchCalllogResultSuccess() throws Exception {

		// StandardCodeVO Array
		ArrayOfStandardCodeVO arrayOfStatusCodeVO = new ArrayOfStandardCodeVO();

		// StandardCode List
		List<StandardCodeVO> standardCodeVOList = new ArrayList<StandardCodeVO>();

		// StandardCode
		StandardCodeVO standardCodeVO = new StandardCodeVO();
		standardCodeVO.setRecordStatus("A");
		standardCodeVO.setCode("33");
		standardCodeVO.setPresentationName("Answer");
		arrayOfStatusCodeVO.getStandardCodeVO().add(standardCodeVO);
		standardCodeVOList.add(standardCodeVO);
		// ---ACT---
		when(contactWebserviceUtil.getStatusCodesByCallResult()).thenReturn(standardCodeVOList);

		// ---Mock MVC---
		// --- EXPECTS ---
		// Expects status is ok and Call result output is correct
		mockMvc.perform(get("/appointment/contact/callresult/").contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk()).andExpect(jsonPath("$.[0].type").value("Answer"))
				.andExpect(jsonPath("$.[0].id").value("33"))
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)).andDo(document);
	}
	
	@Test
	public void testFetchCalllogResultFallBack() throws Exception {

		// StandardCodeVO Array
		ArrayOfStandardCodeVO arrayOfStatusCodeVO = new ArrayOfStandardCodeVO();

		// StandardCode List
		List<StandardCodeVO> standardCodeVOList = new ArrayList<StandardCodeVO>();

		// StandardCode
		StandardCodeVO standardCodeVO = new StandardCodeVO();
		standardCodeVO.setRecordStatus("A");
		standardCodeVO.setCode("33");
		standardCodeVO.setPresentationName("Answer");
		arrayOfStatusCodeVO.getStandardCodeVO().add(standardCodeVO);
		standardCodeVOList.add(standardCodeVO);

		// ---ACT---
		when(contactWebserviceUtil.getStatusCodesByCallResult()).thenCallRealMethod();
		when(contactWebserviceClient.getStatusCodesForCallResult()).thenReturn(standardCodeVOList);

		// ---Mock MVC---
		// ----EXPECTS---
		// Expects status is ok and Call result output is correct
		mockMvc.perform(get("/appointment/contact/callresult/").contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk()).andExpect(jsonPath("$.[0].type").value("Answer"))
				.andExpect(jsonPath("$.[0].id").value("33"))
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE));
	}

	@Test
	public void testFetchCalllogDirectionFail() throws Exception {
		when(contactWebserviceUtil.getStatusCodesByCallDirection()).thenReturn(new ArrayList<StandardCodeVO>());
		mockMvc.perform(get("/appointment/contact/calldirection/").contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isNotFound()).andExpect(jsonPath("$.[0].type").doesNotExist());
	}

	@Test
	public void testFetchCalllogDirectionSuccess() throws Exception {

		// StandardCodeVO Array
		ArrayOfStandardCodeVO arrayOfStatusCodeVO = new ArrayOfStandardCodeVO();

		// StandardCode List
		List<StandardCodeVO> standardCodeVOList = new ArrayList<StandardCodeVO>();

		// StandardCode
		StandardCodeVO standardCodeVO = new StandardCodeVO();
		standardCodeVO.setRecordStatus("A");
		standardCodeVO.setCode("INBOUND");
		standardCodeVO.setPresentationName("Inbound");
		arrayOfStatusCodeVO.getStandardCodeVO().add(standardCodeVO);
		standardCodeVOList.add(standardCodeVO);

		// ---ACT---
		when(contactWebserviceUtil.getStatusCodesByCallDirection()).thenReturn(standardCodeVOList);

		// ---Mock MVC---
		// Expects status is ok and Call direction output is correct
		mockMvc.perform(get("/appointment/contact/calldirection/").contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
				.andExpect(jsonPath("$.[0].type").value("Inbound"))
				.andExpect(jsonPath("$.[0].id").value("INBOUND")).andDo(document);
	}
	
	@Test
	public void testFetchCalllogDirectionFallBack() throws Exception {

		// StandardCodeVO Array
		ArrayOfStandardCodeVO arrayOfStatusCodeVO = new ArrayOfStandardCodeVO();

		// StandardCode List
		List<StandardCodeVO> standardCodeVOList = new ArrayList<StandardCodeVO>();

		// StandardCode
		StandardCodeVO standardCodeVO = new StandardCodeVO();
		standardCodeVO.setRecordStatus("A");
		standardCodeVO.setCode("INBOUND");
		standardCodeVO.setPresentationName("Inbound");
		arrayOfStatusCodeVO.getStandardCodeVO().add(standardCodeVO);
		standardCodeVOList.add(standardCodeVO);

		// ---ACT---
		when(contactWebserviceUtil.getStatusCodesByCallDirection()).thenCallRealMethod();
		when(contactWebserviceClient.getStatusCodesForCallDirection()).thenReturn(standardCodeVOList);

		// ---Mock MVC---

		// --- EXPECTS ---
		// Expects status is ok and Call direction fallback output is correct
		mockMvc.perform(get("/appointment/contact/calldirection/").contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk()).andExpect(jsonPath("$.[0].type").value("Inbound"))
				.andExpect(jsonPath("$.[0].id").value("INBOUND"))
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE));
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testFetchCalllogFail() throws Exception {
		when(contactWebserviceUtil.getPhoneCall(anyList())).thenReturn(new ArrayList<PhoneCallVO>());
		mockMvc.perform(get("/appointment/calllog/ORD1/").contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isNotFound()).andExpect(jsonPath("$[0].contactFirstName").doesNotExist());
	}

	@Test
	public void testFetchCalllogSuccess() throws Exception {

		// PhoneCallVO List
		List<PhoneCallVO> phoneCallVOList = new ArrayList<PhoneCallVO>();

		// PhoneCallVO
		PhoneCallVO phoneCallVO = new PhoneCallVO();
		setPhoneCallVO(phoneCallVO);

		phoneCallVOList.add(phoneCallVO);

		// New List
		List<String> list = new ArrayList<>();
		list.add("TRACK1");

		// ---ACT---
		when(contactWebserviceUtil.getPhoneCall(list)).thenReturn(phoneCallVOList);

		// ---Mock MVC---
		// --- EXPECTS ---
		// Expects status is ok and Call Log List output is correct
		mockMvc.perform(get("/appointment/calllog/TRACK1/").contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk()).andExpect(jsonPath("$[0].contactFirstName").value("John"))
				.andExpect(jsonPath("$[0].contactLastName").value("Smith"))
				.andExpect(jsonPath("$[0].callResult").value("Answered"))
				.andExpect(jsonPath("$[0].communicationDirection").value("Inbound"))
				.andExpect(jsonPath("$[0].phoneNumber").value("001-090-343-21"))
				.andExpect(jsonPath("$[0].intentCode").value("Update Appointment"))
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)).andDo(document);
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testSaveCalllogSuccess() throws Exception {

		// PhoneCallVO List
		List<PhoneCallVO> phoneCallVOList = new ArrayList<PhoneCallVO>();

		// PhoneCallVO
		PhoneCallVO phoneCallVO = new PhoneCallVO();
		setPhoneCallVO(phoneCallVO);
		phoneCallVO.setIdentity(467878);

		phoneCallVOList.add(phoneCallVO);

		// ---ACT---
		when(contactWebserviceUtil.savePhoneCalls(anyList())).thenReturn(phoneCallVOList);

		// ---Mock MVC---
		// --- EXPECTS ---
		// Expects Call Log has been saved successfully
		mockMvc.perform(post("/appointment/calllog").contentType(MediaType.APPLICATION_JSON)
				.content(asJsonString(phoneCallVOList))).andExpect(status().isCreated())
				.andExpect(jsonPath("$[0].contactFirstName").value("John"))
				.andExpect(jsonPath("$[0].contactLastName").value("Smith"))
				.andExpect(jsonPath("$[0].callResult").value("Answered"))
				.andExpect(jsonPath("$[0].communicationDirection").value("Inbound"))
				.andExpect(jsonPath("$[0].phoneNumber").value("001-090-343-21"))
				.andExpect(jsonPath("$[0].intentCode").value("Update Appointment")).andDo(document);

	}

	@SuppressWarnings("unchecked")
	@Test
	public void testSaveCalllogFail() throws Exception {

		// PhoneCallVO
		PhoneCallVO phoneCallVO = new PhoneCallVO();
		setPhoneCallVO(phoneCallVO);

		// PhoneCallVO List
		List<PhoneCallVO> phoneCallVOList = new ArrayList<PhoneCallVO>();
		//phoneCallVOList.add(phoneCallVO);

		// ---ACT---
		when(contactWebserviceUtil.savePhoneCalls(anyList())).thenReturn(phoneCallVOList);

		// ---Mock MVC---
		// --- EXPECTS ---
		// Expects Call Log save has been failed
		mockMvc.perform(post("/appointment/call").contentType(MediaType.APPLICATION_JSON)
				.content(asJsonString(phoneCallVOList))).andExpect(status().isNotFound());
	}
	
	public static String asJsonString(final Object obj) throws JsonProcessingException {
		return new ObjectMapper().writeValueAsString(obj);
	}

	// To set PhoneCallVO values

	private PhoneCallVO setPhoneCallVO(PhoneCallVO phoneCallVO) {
		phoneCallVO.setContactFirstName("John");
		phoneCallVO.setContactLastName("Smith");
		phoneCallVO.setCallResult("Answered");
		phoneCallVO.setCommunicationDirection("Inbound");
		phoneCallVO.setPhoneNumber("001-090-343-21");
		phoneCallVO.setIntentCode("Update Appointment");
		phoneCallVO.setCommunicationType("WEB");
		phoneCallVO.setCreatedProgramCode("OM");
		phoneCallVO.setCreatedUserId("Agent");
		phoneCallVO.setLastUpdatedProgramCode("OM");
		phoneCallVO.setLastUpdatedUserId("Agent");
		phoneCallVO.setHumanResourcePersonId("220837");		
		return phoneCallVO;
	}

}