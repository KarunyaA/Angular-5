package com.jbhunt.ordermanagement.controller;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.jbhunt.hrms.eoi.api.dto.adhoc.AdHocPersonDTO;
import com.jbhunt.hrms.eoi.api.dto.adhoc.AdHocPersonsDTO;
import com.jbhunt.ordermanagement.order.dto.UserDetailDTO;

@RunWith(SpringJUnit4ClassRunner.class)
public class UserDetailsControllerTest {

	private MockMvc mockMvc;

	private UserDetailsController userDetailsController;
	@Mock
	private UserDetailsService userDetailsService;

	@Before
	public void setup() {
		userDetailsController = new UserDetailsController(userDetailsService);
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(userDetailsController).build();
	}

	@Test
	public void fetchUserDetailsTest() throws Exception {
		when(userDetailsService.fetchUserDetails("rcon452")).thenReturn(mockUserDetailsDTO());
		userDetailsController.fetchUserDetails("rcon452");
		this.mockMvc.perform(get("/users/{userID}", 1).accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
		

	}

	private UserDetailDTO mockUserDetailsDTO() {
		UserDetailDTO userDetailDTO = new UserDetailDTO();
		userDetailDTO.setUserId("rcon452");
		userDetailDTO.setEmailAddress("mock@jbhunt.com");
		userDetailDTO.setFirstName("Mark Antony");
		userDetailDTO.setLastName("Bond");
		userDetailDTO.setEmployeeId("007");
		userDetailDTO.setPhoneNumber("900900900");
		userDetailDTO.setDisplayName("James");
		return userDetailDTO;
	}

	@Test
	public void getPeopleByCriteria() throws Exception {
		when(userDetailsService.getPeopleByCriteria("rcon452")).thenReturn(mockList());
		userDetailsController.getPeopleByCriteria("rcon452");
		this.mockMvc.perform(get("/getPeopleByCriteria/{userID}", 1).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());
		

	}

	private List<AdHocPersonDTO> mockList() {
		AdHocPersonsDTO adHocPersonsDTO = new AdHocPersonsDTO();
		AdHocPersonDTO dto = new AdHocPersonDTO();
		dto.setEmplid("007");
		List<AdHocPersonDTO> dtos = new ArrayList();
		dtos.add(dto);
		adHocPersonsDTO.setPeople(dtos);
		return dtos;
	}
}
