package com.jbhunt.ordermanagement.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Matchers.anyList;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.boot.test.context.ConfigFileApplicationContextInitializer;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.jbhunt.contact.entities.PhoneCallVO;
import com.jbhunt.contact.entities.StandardCodeVO;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(initializers = ConfigFileApplicationContextInitializer.class)
public class ContactWebserviceUtilTest {

	private ContactWebserviceUtil contactWeserviceUtil;

	@Mock
	private ContactWebserviceClient contactWebserviceClient;

	@Before
	public void setup() {
		contactWeserviceUtil = new ContactWebserviceUtil(contactWebserviceClient);
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testGetPhoneCallFail() {
		when(contactWebserviceClient.getPhoneCallRequest(anyList())).thenReturn(null);
		assertNull(contactWeserviceUtil.getPhoneCall(new ArrayList<String>()));
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testGetPhoneCallSuccess() {

		// ---ACT---
		when(contactWebserviceClient.getPhoneCallRequest(anyList())).thenReturn(getPhoneCallList());
		List<String> trackingNumbers = new ArrayList<String>();
		trackingNumbers.add("ORD1");
		List<PhoneCallVO> phoneCallVOList = contactWeserviceUtil.getPhoneCall(trackingNumbers);

		// ---ASSERT---
		// Assert not null and list size
		assertNotNull(phoneCallVOList);
		assertEquals("PhoneCallVO size", 1, phoneCallVOList.size());
		assertEquals("Answered", phoneCallVOList.get(0).getCallResult());
	}

	@Test
	public void testGetStatusCodesByCallIntentFail() {

		// ---ACT---
		when(contactWebserviceClient.getStatusCodesForCallIntent()).thenReturn(null);
		List<StandardCodeVO> standardCodeVOList = contactWeserviceUtil.getStatusCodesByCallIntent();

		// ---ASSERT----
		// Assert null
		assertNull(standardCodeVOList);
	}

	@Test
	public void testGetStatusCodesByCallIntentSuccess() {

		// ---ACT---
		when(contactWebserviceClient.getStatusCodesForCallIntent()).thenReturn(getStandardCodeVOList());
		List<StandardCodeVO> standardCodeVOList = contactWeserviceUtil.getStatusCodesByCallIntent();

		// ---ASSERT---
		// Assert not null, list size and equals the name
		assertNotNull(standardCodeVOList);
		assertEquals(1, standardCodeVOList.size());
		assertEquals("StandardCode Size", 1, standardCodeVOList.size());
		assertEquals("Presentation", standardCodeVOList.get(0).getPresentationName());
	}

	@Test
	public void testGetStatusCodesByCallResultFail() {

		// ---ACT---
		when(contactWebserviceClient.getStatusCodesForCallResult()).thenReturn(null);
		List<StandardCodeVO> standardCodeVOList = contactWeserviceUtil.getStatusCodesByCallResult();

		// ---ASSERT---
		// Assert null
		assertNull(standardCodeVOList);
	}

	@Test
	public void testGetStatusCodesByCallResultSuccess() {

		// ---ACT---
		when(contactWebserviceClient.getStatusCodesForCallResult()).thenReturn(getStandardCodeVOList());
		List<StandardCodeVO> standardCodeVOList = contactWeserviceUtil.getStatusCodesByCallResult();

		// ---ASSERT---
		// Assert not null,list size and equals the name
		assertNotNull(standardCodeVOList);
		assertEquals(1, standardCodeVOList.size());
		assertEquals("StandardCode Size", 1, standardCodeVOList.size());
		assertEquals("Presentation", standardCodeVOList.get(0).getPresentationName());
	}

	@Test
	public void testGetStatusCodesByCallDirectionFail() {

		// ---ACT---
		when(contactWebserviceClient.getStatusCodesForCallDirection()).thenReturn(null);
		List<StandardCodeVO> standardCodeVOList = contactWeserviceUtil.getStatusCodesByCallDirection();

		// ---ASSERT---
		// Assert null
		assertNull(standardCodeVOList);
	}

	@Test
	public void getStatusCodesForCallDirectionSuccess() {

		// ---ACT---
		when(contactWebserviceClient.getStatusCodesForCallDirection()).thenReturn(getStandardCodeVOList());
		List<StandardCodeVO> standardCodeVOList = contactWeserviceUtil.getStatusCodesByCallDirection();

		// ---ASSERT---
		// Assert not null, list size and equals name
		assertNotNull(standardCodeVOList);
		assertEquals(1, standardCodeVOList.size());
		assertEquals("StandardCode Size", 1, standardCodeVOList.size());
		assertEquals("Presentation", standardCodeVOList.get(0).getPresentationName());
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testSavePhoneCallsFail() {
		when(contactWebserviceClient.savePhoneCalls(anyList())).thenReturn(null);
		List<PhoneCallVO> phoneCallVOList = contactWeserviceUtil.savePhoneCalls(new ArrayList<PhoneCallVO>());
		assertNull(phoneCallVOList);
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testSavePhoneCallsSuccess() {

		// ---ACT---
		when(contactWebserviceClient.savePhoneCalls(anyList())).thenReturn(getPhoneCallList());
		List<PhoneCallVO> phoneCallVOList = contactWeserviceUtil.savePhoneCalls(getPhoneCallList());

		// ---ASSERT---
		// Assert not null and list size
		assertNotNull(phoneCallVOList);
		assertEquals("PhoneCallVO size", 1, phoneCallVOList.size());
		assertEquals("Answered", phoneCallVOList.get(0).getCallResult());
	}

	// To set standard code values
	private List<StandardCodeVO> getStandardCodeVOList() {
		List<StandardCodeVO> standardCodeVOList = new ArrayList<StandardCodeVO>();
		StandardCodeVO standardCodeVO = new StandardCodeVO();
		standardCodeVO.setCode("Code");
		standardCodeVO.setCodeType("StandardCodeType");
		standardCodeVO.setPresentationName("Presentation");
		standardCodeVO.setRecordStatus("A");
		standardCodeVOList.add(standardCodeVO);
		return standardCodeVOList;

	}

	// To set PhoneCallVO values
	private List<PhoneCallVO> getPhoneCallList() {

		// PhoneCallVO
		PhoneCallVO phoneCallVO = new PhoneCallVO();
		phoneCallVO.setContactFirstName("John");
		phoneCallVO.setContactLastName("Smith");
		phoneCallVO.setCallResult("Answered");
		phoneCallVO.setCommunicationDirection("Inbound");
		phoneCallVO.setPhoneNumber("001-090-343-21");
		phoneCallVO.setIntentCode("Update Appointment");
		List<PhoneCallVO> phoneCallVOList = new ArrayList<PhoneCallVO>();
		phoneCallVOList.add(phoneCallVO);

		return phoneCallVOList;
	}

}
