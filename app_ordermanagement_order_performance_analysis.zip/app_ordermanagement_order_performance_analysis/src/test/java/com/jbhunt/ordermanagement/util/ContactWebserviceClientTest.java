package com.jbhunt.ordermanagement.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyList;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.datacontract.schemas._2004._07.com_jbhunt_apps_contact_model.StandardCodeTypesStandardCode;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.ConfigFileApplicationContextInitializer;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.jbhunt.contact.IContactWebService;
import com.jbhunt.contact.entities.ArrayOfPhoneCallVO;
import com.jbhunt.contact.entities.ArrayOfStandardCodeVO;
import com.jbhunt.contact.entities.PhoneCallVO;
import com.jbhunt.contact.entities.StandardCodeVO;
import com.jbhunt.contact.factory.GetPhoneCallRequestFactory;
import com.jbhunt.contact.factory.GetStandardCodeRequestFactory;
import com.jbhunt.contact.factory.SavePhoneCallRequestFactory;
import com.jbhunt.contact.requestresponseobjects.GetPhoneCallsRequest;
import com.jbhunt.contact.requestresponseobjects.GetPhoneCallsResponse;
import com.jbhunt.contact.requestresponseobjects.GetStandardCodesRequest;
import com.jbhunt.contact.requestresponseobjects.GetStandardCodesResponse;
import com.jbhunt.contact.requestresponseobjects.SavePhoneCallResponse;
import com.jbhunt.contact.requestresponseobjects.SavePhoneCallsRequest;
import com.jbhunt.ordermanagement.properties.OrderProperties;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(initializers = ConfigFileApplicationContextInitializer.class)
public class ContactWebserviceClientTest {

	@InjectMocks
	private ContactWebserviceClient contactWebserviceClient;

	@Mock
	private OrderProperties orderProperties;

	@Mock
	private IContactWebService iContactWebService;

	@Mock
	private GetStandardCodeRequestFactory getStandardCodeRequestFactory;

	@Mock
	private SavePhoneCallRequestFactory savePhoneCallRequestFactory;

	@Mock
	private GetPhoneCallRequestFactory getPhoneCallRequestFactory;

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testGetPhoneCallRequestSuccess() {
		
		//request 
		GetPhoneCallsResponse getPhoneCallResponse = new GetPhoneCallsResponse();
		
		//Response
		ArrayOfPhoneCallVO arrayOfPhoneCallVo = new ArrayOfPhoneCallVO();
		arrayOfPhoneCallVo.getPhoneCallVO().add(getPhoneCall());
		getPhoneCallResponse.setPhoneCalls(arrayOfPhoneCallVo);
		GetPhoneCallsRequest getPhoneCallsRequest = new GetPhoneCallsRequest();
		
		//---ACT---
		when(getPhoneCallRequestFactory.getPhoneCallByTrackingNumbers(anyList())).thenReturn(getPhoneCallsRequest);
		when(iContactWebService.getPhoneCalls(any(GetPhoneCallsRequest.class))).thenReturn(getPhoneCallResponse);
		List<String> list = new ArrayList<String>();
		list.add("ORD1");
		
		//---ASSERT---
		//Assert not null
		assertNotNull(contactWebserviceClient.getPhoneCallRequest(list));
	}

	@Test
	public void testGetPhoneCallRequestFail() {
		
		//Request
		GetPhoneCallsResponse getPhoneCallResponse = new GetPhoneCallsResponse();
		
		//Response
		ArrayOfPhoneCallVO arrayOfPhoneCallVo = new ArrayOfPhoneCallVO();
		getPhoneCallResponse.setPhoneCalls(arrayOfPhoneCallVo);
		GetPhoneCallsRequest getPhoneCallsRequest = new GetPhoneCallsRequest();
		
		//---ACT---
		when(getPhoneCallRequestFactory.getPhoneCallByTrackingNumbers(anyList())).thenReturn(getPhoneCallsRequest);
		when(iContactWebService.getPhoneCalls(any(GetPhoneCallsRequest.class))).thenReturn(getPhoneCallResponse);
		List<String> list = new ArrayList<String>();
		list.add("ORD1");
		List<PhoneCallVO> phoneCallVOList = contactWebserviceClient.getPhoneCallRequest(list);
		
		//---ASSERT---
		//Assert list size
		assertEquals("Phone CallVO size", phoneCallVOList.size(), 0);
	}

	@Test
	public void testGetStatusCodesForCallIntentSuccess() {

		// Request
		GetStandardCodesRequest request = new GetStandardCodesRequest();

		// Response
		GetStandardCodesResponse response = new GetStandardCodesResponse();
		ArrayOfStandardCodeVO arrayOfStatusCodeVO = new ArrayOfStandardCodeVO();
		StandardCodeVO standardCodeVO = new StandardCodeVO();
		standardCodeVO.setRecordStatus("A");
		standardCodeVO.setCode("APPT");
		standardCodeVO.setPresentationName("Update Appointment");
		arrayOfStatusCodeVO.getStandardCodeVO().add(standardCodeVO);
		response.setStandardCodes(arrayOfStatusCodeVO);

		// ---ACT---
		when(getStandardCodeRequestFactory.getStandardCodesRequest(StandardCodeTypesStandardCode.CALL_INTENT))
				.thenReturn(request);
		when(iContactWebService.getStandardCodes(request)).thenReturn(response);
		List<String> list = new ArrayList<String>();
		list.add("ORD1");
		List<StandardCodeVO> standardCodeVOList = contactWebserviceClient.getStatusCodesForCallIntent();

		// ---ASSERT---
		// Assert not null and list size
		assertNotNull(standardCodeVOList);
		assertEquals("standardCodeVO size", 1, standardCodeVOList.size());
	}

	@Test
	public void testGetStatusCodesForCallIntentFail() {

		// Request
		GetStandardCodesRequest request = new GetStandardCodesRequest();

		// Response
		GetStandardCodesResponse response = new GetStandardCodesResponse();
		ArrayOfStandardCodeVO arrayOfStatusCodeVO = new ArrayOfStandardCodeVO();
		response.setStandardCodes(arrayOfStatusCodeVO);

		// ---ACT---
		when(getStandardCodeRequestFactory.getStandardCodesRequest(StandardCodeTypesStandardCode.CALL_INTENT))
				.thenReturn(request);
		when(iContactWebService.getStandardCodes(request)).thenReturn(response);
		List<String> list = new ArrayList<String>();
		list.add("ORD1");
		List<StandardCodeVO> standardCodeVOList = contactWebserviceClient.getStatusCodesForCallIntent();

		// ---ASSERT---
		// Assert list size
		assertEquals("standardCodeVO size", 0, standardCodeVOList.size());
	}

	@Test
	public void testGetStatusCodesForCallResultSuccess() {

		// Request
		GetStandardCodesRequest request = new GetStandardCodesRequest();

		// Response
		GetStandardCodesResponse response = new GetStandardCodesResponse();

		// StandardCodeVO Array
		ArrayOfStandardCodeVO arrayOfStatusCodeVO = new ArrayOfStandardCodeVO();
		StandardCodeVO standardCodeVO = new StandardCodeVO();
		standardCodeVO.setRecordStatus("A");
		standardCodeVO.setCode("Answer");
		standardCodeVO.setPresentationName("Answer");
		arrayOfStatusCodeVO.getStandardCodeVO().add(standardCodeVO);
		response.setStandardCodes(arrayOfStatusCodeVO);

		// ---ACT---
		when(getStandardCodeRequestFactory.getStandardCodesRequest(StandardCodeTypesStandardCode.CALL_RESULT))
				.thenReturn(request);
		when(iContactWebService.getStandardCodes(request)).thenReturn(response);
		List<String> list = new ArrayList<String>();
		list.add("ORD1");
		List<StandardCodeVO> standardCodeVOList = contactWebserviceClient.getStatusCodesForCallResult();

		// ---ASSERT---
		// Assert null list
		assertNotNull(standardCodeVOList);

		// Assert list size
		assertEquals("standardCodeVO size", 1, standardCodeVOList.size());
	}

	@Test
	public void testGetStatusCodesForCallResultFail() {

		// Request
		GetStandardCodesRequest request = new GetStandardCodesRequest();

		// Request
		GetStandardCodesResponse response = new GetStandardCodesResponse();

		// Request
		ArrayOfStandardCodeVO arrayOfStatusCodeVO = new ArrayOfStandardCodeVO();
		response.setStandardCodes(arrayOfStatusCodeVO);

		// ---ACT---
		when(getStandardCodeRequestFactory.getStandardCodesRequest(StandardCodeTypesStandardCode.CALL_RESULT))
				.thenReturn(request);
		when(iContactWebService.getStandardCodes(request)).thenReturn(response);
		List<String> list = new ArrayList<String>();
		list.add("ORD1");
		List<StandardCodeVO> standardCodeVOList = contactWebserviceClient.getStatusCodesForCallResult();

		// ---ASSERT---
		// Assert the list size
		assertEquals("standardCodeVO size", 0, standardCodeVOList.size());
	}

	@Test
	public void testGetStatusCodesForCallDirectionSuccess() {

		// Request
		GetStandardCodesRequest request = new GetStandardCodesRequest();

		// Response
		GetStandardCodesResponse response = new GetStandardCodesResponse();

		// StandardCodeVO array
		ArrayOfStandardCodeVO arrayOfStatusCodeVO = new ArrayOfStandardCodeVO();
		StandardCodeVO standardCodeVO = new StandardCodeVO();
		standardCodeVO.setRecordStatus("A");
		standardCodeVO.setCode("Answer");
		standardCodeVO.setPresentationName("Answer");
		arrayOfStatusCodeVO.getStandardCodeVO().add(standardCodeVO);
		response.setStandardCodes(arrayOfStatusCodeVO);

		// ----ACT---
		when(getStandardCodeRequestFactory.getStandardCodesRequest(StandardCodeTypesStandardCode.CALL_DIRECTION))
				.thenReturn(request);
		when(iContactWebService.getStandardCodes(request)).thenReturn(response);
		List<String> list = new ArrayList<String>();
		list.add("ORD1");
		List<StandardCodeVO> standardCodeVOList = contactWebserviceClient.getStatusCodesForCallDirection();

		// ---ASSERT---
		// Assert the list size
		assertNotNull(standardCodeVOList);
		assertEquals("standardCodeVO size", 1, standardCodeVOList.size());
	}

	@Test
	public void testGetStatusCodesForCallDirectionFail() {

		// Request
		GetStandardCodesRequest request = new GetStandardCodesRequest();

		// Response
		GetStandardCodesResponse response = new GetStandardCodesResponse();

		// StandardCodeVO array
		ArrayOfStandardCodeVO arrayOfStatusCodeVO = new ArrayOfStandardCodeVO();
		response.setStandardCodes(arrayOfStatusCodeVO);

		// ----ACT---
		when(getStandardCodeRequestFactory.getStandardCodesRequest(StandardCodeTypesStandardCode.CALL_DIRECTION))
				.thenReturn(request);
		when(iContactWebService.getStandardCodes(request)).thenReturn(response);
		List<String> list = new ArrayList<String>();
		list.add("ORD1");
		List<StandardCodeVO> standardCodeVOList = contactWebserviceClient.getStatusCodesForCallDirection();

		// ---ASSERT---
		// Assert the list size
		assertEquals("standardCodeVO size", 0, standardCodeVOList.size());
	}

	@Test
	public void testSavePhoneCallsSuccess() {

		// Request
		SavePhoneCallsRequest request = new SavePhoneCallsRequest();
		// Response
		SavePhoneCallResponse response = new SavePhoneCallResponse();
		// PhoneCallVO array
		ArrayOfPhoneCallVO arrayOfPhoneCallVO = new ArrayOfPhoneCallVO();
		arrayOfPhoneCallVO.getPhoneCallVO().add(getPhoneCall());
		response.setPhoneCalls(arrayOfPhoneCallVO);

		// ----ACT---
		when(savePhoneCallRequestFactory.savePhoneCallsRequest(anyList())).thenReturn(request);
		when(iContactWebService.savePhoneCalls(any(SavePhoneCallsRequest.class))).thenReturn(response);
		List<PhoneCallVO> list = new ArrayList<PhoneCallVO>();
		list.add(getPhoneCall());
		List<PhoneCallVO> phoneCallVOList = contactWebserviceClient.savePhoneCalls(list);
		// ---ASSERT---
		// Assert the list size
		assertEquals("phoneCallVOList size", 1, phoneCallVOList.size());
	}

	@Test
	public void testSavePhoneCallsFail() {

		// Request
		SavePhoneCallsRequest request = new SavePhoneCallsRequest();

		// Response
		SavePhoneCallResponse response = new SavePhoneCallResponse();

		// PhoneCallVO Array
		ArrayOfPhoneCallVO arrayOfPhoneCallVO = new ArrayOfPhoneCallVO();
		response.setPhoneCalls(arrayOfPhoneCallVO);

		// ---ACT---
		when(savePhoneCallRequestFactory.savePhoneCallsRequest(anyList())).thenReturn(request);
		when(iContactWebService.savePhoneCalls(any(SavePhoneCallsRequest.class))).thenReturn(response);
		List<PhoneCallVO> list = new ArrayList<PhoneCallVO>();
		list.add(getPhoneCall());
		List<PhoneCallVO> phoneCallVOList = contactWebserviceClient.savePhoneCalls(list);
		// ---ASSERT----
		// Assert the list size
		assertEquals("phoneCallVOList size", 0, phoneCallVOList.size());
	}

	@Test
	public void testPopulateCallResultStaticValuesSuccess() {

		// ----ACT---
		when(orderProperties.getContactStatusCodesTypes()).thenReturn(getProperties());
		List<StandardCodeVO> list = contactWebserviceClient.populateCallResultStaticValues();

		// ---ASSERT---
		// Assert the list size and list value
		assertNotNull(list);
		assertEquals("Call Result Size", list.size(), 2);
		assertEquals(list.get(0).getRecordStatus(), "A");
	}

	@Test
	public void testPopulateCallResultStaticValuesFail() {

		// ----ACT---
		when(orderProperties.getContactStatusCodesTypes())
				.thenReturn(new ArrayList<Map<String, Map<String, String>>>());
		List<StandardCodeVO> list = contactWebserviceClient.populateCallResultStaticValues();

		// ---ASSERT---
		// Assert the list size
		assertEquals("Call Result Size", list.size(), 0);
	}

	@Test
	public void testPopulateCallDirectionStaticValuesSuccess() {
		// ---ACT---
		when(orderProperties.getContactStatusCodesTypes()).thenReturn(getProperties());
		List<StandardCodeVO> list = contactWebserviceClient.populateCallDirectionStaticValues();

		// ---ASSERT---
		// Assert the list size and list value
		assertNotNull(list);
		assertEquals("Call Direction Size", list.size(), 2);
		assertEquals(list.get(0).getRecordStatus(), "A");
	}

	@Test
	public void testPopulateCallDirectionStaticValuesFail() {

		// ---ACT---
		when(orderProperties.getContactStatusCodesTypes())
				.thenReturn(new ArrayList<Map<String, Map<String, String>>>());
		List<StandardCodeVO> list = contactWebserviceClient.populateCallDirectionStaticValues();

		// ---ASSERT---
		// Assert the list size
		assertEquals("Call Direction Size", list.size(), 0);
	}

	@Test
	public void testPopulateCallIntentStaticValuesSuccess() {

		// ---ACT---
		when(orderProperties.getContactStatusCodesTypes()).thenReturn(getProperties());
		List<StandardCodeVO> list = contactWebserviceClient.populateCallIntentStaticValues();

		// ---ASSERT---
		// Assert the list size and list value
		assertNotNull(list);
		assertEquals("Call Intent Size", list.size(), 2);
		assertEquals(list.get(0).getRecordStatus(), "A");
	}

	@Test
	public void testPopulateCallIntentStaticValuesFail() {

		// ---ACT---
		when(orderProperties.getContactStatusCodesTypes())
				.thenReturn(new ArrayList<Map<String, Map<String, String>>>());
		List<StandardCodeVO> list = contactWebserviceClient.populateCallIntentStaticValues();

		// ---ASSERT---
		// Assert the list size
		assertEquals("Call Intent Size", list.size(), 0);
	}

	// To prepare standard code property map
	private List<Map<String, Map<String, String>>> getProperties() {
		Map<String, Map<String, String>> values = new HashMap<String, Map<String, String>>();
		Map<String, String> mapIntent = new HashMap<String, String>();
		mapIntent.put("PRECALL", "PreCall Questionnaire and Appt");
		mapIntent.put("APPT", "Update Appointment");

		Map<String, String> mapResults = new HashMap<String, String>();
		mapResults.put("CALLRES1", "Call Result 1");
		mapResults.put("CALLRES2", "Call Result 2");

		Map<String, String> mapDirection = new HashMap<String, String>();
		mapDirection.put("CALLDIR1", "Inbound");
		mapDirection.put("CALLDIR2", "Outbound");

		values.put("CallIntent", mapIntent);
		values.put("CallResult", mapResults);
		values.put("CallDirection", mapDirection);

		List<Map<String, Map<String, String>>> list = new ArrayList<Map<String, Map<String, String>>>();
		list.add(values);
		return list;
	}

	// To set PhoneCallVO object

	private PhoneCallVO getPhoneCall() {
		PhoneCallVO phoneCallVO = new PhoneCallVO();
		phoneCallVO.setContactFirstName("John");
		phoneCallVO.setContactLastName("Smith");
		phoneCallVO.setCallResult("Answered");
		phoneCallVO.setCommunicationDirection("Inbound");
		phoneCallVO.setPhoneNumber("001-090-343-21");
		phoneCallVO.setIntentCode("Update Appointment");
		return phoneCallVO;
	}

}
