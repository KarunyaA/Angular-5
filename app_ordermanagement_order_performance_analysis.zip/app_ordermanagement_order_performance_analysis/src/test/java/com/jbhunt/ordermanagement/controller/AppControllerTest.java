package com.jbhunt.ordermanagement.controller;

import junit.framework.TestCase;

public class AppControllerTest extends TestCase {

	public void test_type() throws Exception {
		assertNotNull(AppController.class);
	}

	public void test_instantiation() throws Exception {
		AppController target = new AppController();
		assertNotNull(target);
	}

	public void test_home_A$() throws Exception {
		AppController target = new AppController();
		String actual = target.home();
		String expected = "forward:/index.html";
		assertEquals(expected, actual);
	}

}
