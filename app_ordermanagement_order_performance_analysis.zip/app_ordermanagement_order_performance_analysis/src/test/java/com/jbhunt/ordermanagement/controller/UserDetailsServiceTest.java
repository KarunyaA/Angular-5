package com.jbhunt.ordermanagement.controller;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.jbhunt.hrms.EOIAPIUtil.apiutil.EOIAPIUtil;
import com.jbhunt.hrms.EOIAPIUtil.exception.AdHocSearchParseException;
import com.jbhunt.hrms.EOIAPIUtil.exception.AuditInformationException;
import com.jbhunt.hrms.EOIAPIUtil.exception.EOIAPIException;
import com.jbhunt.hrms.EOIAPIUtil.exception.RecordNotFoundException;
import com.jbhunt.hrms.EOIAPIUtil.exception.SizeLimitExceededException;
import com.jbhunt.hrms.EOIAPIUtil.exception.TooManyRecordsException;
import com.jbhunt.hrms.eoi.api.dto.adhoc.AdHocPersonDTO;
import com.jbhunt.hrms.eoi.api.dto.adhoc.AdHocPersonsDTO;
import com.jbhunt.hrms.eoi.api.dto.person.PersonDTO;
import com.jbhunt.ordermanagement.order.dto.UserDetailDTO;
import com.jbhunt.security.boot.ldap.client.LdapClient;
import com.jbhunt.ws.ldap.models.JBHUser;
import com.jbhunt.ws.ldap.models.constants.JBHLdapUserAttributes;

import junit.framework.TestCase;

@RunWith(SpringJUnit4ClassRunner.class)
public class UserDetailsServiceTest extends TestCase {

	@Mock
	private LdapClient ldapClient;

	@Mock
	private EOIAPIUtil eoi;

	private UserDetailsService userDetailsService;

	@Before
	public void init() {
		userDetailsService = new UserDetailsService(ldapClient, eoi);
	}

	@Test
	public void testAppservice()
			throws RecordNotFoundException, TooManyRecordsException, AuditInformationException, EOIAPIException {
		Set<String> userIDs = new HashSet<>();
		userIDs.add("rcon452");
		Set<JBHLdapUserAttributes> fieldsToGet = new HashSet<>();
		fieldsToGet.add(JBHLdapUserAttributes.FIRST_NAME);
		fieldsToGet.add(JBHLdapUserAttributes.LAST_NAME);
		fieldsToGet.add(JBHLdapUserAttributes.AD_USERID);
		fieldsToGet.add(JBHLdapUserAttributes.EMAIL);
		fieldsToGet.add(JBHLdapUserAttributes.PHONE);
		fieldsToGet.add(JBHLdapUserAttributes.EMPLOYEE_NUMBER);
		fieldsToGet.add(JBHLdapUserAttributes.DISPLAY_NAME);
		when(ldapClient.findUsersByUserId(userIDs, fieldsToGet)).thenReturn(mockJbhUser());
		when(eoi.getPersonByUserID("rcon452")).thenReturn(mockPersonDTO());
		UserDetailDTO userDTO = userDetailsService.fetchUserDetails("rcon452");
		assertEquals(userDTO.getUserId(), "rcon452");
		assertEquals(userDTO.getEmailAddress(), "umashankar.srininvasasetty@jbhunt.com");
		assertEquals(userDTO.getFirstName(), "FirstName");
		assertEquals(userDTO.getLastName(), "LastName");
		assertEquals(userDTO.getEmployeeId(), "rcon452");
		assertEquals(userDTO.getPreferredName(), "Prefered Name");
		assertEquals(userDTO.getDisplayName(), "Umashankar s");
		assertEquals(userDTO.getBusinessUnit(), "BusinessUnit");
		assertEquals(userDTO.getPhoneNumber(), "9698708672");

	}

	@Test
	public void testAppserviceInvalidData()
			throws RecordNotFoundException, TooManyRecordsException, AuditInformationException, EOIAPIException {
		Set<String> userIDs = new HashSet<>();
		userIDs.add("rcon452");
		Set<JBHLdapUserAttributes> fieldsToGet = new HashSet<>();
		fieldsToGet.add(JBHLdapUserAttributes.FIRST_NAME);
		fieldsToGet.add(JBHLdapUserAttributes.LAST_NAME);
		fieldsToGet.add(JBHLdapUserAttributes.AD_USERID);
		fieldsToGet.add(JBHLdapUserAttributes.EMAIL);
		fieldsToGet.add(JBHLdapUserAttributes.PHONE);
		fieldsToGet.add(JBHLdapUserAttributes.EMPLOYEE_NUMBER);
		fieldsToGet.add(JBHLdapUserAttributes.DISPLAY_NAME);
		when(ldapClient.findUsersByUserId(userIDs, fieldsToGet)).thenReturn(mockJbhUser());
		when(eoi.getPersonByUserID("rcon452")).thenThrow(new RecordNotFoundException("To many records") {
		});
		UserDetailDTO userDTO = userDetailsService.fetchUserDetails("rcon452");
		assertEquals(userDTO.getUserId(), "rcon452");
		assertEquals(userDTO.getEmailAddress(), "umashankar.srininvasasetty@jbhunt.com");
		assertEquals(userDTO.getFirstName(), "FirstName");
		assertEquals(userDTO.getLastName(), "LastName");
		assertEquals(userDTO.getEmployeeId(), "rcon452");
		assertEquals(userDTO.getDisplayName(), "Umashankar s");
		assertEquals(userDTO.getPhoneNumber(), "9698708672");

	}

	private PersonDTO mockPersonDTO() {
		PersonDTO personDTO = new PersonDTO();
		personDTO.setBusinessUnit("BusinessUnit");
		personDTO.setPrefName("Prefered Name");
		return personDTO;
	}

	private List<JBHUser> mockJbhUser() {

		List<JBHUser> jbhUsers = new ArrayList();
		JBHUser jbhUser = new JBHUser();
		jbhUser.setUid("rcon452");
		jbhUser.setUserId("rcon452");
		jbhUser.setEmail("umashankar.srininvasasetty@jbhunt.com");
		jbhUser.setEmployeeNumber("rcon452");
		jbhUser.setDisplayName("Umashankar s");
		jbhUser.setFirstName("FirstName");
		jbhUser.setLastName("LastName");
		jbhUser.setPhone("9698708672");
		jbhUsers.add(jbhUser);
		return jbhUsers;
	}

	@Test
	public void testGetPeopleByCriteriaWithException() throws RecordNotFoundException, TooManyRecordsException,
			AuditInformationException, EOIAPIException, AdHocSearchParseException, SizeLimitExceededException {
		String userID = "rcon452";
		AdHocPersonsDTO adHocPersonsDTO = new AdHocPersonsDTO();
		AdHocPersonDTO dto = new AdHocPersonDTO();
		dto.setEmplid("q123");
		List<AdHocPersonDTO> dtos = new ArrayList();
		dtos.add(dto);
		adHocPersonsDTO.setPeople(dtos);
		when(eoi.getPeopleByCriteria("select  person.userid ",
				"Person.IsActive eq true AND Person.UserID LIKE '" + userID + "%'"))
						.thenThrow(new RecordNotFoundException("Exception Occured"));

		List<AdHocPersonDTO> output = userDetailsService.getPeopleByCriteria(userID);
		assertNull(output);
	}

	@Test
	public void testGetPeopleByCriteria() throws RecordNotFoundException, TooManyRecordsException,
			AuditInformationException, EOIAPIException, AdHocSearchParseException, SizeLimitExceededException {
		String userID = "rcon452";
		AdHocPersonsDTO adHocPersonsDTO = new AdHocPersonsDTO();
		AdHocPersonDTO dto = new AdHocPersonDTO();
		dto.setEmplid("q123");
		List<AdHocPersonDTO> dtos = new ArrayList();
		dtos.add(dto);
		adHocPersonsDTO.setPeople(dtos);
		when(eoi.getPeopleByCriteria("select  person.userid ",
				"Person.IsActive eq true AND Person.UserID LIKE '" + userID + "%'")).thenReturn(adHocPersonsDTO);
		userDetailsService.getPeopleByCriteria(userID);

	}
}
