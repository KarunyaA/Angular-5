package com.jbhunt.ordermanagement.filter;

import com.jbhunt.biz.securepid.PIDCredentials;

import junit.framework.TestCase;

public class OrderManagementZuulFilterTest extends TestCase {

	public void test_type() throws Exception {
		assertNotNull(OrderManagementZuulFilter.class);
	}

	public void test_instantiation() throws Exception {
		PIDCredentials ldapPidCredential = new PIDCredentials("PID", "PWD");
		OrderManagementZuulFilter target = new OrderManagementZuulFilter(ldapPidCredential);
		assertNotNull(target);
	}

	public void test_run_A$() throws Exception {
		PIDCredentials ldapPidCredential = new PIDCredentials("PID", "PWD");
		;
		OrderManagementZuulFilter target = new OrderManagementZuulFilter(ldapPidCredential);
		Object actual = target.run();
		Object expected = null;
		assertEquals(expected, actual);
	}

	public void test_shouldFilter_A$() throws Exception {
		PIDCredentials ldapPidCredential = new PIDCredentials("PID", "PWD");;
		OrderManagementZuulFilter target = new OrderManagementZuulFilter(ldapPidCredential);
		boolean actual = target.shouldFilter();
		boolean expected = true;
		assertEquals(expected, actual);
	}

	public void test_filterOrder_A$() throws Exception {
		PIDCredentials ldapPidCredential = new PIDCredentials("PID", "PWD");;
		OrderManagementZuulFilter target = new OrderManagementZuulFilter(ldapPidCredential);
		int actual = target.filterOrder();
		int expected = 0;
		assertEquals(expected, actual);
	}

	public void test_filterType_A$() throws Exception {
		PIDCredentials ldapPidCredential = null;
		OrderManagementZuulFilter target = new OrderManagementZuulFilter(ldapPidCredential);
		String actual = target.filterType();
		String expected = "pre";
		assertEquals(expected, actual);
	}

}
